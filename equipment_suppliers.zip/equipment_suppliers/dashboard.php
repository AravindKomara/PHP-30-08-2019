﻿<?php session_start();
if(!isset($_SESSION['eq_user_id'])){
    // redirect them to your desired location
    header('location:index.php');
    exit;
}
include_once("header.php");?>
<!--div class="content" id="applicationbody"-->
<?php include_once("menu.php");?>
<?php include_once("footer.php");?>