<!-- Modal Footer for track -->
<div class="modal fade in" id="Modal_for_all" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog" style="width:80%;">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
				<h3 class="modal-title" style="width:300px;" id="myModalLabel"></h3>
			</div>
			<div class="modal-body" style="float:left; width:100%; background: #fff;">
				<div class="col-md-12" id="trackresult">
				</div>
			</div>
			<div id="modalfooter" class="modal-footer">
				
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	sessionStorage.setItem("eqsu_user_id", "<?php echo $_SESSION["eq_user_id"]; ?>");
	sessionStorage.setItem("eqsu_user_name", "<?php echo "".$_SESSION['eq_user_name']; ?>");
	sessionStorage.setItem("base_url", "<?php echo $base_url; ?>");
</script>
<script src="js/common-config.js"></script>
<script src="js/custom.js?v=1.0"></script>
<script src="js/viewRender.js?v1.0"></script>
<script src="js/serverDataTables.js?v=1.0"></script>
<script src="js/bootstrap-datepicker.js"></script>	
<script src="js/jquery.dataTables.min.js"></script>		
<script src="js/dataTables.bootstrap.min.js"></script>	
<script type="text/javascript">
	$("#btnOrderSearch").click(function(){
		if ($(".custom_search").hasClass("custom_searchpre"))
			$(".custom_search").removeClass("custom_searchpre");
		else
			$(".custom_search").addClass("custom_searchpre");
	});

	$(document).ready(function(){
		$(".loader").show();
		allOrders('all_orders','allordersview',false,1,true);
	});

	$('body').on('click','.datepicker',function(){
		$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true,
		});
	}).on('focus', '.datepicker', function() {
		$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true,
		});
	});

	var today = new Date();
	$("#vendordate").datepicker({
		'setStartDate': '+1d'
	});
</script>

</body>
</html>