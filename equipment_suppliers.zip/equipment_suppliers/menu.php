<section class="tabs_overlay container-fluid" id="pharma_menu" style="margin-top:45px;">
	<div class='container-fluid'>
		<article class='medicine_details'>
			<div class='col-md-9 col-sm-9 col-xs-9'>
				<h1>Medical Equipment Orders</h1>
			</div>
			<!--<div class='col-md-3 col-sm-3'>
				<a href='#' onclick='exportcsv()' class='export_csv_btn pull-right'>Export CSV</a>
			</div>-->
		</article>
	</div>
</section>
<section class='container-fluid' id='patientBannerInfo'></section>
<section id="pharma_widgets">
	<div class='container-fluid custom_pop_rx'>
		<ul class='nav nav-tabs cust_nav'>
			<li role='presentation' class='active'>
				<a onclick="allOrders('all_orders','allordersview',false,1,true);" aria-controls='home' role='tab' data-toggle='tab'>
					<i class='fa fa-shopping-cart' aria-hidden='true'></i>
					All Orders (<span id='allorder_count'>0</span>)
				</a>
			</li>
			<li role='presentation'>
				<a onclick="allOrders('tobeconfirmed','allordersview',false,1,true);" aria-controls='home' role='tab' data-toggle='tab'>
					<i class='fa fa-shopping-cart' aria-hidden='true'></i>
					To be Confirm (<span id='vendor_assigned_count'>0</span>)
				</a>
			</li>
			<li role='presentation'>
				<a onclick="allOrders('requested_pickup','allordersview',false,1,true);" aria-controls='profile' role='tab' data-toggle='tab'>
					<i class='fa fa-check' aria-hidden='true'></i>
					Request to Pickup (<span id='requested_pickup_count'>0</span>)
				</a>
			</li>
			<li role='presentation'>
				<a onclick="allOrders('rejected','allordersview',false,1,true);" aria-controls='profile' role='tab' data-toggle='tab'>
					<i class='fa fa-print' aria-hidden='true'></i>
					Rejected Orders (<span id='rejectedcount'>0</span>)
				</a>
			</li>
			<!--li role='presentation'>
				<a  aria-controls='profile' role='tab' data-toggle='tab'>
					<i class='fa fa-print' aria-hidden='true'></i>
					Return Orders (<span id=''>0</span>)
				</a>
			</li-->			
			<li role='presentation'>
				<a onclick="allOrders('completed','allordersview',false,1,true);" aria-controls='home' role='tab' data-toggle='tab'>
					<i class='fa fa-shopping-cart' aria-hidden='true'></i>
					Completed Orders (<span id='completed_count'>0</span>)
				</a>
			</li>
		</ul>
		<br>
	</div>
	<div class='container-fluid'>
		<!--div class='col-md-9 col-sm-9 col-xs-9'-->
			<select class="form-control" style="max-width:150px; height:30px; display:inline-block;" name="searchtext" id="searchtext">
				<option value="orderidser">Order ID</option>
				<option value="orderdidser">Order DID</option>
                                <option value="mrn">MRN</option>
			</select>
			<input class="form-control" style="max-width:150px; height:30px; display:inline-block;" name="searchvalue" id="searchvalue">
			<button id="l2search" class="btn btn-primary" onclick="allOrders('all_orders','allordersview',false,1,true);">Search</button>
		<!--/div-->
		<!--div class='col-md-3 col-sm-3'>
			<a href='#' onclick='exportcsv()' class='export_csv_btn pull-right'>Export CSV</a>
		</div-->
	</div>
</section>
<section id="Custom_search"></section>
<section id="Custom_body"></section>

		   
