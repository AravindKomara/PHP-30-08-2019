<script type="text/javascript">
 
function process_server_events(type,url,data){
	$.ajax({
		type: type, 
		url: url, 
		data:data,
            success: function(result){
            }
			 
       });
}	   

        $(document).ready(function () {
            $('.datepicker').datepicker({
                format: "dd/mm/yyyy",
                autoclose: true,
            });
            //$('.datepicker').Close();
		
		
			
			
        });
    </script>
    <script src="js/bootstrap-datepicker.js"></script>
   

    <script>

        //$("#btnOrderSearch").click(function () {
        //  //  alert($(".custom_search").hasClass("custom_searchpre"));
        //      $(".custom_search").addClass("custom_searchpre");
        //    alert($(".custom_search").hasClass("custom_searchpre"));
        //});

        $("#btnOrderSearch").click(function () {

            if ($(".custom_search").hasClass("custom_searchpre"))
                $(".custom_search").removeClass("custom_searchpre");
            else
                $(".custom_search").addClass("custom_searchpre");
        });


       
    </script>

  </body>
</html>