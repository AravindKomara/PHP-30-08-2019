function allordersview(response) {
    if(typeof response == 'string'){
    ordersdetails = JSON.parse(response);
    }else{
        ordersdetails = response;
    }
    console.log(response);
    htmlBanner = '<section class="container-fluid">' +
	'<article class="main_content">' +
	'<div class="tab-content custom_tab_content">' +
	'<div role="tabpanel" class="tab-pane fade in active" id="mainreplacecontent">' +
	'<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
	'<div class="table-responsive">' +
	'<table id="example"  cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">' +
	'<thead>' +
	'<tr>' +
	'<th>MRN</th>' +
	'<th>Customer Name</th>'+
	'<th>Source Type</th>'+
	'<th>Transaction ID</th>'+
	'<th>Order No.</th>' +
	'<th>Order DID.</th>' +
	'<th>Location</th>' +
	'<th>Order Created Date </th>' +
	'<th>Preferred Date/Time </th>' +
	'<th>Scheduled Date/Time </th>' +
	'<th>Vendor Name</th>' +
	'<th>Order Status</th>' +
	'<th>Order Details</th>' +
	'<th>Order Track</th>' +
	'</tr>' +
	'</thead>' +
	'<tbody>';

    if(ordersdetails.data.length > 0){
        var patientdetails = "";
        var vendordetails = "";
        $.each(ordersdetails.data, function (key, val) {
            patientdetails = val.order.patientinfo;
            vendordetails = val.order.vendorinfo;
            patientdetails.name = patientdetails.name ? patientdetails.name : "NaN";
            patientdetails.mrn = patientdetails.mrn ? patientdetails.mrn : "NaN";
            patientdetails.source_type = patientdetails.source_type ? patientdetails.source_type : "NaN";
            patientdetails.city = patientdetails.city ? patientdetails.city : "NaN";
            patientdetails.expected_delivery_time = patientdetails.expected_delivery_time ? patientdetails.expected_delivery_time : "NaN";
            patientdetails.scheduled_date = patientdetails.scheduled_date ? patientdetails.scheduled_date : "NaN";
            patientdetails.scheduled_date
			vendordetails = (typeof(val.order.provider_info)!="undefined")?val.order.provider_info[0]:"undefined";			
			//vendordetails.VendorName = vendordetails.VendorName ? vendordetails.VendorName : "NaN";

            htmlBanner += '<tr>' +
			'<td>' + patientdetails.mrn + '</td>' +
			'<td>' + patientdetails.name + '</td>' +
			'<td>' + patientdetails.source_type + '</td>' +
			'<td>' + val.transtiton_code + '</td>' +
			'<td>' + val._id + '</td>' +
			'<td>' + val.odid + '</td>' +
			'<td>' + patientdetails.city + '</td>' +
			'<td>' + changedate(val.order.order_status.created_date) + '</td>' +
			'<td>' + changedate(patientdetails.expected_delivery_time) + '</td>';
            if (val.OStatus != 17 && val.OStatus != 21) {
                htmlBanner += '<td>' + changedate(patientdetails.scheduled_date) + '</td>';
            } else {
                htmlBanner += '<td>-</td>';
            }
            htmlBanner += '<td>'+((typeof(vendordetails.associate_name)!="undefined")?vendordetails.associate_name:"")+ '</td>' +
			'<td>' + getOrderStatus(val.OStatus) + '</td>' +
			'<td> <a onclick="vieworder(' + val._id + ')" target="_new" class="view">View</a> </td>' +
			'<td><a onclick="trackOrder(' + val._id + ')" class="track_btn">Deliver Track</a></td>' +
			'</tr>'; //href=order_view.php?id='+val._id.value+' 
        });
    }else{
        htmlBanner += '<tr><td colspan=13><p class="text-center">'+ordersdetails.message+'</p></td></tr>';
    }

    htmlBanner += '</tbody>' +
	'</table>' +
	'</div>' +
	'</div>' +
	'</div>' +
	'</div>' +
	'</div>' +
	'</div>' +
	'</article>' +
	'</section>' +
	'</div>';
    //$("#Custom_body").html(htmlBanner);
    setTimeout(function(){
    $("#allorder_count").html(ordersdetails.all_orders);
    $("#vendor_assigned_count").html(ordersdetails.countn);
    $("#requested_pickup_count").html(ordersdetails.requested_pickup);
    $("#rejectedcount").html(ordersdetails.rejected);
    $("#completed_count").html(ordersdetails.completed);
    },1000);
    return htmlBanner;
    $(".loader").hide();
}

function trackOrderView(result){
	var modalfooter='<button type="button" class="btn btn-default sa-success" data-dismiss="modal" style="color:#fff;">Close</button>';
	var myModalLabel="Order Tracking Status";
	var trackresult="";
	if(result.status==1){
		var tdata = ''; 
		if(result.data.order_log.length <= 0){
			tdata = '<h4>No Data</h4>';
			$('#trackresult').html(tdata);
			$('#track').modal('show');
		}else{
			tdata="<table class='table table-responsive'><thead><tr>"+
			"<th>Order</th>"+
			"<th>User Name</th>"+
			"<th>User ID</th>"+
			"<th>Role</th>"+
			"<th>Action</th>"+
			"<th>Servicing Facility Name</th>"+
			"<th>Order Status</th>"+
			"<th>Updated On</th>"+
			"<th>Text</th>"+
			"</tr></thead><tbody>";
			$.each(result.data.order_log, function (key, val) {
				tdata +='<tr><td>'+val.wodid+'</td>'+
				'<td>'+val.actionByName+'</td>'+
				'<td>'+val.actionById+'</td>'+
				'<td>'+val.role+'</td>'+
				'<td>'+val.action+'</td>'+
				'<td>'+val.popname+'</td>'+
				'<td>'+orderstatus(val.order_status)+'</td>'+
				'<td>'+val.created_date+'</td>'+
				'<td>'+val.reason+'</td></tr>';
			});
			tdata += '</tbody></table>';
			trackresult = tdata;
		}		
	}else{
		trackresult = result.message;
	}
	//console.log(trackresult);
	$(".loader").hide();
	$("#myModalLabel").html(myModalLabel);
	$("#trackresult").html(trackresult);
	$("#modalfooter").html(modalfooter);
	$("#Modal_for_all").modal('show');
}


function showorderview(resposne){
	var cancel_btn_on_statuses = [1, 2, 3, 4, 5];
	var show_statuses_the_start_btn = [0, 1, 2];
	var MRP = 0;
    var baseprice = 0;
    var sellingprice = 0;
    var discountamount = 0;
    var Tcommission_amount = 0;
    /*if (typeof resposne == 'string') {
        ordersdetails = JSON.parse(resposne);
    } else {
        ordersdetails = resposne;
    }*/
	//console.log(resposne.data);return;
	if(resposne.status==1){		
		if(typeof resposne.data._id != "undefined"){
			ordersdetails = resposne.data;
			htmlBanner = '<br><section class="container-fluid">'+
            '<article class="p_details">'+
            '<div class="col-md-12 col-sm-12 col-xs-12 mp">'+            
			'<section class="complete_order_search">'+
			'<div class="col-xs-12 mp" style="border-bottom:1px solid #7DB0AC; margin-top:-10px; padding:5px;">'+
			'<h5 style="text-decoration:none; font-size:18px;">'+
			'Order ID # '+((typeof ordersdetails._id != "undefined")?ordersdetails._id:"")+
			' | Order DID # '+((typeof ordersdetails.odid != "undefined")?ordersdetails.odid:"")+
			' | MRN - '+((typeof ordersdetails.order.patientinfo.mrn != "undefined")?ordersdetails.order.patientinfo.mrn:"")+
			' | Transaction ID - '+((typeof ordersdetails.transaction_code != "undefined")?ordersdetails.transaction_code:"")+
            '</h5>'+
			'</div>'+
            '<article class="col-md-12 col-sm-12 col-xs-12 mobile_mp"><br>'+			
            '<div class="col-md-2 col-sm-3 col-xs-12 mp">' +
            '<div class="form-group">' +
            '<input type="hidden" id="delivery_lat" name="latitude" value='+ordersdetails.order.patientinfo.delivery_lat+'>'+
            '<input type="hidden" id="delivery_lng" name="longtitude" value='+ordersdetails.order.patientinfo.delivery_lng+'>'+
            '<label style="margin-bottom:10px;">Customer Name:<br><span style="color:#6D6D6D;">'+ordersdetails.order.patientinfo.name+'</span></label>'+
            '<label style="margin-bottom:10px;">Mobile No:<br><span style="color:#6D6D6D;">'+ordersdetails.order.patientinfo.contact+'</span></label>'+
            '<label style="margin-bottom:10px;">Alternate Mobile No:<br><span style="color:#6D6D6D;">'+(ordersdetails.order.patientinfo.alternetcontactno ? ordersdetails.order.patientinfo.alternetcontactno :"")+'</span></label>' +  
            '</div>'+
            '</div>'+
            '<div class="col-md-4 col-sm-3 col-xs-12 mp">'+
			'<label style="margin-bottom:10px;">Delivery Address:<br><span style="color:#6D6D6D;">'+ordersdetails.order.patientinfo.address+'</span></label>'+
            '<label style="margin-bottom:10px;">Pincode:<br><span style="color:#6D6D6D;">'+ordersdetails.order.patientinfo.pincode+'</span></label>'+
            '</div>'+
			'<div class="col-md-3 col-sm-3 col-xs-12 mp">'+
			'<label style="margin-bottom:10px;">Preferred Date/Time:<br><span style="color:#6D6D6D;">'+changedate(ordersdetails.order.patientinfo.expected_delivery_time ? ordersdetails.order.patientinfo.expected_delivery_time : "NaN")+'</span></label>';
            if(ordersdetails.OStatus == 21){
				htmlBanner +='<label style="margin-bottom:10px;">Scheduled Date/Time:</lable><br>'+
				'<div class="col-md-6 mp">'+
				'<input type="text" id="vendordate" onchange="settimeslot();" class="form-control datepicker" placeholder="YYYY-MM-DD" style="margin-bottom:5px; font-size:14px; font-weight:100; width:135px;">' +
                                '<span class="datepicker"></span>'+
				'<select id="vendortime" name="job_name" class="form-control new-status" style="margin-bottom:5px; font-size:14px; font-weight:100; width:135px;">' +
                                '<option id="10amslot" value="14:00:00">10AM-02PM</option>'+
                                '<option id="2pmslot" value="18:00:00">02PM-06PM</option>'+
                                '<option id="6pmslot" value="22:00:00">06PM-10PM</option>'+
                                '</select>'+
				'</div>';
			}else{
				htmlBanner +='<label style="margin-bottom:10px;">Scheduled Date/Time:<br><span style="color:#6D6D6D;">'+changedate(ordersdetails.order.patientinfo.scheduled_date)+'</span></label>';
			}			
            htmlBanner +='</div>';
			
			if (jQuery.inArray(ordersdetails.OStatus, show_statuses_the_start_btn) >= 0) {
				htmlBanner +='<div class="col-md-3 col-sm-12 col-xs-12 order_status_change text-left">' +
				'<a href="#" class="print_invoice_btn" name = "started" onclick="orderstatusChange(\'' + ordersdetails._id + '\',\'' + ordersdetails.order.patientinfo.scheduled_date + '\',3)">Start</a>' +
				'</div>';
			}else if(ordersdetails.OStatus==3){
				htmlBanner +='<div class="col-md-3 col-sm-12 col-xs-12 order_status_change text-left">' +
				'<a href="#" class="print_invoice_btn" name = "inprogress" onclick="orderstatusChange(\'' + ordersdetails._id + '\',\'' + ordersdetails.order.patientinfo.scheduled_date + '\',5)">InProgress</a>' +
				'</div>';
			}else if(ordersdetails.OStatus==5){
				htmlBanner += '<div class="col-md-3 col-sm-12 col-xs-12 order_status_change text-left">' +
				'<a href="#" class="print_invoice_btn" name = "completed" onclick="orderstatusChange(\'' + ordersdetails._id + '\',\'' + ordersdetails.order.patientinfo.scheduled_date + '\',6)">Complete</a>' +
				'<div style="position: absolute; left: 2px; bottom: -44px;"><input type="checkbox" name="" value="1" id = "amt_chkbox" >Amount Collected</div>' +
				'</div>';
			}else if(ordersdetails.OStatus == 21){
				htmlBanner += '<div class="col-md-3 col-sm-12 col-xs-12 cancel_order text-left">' +
				'<label>Logistics Vendor :</label>'+
                                '<select name="vendor" id="logisticsvendor" class="form-control new-status">'+
                                '<option value="callhealth">Callhealthpickup</option>'+
                                '<option value="vendorpickup">VendorPickup</option>'+
                                '</select>'+
				'</div>';
			}			
			if(jQuery.inArray(ordersdetails.OStatus, cancel_btn_on_statuses) >= 0){
				htmlBanner += '<div class="col-md-2 col-sm-12 col-xs-12 cancel_order text-right" style="margin-top:-35px;">' +
				'<a href="#" class="print_invoice_btn" name = "cancel" onclick="cancelorder_Popup(\'' + ordersdetails._id + '\',\'' + ordersdetails.order.patientinfo.scheduled_date + '\',15)">Cancel</a>' +
				'</div>';
			}
			///////// end the box code  ///////////
			
			htmlBanner +='</article>'+
            '</section>'+
            '<br>'+
            '<div class="col-md-12 col-sm-12 col-xs-12 mp">'+
            '<div class="table-responsive">'+
            '<table class="table table-condensed table-bordered table-striped medicine_home_order_table" id="toggleColumn-datatable">'+
            '<thead>'+
            '<tr>'+
            '<th>Select All <input type="checkbox" name="allitem_select" value="1" onclick="allselect()"></th>'+
            '<th>Product Name</th>'+
            '<th>Brand Name</th>'+ 
            '<th>Type</th>'+
            '<th>Order Qty</th>'+
            '<th>Item MRP</th>'+
            '<th>MRP</th>'+
            '<th>Base Price</th>'+
            '<th>Selling Price</th>'+
            '<th>Discount</th>'+
            '<th>Commission</th>'+
            '<th>Actions</th>'+
            '<th>Comments</th>'+
            '<th>Log Info</th>'+
            '<th>Add Log</th>'+
            '</tr>'+
            '</thead>';
            '<tbody>'
	            $.each(ordersdetails.order.orderitem, function (key, val) {				
				commission_amount = parseFloat(val.net_amount) - parseFloat(val.total_baseprice);
				Tcommission_amount = Tcommission_amount + commission_amount;
				MRP = parseFloat(MRP) + parseFloat(val.gross_amount);
				baseprice = parseFloat(baseprice) + parseFloat(val.total_baseprice);
				sellingprice = parseFloat(sellingprice) + parseFloat(val.net_amount);
				discountamount = parseFloat(discountamount) + parseFloat(val.discount_amount);
				

				if (val.item_status == "8") {
					htmlBanner += '<tr style="background:#FFB4B7;">';
				} else {
					htmlBanner += '<tr style="">';
				}
				htmlBanner +='<td>'+
				'<input type="checkbox" name="item_reject"  value="' + val.item_code + '"></td>'+
				'<td>'+val.itemname+'</td>' +
				'<td>'+(val.manufacture ? val.manufacture : "")+'</td>';
				if (val.type == 1) {
					htmlBanner += '<td>Rent</td>';
				}else if (val.type == 2) {
					htmlBanner += '<td>Sale</td>';
				}else{
					htmlBanner += '<td>-</td>';
				}
				htmlBanner +='<td class="oneliner">' + val.quantity + ' </td>' +
				'<td>' + val.MRP + '</td>' +
				'<td>' + val.gross_amount + '</td>' +
				'<td>' + val.total_baseprice + '</td>' +
				'<td>' + val.net_amount + '</td>' +
				'<td>' + val.discount_amount + '</td>' +
				'<td>' + commission_amount + '</td>';
				//edit and view details tab td
				if (ordersdetails.OStatus == 21) {
					if (typeof (val.batch) == "undefined") {
						htmlBanner += '<td> <button type="button" onclick=updateprice_popup(' + ordersdetails._id + ',"' + val.item_code + '",' + val.quantity + ',' + val.MRP + ',' + val.item_base_p + ',' + val.item_selling_p + ',"' + escape(val.itemname) + '","","' + val.s_days + '","' + val.s_month + '","' + val.s_year + '","' + val.type + '","' + val.gross_amount + '","' + val.total_baseprice + '","' + val.net_amount + '") class="btn btn-primary" >Edit</button></td>';
					}else{
						htmlBanner += '<td><button type="button" onclick=viewbatchdetails(' + ordersdetails._id + ',"' + val.item_code + '",' + val.discount_amount + ') class="btn btn-primary" >view Details</button></td>';
					}
				}else if (val.item_status != 9) {
					if (typeof (val.batch) == "undefined") {
						htmlBanner += ' <td>N/A</td>';
					}else{
						htmlBanner += ' <td><div class="dropdown"><button class="dropbtn">Batch details</button><div class="dropdown-content"><table  class="table table-bordered table-condensed table-striped table-responsive"><thead><tr><th>Quantity</th><th>Amount</th><th>batch Name</th></tr></thead>  <tbody>';
						$.each(val.batch, function (bkey, bval) {
							htmlBanner += '<tr><td>' + bval.quantity + '</td><td>' + bval.mrp + '</td><td>' + bval.batch + '</td></tr>';
						});
						htmlBanner += '  </tbody></table></div></div></td>';
					}
				} else {
					htmlBanner +='<td>N/A</td>' +
					'<td>N/A</td>';
				}

				//comments td
				if (val.item_status == 9) {
					htmlBanner += '<td><a href="#" data-toggle="tooltip" title="' + val.item_reject_reason + '">'+val.item_reject_reason +'</a></td>';
				} else {
					htmlBanner += '<td>N/A</td>';
				}

				//showing log information if log is added
				if (val.item_status != 9) {
					var logtable =
							'<td>' +
							'<div class="dropdown">' +
							'<button class="dropbtn"> <i class="fa fa-info cust_check" aria-hidden="true"></i></button>' +
							'<div class="dropdown-content" style="right:10%;">' +
							'<table class="table table-bordered table-condensed table-striped table-responsive">' +
							'<thead>' +
							'<tr>' +
							'<th>Role</th><th>Name</th><th>Log Details</th><th>Date/Time</th></tr></thead><tbody>';
					var logdata = "";
					if (typeof ordersdetails.user_log != "undefined") {
						$.each(ordersdetails.user_log, function (bkey, bval) {
							if (bval.item_code == val.item_code) {
								logdata += '<tr><td>' + bval.role + '</td><td>' + bval.actionbyname + '</td><td>' + bval.log_reason + '</td><td>' + bval.action_date + '</td></tr>';
							}
						});
					}
					if (logdata == "") {
						htmlBanner += '<td colspan="">NA</td>';
					} else {
						htmlBanner += (logtable + logdata + '</tbody></table></div></div></td>');
					}
				   //add log td
					htmlBanner += '<td> <a href="#" class="mpt" onclick="addLog_popup(\'' + ordersdetails._id + '\',\'' + val.item_code + '\')">Add Log</a></td>';
				} else {
					htmlBanner += 
							'<td>N/A</td>' ;
							
				}
				
				'</tr>';

			});
			htmlBanner +=
            '</tbody>' +
            '</table>' +
            '</div>';
			//end of table
   
			//confirm and reject buttons
			if (ordersdetails.OStatus == 21) {
				htmlBanner +=
				'<div class="col-md-1 col-sm-12 col-xs-12 text-right view_prec">' +
				'<a href="#" class="comp_apply_btn  mpt" onclick="assignlogisticsvendor(' + ordersdetails._id + ',\'' + ordersdetails.order.patientinfo.scheduled_date + '\')">Confirm</a>' +
				'</div>';
                                htmlBanner += 
                                '<div class="col-md-1 col-sm-12 col-xs-12 text-right view_prec">' +
				'<a href="#" class="reject_btn  mpt" onclick="rejectorder_popup(' + ordersdetails._id + ')">Reject</a>' +
				'</div>';
			}
			
			//displaying total amount
			statuses = [0, 6, 18];
			if (jQuery.inArray(ordersdetails.OStatus, statuses) >= 0) {
				htmlBanner +=
				'<div class="col-md-2 col-sm-12 col-xs-12 text-right view_prec">' +
				'<label>MRP &nbsp; : &nbsp; &#8377; ' + MRP.toFixed(2) + '</label>' +
				'<label>Base Price &nbsp; : &nbsp; &#8377;&nbsp; ' + baseprice.toFixed(2) + '</label>' +
				'<label>Selling Price &nbsp; : &nbsp; &#8377;&nbsp; ' + sellingprice.toFixed(2) + '</label>' +
				'<label>Discount &nbsp; : &nbsp; &#8377;&nbsp; ' + discountamount.toFixed(2) + '</label>' +
				'<label>Commission &nbsp; : &nbsp; &#8377;&nbsp; ' + Tcommission_amount.toFixed(2) + '</label>' +
				'</div>';
			}

			//print cash memo and shipment label buttons
			htmlBanner += '<div class="col-md-4 col-sm-6 col-xs-12 text-right">';
			if (ordersdetails.OStatus != 24 && ordersdetails.OStatus != 21) {
				htmlBanner += '<a href="#" class="print_invoice_btn" onclick="invoicedownload(' + ordersdetails._id + ')">PRINT Cash MEMO</a>  &nbsp;' +
				'<a href="#" class="print_invoice_btn" onclick="shipmentlabeldownload(' + ordersdetails._id + ')">SHIPMENT LABEL</a>';
			}
			htmlBanner +='</div>' +  
			'</div></article></section>';
			
		}else{
			alert("Data not found.");
			$(".loader").hide();
		}
	}else{
		if(resposne.data.length <= 0) {
			alert(resposne.message);
			$(".loader").hide();
			console.log(resposne);
		}	
	}
	
	
	$("#Custom_body").html(htmlBanner);
	$(".loader").hide();
        var d = new Date(ordersdetails.order.patientinfo.expected_delivery_time);
        var date = d.getYear + "-" + d.getMonth + "-" + d.getDate();
        $('#vendordate').datepicker('setDate', date);
        $("#vendordate").datepicker('setStartDate', '0d');
	
    //console.log(ordersdetails);
    
    /*        
    var statuses = [0, 1, 2];
    if (jQuery.inArray(ordersdetails.OStatus, statuses) >= 0) {
        htmlBanner +=
                '<div class="col-md-3 col-sm-12 col-xs-12 order_status_change text-right">' +
                '<a href="#" class="print_invoice_btn" name = "started" onclick="orderstatusChange(\'' + ordersdetails._id + '\',3)">Start</a>' +
                '</div>';
    } else if (ordersdetails.OStatus == 3) {
        htmlBanner +=
                '<div class="col-md-3 col-sm-12 col-xs-12 order_status_change text-right">' +
                '<a href="#" class="print_invoice_btn" name = "inprogress" onclick="orderstatusChange(\'' + ordersdetails._id + '\',5)">InProgress</a>' +
                '</div>';

    } else if (ordersdetails.OStatus == 5) {
        htmlBanner += '<div class="col-md-3 col-sm-12 col-xs-12 order_status_change text-right">' +
                '<a href="#" class="print_invoice_btn" name = "completed" onclick="orderstatusChange(\'' + ordersdetails._id + '\',6)">Complete</a>' +
                '<div style="position: absolute; left: 2px; bottom: -44px;"><input type="checkbox" name="" value="1" id = "amt_chkbox" >Amount Collected</div>' +
                '</div>';
    } else if (ordersdetails.OStatus == 6) {
        htmlBanner += '';
    }
    statuses = [1, 2, 3, 4, 5];
    if (jQuery.inArray(ordersdetails.OStatus, statuses) >= 0) {
        htmlBanner += '<div class="col-md-3 col-sm-12 col-xs-12 cancel_order text-left">' +
                '<a href="#" class="print_invoice_btn" name = "started" onclick="cancelorder_Popup(\'' + ordersdetails._id + '\',15)">Cancel</a>' +
                '</div>';
    }
    
	
	
	
	
    htmlBanner +=
            '</article>' +
            '</section>' +
            '<br>' +
            '<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
            '<div class="table-responsive">' +
            '<table class="table table-condensed table-bordered table-striped medicine_home_order_table" id="toggleColumn-datatable">' +
            '<thead>' +
            '<tr>' +
            '<th>Select All <input type="checkbox" name="allitem_reject" value="1" onclick="allreject()"></th>' +
            '<th>Product Name</th>' +
            '<th>Brand Name</th>' +
            '<th>Type</th>' +
            '<th>Order Qty</th>' +
            '<th>MRP</th>' +
            '<th>TMRP</th>' +
            '<th>TBase Price</th>' +
            '<th>TSelling Price</th>' +
            '<th>TDiscount</th>' +
            '<th>TCommission</th>' +
            '<th>Actions</th>' +
            '<th>Comments</th>' +
            '<th>Log Info</th>' +
            '<th>Add Log</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';
    var total_MRP = 0;
    var total_baseprice = 0;
    var total_sellingprice = 0;
    var total_discountamount = 0;
    var total_commission_amount = 0;
    var commission_amount = 0;
    $.each(ordersdetails.order.orderitem, function (key, val) {
        commission_amount = parseFloat(val.net_amount) - parseFloat(val.total_baseprice);
        total_MRP = parseFloat(total_MRP) + parseFloat(val.gross_amount);
        total_baseprice = parseFloat(total_baseprice) + parseFloat(val.total_baseprice);
        total_sellingprice = parseFloat(total_sellingprice) + parseFloat(val.net_amount);
        total_discountamount = parseFloat(total_discountamount) + parseFloat(val.discount_amount);
        total_commission_amount = parseFloat(total_sellingprice) - parseFloat(total_baseprice);

        if (val.item_status == "8") {
            htmlBanner += '<tr style="background:#FFB4B7;">';
        } else {
            htmlBanner += '<tr style="">';
        }
        htmlBanner +=
                '<td><input type="checkbox" name="item_reject"  value="' + val.item_code + '"></td>'+
                '<td>' + val.itemname + '</td>' +
                '<td>' + (val.manufacture ? val.manufacture : "") + '</td>';
        if (val.type == 1) {
            htmlBanner += '<td>Rent</td>';
        }
        else if (val.type == 2) {
            htmlBanner += '<td>Sale</td>';
        } else {
            htmlBanner += '<td>-</td>';
        }
        htmlBanner +=
                '<td class="oneliner">' + val.quantity + ' </td>' +
                '<td>' + val.MRP + '</td>' +
                '<td>' + val.gross_amount + '</td>' +
                '<td>' + val.total_baseprice + '</td>' +
                '<td>' + val.net_amount + '</td>' +
                '<td>' + val.discount_amount + '</td>' +
                '<td>' + commission_amount + '</td>';
        //edit and view details tab td
        if (ordersdetails.OStatus == 21) {
            if (typeof (val.batch) == "undefined") {
                htmlBanner += '<td> <button type="button" onclick=updateprice(' + ordersdetails._id + ',"' + val.item_code + '",' + val.quantity + ',' + val.MRP + ',' + val.item_base_p + ',' + val.item_selling_p + ',"' + escape(val.itemname) + '","","' + val.s_days + '","' + val.s_month + '","' + val.s_year + '","' + val.type + '","' + val.gross_amount + '","' + val.total_baseprice + '","' + val.net_amount + '") class="btn btn-primary" >Edit</button></td>';
            } else {
                htmlBanner += '<td><button type="button" onclick=viewbatchdetails(' + ordersdetails._id + ',"' + val.item_code + '",' + val.discount_amount + ') class="btn btn-primary" >view Details</button></td>';
            }
        } else if (val.item_status != 9) {
            if (typeof (val.batch) == "undefined") {
                htmlBanner += ' <td>N/A</td>';
            } else {
                htmlBanner += ' <td><div class="dropdown"><button class="dropbtn">Batch details</button><div class="dropdown-content"><table  class="table table-bordered table-condensed table-striped table-responsive"><thead><tr><th>Quantity</th><th>Amount</th><th>batch Name</th></tr></thead>  <tbody>';
                $.each(val.batch, function (bkey, bval) {
                    htmlBanner += '<tr><td>' + bval.quantity + '</td><td>' + bval.mrp + '</td><td>' + bval.batch + '</td></tr>';
                });
                htmlBanner += '  </tbody></table></div></div></td>';
            }
        } else {
            htmlBanner +=
                    '<td>N/A</td>' +
                    '<td>N/A</td>';
        }

        //comments td
        if (val.item_status == 9) {
            htmlBanner += '<td><a href="#" data-toggle="tooltip" title="' + val.item_reject_reason + '">Reason</a></td>';
        } else {
            htmlBanner += '<td>N/A</td>';
        }

        //showing log information if log is added
        if (val.item_status != 9) {
            var logtable =
                    '<td>' +
                    '<div class="dropdown">' +
                    '<button class="dropbtn"> <i class="fa fa-info cust_check" aria-hidden="true"></i></button>' +
                    '<div class="dropdown-content" style="right:10%;">' +
                    '<table class="table table-bordered table-condensed table-striped table-responsive">' +
                    '<thead>' +
                    '<tr>' +
                    '<th>Role</th><th>Name</th><th>Log Details</th><th>Date/Time</th></tr></thead><tbody>';
            var logdata = "";
            if (typeof ordersdetails.user_log != "undefined") {
                $.each(ordersdetails.user_log, function (bkey, bval) {
                    if (bval.item_code == val.item_code) {
                        logdata += '<tr><td>' + bval.role + '</td><td>' + bval.actionbyname + '</td><td>' + bval.log_reason + '</td><td>' + bval.action_date + '</td></tr>';
                    }
                });
            }
            if (logdata == "") {
                htmlBanner += '<td colspan="">NA</td>';
            } else {
                htmlBanner += (logtable + logdata + '</tbody></table></div></div></td>');
            }
           //add log td
            htmlBanner += '<td> <a href="#" class="mpt" onclick="user_log(\'' + ordersdetails._id + '\',\'' + val.item_code + '\')">Add Log</a></td>';
        } else {
            htmlBanner += 
                    '<td>N/A</td>' +
                    '<td>N/A</td>';
        }
        
        '</tr>';

    });
    htmlBanner +=
            '</tbody>' +
            '</table>' +
            '</div>';
   
   //end of table
   
   //confirm and reject buttons
    if (ordersdetails.OStatus == 21) {
        htmlBanner +=
                '<div class="col-md-1 col-sm-12 col-xs-12 text-right view_prec">' +
                '<a href="#" class="comp_apply_btn  mpt" onclick="assignlogisticsvendor(' + ordersdetails._id + ')">Confirm</a>' +
                '</div>';
    }
    if (ordersdetails.OStatus == 21) {
        htmlBanner += '<div class="col-md-1 col-sm-12 col-xs-12 text-right view_prec">' +
                '<a href="#" class="reject_btn  mpt" onclick="rejectorder(' + ordersdetails._id + ')">Reject</a>' +
                '</div>';
    }
    
    //displaying total amount
    statuses = [0, 6, 18];
    if (jQuery.inArray(ordersdetails.OStatus, statuses) >= 0) {
        htmlBanner +=
                '<div class="col-md-2 col-sm-12 col-xs-12 text-right view_prec">' +
                '<label>MRP &nbsp; : &nbsp; &#8377; ' + total_MRP.toFixed(2) + '</label>' +
                '<label>Base Price &nbsp; : &nbsp; &#8377;&nbsp; ' + total_baseprice.toFixed(2) + '</label>' +
                '<label>Selling Price &nbsp; : &nbsp; &#8377;&nbsp; ' + total_sellingprice.toFixed(2) + '</label>' +
                '<label>Discount &nbsp; : &nbsp; &#8377;&nbsp; ' + total_discountamount.toFixed(2) + '</label>' +
                '<label>Commission &nbsp; : &nbsp; &#8377;&nbsp; ' + total_commission_amount.toFixed(2) + '</label>' +
                '</div>';
    }
    
    //print cash memo and shipment label buttons
    htmlBanner += '<div class="col-md-4 col-sm-6 col-xs-12 text-right">';
    if (ordersdetails.OStatus != 24 && ordersdetails.OStatus != 21) {
        htmlBanner += '<a href="#" class="print_invoice_btn" onclick="memodownload(' + ordersdetails._id + ')">PRINT Cash MEMO</a>  &nbsp;' +
                '<a href="#" class="print_invoice_btn" onclick="cashmemodownload(' + ordersdetails._id + ')">SHIPMENT LABEL</a>';
    }
   htmlBanner += 
           '</div>' +  
           '</div>'+
  
        //batch details modal
            '<!-- Showing batch update Price  -->' +
            '<div class="modal fade" id="batchmodel" role="dialog">' +
            '<div class="modal-dialog">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">View Batch Details </h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<h5>Quantity: <span id=qty1></span></h5>' +
            '<h6>Product Name:<span id=iname1></span></h6>' +
            '<input type="hidden" id="bquantity" name="bquantity">' +
            '<input type="hidden" id="vendor_batch_omorder_id" name="vendor_batch_omorder_id">' +
            '<input type="hidden" id="batch_item_code" name="batch_item_code">' +
            '<input type="hidden" id="batch_disamount" name="batch_disamount">' +
            '<input type="hidden" id="batch_rowcount" name="batch_rowcount">' +
            '<table class="table table-striped" id="vendorupdatebatchprice">' +
            ' <thead id="tblHead">' +
            ' <tr>' +
            ' <th>Quantity</th>' +
            '<th>MRP</th>' +
            '<th>Selling Price</th>' +
            '<th>Base Price</th>' +
            '<th>GST</th>' +
            ' </tr>' +
            '</thead>' +
            '<tbody>';
           ' </tbody>' +
            '</table>' +
            '<button type="button" class="btn btn-primary" onclick="vendorbatchupdateprice()">Update</button>' +
            '</div>' +
            '<div class="modal-footer">' +
            ' <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            //end of batch details modal
    
            //item wise reject modal        
            '<!-- Showing Item Wise Reject  -->' +
            '<div class="modal fade" id="itemReject" role="dialog">' +
            '<div class="modal-dialog">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">Are  you  sure  You Want to Reject  This Order. </h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<div>' +
            '<select id="rejectreasons" style="width:550px;" required="">' +
            '<option value="Some medicines ordered by you are currently unavailable">Some medicines ordered by you are currently unavailable </option>' +
            '<option value="Medicines ordered by you are currently unavailable">Medicines ordered by you are currently unavailable </option>' +
            '<option value="Prescription shared by you is invalid"> Prescription shared by you is invalid</option>' +
            '</select>' +
            '<input type="hidden" id="item_reject_omorder_id" name="item_reject_omorder_id">' +
            '<input type="hidden" id="item_reject_code" name="item_reject_code">' +
            '</div>' +
            '</div>' +
            '<div class="modal-footer">' +
            ' <button type="button" class="btn btn-default" data-dismiss="modal" onclick="itemrejectsubmit()">Submit</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            //end of itemwise reject modal
    
           //order wise log modal
            '<!-- Showing Order Wise Log  -->' +
            '<div class="modal fade" id="orderLog" role="dialog">' +
            '<div class="modal-dialog">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">Log the Activity..! </h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<div>' +
            '<label>Log Info &nbsp;&nbsp;&nbsp;</label>' +
            '<input type="text" id="orderlogreasons" name="orderlogreasons" style="border:1px solid !important;width:500px;" required="required">' +
            '<input type="hidden" id="log_omorder_id" name="log_omorder_id">' +
            '<input type="hidden" id="log_item_id" name="log_item_id">' +
            '</div>' +
            '</div>' +
            '<div class="modal-footer">' +
            ' <button type="button" class="btn btn-default" onclick="orderlogsubmit()">Submit</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
          //end of order wise log modal
  
          //order wise user log modal
            '<!-- Showing Order Wise user Log  -->' +
            '<div class="modal fade" id="userLog" role="dialog">' +
            '<div class="modal-dialog">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">Log Details </h4>' +
            '</div>' +
            '<div class="modal-body" id="userLogbody">' +
            '</div>' +
            '<div class="modal-footer">' +
            '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            //end of order wise user log modal
            
            //order wise reject modal
            '<!-- Showing Order Wise Reject  -->' +
            '<div class="modal fade" id="orderReject" role="dialog">' +
            '<div class="modal-dialog">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">Are  you  sure  You Want to Reject  This Order. </h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<div>' +
            '<select id="orderrejectreasons" style="width:550px;" required="">' +
            '<option value="Some products ordered by you are currently unavailable">Some products ordered by you are currently unavailable </option>' +
            '<option value="Products ordered by you are currently unavailable">products ordered by you are currently unavailable </option>' +
            '</select>' +
            '<input type="hidden" id="reject_omorder_id" name="reject_omorder_id">' +
            '<input type="hidden" id="reject_item_id" name="reject_item_id">' +
            '</div>' +
            '</div>' +
            '<div class="modal-footer">' +
            ' <button type="button" class="btn btn-default" data-dismiss="modal" onclick="orderrejectsubmit()">Submit</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            //end of order wise reject modal
    
          //prescrption modal
            '<!-- Showing prescption images  -->' +
            '<div class="modal fade" id="myModal" role="dialog">' +
            '<div class="modal-dialog">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">Prescription </h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<table class="table table-striped" id="tblGrid">' +
            ' <thead id="tblHead">' +
            ' <tr>' +
            '<th>Action</th>' +
            ' </tr>' +
            '</thead>' +
            '<tbody>';
    if (typeof ordersdetails.order.prescription_file != 'undefined' && (ordersdetails.order.prescription_file).length != 0) {
        $.each(ordersdetails.order.prescription_file, function (key, val) {
            $.each(val, function (key, val1) {
                htmlBanner += '<tr>' +
                        '<td><a target="_blank" href="' + val1 + '">Full Image</a></td>' +
                        '</tr>';
            });
        });
    } else {

        htmlBanner += '<tr><td>NO Prescription</td></tr>';
    }
    htmlBanner += ' </tbody>' +
            '</table>' +
            '</div>' +
            '<div class="modal-footer">' +
            ' <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            
       //end of prescrption modal
            
        //prescription images upload modal
            '<!-- Showing prescption images uplaoding for l2   -->' +
            '<div class="modal fade" id="Uploadprescption" role="dialog">' +
            '<div class="modal-dialog">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">Upload Prescription </h4> ' +
            '</div>' +
            '<div class="modal-body">' +
            '<form  id="formsum"  method="post" enctype="multipart/form-data">' +
            '<input type="file" name="pic[]" id ="l2prescptionname" multiple>' +
            '<input type="hidden" name="orderid" value=' + ordersdetails._id + ' id="orderid">' +
            ' <button type="button" class="btn btn-success" data-dismiss="modal" onclick="l2prescptionupload()" >Upload</button>' +
            '</div></form>' +
            '<div class="modal-footer">' +
            ' <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
        //end of prescription images upload modal    
            
            '</article>' +
            '</section>';
    
    $("#Custom_body").html(htmlBanner);
    $(".loader").hide();
    var d = new Date(ordersdetails.order.patientinfo.expected_delivery_time);
    var date = d.getYear + "-" + d.getMonth + "-" + d.getDate();
    $('#vendordate').datepicker('setDate', date);
    $("#vendordate").datepicker('setStartDate', '0d');
    */
}







































