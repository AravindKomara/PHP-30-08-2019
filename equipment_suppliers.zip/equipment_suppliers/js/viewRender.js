function allordersview(response) {
    if (typeof response == 'string') {
        ordersdetails = JSON.parse(response);
    } else {
        ordersdetails = response;
    }
    console.log(response);
    htmlBanner = '<section class="container-fluid">' +
            '<article class="main_content">' +
            '<div class="tab-content custom_tab_content">' +
            '<div role="tabpanel" class="tab-pane fade in active" id="mainreplacecontent">' +
            '<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
            '<div class="table-responsive">' +
            '<table id="example"  cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">' +
            '<thead>' +
            '<tr>' +
            '<th>MRN</th>' +
            '<th>Customer Name</th>' +
            '<th>Source Type</th>' +
            '<th>Transaction ID</th>' +
            '<th>Order No.</th>' +
            '<th>Order DID.</th>' +
            '<th>Location</th>' +
            '<th>Order Created Date </th>' +
            '<th>Preferred Date/Time </th>' +
            '<th>Scheduled Date/Time </th>' +
            '<th>Vendor Name</th>' +
            '<th>Order Status</th>' +
            '<th>Order Details</th>' +
            '<th>Order Track</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';

    if (ordersdetails.data.length > 0){
        //var vendordetails = "";
        $.each(ordersdetails.data, function (key, val) {
            //console.log(val.statusName[0]);
            var vendordetails = (typeof (val.order.provider_info) != "undefined") ?((typeof (val.order.provider_info[0]) != "undefined") ? val.order.provider_info[0] : "NA") : "NA";
            //debugger;
            var associate_name = (vendordetails.associate_name != null) ? vendordetails.associate_name : "";
            //debugger;
            htmlBanner +='<tr>' +
			'<td>' + (val.order.patientinfo.mrn ? val.order.patientinfo.mrn : "") + '</td>' +
			'<td>' + (val.order.patientinfo.name ? val.order.patientinfo.name : "") + '</td>' +
			'<td>' + ((typeof(val.channel)!="undefined")?channel[val.channel]:"") + '</td>' +
			'<td>' + ((typeof(val.transaction_code)!="undefined")?val.transaction_code:"") + '</td>' +
			'<td>' + val._id + '</td>' +
			'<td>' + val.odid + '</td>' +
			'<td>' + (val.order.patientinfo.city ? val.order.patientinfo.city : "") + '</td>' +
			'<td>' + changedate(val.order.order_status.created_date) + '</td>' +
			'<td>' + changedate(val.order.patientinfo.expected_delivery_time ? val.order.patientinfo.expected_delivery_time : "NA") + '</td>';
            if (val.OStatus != 1000 && val.OStatus != 1001 && val.OStatus != 21) {
                htmlBanner += '<td>' + changedate(val.order.patientinfo.scheduled_date) + '</td>';
            } else {
                htmlBanner += '<td>-</td>';
            }
            htmlBanner += '<td>'+associate_name+ '</td>' +
			'<td>' + ((typeof (val.statusName[0]) != "undefined") ? val.statusName[0].Nomenclature : "NA") + '</td>' +
			'<td> <a onclick="vieworder(' + val._id + ')" target="_new" class="view">View</a> </td>' +
			'<td><a onclick="trackOrder(' + val._id + ')" class="track_btn">Deliver Track</a></td>' +
			'</tr>';
        });
    } else {
        htmlBanner += '<tr><td colspan=13><p class="text-center">' + ordersdetails.message + '</p></td></tr>';
    }

    htmlBanner += '</tbody>' +
            '</table>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</article>' +
            '</section>' +
            '</div>';
    //$("#Custom_body").html(htmlBanner);
    setTimeout(function () {
        $("#allorder_count").html(ordersdetails.all_orders);
        $("#requested_pickup_count").html(ordersdetails.requested_pickup);
        $("#rejectedcount").html(ordersdetails.rejected);
        $("#vendor_assigned_count").html(ordersdetails.tobeconfirmed);
        $("#completed_count").html(ordersdetails.completed);
    }, 1000);
    return htmlBanner;
    $(".loader").hide();
}

function trackOrderView(result) {
    var modalfooter = '<button type="button" class="btn btn-default sa-success" data-dismiss="modal" style="color:#fff;">Close</button>';
    var myModalLabel = "Order Tracking Status";
    var trackresult = "";
    if (result.status == 1) {
        var tdata = '';
        if(result.data.order_log.length <= 0){
            tdata = '<h4>No Data</h4>';
            $('#trackresult').html(tdata);
            $('#track').modal('show');
        } else {
            tdata = "<table class='table table-responsive'><thead><tr>" +
                    "<th>Order</th>" +
                    "<th>User Name</th>" +
                    "<th>User ID</th>" +
                    "<th>Role</th>" +
                    "<th>Action</th>" +
                    "<th>Servicing Facility Name</th>" +
                    "<th>Order Status</th>" +
                    "<th>Updated On</th>" +
                    "<th>Text</th>" +
                    "</tr></thead><tbody>";
            $.each(result.data.order_log, function (key, val) {
                tdata += '<tr><td>' + val.wodid + '</td>' +
				'<td>' + val.actionByName + '</td>' +
				'<td>' + val.actionById + '</td>' +
				'<td>' + val.role + '</td>' +
				'<td>' + val.action + '</td>' +
				'<td>' + val.popname + '</td>' +
				'<td>'+((typeof val.status_name !="undefined")?val.status_name:"")+'</td>'+
				'<td>' + val.created_date + '</td>' +
				'<td>' + val.reason + '</td></tr>';
            });
            tdata += '</tbody></table>';
            trackresult = tdata;
        }
    } else {
        trackresult = result.message;
    }
    //console.log(trackresult);
    $(".loader").hide();
    $("#myModalLabel").html(myModalLabel);
    $("#trackresult").html(trackresult);
    $("#modalfooter").html(modalfooter);
    $("#Modal_for_all").modal('show');
}


function showorderview(resposne) {
    var cancel_btn_on_statuses = [0,1, 2, 3, 4, 5,802];
    var show_totalamount_on_statuses = [0, 6, 18];
    var show_statuses_the_start_btn = [0, 1, 2];
    var MRP = 0;
    var baseprice = 0;
    var sellingprice = 0;
    var discountamount = 0;
    var Tcommission_amount = 0;
    /*if (typeof resposne == 'string') {
     ordersdetails = JSON.parse(resposne);
     } else {
     ordersdetails = resposne;
     }*/
    //console.log(resposne.data);return;
    if (resposne.status == 1) {
        if (typeof resposne.data._id != "undefined") {
            ordersdetails = resposne.data;
            var payable_amount = (typeof ordersdetails.payment_info != "undefined") ? ordersdetails.payment_info.payable_amount : 0;
            htmlBanner = 
     /////////  box code is started  ///////////
                    
                    '<br><section class="container-fluid">' +
                    '<article class="p_details">' +
                    '<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
                    '<section class="complete_order_search">' +
                    '<div class="col-xs-12 mp" style="border-bottom:1px solid #7DB0AC; margin-top:-10px; padding:5px;">' +
                    '<h5 style="text-decoration:none; font-size:18px;">' +
                    'Order ID # ' + ((typeof ordersdetails._id != "undefined") ? ordersdetails._id : "") +
                    ' | Order DID # ' + ((typeof ordersdetails.odid != "undefined") ? ordersdetails.odid : "") +
                    ' | MRN - ' + ((typeof ordersdetails.order.patientinfo.mrn != "undefined") ? ordersdetails.order.patientinfo.mrn : "") +
                    ' | Transaction ID - ' + ((typeof ordersdetails.transaction_code != "undefined") ? ordersdetails.transaction_code : "") +
                    '</h5>' +
                    '</div>' +
                    '<article class="col-md-12 col-sm-12 col-xs-12 mobile_mp"><br>' +
                    '<div class="col-md-2 col-sm-3 col-xs-12 mp">' +
                    '<div class="form-group">' +
                    '<input type="hidden" id="delivery_lat" name="latitude" value=' + ordersdetails.order.patientinfo.delivery_lat + '>' +
                    '<input type="hidden" id="delivery_lng" name="longtitude" value=' + ordersdetails.order.patientinfo.delivery_lng + '>' +
                    '<label style="margin-bottom:10px;">Customer Name:<br><span style="color:#6D6D6D;">' + ordersdetails.order.patientinfo.name + '</span></label>' +
                    '<label style="margin-bottom:10px;">Mobile No:<br><span style="color:#6D6D6D;">' + ordersdetails.order.patientinfo.contact + '</span></label>' +
                    '<label style="margin-bottom:10px;">Alternate Mobile No:<br><span style="color:#6D6D6D;">' + (ordersdetails.order.patientinfo.alternetcontactno ? ordersdetails.order.patientinfo.alternetcontactno : "") + '</span></label>' +
                    '</div>' +
                    '</div>' +
                    '<div class="col-md-4 col-sm-3 col-xs-12 mp">' +
                    '<label style="margin-bottom:10px;">Delivery Address:<br><span style="color:#6D6D6D;">' + ordersdetails.order.patientinfo.address + '</span></label>' +
                    '<label style="margin-bottom:10px;">Pincode:<br><span style="color:#6D6D6D;">' + ordersdetails.order.patientinfo.pincode + '</span></label>' +
                    '</div>' +
                    '<div class="col-md-3 col-sm-3 col-xs-12 mp">' +
                    '<label style="margin-bottom:10px;">Preferred Date/Time:<br><span style="color:#6D6D6D;">' + changedate(ordersdetails.order.patientinfo.expected_delivery_time ? ordersdetails.order.patientinfo.expected_delivery_time : "NaN") + '</span></label>';
            if (ordersdetails.OStatus == 21) {
                htmlBanner += '<label style="margin-bottom:10px;">Scheduled Date/Time:</lable><br>' +
                        '<div class="col-md-6 mp">' +
                        '<input type="text" id="vendordate" onchange="settimeslot();" class="form-control datepicker" placeholder="YYYY-MM-DD" style="margin-bottom:5px; font-size:14px; font-weight:100; width:135px;">' +
                        '<span class="datepicker"></span>' +
                        '<select id="vendortime" name="job_name" class="form-control new-status" style="margin-bottom:5px; font-size:14px; font-weight:100; width:135px;">' +
                        '<option id="10amslot" value="14:00:00">10AM-02PM</option>' +
                        '<option id="2pmslot" value="18:00:00">02PM-06PM</option>' +
                        '<option id="6pmslot" value="22:00:00">06PM-10PM</option>' +
                        '</select>' +
                        '</div>';
            } else {
                htmlBanner += '<label style="margin-bottom:10px;">Scheduled Date/Time:<br><span style="color:#6D6D6D;">' + changedate(ordersdetails.order.patientinfo.scheduled_date) + '</span></label>';
            }
            htmlBanner += '</div>';

            if (jQuery.inArray(ordersdetails.OStatus, show_statuses_the_start_btn) >= 0) {
                htmlBanner += '<div class="col-md-3 col-sm-12 col-xs-12 order_status_change text-left">' +
                        '<a href="#" class="print_invoice_btn" name = "started" onclick="orderstatusChange(\'' + ordersdetails._id + '\',\'' + ordersdetails.order.patientinfo.scheduled_date + '\',\'' + payable_amount + '\',3)">Start</a>' +
                        '</div>';
            } else if (ordersdetails.OStatus == 3) {
                htmlBanner += '<div class="col-md-3 col-sm-12 col-xs-12 order_status_change text-left">' +
                        '<a href="#" class="print_invoice_btn" name = "inprogress" onclick="orderstatusChange(\'' + ordersdetails._id + '\',\'' + ordersdetails.order.patientinfo.scheduled_date + '\',\'' + payable_amount + '\',5)">Delivered</a>' +
                        '</div>';
            } else if (ordersdetails.OStatus == 5) {
                htmlBanner += '<div class="col-md-3 col-sm-12 col-xs-12 order_status_change text-left">' +
                        '<a href="#" class="print_invoice_btn" name = "completed" onclick="orderstatusChange(\'' + ordersdetails._id + '\',\'' + ordersdetails.order.patientinfo.scheduled_date + '\',\'' + payable_amount + '\',6)">Complete</a>' +
                        '<div style="position: absolute; left: -98px; bottom: -85px;">'+
                        '<input type="text" name="collected_amount" class="form-control" id="vendor_collected_amount" value="" placeholder="Enter collected amount...">'+
                        '<input type="checkbox" name="" value="1" id = "amt_chkbox" >Amount Collected' +
                        '</div>'+
                        '</div>';
            } else if (ordersdetails.OStatus == 21) {
                htmlBanner += '<div class="col-md-3 col-sm-12 col-xs-12  text-left">' +
                        '<label>Logistics Vendor :</label>' +
                        '<select name="vendor" id="logisticsvendor" class="form-control new-status">' +
                        '<option value="callhealth">Callhealthpickup</option>' +
                        '<option value="vendorpickup">VendorPickup</option>' +
                        '</select>' +
                        '</div>';
            }else{
                
            }
            
            if (jQuery.inArray(ordersdetails.OStatus, cancel_btn_on_statuses) >= 0) {
                htmlBanner += '<div class="col-md-2 col-sm-12 col-xs-12 cancel_order text-right" style="margin-top:-35px;">' +
                        '<a href="#" class="print_invoice_btn" name = "cancel" onclick="cancelorder_Popup(\'' + ordersdetails._id + '\',\'' + ordersdetails.order.patientinfo.scheduled_date + '\',15)">Cancel</a>' +
                        '</div>';
            }
            htmlBanner += '</article>' +
                    '</section>' +
            ///////// end of box code  ///////////
                    
            '<br>' +
                    
            ///////// Table is started  ///////////
    
                    '<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
                    '<div class="table-responsive">' +
                    '<table class="table table-condensed table-bordered table-striped medicine_home_order_table" id="toggleColumn-datatable">' +
                    '<thead>' +
                    '<tr>' +
                    '<th>Select All <input type="checkbox" name="allitem_select" value="1" onclick="allselect()"></th>' +
                    '<th>Product Name</th>' +
                    '<th>Brand Name</th>' +
                    '<th>Type</th>' +
                    '<th>Order Qty</th>' +
                    '<th>Item MRP</th>' +
                    '<th>MRP</th>' +
                    '<th>Base Price</th>' +
                    '<th>Selling Price</th>' +
                    '<th>Discount</th>' +
                    '<th>Commission</th>' +
                    '<th>Actions</th>' +
                    '<th>Comments</th>' +
                    '<th>Reason</th>' +
                    '<th>Log Info</th>' +
                    '<th>Add Log</th>' +
                    '</tr>' +
                    '</thead>';
            '<tbody>'
            $.each(ordersdetails.order.orderitem, function (key, val) {
                commission_amount = parseFloat(val.net_amount) - parseFloat(val.total_baseprice);
                Tcommission_amount = Tcommission_amount + commission_amount;
                MRP = parseFloat(MRP) + parseFloat(val.gross_amount);
                baseprice = parseFloat(baseprice) + parseFloat(val.total_baseprice);
                sellingprice = parseFloat(sellingprice) + parseFloat(val.net_amount);
                discountamount = parseFloat(discountamount) + parseFloat(val.discount_amount);

                if (val.item_status == "8") {
                    htmlBanner += '<tr style="background:#FFB4B7;">';
                } else {
                    htmlBanner += '<tr style="">';
                }
                htmlBanner +=
                        '<td>' + '<input type="checkbox" name="item_reject"  value="' + val.item_code + '"></td>' +
                        '<td>' + (val.itemname ? val.itemname : "") + '</td>' +
                        '<td>' + (val.manufacturer ? val.manufacturer : "") + '</td>';
                if (val.type == 1) {
                    htmlBanner += '<td>Rent</td>';
                } else if (val.type == 2) {
                    htmlBanner += '<td>Sale</td>';
                } else {
                    htmlBanner += '<td>-</td>';
                }
                htmlBanner += '<td class="oneliner">' + (val.quantity ? val.quantity : 1) + ' </td>' +
                        '<td>' + val.MRP + '</td>' +
                        '<td>' + val.gross_amount + '</td>' +
                        '<td>' + val.total_baseprice + '</td>' +
                        '<td>' + val.net_amount + '</td>' +
                        '<td>' + val.discount_amount + '</td>' +
                        '<td>' + commission_amount + '</td>';
                //edit and view details tab td
                if (ordersdetails.OStatus == 21) {
                    if (typeof (val.batch) == "undefined") {
                        htmlBanner += '<td> <button type="button" onclick=updateprice_popup(' + ordersdetails._id + ',"' + val.item_code + '",' + val.quantity + ',' + val.MRP + ',' + val.item_base_p + ',' + val.item_selling_p + ',"' + escape(val.itemname) + '","","' + val.s_days + '","' + val.s_month + '","' + val.s_year + '","' + val.type + '","' + val.gross_amount + '","' + val.total_baseprice + '","' + val.net_amount + '") class="btn btn-primary" >Edit</button></td>';
                    } else {
                        htmlBanner += '<td><button type="button" onclick=viewbatchdetails(' + ordersdetails._id + ',"' + val.item_code + '",' + val.discount_amount + ') class="btn btn-primary" >view Details</button></td>';
                    }
                } else if (val.item_status != 9) {
                    if (typeof (val.batch) == "undefined") {
                        htmlBanner += ' <td>N/A</td>';
                    } else {
                        htmlBanner += ' <td><div class="dropdown"><button class="dropbtn">Batch details</button><div class="dropdown-content"><table  class="table table-bordered table-condensed table-striped table-responsive"><thead><tr><th>Quantity</th><th>Amount</th><th>batch Name</th></tr></thead>  <tbody>';
                        $.each(val.batch, function (bkey, bval) {
                            htmlBanner += '<tr><td>' + bval.quantity + '</td><td>' + bval.mrp + '</td><td>' + bval.batch + '</td></tr>';
                        });
                        htmlBanner += '  </tbody></table></div></div></td>';
                    }
                } else {
                    htmlBanner += '<td>N/A</td>' +
                            '<td>N/A</td>';
                }

                //comments td
                if (val.item_status == 9) {
                    htmlBanner += '<td><a href="#" data-toggle="tooltip" title="' + val.item_reject_reason + '">' + val.item_reject_reason + '</a></td>';
                } else {
                    htmlBanner += '<td>N/A</td>' +
                            '<td>N/A</td>';
                }

                //showing log information if log is added
                if (val.item_status != 9) {
                    var logtable =
                            '<td>' +
                            '<div class="dropdown">' +
                            '<button class="dropbtn"> <i class="fa fa-info cust_check" aria-hidden="true"></i></button>' +
                            '<div class="dropdown-content" style="right:10%;">' +
                            '<table class="table table-bordered table-condensed table-striped table-responsive">' +
                            '<thead>' +
                            '<tr>' +
                            '<th>Role</th><th>Name</th><th>Log Details</th><th>Date/Time</th></tr></thead><tbody>';
                    var logdata = "";
                    if (typeof ordersdetails.user_log != "undefined") {
                        $.each(ordersdetails.user_log, function (bkey, bval) {
                            if (bval.item_code == val.item_code) {
                                logdata += '<tr><td>' + bval.role + '</td><td>' + bval.actionbyname + '</td><td>' + bval.log_reason + '</td><td>' + bval.action_date + '</td></tr>';
                            }
                        });
                    }
                    if (logdata == "") {
                        htmlBanner += '<td colspan="">NA</td>';
                    } else {
                        htmlBanner += (logtable + logdata + '</tbody></table></div></div></td>');
                    }
                    //add log td
                    htmlBanner += '<td> <a href="#" class="mpt" onclick="addLog_popup(\'' + ordersdetails._id + '\',\'' + val.item_code + '\')">Add Log</a></td>';
                } else {
                    htmlBanner +=
                            '<td>N/A</td>' +
                            '<td>N/A</td>';

                }

                '</tr>';

            });
            htmlBanner +=
                    '</tbody>' +
                    '</table>' +
                    '</div>';
            //end of table

            //confirm and reject buttons
            if (ordersdetails.OStatus == 21) {
                htmlBanner +=
                        '<div class="col-md-1 col-sm-12 col-xs-12 text-right view_prec">' +
                        '<a href="#" class="comp_apply_btn  mpt" onclick="assignlogisticsvendor(' + ordersdetails._id + ',\'' + ordersdetails.order.patientinfo.scheduled_date + '\')">Confirm</a>' +
                        '</div>'+
              
                        '<div class="col-md-1 col-sm-12 col-xs-12 text-right view_prec">' +
                        '<a href="#" class="reject_btn  mpt" onclick="rejectorder_popup(' + ordersdetails._id + ')">Reject</a>' +
                        '</div>';
            }

            //displaying total amount
            if (jQuery.inArray(ordersdetails.OStatus, show_totalamount_on_statuses) >= 0) {
                htmlBanner +=
                        '<div class="col-md-2 col-sm-12 col-xs-12 text-right view_prec">' +
                        '<label>MRP &nbsp; : &nbsp; &#8377; ' + MRP.toFixed(2) + '</label>' +
                        '<label>Base Price &nbsp; : &nbsp; &#8377;&nbsp; ' + baseprice.toFixed(2) + '</label>' +
                        '<label>Selling Price &nbsp; : &nbsp; &#8377;&nbsp; ' + sellingprice.toFixed(2) + '</label>' +
                        '<label>Discount &nbsp; : &nbsp; &#8377;&nbsp; ' + discountamount.toFixed(2) + '</label>' +
                        '<label>Commission &nbsp; : &nbsp; &#8377;&nbsp; ' + Tcommission_amount.toFixed(2) + '</label>' +
                        '</div>';
            }

            //print cash memo and shipment label buttons
            htmlBanner += '<div class="col-md-4 col-sm-6 col-xs-12 text-right">';
            if (ordersdetails.OStatus != 24 && ordersdetails.OStatus != 21) {
                htmlBanner += '<a href="#" class="print_invoice_btn" onclick="invoicedownload(' + ordersdetails._id + ')">PRINT Cash MEMO</a>  &nbsp;' +
                        '<a href="#" class="print_invoice_btn" onclick="shipmentlabeldownload(' + ordersdetails._id + ')">SHIPMENT LABEL</a>';
            }
            htmlBanner += '</div>' +
                    '</div></article></section>';

        } else {
            alert("Data not found.");
            $(".loader").hide();
        }
    } else {
        if (resposne.data.length <= 0) {
            alert(resposne.message);
            $(".loader").hide();
            console.log(resposne);
        }
    }


    $("#Custom_body").html(htmlBanner);
    $(".loader").hide();
    var d = new Date(ordersdetails.order.patientinfo.expected_delivery_time);
    var date = d.getDate + "-" + d.getMonth + "-" + d.getYear();
    $('#vendordate').datepicker('setDate', date);
    $("#vendordate").datepicker('setStartDate', '0d');

}







































