var RestServiceURL = sessionStorage.getItem('base_url')+"OMS/api/";
var SHOW_LOADER = "1";
var NO_SHOW_LOADER = "0";

//common ajax call
function _ajaxEventHandler(_method,payload,responce,showLoader=1,methodtype="POST",route_file="medicine_supply.php/v1/"){
	if(showLoader=='1')
	{$(".loader").show();}
	var url = RestServiceURL+route_file+_method;
	$.ajax({
		url: url, 
		type: methodtype,
    	        data: JSON.stringify(payload),
    	        contentType: "application/json",
                success: responce,
	        error:errormsg
    });
} 

function errormsg(error){
	console.log(error);
	alert(error);
	$(".loader").hide();
}

//service type in an array
var servicetype = {
	"1" : "Consultation Order",
	"2" : "Drug Order",
	"3" : "Diagnostics Order",
	"4" : "Facilitation Order",
	"5" : "Care@Home Order",
	"30" : "Assessment Order"
};

var channel = {
	1:"CP",
	2:"CCO",
	3:"Android App",
	4:"Corporate Portal",
	5:"IOS App",
	6:"L2 Pharma",
	7:"Officer App"
};

function logout(){
	sessionStorage.clear();
	window.location = "logout.php";
}

function usersession(){
	if($.trim(sessionStorage.getItem('eqsu_user_id'))=="" && $.trim(sessionStorage.getItem('eqsu_user_name'))==""){
		logout();
	}
}
usersession();

function changedate(dt){ 
   /* if(dt === "NaN"){
          return "-"; 
   }else{
        dt = dt.replace(" ", "T");
        dt = dt.split('T');
        var time = dt[1].slice(0, 10);
        time = time.slice(0, 8);
        var H = +time.substr(0, 2);
        var h = (H % 12) || 12;
        var ampm = H < 12 ? "AM" : "PM";
        time = h + time.substr(2, 6) +" "+ ampm;
        //console.log(time[1]);
        return dt = dt[0] + ' ' + time; 
   }*/
    if (typeof dt != 'undefined') {
        return dt.replace('T', ' ').replace('.000Z', '');
    }else{
		return "-";
	}
}



function getOrderStatus(orderstatus) {
        if (orderstatus === "0" || orderstatus === 0) {
            return "Unassigned";
        } else if (orderstatus === "1" || orderstatus === 1) {
            return "Assigned";
        } else if (orderstatus === "2" || orderstatus === 2) {
            return "Accepted";
        } else if (orderstatus === "3" || orderstatus === 3) {
            return "Started";
        } else if (orderstatus === "4" || orderstatus === 4) {
            return "Reached";
        } else if (orderstatus === "5" || orderstatus === 5) {
            return "In Progress";
        } else if (orderstatus === "6" || orderstatus === 6) {
            return "Completed";
        } else if (orderstatus === "7" || orderstatus === 7) {
            return "Rescheduled";
        } else if (orderstatus === "9" || orderstatus === 9) {
            return "Rejected";
        } else if (orderstatus === "10" || orderstatus === 10) {
            return "Reallocation";
        } else if (orderstatus === "13" || orderstatus === 13) {
            return "Item Packed";
        } else if (orderstatus === "14" || orderstatus === 14) {
            return "Assigned to L2 Pharmacists";
        } else if (orderstatus === "15" || orderstatus === 15) {
            return "Request for Cancellation";
        } else if (orderstatus === "16" || orderstatus === 16) {
            return "Request for Reschedule";
        } else if (orderstatus === "17" || orderstatus === 17) {
            return "Draft";
        } else if (orderstatus === "21" || orderstatus === 21) {
            return "L2 Assigned to Vendor";
        }
}

function orderstatus(order_status){
	switch(order_status){
	 case 0:
	   return 'Unassigned';
	   break;
	 case 1:
	   return 'Assigned';
	   break;
	 case 2:
	   return 'Accepted';
	   break;
	 case 3:
	   return 'Started';
	   break;
	 case 4:
	   return 'Reached';
	   break;
	 case 5:
	   return 'InProgress';
	   break;
	 case 6:
	   return 'Completed';
	   break;
	 case 7:
	   return 'Rescheduled';
	   break;
	 case 8:
	   return 'Cancelled';
	   break;
	 case 9:
	   return 'Rejected';
	   break;
	 case 10:
	   return 'Reallocation';
	   break;
	 case 13:
	   return 'Item Bagged';
	   break;
	 case 14:
	   return 'Assigned to l2 pharmacist';
	   break;
	 case 15:
	   return 'Request for cancellation';
	   break;
	 case 16:
	   return 'Request for reschedule';
	   break;
	 case 17:
	   return 'Draft';
	   break;
	 case 18:
	   return 'Vendor requested for pickup';
	   break;
	 case 19:
	   return 'Return';
	   break;
	 case 20:
	   return 'Not Pickedup Imcomplete Order';
	   break;
	 case 21:
	   return 'L2 Assigned to Vendor';
	   break;
	 case 22:
	   return 'Payment submitted by MHO';
	   break;
	 case 24:
	   return 'Rejected';
	   break;
	default:
	   return 'Order status is incorrect';
	   break;
	}
}

function todayDate() {
    var d = new Date(),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();
    hour = d.getHours();
    minute = d.getMinutes();
    if (month.length < 2)
        month = '0' + month;
    if (day.length < 2)
        day = '0' + day;
    if (hour.length < 2)
        hour = '0' + hour;
    if (minute.length < 2)
        minute = '0' + minute;
    return ([month, day, year].join('/'));
}

function settimeslot(orderdate = "", ordertime = ""){
    var date1 = todayDate();
    var date2 = $("#vendordate").val();
    var today = new Date();
    var time = today.getHours();
    var date1Updated = new Date(date1.replace(/-/g, '/'));
    //alert(date1Updated);
    var date2Updated = new Date(date2.replace(/-/g, '/'));
// alert(date2Updated);
    if (date1 === date2) {
        if (time <= 9) {
            $('#10amslot').attr('disabled', false);
            $('#2pmslot').attr('disabled', false);
            $('#6pmslot').attr('disabled', false);
        }
        if (time >= 10 && time <= 14) {
            $('#10amslot').attr('disabled', true);
            $("#vendortime option[value='18:00:00']").prop('selected', true);
            $('#2pmslot').attr('disabled', false);
            $('#6pmslot').attr('disabled', false);
        }
        if (time >= 14 && time <= 18) {
            $('#10amslot').attr('disabled', true);
            $('#2pmslot').attr('disabled', true);
            $("#vendortime option[value='22:00:00']").prop('selected', true);
            $('#6pmslot').attr('disabled', false);
        }
        if (time >= 18) {
            $('#10amslot').attr('disabled', true);
            $('#2pmslot').attr('disabled', true);
            $('#6pmslot').attr('disabled', true);
        }

    } else if (date1Updated < date2Updated) {
        $('#10amslot').attr('disabled', false);
        $('#2pmslot').attr('disabled', false);
        $('#6pmslot').attr('disabled', false);
        $("#vendortime option[value='14:00:00']").prop('selected', true);
    } else {
        $('#10amslot').attr('disabled', true);
        $('#2pmslot').attr('disabled', true);
        $('#6pmslot').attr('disabled', true);
    }
}


