/* Plugin Name : Custome Data Table, 
 * Developed By : Prasanna Kumar
 * Date : 18/02/2019
 * Features : Table prepare with pagination from server side and local, search, show per page, search 
 */


(function ($) {
    var $this = '';
    var searchValue = '';
    var tBody = {table: "", totalcount: 0};
    var jsonParse = '';
    var __ajaxCall = true;
    $.fn.customeDataTable = function (options) {
        var settings = $.extend({
            data: {},
            searchcolumns: [], // Sno - local - true, server - false 
            headers: [], // Sno - If want Sno - true otherwise Sno : false,
            columns: [],
            structure: "json", // json, table, local 
            orderby: 0, // 0 - ascending, 1 - decending
            perpage: 10,
            actionurl: '',
            actiontype: 'get', // get, post,
            search: true, // true or false,
            localpagination: true, // true or false it will use in full data get from server at on time.
            serverpagination: true, // true or false
            customsearch: false,
            tableprepare: '',
            skip : 1,
        }, options);

        this.each(function () {
            $this = $(this);
            var dataTable = '';
            var structure = settings.structure;
            if (structure == 'local') {
                __ajaxCall = false;
                dataTable = tableFullDataStructure();
            } else if (structure == 'json') {
                dataTable = jsonStructure();
            } else {
                dataTable = tableStructure();
            }
            if (dataTable) {
                $this.html(dataTable);
            }
        });

        function ajaxCall() {
            var params = settings.data;
            params.orderby = settings.orderby;
            params.limit = settings.perpage;
            params.skip = settings.skip;
            params.pagination = settings.serverpagination;

            var result = '';
            $.ajax({
                url: settings.actionurl,
                type: settings.actiontype,
                data: JSON.stringify(params),
                async: false,
                success: function (response) {
                    if (typeof response == 'string') {
                        jsonParse = JSON.parse(response);
                    } else {
                        jsonParse = response;
                    }
                    var records = jsonParse['data'];
                    if (settings.structure == 'json') {
                        records = JSON.stringify(jsonParse);
                        result = window[settings.tableprepare](records);
                    } else {
                        result = records;
                        var perPage = settings.perpage;
                        var totalCount = jsonParse.totalcount;
                        var paginationBody = pagination(totalCount, perPage, settings.skip);
                        var table = '<div>' + prepareSearch() + result + paginationBody + '</div>';
                        $this.html(table);
                    }
                    searchValue = '';
                },
                error: function () {

                }
            });
            result = {
                table: result,
                totalcount: jsonParse['totalcount']
            };
            return result;
        }

        function prepareThead() {
            var headers = settings.headers;
            if (headers.length > 0) {
                var thead = '<thead>';
                if (settings.structure == 'local') {
                    thead += $this.find('table thead').html();
                } else {
                    thead += '<tr>';
                    if (headers.length > 0) {
                        for (var headerkey in headers) {
                            thead += '<th>' + headers[headerkey] + '</th>';
                        }
                    }
                    thead += '</tr>';
                }
                thead += '</thead>';
                return thead;
            }
            return '';
        }

        function jsonStructure() {
            var jsonStructure = '';
            if (settings.serverpagination == true) {
                jsonStructure = jsonPerPageStructure();
            } else {
                jsonStructure = jsonFullDataStructure();
            }
            return jsonStructure;
        }

        function jsonPerPageStructure() {
            tBody = ajaxCall();
            var table = '<div>';
            table += prepareSearch();
            var perPage = settings.perpage;
            var totalCount = tBody.totalcount;
            var paginationBody = pagination(totalCount, perPage, settings.skip);
            var tHead = prepareThead();
            if (tHead != '') {
                table += '<div><table class="table table-bordered">' + tHead + tBody.table + '</table></div>' + paginationBody + '</div>';
            } else {
                table += '<div>' + tBody.table + '</div>' + paginationBody + '</div>';
            }
            return table;
        }

        function jsonFullDataStructure() {
            if (__ajaxCall === true || settings.customsearch == true || settings.skip == 1) {
                settings.skip = 1;
                tBody = ajaxCall();
                __ajaxCall = false;
                var paginationBody = '';
                if (settings.localpagination === true) {
                    var perPage = settings.perpage;
                    var totalCount = '';
                    totalCount = tBody.totalcount;
                    paginationBody = pagination(totalCount, perPage, settings.skip);
                }
                var table = '<div>';
                var tHead = prepareThead();
                table += prepareSearch();
                if (tHead != '') {
                    table += '<div><table class="table table-bordered">' + tHead + tBody.table + '</table></div>' + paginationBody + '</div>';
                } else {
                    table += '<div>' + tBody.table + '</div>' + paginationBody + '</div>';
                }
                $this.html(table);
            }

            prepareFinalTable();

        }

        function tableStructure() {
            var tableStructure = '';
            if (settings.serverpagination === true) {
                tableStructure = tablePerPageStructure();
            } else {
                tableStructure = tableFullDataStructure();
            }
            return tableStructure;
        }

        function tablePerPageStructure() {
            return jsonPerPageStructure();
        }

        function tableFullDataStructure() {
            if (__ajaxCall === true || settings.customsearch == true) {
                __ajaxCall = false;
                tBody = ajaxCall();
                settings.skip = 1;
            }
            return prepareFinalTable();
        }

        function prepareFinalTable() {
            var perPage = settings.perpage;
            var records = prepareSearchData();
            records = JSON.parse(records);
            var offset = (settings.skip - 1) * perPage;
            var limit = offset + perPage;
            var totalCount = records.totalCount;
            var paginationBody = '';
            if (settings.localpagination === true) {
                paginationBody = pagination(totalCount, perPage, settings.skip);
                records.tableIndex = records.tableIndex.slice(offset, limit);
            }
            localTablePrepare(records.tableIndex);

            var search = prepareSearch();
            if ($this.find('#searchHtml').length > 0) {
                $this.find('#searchHtml').html(search);
            } else {
                $this.prepend(search);
            }
            if ($this.find('#paginationHtml').length > 0) {
                $this.find('#paginationHtml').html(paginationBody);
            } else {
                $this.append(paginationBody);
            }
            return '';
        }

        function localTablePrepare(tableIndex) {
            var table = $this.find('tbody tr');
            $.each(table, function (key, value) {
                if ($.inArray(key, tableIndex) == -1) {
                    $this.find('tbody tr').eq(key).hide();
                } else {
                    $this.find('tbody tr').eq(key).show();
                }
            });
        }

        function prepareSearchData() {
            $totalCount = 0;
            $columns = [];
            $tableIndex = [];
            $i = 0;
            $this.find('th').each(function () {
                $columns[$i] = $(this).text();
                $i++;
            });
            $.each($this.find('table tbody tr'), function () {
                $jsonrow = {};
                $match = false;
                $.each($(this).find('td'), function (key, value) {
                    $tdIndex = $(this).index();
                    $key = $columns[$tdIndex];
                    $jsonrow[$key] = $(this).text();
                });
                $index = $(this).index();
                if (searchValue == '') {
                    $totalCount++;
                    $tableIndex.push($index);
                } else {
                    searchValue = searchValue.toLowerCase();
                    $jsonrowCheck = false;
                    for (var key in $jsonrow) {
                        if ($jsonrow[key].toLowerCase().indexOf(searchValue) != -1) {
                            $jsonrowCheck = true;
                            break;
                        }
                    }
                    if ($jsonrowCheck === true) {
                        $totalCount++;
                        $tableIndex.push($index);
                    }
                }
            });
            $json = {totalCount: $totalCount, tableIndex: $tableIndex};
            return JSON.stringify($json);
        }

        function pagination(totalCount, perpage, pageNo) {
            settings.skip = parseInt(pageNo);
            $pagination = Math.ceil(totalCount / perpage);
            var htmlBanner = '';
            if ($pagination > 1) {
                $paginationLength = 5;
                $p = 1;
                htmlBanner += '<div id="paginationHtml" class="text-center" ><ul id="pagination" class="pagination">';
                
                if ($pagination > 5) {
                    if ($pagination > settings.skip) {
                        if (settings.skip >= 5) {
                            htmlBanner += '<li class="" style="cursor: pointer;"   ><a id="paginationPage-' + $p + '" class="paginationPage">First</a></li><li><a>...</a></li>';
                            $p = settings.skip - 3;
                            $paginationLength = settings.skip + 1;
                        }

                    } else {
                        htmlBanner += '<li  style="cursor: pointer;" ><a id="paginationPage-' + $p + '" class="paginationPage">First</a></li><li><a>...</a></li>';
                        $p = settings.skip - 4;
                        $paginationLength = $pagination;
                    }

                } else {
                    $paginationLength = $pagination;
                }
                for ($p; $p <= $paginationLength; $p++) {
                    if (($p == settings.skip)) {
                        $active = 'active';
                    } else {
                        $active = '';
                    }
                    htmlBanner += '<li class="' + $active + '" style="cursor: pointer;"><a id="paginationPage-' + $p + '" class="paginationPage">' + $p + '</a></li>';

                }
                if ($pagination > 5) {
                    $last = $pagination - settings.skip;
                    if ($last >= 2) {
                        htmlBanner += '<li><a>...</a></li><li style="cursor: pointer;"><a id="paginationPage-' + $pagination + '" class="paginationPage">Last</a></li>';
                    }
                }
                htmlBanner += '</ul>';
                htmlBanner += '</div>';
            }
            return htmlBanner;
        }

        function prepareSearch() {
            if (settings.search == false) {
                return '';
            }
            var search = '';
            if ((settings.serverpagination == false) || ((settings.localpagination == true) && (settings.structure == 'local'))) {
                search = '<div id="searchHtml" class="pull-right"><ul style="margin: 9px;"  class="pagination" ><li style="float: left;"><input type="text" value="' + searchValue + '" name="search" class="form-control datatable-search" id="datatable-search"  /></li></ul></div>';
            } else if ((settings.serverpagination == true) && (settings.structure != 'local')) {
                search = '<div id="searchHtml" class="pull-right"><ul style="margin: 9px;" class="pagination" ><li style="float: left;"><input type="text" value="' + searchValue + '" name="search" class="form-control datatable-search"  /></li><li><button style="padding: 6.5px 18px;margin-left: 7px;" type="button" class="btn btn-sm btn-primary" id="datatable-search">Search</button></li></ul></div>';
            }
            return search;
        }

        function callDataTable($this, searchValue, pageNo) {
            pageNo = pageNo || false;
            var params = settings.data;
            params.search = searchValue;
            if (pageNo == false || settings.customsearch == true) {
                settings.skip = 1;
            } else {
                settings.skip = pageNo;
            }
            $this.customeDataTable({
                data: params,
                searchcolumns: settings.searchcolumns, // Sno - local - true, server - false 
                headers: settings.headers, // Sno - If want Sno - true otherwise Sno : false,
                columns: settings.columns,
                structure: settings.structure, // servertable, localtable, json
                orderby: settings.orderby, // 0 - ascending, 1 - decending
                perpage: settings.perpage,
                actionurl: settings.actionurl,
                actiontype: settings.actiontype, // get, post,
                tableprepare: settings.tableprepare, // table preparefunction
                search: settings.search, // true or false,
                localpagination: settings.localpagination, // true or false it will use in full data get from server at on time.
                serverpagination: settings.serverpagination, // true or false
                customsearch: settings.customsearch,
                skip:settings.skip
            });
        }

        var searchFn = 'click';
        if ((settings.serverpagination == false) || ((settings.localpagination == true) && (settings.structure == 'local'))) {
            searchFn = 'keyup';
        }

        $.fn.setCursorPosition = function (pos) {
            this.each(function (index, elem) {
                if (elem.setSelectionRange) {
                    elem.setSelectionRange(pos, pos);
                }
            });
        };
        $('#datatable-search').on(searchFn, function () {
            if (settings.serverpagination == false) {
                searchValue = $(this).val();
                __ajaxCall = false;
            } else {
                searchValue = $('.datatable-search').val();
            }
            settings.customsearch = false;
            callDataTable($this, searchValue);
            var searchValueLength = searchValue.length;
            $('.datatable-search').focus().setCursorPosition(searchValueLength);
        });

        $('.paginationPage').click(function () {
            var id = $(this).attr('id');
            var idSplit = id.split('-');
            var pageNo = parseInt(idSplit[1]);
            if (settings.serverpagination === false) {
                __ajaxCall = false;
            }
            settings.customsearch = false;
            callDataTable($this, '', pageNo);
        });
    }
})(jQuery);
