function allOrders(ajaxMethod, SuccessFn, withSearch, skip, pagination) {
    console.log(pagination);
    withSearch = withSearch || false;
    ajaxMethod = ajaxMethod || false;
    pagination = pagination || false;
    skip = skip || '1';
    sessionStorage.setItem("ajaxMethod", ajaxMethod);
    sessionStorage.setItem("SuccessFn", SuccessFn);
    sessionStorage.setItem("withSearch", withSearch);
    sessionStorage.setItem("pagination", pagination);
    sessionStorage.setItem("skip", skip);
    var _data = {};
	if($.trim($("#searchvalue").val())!=""){
		//alert();
		if($("#searchtext").val()=="orderidser"){
			_data.orderidser = $("#searchvalue").val();
		}else if($("#searchtext").val()=="orderdidser"){
			_data.orderdidser = $("#searchvalue").val();
		}else{
                    _data.mrn = $("#searchvalue").val();
                }
	}	
   
    _data.vendorid = sessionStorage.getItem('eqsu_user_id');
    _data.pagination = true;
    _data.skip = skip; 
    _data.limit = 10;
    //_ajaxEventHandler(ajaxMethod, _data, SuccessFn, SHOW_LOADER);
    _customeDataTable(_data, ajaxMethod, SuccessFn, SHOW_LOADER);
}

function _customeDataTable(_data, ajaxMethod, SuccessFn, showLoader) {
    showLoader = showLoader || 1;
    if (showLoader == '1') {
        $(".loader").show();
    }
    _data.method = ajaxMethod;
    _data.type = "eqvendor";
    var url = sessionStorage.getItem("base_url") + 'OMS/api/medicine_supply.php/v1/getMedOrdersByFilter';
    $("#Custom_body").customeDataTable({
        data: _data,
        orderby: 0,
        actionurl: url,
        actiontype: "POST",
        tableprepare: SuccessFn,
        pagination: _data.pagination,
        perpage: _data.limit,
        search: false,
        customsearch: _data.customsearch,
        skip: _data.skip
    });
    $(".loader").hide();
}

function trackOrder(orderid) {
    if (orderid == "") {
        alert("Please Select the Correct Order.")
    } else {
        var _data = {order_id: orderid};
        _ajaxEventHandler('ordertrack', _data, trackOrderView, SHOW_LOADER,"POST","operation.php/v1/");
    } 
}

function vieworder(orderid) {
    var _data = {orderid: orderid};
    var data = _ajaxEventHandler("getorderdetails",_data, showorderview, SHOW_LOADER);
    //console.log(data);
}









var global_eqorderid="";

function allselect(){
    var st=$('input[name="allitem_select"]:checked').val();
    console.log(st);
    if(st){
        $('input[name="item_reject"]').prop("checked", "checked");
    }else{
        $('input[name="item_reject"]').prop("checked", false);
    }	
}

//calling popup for updateprice
function updateprice_popup(eqorder_id, item_code, quantity, mrp, baseprice, sellingprice, itemname, disamount, days, month, year, type, gross_amount, total_baseprice, net_amount) {
    var header_data = "";
    var body_data = "";
    var footer_data = "";
    itemname = itemname.replace(/[^a-zA-Z ]/g, " ");
    header_data +='<h3 class="modal-title" style="width:300px;" id="myModalLabel">Update MRP</h3>';        
    body_data +=
            '<h5>Quantity:&nbsp;&nbsp;<b><span id=qty>'+quantity+'</span></b></h5>'+
            '<h6 id=equipment_name>Product Name:&nbsp;&nbsp;<b><span id=iname>'+itemname+'</span></b></h6>'+
            '<h6 id=eq_rent_days>Days:&nbsp;&nbsp;<b><span id=days>'+days+'</span></b></h6>'+
            '<h6 id=eq_rent_months>Month:&nbsp;&nbsp;<b><span id=month>'+month+'</span></b></h6>'+
            '<h6 id=eq_rent_years>Year:&nbsp;&nbsp;<b><span id=year>'+year+'</span></b></h6>'+
            '<h6 id=equipmenttype>Type:&nbsp;&nbsp;<b><span>'+type+'</span></b>&nbsp;&nbsp;(1=Rent / 2=Sale )</h6><br>'+
            '<table class="table table-striped" id="vendorupdateprice">'+
            '<thead id="tblHead">'+
            '<tr>'+
            '<th>Quantity</th>'+
            '<th>MRP</th>' +
            '<th>Base Price</th>'+
            '<th>Selling Price</th>'+
            '</tr>'+
            '</thead>'+
            '<tbody>'+
            '<tr>'+
            '<td><input type="Number" value=' + quantity + ' onkeypress="return event.charCode >= 48 && event.charCode <= 57" class="form-control controlInput" id="item_quantity"  min="1" name="changequantity1"></td>' +
            '<td><input type="Number" value=' + mrp + ' min="1"   onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" title="Only Number"  step="1" class="form-control controlInput" id="item_mrp" name="price1"></td>' +
            '<td><input type="Number" value=' + baseprice + ' min="1"   onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" title="Only Number"  step="1" class="form-control controlInput" id="item_baseprice" name="baseprice"></td>' +
            '<td><input type="Number" value=' + sellingprice + ' min="1"   onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" title="Only Number"  step="1" class="form-control controlInput sellingprice1" id="item_sellingprice" name="sellingprice"></td>' +
            '<!--<td><input type="text" min="1"   onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" title="Only Number"  step="1" class="form-control controlInput" id="gst" name="gst" disabled></td>-->' +
            '<td><input type="hidden" id="eqorder_id" name="l2omorder_id" value='+eqorder_id+'></td>'+
            '<td><input type="hidden" class="form-control controlInput" id="bbatchno1" name="bbatchno1" maxlength="20"  value="1"></td>'+
            '<td><input type="hidden" id="item_code" name="item_code" value='+item_code+'></td>'+
            '<td><input type="hidden" id="batchcount" name="batchcount" value="1"></td>'+
            '</tr>'+
            '<!--<tr><label>Calculate GST(Selling Price):</label>'+
            '<td id="show_gst"></td>' +
            '<select name="gstcalcualtor" id="gstdropdown" class="form-control new-status" onchange="calculateGST(this.value)">'+
            '<option value="0.00">Calculate GST</option>'+
            '<option value="0.05">5%</option>'+
            '<option value="0.12">12%</option>'+
            '<option value="0.18">18%</option>'+
            '</select>' +
            '<td><input type="hidden" id="showprice" name="gst"></td>'+
            '</tr>-->'+
            '<tr>'+
            '<h6 id=total_mrp>Total MRP:&nbsp;&nbsp;<b><span>' + gross_amount + '</span></b></h6>'+
            '<h6 id=total_baseprice>Total Baseprice:&nbsp;&nbsp;<b><span>' + total_baseprice + '</span></b></h6>'+
            '<h6 id=total_sellingprice>Total Sellingprice:&nbsp;&nbsp;<b><span>' + net_amount + '</span></b></h6>'+
            '</tr>'+
            '</tbody>'+
            '</table>';
    
    footer_data +=
            '<button type="button" class="btn btn-primary" onclick="vendorupdateprice()">Update</button>'+
            '<span id="display"></span>';

    $("#myModalLabel").html(header_data);
    $("#trackresult").html(body_data);
    $("#modalfooter").html(footer_data);
    $("#Modal_for_all").modal("show");
    
    if (type == "1") {    
        $("#item_mrp").prop('disabled', true);
        $("#item_baseprice").prop('disabled', true);
        $('#item_sellingprice').prop('disabled', false);
    } else {
        $("#item_mrp").prop('disabled', false);
        $("#item_baseprice").prop('disabled', false);
        $('#item_sellingprice').prop('disabled', true);
    }
    
}

//vendor updating price
function vendorupdateprice() {
    var newvalues = [];
    var qty = 0;
    var type = $('#equipmenttype span').text();
    var rowcount = $("#batchcount").val();
    var orderqty = $('#item_quantity').val();
    var eqorder_id = $('#eqorder_id').val();
    var item_code = $('#item_code').val();
    var mrp = $('#item_mrp').val();
    var baseprice = $('#item_baseprice').val();
    var sellingprice = $('#item_sellingprice').val();
    var gross_amount = $('#total_mrp span').text();
    var total_baseprice = $('#total_baseprice span').text();
    var net_amount = $('#total_sellingprice span').text();

    if (parseFloat(sellingprice) > parseFloat(mrp)) {
        alert("SellingPrice is always lessthan MRP");
        return false;
    }
    if (parseFloat(mrp) < parseFloat(sellingprice)) {
        alert("MRP is always Greaterthan Sellingprice");
        return false;
    }
    if (parseFloat(baseprice) > parseFloat(sellingprice)) {
        alert("BasePrice is always lessthan Sellingprice");
        return false;
    }

    if (mrp == 0 || baseprice == 0 || sellingprice == 0) {
        alert("please fill all fields in add batch and Don`t fill 0 as quantity or mrp or baseprice and selling price.");
        return false;
    }
    if (orderqty <= 0) {
        alert("Atleast one quantity is needed");
        return false;
    }
    global_eqorderid = eqorder_id;
    gross_amount = parseFloat(mrp * orderqty);
    net_amount = parseFloat(sellingprice * orderqty);
    total_baseprice = parseFloat(baseprice * orderqty);
    var _data = {
        order_id:parseInt(eqorder_id), 
        item_code:item_code, 
        MRP:parseFloat(mrp),
        item_selling_p:parseFloat(sellingprice),
        item_base_p:parseFloat(baseprice),
        gross_amount:parseFloat(gross_amount),
        net_amount:parseFloat(net_amount),
        total_baseprice:parseFloat(total_baseprice),
        quantity:parseInt(orderqty), 
        type:parseInt(type) 
      };
    console.log(_data);
	_ajaxEventHandler("updateEquipmentItem",_data,commonres_forvendormethods,SHOW_LOADER);
    /*$.ajax({
       url: "http://172.26.7.111/vivek/OMS/api/medicine_supply.php/v1/updateEquipmentItem", 
       type: "POST",
       data: JSON.stringify(_data),
       contentType: "application/json",
       success: commonres_forvendormethods		
   });*/
}

//common response of vendor 
function commonres_forvendormethods(resposne) {
    $(".loader").hide();
    console.log(resposne);
    if (typeof resposne == 'string') {
        resposne = JSON.parse(resposne);
    } 
    if (resposne.status == "1" || resposne.status == 1) {
        alert(resposne.message);
        $("#Modal_for_all").modal("hide");
        vieworder(global_eqorderid);
    } else {
        alert(resposne.message);
    }
}

//cancel button popup
function cancelorder_Popup(orderid,scheduled_date,status){
    var header_data = "";
    var body_data = "";
    var footer_data = "";
    header_data +='<h3 class="modal-title" style="width:300px;" id="myModalLabel">Are you sure you want to cancel.?</h3>' ;
    body_data +=
            "<div class='form-group'>"+
            "<label for='usr'>Reason:</label>"+
            '<textarea name="job_name"  class="form-control new-status" id="cancel_reason" placeholder="Enter Reason To Cancel"></textarea>'+
            "</div>";
    footer_data+=
            "<div class='form-group'>"+
            '<button type="button" class="btn btn-success" style="margin-bottom:25px;margin-right: 10px;" onclick="orderCancel(\'' + orderid + '\',\'' + scheduled_date + '\',\'' + status + '\')"">Yes</button>'+
            '<button type="submit" class="btn btn-danger" data-dismiss="modal" style="margin-bottom:25px;margin-right: 10px;">No</button>'+
            "</div>";
            
    $("#myModalLabel").html(header_data);
    $("#trackresult").html(body_data);
    $("#modalfooter").html(footer_data);
    $("#Modal_for_all").modal("show");
}

function orderCancel(eqorderid,scheduled_date,status){
     var scdate = scheduled_date.split("T"); 
     var reason_text = $("#cancel_reason").val();
     if(status == 15 && reason_text === "" ){ 
         alert("please enter the reason and click on yes");
         return false;  
     }
     global_eqorderid = eqorderid;
     var _data = {
            order_id:[parseInt(eqorderid)],
            actionById:sessionStorage.getItem("eqsu_user_id"),
            actionByName:sessionStorage.getItem("eqsu_user_name"),
            source:1,
            role:"CCO",
            scheduled_date:scdate[0],
            reasonType:1,
            reason:"cancel",
            reason_text:reason_text,
            comment:"cancel"
     };
	
    console.log(_data);
    _ajaxEventHandler("orderCancel",_data,res_orderCancel,SHOW_LOADER,"POST","operation.php/v1/");	
}
function res_orderCancel(resposne){
    $(".loader").hide();
    console.log(resposne); 
    if (resposne.status == "1" || resposne.status == 1) {
        alert(resposne.msg[0].msg);
        $("#Modal_for_all").modal("hide");
        vieworder(global_eqorderid);
    } else {
        alert(resposne.msg);
    }
}

//changing orderstatus for Start,Inprogress,Completed

var scheduledd_date="";
var OStatus="";

function orderstatusChange(eqorderid,scheduled_date,payable_amount,status){
   var vendor_collected_amount = $("#vendor_collected_amount").val();
   // alert(vendor_collected_amount);
   //alert(payable_amount);
   if(vendor_collected_amount == "" ){ 
        alert("please enter collected amount");
        return;       
  }
  if(vendor_collected_amount > payable_amount){ 
        alert("collected amount should not be greaterthan payable amount");
        return;       
  }
   
   if($("#amt_chkbox").prop('checked') == false ){ 
        alert("please click on amount collected box before updating the order status");
        return;       
  }
   if(status == 5){
       _ajaxEventHandler("generateBill",{OrderID:eqorderid},commonres_forvendormethods,SHOW_LOADER,"POST","operation.php/v1/");
  }
 
    global_eqorderid = eqorderid;
    scheduledd_date = scheduled_date;
    OStatus = status;
    var scdate = scheduled_date.split("T"); 
    var endtime = scdate[1].split(".");
    var starttime = endtime[0].split(":");
    if(starttime[0]=="14"){
        starttime[0] = "10:00:00";
    }else if(starttime[0]=="18"){
        starttime[0] = "14:00:00";
    }else if(starttime[0]=="22"){
        starttime[0] = "18:00:00";
    }
    var _data = {
            order_id:eqorderid,
            actionById:sessionStorage.getItem("eqsu_user_id"),
            actionByName:sessionStorage.getItem("eqsu_user_name"),
            source:"CCO",
            latitude:$("#delivery_lat").val(),
            longitude:$("#delivery_lng").val(),
            status:status,
            scheduled_date:scdate[0],
            start_time:starttime[0],
            end_time:endtime[0],
            chiss_transaction_id:456434564576,
            role_id:1
        };
	
    console.log(_data);
   _ajaxEventHandler("order/change/status",_data,res_orderstatusChange,SHOW_LOADER,"POST","operation.php/v1/");	
}

//response of change orderstatus
function res_orderstatusChange(response){
    $(".loader").hide();
    console.log(OStatus);
    if(response.status=="1" || response.status==1){
        if(response.OStatus === 15){
            alert("Order Canclled Successfully");
            $(".close").click();
            $(".order_status_change1").html('') ;
       }else if(OStatus === 3){
            $(".order_status_change").html('<a href="#" class="print_invoice_btn" name = "inprogress" onclick="orderstatusChange(\''+global_eqorderid+'\',\''+scheduledd_date+'\',5)">Delivered</a>');
            $(".cancel_order").html('<a href="#" class="print_invoice_btn" name = "started" onclick="cancelorder_Popup(\'' + global_eqorderid + '\',\''+scheduledd_date+'\',15)">Cancel</a>'); 
       }else if(OStatus === 5){
           $(".order_status_change").html('<a href="#" class="print_invoice_btn" name = "completed" onclick="orderstatusChange(\''+global_eqorderid+'\',\''+scheduledd_date+'\',6)">Complete</a>' +
                                          '<div style="position: absolute; left: -98px; bottom: -85px;">'+
                                          '<input type="text" name="collected_amount" class="form-control" id="vendor_collected_amount" value="" placeholder="Enter collected amount...">'+
                                          '<input type="checkbox" name="" value="1" id = "amt_chkbox" >Amount Collected' +
                                          '</div>');
           $(".cancel_order").html('<a href="#" class="print_invoice_btn" name = "started" onclick="cancelorder_Popup(\'' + global_eqorderid + '\',\''+scheduledd_date+'\',15)">Cancel</a>');                                 
       }else if(OStatus === 6){
           $(".order_status_change").html('') ;
           $(".cancel_order").html('') ;
       }
        alert(response.message);
    }else{
       alert("Failed to update the order status");
    }
}

//order assigning and confirming by eqvendor
function assignlogisticsvendor(eqorderid,scheduled_date){
      var scdate = scheduled_date.split("T"); 
      var endtime = scdate[1].split(".");
      var starttime = endtime[0].split(":");
      if(starttime[0]=="14"){
           starttime[0] = "10:00:00";
      }else if(starttime[0]=="18"){
           starttime[0] = "14:00:00";
      }else if(starttime[0]=="22"){
           starttime[0] = "18:00:00";
      }
      var vendor_val=$('#logisticsvendor').val();
      if(vendor_val==''){
            alert("Please Select Logistics Vendor");
            return false;
       }
       global_eqorderid = eqorderid;
       var _data = {
            order_id:eqorderid,
            actionById:sessionStorage.getItem("eqsu_user_id"),
            actionByName:sessionStorage.getItem("eqsu_user_name"),
            source:"CCO",
            latitude:$("#delivery_lat").val(),
            longitude:$("#delivery_lng").val(),
            status:0,
            scheduled_date:scdate[0],
            start_time:starttime[0],
            end_time:endtime[0],
            chiss_transaction_id:456434564576,
            role_id:1
       };
         console.log(_data);	
        _ajaxEventHandler("order/change/status",_data,commonres_forvendormethods,SHOW_LOADER,"POST","operation.php/v1/");	
	
}

//order reject popup
function rejectorder_popup(eqorder_id){
        var header_data = "";
        var body_data = "";
        var footer_data ="";
	var item_rejectarray=[];
	$("input:checkbox:checked").map(function(){
              item_rejectarray.push($(this).val());
        });
	var length=item_rejectarray.length;
	if(length){
             header_data +='<h3 class="modal-title" style="width:300px;" id="myModalLabel">Are  you  sure  You Want to Reject  This Order. </h3>';      
             body_data +=
		'<div>'+
		'<select id="orderrejectreasons" style="width:550px;" required="">'+
                '<option value="Please select reason to reject">Please select reason to reject </option>'+
		'<option value="Some medicines ordered by you are currently unavailable">Some medicines ordered by you are currently unavailable </option>'+
		'<option value="Products ordered by you are currently unavailable">Products ordered by you are currently unavailable </option>'+
		'</select>'+
	        '<input type="hidden" value = '+eqorder_id+' id="reject_omorder_id" name="reject_omorder_id">'+
                '<input type="hidden" value = '+item_rejectarray+' id="reject_item_id" name="reject_item_id">'+
		'</div>';
               
            footer_data+=
            '<button type="button" class="btn btn-danger" data-dismiss="modal" onclick="rejectorder_submit()">Reject</button>';
        
            $("#myModalLabel").html(header_data);
            $("#trackresult").html(body_data);
            $("#modalfooter").html(footer_data);
            $("#Modal_for_all").modal("show");
		
      }else{
	alert("Please Select Equipment To Reject ");
      }
}

//rejecting order
function rejectorder_submit(){	
    var eqorder_id=$('#reject_omorder_id').val();
    var item_ids=$('#reject_item_id').val();
    var rejectreasons= $('#orderrejectreasons').val();
    var vendorid=sessionStorage.getItem('eqsu_user_id');
    var vendorname=sessionStorage.getItem('eqsu_user_name');
    var _data = {
        order_id:eqorder_id,
        item_id:[item_ids],
        rejectreasons:rejectreasons,
        vendorid:vendorid,
        vendorname:vendorname
    };
    global_eqorderid = eqorder_id;
    console.log(_data);
    $.ajax({
       url: "http://172.26.7.111/prakhar/OMS_main/OMS/api/operation.php/v1/reject_order", 
       type: "POST",
       data: JSON.stringify(_data),
       contentType: "application/json",
       success: commonres_forvendormethods		
   });
    //_ajaxEventHandler("rejectorder",_data,commonres_forvendormethods,SHOW_LOADER); 
	
	
}

//print CashMemo
function invoicedownload(eqorderid){
	window.location=RestServiceURL+'operation.php/v1/invoice?OrderID='+eqorderid; 
}
//Shippment lable
function shipmentlabeldownload(eqorderid){
	window.location=RestServiceURL+'operation.php/v1/shipment_lable?OrderID='+eqorderid;
}

//add log
function addLog_popup(eqorder_id){
      var header_data = "";
      var body_data = "";
      var footer_data="";
      var log_array=[];
      $("input:checkbox:checked").map(function(){
              log_array.push($(this).val());
        });
      var length =log_array.length;
      if(length){
          header_data +='<h3 class="modal-title" style="width:300px;" id="myModalLabel">Log the activity!!. </h3>';        
          body_data +=
                '<div class="modal-body">'+
		'<div>'+
		'<label>Log Info &nbsp;&nbsp;&nbsp;</label>'+
		'<input type="text" id="orderlogreasons" name="orderlogreasons" style="border:1px solid !important;width:500px;" required="required">'+
		'<input type="hidden" value = '+eqorder_id+' id="log_omorder_id" name="log_omorder_id">'+
                '<input type="hidden" value = '+log_array+' id="log_item_id" name="log_item_id">'+
		'</div>'+
                '</div>';
         footer_data+=
            '<button type="button" class="btn btn-primary" data-dismiss="modal" onclick="createLog()">Add Log</button>';
        
        $("#myModalLabel").html(header_data);
        $("#trackresult").html(body_data);
        $("#modalfooter").html(footer_data);
        $("#Modal_for_all").modal("show");

     }else{
	alert("Please Select Equipment To Log!");
     }
}

function createLog(){	
   var eqorder_id=$('#log_omorder_id').val();
   var item_ids=$('#log_item_id').val();
   var logreasons=$('#orderlogreasons').val();
   global_eqorderid = eqorder_id;
   if($.trim(logreasons)==''){
      alert('Kindly fill Log info!');
      return;
   }else{
     var _data = {
         omorder_id:parseInt(eqorder_id),
         item_ids:item_ids,
         rejectreasons:logreasons,
         vendorid:sessionStorage.getItem('eqsu_user_id'),
         vendorname:sessionStorage.getItem('eqsu_user_name'),
         role:"CCO" 
     };
     console.log(_data);
    _ajaxEventHandler("create_log",_data,commonres_forvendormethods,SHOW_LOADER);
  }
}

function res_logorder(response){
       console.log(response);
       alert(response);
       
       /*setTimeout(function(){ location.reload(); }, 1000);
	$(".loader").hide();
	$("#orderlogreasons").val("");
	$("#Modal_for_all").modal("hide");*/
}





















