var vendorList = 0;
var checkSum = '';
var selectedDrugsList = [];
var activeSection = 0;
var activeDrugSearch = false;
var currentReqt; 
var rowcount = 0;
var selecteddiag = '';
var selectedDrugDetails = [];
var mdmLineItemList = [];
var para_val_del = '';
var updateCategory = '';

function patient_search(searchType, searchText, records_per_page, pagenumber, responsefun) {
    records_per_page = records_per_page || 10;
    pagenumber = pagenumber || 1;
    responsefun = responsefun || 'patient_search_list';
    var _data = {searchType: searchType, searchText: searchText, records_per_page: records_per_page, pagenumber: pagenumber};
    _ajaxEventHandler("customerSearch", _data, responsefun, SHOW_LOADER);
    $("#patientsearchvalue").val(searchText);
    $("#patientsearchtype").val(searchType);
}

function open_patient_details() {
    var searchText = $("#patientsearchvalue").val();
    var searchType = $("#patientsearchtype").val();
    sessionStorage.setItem('orderMode', 'new');
    patient_search(searchType, searchText, 10, 1, cbk_open_patient_records);
}

function cbk_open_patient_records(response) {
    if (typeof response.status != "undefined" && response.status == 1){
		for(var i = 0; i < sessionStorage.length; i++){
			if (sessionStorage.key(i).substring(0,14) == 'new_drug_order') {
				sessionStorage.removeItem(sessionStorage.key(i));
			}
		}
		
        checkSum = '.splitOne';
        var Obj = response.data.customerList[0];
        //sessionStorage.setItem("patientid", ""); // required
        sessionStorage.setItem("name", Obj.salutation + " " + Obj.firstName + " " + Obj.lastName);
        sessionStorage.setItem("salutation", Obj.salutation);
        sessionStorage.setItem("patientfname", Obj.firstName);
        sessionStorage.setItem("patientlname", Obj.lastName);
        sessionStorage.setItem("patientmrn", Obj.mrn);
        //sessionStorage.setItem("mrn", Obj.mrn);
        //sessionStorage.setItem("displaygender", Obj.Gender);
        sessionStorage.setItem("patientgender", setgender(Obj.gender));
        sessionStorage.setItem("patientdob", Obj.dob);
        sessionStorage.setItem("age", age_calculation(sessionStorage.getItem("patientdob"))); // required
        sessionStorage.setItem("email", Obj.email);
        sessionStorage.setItem("contactno", Obj.mobile);
        sessionStorage.setItem("alternetcontactno", ""); // required
        sessionStorage.setItem("servicetype", "2");
        sessionStorage.setItem("TagName", Obj.tagsList.toString());
        //addressVal
        sessionStorage.setItem("area", Obj.defaultAddressDetails[0].areaVal);
        sessionStorage.setItem("landmark", Obj.defaultAddressDetails[0].landmark);
        sessionStorage.setItem("city", Obj.defaultAddressDetails[0].cityVal);
        sessionStorage.setItem("district", Obj.defaultAddressDetails[0].district);
        sessionStorage.setItem("state", Obj.defaultAddressDetails[0].stateVal);
        sessionStorage.setItem("country", Obj.defaultAddressDetails[0].countryVal);
        sessionStorage.setItem("zipcode", Obj.defaultAddressDetails[0].zipcodeVal);
        sessionStorage.setItem("longitude", Obj.defaultAddressDetails[0].lngVal);
        sessionStorage.setItem("latitude", Obj.defaultAddressDetails[0].latVal);
		
        sessionStorage.setItem("address_id", Obj.defaultAddressDetails[0].addressId);
        sessionStorage.setItem("address_type_id", Obj.defaultAddressDetails[0].addressType);
        sessionStorage.setItem("address_nickname", Obj.defaultAddressDetails[0].addressNickName);
        var address = Obj.defaultAddressDetails[0].addressVal + ", " +
		Obj.defaultAddressDetails[0].areaVal + ", " +
		Obj.defaultAddressDetails[0].cityVal + ", " +
		Obj.defaultAddressDetails[0].stateVal + ", " +
		Obj.defaultAddressDetails[0].countryVal + ", " +
		Obj.defaultAddressDetails[0].zipcodeVal;
        sessionStorage.setItem("address", address);
		sessionStorage.setItem("walletstatus","0")

        //remain
        sessionStorage.setItem("ordersmscreate", "0");
        sessionStorage.setItem("doctorid", "");
        sessionStorage.setItem("doctorname", "");
		
        $("#address1").val(sessionStorage.getItem('address'));
        $("#locality").val(sessionStorage.getItem('city'));
        $("#administrative_area_level_1").val(sessionStorage.getItem('state'));
        $("#route").val(sessionStorage.getItem('district'));
        $("#postal_code").val(sessionStorage.getItem('zipcode'));
        $("#autocomplete").val(sessionStorage.getItem('landmark'));
        $("#popname").val(sessionStorage.getItem('popname'));
        $("#popid").val(sessionStorage.getItem('facility_id'));
        $("#latitude").val(sessionStorage.getItem('latitude'));
        $("#longitude").val(sessionStorage.getItem('longitude'));
        $("#pcontactno").val(sessionStorage.getItem('contactno'));
        $("#alcontactno").val(sessionStorage.getItem('alternetcontactno'));
		
        render_actiontab_for_mrn(); //pharma_widgets();
        renderBanner();
        renderorderHeader();
        cbk_open_patient_orders({countn: 0});
        renderCreateOrder();
        //timeslotselect();
    } else {
        //console.log('sfsdfs');
        render_actiontab_for_mrn(); //pharma_widgets();
        renderBanner();
        renderorderHeader();
        cbk_open_patient_orders({countn: 0});
        renderCreateOrder();
    }
}

//open the order tab with and without order id
function cbk_open_patient_orders(response) {
    $(".loader").hide();
    sessionStorage.setItem("orderstatuscurorder", "");
    sessionStorage.setItem("encounterid", "");
    sessionStorage.setItem("source_of_referral", "");
    sessionStorage.setItem("prescription_file_length", "0");
    _ajaxEventHandler("getsource_of_referral", "", cbk_getsource_of_referral,'');	
    //console.log(response);
	if (response.countn < 1) {
		renderCreateOrder(response);
	}    
    var _datamrn = {"mrn": sessionStorage.getItem("patientmrn")};
    //check mrn is related to corporate or not.
    sessionStorage.setItem("mrncoporateid", "");
    sessionStorage.setItem("mrncoporatename", "");
	_ajaxEventHandler("get_customer_type", _datamrn,cbk_get_customer_type);
    if (response.countn > 0) {
		//$(".selecttimeslot").css("display","none");
		//alert();
		//console.log(response);
		//$("#timeslot").html("display",response.data.order.patientinfo.scheduled_date);
		
		//$("#").
        /*var completeOrderDetails = response.data;
        var orderDetails = completeOrderDetails.order;
        var patientinfo = orderDetails.patientinfo;
        sessionStorage.setItem("doctorid", ((typeof patientinfo.doctorid != 'undefined') ? patientinfo.doctorid : ""));
        sessionStorage.setItem("doctorid", ((typeof patientinfo.doctorid != 'undefined') ? patientinfo.doctorid : ""));
        sessionStorage.setItem("doctorname", ((typeof patientinfo.doctorname != 'undefined') ? patientinfo.doctorname : ""));
        var orderstatus = (typeof (patientinfo.order_status) == "undefined") ? " " : patientinfo.order_status;
        sessionStorage.setItem("orderstatuscurorder", orderstatus);
        var vendor_id = (typeof orderDetails.vendorinfo != 'undefined') ? orderDetails.vendorinfo.VendorCode : "0";
        //ezeetab
        var ezeetab = (typeof (patientinfo.ezzetab_sms) == "undefined") ? "" : patientinfo.ezzetab_sms;
        sessionStorage.setItem("ezzetab_sms", ezeetab);
        var encid = (typeof (patientinfo.encid) == "undefined") ? "" : patientinfo.encid;
        var service_subtype = (typeof (patientinfo.service_subtype) == "undefined") ? " " : patientinfo.service_subtype;
        var ordersmscreate = (typeof (patientinfo.ordersmscreate) == "undefined") ? "0" : patientinfo.ordersmscreate;
        sessionStorage.setItem("ordersmscreate", ordersmscreate);
        sessionStorage.setItem("placedfromdoctorplace", (typeof (patientinfo.placedfromdoctorplace) == "undefined") ? "0" : patientinfo.placedfromdoctorplace);
        //counpon
        if ($.trim(patientinfo.coupon) != "") {
            $("#l2vCoupanCode").val($.trim(patientinfo.coupon));
            $("#l2vCoupanCode").attr($.trim(patientinfo.couponitem));
        }
        if (encid != "" && orderstatus != "6") {
            $("#orderfrom").html("| SubType - " + service_subtype);
            sessionStorage.setItem("encounterid", encid);
            sessionStorage.setItem("orderstatusencounterid", orderstatus);
            $("#l2vopenprescriptionmadal").show();
            $("#checkboxprescriptionsms").hide();
            $("#checkboxprescriptionsmsname").hide();
            getECpriscription(sessionStorage.getItem("mrn"));
        } else if (orderstatus != "6") {
            sessionStorage.setItem("encounterid", "");
            sessionStorage.setItem("orderstatusencounterid", "");
            $("#orderfrom").html("");
        } else if (orderstatus == "6") {
            var ezeetab = "";
            sessionStorage.setItem("encounterid", "");
            sessionStorage.setItem("orderstatusencounterid", "");
            $("#orderfrom").html("");
            sessionStorage.setItem("ezzetab_sms", ezeetab);
            $("#l2vCoupanCode").val($.trim(""));
            $("#l2vCoupanCode").attr($.trim(""));
            vendor_id = "0";
            $("#l2vCoupanCode").val("");
            $("#l2vCoupanCode").attr("");
            sessionStorage.setItem("placedfromdoctorplace", "0");
        }
        vendor_id = $.trim(vendor_id);
        $("#vendorname").val(vendor_id);

        //Set workorder details
        sessionStorage.setItem("orderwid", ((typeof (Obj.itemlist.order_status.workorder_id) == "undefined") ? " " : Obj.itemlist.order_status.workorder_id));
        sessionStorage.setItem("orderwdid", ((typeof (Obj.itemlist.order_status.workorder_did) == "undefined") ? " " : Obj.itemlist.order_status.workorder_did));

        var lead_id = ((typeof (Obj.itemlist.patientinfo.lead_id) == "undefined") ? "" : Obj.itemlist.patientinfo.lead_id);
        var callNumber = ((typeof (Obj.itemlist.patientinfo.callNumber) == "undefined") ? "" : Obj.itemlist.patientinfo.callNumber);
        if ($.trim(lead_id) != "") {
            sessionStorage.setItem("lead_id", lead_id);
        }
        if ($.trim(callNumber) != "") {
            sessionStorage.setItem("callNumber", callNumber);
        }
        //End workorder details

        var address = (typeof (Obj.itemlist.patientinfo.address) == "undefined") ? " " : Obj.itemlist.patientinfo.address;
        var state = (typeof (Obj.itemlist.patientinfo.state) == "undefined") ? " " : Obj.itemlist.patientinfo.state;
        var city = (typeof (Obj.itemlist.patientinfo.city) == "undefined") ? " " : Obj.itemlist.patientinfo.city;
        var area = (typeof (Obj.itemlist.patientinfo.area) == "undefined") ? " " : Obj.itemlist.patientinfo.area;
        var pincode = (typeof (Obj.itemlist.patientinfo.pincode) == "undefined") ? " " : Obj.itemlist.patientinfo.pincode;
        var landmark = (typeof (Obj.itemlist.patientinfo.landmark) == "undefined") ? " " : Obj.itemlist.patientinfo.landmark;
        var popname = (typeof (Obj.itemlist.patientinfo.popname) == "undefined") ? " " : Obj.itemlist.patientinfo.popname;
        var popid = (typeof (Obj.itemlist.patientinfo.facility_id) == "undefined") ? " " : Obj.itemlist.patientinfo.facility_id;
        var pcontactno = (typeof (Obj.itemlist.patientinfo.contactno) == "undefined") ? "" : Obj.itemlist.patientinfo.contactno;
        var alcontactno = (typeof (Obj.itemlist.patientinfo.alternetcontactno) == "undefined") ? "" : Obj.itemlist.patientinfo.alternetcontactno;
        sessionStorage.setItem("popname", popname);
        sessionStorage.setItem("facility_id", popid);
        var delivery_lat = (typeof (Obj.itemlist.patientinfo.delivery_lat) == "undefined") ? " " : Obj.itemlist.patientinfo.delivery_lat;
        var delivery_lng = (typeof (Obj.itemlist.patientinfo.delivery_lng) == "undefined") ? " " : Obj.itemlist.patientinfo.delivery_lng;
        if ($.trim(address) != "") {
            $("#address1").val(Obj.itemlist.patientinfo.address);
        }
        if ($.trim(state) != "") {
            $("#administrative_area_level_1").val(Obj.itemlist.patientinfo.state);
        }
        if ($.trim(city) != "") {
            $("#locality").val(Obj.itemlist.patientinfo.city);
        }
        if ($.trim(area) != "") {
            $("#route").val(Obj.itemlist.patientinfo.area);
        }
        if ($.trim(pincode) != "") {
            $("#postal_code").val(Obj.itemlist.patientinfo.pincode);
        }
        if ($.trim(landmark) != "") {
            $("#autocomplete").val(Obj.itemlist.patientinfo.landmark);
        }
        if ($.trim(popname) != "") {
            $("#popname").val(Obj.itemlist.patientinfo.popname);
        }
        if ($.trim(popid) != "") {
            $("#popid").val(Obj.itemlist.patientinfo.facility_id);
        }
        if ($.trim(delivery_lat) != "") {
            $("#latitude").val(Obj.itemlist.patientinfo.delivery_lat);
        }
        if ($.trim(delivery_lng) != "") {
            $("#longitude").val(Obj.itemlist.patientinfo.delivery_lng);
        }
        if ($.trim(pcontactno) != "") {
            $("#pcontactno").val(Obj.itemlist.patientinfo.contactno);
        }
        if ($.trim(alcontactno) != "") {
            $("#alcontactno").val(Obj.itemlist.patientinfo.alternetcontactno);
        }
        //check pin no
        populatepopsetailsbypin(Obj.itemlist.patientinfo.pincode);
        // for show #showdelvpop - pop name		
        $("#showdelvpop").html($("#popname").val());
        $("#showdelvaddress").html($("#address1").val() + " " + $("#administrative_area_level_1").val() + " " + $("#locality").val() + " " + $("#route").val() + " " + $("#postal_code").val());

        if ((typeof (Obj.itemlist.patientinfo.payment_method) != "undefined") && Obj.itemlist.patientinfo.payment_method != null) {
            $("#payment_method").val('' + Obj.itemlist.patientinfo.payment_method);
        } else {
            $("#payment_method").val("0");
        }
        var prescription_file = (typeof (Obj.itemlist.prescription_file) == "undefined") ? "0" : Obj.itemlist.prescription_file;
        if (prescription_file.length == 0 || prescription_file == "0") {
            if (sessionStorage.getItem("encounterid") == "") {
                $("#l2vopenprescriptionmadal").hide();
            }
            sessionStorage.setItem("prescriptionobj", "");
        } else {
            if (orderstatus == "6") {
                $("#l2vopenprescriptionmadal").hide();
                sessionStorage.setItem("prescriptionobj", "");
            } else {
                $("#l2vopenprescriptionmadal").show();
                sessionStorage.setItem("prescriptionobj", prescription_file);
            }
        }
        if (typeof prescription_file.length != "undefined" && prescription_file.length != null) {
            sessionStorage.setItem("prescription_file_length", prescription_file.length);
        } else {
            sessionStorage.setItem("prescription_file_length", "0");
        }

        //refer ans source of referal
        var referedby = (typeof (Obj.itemlist.patientinfo.referedby) == "undefined") ? "" : Obj.itemlist.patientinfo.referedby;
        var referred_mrn = (typeof (Obj.itemlist.patientinfo.referred_mrn) == "undefined") ? "" : Obj.itemlist.patientinfo.referred_mrn;
        var source_of_referral = (typeof (Obj.itemlist.patientinfo.source_of_referral) == "undefined") ? "" : Obj.itemlist.patientinfo.source_of_referral;
        sessionStorage.setItem("source_of_referral", source_of_referral);
        $("#l2vreferby").val($.trim(referedby));
        if ($.trim(referedby) != "9999") {
            $("#referedbylist").html('<option value="9999">9999</option><option value="' + $.trim(referedby) + '">' + $.trim(referedby) + '</option>');
        }
        $("#l2vsreferbymrn").val($.trim(referred_mrn));

        //wallet
        var walletstatus = (typeof (Obj.itemlist.patientinfo.walletstatus) == "undefined") ? "0" : Obj.itemlist.patientinfo.walletstatus;
        if (walletstatus == "1" && (orderstatus != "6")) {
            var walletamt = (typeof (Obj.itemlist.patientinfo.wallet_amount) == "undefined") ? "0" : Obj.itemlist.patientinfo.wallet_amount;
            sessionStorage.setItem("walletstatus", walletstatus);
            $("#l2vwalletbutton").hide();
            $("#l2vitemwalletamount").html(walletamt);
        } else {
            sessionStorage.setItem("walletstatus", "0");
            $("#l2vwalletbutton").show();
            if (orderstatus != "6") {
                walletstatus = "0";
                sessionStorage.setItem("walletstatus", walletstatus);
            }
        }
        //scheduled date
        var secheduledate = Obj.itemlist.patientinfo.scheduled_date.split("T");
        var secheduletime = secheduledate[1].split(":");
        if (orderstatus != "6") {
            settimeslot(secheduledate[0], secheduletime[0]);
        } else {
            $(checkSum).find("#mainorderdate").val(tommorowDate());
            settimeslot();
        }
        if (typeof (Obj.itemlist.prepayment) != "undefined") {
            $("#l2vprepaidamount").html(Obj.itemlist.prepayment.amount);
        }
        newCheckpricefrommdm();*/
    } else {
        if ($.trim(sessionStorage.getItem("encounterid")) != "") {
            $("#l2vopenprescriptionmadal").show();
        } else {
            $("#l2vopenprescriptionmadal").hide();
        }
        sessionStorage.setItem("walletstatus", "0");
        newCheckpricefrommdm();
    }
    getwalletamt();
}

// Wallet //
function getwalletamt(){
	var _datamrn = {"mrn": sessionStorage.getItem("patientmrn")};
	_ajaxEventHandler("getwalletamt", _datamrn, cbk_getwalletamt,'');
}

function cbk_getwalletamt(res) {
    //console.log(res);
    if (res.status == 1) {
        var walletamount = res.amount;
        walletamount = parseFloat(walletamount.replace(/,/g,"")).toFixed(2);		
        sessionStorage.setItem("walletamount", walletamount);
		$("#l2vwalletamt").html(walletamount);
		//$(".l2vwalletamt").html(walletamount);
    } else {
        $("#l2vwalletamt").html(0);
		//$(".l2vwalletamt").html(0);
        sessionStorage.setItem("walletamount", 0);
    }
    $(".loader").hide();
}
// End Wallet //

function cbk_getsource_of_referral(data) {
    var obj = '';
    if (typeof data == 'string') {
        obj = JSON.parse(data);
    } else {
        obj = data;
    }
    var str = "<option value=''>Choose refferal source</option>";
    if (obj.status == 1 || obj.status == '1') {
        $.each(obj.data, function (key, val) {
            str += "<option value='" + $.trim(val.name) + "'>" + $.trim(val.name) + "</option>";
        });
    }
    $("#l2vsourcereferral").html(str);

    if (sessionStorage.getItem("source_of_referral") != "") {
        var referral = sessionStorage.getItem("source_of_referral");
        //console.log($('#l2vsourcereferral').html());
        //console.log(referral);
        $('#l2vsourcereferral').val($.trim(referral));
    }
}

function cbk_get_customer_type(res){
    if (res.status === "0"){
		sessionStorage.setItem("mrncoporateid","");
        sessionStorage.setItem("mrncoporatename","");        
    }else {
        if (typeof res.data != "undefined") {
            sessionStorage.setItem("mrncoporateid", res.data.ID);
            sessionStorage.setItem("mrncoporatename", res.data.name);
        }
    }
	$(".loader").hide(); 
}

//function callallorder(){
function get_allorder() {
    dashboard_widgets_render();
    dashboard_search_render();
    $("#fromdate").val(todayDate());
    $("#todate").val(todayDate());
    $('#l2search').attr('onclick', 'callallorder1()');
    var formdate = $("#fromdate").val();
    var todate = $("#todate").val();
    var city = $("#city").val();
    var status = $("#status_serach").val();
    var _data = {city: city, formdate: formdate, todate: todate, status: status};
    _ajaxEventHandler("all_orders", _data, allordersview, SHOW_LOADER);
}

function getwidgetCount() {
    //renderWidgets();
    dashboard_widgets_render();
    $(".loader").hide();
}

function allOrders(ajaxMethod, SuccessFn, withSearch, skip, pagination) {
    //console.log(pagination);
    withSearch = withSearch || false;
    ajaxMethod = ajaxMethod || false;
    pagination = pagination || false;
    skip = skip || '1';
    sessionStorage.setItem("ajaxMethod", ajaxMethod);
    sessionStorage.setItem("SuccessFn", SuccessFn);
    sessionStorage.setItem("withSearch", withSearch);
    sessionStorage.setItem("pagination", pagination);
    sessionStorage.setItem("skip", skip);
    var searchFn = 'allOrders("' + ajaxMethod + '","' + SuccessFn + '",' + true + ',1,' + pagination + ')';
    if (withSearch === false) {
        dashboard_search_render();
        $("#fromdate").val(todayDate());
        $("#todate").val(todayDate());
        if (ajaxMethod == 'all_orders') {
            getwidgetCount();
        }
    }
    $('#l2search').attr('onclick', searchFn);
    var formdate = $("#fromdate").val();
    var todate = $("#todate").val();
    var city = $("#city").val();
    var status = $("#status_serach").val();
    var orderidser = $("#orderid_search").val();

    if (new Date(formdate) > new Date(todate)) {
        alert("Todate greater than  Form Date");
        return false;
    }
    var _data = {city: city, formdate: formdate, todate: todate, status: status};

    if ((ajaxMethod == 'rx_not_upload')) {
        $("#todate").attr("disabled", "disabled");
        $("#fromdate").attr("disabled", "disabled");
        $("#status_serach").attr("disabled", "disabled");
        var _data = {city: city};
    }

    if (ajaxMethod == 'reminder_request') {
        $("#status_serach").attr("disabled", "disabled");
        $("#city").attr("disabled", "disabled");
        _data = {};
    }
    _data.customsearch = false;
    if (withSearch === true) {
        _data.orderidser = orderidser;
        if (ajaxMethod == 'rx_not_upload') {
            var _data = {city: city, orderidser: orderidser};
        }

        if (ajaxMethod == 'reminder_request') {
            var _data = {formdate: formdate, todate: todate};
        }

        _data.customsearch = true;
    }
    _data.pagination = true;
    _data.skip = skip;
    _data.limit = 10;
    //console.log(SuccessFn);
    _customeDataTable(_data, ajaxMethod, SuccessFn, SHOW_LOADER)
}

function _customeDataTable(_data, ajaxMethod, SuccessFn, showLoader) {
    showLoader = showLoader || 1;
    if (showLoader == '1') {
        $(".loader").show();
    }
    _data.method = ajaxMethod;
    _data.type = "l2pharma";
    //var url = baseRestUrl+medicineSupplyUrl+'getMedOrdersByFilter';
    var url = RestServiceURL+medicineSupplyUrl+'getMedOrdersByFilter';
    $("#Custom_body").customeDataTable({
        data: _data,
        orderby: 0,
        actionurl: url,
        actiontype: "POST",
        tableprepare: SuccessFn,
        pagination: _data.pagination,
        perpage: _data.limit,
        customsearch: _data.customsearch
    });
    $(".loader").hide();
}

//search the medicine item
/*function loaddruglist(id) {
    var str = $('#' + id).val();
    var listid = $('#' + id).attr('list');
    var l2type = "medicine";
    if (str.length <= 0) {
        return false;
    }
    var dataList = $('.data-search-select').find('.data_druglist [value="' + str + '"]');
    if (dataList.length <= 0) {
        if (str.length > 3) {
            //console.log(activeDrugSearch);
            if (activeDrugSearch) {
                currentReqt.abort();
            }
            activeDrugSearch = true;			
            var _data = {"filtercolumn":"name","brandname": str,"listid": listid,"entitytype":l2type};
			currentReqt= _ajaxEventHandler("search_item",_data,cbk_loaddruglist, SHOW_LOADER);
        }
    } else {
        selectDrug('drugsearch');
    }
    $(".loader").hide();
}*/

//search the medicine item
function loaddruglist(id) {
	var str = $('#' + id).val();
	var listid = $('#' + id).attr('list');
	var l2type = "medicine";
	if (str.length <= 0) {
		return false;
	}
	var dataList = $('.data-search-select').find('.data_druglist [value="' + str + '"]');
	if (dataList.length <= 0) {
		if (str.length > 3) {
		//console.log(activeDrugSearch);
			if (activeDrugSearch) {
				currentReqt.abort();
			}
			activeDrugSearch = true;
			var _data = {"filtercolumn": "name", "brandname": str, "listid": listid, "entitytype": l2type};
			_ajaxEventHandler("search_item", _data, cbk_loaddruglist, SHOW_LOADER);
		}
	} else {
		$this = $('#drugsearch');
		selecteddiag = $('#drugsearch').val();
		if ($.inArray(selecteddiag, selectedDrugsList) > - 1) {
			alert('Same item cannot be ordered two times');
			$('#drugsearch').val('');
			return;
		}

		var datalist = $('.data-search-select').find('.data_druglist [value="' + selecteddiag + '"]');
		var drugCategory = datalist.data('category');
		console.log(updateCategory);
		if(updateCategory != ''){
			if (($.inArray(drugCategory, splitone) > - 1) && (updateCategory != 'splitone')) {
				alert('Another category item can`t be selected');
				$('#drugsearch').val('');
				return;
			}else if(($.inArray(drugCategory, splittwo) > - 1) && (updateCategory != 'splittwo')){
				alert('Another category item can`t be selected');
				$('#drugsearch').val('');
				return;
			}
		}

		selectedDrugsList.push(selecteddiag);
		var orderGlobalDetails = splitOrderGlobalDetails();
		newCheckpricefrommdm(selecteddiag);
		updateSplitOrderDetails(orderGlobalDetails)
		//  selectDrug('drugsearch');
	}
	$(".loader").hide();
}

function cbk_loaddruglist(response) {
	activeDrugSearch = false;
    if (typeof response === 'string') {
        var Obj = JSON.parse(response);
    } else {
        var Obj = response;
    }
    var listid = Obj.listid;
    var druglists = "";
    var objData = Obj.data;
    if (Obj.status === 1) {
        $i = 1;
        for (var key in objData) {
            $i++;
            var pharmaname = objData[key].molecularNames;
            druglists += '<option '+
			'data-codedid="' + objData[key].code + '" '+
			'data-id="' + objData[key].ID + '" '+			
			'data-prescribed="' + objData[key].prescribed + '" '+
			'data-category="' + objData[key].categoryID + '" '+
			'value="' + objData[key].name + '" '+
			'data-minQuantity="' + objData[key].minQuantity + '" '+
			'data-maxQuantity="' + objData[key].maxQuantity + '" '+
			'data-manufacturerid="' + objData[key].manufacturerID + '" '+
			'data-packsize="' + objData[key].packSize + '" '+
			'data-manufacturer="' + objData[key].manufacturer + '">';
            //console.log(druglists);
        }
        $('#' + listid).html(druglists);
        //console.log(druglists);
    } else {
        //alert(Obj.message);
        $('#drugsearch').val('');
    }
    $(".loader").hide();
}

function newCheckpricefrommdm(selecteddiag) {
	selecteddiag = selecteddiag || false;
	var coupon = "";
	var orderDate = todayDateforMDM();
    if ($.trim($("#l2vCoupanCode").attr("data-code")) == "") {
        coupon = $("#l2vCoupanCode").val();
	}
	var business = "2";
	var source = "CCO";
	if (sessionStorage.getItem("channel") !== null && sessionStorage.getItem("channel") !== "") {
		source = channel[parseInt(sessionStorage.getItem("channel"))];
	}

	var lineitems = [];
	var mrnno = sessionStorage.getItem("patientmrn");
	// var itemarray = $("#l2vCoupanCode").attr("data-code").split(',');
	$('input[name=drugsearch]').each(function () {
		$rowId = $(this).parents('tr').attr('id');
		$splitOrderId = $(this).attr('data-split');
		if ($.trim($(this).val()) !== "") {
			$drugName = $(this).val();
			var codedata = $(this).attr('data-codedid');
			if ((typeof codedata !== "undefined") && codedata !== "" && codedata !== "0") {
				/* var couponitem = "";
				if (jQuery.inArray(codedata, itemarray) !== -1) {
				couponitem = $("#l2vCoupanCode").val();
				} */
				lineitems.push({
					orderDate: orderDate,
					business: business,
					code: codedata,
					sessions: $('.'+$splitOrderId).find("#"+$rowId+' input[name="quantity"]').val(),
					source: source,
					mrn: mrnno,
					engage_at: '1',
					zipcode: sessionStorage.getItem('zipcode')
				});
			}
        }
    });
    if (selecteddiag) {
        var datalist = $('.data-search-select').find('.data_druglist [value="' + selecteddiag + '"]');
		selectedDrugDetails.push({
			id : datalist.data('id'),
			codedid : datalist.data('codedid'),
			pharma : datalist.data('pharma'),
			prescribed : datalist.data('prescribed'),
			category : datalist.data('category'),
			manufacturerid : datalist.data('manufacturerid'),
			manufacturer : datalist.data('manufacturer'),
			packsize : datalist.data('packsize'),
			priceperunit : datalist.data('priceperunit')
		});
		lineitems.push({
		orderDate: orderDate,
				business: business,
				code: datalist.data('codedid'),
				sessions: '1',
				source: source,
				mrn: mrnno,
				engage_at: '1',
				zipcode: sessionStorage.getItem('zipcode')
		});
	}
	console.log(lineitems); //return false;
   
	var walletstatus = sessionStorage.getItem("walletstatus");
	var _data = {
		method: "domain/Order",
		type: "POST",
		orderDate: orderDate,
		source: source,
		coupon: coupon,
		useWallet: "false",
		LineItems: lineitems
	};
	if (($("#applywallet").prop('checked') == true) && (parseInt(walletstatus) != 1)) {
		_data.useWallet = "true";
	}
	console.log(_data);
	_ajaxEventHandler("checkpricefrommdm", _data, prepare_body_checkpricefrommdm, SHOW_LOADER);
}

function prepare_body_checkpricefrommdm(response) {
	var orederHtmlBody = '';
	var countitem = 0;
	var coupon = $("#l2vCoupanCode").val();
	if (typeof response == 'string') {
        var Obj = JSON.parse(response);
    } else {
        var Obj = response;
    }
	
	// Obj = response;
	var walletstatus = sessionStorage.getItem("walletstatus");
	if (Obj.status === 1) {
		var objData = Obj.data;
		mdmLineItemList = objData.lineItemList;
		var htmlData = prepareOrder(objData, selectedDrugDetails);
		sessionStorage.setItem('associate_id',$('#vendorname').val());
		$("#split-order").html(htmlData);
		var _dataforvendor = {"systemType": "l2pharma"};
		_ajaxEventHandler("vendor_list", _dataforvendor, cbk_setvendorinselecttag, '');
	}
	$('#drugsearch').val('');
	$(".loader").hide();
}
                
                
function splitOrderGlobalDetails(para_val_del,rowIndex){
    para_val_del = para_val_del || false;
    rowIndex = rowIndex || false;
    var splitOrderDetails = [];
    if($('.new-order-by-category').length < 0){
        return false;
    }
    $('.new-order-by-category').each(function(){
		var currentCheckSum = $(this).attr('data-sectionid');
		var currentRowIndex = '#rowdrug-1';
		if ((currentCheckSum == para_val_del) && (rowIndex == currentRowIndex)){
			currentRowIndex = '#rowdrug-2';
		}
		console.log(currentCheckSum);

		splitOrderDetails.push({
			itemName :  $('.' + currentCheckSum).find(currentRowIndex).find('input[name="drugsearch"]').val(),
			splitName : (typeof $(this).attr('data-sectionid') != 'undefined') ? $(this).attr('data-sectionid') : '',
			timeslot : (typeof $(this).find('.timeslot').attr('data_trasactionid') != 'undefined') ? $(this).find('.timeslot').attr('data_trasactionid') : '',
			timestart : (typeof $(this).find('.timeslot').attr('data_starttime') != 'undefined') ? $(this).find('.timeslot').attr('data_starttime') : '',
			timesend : (typeof $(this).find('.timeslot').attr('data_endtime') != 'undefined') ? $(this).find('.timeslot').attr('data_endtime') : '',
			timeDate : (typeof $(this).find('.timeslot').attr('data_date') != 'undefined') ? $(this).find('.timeslot').attr('data_date') : '',
			vendorname : $(this).find('#vendorname').val()
		});
	});
	console.log(splitOrderDetails);
	return splitOrderDetails;
}  

function updateSplitOrderDetails(orderGlobalDetails){    
    if(orderGlobalDetails == false){
        return false;
    }
	setTimeout(function(){
		console.log('----S----');
		console.log(orderGlobalDetails);
		console.log('----E----');
		if(sessionStorage.getItem('orderMode') == 'new'){
			$('.new-order-by-category').each(function(){
				var currentCheckSum = '.' + $(this).attr('data-sectionid');
				console.log(currentCheckSum);
				var splitOrderData = orderGlobalDetails.filter(function(item){
				return ($(currentCheckSum).find('input[value="' + item.itemName + '"]').length > 0);
				});
				splitOrderData = splitOrderData[0];
				console.log(splitOrderData);
				if(typeof splitOrderData !== 'undefined'){
					var timeSlot = splitOrderData.timeDate + ' ' + splitOrderData.timesend;
					$(currentCheckSum).find('#vendorname').val(splitOrderData.vendorname);
					$(currentCheckSum).find('.timeslot').html(timeSlot);
					$(currentCheckSum).find('.timeslot').attr({
						'data_starttime' : splitOrderData.timestart,
						'data_endtime' : splitOrderData.timesend,
						'data_date' : splitOrderData.timeDate,
						'data_trasactionid' : splitOrderData.timeslot
					});					
				}
			});
		}
	},1500);
}

function showcoupon(){
	$("#couponlistmodal").modal("show");
	var orderDate=todayDateforMDM();
	var orderlevel=[];
	var itemlevel=[];
	orderlevel.push({
		orderDate: orderDate,
		pop: sessionStorage.getItem('facility_id'),
		business: "2",
		source: "CCO",
		mrn: sessionStorage.getItem('mrn'),
		cartCoupon:"1"
	});
	$('#Custom_body input[name=drugsearch]').each(function() {
		if($.trim($(this).val())!=""){	
			if(isNaN(parseInt($(this).attr("id").match(/\d+/g),10))){	var num="";	}
			else{	var num = parseInt($(this).attr("id").match(/\d+/g),10);	}
			var codedata = ''+((typeof ($('#druglist'+num+' [value="'+$("#drugsearch"+num).val()+'"]').data('codedid')) == "undefined")?$('input[value="'+$("#drugsearch"+num).val()+'"]').data('codedid'):($('#druglist'+num+' [value="'+$("#drugsearch"+num).val()+'"]').data('codedid')));
			if((typeof codedata != "undefined") && codedata!="" && codedata!="0"){				
				itemlevel.push({
					orderDate: orderDate,
					pop: sessionStorage.getItem('facility_id'),
					business: "2",
					code: codedata,
					source: "CCO",
					mrn: sessionStorage.getItem('mrn')
				});
			}			
		}		
	});
	var _data = {orderlevel:orderlevel,itemlevel:itemlevel};
	_ajaxEventHandler("coupenlist_all",_data,coupenlist_all_fun,NO_SHOW_LOADER);
}

function coupenlist_all_fun(data){
	var obj =JSON.parse(data);
	var str='';
	var i=0;
	$.each(obj,function(key,val){		
		i = i + 1;
		var codes="";
		console.log(val.name);
		$.each(val.code,function(key,valco){
			if(codes!=""){
				codes+=",";
			}
			codes+=valco;
		});
		str+='<tr><td>'+val.name+'</td><td>'+val.description+'</td><td><button data-id="'+val.name+'" class="btn btn-success" data-code="'+codes+'" onclick="copycoupon('+i+');" id="couponlistbtn'+i+'">Apply</button></td></tr>';
	});	
	$("#couponlist").html(str);
}  

function removecoupen() {
	$("#l2vCoupanCode").val("");
	$("#l2vCoupanCode").attr("data-code","");
	showcoupenmmsg=2;
        var orderGlobalDetails = splitOrderGlobalDetails();
        newCheckpricefrommdm();
        updateSplitOrderDetails(orderGlobalDetails);
}

function itemcancel(itemCode,orderId){
    $('#itemCancelOrderId').val(orderId);
    $('#itemCancelItemCode').val(itemCode);
    $('#itemCancelModel').modal('show');
}

var itemCancelOrderId = '';
function itemCancelSubmit(){
    $('#itemCancelReason_error').hide();
    if($('#itemCancelReason').val() == ''){
        $('#itemCancelReason_error').show();
        return false;
    }
    $('#itemCancelModel').hide();
    itemCancelOrderId = $('#itemCancelOrderId').val();
    var _data = {
                "order_id": $('#itemCancelOrderId').val(),
                "item_code": $('#itemCancelItemCode').val(),
                "cancel_reason": $('#itemCancelReason').val(),
                "actionById": sessionStorage.getItem("loginid"),
                "actionByName": sessionStorage.getItem("loginname")
                };
	_ajaxEventHandler("orders/lineitem/cancel",_data,cbk_item_cancel,SHOW_LOADER);
}

function cbk_item_cancel(response){
    alert('Item Cancelled Successfully');
    $('#viewOrder').hide();
    vieworder(itemCancelOrderId);
}






function selectDrug(id) {
    $this = $('#' + id);
    var pop = sessionStorage.getItem('facility_id');
    /*if (pop == "" || pop == 0 || pop == "0") {
        alert('Non serviceable area, Please update Address with Proper POP Name.');
        $this.val('');
        return;
    }*/

    var selecteddiag = $this.val();
    if ($.inArray(selecteddiag, selectedDrugsList) > -1) {
        alert('Same item cannot be ordered two times');
        $this.val('');
        return;
    }
	
    selectedDrugsList.push(selecteddiag);
    //console.log(selecteddiag);
    var datalist = $('.data-search-select').find('.data_druglist [value="' + selecteddiag + '"]');
    //console.log(datalist.length);
    //console.log(datalist.data('mrp'));
    var s_mrp = parseFloat(datalist.data('mrp')).toFixed(2);
    var brand = datalist.data('brand');
    var codedid = datalist.data('codedid');
    var discountAmount = datalist.data('discountamount');
    var netAmount = datalist.data('netamount');
    var pharmaname = datalist.data('pharma');
    var prescribed = datalist.data('prescribed');
    var category = '';
    var categoryId = datalist.data('category');
    var manufacturerId = datalist.data('manufacturerid');
    var manufacturer = datalist.data('manufacturer');
    var packsize = datalist.data('packsize');
    var id = datalist.data('id');
    var priceperunit = datalist.data('priceperunit');
    var sectionId = 'new-drug-order-' + manufacturerId;
	if(jQuery.inArray(categoryId, splitone) !== -1){
    //if ((categoryId <= 7 || categoryId === 10) && categoryId!==4) {
        category = 'splitOne';
        checkSum = '.splitOne';
    } else {
        category = 'splitTwo';
        checkSum = '.' + sectionId;
    }

    if ((($('#Custom_body .splitOne').length <= 0) && (category === 'splitOne')) || (($('#Custom_body .' + sectionId).length <= 0) && (category === 'splitTwo'))) {
        var drugHtml = addDrugSearchItemsList(sectionId, category);
        $(".coupon_block").before(drugHtml);
        var prescriptionObj = sectionId + '_file';
        var prescriptionObjLength = sectionId + '_file_length';
        sessionStorage.setItem(prescriptionObj, "");
        sessionStorage.setItem(prescriptionObjLength, "");
        var _dataforvendor = {"systemType": "l2pharma"};
        _ajaxEventHandler("vendor_list", _dataforvendor, cbk_setvendorinselecttag,'');
    } else {
        //console.log($(checkSum).find('#mtable tbody').length);
		//alert(rowcount);
        $(checkSum).find('table tbody').append($(checkSum).find('table tbody tr:last').clone().find('input').val('').end());
		$(checkSum + ' table tbody tr:last').attr('id','rowdrug-'+rowcount);
		$(checkSum + ' table tbody tr:last #l2vcancel').attr('data-value',rowcount);
    }
	//debugger;
	//alert(rowcount);
    //var currentRowId = $(checkSum + ' table tbody tr:last').attr('id').replace('rowdrug-','');
    //var currentRowId = $(checkSum + ' table tbody tr:last').index();
	//alert(currentRowId);
    //var currentRow = checkSum + ' table tbody tr:eq(' + rowcount + ')';
	var currentRow = checkSum + ' table #rowdrug-'+rowcount;
	//alert(currentRow);
    //console.log(currentRowId);
    //console.log(currentRow);
    //$(checkSum + ' table tbody tr:last').attr('id', 'rowdrug-' + rowcount);
    //$(checkSum + ' table tbody tr:last').attr('id', 'rowdrug-' + rowcount);
    //$(checkSum + ' table tbody tr:last').attr('id','rowdrug-'+rowcount);
	//alert(checkSum);
    $(currentRow).find("input[name=drugsearch]").attr('data-codedid', codedid);
    $(currentRow).find("input[name=drugsearch]").attr('data-id', id);
    $(currentRow).find("input[name=drugsearch]").attr('data-category', categoryId);
    $(currentRow).find("input[name=drugsearch]").attr('data-priceperunit', priceperunit);
    $(currentRow).find("input[name=drugsearch]").attr('data-packsize', packsize);
    $(currentRow).find("input[name=drugsearch]").attr('data-manufacturerid', manufacturerId);
    $(currentRow).find("input[name=drugsearch]").attr('data-manufacturer', manufacturer);

    $(currentRow).find("input[name=drugsearch]").val(selecteddiag);
    $(currentRow).find("input[name=pharmaname]").val(pharmaname);
    $(currentRow).find("input[name=quantity]").val('1');
    $(currentRow).find("input[name=itemmrpval]").val(s_mrp);
    $(currentRow).find("input[name=discountAmount]").val(discountAmount);
    $(currentRow).find("input[name=netAmount]").val(netAmount);
    $(currentRow).find("input[name=grossamount]").val(s_mrp);
	//debugger; 
    newCheckpricefrommdm();
    //settimeslot();
    $this.val('');	
	rowcount = rowcount + 1;
	
	
}

function calculate(e, $this) {
    //console.log(checkSum);
    //console.log(e.type);
    if (e.type == 'keyup' || e.type == 'focusout' || e.type == 'change' || e.type == 'focus') {
        $rowId = $($this).parents('tr').attr('id');
        //console.log($rowId);
        $qty = $(checkSum).find('#' + $rowId).find('input[name="quantity"]').val();
        //console.log($qty);
        if ($qty > 0 && e.type == 'focusout') {
            return;
        }
        $currentDrug = $(checkSum).find('#' + $rowId).find('input[name="drugsearch"]').val();
        $pricePerUnit = $(checkSum).find('#' + $rowId).find('input[name="itemmrpval"]').val();
        //console.log($rowId);
        if (($qty <= 0 && $qty != '') || ($qty == '' && e.type == 'focusout')) {
            $(checkSum).find('#' + $rowId).find('input[name="quantity"]').val(1)
            $qty = 1;
        }
        if ($qty == '') {
            $qty = 0;
        }
        $mrp = parseFloat(parseFloat($pricePerUnit) * parseInt($qty)).toFixed(2);
        $(checkSum).find('#' + $rowId).find('input[name="grossamount"]').val($mrp);
        newCheckpricefrommdm();
    }
}

function cancellineitemdiag(val) {    
	console.log("#rowdrug-"+$(val).attr("data-value"));
	var para_val_del = $("#rowdrug-"+$(val).attr("data-value")).parents().get(5).getAttribute("data-sectionid");
	$index = $("."+para_val_del).find("table tbody tr").length;
	var itemtoRemove= $("#rowdrug-"+($(val).attr("data-value"))+" input[name=drugsearch]").val();
	console.log(itemtoRemove);
    //$index = $(checkSum).find("table tbody tr").length;
    console.log($index);
    if ($index > 1) {
        /*var rowId = '#' + $($this).parents('tr').attr('id');
        var removeItem = $(checkSum).find(rowId + ' input[name=drugsearch]').val();
        //console.log(removeItem);
        selectedDrugsList = $.grep(selectedDrugsList, function (value) {
            return value != removeItem;
        });
        $($this).parents('tr').remove();*/
        console.log(selectedDrugsList);
		$("#rowdrug-"+$(val).attr("data-value")).remove();
		selectedDrugsList.splice($.inArray(itemtoRemove,selectedDrugsList),1);
    }else{
		if(sessionStorage.getItem('orderMode') != 'update'){
			$("."+para_val_del).remove();
			selectedDrugsList.splice($.inArray(itemtoRemove,selectedDrugsList),1);
		}		
	} 	
	console.log(selectedDrugsList);
    newCheckpricefrommdm();
}

function findofferid() {}
/*
function newCheckpricefrommdm(){
	getwalletamt();
    var coupon = "";
    var orderDate = todayDateforMDM();
    if ($.trim($("#l2vCoupanCode").attr("data-code")) == "") {
        coupon = $("#l2vCoupanCode").val();
    }
    var business = "2";
	var source = "CCO";
	
	if(sessionStorage.getItem("channel")!=null && sessionStorage.getItem("channel")!=""){
		source = channel[parseInt(sessionStorage.getItem("channel"))];
	}
    var lineitems = [];
    var mrnno = sessionStorage.getItem("patientmrn");
    var itemarray = $("#l2vCoupanCode").attr("data-code").split(',');
    $('input[name=drugsearch]').each(function () {
    //$(checkSum + ' input[name=drugsearch]').each(function () {
        $rowId = $(this).parents('tr').attr('id');
        //console.log($rowId);
        //console.log($(this).val()); 
        if ($.trim($(this).val()) != "") {
            $drugName = $(this).val();
            var codedata = $(this).attr('data-codedid');
            if ((typeof codedata != "undefined") && codedata != "" && codedata != "0") {
                var couponitem = "";
                if (jQuery.inArray(codedata, itemarray) !== -1) {
                    couponitem = $("#l2vCoupanCode").val();
                }
                lineitems.push({
                    orderDate: orderDate,
                    business: business,
                    code: codedata,
                    sessions: $(checkSum).find('#'+$rowId + ' input[name="quantity"]').val(),
                    source: source,
                    mrn: mrnno,
                    engage_at: '1',
                    zipcode: sessionStorage.getItem('zipcode')
                });
            }
        }
    });
    //console.log(lineitems);
    var doctorReferral = "no";
    if (sessionStorage.getItem("placedfromdoctorplace") == "1") {
        doctorReferral = "yes";
    }
    var walletstatus = sessionStorage.getItem("walletstatus");	
    var _data = {
		method: "domain/Order",
		type: "POST",
		orderDate: orderDate,
		source: source,
		coupon: coupon,
		useWallet:"false",
		LineItems: lineitems
	};
    if (($("#applywallet").prop('checked') == true) && (parseInt(walletstatus)!=1)){
        _data.useWallet = "true";
    }
    //console.log(_data);	
    _ajaxEventHandler("checkpricefrommdm", _data, new_cbk_checkpricefrommdm, SHOW_LOADER);
}*/

var showcoupenmmsg = 2;
/*
function new_cbk_checkpricefrommdm(response) {
    //console.log(response);
    var countitem = 0;
    var coupon = $("#l2vCoupanCode").val();
    var countinvalidcounpen = 0;
    var couponApplied = false;
    var couponApplieditem = false;
    if (typeof response == 'string') {
        var Obj = JSON.parse(response);
    } else {
        var Obj = response;
    }

    // Obj = response;
    var walletstatus = sessionStorage.getItem("walletstatus");
	var usedwalletAmount=0;
    if (Obj.status == 1) {
        var checkprescriptioncount = 0;
        var objData = Obj.data;
        couponApplied = Obj.couponApplied;
        $.each(objData.lineItemList, function (key, val) {
            $itemCode = val.code;
            $rowId = '#' + $(checkSum).find('input[data-codedid="' + $itemCode + '"]').parents('tr').attr('id');
            var dis = parseFloat(val.discountAmount) + 
			((typeof val.apportionedDiscountAmount != 'undefined') ? parseFloat(val.apportionedDiscountAmount) : 0) +
			((typeof val.orderApportionedDiscountAmount != 'undefined') ? parseFloat(val.orderApportionedDiscountAmount) : 0);
            //alert(dis);
			$(checkSum).find($rowId + ' input[name="discountAmount"]').val(dis);
            $(checkSum).find($rowId + ' input[name="grossamount"]').val(val.grossAmount);
            $(checkSum).find($rowId + ' input[name="itemmrpval"]').val(val.unitPrice);
            $(checkSum).find($rowId + ' input[name="grossamount"]').attr("data-mrp", val.unitPrice);
            //$(checkSum).find($rowId + ' input[name="netAmount"]').val(val.netAmount);
            $(checkSum).find($rowId + ' input[name="netAmount"]').val(val.OMSNetAmount);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-cartCouponApplied', val.cartCouponApplied);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-cartDiscountApplied', val.cartDiscountApplied);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-cartDiscountApportionedAmount', val.cartDiscountApportionedAmount);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-couponValue', val.couponValue);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-discountApplied', val.discountApplied);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-invoiceTo', val.invoiceTo);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-orderDiscountApplied', val.orderDiscountApplied);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-penalty_amount', val.penalty_amount);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-orderApportionedDiscountAmount', val.orderApportionedDiscountAmount);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-cartDiscountApportionedAmount', val.cartDiscountApportionedAmount);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-apportionedCouponAmount', val.apportionedCouponAmount);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-apportionedWalletAmount', val.apportionedWalletAmount);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-maxQuantity', val.maxQuantity);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-minQuantity', val.minQuantity);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-voucherApportionedAmount', val.voucherApportionedAmount);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-grossAmount', val.grossAmount);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-MRP', val.MRP);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-OMSNetAmount', val.OMSNetAmount);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-netAmount', val.netAmount);
            $(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-discountAmount', val.discountAmount);

            if (val.couponApplied == true) {
                couponApplieditem = val.couponApplied;
            }
            if (walletstatus != 1 || walletstatus != "1") {
				var wallet = (typeof val.apportionedWalletAmount == "undefined" || val.apportionedwalletamount == '') ? 0 : val.apportionedWalletAmount;                
				$(checkSum).find($rowId + ' input[name="netamount"]').attr("data-walletamt",wallet);				
				usedwalletAmount = usedwalletAmount + wallet;
				//$(checkSum).find($rowId + ' input[name="netamount"]').attr("data-walletamt",
            }
            countitem = countitem + 1;
            var prescribedval = val.prescribed;
            if (prescribedval === true) {
                $(checkSum).find($rowId + ' label[name="l2vsetrxotg"]').show();
                $(checkSum).find($rowId + ' label[name="l2vsetrxotg"]').attr("data-rxset", "true");
                checkprescriptioncount = 1;
            } else if (prescribedval === false) {
                $(checkSum).find($rowId + ' label[name="l2vsetrxotg"]').attr("data-rxset", "false");
                $(checkSum).find($rowId + ' label[name="l2vsetrxotg"]').css('display', 'none');
            } else {
                $(checkSum).find($rowId + ' label[name="l2vsetrxotg"]').attr("data-rxset", "");
                $(checkSum).find($rowId + ' label[name="l2vsetrxotg"]').css('display', 'none');
            }
        });
        //console.log(checkprescriptioncount);
        if (checkprescriptioncount == 1 && sessionStorage.getItem("encounterid") == "" && sessionStorage.getItem("orderstatuscurorder") != "24") {
            $(checkSum).find("#vendorname").attr('disabled', 'disabled');
            //console.log(checkSum);
            var sectionId = $(checkSum).attr('data-sectionid');
            var prescriptionobj = sectionId + '_file';
            if (sessionStorage.getItem(prescriptionobj) == "") {
                $(checkSum).find("#vendorname").val("0");
                $(checkSum).find("#checkboxprescriptionsms").prop("checked", true);
            } else {
                $(checkSum).find("#vendorname").removeAttr('disabled');
            }

        } else if (checkprescriptioncount == 1 && sessionStorage.getItem("orderstatuscurorder") == "24") {
            $(checkSum).find("#checkboxprescriptionsms").prop("checked", true);
            $(checkSum).find("#vendorname").removeAttr('disabled');
        } else {
            $(checkSum).find("#checkboxprescriptionsms").prop("checked", false);
            $(checkSum).find("#vendorname").removeAttr('disabled');
        }

        if ($.trim(coupon) != "" && (couponApplied == true || couponApplieditem == true)) {
            if (showcoupenmmsg == 2) {
                alert("Coupon " + coupon + " is applied successfully.");
                _data = {coupen_name: ($.trim($("#l2vCoupanCode").val()))}
                _ajaxEventHandler("coupendetails", _data, cbk_coupendetails, SHOW_LOADER);
                showcoupenmmsg = 1;
            }
        }
        else if ($.trim(coupon) != "") {
            if (showcoupenmmsg == 2) {
                alert("Invalid coupon " + coupon);
                showcoupenmmsg = 0;
                $("#l2vCoupanCode").val("");
                $("#l2vreferby").val("");
            }
        }
        $(checkSum).find('#l2vitemtotalamount').attr('data-voucherAmount', objData.voucherAmount);
        if (objData.addMedicineDeliveryCharges == true && (typeof objData.medicineDeliveryChargesList != "undefined")) {
            $(checkSum).find("#l2vdeliverycharge").html($.trim(objData.medicineDeliveryCharges));
            $(checkSum).find("#medicine_delivery").attr("data-codedid", $.trim(objData.medicineDeliveryChargesList[0].code));
            $(checkSum).find("#medicine_delivery").attr("data-item_mrp", $.trim(objData.medicineDeliveryChargesList[0].unitPrice));
            $(checkSum).find("#medicine_delivery").attr("data-item_gross", $.trim(objData.medicineDeliveryChargesList[0].grossAmount));
            $(checkSum).find("#medicine_delivery").attr("data-item_net", $.trim(objData.medicineDeliveryChargesList[0].netAmount));
            $(checkSum).find("#medicine_delivery").attr("data-item_discount", $.trim(objData.medicineDeliveryChargesList[0].discountAmount));
            $(checkSum).find("#medicine_delivery").attr("data-ignoreToPartner", $.trim(objData.medicineDeliveryChargesList[0].ignoreToPartner));
            $(checkSum).find("#medicine_delivery").val("1");
        } else {
            $(checkSum).find("#l2vdeliverycharge").html("0");
            $(checkSum).find("#medicine_delivery").val("0");
            $(checkSum).find("#medicine_delivery").attr("data-id", "");
            $(checkSum).find("#medicine_delivery").attr("data-codedid", "");
            $(checkSum).find("#medicine_delivery").attr("data-item_mrp", 0);
            $(checkSum).find("#medicine_delivery").attr("data-item_gross", 0);
            $(checkSum).find("#medicine_delivery").attr("data-item_net", 0);
            $(checkSum).find("#medicine_delivery").attr("data-item_discount", 0);
            $(checkSum).find("#medicine_delivery").attr("data-ignoreToPartner", "");
        }
		
        var walletamountavailable = parseFloat(sessionStorage.getItem("walletamount"));
        //console.log(walletamountavailable);
        var totalamt = parseFloat(objData.netAmount);
        /*var totalamtapplied = parseFloat(objData.walletAmount);
        var remainwallet = walletamountavailable;

        if (walletstatus != 1 || walletstatus != "1") {
            remainwallet = walletamountavailable - totalamtapplied;
        }else{
            var totalamt = totalamt - parseFloat($(checkSum).find("#l2vitemwalletamount").html()).toFixed(2);
            $(checkSum).find("#l2vitemwalletamount").html(parseFloat(totalamtapplied).toFixed(2));
        }
		//l2vitemwalletamount l2vitemtotalamountgross l2vwalletamt
		//console.log(walletamountavailable - parseFloat(objData.walletAmount));
		//console.log($("#l2vwalletamt").html());
		//console.log(usedwalletAmount);
        $("#l2vwalletamt").html(walletamountavailable - parseFloat(objData.walletAmount));
        $(checkSum).find("#l2vitemwalletamount").html(parseFloat(usedwalletAmount));
        $(checkSum).find("#l2vitemtotalamount").html(parseFloat(totalamt));
        $(checkSum).find("#l2vitemtotalamountgross").html(parseFloat(objData.grossAmount));
        $(checkSum).find("#l2vitemtotalamountdiscount").html((parseFloat(objData.discountAmount) + parseFloat(objData.cartDiscountAmount) + parseFloat(objData.orderDiscountAmount) + parseFloat(objData.couponAmount)));
        //sessionStorage.setItem('walletamount', remainwallet);
    }
    $(".loader").hide();
}
*/

function new_cbk_checkpricefrommdm(response) {
    //console.log(response);
	var para_sectionId="";
	var checkSumEach ="";
    var countitem = 0;
    var coupon = $("#l2vCoupanCode").val();
    var countinvalidcounpen = 0;
    var couponApplied = false;
    var couponApplieditem = false;
    if (typeof response == 'string') {
        var Obj = JSON.parse(response);
    } else {
        var Obj = response;
    }

    // Obj = response;
    var walletstatus = sessionStorage.getItem("walletstatus");
	
    if (Obj.status == 1) {
        //var checkprescriptioncount = 0;
        var objData = Obj.data;
        couponApplied = Obj.couponApplied;
		
		$(".l2vitemwalletamount").html(0);
		$(".l2vitemtotalamount").html(0);
		$(".l2vitemtotalamountgross").html(0);
		$(".l2vitemtotalamountdiscount").html(0);
		
        $.each(objData.lineItemList, function (key, val){
			var checkprescriptioncount = 0;
			$itemCode = $.trim(val.code);
			//alert(checkSum);
			//alert($("#l2vsearch_custom input[data-codedid='"+$itemCode+"']").val());
			//para_sectionId = ".splitOne";
			console.log($itemCode);
			var para = $("#l2vsearch_custom input[data-codedid='"+$itemCode+"']").parents().get(8).getAttribute("class");
			//console.log("start");
			//console.log(para);
			var block_sectionId = $("#l2vsearch_custom input[data-codedid='"+$itemCode+"']").parents().get(8).getAttribute("data-sectionid");
			//console.log(block_sectionId);
			var para_sectionId = "."+block_sectionId;
			if(para.search("splitOne")>-1){
				checkSumEach = ".splitOne";
			}
			if(para.search("splitTwo")>-1){
				checkSumEach = ".splitTwo";
			}
			if(para_sectionId==""){
				alert("Please try again.");
				return;
			}
			//console.log(para_sectionId);
			//alert(para_sectionId);			
            $rowId = '#' + $(para_sectionId).find('input[data-codedid="' + $itemCode + '"]').parents('tr').attr('id');
			console.log($rowId);
            var dis = parseFloat(val.discountAmount) + 
			((typeof val.apportionedDiscountAmount != 'undefined') ? parseFloat(val.apportionedDiscountAmount) : 0) +
			((typeof val.orderApportionedDiscountAmount != 'undefined') ? parseFloat(val.orderApportionedDiscountAmount) : 0);
            //alert(dis);
			$(para_sectionId).find($rowId + ' input[name="discountAmount"]').val(dis);
            $(para_sectionId).find($rowId + ' input[name="grossamount"]').val(val.grossAmount);
            $(para_sectionId).find($rowId + ' input[name="itemmrpval"]').val((val.unitPrice).toFixed(2));
            $(para_sectionId).find($rowId + ' input[name="grossamount"]').attr("data-mrp", val.unitPrice);
            //$(para_sectionId).find($rowId + ' input[name="netAmount"]').val(val.netAmount);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').val(val.OMSNetAmount);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-cartCouponApplied', val.cartCouponApplied);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-cartDiscountApplied', val.cartDiscountApplied);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-cartDiscountApportionedAmount', val.cartDiscountApportionedAmount);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-couponValue', val.couponValue);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-discountApplied', val.discountApplied);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-invoiceTo', val.invoiceTo);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-orderDiscountApplied', val.orderDiscountApplied);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-penalty_amount', val.penalty_amount);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-orderApportionedDiscountAmount', val.orderApportionedDiscountAmount);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-cartDiscountApportionedAmount', val.cartDiscountApportionedAmount);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-apportionedCouponAmount', val.apportionedCouponAmount);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-apportionedWalletAmount', val.apportionedWalletAmount);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-maxQuantity', val.maxQuantity);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-minQuantity', val.minQuantity);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-voucherApportionedAmount', val.voucherApportionedAmount);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-grossAmount', val.grossAmount);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-MRP', val.MRP);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-OMSNetAmount', val.OMSNetAmount);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-netAmount', val.netAmount);
            $(para_sectionId).find($rowId + ' input[name="netAmount"]').attr('data-discountAmount', val.discountAmount);

            if (val.couponApplied == true) {
                couponApplieditem = val.couponApplied;
            }
            if (walletstatus != 1 || walletstatus != "1") {
				var wallet = (typeof val.apportionedWalletAmount == "undefined" || val.apportionedwalletamount == '') ? 0 : val.apportionedWalletAmount;               
				$(para_sectionId).find($rowId + ' input[name="netamount"]').attr("data-walletamt",wallet);				
				//usedwalletAmount = usedwalletAmount + wallet;
				//$(para_sectionId).find($rowId + ' input[name="netamount"]').attr("data-walletamt",
            }
            countitem = countitem + 1;
            var prescribedval = val.prescribed;
            if (prescribedval === true) {
                $(para_sectionId).find($rowId + ' label[name="l2vsetrxotg"]').show();
                $(para_sectionId).find($rowId + ' label[name="l2vsetrxotg"]').attr("data-rxset", "true");
                checkprescriptioncount = 1;
            } else if (prescribedval === false) {
                $(para_sectionId).find($rowId + ' label[name="l2vsetrxotg"]').attr("data-rxset", "false");
                $(para_sectionId).find($rowId + ' label[name="l2vsetrxotg"]').css('display', 'none');
            } else {
                $(para_sectionId).find($rowId + ' label[name="l2vsetrxotg"]').attr("data-rxset", "");
                $(para_sectionId).find($rowId + ' label[name="l2vsetrxotg"]').css('display', 'none');
            }
			//alert($(para_sectionId+" .l2vitemwalletamount").html());
			//wallet 
			$(para_sectionId+" .l2vitemwalletamount").html((parseFloat($(para_sectionId+" #l2vitemwalletamount").html()) + parseFloat(wallet)).toFixed(2));
			//payable
			$(para_sectionId+" .l2vitemtotalamount").html((parseFloat($(para_sectionId+" #l2vitemtotalamount").html()) + parseFloat(val.payabaleAmount)).toFixed(2));
			
			//gross
			$(para_sectionId+" .l2vitemtotalamountgross").html((parseFloat($(para_sectionId+" .l2vitemtotalamountgross").html()) + parseFloat(val.grossAmount)).toFixed(2));
			
			//discount
			$(para_sectionId+" .l2vitemtotalamountdiscount").html((parseFloat($(para_sectionId+" .l2vitemtotalamountdiscount").html()) + parseFloat(dis)).toFixed(2));
			
			var prescriptionobj = block_sectionId+ '_file';
			prescriptionobj = prescriptionobj.replace(/\-/g,'_');
			var pre_check = (typeof sessionStorage.getItem(prescriptionobj)!="undefined" && sessionStorage.getItem(prescriptionobj)!=null)?sessionStorage.getItem(prescriptionobj):"";
			
            if (pre_check=="" && checkprescriptioncount==1){
				$(para_sectionId).find("#vendorname").val("0");
                $(para_sectionId).find("#checkboxprescriptionsms").prop("checked", true);
                $(para_sectionId).find("#vendorname").attr('disabled', 'disabled');
			}else if(pre_check!="" && checkprescriptioncount==1){
                $(para_sectionId).find("#checkboxprescriptionsms").prop("checked", false);
                $(para_sectionId).find("#vendorname").removeAttr('disabled');
			}
		
			if (objData.addMedicineDeliveryCharges == true && (typeof objData.medicineDeliveryChargesList != "undefined")){
				$i=0;
				$.each(objData.medicineDeliveryChargesList,function(keyval, delval){
					
					if(jQuery.inArray($itemCode, delval.services) !== -1){
						$(para_sectionId+" .l2vdeliverycharge").html($.trim(objData.medicineDeliveryChargesList[$i].OMSNetAmount));
						//console.log(delval.services);
						//console.log($itemCode);
						//console.log(para_sectionId);
						//console.log($i);
						//alert(para_sectionId);
						$(para_sectionId+" .medicine_delivery").attr("data-codedid", $.trim(objData.medicineDeliveryChargesList[$i].code));
						$(para_sectionId+" .medicine_delivery").attr("data-item_mrp", $.trim(objData.medicineDeliveryChargesList[$i].unitPrice));
						$(para_sectionId+" .medicine_delivery").attr("data-item_gross", $.trim(objData.medicineDeliveryChargesList[$i].grossAmount));
						$(para_sectionId+" .medicine_delivery").attr("data-item_net", $.trim(objData.medicineDeliveryChargesList[$i].OMSNetAmount));
						$(para_sectionId+" .medicine_delivery").attr("data-item_discount", $.trim(objData.medicineDeliveryChargesList[$i].discountAmount));
						$(para_sectionId+" .medicine_delivery").attr("data-ignoreToPartner", $.trim(objData.medicineDeliveryChargesList[$i].ignoreToPartner));
						$(para_sectionId+" .medicine_delivery").val("1");
					}
					$i = $i +1;
				});
			}else{
				$(para_sectionId+" .l2vdeliverycharge").html("0");
				$(para_sectionId+" .medicine_delivery").val("0");
				$(para_sectionId+" .medicine_delivery").attr("data-id", "");
				$(para_sectionId+" .medicine_delivery").attr("data-codedid", "");
				$(para_sectionId+" .medicine_delivery").attr("data-item_mrp", 0);
				$(para_sectionId+" .medicine_delivery").attr("data-item_gross", 0);
				$(para_sectionId+" .medicine_delivery").attr("data-item_net", 0);
				$(para_sectionId+" .medicine_delivery").attr("data-item_discount", 0);
				$(para_sectionId+" .medicine_delivery").attr("data-ignoreToPartner", "");
			}
		//$(para_sectionId).find("#l2vitemtotalamount").html(parseFloat(totalamt));			//$(para_sectionId).find("#l2vitemtotalamountgross").html(parseFloat(objData.grossAmount));			//$(para_sectionId).find("#l2vitemtotalamountdiscount").html((parseFloat(objData.discountAmount) + parseFloat(objData.cartDiscountAmount) + parseFloat(objData.orderDiscountAmount) + parseFloat(objData.couponAmount)));
        });
		$("section[name='drug_orders']").each(function(finalval){
			var final_sectionId="."+$(this).attr("data-sectionid");
			$(final_sectionId+" .l2vitemtotalamount").html((parseFloat($(final_sectionId+" #l2vitemtotalamount").html()) + parseFloat($(final_sectionId+" .medicine_delivery").attr("data-item_net"))).toFixed(2));
			
			//gross
			$(final_sectionId+" .l2vitemtotalamountgross").html((parseFloat($(final_sectionId+" .l2vitemtotalamountgross").html()) + parseFloat($(final_sectionId+" .medicine_delivery").attr("data-item_net"))).toFixed(2));
		})
		//drug_orders
		
        //console.log(checkprescriptioncount);
        /*if(checkprescriptioncount == 1 && sessionStorage.getItem("encounterid") == "" && sessionStorage.getItem("orderstatuscurorder") != "24") {
            $(para_sectionId).find("#vendorname").attr('disabled', 'disabled');
            //console.log(para_sectionId);
            var sectionId = $(para_sectionId).attr('data-sectionid');
            var prescriptionobj = sectionId + '_file';
            if (sessionStorage.getItem(prescriptionobj) == "") {
                $(para_sectionId).find("#vendorname").val("0");
                $(para_sectionId).find("#checkboxprescriptionsms").prop("checked", true);
            } else {
                $(para_sectionId).find("#vendorname").removeAttr('disabled');
            }

        }else if (checkprescriptioncount == 1 && sessionStorage.getItem("orderstatuscurorder") == "24") {
            $(para_sectionId).find("#checkboxprescriptionsms").prop("checked", true);
            $(para_sectionId).find("#vendorname").removeAttr('disabled');
        }else {
            $(para_sectionId).find("#checkboxprescriptionsms").prop("checked", false);
            $(para_sectionId).find("#vendorname").removeAttr('disabled');
        }*/

        if($.trim(coupon) != "" && (objData.couponApplied == "true")) {
            if (showcoupenmmsg == 2) {
                alert("Coupon " + coupon + " is applied successfully.");
                _data = {coupen_name: ($.trim($("#l2vCoupanCode").val()))}
                _ajaxEventHandler("coupendetails", _data, cbk_coupendetails, SHOW_LOADER);
                showcoupenmmsg = 1;
            }
        }else if ($.trim(coupon) != "") {
            if (showcoupenmmsg == 2) {
                alert("Invalid coupon " + coupon);
                showcoupenmmsg = 0;
                $("#l2vCoupanCode").val("");
                $("#l2vreferby").val("");
            }
        }        
        
		/*if (objData.addMedicineDeliveryCharges == true && (typeof objData.medicineDeliveryChargesList != "undefined")) {
            $(para_sectionId).find("#l2vdeliverycharge").html($.trim(objData.medicineDeliveryCharges));
            $(para_sectionId).find("#medicine_delivery").attr("data-codedid", $.trim(objData.medicineDeliveryChargesList[0].code));
            $(para_sectionId).find("#medicine_delivery").attr("data-item_mrp", $.trim(objData.medicineDeliveryChargesList[0].unitPrice));
            $(para_sectionId).find("#medicine_delivery").attr("data-item_gross", $.trim(objData.medicineDeliveryChargesList[0].grossAmount));
            $(para_sectionId).find("#medicine_delivery").attr("data-item_net", $.trim(objData.medicineDeliveryChargesList[0].netAmount));
            $(para_sectionId).find("#medicine_delivery").attr("data-item_discount", $.trim(objData.medicineDeliveryChargesList[0].discountAmount));
            $(para_sectionId).find("#medicine_delivery").attr("data-ignoreToPartner", $.trim(objData.medicineDeliveryChargesList[0].ignoreToPartner));
            $(para_sectionId).find("#medicine_delivery").val("1");
        } else {
            $(para_sectionId).find("#l2vdeliverycharge").html("0");
            $(para_sectionId).find("#medicine_delivery").val("0");
            $(para_sectionId).find("#medicine_delivery").attr("data-id", "");
            $(para_sectionId).find("#medicine_delivery").attr("data-codedid", "");
            $(para_sectionId).find("#medicine_delivery").attr("data-item_mrp", 0);
            $(para_sectionId).find("#medicine_delivery").attr("data-item_gross", 0);
            $(para_sectionId).find("#medicine_delivery").attr("data-item_net", 0);
            $(para_sectionId).find("#medicine_delivery").attr("data-item_discount", 0);
            $(para_sectionId).find("#medicine_delivery").attr("data-ignoreToPartner", "");
        }*/
		
        //console.log(walletamountavailable);
        //var totalamt = parseFloat(objData.netAmount);
        /*var totalamtapplied = parseFloat(objData.walletAmount);
        var remainwallet = walletamountavailable;

        if (walletstatus != 1 || walletstatus != "1") {
            remainwallet = walletamountavailable - totalamtapplied;
        }else{
            var totalamt = totalamt - parseFloat($(para_sectionId).find("#l2vitemwalletamount").html()).toFixed(2);
            $(para_sectionId).find("#l2vitemwalletamount").html(parseFloat(totalamtapplied).toFixed(2));
        }*/
		//l2vitemwalletamount l2vitemtotalamountgross l2vwalletamt
		//console.log(walletamountavailable - parseFloat(objData.walletAmount));
		//console.log($("#l2vwalletamt").html());
		//console.log(usedwalletAmount);
		$(para_sectionId).find('#l2vitemtotalamount').attr('data-voucherAmount', objData.voucherAmount);
		var walletamountavailable = parseFloat(sessionStorage.getItem("walletamount"));
        $("#l2vwalletamt").html(walletamountavailable - parseFloat(objData.walletAmount));
        
        //sessionStorage.setItem('walletamount', remainwallet);
    }
    $(".loader").hide();
}


function l2prescptionuploadl2(sectionId) {
    $("." + sectionId + "_uploadpresc").modal("show");
}

function l2prescptionuploadfroml2(sectionId) {
    var formClass = sectionId + "_form";
    var formData = new FormData($('#' + formClass)[0]);
	var prescriptionobj = sectionId+'_file';
	prescriptionobj = prescriptionobj.replace(/\-/g,'_');
	var prescriptionfiles = [];
	if($.trim(sessionStorage.getItem(prescriptionobj))!=null && sessionStorage.getItem(prescriptionobj)!="undefined" && $.trim(sessionStorage.getItem(prescriptionobj))!=""){
		//prescriptionfiles.push(JSON.parse(sessionStorage.getItem(prescriptionobj)));
		$.merge(prescriptionfiles,JSON.parse(sessionStorage.getItem(prescriptionobj)));
	}
    $.ajax({
        url: RestServiceURL + 'medicine_supply.php/v1/prescription_upload_l2screen',
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        type: 'POST',
        success: function (data) {
            var result = data;
            if (typeof data == 'string') {
                result = JSON.parse(data);
            }
            if (result.status == 1){
				$.each(result.data, function (key, val) {
                    if (val.status == 1){
                        prescriptionfiles.push(val.data);
                    }
                });
				
				if(prescriptionfiles.length>0){
					sessionStorage.setItem(prescriptionobj,JSON.stringify(prescriptionfiles));
					//console.log(prescriptionfiles);
					$('.'+sectionId).find("#l2vopenprescriptionmadal").show();
					$('.'+sectionId).find("#vendorname").removeAttr('disabled');
					$('.'+sectionId).find("#checkboxprescriptionsms").prop("checked",false);
					
				}
            } else if (result.status == 0) {
                alert(result.message[0].message);
            } else {
                alert("some thing Wrong, Please try again !")
            }
        }
    });
    document.getElementById(formClass).reset();
}

function l2prescptionupload() {
    var formData = new FormData($("#formsum")[0]);
    formData.append('order_id', $('#orderid').val());
    var vendorname = sessionStorage.getItem('loginname');
    formData.append('mrn', sessionStorage.getItem('patientmrn'));

    $.ajax({
        url: RestServiceURL + 'medicine_supply.php/v1/prescription_upload_link',
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        type: 'POST',
        success: function (data) {
			//console.log(data);
            var result = '';
            if (typeof data == 'string') {
                result = JSON.parse(data);
            } else {
                result = data;
            }
            if (result.status == 1) {
                alert('Prescription uploaded.');
                $('.hideAllDetails').hide();
                $('.removeActive').removeClass('active');
                $('.veiwOrderDetails').addClass("active");
                $('#veiwOrderDetails').addClass('active in');
				$("#viewOrder").modal("hide");
            }
            else {

                alert("some Thing Wrong  Please try again !")
            }
        }
    });
}

function showaddress() {
    $("#l2edit").toggle();
}

function updateaddresspopn() {
    if ($("#address1").val() == "") {
        alert('Please enter address');
        return;
    }
    if ($("#postal_code").val() == "" || $("#postal_code").val() == 0 || $("#postal_code").val() == "0") {
        alert('Please enter postal code');
        return;
    }
    if ($("#administrative_area_level_1").val() == "") {
        alert('Please enter state.');
        return;
    }
    if (($("#pcontactno").val() == "") || ($("#pcontactno").val().length < 10)) {
        alert('Please enter contact no.');
        return;
    }
    var showdelvaddress = $("#address1").val() + ", " + $("#route").val() + ", " + $("#locality").val() + ", " + $("#administrative_area_level_1").val() + ", " + $("#postal_code").val();


    $("#showdelvaddress").html(showdelvaddress);
    $("#showdelvpop").html($("#popname").val());
    sessionStorage.setItem("popname", $("#popname").val());
    sessionStorage.setItem("facility_id", $("#popid").val());
    sessionStorage.setItem("state", $("#administrative_area_level_1").val());
    var addressActionType = $('#actionType').val();
    var addressNickName = $('#address_nick_name').val();
    var district = $('#district').val();
    var latitude = $('#latitude').val();
    var longitude = $('#longitude').val();
    var addressId = $('#selected_address_id').val();
    var address1 = $('#address1').val();
    var stateVal = $('#administrative_area_level_1').val();
    var locality = $('#locality').val();
    var route = $('#route').val();
    var zipcodeVal = $('#postal_code').val();
    var landmark = $('#autocomplete').val();
    var contactno = $('#pcontactno').val();
    var alternetcontactno = $('#alternetcontactno').val();
    var _dataAddress = {
        action: (addressId) ? 'update' : 'add', // add or update
        addressId: addressId, //Mandatory if action=="update"
        mrn: sessionStorage.getItem('patientmrn'),
        createdBy: "",
        createdByType: "",
        stateVal: stateVal,
        addressVal: address1,
        cityVal: locality,
        addressType: 1,
        addressNickName: addressNickName,
        zipcodeVal: zipcodeVal,
        isActive: 1,
        countryVal: "India",
        lngVal: longitude,
        district: district,
        customerId: "CH333218",
        latVal: latitude,
        landmark: landmark,
        defaultAddress: "1"
    };
    _ajaxEventHandler("modifyAddress", _dataAddress, cbk_setNewAddress,'');
}

function cbk_setNewAddress(response) {
    var responseData = response;
    if (typeof response == 'string') {
        responseData = JSON.parse(response);
    }
    //console.log(responseData);
    if (responseData.status == 0 || responseData.status == '0') {
        alert(responseData.message);
        return false;
    }

    var currentAddress = responseData.data.addressDetails;
    var district = $('#district').val();
    var latitude = $('#latitude').val();
    var longitude = $('#longitude').val();
    var addressId = currentAddress.AddressId;
    var address1 = $('#address1').val();
    var stateVal = $('#administrative_area_level_1').val();
    var country = $('#country').val();
    var locality = $('#locality').val();
    var latitude = $('#latitude').val();
    var longitude = $('#longitude').val();
    var route = $('#route').val();
    var zipcodeVal = $('#postal_code').val();
    var landmark = $('#autocomplete').val();
    var contactno = $('#pcontactno').val();
    var address_nick_name = $('#address_nick_name').val();
    var alternetcontactno = $('#alternetcontactno').val();
    var address = address1 + ", " + route + ", " + locality + ", " + stateVal + ", " + country + ", " + zipcodeVal;
    sessionStorage.setItem("landmark", landmark);
    sessionStorage.setItem("city", locality);
    sessionStorage.setItem("district", district);
    sessionStorage.setItem("state", stateVal);
    sessionStorage.setItem("country", country);
    sessionStorage.setItem("zipcode", zipcodeVal);
    sessionStorage.setItem("address_id", addressId);
    sessionStorage.setItem("address_nickname", address_nick_name);
    sessionStorage.setItem("address", address);
    sessionStorage.setItem("latitude", latitude);
    sessionStorage.setItem("longitude", longitude);
    $('#showdelvaddress').html(address);
    $('#addressListModal').modal('hide');
}

function cbk_setvendorinselecttag(res) {
    var associate_id = sessionStorage.getItem('associate_id');
    var Obj = '';
    if (typeof res == 'string') {
        Obj = JSON.parse(res);
    } else {
        Obj = res;
    }
    if (associate_id == '' || associate_id == 'undefined') {
        var htmlBanner = '<option value="0" selected>Select Vendor</option>';
    } else {
        var htmlBanner = '<option value="0">Select Vendor</option>';
    }
    if (Obj.status == '1' || Obj.staus == 1) {
        $.each(Obj.data, function (key, val) {
            var selected = '';
            if (associate_id == val.userinfo.USER_ID) {
                selected = 'selected';
            }
            htmlBanner += '<option ' + selected + ' data-address="' + val.userinfo.ADDRESS + '" value="' + val.userinfo.USER_ID + '">' + val.userinfo.USER_NAME +
                    '</option>';
        });
    }
    sessionStorage.setItem('associate_id', '');
    $(checkSum).find("#vendorname").html(htmlBanner);
}

function cbk_setvendorList(res) {
    var Obj = '';
    if (typeof res == 'string') {
        Obj = JSON.parse(res);
    } else {
        Obj = res;
    }
    var htmlBanner = '<option value="0" selected>Select Vendor</option>';
    if (Obj.status == '1' || Obj.staus == 1) {
        $.each(Obj.data, function (key, val) {
			var selected = "";
			if(sessionStorage.getItem("reject_default_vendor_id")!=null && sessionStorage.getItem("reject_default_vendor_id")!="" && val.userinfo.USER_ID==sessionStorage.getItem("reject_default_vendor_id")){
				selected = "selected";
			}
            htmlBanner += '<option data-address="' + val.userinfo.ADDRESS + '" value="' + val.userinfo.USER_ID + '" '+selected+'>' + val.userinfo.USER_NAME +
                    '</option>';
        });
    }
    $("#vendor").html(htmlBanner);
}


function updateDeliveryAddress() {
    var newAdddress = $('#deliveryAddress').val();
    //console.log(newAdddress);
    $('#showdelvaddress').html(newAdddress);
    sessionStorage.setItem("address", newAdddress);
    $("#updateAddressModel").toggle();
}

function createNewDrugOrder() {
    var referedby = "";
    var sourceofreferral = "";
    var referredmrn = "";
    // 1 - yes 2 - no 
    var couponitem = "";
    if ($("#l2vreferby").val() == "") {
        //alert('Please enter referred by, if no referred by is there please enter 9999.');
        //return;
    } else {
        referedby = $("#l2vreferby").val();
        if ($("#referedbylist option[value='" + referedby + "']").length > 0 || referedby == "9999") {
        } else {
            alert('Invalid officer id.');
            return;
        }
    }

    if ($("#l2vsourcereferral option:selected").val() == "") {
        alert('Please select source.');
        return;
    } else {
        sourceofreferral = $("#l2vsourcereferral option:selected").val();
    }

    referredmrn = $("#l2vsreferbymrn").val();
    // for postal code
    if ($("#postal_code").val() == "" || $("#postal_code").val() == 0 || $("#postal_code").val() == "0") {
        alert('Please enter postal code');
        return;
    }
	
    var loginid = sessionStorage.getItem("loginid");
    var loginname = sessionStorage.getItem("loginname");
    var name = sessionStorage.getItem('displayname');
    var salutation = sessionStorage.getItem("salutation");
    var patientfname = sessionStorage.getItem('patientfname');
    var patientmname = sessionStorage.getItem('patientmname');
    var patientlname = sessionStorage.getItem('patientlname');
    var age = sessionStorage.getItem('displayage');
    var gender = sessionStorage.getItem('patientgender');
    var contactno = sessionStorage.getItem('contactno');
    var alternetcontactno = sessionStorage.getItem('alternetcontactno');
    if (contactno == "") {
        contactno = sessionStorage.getItem('contactno');
    }
    if (alternetcontactno == "") {
        alternetcontactno = (sessionStorage.getItem('alternetcontactno') == "Array") ? "" : sessionStorage.getItem('alternetcontactno');
    }
    var email = sessionStorage.getItem('email');
    var tagsfororder = (sessionStorage.getItem('tagsfororder') == null) ? "" : sessionStorage.getItem('tagsfororder');
    //var referedby=$.trim($("#l2vreferby").val());

    var doorno = "";
    var popname = sessionStorage.getItem('popname');
    var facility_id = sessionStorage.getItem('facility_id');
    var home_pop = sessionStorage.getItem('home_popname');
    var home_fc_id = sessionStorage.getItem('home_facility_id');
    var landmark = sessionStorage.getItem('landmark');
    var address1 = sessionStorage.getItem('address');
    var area = sessionStorage.getItem('area');
    var area = sessionStorage.getItem('area');
    var countrydistrict = sessionStorage.getItem('district');
    var state = sessionStorage.getItem('state');
    var zipcode = sessionStorage.getItem('zipcode');
    var longitude = sessionStorage.getItem('longitude');
    var latitude = sessionStorage.getItem('latitude');
    var addressId = sessionStorage.getItem('address_id');
    var payment_method = $("#payment_method option:selected").val();
    //var coupon = $("#coupon").val();
    var coupon = $("#l2vCoupanCode").val();
    if (showcoupenmmsg == 0) {
        coupon = "";
    }

    //for call
    var mrn = sessionStorage.getItem('patientmrn');
    var lead_id = (typeof sessionStorage.getItem('lead_id') != "undefined") ? sessionStorage.getItem('lead_id') : "";
    var callNumber = sessionStorage.getItem('callNumber');
    var orderid = sessionStorage.getItem('orderid');
    var encounterid = sessionStorage.getItem('encounterid');
    var patientid = sessionStorage.getItem('patientid');
    var orderwid = sessionStorage.getItem('orderwid');
    var orderwdid = sessionStorage.getItem('orderwdid');
    var doctorid = sessionStorage.getItem('doctorid');
    var doctorname = sessionStorage.getItem('doctorname');
    var mrncoporateid = sessionStorage.getItem('mrncoporateid');
    var mrncoporatename = sessionStorage.getItem('mrncoporatename');
    var ordersmscreate = (typeof (sessionStorage.getItem("ordersmscreate")) == "undefined") ? "0" : sessionStorage.getItem("ordersmscreate");
    var ezzetab_sms = sessionStorage.getItem('ezzetab_sms');
    var placedfromdoctorplace = sessionStorage.getItem("placedfromdoctorplace");
    var orderstatuscurorder = sessionStorage.getItem("orderstatuscurorder");
    var l2vprepaidamountcheck = $("#l2vprepaidamount").html();

    var medicine_delivery = 0;
    var deliveryarray = [];
    if ($("#medicine_delivery").val() == "1") {
        medicine_delivery = $("#medicine_delivery").attr("data-item_mrp");
        deliveryarray.push({
            item_code: $("#medicine_delivery").attr("data-codedid"),
            quantity: "1",
            gross_amount: $("#medicine_delivery").attr("data-item_gross"),
            item_mrp: $("#medicine_delivery").attr("data-item_mrp"),
            discount_amount: $("#medicine_delivery").attr("data-item_discount"),
            net_amount: $("#medicine_delivery").attr("data-item_net"),
            ignoreToPartner: $("#medicine_delivery").attr("data-ignoreToPartner")
        });
    }

    var totalOrders = [];
    var totalgross = '0.00';
    var totalnet = '0.00';
    var totaldiscount = '0.00';
    var totalUsedWalletAmount = '0.00';
    var totalVoucherAmount = '0.00';
	var check_anyerror = 0; 
    $('.new-order-by-category').each(function () {
        $this = $(this);
        var sectionId = $this.attr('data-sectionid');
        //check any rx item is available(set prescription later and send message) or not (set vendor) 
        var rxisavailable = 0;
        var otgisavailable = 0;
        var sendsmsforpprescription = 0;
        $this.find('label[name=l2vsetrxotg]').each(function () {
            if ($.trim($(this).attr("data-rxset")) == "true") {
                rxisavailable = rxisavailable + 1;
            }
        });
        if (rxisavailable < 1) {
            if ($("#vendorname").val() === "0") {
                alert("Please select vendor.");
				check_anyerror=1;
                return;
            }
        }
        else if (sessionStorage.getItem("orderstatuscurorder") == "24") {
            if ($("#vendorname").val() === "0") {
                alert("Please select vendor.");
				check_anyerror=1;
                return;
            }
            if (sessionStorage.getItem(sectionId) == "") {
                var r = confirm("Prescription file is required. Do you have the prescription file ??");
                if (r == true) {
                    l2prescptionuploadl2();
					check_anyerror=1;
                    return;
                }
            }
        } else {
            if (sessionStorage.getItem("encounterid") != "" && sessionStorage.getItem("orderstatusencounterid") != "6") {
                sendsmsforpprescription = 0;
            } else {
                if ((sessionStorage.getItem("encounterid") == "") && (sessionStorage.getItem(sectionId) != "")) {
                    sendsmsforpprescription = 0;
                } else {
                    sendsmsforpprescription = 1;
                }
            }
        }

        var vendorid = $this.find("#vendorname option:selected").val();
        var vendorname = $this.find("#vendorname option:selected").text();
        var vendoraddress = $this.find("#vendorname option:selected").attr("data-address");
        if (vendorid == "0") {
            var vendorid = "";
            var vendorname = "";
        }


        var currentNetAmount = $.trim($this.find("#l2vitemtotalamount").html());
        if (currentNetAmount != '') {
            totalnet = parseFloat(totalnet) + parseFloat(currentNetAmount);
            totalnet = parseFloat(totalnet).toFixed(2);
        }

        var deliveryAmount = $.trim($this.find("#l2vdeliverycharge").html());
        if (deliveryAmount != '') {
            deliveryAmount = parseFloat(deliveryAmount).toFixed(2);
        }


        var currentGrossAmount = $.trim($this.find("#l2vitemtotalamountgross").html());
        if (currentGrossAmount != '') {
            totalgross = parseFloat(totalgross) + parseFloat(currentGrossAmount);
            totalgross = parseFloat(totalgross).toFixed(2);
        }


        var currentDiscountAmount = $.trim($this.find("#l2vitemtotalamountdiscount").html());
        if (currentDiscountAmount != '') {
            totaldiscount = parseFloat(totaldiscount) + parseFloat(currentDiscountAmount);
            totaldiscount = parseFloat(totaldiscount).toFixed(2);
        }
		
		//var payment_info_coupon_amount = 0;
        /*if (currentDiscountAmount != '') {
            totaldiscount = parseFloat(totaldiscount) + parseFloat(currentDiscountAmount);
            totaldiscount = parseFloat(totaldiscount).toFixed(2);
        }*/

        var currentUsedWalletAmount = $.trim($this.find("#l2vitemwalletamount").html());
        if (currentUsedWalletAmount != '') {
            totalUsedWalletAmount = parseFloat(totalUsedWalletAmount) + parseFloat(currentUsedWalletAmount);
            totalUsedWalletAmount = parseFloat(totalUsedWalletAmount).toFixed(2);
        }

        var currentVoucherAmount = $.trim($this.find('#l2vitemtotalamount').attr('data-voucherAmount'));
        if (currentVoucherAmount != '') {
            totalVoucherAmount = parseFloat(totalVoucherAmount) + parseFloat(currentVoucherAmount);
            totalVoucherAmount = parseFloat(totalVoucherAmount).toFixed(2);
        }



        //getting current date
        /*var estdate = $this.find("#mainorderdate").val();
        var date2 = estdate.split(" ");
        var date3 = date2[0].split("-");
        var d1 = date3[0] + "-" + date3[1] + "-" + date3[2];
        var d = new Date(d1);
        var scheduledslot = $this.find("#scheduledslot option:selected").val();
        //console.log(scheduledslot);
        if (scheduledslot == "00:00:00") {
            alert("Please select time slot.");
            return;
        }
        var month = d.getMonth() + 1;
        month = month < 10 ? '0' + month : month;
        var day = d.getDate();
        day = day < 10 ? '0' + day : day;
        //var scheduletimeforordr = (d.getFullYear() + "-" + month + "-" + day + " " + scheduledslot);*/
		var scheduletimeforordr =$.trim($this.find(".timeslot").html());
		if((typeof scheduletimeforordr =="undefined") || scheduletimeforordr==""){
			alert("please choose the prefered delivery time slot.");
			check_anyerror=1;
			return false;
		}

       
        //var prescriptionObjLength = sectionId + '_file_length';
		var prescriptionObj = sectionId + '_file';
		prescriptionObj = prescriptionObj.replace(/\-/g,'_');
		var prescriptionfile = [];
		if(sessionStorage.getItem(prescriptionObj)!=null){
			prescriptionfile = JSON.parse(sessionStorage.getItem(prescriptionObj));
		}        
        //var prescriptionfilelength = sessionStorage.getItem(prescriptionObjLength);
		//console.log(prescriptionfile);
		//alert(prescriptionfile);
        var newOrderItems = newOrderByCategory($this);
        newOrderItems.push({
            codedid: "TS1801DRHSRA00006",
            brandname: "",
            pharmaname: "",
            doctorname: "",
            item_mrp: parseFloat(deliveryAmount),
            discountamount: 0,
            item_wallet: 0,
            coupon: "",
            code: "",
            priceperunit: "",
            category: "1",
            subcategory_id: "",
            item_code: "TS1801DRHSRA00006",
            quantity: "1",
            type: "2",
            MRP: parseFloat(deliveryAmount),
            gross_amount: parseFloat(deliveryAmount),
            net_amount: parseFloat(deliveryAmount),
            wallet_amount: 0,
            voucher_amount: 0,
            markup_amount: 0,
            cli: 0,
            coupon_amount: 0,
            is_cashless: "",
            invoiceto: "",
            reportto: "1",
            payment_code: "0",
            corporateinvoiceemail: "",
            corporatereportemail: "",
            roleBasedService: 1,
            doctor: "",
            discount_amount: 0,
            old_item_mrp: parseFloat(deliveryAmount),
            old_gross_amount: parseFloat(deliveryAmount),
            old_discount_amount: 0,
            old_net_amount: parseFloat(deliveryAmount),
            manufacturer_id: "",
            manufacturer: "",
            packsize: "",
            prescribed: "1",
            cartDiscountApplied: false,
            discountApplied: false,
            cartCouponApplied: false,
            orderDiscountApplied: false,
            lineItemDiscountAmount: 0,
            cartDiscountApportionedAmount: 0,
            orderApportionedDiscountAmount: 0,
            isReturnable: true,
            isWaiver: false,
			role:9,
			skill:"1"
        });
        totalOrders.push({
            mrn: mrn,
            address_id: addressId,
            order_id: sessionStorage.getItem('orderid'),
            associate_id: vendorid,
            associate_branch_id: "",
            service_type: "2",
            scheduled_date: scheduletimeforordr,
            payment_code: "0",
            creation_type: 1,
            application_no: "",
            surge_amount: 1,
            mode_of_service: 1,
            report_required:((typeof $this.find('#checkboxprescriptionsms').val() != "undefined")?$this.find('#checkboxprescriptionsms').val():0),
            report_delivery_date: "",
            slot_transaction_id: [],
            deliveryCharges: deliveryAmount,
			prescription_images:prescriptionfile,
            /*prescription_file: [
                [
                    prescriptionfile
                ]
            ],*/
            order_item: newOrderItems
        });
        //return false;
    });
	if(check_anyerror==1){
		return false;
	}
	var deduct_the_wallet = 0;
	if(parseFloat(totalUsedWalletAmount)>1){
		deduct_the_wallet = 1;
	}
	var payment_info_coupon_amount=0;
    var _data = {
        orderMode: sessionStorage.getItem('orderMode'),
        mrn: mrn,
        channel: 2,
        source_of_referral: "Outbound",
        referral_id: referedby,
        created_by_id: loginid,
        created_by_name: loginname,
        referral_mrn: referredmrn,
        orders: totalOrders,
		deduct_the_wallet:deduct_the_wallet,
        payment_info: {
            payment_amount: parseFloat(totalnet),
            payment_service: "COD",
            source_type: "",
            payment_mode: 0,
            payment_reference_id: "",
            wallet_amount: parseFloat(totalUsedWalletAmount),
            coupon: coupon,
            //coupon_amount: parseInt(totaldiscount),
            coupon_amount: parseFloat(payment_info_coupon_amount),
            gross_amount: parseFloat(totalgross),
            voucher_assoc_code: "",
            voucher_code: "",
            voucher_amount: parseFloat(totalVoucherAmount)
        }
    }; 
    //console.log(_data);
    //return false;
    _ajaxEventHandler("createTransaction", _data, cbk_createdrugorder,SHOW_LOADER,"POST",orderUrl);
}

function cbk_createdrugorder(response) {
    $(".loader").hide();
    //console.log(response);
    var Obj = response;
    if (typeof response == 'string') {
        Obj = JSON.parse(response);
    }
    if (Obj.status == "1") {
        alert(Obj.message);
		$("section[class='new-order-by-category']").each(function(){
			var prescriptionObj_remove = $(this).attr("data-sectionid")+ '_file';
			prescriptionObj_remove = prescriptionObj_remove.replace(/\-/g,'_');
			if(sessionStorage.getItem(prescriptionObj_remove)!=null){
				sessionStorage.removeItem(prescriptionObj_remove);
			}		
		});
        sessionStorage.setItem('orderid', "");
        sessionStorage.setItem('orderwid', "");
        sessionStorage.setItem('orderwdid', "");
        sessionStorage.setItem("encounterid", "");
        sessionStorage.setItem("prescriptionobj", "");
        sessionStorage.setItem("placedfromdoctorplace", "0");
        $("#l2vreferby").val("");
        var _data = {"orderid": ""}
        _ajaxEventHandler("open_patient_orders", _data, cbk_open_patient_orders,'');
        newordertab();
    } else {
        alert(Obj.message);
    }
}

function newOrderByCategory($this) {
    var lineitems = [];
    $this.find('.rowdrug').each(function () {
        var drugsearchInput = $(this).find('input[name=drugsearch]');
        var drugAmountDetails = $(this).find('input[name=netAmount]');
        var drugName = drugsearchInput.val();
        if ($.trim(drugName) != "") {
            var codedidval = drugsearchInput.attr("data-codedid");
            if ((typeof codedidval != "undefined") && codedidval != "" && codedidval != "0") {
                var couponitems = "";
                if ($.trim($("#l2vCoupanCode").attr("data-code")) == codedidval) {
                    couponitems = $("#l2vCoupanCode").val();
                    couponitem = codedidval;
                }
                lineitems.push({
                    codedid: codedidval,
                    brandname: drugName,
                    pharmaname: $(this).find('input[name="pharmaname"]').val(),
                    doctorname: $(this).find('input[name="doctorname"]').val(),
                    item_mrp: parseFloat($(this).find('input[name="itemmrpval"]').val()),
                    discountamount: parseFloat($(this).find('input[name="discountAmount"]').val()),
                    item_wallet: (drugAmountDetails.attr("data-walletamt")) ? drugAmountDetails.attr("data-walletamt") : 0,
                    coupon: couponitems,
                    code: drugsearchInput.attr("data-id"),
                    priceperunit: drugsearchInput.attr("data-priceperunit"),
                    category: drugsearchInput.attr("data-category"),
                    subcategory_id: "",
                    item_code: codedidval,
                    quantity: $(this).find('input[name="quantity"]').val(),
                    type: "2",
                    MRP: parseFloat($(this).find('input[name="itemmrpval"]').val()),
                    gross_amount: parseFloat($(this).find('input[name="grossamount"]').val()),
                    net_amount: parseFloat($(this).find('input[name="netAmount"]').val()),
                    wallet_amount: parseFloat(drugAmountDetails.attr("data-apportionedwalletamount")),
                    voucher_amount: parseFloat(drugAmountDetails.attr("data-voucherApportionedAmount")),
                    markup_amount: 0,
                    cli: 0,
                    coupon_amount: parseFloat(drugAmountDetails.attr("data-couponValue")),
                    is_cashless: "",
                    invoiceto: "",
                    reportto: drugAmountDetails.attr("data-invoiceTo"),
                    payment_code: "0",
                    corporateinvoiceemail: "",
                    corporatereportemail: "",
                    roleBasedService: 0,
                    doctor: $(this).find('input[name="doctorname"]').val(),
                    discount_amount: parseFloat($(this).find('input[name="discountAmount"]').val()),
                    old_item_mrp: parseFloat(drugAmountDetails.attr("data-MRP")),
                    old_gross_amount: parseFloat(drugAmountDetails.attr("data-grossAmount")),
                    old_discount_amount: parseFloat(drugAmountDetails.attr("data-discountAmount")),
                    old_net_amount: parseFloat(drugAmountDetails.attr("data-netAmount")),
                    manufacturer_id: drugsearchInput.attr("data-manufacturerid"),
                    manufacturer: drugsearchInput.attr("data-manufacturer"),
                    packsize: drugsearchInput.attr("data-packsize"),
                    prescribed: ($(this).find('label[name="l2vsetrxotg"]').data("rxset") == true) ? "1" : "0",
					prescription_required:($(this).find('label[name="l2vsetrxotg"]').data("rxset") == true) ? "1" : "0",
                    cartDiscountApplied: (drugAmountDetails.attr("data-cartdiscountapplied") == "true") ? true : false,
                    discountApplied: (drugAmountDetails.attr("data-discountapplied") == "true") ? true : false,
                    cartCouponApplied: (drugAmountDetails.attr("data-cartcouponapplied") == "true") ? true : false,
                    orderDiscountApplied: (drugAmountDetails.attr("data-orderdiscountapplied") == "true") ? true : false,
                    lineItemDiscountAmount: 0,
                    cartDiscountApportionedAmount: parseFloat(drugAmountDetails.attr("data-cartdiscountapportionedamount")),
                    orderApportionedDiscountAmount: parseFloat(drugAmountDetails.attr("data-orderapportioneddiscountamount")),
                    isReturnable: true,
					isWaiver: false,
					//role:9,
					//skill:"1" prescription_required
                });
            }
        }
    });

    return lineitems;
}

function applywallet() {
    newCheckpricefrommdm();
}

function newordertab() {
	for(var i = 0; i < sessionStorage.length; i++){
		if (sessionStorage.key(i).substring(0,14) == 'new_drug_order') {
			sessionStorage.removeItem(sessionStorage.key(i));
		}
	}
    $("#vendorname").val("0");
    sessionStorage.setItem('orderid', "");
    sessionStorage.setItem('orderwid', "");
    sessionStorage.setItem('orderwdid', "");
    sessionStorage.setItem("encounterid", "");
    sessionStorage.setItem("prescriptionobj", "");
    sessionStorage.setItem("orderstatuscurorder", "");
    sessionStorage.setItem('orderMode', 'new');
    $("#l2vreferby").val("");
    var _data = {"orderid": ""}
    var mrn = sessionStorage.getItem('patientmrn');
    selectedDrugsList = [];
    patient_search('mrn', mrn, 10, 1, cbk_open_patient_records);

    $("#l2orderdetailsdiv").css("display", "none");
    $("#l2ordercreatediv").css("display", "block");
    $("#l2vsearch_custom").show();
    $("#l2v_completeorder").removeClass("active");
    $("#l2v_pendingorder").removeClass("active");
    $("#l2v_neworder").addClass("active");
    $("#l2vwalletbutton").show();
}

function l2vpendingorder() {
    $("#l2edit").hide();
    var mrn = sessionStorage.getItem('patientmrn');
    var _data = {orderStatus: [1, 2], mrn: mrn, NotInActionON: ["orderStatus"], businessId: ["2"],dateFilter:"created_date",sortBy:"DESC"};

    _ajaxEventHandler("orders",_data,cbk_pendingorder,SHOW_LOADER,"POST",operationUrl);
    //pharma_widgets
    showcoupenmmsg = 2;
}

function l2vcompleteorder() {
    $("#l2edit").hide();
    var mrn = sessionStorage.getItem('patientmrn');
    var _data = {orderStatus: [6], mrn: mrn, NotInActionON: ["orderStatus"], businessId: ["2"],dateFilter:"created_date",sortBy:"DESC"};
   
    
    _ajaxEventHandler("orders", _data, cbk_completedorder,SHOW_LOADER,"POST",operationUrl);
    //pharma_widgets
    showcoupenmmsg = 2;
}
 
function cbk_pendingorder(response) {
    renderpendingorder(response);
    $("#l2v_pendingorder").addClass("active");
    $("#l2v_neworder").removeClass("active");
    $("#l2v_completeorder").removeClass("active");
    //console.log(response);
    $(".loader").hide();
}

function cbk_completedorder(response) {
    rendercompletedorder(response);
    $("#l2v_completeorder").addClass("active");
    $("#l2v_neworder").removeClass("active");
    $("#l2v_pendingorder").removeClass("active");
    //console.log(response);
    $(".loader").hide();
}

//single order  view 
function vieworder(order_id) {
    checkSum = '.splitOne';
    var _data = {orderid: order_id};
    _ajaxEventHandler("getorderdetails", _data, showorderview, SHOW_LOADER);
}

function openDetails(contentId, orderId, itemCode) {
    orderId = orderId || false;
    itemCode = itemCode || false;
    $('.hideAllDetails').hide();
    $('.removeActive').removeClass('active');
    $('.innerModal').addClass("active");
    $('#innerModal').addClass('active in');
    if (orderId !== false) {
        $('#log_omorder_id').val(orderId);
        $('#log_item_id').val(itemCode);
    }
    $('#' + contentId).show();
}

function hideAllDetails() {
    $('.hideAllDetails').hide();
}

function showAddressList() {
    var mrn = sessionStorage.getItem("patientmrn");
    var _datamrn = {mrn: mrn};
    _ajaxEventHandler("getAddress", _datamrn, cbk_getAddress,'');
}

function cbk_getAddress(response) {
    if (typeof response == 'string') {
        var patientAddressJson = JSON.parse(response);
    } else {
        var patientAddressJson = response;
    }

    var patientAddressArray = [];
    if (patientAddressJson.status == 1) {
        patientAddressArray = patientAddressJson.data.addressDetails;
    }
    patientAddressList(patientAddressArray);
}

function selectAddress(addressId, modify) {
    modify = modify || false;
    var addressDivId = '#' + addressId;
    var landmark = $(addressDivId).find('.landMarkVal').text();
    var cityVal = $(addressDivId).find('.cityVal').text();
    var areaVal = $(addressDivId).find('.areaVal').text();
    var stateVal = $(addressDivId).find('.stateVal').text();
    var zipcodeVal = $(addressDivId).find('.zipcodeVal').text();
    var countryVal = sessionStorage.getItem("country");
    var latitude = $(addressDivId).find('.latitude').text();
    var longitude = $(addressDivId).find('.logitude').text();
    var addressNickName = $(addressDivId).find('.addressNickName').text();
    var district = $(addressDivId).find('.districtVal').text();
    var addressVal = $(addressDivId).find('.addressVal').text();
    var address = addressVal + ", " + areaVal + ", " + cityVal + ", " + stateVal + ", " + countryVal + ", " + zipcodeVal;
    var contactno = sessionStorage.getItem("contactno");
    var alternetcontactno = sessionStorage.getItem("alternetcontactno");
    if (modify == true) {
        $('#address_nick_name').val(addressNickName);
        $('#address1').val(addressVal);
        $('#administrative_area_level_1').val(stateVal);
        $('#locality').val(cityVal);
        $('#route').val(areaVal);
        $('#postal_code').val(zipcodeVal);
        $('#autocomplete').val(landmark);
        $('#pcontactno').val(contactno);
        $('#latitude').val(latitude);
        $('#longitude').val(longitude);
        $('#alternetcontactno').val(alternetcontactno);
        $('.update_address_btn').html('Update Address');
    } else {
        sessionStorage.setItem("landmark", landmark);
        sessionStorage.setItem("city", cityVal);
        sessionStorage.setItem("district", district);
        sessionStorage.setItem("state", stateVal);
        sessionStorage.setItem("country", countryVal);
        sessionStorage.setItem("zipcode", zipcodeVal);
        sessionStorage.setItem("address_nickname", addressNickName);
        sessionStorage.setItem("address", address);
        sessionStorage.setItem("address_id", addressId);
        sessionStorage.setItem("address", address);
        sessionStorage.setItem("address_id", addressId);
        sessionStorage.setItem("latitude", latitude);
        sessionStorage.setItem("longitude", longitude);
        $('#showdelvaddress').html(address);
        $('#addressListModal').modal('hide');
    }
    $('#selected_address_id').val(addressId);
}

function openprescriptionmadal(prescriptionId) {
    $(".loader").hide();
    renderModalPrescription(prescriptionId);
}

function clearAddressData() {
    $('.clearAddressData').val('');
    $('.update_address_btn').text('Save Address');
    $('#selected_address_id').val('');
}


function reorderfun(orderid, type) {
    if (type == 0) {
        sessionStorage.setItem('orderid', orderid);
    }
    sessionStorage.setItem("encounterid", "");
    $("#l2vopenprescriptionmadal").css("display", "none");
    var _data = {"orderid": orderid};
    _ajaxEventHandler("getorderdetails", _data, cbk_open_patient_orders,'');
    $("#l2vsearch_custom").show();
    $("#l2v_completeorder").removeClass("active");
    $("#l2v_pendingorder").removeClass("active");
    $("#l2v_neworder").addClass("active");
    showcoupenmmsg = 2;
}

function editOrderDetails(order_id,orderType) {
    orderType = orderType || 'update';
    sessionStorage.setItem('orderMode', orderType);
    sessionStorage.setItem('orderid', order_id);
    var _data = {orderid: order_id};
    _ajaxEventHandler("getorderdetails", _data, editOrderHtml, SHOW_LOADER);
}

//order assign to vendor 
function assignvendor(omorder_id) {
    var vendor_id = $('#vendor').val();
    var vendor_name = $('#vendor option:selected').text();
    var vendoraddress = $("#vendor option:selected").data("address");
    var loginid = sessionStorage.getItem("loginid");
    var loginname = sessionStorage.getItem("loginname");
    var _data = {
        order_id: omorder_id,
        actionById: loginid,
        actionByName: loginname,
        source: "L2",
        comment: "",
        reason: "Assigned Vendor",
        status: 21, //*
        associate_id: vendor_id
    };

    if (vendor_id == '' || vendor_name == '') {
        alert("Plese Select All Fileds");
        return false;
    }
    //console.log(_data);
    _ajaxEventHandler("order/change/status", _data, hidecbk, SHOW_LOADER,"POST",operationUrl);


}

function hidecbk() {
    location.reload();
}

function trackOrder(orderid) {
    if (orderid == "") {
        alert("Please Select the Correct Order.")
    } else {
        var _data = {order_id: orderid};
        _ajaxEventHandler('ordertrack', _data, trackOrderView, SHOW_LOADER,"POST","operation.php/v1/");
    }
}

function orderlogsubmit() {
    var omorder_id = $('#log_omorder_id').val();
    var item_ids = $('#log_item_id').val();
    var logreasons = $('#orderlogreasons').val();
    var role = 'L2Pharma';
    if ($.trim(logreasons) == '') {
        alert('Kindly fill Log info!');
        //return false;
    } else {
        var vendorid = sessionStorage.getItem('loginid');
        var vendorname = sessionStorage.getItem('loginname');
        var _data = {omorder_id: omorder_id, item_ids: item_ids, rejectreasons: logreasons, vendorid: vendorid, vendorname: vendorname, role: role};
        //console.log(_data); return false;

        _ajaxEventHandler("create_log", _data, logorderhide, SHOW_LOADER);
    }
}
function logorderhide() {
    alert('Log submitted successfully.');
    $('.hideAllDetails').hide();
    $('.removeActive').removeClass('active');
    $('.veiwOrderDetails').addClass("active");
    $('#veiwOrderDetails').addClass('active in');
	$(".loader").hide();
}

function showwallethistory(mrn){
	var _data = {mrn:mrn};
	_ajaxEventHandler("wallet_transaction_history",_data,cbk_wallet_transction_history,NO_SHOW_LOADER);
}

function open_cp_prescription(mrn){ 
	var _data = {mrn:mrn};
	_ajaxEventHandler("getPrescriptionCP",_data,cbk_getprescriptionCP);
}

function open_3monthprecription(mrn){
	var _data = {mrn:mrn};
	var data=_ajaxEventHandler("monthviseprecription",_data,past_prescriptionview,SHOW_LOADER);
}

function open_refillbymrn(mrn){
	var _data = {mrn:mrn};
	var data=_ajaxEventHandler("reminder_request",_data,refillviewbymrn,SHOW_LOADER);
}

function open_slot_modal(sectionId){
    var header_data = "";
    var body_data = "";
    var itemcode="";
	activeSection = sectionId;
	$('.'+sectionId).find("input[name=drugsearch]").each(function (){
		itemcode = $(this).attr("data-codedid");
		return false; 
		//break;
	});
	
	if($.trim(itemcode)==""){
		alert("Please enter test name");	
		return false; 
	}
	if($.trim(sessionStorage.getItem("zipcode"))==""){
		alert("Please provide proper pincode.");
		return false; 
	}
    //var tommorowDate = $("#selecttimeslot").attr("data-scheduled_date").split(" ");     
    //var tommorowDate = $("#selecttimeslot").attr("data-scheduled_date").split(" ");     
    header_data +=  '<h4 class="modal-title" id="myModalLabel">Choose the slot</h4><span id="walletbal"></span>';	 
    body_data +='<div>'+
	"<div class='input-group date datepicker orderdatediv' id='orderdatediv'>"+
	"<input id='mainorderdate' type='text' onchange='fetch_slot();' class='form-control' value='"+tommorowDate()+"' readonly=''>"+
	"<span class='input-group-addon'>"+
	"<i class='fa fa-calendar' aria-hidden='true'></i>"+
	"</span>"+
	"</div>"+
	"</div>"+
	'<div id="londing_view">'+
	'<div class="loader" style="display:block"></div>'+
	'</div>'+
	'<div id="slotdiv"></div>';          
    	
    $("#myModalLabel").html(header_data);
    $("#trackresult").html(body_data);
    $("#Modal_for_all").modal("show");
    //$("#mainorderdate").val();
    fetch_slot(itemcode,tommorowDate());	
}

function fetch_slot(itemcode,defaultDateSlot=""){
	if(itemcode==""){
		$("input[name=item_reject]").each(function (){			
			itemcode = $(this).val;
			return false; 
			//break;
		});
		if($.trim(itemcode)==""){
			alert("Please enter test name");	
			return false; 
		}
	}
	if(defaultDateSlot==""){
		defaultDateSlot = $("#mainorderdate").val();
	}
	
	var _data = {
		from_date:defaultDateSlot, 
		to_date:defaultDateSlot,
		business_id:"2",
		sub_business_id:"9",
		service_did:itemcode,
		//pop_id:$("#selecttimeslot").attr("data-popid"),
		patient_mrn:$.trim(sessionStorage.getItem("patientmrn")),
		patient_age:$("#selecttimeslot").attr("age"),
		patient_gender:"",
		preferred_officer:"",
		pin_code:$.trim(sessionStorage.getItem("zipcode")),
		order_latitude:$.trim(sessionStorage.getItem("latitude")),
		order_longitude:$.trim(sessionStorage.getItem("longitude"))
	}
	//console.log(_data);
	_ajaxEventHandler('fetch_slots', _data, response_fetch_slot, SHOW_LOADER,"POST","operation.php/v1/");
}

function response_fetch_slot(response){
	//console.log(response);
	$(".loader").hide();
	var senddate = $("#mainorderdate").val();
        var htmlstring="";
		if(response.success==="1"){
		$.each(response.data[senddate], function (key, val) {
			if(val.is_booked!=1){
				var from_time=senddate+" "+val.from_time;
				var to_time=senddate+" "+val.to_time;
				htmlstring+="<button class='btn btn-success' style='margin:5px;' onclick='booktheslot(\""+val.transaction_id+"\",\""+senddate+"\",\""+val.from_time+"\",\""+val.to_time+"\")'>"+datetime24to12(from_time)+" - "+datetime24to12(to_time)+"</button>";
			}		   
		});
		if(htmlstring==""){
			htmlstring="<br><label>Slots are not available.</label>";
		}
		$("#slotdiv").html(htmlstring);
	}else{
		//console.log(response.message);
		alert(response.message);
	}
}

function booktheslot(transaction_id,selected_date,from_time,to_time){	
	$('.'+activeSection).find(".timeslot").attr("data_starttime",from_time);
    $('.'+activeSection).find(".timeslot").attr("data_endtime",to_time);
	$('.'+activeSection).find(".timeslot").attr("data_date",selected_date);
	$('.'+activeSection).find(".timeslot").attr("data_trasactionid",transaction_id);
	$('.'+activeSection).find(".timeslot").html(selected_date+" "+to_time);
	$("#Modal_for_all").modal("hide");
	//"bookedselecttime"
}

function prescriptionLinkSMS(orderid,componenetno){
	var _data = {
		order_id:orderid,
		component_id:componenetno
	};
	var data=_ajaxEventHandler("prescription-upload-link",_data,cbk_prescriptionLinkSMS,SHOW_LOADER,"POST","operation.php/v1/orders/notification/send/");	
}

function cbk_prescriptionLinkSMS(result){
	console.log(result);
	console.log(result.success);
	if(result.success==1){
		alert(result.message);
	}else{
		alert(result.message);
	}
	$(".loader").hide();
}

function cancelorder(orderid){
	var loginid = sessionStorage.getItem("loginid");
    var loginname = sessionStorage.getItem("loginname");
	var r = prompt("Please enter Cancel Reason:", "");
	if(r== null || r==""){
		
	}
	else {
		var _data = {
			order_id:[orderid],
			reason:r,
			reason_text:r,
			comment:"cancel",
			actionById:loginid,
			actionByName:loginname,
			scheduled_date:"",
			reasonType:1,
			source:6,
			categoryId:"1",
			subCategoryId:"2",
			role:"customer",
		};
		var data=_ajaxEventHandler("orderCancel",_data,cbk_cancelorder,SHOW_LOADER,"POST","operation.php/v1/");
	}
}

function cbk_cancelorder(result){
	console.log(result);
}

function updateDrugOrder(){
	var referedby = "";
    var sourceofreferral = "";
    var referredmrn = "";
    // 1 - yes 2 - no 
    var couponitem = "";
    if ($("#l2vreferby").val() == "") {
        //alert('Please enter referred by, if no referred by is there please enter 9999.');
        //return;
    } else {
        referedby = $("#l2vreferby").val();
        if ($("#referedbylist option[value='" + referedby + "']").length > 0 || referedby == "9999") {
        } else {
            alert('Invalid officer id.');
            return;
        }
    }

    if ($("#l2vsourcereferral option:selected").val() == "") {
        alert('Please select source.');
        return;
    } else {
        sourceofreferral = $("#l2vsourcereferral option:selected").val();
    }

    referredmrn = $("#l2vsreferbymrn").val();
    // for postal code
    if ($("#postal_code").val() == "" || $("#postal_code").val() == 0 || $("#postal_code").val() == "0") {
        alert('Please enter postal code');
        return;
    }
	
    var loginid = sessionStorage.getItem("loginid");
    var loginname = sessionStorage.getItem("loginname");
    var name = sessionStorage.getItem('displayname');
    var salutation = sessionStorage.getItem("salutation");
    var patientfname = sessionStorage.getItem('patientfname');
    var patientmname = sessionStorage.getItem('patientmname');
    var patientlname = sessionStorage.getItem('patientlname');
    var age = sessionStorage.getItem('displayage');
    var gender = sessionStorage.getItem('patientgender');
    var contactno = sessionStorage.getItem('contactno');
    var alternetcontactno = sessionStorage.getItem('alternetcontactno');
    if (contactno == "") {
        contactno = sessionStorage.getItem('contactno');
    }
    if (alternetcontactno == "") {
        alternetcontactno = (sessionStorage.getItem('alternetcontactno') == "Array") ? "" : sessionStorage.getItem('alternetcontactno');
    }
    var email = sessionStorage.getItem('email');
    var tagsfororder = (sessionStorage.getItem('tagsfororder') == null) ? "" : sessionStorage.getItem('tagsfororder');
    //var referedby=$.trim($("#l2vreferby").val());

    var doorno = "";
    var popname = sessionStorage.getItem('popname');
    var facility_id = sessionStorage.getItem('facility_id');
    var home_pop = sessionStorage.getItem('home_popname');
    var home_fc_id = sessionStorage.getItem('home_facility_id');
    var landmark = sessionStorage.getItem('landmark');
    var address1 = sessionStorage.getItem('address');
    var area = sessionStorage.getItem('area');
    var area = sessionStorage.getItem('area');
    var countrydistrict = sessionStorage.getItem('district');
    var state = sessionStorage.getItem('state');
    var zipcode = sessionStorage.getItem('zipcode');
    var longitude = sessionStorage.getItem('longitude');
    var latitude = sessionStorage.getItem('latitude');
    var addressId = sessionStorage.getItem('address_id');
    var payment_method = $("#payment_method option:selected").val();
    //var coupon = $("#coupon").val();
    var coupon = $("#l2vCoupanCode").val();
    if (showcoupenmmsg == 0) {
        coupon = "";
    }

    //for call
    var mrn = sessionStorage.getItem('patientmrn');
    var lead_id = (typeof sessionStorage.getItem('lead_id') != "undefined") ? sessionStorage.getItem('lead_id') : "";
    var callNumber = sessionStorage.getItem('callNumber');
    var orderid = sessionStorage.getItem('orderid');
    var encounterid = sessionStorage.getItem('encounterid');
    var patientid = sessionStorage.getItem('patientid');
    var orderwid = sessionStorage.getItem('orderwid');
    var orderwdid = sessionStorage.getItem('orderwdid');
    var doctorid = sessionStorage.getItem('doctorid');
    var doctorname = sessionStorage.getItem('doctorname');
    var mrncoporateid = sessionStorage.getItem('mrncoporateid');
    var mrncoporatename = sessionStorage.getItem('mrncoporatename');
    var ordersmscreate = (typeof (sessionStorage.getItem("ordersmscreate")) == "undefined") ? "0" : sessionStorage.getItem("ordersmscreate");
    var ezzetab_sms = sessionStorage.getItem('ezzetab_sms');
    var placedfromdoctorplace = sessionStorage.getItem("placedfromdoctorplace");
    var orderstatuscurorder = sessionStorage.getItem("orderstatuscurorder");
    var l2vprepaidamountcheck = $("#l2vprepaidamount").html();

    var medicine_delivery = 0;
    var deliveryarray = [];
    if ($("#medicine_delivery").val() == "1") {
        medicine_delivery = $("#medicine_delivery").attr("data-item_mrp");
        deliveryarray.push({
            item_code: $("#medicine_delivery").attr("data-codedid"),
            quantity: "1",
            gross_amount: $("#medicine_delivery").attr("data-item_gross"),
            item_mrp: $("#medicine_delivery").attr("data-item_mrp"),
            discount_amount: $("#medicine_delivery").attr("data-item_discount"),
            net_amount: $("#medicine_delivery").attr("data-item_net"),
            ignoreToPartner: $("#medicine_delivery").attr("data-ignoreToPartner")
        });
    }

    var totalOrders = [];
    var totalgross = '0.00';
    var totalnet = '0.00';
    var totaldiscount = '0.00';
    var totalUsedWalletAmount = '0.00';
    var totalVoucherAmount = '0.00';
	var check_anyerror = 0; 
    $('.new-order-by-category').each(function () {
        $this = $(this);
        var sectionId = $this.attr('data-sectionid');
        //check any rx item is available(set prescription later and send message) or not (set vendor) 
        var rxisavailable = 0;
        var otgisavailable = 0;
        var sendsmsforpprescription = 0;
        $this.find('label[name=l2vsetrxotg]').each(function () {
            if ($.trim($(this).attr("data-rxset")) == "true") {
                rxisavailable = rxisavailable + 1;
            }
        });
        if (rxisavailable < 1) {
            if ($("#vendorname").val() === "0") {
                alert("Please select vendor.");
				check_anyerror=1;
                return;
            }
        }
        else if (sessionStorage.getItem("orderstatuscurorder") == "24") {
            if ($("#vendorname").val() === "0") {
                alert("Please select vendor.");
				check_anyerror=1;
                return;
            }
            if (sessionStorage.getItem(sectionId) == "") {
                var r = confirm("Prescription file is required. Do you have the prescription file ??");
                if (r == true) {
                    l2prescptionuploadl2();
					check_anyerror=1;
                    return;
                }
            }
        } else {
            if (sessionStorage.getItem("encounterid") != "" && sessionStorage.getItem("orderstatusencounterid") != "6") {
                sendsmsforpprescription = 0;
            } else {
                if ((sessionStorage.getItem("encounterid") == "") && (sessionStorage.getItem(sectionId) != "")) {
                    sendsmsforpprescription = 0;
                } else {
                    sendsmsforpprescription = 1;
                }
            }
        }

        var vendorid = $this.find("#vendorname option:selected").val();
        var vendorname = $this.find("#vendorname option:selected").text();
        var vendoraddress = $this.find("#vendorname option:selected").attr("data-address");
        if (vendorid == "0") {
            var vendorid = "";
            var vendorname = "";
        }


        var currentNetAmount = $.trim($this.find("#l2vitemtotalamount").html());
        if (currentNetAmount != '') {
            totalnet = parseFloat(totalnet) + parseFloat(currentNetAmount);
            totalnet = parseFloat(totalnet).toFixed(2);
        }

        var deliveryAmount = $.trim($this.find("#l2vdeliverycharge").html());
        if (deliveryAmount != '') {
            deliveryAmount = parseFloat(deliveryAmount).toFixed(2);
        }


        var currentGrossAmount = $.trim($this.find("#l2vitemtotalamountgross").html());
        if (currentGrossAmount != '') {
            totalgross = parseFloat(totalgross) + parseFloat(currentGrossAmount);
            totalgross = parseFloat(totalgross).toFixed(2);
        }


        var currentDiscountAmount = $.trim($this.find("#l2vitemtotalamountdiscount").html());
        if (currentDiscountAmount != '') {
            totaldiscount = parseFloat(totaldiscount) + parseFloat(currentDiscountAmount);
            totaldiscount = parseFloat(totaldiscount).toFixed(2);
        }
		
		//var payment_info_coupon_amount = 0;
        /*if (currentDiscountAmount != '') {
            totaldiscount = parseFloat(totaldiscount) + parseFloat(currentDiscountAmount);
            totaldiscount = parseFloat(totaldiscount).toFixed(2);
        }*/

        var currentUsedWalletAmount = $.trim($this.find("#l2vitemwalletamount").html());
        if (currentUsedWalletAmount != '') {
            totalUsedWalletAmount = parseFloat(totalUsedWalletAmount) + parseFloat(currentUsedWalletAmount);
            totalUsedWalletAmount = parseFloat(totalUsedWalletAmount).toFixed(2);
        }

        var currentVoucherAmount = $.trim($this.find('#l2vitemtotalamount').attr('data-voucherAmount'));
        if (currentVoucherAmount != '') {
            totalVoucherAmount = parseFloat(totalVoucherAmount) + parseFloat(currentVoucherAmount);
            totalVoucherAmount = parseFloat(totalVoucherAmount).toFixed(2);
        }



        //getting current date
        /*var estdate = $this.find("#mainorderdate").val();
        var date2 = estdate.split(" ");
        var date3 = date2[0].split("-");
        var d1 = date3[0] + "-" + date3[1] + "-" + date3[2];
        var d = new Date(d1);
        var scheduledslot = $this.find("#scheduledslot option:selected").val();
        //console.log(scheduledslot);
        if (scheduledslot == "00:00:00") {
            alert("Please select time slot.");
            return;
        }
        var month = d.getMonth() + 1;
        month = month < 10 ? '0' + month : month;
        var day = d.getDate();
        day = day < 10 ? '0' + day : day;
        //var scheduletimeforordr = (d.getFullYear() + "-" + month + "-" + day + " " + scheduledslot);*/
		var scheduletimeforordr =$.trim($this.find(".timeslot").html());
		if((typeof scheduletimeforordr =="undefined") || scheduletimeforordr==""){
			alert("please choose the prefered delivery time slot.");
			check_anyerror=1;
			return false;
		}

       
        //var prescriptionObjLength = sectionId + '_file_length';
		var prescriptionObj = sectionId + '_file';
		prescriptionObj = prescriptionObj.replace(/\-/g,'_');
		var prescriptionfile = [];
		if(sessionStorage.getItem(prescriptionObj)!=null){
			prescriptionfile = JSON.parse(sessionStorage.getItem(prescriptionObj));
		}        
        //var prescriptionfilelength = sessionStorage.getItem(prescriptionObjLength);
		//console.log(prescriptionfile);
		//alert(prescriptionfile);
        var newOrderItems = newOrderByCategory($this);
        newOrderItems.push({
            codedid: "TS1801DRHSRA00006",
			itemname:"DDO",
            brandname: "",
            pharmaname: "",
            doctorname: "",
            item_mrp: parseFloat(deliveryAmount),
            discountamount: 0,
            item_wallet: 0,
            coupon: "",
            code: "",
            priceperunit: "",
            category: "1",
            subcategory_id: "",
            item_code: "TS1801DRHSRA00006",
            quantity: "1",
            type: "2",
            MRP: parseFloat(deliveryAmount),
            gross_amount: parseFloat(deliveryAmount),
            net_amount: parseFloat(deliveryAmount),
            wallet_amount: 0,
            voucher_amount: 0,
            markup_amount: 0,
            cli: 0,
            coupon_amount: 0,
            is_cashless: "",
            invoiceto: "",
            reportto: "1",
            payment_code: "0",
            corporateinvoiceemail: "",
            corporatereportemail: "",
            roleBasedService: 1,
            doctor: "",
            discount_amount: 0,
            old_item_mrp: parseFloat(deliveryAmount),
            old_gross_amount: parseFloat(deliveryAmount),
            old_discount_amount: 0,
            old_net_amount: parseFloat(deliveryAmount),
            manufacturer_id: "",
            manufacturer: "",
            packsize: "",
            prescribed: "1",
            cartDiscountApplied: false,
            discountApplied: false,
            cartCouponApplied: false,
            orderDiscountApplied: false,
            lineItemDiscountAmount: 0,
            cartDiscountApportionedAmount: 0,
            orderApportionedDiscountAmount: 0,
            isReturnable: true,
            isWaiver: false,
			role:9,
			skill:"1"
        });
        totalOrders.push({
            mrn: mrn,
			order_id: sessionStorage.getItem('orderid'),
            address_id: addressId,         
            associate_id: vendorid,
            associate_branch_id: "",
            service_type: "2",
            scheduled_date: scheduletimeforordr,
            payment_code: "0",
            creation_type: 1,
            application_no: "",
            surge_amount: 1,
            mode_of_service: 1,
            report_required:((typeof $this.find('#checkboxprescriptionsms').val() != "undefined")?$this.find('#checkboxprescriptionsms').val():0),
            report_delivery_date: "",
            slot_transaction_id: [],
            deliveryCharges: deliveryAmount,
			prescription_images:prescriptionfile,
            /*prescription_file: [
                [
                    prescriptionfile
                ]
            ],*/
            order_item: newOrderItems
        });
        //return false;
    });
	if(check_anyerror==1){
		return false;
	}
	var deduct_the_wallet = 0;
	if(parseFloat(totalUsedWalletAmount)>1){
		deduct_the_wallet = 1;
	}
	var payment_info_coupon_amount=0;
    var _data = {
        orderMode: sessionStorage.getItem('orderMode'),		
        mrn: mrn,
        channel: 2,
        source_of_referral: "Outbound",
        referral_id: referedby,
        created_by_id: loginid,
        created_by_name: loginname,
        referral_mrn: referredmrn,
        orders: totalOrders,
		deduct_the_wallet:deduct_the_wallet,
        payment_info: {
            payment_amount: parseFloat(totalnet),
            payment_service: "COD",
            source_type: "",
            payment_mode: 0,
            payment_reference_id: "",
            wallet_amount: parseFloat(totalUsedWalletAmount),
            coupon: coupon,
            //coupon_amount: parseInt(totaldiscount),
            coupon_amount: parseFloat(payment_info_coupon_amount),
            gross_amount: parseFloat(totalgross),
            voucher_assoc_code: "",
            voucher_code: "",
            voucher_amount: parseFloat(totalVoucherAmount)
        }
    }; 
    //console.log(_data);
    //return false;
	console.log(_data);
	
    _ajaxEventHandler("updateOrder", _data, cbk_updateRejectedOrder,SHOW_LOADER,"POST");
}

function cbk_updateRejectedOrder(response){
	$(".loader").hide();
    //console.log(response);
    var Obj = response;
    if (typeof response == 'string') {
        Obj = JSON.parse(response);
    }
    if (Obj.status == "1") {
        alert(Obj.message);
		$("section[class='new-order-by-category']").each(function(){
			var prescriptionObj_remove = $(this).attr("data-sectionid")+ '_file';
			prescriptionObj_remove = prescriptionObj_remove.replace(/\-/g,'_');
			if(sessionStorage.getItem(prescriptionObj_remove)!=null){
				sessionStorage.removeItem(prescriptionObj_remove);
			}		
		});
        sessionStorage.setItem('orderid', "");
        sessionStorage.setItem('orderwid', "");
        sessionStorage.setItem('orderwdid', "");
        sessionStorage.setItem("encounterid", "");
        sessionStorage.setItem("prescriptionobj", "");
        sessionStorage.setItem("placedfromdoctorplace", "0");
        $("#l2vreferby").val("");
        var _data = {"orderid": ""}
        _ajaxEventHandler("open_patient_orders", _data, cbk_open_patient_orders,'');
        newordertab();
    } else {
        alert(Obj.message);
    }
}