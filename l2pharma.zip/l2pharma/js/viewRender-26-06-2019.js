function renderMenu(action) {
    var htmlBanner = "";
    htmlBanner = "<article class='patient_details'>" +
            "<div class='col-md-1 mp'>" +
            "<a href='#' class='back_btn'>Back</a>" +
            "</div>" +
            "<div class='col-md-4'><h1>Patient Dashboard</h1></div>" +
            "</article>";
    $("#pharma_menu").html(htmlBanner);

}

//function pharma_widgets(){
function render_actiontab_for_mrn() {
    var htmlBanner = "<div class='col-md-12' style='margin-top:8px;'><button class='new_order active' id='l2v_neworder'  onclick='newordertab();'> New Order </button><button class='new_order' id='l2v_pendingorder' onclick='l2vpendingorder();'> Pending Order </button><button class='new_order' id='l2v_completeorder' onclick='l2vcompleteorder();'> Completed Order </button><button class='new_order pull-right' style='color: white; background : #81b354;' id='previousPage' onclick='hidecbk();'> Back </button></div>";
    $("#pharma_widgets").html(htmlBanner);
}


function dashboard_widgets_render(counts){ 
    counts = counts || '';
    var htmlBannerup = "<div class='container-fluid'>" +
            "<article class='medicine_details'>" +
            "<div class='col-md-8 col-sm-8 col-xs-8'>" +
            "<h1 style='font-size:20px;'>Medicine Orders</h1>" +
            "</div>" +
            "<div class='col-md-4 col-sm-4'>" +
            /*"<!--input  type='hidden' id='exporttype' value='Ordersdata' name='type'>" +
            "<a href='#' onclick='exportcsv()'  class='export_csv_btn pull-right'>Export CSV</a>" +
            "<a class='export_csv_btn pull-right' style='background:#75AB59; border:1px #75AB59; border-radius:3px 3px; line-height:22px; font-weight: bold;' target='_blank' href='" + sessionStorage.getItem('callbacklink') + "'> &nbsp; Call Back Request&nbsp; </a-->" +*/
            "</div>" +
            "</article>" +
            "</div>";

    var htmlBanner = "";
    htmlBanner = "<div class='container-fluid custom_pop_rx'><ul class='nav nav-tabs cust_nav'>" +
            "<li class='active'>" +
            "<a onclick=allOrders('all_orders','allordersview',false,1,true); aria-controls='profile' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-shopping-cart ' aria-hidden='true'></i>" +
            "All Orders (<span id='allorderscount'>0</span>)" +
            "</a>" +
            "</li>" +
            "<li role='presentation'>" +
            "<a onclick=allOrders('rx_pending','allordersview',false,1,true); aria-controls='profile' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-check' aria-hidden='true'></i>" +
            "Rx Pending (<span id='rxuploadedpendingcount'>0</span>)" +
            "</a>" +
            "</li>" +
            "<li  >" +
            "<a onclick=allOrders('prescription_upload','allordersview',false,1,true); aria-controls='profile' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-shopping-cart ' aria-hidden='true'></i>" +
            "Rx Uploaded (<span id='rxuploadedcount'>0</span>)" +
            "</a>" +
            "</li>" +
			"<li role='presentation'>" +
            "<a onclick=allOrders('tobeassigned','allordersview',false,1,true); aria-controls='profile' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-print' aria-hidden='true'></i>" +
            "To Be Assigned (<span id='tobeassignedcount'>0</span>)" +
            "</a>" +
            "</li>" +
            "<li role='presentation' >" +
            "<a onclick=allOrders('assignvendororders','allordersview',false,1,true); aria-controls='profile' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-print' aria-hidden='true'></i>" +
            "Assigned to Vendor (<span id='assignvendorcount'>0</span>)" +
            "</a>" +
            "</li>" +
            "<li role='presentation'>" +
            "<a onclick=allOrders('rejected','allordersview',false,1,true); aria-controls='profile' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-print' aria-hidden='true'></i>" +
            "Rejected Orders (<span id='rejectedcount'>0</span>)" +
            "</a>" +
            "</li>" +
            "<!--li role='presentation'>" +
            "<a onclick=allOrders('rx_not_upload','allordersview',false,1,true); aria-controls='profile' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-print' aria-hidden='true'></i>" +
            "Rx Not Uploaded(<span id='rxnotuploadedcount'>0</span>)" +
            "</a>" +
            "</li-->" +
            "<li role='presentation'>" +
            "<a onclick=allOrders('reminder_request','refillview',false,1,true); aria-controls='profile' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-print' aria-hidden='true'></i>" +
            "Refill Request" +
            "</a>" +
            "</li>" +
            "<li role='presentation'>" +
            "<div class='input-group' style='max-width:266px;'>" +
            "<select class='form-control' id='patientsearchtype' style='width:90px; background:#569D98; color:#fff;'>" +
            "<option value='mrn'>MRN</option>" +
            "<option value='mobile'>Mobile no</option>" +
            "<select>" +
            "<input type='number' class='form-control' id='patientsearchvalue' placeholder='Enter Number' style='width:125px;'>" +
            "<span class='input-group-addon' onclick='open_patient_details();' id='basic-addon2' style='width:50px; background:#569D98; color:#fff;'>Go</span>" +
            "<!--input type='number' class='form-control' id='new_ordermrn' placeholder='enter mrn'>" +
            "<span class='input-group-addon' onclick='new_ordermrn();' style='background:#569D98; color:#fff;' id='basic-addon2'>New Order</span-->" +
            "</div>" +
            "<!--input type='text' class='form-control' style='width:120px; color:#000;' placeholder='Enter mrn'>" +
            "<button class='btn btn-success' style='width:90px;' onclick='allOrders('rx_not_upload','allordersview',false,1,true);'> New Order </button-->" +
            "</li>" +
            "</ul></div>";
    //$("#pharma_menu").html(htmlBannerup);
    $("#pharma_widgets").html(htmlBanner);
}

function dashboard_search_render(condition) {
    condition = condition || '';
    var htmlBanner = "";
    htmlBanner =
            "<div class='container-fluid'>" +
            "<section class='custom_search'>" +
            "<article class='col-md-12 col-sm-12 col-xs-12'>" +
            "<div class='col-md-1 col-sm-1 col-xs-12 mnp'>" +
            "<div class='form-group'>" +
            "<label>City :</label>" +
            "<select name='city' id='city' class='form-control new-status'>" +
            "<option value=''>Select City</option>" +
            "<option value='New Delhi'>New Delhi</option>" +
            "<option value='New Delhi'>Delhi</option>" +
            "<option value='Gurgaon'>Gurgaon</option>" +
            "<option value='Guntur'>Guntur</option>" +
            "<option value='Hyderabad'>Hyderabad</option>" +
            "<option value='Kurnool'>Kurnool</option>" +
            "<option value='Nellore'>Nellore</option>" +
            "<option value='Noida'>Noida</option>" +
            "<option value='Rajahmundry'>Rajahmundry</option>" +
            "<option value='Secunderabad'>Secunderabad</option>" +
            "<option value='Tirupati'>Tirupati</option>" +
            "<option value='Vijayawada'>Vijayawada</option>" +
            "<option value='Visakhapatnam'>Visakhapatnam</option>" +
            "<option value='Warangal'>Warangal</option>" +
            "</select>" +
            "</div>" +
            "</div>" +            
            "<div class='col-md-2 col-sm-6 col-xs-12 mp'>" +
            "<div class='form-group'>" +
            "<label>From Date :</label>" +
            "<div class='input-group' class='datepicker'>" +
            "<input type='text' id='fromdate' class='form-control datepicker' placeholder='DD/MM/YYYY'>" +
            "<span class='datepicker1'>" +
            "<span class='glyphicon glyphicon-calendar cust_cal'></span>" +
            "</span>" +
            "</div>" +
            "</div>" +
            "</div>" +
            "<div class='col-md-2 col-sm-1 col-xs-12 mp'>" +
            "<div class='form-group'>" +
            "<label>To Date :</label>" +
            "<div class='input-group' class='datepicker'>" +
            "<input  type='text' id='todate' class='form-control datepicker' placeholder='DD/MM/YYYY'>" +
            "<span class='datepicker2'>" +
            "<span class='glyphicon glyphicon-calendar cust_cal'></span>" +
            "</span>" +
            "</div>" +
            "</div>" +
            "</div>" +
            "<div class='col-md-1 col-sm-1 col-xs-12 mp'>" +
            "<div class='form-group'>" +
            "<label>Order Status :</label>" +
            "<select  name='job_name' id='status_serach' class='form-control new-status'>" +
            "<option value=''>--Select--</option>" +
            "<option value='0'>Unassigned</option>" +
            "<option value='1'>Assigned</option>" +
            "<option value='2'>Accepted</option>" +
            "<option value='3'>Started</option>" +
            "<option value='4'>Reached</option>" +
            "<option value='5'>InProgress</option>" +
            "<option value='6'>Completed</option>" +
            "<option value='7'>Rescheduled</option>" +
            "<option value='8'>Cancelled</option>" +
            "<option value='24'>Rejected</option>" +
            "<option value='15'>Request for cancellation</option>" +
            "<option value='16'>Request for reschedule</option>" +
            "<option value='17'>Draft</option>" +
            "<option value='18'>Vendor Requested for Pickup</option>" +
            "<option value='21'>L2 Assigned to Vendor</option>" +
            "</select>" +
            "</div>" +
            "</div>" +
            "<div class='col-md-2 col-sm-6 col-xs-12'>" +
            "<label>Vendor Pharma Name :</label>" +
            "<select id='vendor_serach' name='job_name' class='form-control new-status'>" +
            "<option value='0'>Select Vendor</option>" +
            "<option value='1161'>Mediworld</option>" +
            "<option value='945'>Health mitra</option>" +
            "<option value='2615'>A N Apollo Pharmacy</option>" +
            "<option value='949'>Healthskool Clinic &amp; Pharmacy</option>" +
            "<option value='5564'>New Health Plus</option>" +
            "</select>" +
            "</div>" +
            "<div class='col-md-1 col-sm-6 col-xs-12'>" +
            "<label>Order ID</label>" +
            "<input type='number' style='min-width:120px' min='1' id='orderid_search' name='orderid_search' class='form-control' placeholder='Enter order id.'>" +
            "</div>" +
            "<div class='col-md-1 col-sm-6 col-xs-12'>" +
            "<a id='l2search' class='med_order_srch'>Search</a>" +
            "</div>" +
            "</article>" +
            " </section>" +
            "</div>";
    $("#Custom_search").html(htmlBanner);
    $("#vendor_serach").attr("disabled", "disabled");
    $("#pop_serach").attr("disabled", "disabled");
}

// on direct call
function dashboard_widgets_render_oncall(counts){
	var htmlBanner ="<div class='container-fluid custom_pop_rx'>"+
		"<ul class='nav nav-tabs cust_nav'>"+
			"<li role='presentation'>"+
				"<div class='input-group' class='mrn_number_searchbox' style='max-width:266px;'>"+
					"<select class='form-control' id='patientsearchtype' style='width:90px; background:#569D98; color:#fff;'>"+
						"<option value='mrn'>MRN</option>"+
						"<option value='mobile'>Mobile no</option>"+
					"<select>"+
					"<input type='number' class='form-control' id='patientsearchvalue' placeholder='Enter Number' style='width:125px;'>"+
					"<span class='input-group-addon' onclick='open_patient_details();' id='basic-addon2' style='width:50px; background:#569D98; color:#fff;'>Go</span>"+
				"</div>"+
			"</li>"+
		"</ul>"+
	"</div>";
	$("#pharma_widgets").html(htmlBanner);
}

function pagination(totalRecordsCount) {
    var method = sessionStorage.getItem("ajaxMethod");
    var totalCount = 0;
    switch (method) {
        case 'rx_pending':
            totalCount = totalRecordsCount.prescription_pending;
            break;
        case 'prescription_upload':
            totalCount = totalRecordsCount.prescription_upload;
            break;
        case 'assignvendororders':
            totalCount = totalRecordsCount.assigned_count;
            break;
        case 'rejected':
            totalCount = totalRecordsCount.rejected_count;
            break;
        case 'rx_not_upload':
            totalCount = totalRecordsCount.rx_not_upload;
            break;
        case 'reminder_request':
            totalCount = totalRecordsCount.reminder_request;
            break;
        default :
            totalCount = totalRecordsCount.allorder_count;
            break;
    }
    //console.log(totalCount);
    $pagination = Math.ceil(totalCount / 10);
    var htmlBanner = '';
    if ($pagination > 1) {
        $paginationLength = 5;
        $p = 1;
        htmlBanner += '<div class="col-md-12 text-center" ><ul id="pagination" class="pagination">';
        $skip = parseInt(sessionStorage.getItem("skip"));
        //console.log($skip);
        if ($pagination > 5) {
            if ($pagination > $skip) {
                if ($skip >= 5) {
                    htmlBanner += '<li class="" style="cursor: pointer;"><a onclick=allOrders("' + sessionStorage.getItem("ajaxMethod") + '","' + sessionStorage.getItem("SuccessFn") + '",' + sessionStorage.getItem("withSearch") + ',' + 1 + ',true)>First</a></li><li><a>...</a></li>';
                    $p = $skip - 3;
                    $paginationLength = $skip + 1;
                }
            } else {
                htmlBanner += '<li class="" style="cursor: pointer;"><a onclick=allOrders("' + sessionStorage.getItem("ajaxMethod") + '","' + sessionStorage.getItem("SuccessFn") + '",' + sessionStorage.getItem("withSearch") + ',' + 1 + ',true)>First</a></li><li><a>...</a></li>';
                $p = $skip - 4;
                $paginationLength = $pagination;
            }

        } else {
            $paginationLength = $pagination;
        }
        for ($p; $p <= $paginationLength; $p++) {
            if (($p == $skip)) {
                $active = 'active';
            } else {
                $active = '';
            }
            htmlBanner += '<li class="' + $active + '" style="cursor: pointer;"><a onclick=allOrders("' + sessionStorage.getItem("ajaxMethod") + '","' + sessionStorage.getItem("SuccessFn") + '",' + sessionStorage.getItem("withSearch") + ',' + $p + ',true)>' + $p + '</a></li>';
        }
        $last = $pagination - $skip;
        if ($last >= 2) {
            htmlBanner += '<li><a>...</a></li><li class="" style="cursor: pointer;"><a onclick=allOrders("' + sessionStorage.getItem("ajaxMethod") + '","' + sessionStorage.getItem("SuccessFn") + '",' + sessionStorage.getItem("withSearch") + ',' + $pagination + ',true)>Last</a></li>';
        }
        htmlBanner += '</ul>';
        htmlBanner += '</div>';
    }
    return htmlBanner;
}

function allordersview(ordersdetails, updateCount) {
    updateCount = updateCount || true;
    if (typeof ordersdetails == 'string') {
        ordersdetails = JSON.parse(ordersdetails);
    }
    var htmlBanner = '<section class="container-fluid">' +
            '<article class="main_content">' +
            '<div class="tab-content custom_tab_content">' +
            '<div role="tabpanel" class="tab-pane fade in active" id="mainreplacecontent">' +
            '<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
            '<div class="table-responsive">' +
            '<table id="example"  cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">' +
            '<thead>' +
            '<tr>' +
            '<th>MRN</th>' +
            '<th>Customer Name</th>' +
            '<th>Source Type</th>' +
            '<th>Order No.</th>' +
			'<th>Order DID.</th>' +
            '<th>Location</th>' +
            '<th>Order Created Date </th>' +
            '<th>Preferred Date/Time </th>' +
            '<th>Scheduled Date/Time </th>' +
            '<th>Vendor Assign Date</th>' +
            '<th>Vendor Name</th>' +
            '<th>Order Status</th>' +
            '<th>Payment Type</th>' +
            '<th>Order Details</th>' +
            '<th>Order Track</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';
    if (ordersdetails.data.length > 0) {
        $.each(ordersdetails.data, function (key, val) {
            //console.log(val.order.patientinfo);
            var patientname = val.order.patientinfo.name;
            if (patientname == null) {
                patientname = '';
            } 
            //patientname = patientname.replace("null", "");
            htmlBanner += '<tr>' +
			'<td>' + val.order.patientinfo.mrn + '</td>' +
			'<td>' + patientname + '</td>' +
			'<td>' + channel[val.channel]+'</td>' +
			'<td>' + val._id + '</td>' +
			'<td>' + val.odid + '</td>' +
			'<td>' + val.order.patientinfo.city + '</td>' +
			'<td>' + val.order.order_status.created_date + '</td>' +
			'<td>' + changedate(val.order.patientinfo.expected_delivery_date) + '</td>';
			var myarray_ststus = [1000,1001,21,24,17];
			if(jQuery.inArray(val.OStatus,myarray_ststus) == -1){
            //if (val.OStatus != 1000 && val.OStatus != 1001 && val.OStatus != 21) {
                htmlBanner += '<td>' + changedate(val.order.patientinfo.scheduled_date) + '</td>';
            } else {
                htmlBanner += '<td>-</td>';
            }
            htmlBanner += '<td>' + ((typeof (val.order.provider_info) == "undefined") ? "" : ((typeof val.order.provider_info[0].vendor_assigned_date == "undefined") ? "" : val.order.provider_info[0].vendor_assigned_date)) + '</td>' +
			'<td>' + ((typeof (val.order.provider_info) == "undefined") ? "" : ((typeof val.order.provider_info[0].associate_name == "undefined") ? "" : val.order.provider_info[0].associate_name)) + '</td>'+
			//'<td>' + orderstatus(val.OStatus) + '</td>' +
			'<td>' + ((typeof(val.statusName[0])!="undefined")?val.statusName[0].Nomenclature:"NA") + '</td>' +
			'<td>' + paymentModeName[val.payment_info.payment_mode] + '</td>' +
			'<td><a onclick="vieworder(' + val._id + ')" target="_new" class="view">View</a> </td>' +
			'<td><a href="#" onclick="trackOrder(' + val._id + ')" class="track_btn">Deliver Track</a></td>' +
			'</tr>';
        });
    } else {
        htmlBanner += '<tr><td colspan=14><p class="text-center">' + ordersdetails.message + '</p></td></tr>';
    }
    htmlBanner += '</tbody>' +
            '</table></div></div>';
    htmlBanner += ' </div>' +
            '</div>' +
            '</div>' +
            ' </div>' +
            '</article>' +
            '</section>' +
            '</div>';
    //$("#Custom_body").html(htmlBanner);
    if(updateCount === true){
        $("#rxuploadedcount").html(ordersdetails.prescription_upload);
        $("#allorderscount").html(ordersdetails.all_orders);
        $("#rxuploadedpendingcount").html(ordersdetails.rx_pending);
        $("#assignvendorcount").html(ordersdetails.assignvendororders);
        $("#rejectedcount").html(ordersdetails.rejected);
        //$("#rxnotuploadedcount").html(ordersdetails.rx_not_upload);
        $("#tobeassignedcount").html(ordersdetails.tobeassigned);
    }
    $(".loader").hide();
    return htmlBanner;
}


//function patientsearchlistpage(data){
function patient_search_list(data) {
    //$("#custom_search").hide();
    var htmlBanner = "";
    htmlBanner = "<div class='container-fluid'>" +
            "<section class='custom_search'>" +
            "<article class='col-md-12 col-sm-12 col-xs-12'>" +
            "<div class='col-md-9 col-sm-9 col-xs-12 mp'>" +
            "<h2 style='line-height:28px; font-weight:bold;'>Patient List</h2>" +
            "</div>" +
            "<!--div class='col-md-3 col-sm-3 col-xs-12 mp'>" +
            "<a href='#' class='back_btn' style='margin-top:-3px;'>Back</a>" +
            "</div-->" +
            "</article>" +
            "</section>" +
            "</div>";
    ////console.log(data);
    //var patientdetails=JSON.parse(data);
    var patientdetails = data;
    var htmlBanner1 = '';
    if (patientdetails.status == "1") {
        htmlBanner1 = '<br><section class="container-fluid">' +
                '<article class="main_content">' +
                '<div class="tab-content custom_tab_content">' +
                '<div role="tabpanel" class="tab-pane fade in active">' +
                '<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
                '<div class="table-responsive">' +
                '<table id="example1" cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">' +
                '<thead>' +
                '<tr>' +
                '<th style="width:100px;">MRN</th>' +
                '<th style="width:300px;">Name</th>' +
                '<th style="width:100px;">Contact No</th>' +
                '<th></th>' +
                '<th style="width:100px;">Order</th>' +
                '</tr>' +
                '</thead>' +
                '<tbody>';
        var patientlist = "";
        $.each(patientdetails.data.customerList, function (key, val) {
            if (parseInt(val.mrn) != 0) {
                patientlist += '<tr>' +
                        '<td>' + val.mrn + '</td>' +
                        '<td>' + val.firstName + ' ' + val.lastName + '</td>' +
                        '<td>' + val.mobile + '</td>' +
                        '<td></td>' +
                        '<td><span class="input-group-addon" onclick="open_patient_details(\'' + val.mrn + '\');" style="background:#569D98; color:#fff;" id="basic-addon2">New Order</span></td>' +
                        '</tr>';
            }
        });
        htmlBanner1 += patientlist;
        htmlBanner1 += '</tbody>' +
                '</table>' +
                '</div>' +
                ' </div>' +
                '</div>' +
                '</div>' +
                '</article>' +
                '</section>';
        $("#Custom_search").html(htmlBanner);
        $("#Custom_body").html(htmlBanner1);
    } else {
        //console.log(patientdetails.message);
        //console.log(patientdetails.data.message);
        alert(patientdetails.data.message);
    }
    $(".loader").hide();
}

//patientinfo banner
function renderBanner() {
    var htmlBanner = "";
    var htmlBanner = "<div class='row'>" +
	"<div class='container-fluid'>" +
	"<article class='medicine_home'>" +
	"<div class='col-md-12'><h2>" +
	sessionStorage.getItem('name') + "<small> | " +
	sessionStorage.getItem('patientgender') + " | " +
	sessionStorage.getItem('age') + " Y | MRN-" +
	sessionStorage.getItem('patientmrn') + " | Emailid" +
	sessionStorage.getItem('email') + " | <i class='fa fa-tags' aria-hidden='true' title=" +
	sessionStorage.getItem('TagName') + "></i>&nbsp;&nbsp;<button onclick='showwallethistory(" +
	sessionStorage.getItem('patientmrn') + ")' class='btn btn-success'> Wallet History </button>" +
	"&nbsp;&nbsp;<button onclick='open_cp_prescription(" + sessionStorage.getItem('patientmrn') + ")' style='float:right; margin-top:5px;' class='btn btn-success'> Customer Prescriptions </button>" +
	"&nbsp;&nbsp;<button onclick='open_refillbymrn(" + sessionStorage.getItem('patientmrn') + ")' style='float:right; margin-right: 10px; margin-top:5px;' class='btn btn-success'> Refill Requests </button>" +
	"&nbsp;&nbsp;<button onclick='open_3monthprecription(" + sessionStorage.getItem('patientmrn') + ")' style='float:right; margin-right: 10px; margin-top:5px;' class='btn btn-success'> Last 3 months prescriptions </button>" +
	"&nbsp;&nbsp;<br>English | Service Type : Drug@Home <span id='orderfrom'></span></small></h2></div></article></div></div>";

    htmlBanner += "<div id='right_side' style='display:none;'>" +
	"<div id='right_side_header' style=''>&nbsp; &nbsp; &nbsp;&nbsp;" +
	"<button class='btn' style='float:right;' onclick='right_side_toggle();'>X</button>&nbsp;&nbsp;</div>" +
	"<hr><div id='showdetails' style='overflow:auto; max-height:500px;'></div></div>";
	

    $("#patientBannerInfo").html(htmlBanner);
    $(".loader").hide();
} 

//create order header 
function renderorderHeader(response="") {
    var empltyval = "";
    var i = 0;
    var htmlBanner = "<style>.datepicker-dropdown{margin-top : 44px !important;}</style><section class='container-fluid' style='background:#ECF8F8;border: 1px #C4C4C4 solid;margin: 15px;margin-top: 35px;margin-bottom: 0px;'> " +
	"<div class='col-md-12 col-sm-12 col-xs-12 mp'>" +
	"<div class='col-sm-3 col-xs-12' style='margin: 12px 0px;'>" +
	"<div class='form-group' style='margin: 0px;'>" +
	"<label style='color:#408DAE;font-weight: bold;margin-bottom: 2px;'>Delivery Address</label>" +
	"<label class='' style='cursor: pointer;' onclick='showAddressList();' ><i class='fa fa-pencil-square-o' style='background-color:#408DAE'></i></label>" +
	"<p id='showdelvaddress' style='color:#408DAE; font-weight: bold;'>" +
	((sessionStorage.getItem("address") == 'Array') ? '' : ((sessionStorage.getItem("address")) + ", ")) +
	" " + "</p>" +
	"</div>" +
	"</div>" +
	"<div class='col-sm-5 col-xs-12 mp'>" +
	"<div class='form-group'>" +
	"<div class='' style='padding-top:8px;'><label style='color:#408DAE'><b>Choose the Medicine</b></label>" +
	"<div class='icon-addon data-search-select'>" +
	"<input type='text' list='druglist'  class='form-control drugsearch' autocomplete='off' placeholder='Enter Drug Name' onkeyup=loaddruglist('drugsearch') id='drugsearch' name='drugsearch' /><datalist id='druglist' class='data_druglist'></datalist>" +
	"</div>" +
	"</div>" +
	"</div>" +
	"</div>" +
	/* "<div class='col-sm-1 col-xs-12 mp' style='padding-top: 32px;' >" +
	"<button style='padding: 6px; margin-left: 10px;' type='button' class='btn btn-success btn-md searchDrug' >Search</button>" +
	"</div>" +*/
	"<div class='col-sm-3 pull-right col-xs-12 mp' style='padding-top: 7px;'>" +
	"<label style='color:#408DAE'><b>Available Wallet : <span id='l2vwalletamt'></span></b></label><br>";
	if(sessionStorage.getItem('orderMode') != 'update'){
		htmlBanner += "<span style='font-weight:bold; background:#338CAC; color:#fff; padding: 4px; border: 1px solid #338cac;' id='l2vwalletbutton'>Apply &nbsp;&nbsp;<input type='checkbox' style='margin-bottom: 3px; vertical-align: middle;' onclick='applywallet()' id='applywallet'/></span>";
	}
	htmlBanner += "<!--br><label style='color:#408DAE'><b>Payment Mode :</b></label>" +
	"<select name='payment_method' id='payment_method' class='form-control new-status'>" +
	"<option value='CARD'>Card</option>" +
	"<option value='COD'>Cash</option>" +
	"<!--option value='CARD'>Debit Card</option-->" +
	"</select-->" +
	"</div>" +
	"</div>" +
	"<div class='modal' id='updateAddressModel' role='dialog'>" +
	"<div class='modal-dialog' role='document'>" +
	"<div class='modal-content'>" +
	"<div class='modal-header'>" +
	"<h5 class='modal-title'>Delivery Address</h5>" +
	"<button type='button' class='close' style='margin-top: -20px;' data-dismiss='modal' aria-label='Close'>" +
	"<span aria-hidden='true'>&times;</span>" +
	"</button>" +
	"</div>" +
	"<div class='modal-body'>" +
	"<div class='form-group green-border-focus'>" +
	"<textarea id='deliveryAddress' class='form-control' style='height: 90px;'>" + ((sessionStorage.getItem("address") == 'Array') ? '' : ((sessionStorage.getItem("address")) + ", ")) + "</textarea>" +
	"</div>" +
	"</div>" +
	"<div class='modal-footer'>" +
	"<button type='button' class='btn btn-primary' onclick='updateDeliveryAddress();' id='updateDeliveryAddress'>Update</button>" +
	"</div>" +
	"</div>" +
	"</div>" +
	"</div>" +
	"</section>";
    $("#Custom_search").html(htmlBanner);
}

function renderCreateOrder(bj) {
    //console.log(bj);
    //var htmlBannerMCrg = "<input id='medicine_delivery' data-id='' data-codedid='' data-item_mrp='' data-item_gross='' data-item_net='' data-item_discount='' data-ignoreToPartner='' value='0' type='hidden'>";
	var htmlBanner = "";
    var htmlBannerMCrg = "";
    ////console.log(bj.countn);
    /*if ((typeof bj != "undefined") && bj.countn > 0) {
        var Obj = bj.data.order.orderitem;
        //console.log(Obj[0].itemname);
        var htmlBanner = "";
        htmlBanner += "<section class='container-fluid'><div class='col-md-12 col-sm-12 col-xs-12 mp'>" +
                "<div class=''>" +
                "<table class='table cust_table_order table-condensed table-bordered table-striped medicine_home_order_table' id='mtable'>" +
                "<thead>" +
                "<tr>" +
                "<th style='width: 23%;'>" +
                "Brand Name" +
                "</th>" +
                "<th style='width: 20%;'>" +
                "Pharmaceutical Name" +
                "</th>" +
                "<th>" +
                " Doctor Name" +
                "</th>" +
                "<th>" +
                "Type" +
                "</th>" +
                "<th>" +
                "Item MRP" +
                "</th>" +
                "<th style='width:80px;'>" +
                "Order Qty" +
                "</th>" +
                "<th>" +
                "Gross Amount" +
                "</th>" +
                "<th>" +
                "Discount" +
                "</th>" +
                "<th>" +
                "Net Amount" +
                "</th>" +
                "<th style='min-width:65px;'>" +
                " Actions" +
                "</th> " +
                "</tr>" +
                "</thead>" +
                "<tbody>";
        for (var i = 0; i < (Obj.length); i++) {

            if (Obj[i].item_status != "8") {
                var category = (typeof Obj[i].category != "undefined") ? Obj[i].category : "";
                var priceperunit = (typeof Obj[i].priceperunit != "undefined") ? Obj[i].priceperunit : "";
                var manufacturerid = (typeof Obj[i].manufacturer_id != "undefined") ? Obj[i].manufacturer_id : "";
                var manufacturer = (typeof Obj[i].manufacturer != "undefined") ? Obj[i].manufacturer : "";
                var packsize = (typeof Obj[i].packsize != "undefined") ? Obj[i].packsize : "";

                if (i == 0) {
                    //itemdetailsby_itemcode(Obj[i].item_code, "drugsearch");
                    htmlBanner +=
                            "<tr class='rowdrug' id='rowdrug-"+rowcount+"'>" +
                            "<td>" +
                            "<div class='form-group'>" +
                            "<div class='input-group input-group-md'>" +
                            "<div class='icon-addon'>" +
                            "<input type='text' value='" + Obj[i].itemname + "' list='druglist'  class='form-control drugsearch' id='drugsearch' name='drugsearch' onkeyup='loaddruglist(event,this);' onchange='loadanotherdrug(this);' data-code='" + Obj[i].item_id + "' data-codedid='" + Obj[i].item_code + "' data-category='" + category + "' data-priceperunit='" + priceperunit + "' data-packsize='" + packsize + "' data-manufacturerid='" + manufacturerid + "'  data-manufacturer='" + manufacturer + "' ><datalist id='druglist' class='data_druglist'></datalist>" +
                            "</div>" +
                            "<span class='input-group-btn'>" +
                            "<button class='btn btn-default' type='button'><i class='fa fa-search' aria-hidden='true'></i></button>" +
                            "</span>" +
                            "</div>" +
                            "</div>" +
                            "</td>" +
                            "<td>" +
                            "<div class='form-group'>" +
                            "<input type='text' value='" + Obj[i].pharmaname + "' name='pharmaname' disabled  class='form-control' id='pharmaname'>" +
                            "</div>" +
                            "</td>" +
                            "<td>" +
                            "<input type='text' value='" + Obj[i].doctor + "'  class='form-control' name='doctorname' id='doctorname'>" +
                            "</td>" +
                            "<td>";
                    //alert(Obj[i].prescribed);
                    if (Obj[i].prescribed == true) {
                        htmlBanner += "<label name='l2vsetrxotg' id='l2vsetrxotg' data-rxset='true' style='display:block;'>";
                    } else {
                        htmlBanner += "<label name='l2vsetrxotg' id='l2vsetrxotg' data-rxset='' style='display:none;'>";
                    }
                    htmlBanner += "<span class='rx'>Rx</span></label>";
                    htmlBanner += "</td>" +
                            "<td>" +
                            "<input type='text' disabled value='" + Obj[i].item_mrp + "' class='form-control itemmrpval' name='itemmrpval' id='itemmrpval'>" +
                            "</td>" +
                            "<td><input type='number' min='1' class='form-control' onchange='calculate(event,this);' onkeyup='calculate(event,this);' name='quantity' value='" + Obj[i].quantity + "' id='quantity'></td>" +
                            "<td>" +
                            "<input type='text' disabled data-mrp='" + Obj[i].item_mrp + "' value='" + Obj[i].gross_amount + "' class='form-control grossamount' name='grossamount' id='grossamount'>" +
                            "</td>" +
                            "<td>" +
                            "<input type='text' disabled value='" + Obj[i].discount_amount + "' class='form-control' name='discountAmount' id='discountamount'>" +
                            "</td>" +
                            "<td><input disabled type='text'  class='form-control' id='netamount' name='netAmount'  data-walletamt='" + ((typeof Obj[i].item_wallet == "undefined") ? 0 : Obj[i].item_wallet) + "' value='" + Obj[i].net_amount + "'></td>" +
                            "<td><label id='l2vaccept" + i + "' title='" + ((typeof Obj[i].pricePerUnit != "undefined") ? Obj[i].pricePerUnit : 'NA') + "'><a href='#' title='" + Obj[i].user_log + "'><i class='fa fa-info cust_check' aria-hidden='true'></i></a></label><label name='l2vcancel' id='l2vcancel" + i + "' data-value='"+rowcount+"' onclick='cancellineitemdiag(this);'><i class='fa fa-times cust_times' aria-hidden='true'></i></label></td>" +
                            "</tr> ";
					rowcount = rowcount + 1;
                }
                else {
                    //itemdetailsby_itemcode(Obj[i].item_code, "drugsearch" + i);
                    htmlBanner +=
                            "<tr class='rowdrug' id='rowdrug-"+rowcount+"'>" +
                            "<td>" +
                            "<div class='form-group'>" +
                            "<div class='input-group input-group-md'>" +
                            "<div class='icon-addon'>" +
                            "<input value='" + Obj[i].itemname + "' type='text' list='druglist" + i + "'  class='form-control drugsearch' id='drugsearch" + i + "' name='drugsearch' onkeyup='loaddruglist(event,this);' onchange='loadanotherdrug(this);' data-code='" + Obj[i].item_id + "' data-codedid='" + Obj[i].item_code + "'' data-category='" + category + "' data-priceperunit='" + priceperunit + "' data-packsize='" + packsize + "'  data-manufacturerid='" + manufacturerid + "' data-manufacturer='" + manufacturer + "'><datalist id='druglist" + i + "'' class='data_druglist'></datalist>" +
                            "</div>" +
                            "<span class='input-group-btn'>" +
                            "<button class='btn btn-default' type='button'><i class='fa fa-search' aria-hidden='true'></i></button>" +
                            "</span>" +
                            "</div>" +
                            "</div>" +
                            "</td>" +
                            "<td>" +
                            "<div class='form-group'>" +
                            "<input type='text' disabled  value='" + Obj[i].pharmaname + "' name='pharmaname' class='form-control' id='pharmaname" + i + "'>" +
                            "</div>" +
                            "</td>" +
                            "<td>" +
                            "<input type='text' class='form-control' value='" + Obj[i].doctor + "' name='doctorname' id='doctorname" + i + "'>" +
                            "</td>" +
                            "<td>";
                    if (Obj[i].prescribed == true) {
                        htmlBanner += "<label name='l2vsetrxotg' id='l2vsetrxotg" + i + "' data-rxset='true' style='display:block;'>";
                    } else {
                        htmlBanner += "<label name='l2vsetrxotg' id='l2vsetrxotg" + i + "' data-rxset='' style='display:none;'>";
                    }
                    htmlBanner += "<span class='rx'>Rx</span></label>";
                    htmlBanner += "</td>" +
                            "<td>" +
                            "<input type='text' disabled value='" + Obj[i].item_mrp + "' name='itemmrpval' class='form-control itemmrpval' id='itemmrpval" + i + "'>" +
                            "</td>" +
                            "<td><input type='number' min='1' class='form-control quantity' name='quantity' onchange='calculate(event,this);' onkeyup='calculate(event,this);' value='" + Obj[i].quantity + "' id='quantity" + i + "'></td>" +
                            "<td>" +
                            "<input type='text' disabled data-mrp='" + Obj[i].item_mrp + "' value='" + Obj[i].gross_amount + "'  class='form-control grossamount' name='grossamount' id='grossamount" + i + "'>" +
                            "</td>" +
                            "<td>" +
                            "<input type='text' disabled value='" + Obj[i].discount_amount + "'  class='form-control' name='discountAmount' id='discountamount" + i + "'>" +
                            "</td>" +
                            "<td><input disabled value='" + Obj[i].net_amount + "' type='text'  class='form-control'  data-walletamt='" + ((typeof Obj[i].item_wallet == "undefined") ? 0 : Obj[i].item_wallet) + "' name='netamount' id='netamount" + i + "'></td>" +
                            "<td><label id='l2vaccept" + i + "' title='" + ((typeof Obj[i].pricePerUnit != "undefined") ? Obj[i].pricePerUnit : 'NA') + "'><a href='#' title='" + Obj[i].user_log + "'><i class='fa fa-info cust_check' aria-hidden='true'></i></a></label><label name='l2vcancel' id='l2vcancel" + i + "' data-value='"+rowcount+"' onclick='cancellineitemdiag(this);'><i class='fa fa-times cust_times' aria-hidden='true'></i></label></td>" +
                            "</tr> ";
                }
            }
			rowcount = rowcount + 1;
        }
        htmlBanner +=
                "<tr class='rowdrug' id='rowdrug-"+rowcount+"'>" +
                "<td>" +
                "<div class='form-group'>" +
                "<input type='text' disabled  list='druglist'  class='form-control drugsearch' id='drugsearch' name='drugsearch'>" +
                "</div>" +
                "</td>" +
                "<td>" +
                "<div class='form-group'>" +
                "<input type='text' disabled  class='form-control' name='pharmaname' id='pharmaname" + i + "'>" +
                "</div>" +
                "</td>" +
                "<td>" +
                "<input type='text'  class='form-control' name='doctorname' id='doctorname" + i + "'>" +
                "</td>" +
                "<td><label name='l2vsetrxotg' id='l2vsetrxotg" + i + "' style='display:none;' data-rxset=''><span class='rx'>Rx</span></label></td>" +
                "<td>" +
                "<input type='text' disabled value='' name='itemmrpval' class='form-control itemmrpval' id='itemmrpval" + i + "'>" +
                "</td>" +
                "<td><input type='number' min='1' class='form-control' name='quantity' onchange='calculate(event,this);' onkeyup='calculate(event,this);' id='quantity" + i + "'></td>" +
                "<td>" +
                "<input type='text' disabled data-mrp='' class='form-control grossamount' name='grossamount' id='grossamount" + i + "'>" +
                "</td>" +
                "<td>" +
                "<input type='text' disabled  class='form-control' name='discountAmount' id='discountamount" + i + "'>" +
                "</td>" +
                "<td><input disabled type='text'  class='form-control' data-walletamt='' name='netAmount' id='netamount" + i + "'></td>" +
                "<td><label id='l2vaccept' title='hello'><a href='#'><i class='fa fa-info cust_check' aria-hidden='true'></i></a></label><label name='l2vcancel' id='l2vcancel' data-value='"+rowcount+"' onclick='cancellineitemdiag(this);'><i class='fa fa-times cust_times' aria-hidden='true'></i></label></td>" +
                "</tr> ";
        htmlBanner +=
                "</tbody>" + "</table>" +
                "</div>" +
                "<!--<div class='col-md-12 col-sm-12 col-xs-12 text-right view_prec'>" +
                "<a href='#' class='back_btn'>View Prescription</a>&nbsp;" +
                "<a href='#' class='back_btn'>Rpeat Order</a>&nbsp;" +
                "<button onclick='createNewDrugOrder()' class='btn btn-primary'>Save</button>&nbsp;" +
                "</div>-->" +
                "<!--<div class='col-md-8 col-md-offset-4 pull-right'>" +
                "<nav aria-label='...'>" +
                "<ul class='pagination'>" +
                "<li class='page-item disabled'>" +
                "<a class='page-link' href='#' tabindex='-1'>Previous</a>" +
                "</li>" +
                "<li class='page-item'><a class='page-link' href='#'>Order( 1 - 100 from 123 )</a></li>" +
                "<li class='page-item'>" +
                "<a class='page-link' href='#'>Next</a>" +
                "</li>" +
                "</ul>" +
                "<span class='nps'>" +
                "No of Pages <select name='job_name' class='form-control noofpages'>" +
                "<option value=''>1</option>" +
                "<option value=''>25</option>" +
                "<option value=''>50</option>" +
                "<option value=''>100</option>" +
                "</select>" +
                "</span>" +
                "</nav>" +
                "</div>-->" +
                "</div></section>";
    }
    else {
        var empltyval = '';
        var htmlBanner = "";
    }*/
    var htmlRefferBanner = "<section class='container-fluid coupon_block'>" +
            "<div class='col-lg-7'>" +
            "<div class='col-lg-3'>" +
            "<label style='color:#408DAE; font-weight:bold;'>Source of Referral*</label><br>" +
            "<select type='text' id='l2vsourcereferral' class='form-control' style='min-width:140px;'><option value=''>Choose officer id</option></select>" +
            "</div>" +
            "<!--div class='col-lg-4'>" +
            "<label style='color:#408DAE; font-weight:bold;'>Coupon</label><br>" +
            "<input type='text' placeholder='Please enter coupon code' id='l2vCoupanCode' class='form-control' style='width:140px; display:inline-block;'>" + "&nbsp;<button onclick='applycoupen()' class='btn btn-danger' style='background:#277B72; height:35px; line-height:26px; padding-left:6px; padding-right:6px;'>Remove</button><br>" + "<b style='font-size:12px; color:#d22;'>Note:*Re-apply the Coupon Code When Add/Edit item </b>" +
            "</div-->" +
            "<div class='col-lg-4'>" +
            "<label style='color:#408DAE; font-weight:bold;'>Coupon</label><br>" +
            "<input type='text' placeholder='Please enter coupon code' disabled='disabled' id='l2vCoupanCode' data-code='' class='form-control' style='width:140px; display:inline-block;'>" + "&nbsp;<button onclick='removecoupen()' class='btn btn-danger' style='height:35px; line-height:26px; padding-left:6px; padding-right:6px;'>Remove</button><br>" + "<a style='font-size:12px; color:#3E3C6C; font-weight:bold; cursor:pointer;' onclick='showcoupon()'>View Coupons</a><br>" + "<b style='font-size:12px; color:#d22;'>Note:*Re-apply the Coupon Code When Add/Edit item </b>" +
            "</div>" +
            "<div class='col-lg-3'>" +
            "<label style='color:#408DAE; font-weight:bold;'>Referred By*</label><br>" +
            "<input type='text' onkeyup='findofferid();' value='' placeholder='Please officer id or 9999' id='l2vreferby' class='form-control referedbylist' style='min-width:140px;'>" +
            "</div>" +
            "<div class='col-lg-2'>" +
            "<label style='color:#408DAE; font-weight:bold; min-width:150px;'>Referred by mrn</label><br>" +
            "<input type='number' placeholder='Please enter mrn.' id='l2vsreferbymrn' class='form-control' style='min-width:150px;'>" +
            "</div>" +
            "<div class='col-lg-4'></div>" +
            "</div>" +
            "" +
            "<div class='col-lg-12' align='right'><button onclick='createNewDrugOrder()' class='btn btn-success'> Book </button><br><br></div>" +
            "</section>" +
            "<div class='modal fade' id='couponlistmodal' role='dialog'>" +
            "<div class='modal-dialog'>" +
            "<!-- Modal content-->" +
            "<div class='modal-content'>" +
            "<div class='modal-header'>" +
            "<button type='button' class='close' data-dismiss='modal'>&times;</button>" +
            "<h4 class='modal-title'>Coupon List</h4>" +
            "</div>" +
            "<div class='modal-body' align='left'>" +
            "<table border='1' style='margin:10px; width:95%;'><thead><tr style='background:#0F7C75; color:#fff;'><th>Coupons Name</th><th>Description</th><th>Action</th></tr></thead><tbody id='couponlist'>" +
            "</tbody></table>" +
            "</div>" +
            "<div class='modal-footer'>" +
            "<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>" +
            "</div>" +
            "</div>" +
            "</div>" +
            "</div>" + htmlBannerMCrg;
    htmlBanner += '<div id="patientAddressList"></div>';
    ////console.log(htmlBanner);
    $("#Custom_body").html("<section id='l2ordercreatediv' style='display:block;'>" + htmlBanner + "</section>" + htmlRefferBanner + "<section style='display:none;' id='l2orderdetailsdiv'></section>");
}

function addDrugSearchItemsList($sectionId, category, response) {
	console.log(response); 
    if (sessionStorage.getItem('orderMode') == 'update' || sessionStorage.getItem('orderMode') == 'reorder' && (typeof response !="undefined")) {
		if(typeof response =="undefined" && sessionStorage.getItem('orderMode') == 'update'){
			alert("Another categoty/manufacture related item should not be added.");
			return;
		}
		sessionStorage.setItem($sectionId+"_file",JSON.stringify(response.data.order.prescription_images));
        var orderDetails = response.data.order;
        var orderItemsList = orderDetails.orderitem;
    } else {
        orderItemsList = [];
    }
	//if (sessionStorage.getItem('orderMode') == 'update'
    var empltyval = '';
    var htmlBanner = "<section data-sectionid='split-0' class='container-fluid new-order-by-category split-0' name='drug_orders' id='l2vsearch_custom' >" +
            "<section class='complete_order_search drug-order-gross-details' style='background:#ECF8F8; border: 1px #C4C4C4 solid; margin:15px 0px -4px 0px;'>" +
            "<article class='col-md-12 col-sm-12 col-xs-12 mobile_mp'>" +
			"<div class='row'>"+
			"<!--div class='col-md-2 col-sm-2 col-xs-12' align='center'>" +
            "<label style='color:#408DAE'>Choose the slot :</label>" +            
			"<button name='job_name' onclick='open_slot_modal();' id='selecttimeslot' class='btn btn-success'>Select slot</button>"+            
            "</div-->"+
			"<div class='col-md-2 col-sm-2 col-xs-12' align='center'>";
				htmlBanner += "<label style='color:#408DAE'>Choose the slot :</label>"+
				"<button name='job_name' onclick=open_slot_modal('split-0'); id='selecttimeslot' class='btn btn-success'>Select slot</button>"+
				"<label class='timeslot' style='color:#408DAE'>"+orderDetails.patientinfo.scheduled_date+"</label>";
				sessionStorage.setItem("reject_default_vendor_id",orderDetails.provider_info[0].associate_id);
			
            htmlBanner += "</div>"+
	    "<div class='col-md-2 col-sm-1 col-xs-12'>" +            
            "<label style='color:#408DAE'>Vendor Pharma Name :</label>" +
            "<select name='vendorname' id='vendorname' class='form-control new-status' style='width:90%'>" +
            "<option value='0' selected='selected'>Select Vendor</option>" +
            "</select>" +
            "</div>" +
	    "<div class='col-md-2 col-xs-12'>" +
            "<label style='color:#408DAE'>Gross Amount &nbsp; : &nbsp; &#8377;&nbsp; <span class='l2vitemtotalamountgross' id='l2vitemtotalamountgross'> 0 </span></label>" +
            "<label style='color:#408DAE'>Used Wallet Amount : &nbsp; &#8377;&nbsp; <span class='l2vitemwalletamount' id='l2vitemwalletamount'> 0 </span></label>" +
            "</div>" +
            "<div class='col-md-2 col-xs-12'>" +
            "<label style='color:#408DAE'>Discount Amount &nbsp; : &nbsp; &#8377;&nbsp; <span class='l2vitemtotalamountdiscount' id='l2vitemtotalamountdiscount'> 0 </span></label>" +
            "<label style='color:#408DAE'>Delivery Charge &nbsp; : &nbsp; &#8377;&nbsp; <span class='l2vdeliverycharge' id='l2vdeliverycharge'> 0 </span></label>" +
	    "<input class='medicine_delivery' id='medicine_delivery' data-id='' data-codedid='' data-item_mrp='' data-item_gross='' data-item_net='' data-item_discount='' data-ignoreToPartner='' value='0' type='hidden'>"+
            "</div>" +
            "<div class='col-md-2 col-xs-12'>" +
            "<label style='color:#408DAE'>Net Amount &nbsp; : &nbsp; &#8377;&nbsp; <span class='l2vitemtotalamount' id='l2vitemtotalamount'> 0 </span></label>" +
            "<label style='color:#408DAE'>Prepaid Amount &nbsp; : &nbsp; &#8377;&nbsp; <span class='l2vprepaidamount' id='l2vprepaidamount'> 0 </span></label>" +
            "</div>"+
	    "</article>"+
            "</section>" +
            "<section class='drug-order-items'><div class='col-md-12 col-sm-12 col-xs-12 mp'>" +
            "<div class=''>" +
            "<table class='table cust_table_order table-condensed table-bordered table-striped medicine_home_order_table' id='mtable'>" +
            "<thead>" +
            "<tr>" +
            "<th style='width: 23%;'>" +
            "Brand Name" +
            "</th>" +
            "<th style='width: 20%;'>" +
            "Pharmaceutical Name" +
            "</th>" +
            "<th>" +
            " Doctor Name" +
            "</th>" +
            "<th>" +
            "Type" +
            "</th>" +
            "<th>" +
            "Item MRP" +
            "</th>" +
            "<th style='width:80px;'>" +
            "Order Qty" +
            "</th>" +
            "<th>" +
            "Gross Amount" +
            "</th>" +
            "<th>" +
            "Discount" +
            "</th>" +
            "<th>" +
            "Net Amount" +
            "</th>" +
            "<th>" +
            " Actions" +
            "</th> " +
            "</tr>" +
            "</thead>" +
            "<tbody>";
    //console.log(orderItemsList);
    if (orderItemsList.length > 0) {
        //console.log(orderItemsList);
        $.each(orderItemsList, function (key, itemRecord) {
            if (itemRecord.roleBasedService == 1 || itemRecord.roleBasedService == '1' || itemRecord.cancelbeforeaccept == '1' || itemRecord.cancelbeforeaccept == 1) {
                return;
            }
            //console.log(itemRecord);
            //console.log(itemRecord.MRP);
            selectedDrugsList.push(itemRecord.itemname);
			//alert(itemRecord.itemname);
			var pricePerUnit = (typeof itemRecord.pricePerUnit!="undefined")?itemRecord.pricePerUnit:"";
			var discountamount = parseFloat(itemRecord.gross_amount) - parseFloat(itemRecord.net_amount);
			var doctorname = (typeof itemRecord.doctorname!="undefined")?itemRecord.doctorname:"";
            htmlBanner += "<tr class='rowdrug' id='rowdrug-"+rowcount+"'>" +
			"<td>"+
			"<div class='form-group'>" +
			"<input type='text' disabled class='form-control' value='" + itemRecord.itemname + "' name='drugsearch' data-codedid='" + itemRecord.item_code + "' data-id='" + itemRecord.item_code + "' data-category='" + itemRecord.category + "' data-priceperunit='' data-packsize='"+pricePerUnit+"' data-manufacturerid='" + itemRecord.manufacturer_id + "' data-manufacturer='" + itemRecord.manufacturer + "'>" +
			"</div>" +
			"</td>" +
			"<td>" +
			"<div class='form-group'>" +
			"<input type='text' disabled  class='form-control' value='" + itemRecord.manufacturer + "' name='pharmaname' id='pharmaname'>" +
			"</div>" +
			"</td>" +
			"<td>"+
			"<input type='text' class='form-control' value='"+doctorname+"' name='doctorname' id='doctorname'>" +
			"</td>" +
			"<td><label name='l2vsetrxotg' id='l2vsetrxotg' data-rxset='' style='display:none;'><span class='rx'>Rx</span></label></td>" +
			"<td>" +
			"<input type='text' disabled value='" + itemRecord.item_mrp + "' name='itemmrpval'  class='form-control itemmrpval' id='itemmrpval'>" +
			"</td>" +
			"<td><input type='number' min='1' class='form-control' value='" + itemRecord.quantity + "' onchange='calculate(event,this);' onkeyup='calculate(event,this);' name='quantity' id='quantity'></td>" +
			"<td>" +
			"<input type='text' disabled data-mrp=''  class='form-control grossamount' value='"+ itemRecord.gross_amount +"' name='grossamount' id='grossamount'>" +
			"</td>" +
			"<td>" +
			"<input type='text' disabled  class='form-control' value='" +discountamount+ "' name='discountAmount' id='discountamount'>" +
			"</td>" +
			//"<td><input disabled type='text'  class='form-control' data-walletamt='' value='" + itemRecord.net_amount + "' name='netAmount' id='netamount'></td>" +
			"<td>" +
			"<input disabled type='text' class='form-control' data-walletamt='' value='" + itemRecord.net_amount + "' name='netAmount' id='netamount' data-cartcouponapplied='" + itemRecord.cartCouponApplied + "' data-cartdiscountapplied='" + itemRecord.cartDiscountApplied + "' data-cartdiscountapportionedamount='" + itemRecord.cartDiscountApportionedAmount + "' data-couponvalue='" + itemRecord.coupon_amount + "' data-discountapplied='" + itemRecord.discountApplied + "' data-invoiceto='" + itemRecord.invoiceto + "' data-orderdiscountapplied='" + itemRecord.orderDiscountApplied + "' data-penalty_amount='0' data-orderapportioneddiscountamount='" + itemRecord.orderApportionedDiscountAmount + "' data-apportionedcouponamount='0' data-apportionedwalletamount='0' data-maxquantity='0' data-minquantity='0' data-voucherapportionedamount='0' data-grossamount='" + itemRecord.gross_amount + "' data-mrp='" + itemRecord.MRP + "' data-omsnetamount='" + itemRecord.net_amount + "' data-netamount='" + itemRecord.net_amount + "' data-discountamount='" +discountamount+ "'>" +
			"</td>" +
			"<td><label id='l2vaccept' title='hello'><a href='#'><i class='fa fa-info cust_check' aria-hidden='true'></i></a></label><label name='l2vcancel' id='l2vcancel' data-value='"+rowcount+"' onclick='cancellineitemdiag(this);'><i class='fa fa-times cust_times' aria-hidden='true'></i></label></td>" +
			"</tr> ";
			rowcount = rowcount +1;
        });
    } else {
        htmlBanner += "<tr class='rowdrug' id='rowdrug-"+rowcount+"'>" +
                "<td>" +
                "<div class='form-group'>" +
                "<input type='text'disabled class='form-control' name='drugsearch' >" +
                "</div>" +
                "</td>" +
                "<td>" +
                "<div class='form-group'>" +
                "<input type='text' disabled  class='form-control' name='pharmaname' id='pharmaname'>" +
                "</div>" +
                "</td>" +
                "<td>" +
                "<input type='text' class='form-control' name='doctorname' id='doctorname'>" +
                "</td>" +
                "<td><label name='l2vsetrxotg' id='l2vsetrxotg' data-rxset='' style='display:none;'><span class='rx'>Rx</span></label></td>" +
                "<td>" +
                "<input type='text' disabled value='' name='itemmrpval' class='form-control itemmrpval' id='itemmrpval'>" +
                "</td>" +
                "<td><input type='number' min='1' class='form-control' onchange='calculate(event,this);' onkeyup='calculate(event,this);' name='quantity' id='quantity'></td>" +
                "<td>" +
                "<input type='text' disabled data-mrp=''  class='form-control grossamount' name='grossamount' id='grossamount'>" +
                "</td>" +
                "<td>" +
                "<input type='text' disabled  class='form-control' name='discountAmount' id='discountamount'>" +
                "</td>" +
                "<td><input disabled type='text'  class='form-control' data-walletamt='' name='netAmount' id='netamount'></td>" +
                "<td><label id='l2vaccept' title='hello'><a href='#'><i class='fa fa-info cust_check' aria-hidden='true'></i></a></label><label name='l2vcancel' id='l2vcancel' data-value='"+rowcount+"' onclick='cancellineitemdiag(this);'><i class='fa fa-times cust_times' aria-hidden='true'></i></label></td>" +
                "</tr> ";
    }

    //console.log(htmlBanner); 
    htmlBanner += "</tbody>" +
            "</table>" +
            "</div>" +
            "<div class='col-lg-12' align='right'>" +
            "<label></label>";
	if(checkSum==".splitOne"){
    htmlBanner +="<input type='checkbox' readonly name='checkboxprescriptionsms' id='checkboxprescriptionsms' data-status='0'>&nbsp;" +
            "<span style='color:#222; font-size:13px; font-weight: bold;' id='checkboxprescriptionsmsname'>Prescription Required</span>&nbsp;" +
            "<button onclick=l2prescptionuploadl2('" + $sectionId + "') class='btn btn-success'>Add Prescription</button>&nbsp;" +
            "<button onclick=openprescriptionmadal('" + $sectionId + "') id='l2vopenprescriptionmadal' class='btn btn-success'>View Prescription</button>&nbsp;";
	}
    htmlBanner +="</div>" +
            "</div><div class='modal fade " + $sectionId + "_uploadpresc' id='' role='dialog'>" +
            "<div class='modal-dialog'>" +
            "<!-- Modal content-->" +
            "<div class='modal-content'>" +
            "<div class='modal-header'>" +
            "<button type='button' class='close' data-dismiss='modal'>&times;</button>" +
            "<h4 class='modal-title'>Upload Prescription </h4>" +
            "</div>" +
            "<div class='modal-body'>" +
            "<form  id='" + $sectionId + "_form'  method='post' enctype='multipart/form-data'>" +
            "<input type='file' name='pic[]' data-id='" + $sectionId + "' id='l2prescptionname' multiple>" +
            "<input type='hidden' name='mrn' value='" + sessionStorage.getItem('patientmrn') + "' id='orderMrn'>" +
            "<input type='hidden' name='orderid' value='' id='orderid'>" +
            "<button type='button' class='btn btn-success' data-dismiss='modal' onclick=l2prescptionuploadfroml2('" + $sectionId + "') >Upload</button>" +
            "</form>" +
            "</div>" +
            "<div class='modal-footer'>" +
            "<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>" +
            "</div>" +
            "</div>" +
            "</div>" +
            "</div><!--input id='medicine_delivery' data-id='' data-codedid='' data-item_mrp='' data-item_gross='' data-item_net='' data-item_discount='' data-ignoreToPartner='' value='0' type='hidden'--></section></section>";

    return htmlBanner;
}

function newDrugSearchItemsList(category, itemList, response) {
    $sectionId = category;
	console.log(response); 
    if (sessionStorage.getItem('orderMode') == 'update' || sessionStorage.getItem('orderMode') == 'reorder' && (typeof response !="undefined")) {
		if(typeof response =="undefined" && sessionStorage.getItem('orderMode') == 'update'){
			alert("Another categoty/manufacture related item should not be added.");
			return;
		}
		sessionStorage.setItem($sectionId+"_file",JSON.stringify(response.data.order.prescription_images));
        var orderDetails = response.data.order;
        var orderItemsList = orderDetails.orderitem;
    } else {
        orderItemsList = [];
    }
	//if (sessionStorage.getItem('orderMode') == 'update'
    var empltyval = '';
    var htmlBanner = "<section data-sectionid='" + category + "' class='container-fluid new-order-by-category " + category + "' name='drug_orders' id='l2vsearch_custom' >" +
            "<section class='complete_order_search drug-order-gross-details' style='background:#ECF8F8; border: 1px #C4C4C4 solid; margin:15px 0px -4px 0px;'>" +
            "<article class='col-md-12 col-sm-12 col-xs-12 mobile_mp'>" +
			
			"<div class='row'>"+
			"<!--div class='col-md-2 col-sm-2 col-xs-12' align='center'>" +
            "<label style='color:#408DAE'>Choose the slot :</label>" +            
			"<button name='job_name' onclick='open_slot_modal();' id='selecttimeslot' class='btn btn-success'>Select slot</button>"+            
            "</div-->"+
			"<div class='col-md-2 col-sm-2 col-xs-12' align='center'>";
			if (sessionStorage.getItem('orderMode') == 'update'){
				htmlBanner += "<label style='color:#408DAE'>Preferred Time Slot :</label><br><label class='timeslot' style='color:#408DAE'>"+changedate(orderDetails.patientinfo.scheduled_date)+"</label>";
				sessionStorage.setItem("reject_default_vendor_id",orderDetails.provider_info[0].associate_id);
			}else{
				htmlBanner += "<label style='color:#408DAE'>Choose the slot :</label>"+
				"<button name='job_name' onclick=open_slot_modal(\""+category+"\"); id='selecttimeslot' class='btn btn-success'>Select slot</button>"+
				"<label class='timeslot' style='color:#408DAE'></label>";
				sessionStorage.setItem("reject_default_vendor_id","");
			}
            htmlBanner += "</div>"+
			"<div class='col-md-2 col-sm-1 col-xs-12'>" +            
            "<label style='color:#408DAE'>Vendor Pharma Name :</label>" +
            "<select name='vendorname' id='vendorname' class='form-control new-status' style='width:90%'>" +
            "<option value='0' selected='selected'>Select Vendor</option>" +
            "</select>" +
            "</div>" +
			
			"<div class='col-md-2 col-xs-12'>" +
            "<label style='color:#408DAE'>Gross Amount &nbsp; : &nbsp; &#8377;&nbsp; <span  class='l2vitemtotalamountgross' id='l2vitemtotalamountgross'> 0 </span></label>" +
            "<label style='color:#408DAE'>Used Wallet Amount : &nbsp; &#8377;&nbsp; <span class='l2vitemwalletamount' id='l2vitemwalletamount'> 0 </span></label>" +
            "</div>" +
            "<div class='col-md-2 col-xs-12'>" +
            "<label style='color:#408DAE'>Discount Amount &nbsp; : &nbsp; &#8377;&nbsp; <span class='l2vitemtotalamountdiscount' id='l2vitemtotalamountdiscount'> 0 </span></label>" +
            "<label style='color:#408DAE'>Delivery Charge &nbsp; : &nbsp; &#8377;&nbsp; <span class='l2vdeliverycharge' id='l2vdeliverycharge'> 0 </span></label>" +
			"<input class='medicine_delivery' id='medicine_delivery' data-id='' data-codedid='' data-item_mrp='' data-item_gross='' data-item_net='' data-item_discount='' data-ignoreToPartner='' value='0' type='hidden'>"+
            "</div>" +
            "<div class='col-md-2 col-xs-12'>" +
            "<label style='color:#408DAE'>Net Amount &nbsp; : &nbsp; &#8377;&nbsp; <span class='l2vitemtotalamount' id='l2vitemtotalamount'> 0 </span></label>" +
            "<label style='color:#408DAE'>Prepaid Amount &nbsp; : &nbsp; &#8377;&nbsp; <span class='l2vprepaidamount' id='l2vprepaidamount'> 0 </span></label>" +
            "</div>"+
	    "</article>"+
            "</section>" +
            "<section class='drug-order-items'><div class='col-md-12 col-sm-12 col-xs-12 mp'>" +
            "<div class=''>" +
            "<table class='table cust_table_order table-condensed table-bordered table-striped medicine_home_order_table' id='mtable'>" +
            "<thead>" +
            "<tr>" +
            "<th style='width: 23%;'>" +
            "Brand Name" +
            "</th>" +
            "<th style='width: 20%;'>" +
            "Pharmaceutical Name" +
            "</th>" +
            "<th>" +
            " Doctor Name" +
            "</th>" +
            "<th>" +
            "Type" +
            "</th>" +
            "<th>" +
            "Item MRP" +
            "</th>" +
            "<th style='width:80px;'>" +
            "Order Qty" +
            "</th>" +
            "<th>" +
            "Gross Amount" +
            "</th>" +
            "<th>" +
            "Discount" +
            "</th>" +
            "<th>" +
            "Net Amount" +
            "</th>" +
            "<th>" +
            " Actions" +
            "</th> " +
            "</tr>" +
            "</thead>" +
            "<tbody>";
    //console.log(orderItemsList);
    if (itemList.length > 0) {
        //console.log(orderItemsList);
        $.each(itemList, function (key, itemCodedId) {
            var currentItemMdmData = itemList.filter(function (list) {
                return (list.code === itemCodedId);
            });
            if (currentItemMdmData.roleBasedService == 1 || itemRecord.roleBasedService == '1' || itemRecord.cancelbeforeaccept == '1' || itemRecord.cancelbeforeaccept == 1) {
                return;
            }
            //console.log(itemRecord);
            //console.log(itemRecord.MRP);
            selectedDrugsList.push(itemRecord.itemname);
			//alert(itemRecord.itemname);
			var pricePerUnit = (typeof itemRecord.pricePerUnit!="undefined")?itemRecord.pricePerUnit:"";
			var discountamount = parseFloat(itemRecord.gross_amount) - parseFloat(itemRecord.net_amount);
			var doctorname = (typeof itemRecord.doctorname!="undefined")?itemRecord.doctorname:"";
            htmlBanner += "<tr class='rowdrug' id='rowdrug-"+rowcount+"'>" +
			"<td>"+
			"<div class='form-group'>" +
			"<input type='text' disabled class='form-control' value='" + itemRecord.itemname + "' name='drugsearch' data-codedid='" + itemRecord.item_code + "' data-id='" + itemRecord.item_code + "' data-category='" + itemRecord.category + "' data-priceperunit='' data-packsize='"+pricePerUnit+"' data-manufacturerid='" + itemRecord.manufacturer_id + "' data-manufacturer='" + itemRecord.manufacturer + "'>" +
			"</div>" +
			"</td>" +
			"<td>" +
			"<div class='form-group'>" +
			"<input type='text' disabled  class='form-control' value='" + itemRecord.manufacturer + "' name='pharmaname' id='pharmaname'>" +
			"</div>" +
			"</td>" +
			"<td>"+
			"<input type='text' class='form-control' value='"+doctorname+"' name='doctorname' id='doctorname'>" +
			"</td>" +
			"<td><label name='l2vsetrxotg' id='l2vsetrxotg' data-rxset='' style='display:none;'><span class='rx'>Rx</span></label></td>" +
			"<td>" +
			"<input type='text' disabled value='" + itemRecord.item_mrp + "' name='itemmrpval'  class='form-control itemmrpval' id='itemmrpval'>" +
			"</td>" +
			"<td><input type='number' min='1' class='form-control' value='" + itemRecord.quantity + "' onchange='calculate(event,this);' onkeyup='calculate(event,this);' name='quantity' id='quantity'></td>" +
			"<td>" +
			"<input type='text' disabled data-mrp=''  class='form-control grossamount' value='"+ itemRecord.gross_amount +"' name='grossamount' id='grossamount'>" +
			"</td>" +
			"<td>" +
			"<input type='text' disabled  class='form-control' value='" +discountamount+ "' name='discountAmount' id='discountamount'>" +
			"</td>" +
			//"<td><input disabled type='text'  class='form-control' data-walletamt='' value='" + itemRecord.net_amount + "' name='netAmount' id='netamount'></td>" +
			"<td>" +
			"<input disabled type='text' class='form-control' data-walletamt='' value='" + itemRecord.net_amount + "' name='netAmount' id='netamount' data-cartcouponapplied='" + itemRecord.cartCouponApplied + "' data-cartdiscountapplied='" + itemRecord.cartDiscountApplied + "' data-cartdiscountapportionedamount='" + itemRecord.cartDiscountApportionedAmount + "' data-couponvalue='" + itemRecord.coupon_amount + "' data-discountapplied='" + itemRecord.discountApplied + "' data-invoiceto='" + itemRecord.invoiceto + "' data-orderdiscountapplied='" + itemRecord.orderDiscountApplied + "' data-penalty_amount='0' data-orderapportioneddiscountamount='" + itemRecord.orderApportionedDiscountAmount + "' data-apportionedcouponamount='0' data-apportionedwalletamount='0' data-maxquantity='0' data-minquantity='0' data-voucherapportionedamount='0' data-grossamount='" + itemRecord.gross_amount + "' data-mrp='" + itemRecord.MRP + "' data-omsnetamount='" + itemRecord.net_amount + "' data-netamount='" + itemRecord.net_amount + "' data-discountamount='" +discountamount+ "'>" +
			"</td>" +
			"<td><label id='l2vaccept' title='hello'><a href='#'><i class='fa fa-info cust_check' aria-hidden='true'></i></a></label><label name='l2vcancel' id='l2vcancel' data-value='"+rowcount+"' onclick='cancellineitemdiag(this);'><i class='fa fa-times cust_times' aria-hidden='true'></i></label></td>" +
			"</tr> ";
			rowcount = rowcount +1;
        });
    } else {
        htmlBanner += "<tr class='rowdrug' id='rowdrug-"+rowcount+"'>" +
                "<td>" +
                "<div class='form-group'>" +
                "<input type='text'disabled class='form-control' name='drugsearch' >" +
                "</div>" +
                "</td>" +
                "<td>" +
                "<div class='form-group'>" +
                "<input type='text' disabled  class='form-control' name='pharmaname' id='pharmaname'>" +
                "</div>" +
                "</td>" +
                "<td>" +
                "<input type='text' class='form-control' name='doctorname' id='doctorname'>" +
                "</td>" +
                "<td><label name='l2vsetrxotg' id='l2vsetrxotg' data-rxset='' style='display:none;'><span class='rx'>Rx</span></label></td>" +
                "<td>" +
                "<input type='text' disabled value='' name='itemmrpval' class='form-control itemmrpval' id='itemmrpval'>" +
                "</td>" +
                "<td><input type='number' min='1' class='form-control' onchange='calculate(event,this);' onkeyup='calculate(event,this);' name='quantity' id='quantity'></td>" +
                "<td>" +
                "<input type='text' disabled data-mrp=''  class='form-control grossamount' name='grossamount' id='grossamount'>" +
                "</td>" +
                "<td>" +
                "<input type='text' disabled  class='form-control' name='discountAmount' id='discountamount'>" +
                "</td>" +
                "<td><input disabled type='text'  class='form-control' data-walletamt='' name='netAmount' id='netamount'></td>" +
                "<td><label id='l2vaccept' title='hello'><a href='#'><i class='fa fa-info cust_check' aria-hidden='true'></i></a></label><label name='l2vcancel' id='l2vcancel' data-value='"+rowcount+"' onclick='cancellineitemdiag(this);'><i class='fa fa-times cust_times' aria-hidden='true'></i></label></td>" +
                "</tr> ";
    }

    //console.log(htmlBanner); 
    htmlBanner += "</tbody>" +
            "</table>" +
            "</div>" +
            "<div class='col-lg-12' align='right'>" +
            "<label></label>";
	if(checkSum==".splitOne"){
    htmlBanner +="<input type='checkbox' readonly name='checkboxprescriptionsms' id='checkboxprescriptionsms' data-status='0'>&nbsp;" +
            "<span style='color:#222; font-size:13px; font-weight: bold;' id='checkboxprescriptionsmsname'>Prescription Required</span>&nbsp;" +
            "<button onclick=l2prescptionuploadl2('" + $sectionId + "') class='btn btn-success'>Add Prescription</button>&nbsp;" +
            "<button onclick=openprescriptionmadal('" + $sectionId + "') id='l2vopenprescriptionmadal' class='btn btn-success'>View Prescription</button>&nbsp;";
	}
    htmlBanner +="</div>" +
            "</div><div class='modal fade " + $sectionId + "_uploadpresc' id='' role='dialog'>" +
            "<div class='modal-dialog'>" +
            "<!-- Modal content-->" +
            "<div class='modal-content'>" +
            "<div class='modal-header'>" +
            "<button type='button' class='close' data-dismiss='modal'>&times;</button>" +
            "<h4 class='modal-title'>Upload Prescription </h4>" +
            "</div>" +
            "<div class='modal-body'>" +
            "<form  id='" + $sectionId + "_form'  method='post' enctype='multipart/form-data'>" +
            "<input type='file' name='pic[]' data-id='" + $sectionId + "' id='l2prescptionname' multiple>" +
            "<input type='hidden' name='mrn' value='" + sessionStorage.getItem('patientmrn') + "' id='orderMrn'>" +
            "<input type='hidden' name='orderid' value='' id='orderid'>" +
            "<button type='button' class='btn btn-success' data-dismiss='modal' onclick=l2prescptionuploadfroml2('" + $sectionId + "') >Upload</button>" +
            "</form>" +
            "</div>" +
            "<div class='modal-footer'>" +
            "<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>" +
            "</div>" +
            "</div>" +
            "</div>" +
            "</div><!--input id='medicine_delivery' data-id='' data-codedid='' data-item_mrp='' data-item_gross='' data-item_net='' data-item_discount='' data-ignoreToPartner='' value='0' type='hidden'--></section></section>";

    return htmlBanner;
}

function showorderview(response) {
    if (typeof data == 'string') {
        var ordersdetails = JSON.parse(response);
        ordersdetails = ordersdetails.data;
    } else {
        var ordersdetails = response.data;
    }
    var orderJson = ordersdetails.order;
    //var vendordetails = (typeof orderJson.provider_info[0] != 'undefined')?((typeof orderJson.provider_info[0].associate_id!="undefined")? orderJson.provider_info[0].associate_id:''):'';
	var vendordetails = (typeof orderJson.provider_info[0] != 'undefined')?orderJson.provider_info[0]:'';
    var disabledVendor = '';
    var hideAsignButton = '';
    if ((typeof vendordetails.associate_id != "undefined") && vendordetails.associate_id != '') {
        disabledVendor = 'disabled';
        hideAsignButton = 'display: none;';
		if(ordersdetails.OStatus==24){
			disabledVendor = '';
			hideAsignButton = '';
		}
		if((ordersdetails.OStatus == 1001 && (typeof (ordersdetails.order.prescription_images)!="undefined") && (ordersdetails.order.prescription_images).length != 0)){
			disabledVendor = '';
			hideAsignButton = '';
		}
    }
    //console.log(vendordetails);
    var orderItems = (typeof orderJson.orderitem != 'undefined') ? orderJson.orderitem : '';
    var patientinfo = orderJson.patientinfo;
    //console.log(patientinfo.scheduled_date);
    var paymentInfo = ordersdetails.payment_info;
    var patientname = patientinfo.name;
    var patientname = patientname.replace("null", "");
    var htmlBanner = '<section class="container-fluid">' +
	'<article class="p_details">' +
	'<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
	'<div class="col-md-12 col-sm-12 col-xs-12 mp">' + 
	'<h3>Order ID #' + ordersdetails._id + ' | MRN - ' + patientinfo.mrn + '| DID-No. - ' + ordersdetails.odid + '</h3>' +
	'<section class="complete_order_search">' +
	'<article class="col-md-12 col-sm-12 col-xs-12 mobile_mp">' +
	'<div class="col-md-3 col-sm-1 col-xs-12 mp">' +
	'<div class="form-group">' +
	'<label>Customer Name </br>' + patientname + ' </label>' +
	'<label>Delivery Address</label>' +
	'<small>' + patientinfo.address + '</br>' + patientinfo.landmark + '</small>' +
	'</div>' +
	'</div>' +
	'<div class="col-md-2 col-sm-6 col-xs-12 mnp">' +	
	'<label>Mobile No. </br>' + patientinfo.contact + ' </label>' +
	'<label>Alternate Mobile No. : </br>' + ((typeof patientinfo.alternetcontactno!="undefined")?patientinfo.alternetcontactno:"NA") + ' </label>' +
	'<label>Pin Code </br>' + patientinfo.pincode + ' </label>' +
	'</div>' +
	'<div class="col-md-2 col-sm-6 col-xs-12 mnp">' +
	'<label>Preferred Date/Time : </br>' + changedate(patientinfo.expected_delivery_date) + ' </label>' +
	'<label>Scheduled Date/Time : </br>';
	var myarray_ststus = [1000,1001,21,24,17];
	if(jQuery.inArray(ordersdetails.OStatus,myarray_ststus) == -1){
		htmlBanner += changedate(patientinfo.scheduled_date);
	}else{
		htmlBanner += "NA";
	}
	htmlBanner += '</label>' +
	'</div>' +
	'<div class="col-md-1 col-sm-6 col-xs-12 mnp">' +
	'<label>Payment Mode </br>'+paymentModeName[paymentInfo.payment_mode]+ ' </label>';
	if ((typeof ordersdetails.payment_info.payment_amount != "undefined") && patientinfo.prepaid == 1) {
		htmlBanner += '<label>Prepaid Amount  &#8377;&nbsp; ' + ordersdetails.payment_info.payment_amount.toFixed(2) + ' </label>';
	}
	htmlBanner += '</div>' +
	'<div class="col-md-3 col-sm-6 col-xs-12 mnp" >' +
	'<a style="padding : 10px; line-height: 35px; ' + hideAsignButton + '" class="comp_apply_btn" onclick="assignvendor(' + ordersdetails._id + ')">Assign</a>&nbsp;';

    /* if (ordersdetails.OStatus == 17 || ordersdetails.OStatus == 24) {
     htmlBanner += '<div class="col-md-2 col-sm-6 col-xs-12 mnp">' +
     '<a class="back_btn pull-left" onclick="openDetails(\'uploadPrescription\')"> Upload Prescription</a>' +
     '</div>';
     }*/
    //if (ordersdetails.OStatus == 17 || ordersdetails.OStatus == 24) {
    htmlBanner += '<div class="col-md-9 col-sm-12 col-xs-12 mnp">' +
            '<div class="form-group">';

    htmlBanner += '<select name="vendor" id="vendor" ' + disabledVendor + ' class="form-control new-status"><option value="">Select Vendor</option>';
	if(typeof vendordetails.associate_address != "undefined" && vendordetails.associate_address!=""){
		sessionStorage.setItem("reject_default_vendor_id",vendordetails.associate_id);
		//htmlBanner += '<option data-address="' + vendordetails.associate_address + '" value=' + vendordetails.associate_id + ' selected>' + vendordetails.associate_name + '</option> ';
	}else{
		sessionStorage.setItem("reject_default_vendor_id","");
	}

    //vendorList = vendordetails.length;
    htmlBanner += '</select>' +
            '</div>' +
            '</div>';
    //'<div class="col-md-4 col-sm-6 col-xs-12 mnp text-right group_btns" style="top: 56px; padding: 0px; right: 12px;">';
    if (ordersdetails.OStatus == 17 || ordersdetails.OStatus == 24 || ordersdetails.OStatus == 0){
        htmlBanner += '<a style="padding : 10px; line-height: 35px;" class="cancel_order_btn" onclick="cancelorder(' + ordersdetails._id + ')">Cancel Order</a>&nbsp;&nbsp;&nbsp;';
    }
    htmlBanner += '<a class="back_btn" id="viewPrescription" onclick="openDetails(\'uploadPrescription\')">View Prescription</a>';
    '</div>';
	/*if (ordersdetails.OStatus == 1000 || ordersdetails.OStatus == 24 || ordersdetails.OStatus == 1001) {
		htmlBanner += '<a class="back_btn" id="viewPrescription" onclick="assigntovendor(\'uploadPrescription\')">View Prescription</a>';
		'</div>';
	}*/
    // }
    htmlBanner += '' +
	'</article>' +
	'</section>' +
	'<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
	'<div class="table-responsive">' +
	'<table class="table table-condensed table-bordered table-striped medicine_home_order_table" id="toggleColumn-datatable">' +
	'<thead>' +
	'<tr>' +
	'<th>Medicine Name</th>' +
	'<th>Brand Name</th>' +
	'<th>Type</th>' +
	'<th>Doctor Name</th>' +
	'<th>MRP</th>' +
	'<th>Order Qty</th>' +
	'<th>Gross Amount</th>' +
	'<th>Discount</th>' +
	'<th>Net Amount</th>' +
	'<th>Comments</th>' +
	'<th>Actions</th>' +
	'<th>Log Info</th>' +
	'<th>Add Log</th>' +
	'</tr>' +
	'</thead>' +
	'<tbody>';
    var order_total = 0;
    var order_gross = 0;
    var order_discount = 0;
    var charge_delivery = 0;
    //var order_total=0;
    $.each(orderItems, function (key, val) {
      console.log(val.quantity);
        var item_count = orderItems.length;
        if (val.item_status != 8) {
            if (val.roleBasedService == 1 || val.roleBasedService == '1') {
                charge_delivery = parseFloat(val.net_amount).toFixed(0);
                return;
            }
            order_total += parseFloat(val.net_amount);
            order_gross += parseFloat(val.gross_amount);
            //order_discount += parseFloat(val.discount_amount);
            if (val.item_status == 9) {
                htmlBanner += '<tr style="background-color:orange">' +
				'<td>' + val.itemname + '</td>' +
				'<td>' + val.manufacturer + '</td>';
                if (val.prescribed == "1") {
                    htmlBanner += '<td><label name="l2vsetrxotg" id="l2vsetrxotg" data-rxset="true" style="display:block;"><span class="rx">Rx</span></label></td>';
                } else {
                    htmlBanner += '<td></td>';
                }
                htmlBanner += '<td>' + ((typeof val.doctor!="undefined")?val.doctor:"NA") + '</td>' +
				'<td>'+ val.MRP + '</td>' +
				'<td class="oneliner">' + ((typeof val.quantity!="undefined")?val.quantity:"1")+ ' </td>' +
				'<td>'+ val.gross_amount + '</td>' +
				'<td>'+ val.discount_amount + '</td>' +
				'<td>'+ val.net_amount + '</td>' +
				'<td><a data-toggle="tooltip" title="' + val.item_reject_reason + '">Reason</a></td>';
                if (item_count > 1) {
                    htmlBanner += '<td><button style="background-color: #0008ff;color: #eef5ee;font-weight: bold !important;" onclick=itemcancel("' + val.item_code + '",' + ordersdetails._id + ')>Cancel Item</button></td>';
                }
                else {
                    htmlBanner += ' <td>N/A</td>';
                }

                /*htmlBanner+='<td><label id="l2vaccept" title="Log details"><a href="#" class="mpt"  onclick="user_log_view(\''+ordersdetails._id+'\',\''+val.item_code+'\')"><i class="fa fa-info cust_check" aria-hidden="true"></i></a></label></td>';*/

                /** changes htmlBanner+= **/
                var box1 = '<td><div class="dropdown"><button class="dropbtn"> <i class="fa fa-info cust_check" aria-hidden="true"></i></button><div class="dropdown-content" style="right:10%;"><table class="table table-bordered table-condensed table-striped table-responsive"><thead><tr><th>Role</th><th>Name</th><th>Log Details</th><th>Date/Time</th></tr></thead><tbody>';
                var testdata = "";
                if (typeof ordersdetails.user_log != "undefined") {
                    $.each(ordersdetails.user_log, function (bkey, bval) {
                        if (bval.item_code == val.item_code) {
                            testdata += '<tr><td>' + bval.role + '</td><td>' + bval.actionbyname + '</td><td>' + bval.log_reason + '</td><td>' + bval.action_date + '</td></tr>';
                        }
                    });
                }

                if (testdata == "") {
                    htmlBanner += '<td colspan="">NA</td>';
                } else {
                    htmlBanner += (box1 + testdata + '</tbody></table></div></div></td>');
                }
                /** changes **/


                htmlBanner += '<td> <a href="#" class="mpt" onclick="openDetails(\'orderLog\',\'' + ordersdetails._id + '\',\'' + val.item_code + '\')">Add Log</a></td>' +
                        '</tr> ';
            } else {
                htmlBanner += '<tr>' +
                        '<td>' + val.itemname + '</td>' +
                        '<td>' + val.manufacturer + '</td>';
                if (val.prescribed == "1") {
                    htmlBanner += '<td><label name="l2vsetrxotg" id="l2vsetrxotg" data-rxset="true" style="display:block;"><span class="rx">Rx</span></label></td>';
                } else {
                    htmlBanner += '<td></td>';
                }
                htmlBanner += '<td>' + ((typeof val.doctor!="undefined")?val.doctor:"NA") + '</td>' +
                        '<td>' + val.MRP + '</td>' +
                        '<td class="oneliner">' +((typeof val.quantity!="undefined")?val.quantity:"1") + ' </td>' +
                        '<td>' + val.gross_amount + '</td>' +
                        '<td> ' + val.discount_amount + '</td>' +
                        '<td>' + val.net_amount + '</td>' +
                        '<td>N/A</td>' +
                        '<td>N/A</td>';
                /*htmlBanner+='<td><label id="l2vaccept" title="Log details"><a href="#" class="mpt"  onclick="user_log_view(\''+ordersdetails._id+'\',\''+val.item_code+'\')"><i class="fa fa-info cust_check" aria-hidden="true"></i></a></label></td>';*/

                /** changes htmlBanner+= **/
                var box1 = '<td><div class="dropdown"><button class="dropbtn"> <i class="fa fa-info cust_check" aria-hidden="true"></i></button><div class="dropdown-content" style="right:10%;"><table class="table table-bordered table-condensed table-striped table-responsive"><thead><tr><th>Role</th><th>Name</th><th>Log Details</th><th>Date/Time</th></tr></thead><tbody>';
                var testdata = "";
                if (typeof ordersdetails.user_log != "undefined") {
                    $.each(ordersdetails.user_log, function (bkey, bval) {
                        if (bval.item_code == val.item_code) {
                            testdata += '<tr><td>' + bval.role + '</td><td>' + bval.actionbyname + '</td><td>' + bval.log_reason + '</td><td>' + bval.action_date + '</td></tr>';
                        }
                    });
                }

                if (testdata == "") {
                    htmlBanner += '<td colspan="">NA</td>';
                } else {
                    htmlBanner += (box1 + testdata + '</tbody></table></div></div></td>');
                }
                /** changes **/

                htmlBanner += '<td> <a href="#" class="mpt" onclick="openDetails(\'orderLog\',\'' + ordersdetails._id + '\',\'' + val.item_code + '\')" >Add Log</a></td>' +
                        '</tr> ';
            }
        } else if (val.item_status == "8" && (typeof val.cancelbeforeaccept == "undefined")) {
            //for order cancel
            //item_count++;
            order_total += parseFloat(val.net_amount).toFixed(2);
            order_gross += parseFloat(val.gross_amount);
            //order_discount += parseFloat(val.discount_amount);
            htmlBanner += '<tr style="background:#FFB4B7;">' +
                    '<td>' + val.itemname + '</td>' +
                    '<td>' + val.manufacturer + '</td>';
            if (val.prescribed == "1") {
                htmlBanner += '<td><label name="l2vsetrxotg" id="l2vsetrxotg" data-rxset="true" style="display:block;"><span class="rx">Rx</span></label></td>';
            } else {
                htmlBanner += '<td></td>';
            }
            htmlBanner += '<td>' + ((typeof val.doctor!="undefined")?val.doctor:"NA") + '</td>' +
                    '<td>' + val.MRP + '</td>' +
                    '<td class="oneliner">' + ((typeof val.quantity!="undefined")?val.quantity:"1") + ' </td>' +
                    '<td>' + val.gross_amount + '</td>' +
                    '<td> ' + val.discount_amount + '</td>' +
                    '<td>' + val.net_amount + '</td>' +
                    '<td>N/A</td>' +
                    '<td>N/A</td>' +
                    '<td>N/A</td>' +
                    '<td>N/A</td>';
            htmlBanner += '</tr> ';
        }
    });

    htmlBanner +=
            '</tbody>' +
            '</table>' +
            '</div>' +
            '<div class="col-md-12 col-sm-12 col-xs-12 text-right view_prec">';
    if (ordersdetails.OStatus == 1001 || ordersdetails.OStatus == 24) {
        htmlBanner += '<div class="col-md-12"><div class="col-md-4"><button type="button" name="SendPrescription" value="Send Prescription" class="btn btn-primary pull-left" onclick="prescriptionLinkSMS(' + ordersdetails._id + ',' + ordersdetails.active_component+')">Send Prescription</button></div>'+'<div class="col-md-4"> <span class="pull-left sms">Sms Count:';
        if (typeof ordersdetails.smscount != 'undefined')
        {
            htmlBanner += ordersdetails.smscount;
        }
        else {
            htmlBanner += 0;
        }
    }
    htmlBanner += '</span></div>';
    //if (ordersdetails.OStatus != 17 || ordersdetails.OStatus != 21 || ordersdetails.OStatus != 8 || ordersdetails.OStatus != 24) {
        var wallet_amount = (typeof patientinfo.wallet_amount == "undefined" ? "0" : patientinfo.wallet_amount);
        var prepaid_amount = ((typeof ordersdetails.order.prepayment != "undefined") ? ordersdetails.order.prepayment.amount : "0");
        //var charge_delivery = (typeof patientinfo.medicine_delivery_charge == 'undefined') ? 0 : patientinfo.medicine_delivery_charge;
        order_total = order_total - wallet_amount;

        htmlBanner += '<div style="text-align:right;"><div>' + '<label>Gross Amount &nbsp; : &nbsp; &#8377;&nbsp;  ' + paymentInfo.gross_amount + '</label></div>' +
		'<div><label>Discount Amount &nbsp; : &nbsp; &#8377; ' + paymentInfo.discount_amount + '</label></div>' +
		'<div><label>Wallet Amount &nbsp; : &nbsp; &#8377; ' + paymentInfo.wallet_amount + '</label></div>' +
		'<div><label>Shipping Charges &nbsp; : &nbsp; &#8377; ' + charge_delivery + '</label></div>' +
		'<div><label>Prepaid Amount &nbsp; : &nbsp; &#8377; ' + paymentInfo.paid_amount + '</label></div>' +
		'<div><label>Net Amount &nbsp; : &nbsp; &#8377;&nbsp; <span>'+parseFloat(paymentInfo.net_amount)+'</span></label></div>'+
		'<div><label>Payable Amount &nbsp; : &nbsp; &#8377;&nbsp; <span> '+parseFloat(paymentInfo.payable_amount) + '</span></label></div></div>';
    //}
    htmlBanner += '<div class="col-md-12 col-sm-12 col-xs-12">' + ((typeof patientinfo.reject_reason == "undefined") ? "" : "<b>Reject Reason : </b>" + patientinfo.reject_reason) + '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</article>' +
            '</section>';
    var htmlModals = '<!-- Showing prescption images uplaoding for l2   -->' +
            '<div class="hideAllDetails uploadPrescription" id="uploadPrescription" style="display:none;">' +
            '<h4 class="" style="margin-top: 10px; border:0px;">Prescription </h4>' +
            '<div>' +
            '<form  id="formsum"  method="post" enctype="multipart/form-data">' +
            '<div class="col-md-3"><input type="file" name="pic[]" id ="l2prescptionname" multiple></div>' +
            '<input type="hidden" name="orderid" value='+ordersdetails._id+' id="orderid">' +
            '<div class="col-md-3"><button type="button" class="btn btn-success" onclick="l2prescptionupload()" >Upload</button></div>' +
            '</form>' +
            '</div>' +
            '<div class="clearfix"></div>' +
            '<hr style="margin-bottom: 0px;">' +
            '<div class="">' +
            '<table class="table table-striped" id="tblGrid">' +
            ' <thead id="tblHead">' +
            ' <tr>' +
            '<th>Uploaded Prescription Documents</th>' +
            ' </tr>' +
            '</thead>' +
            '<tbody>';
    if (typeof ordersdetails.order.prescription_images != 'undefined' && (ordersdetails.order.prescription_images).length != 0) {
		var i = 1;
        $.each(ordersdetails.order.prescription_images, function (key, val) {
			
            //$.each(val, function (key, val1){
				var name="Prescription - "+i;
				if(typeof val.filename!="undefined"){
					var name=val.filename;
				}				
                htmlModals += '<tr>' +
				'<td>'+i+'. '+name+' <a target="_blank" href="' + val.fullpath+ '">View</a></td>' +
				'</tr>';
				i = i +1;
            //});
        });
    } else {

        htmlModals += '<tr><td>No Prescription</td></tr>';
    }

    htmlModals += ' </tbody>' +
            '</table>' +
            '</div>' +
            '</div>' +
            '<!-- Showing Order Wise user Log  -->' +
            '<div class="hideAllDetails orderWiseUserLog" id="orderWiseUserLog" style="display:none;">' +
            '<h4 class="">Log Details </h4>' +
            '<div id="userLogbody">' +
            '</div>' +
            '</div>' +
            '<!-- Showing Order Wise Log  -->' +
            '<div class="hideAllDetails orderLog" id="orderLog" style="display:none;">' +
            '<h4 class="" style="border:0px;">Log the Activity..! </h4>' +
            '<div class="">' +
            '<div class="col-md-6">' +
            '<input type="text" id="orderlogreasons" name="orderlogreasons" class="form-control" placeholder="Log Info" required="required" style="padding: 6px 18px; font-weight: 600;">' +
            '<input type="hidden" id="log_omorder_id" name="log_omorder_id">' +
            '<input type="hidden" id="log_item_id" name="log_item_id">' +
            '</div>' +
            '<div class="col-md-2"><button type="button" class="btn btn-success" onclick="orderlogsubmit()">Submit</button></div>' +
            '<div class="clearfix"></div></div>' +
            '</div>' +
            '<!-- Showing prescption images  -->' +
            '<div class="hideAllDetails prescriptionImages" id="prescriptionImages">' +
            '</div>';
    //console.log(htmlModals);

    //$("#Custom_body").html(htmlBanner);
    //alert("working");
    //$("#Custom_search").html("");
    //$("#order_total").html(order_total);
    modelWithTab(htmlBanner, htmlModals);
    //console.log(vendordetails.associate_id);
    setTimeout(function () {    
        //console.log('comming');
		//alert(ordersdetails.order.prescription_images);
		//alert(ordersdetails.order.prescription_images.length);
		if (ordersdetails.OStatus == 1000 || ordersdetails.OStatus == 24 || (ordersdetails.OStatus == 1001 && ordersdetails.order.prescription_images.length > 0)){
			//alert("working");
			var _dataforvendor = {"systemType": "l2pharma"};
			_ajaxEventHandler("vendor_list", _dataforvendor, cbk_setvendorList);
			$("#vendor").attr('disabled',false);
			$('.comp_apply_btn').show();
		}
		$(".loader").hide(); 
    }, 500);
}


function modelWithTab(htmlBanner, htmlModals) {
    var modelTab = '<ul class="nav nav-tabs orderdetailsView">' +
            '<li class="removeActive nav veiwOrderDetails active"><a data-toggle="tab" onclick="hideAllDetails();" href="#veiwOrderDetails" id="anchor_viewOrderDetails">View Order</a></li>' +
            '<li class="disabled removeActive nav innerModal" ><a>Details</a></li>' +
            '</ul>' +
            '<div class="tab-content">' +
            '<div class="removeActive tab-pane fade veiwOrderDetails in active" id="veiwOrderDetails">' + htmlBanner + '</div>' +
            '<div class="removeActive tab-pane fade" id="innerModal">' + htmlModals + '</div>' +
            '</div>';
    var modelHtml = '<div id="viewOrder" class="modal fade" role="dialog">' +
            '<div class="modal-dialog modal-lg" style="width: 97%">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">View Order</h4>' +
            '</div>' +
            '<div class="modal-body">' + modelTab + '</div>' +
            '</div>' +
            '</div>' +
            '</div>';
    $(".loader").hide();
    $('#viewCompleteOrder').html(modelHtml);
    $('#viewOrder').modal('show');
}

function patientAddressList(addressList) {
    var addressListHtml = '';
    if (addressList.length > 0) {
        $.each(addressList, function (key, address) {
            var selectedBackground = 'style="border: 1px solid;padding: 0px 5px; color:gray;margin:0px 2.5px 5px 2.5px; width : 49.5%; height: 180px; float: left;"';
            if (address.AddressId == sessionStorage.getItem('address_id')) {
                selectedBackground = 'style="background : #d3d3d32b;border: 1px solid;padding: 0px 5px; color:gray; margin:0px 2.5px 5px 2.5px;width : 49.5%; height: 180px; float: left;"';
            }
            addressListHtml += '<div id="' + address.AddressId + '" ' + selectedBackground + '>' +
                    '<p style="background-color: gray;margin: 10px 0px;font-size: 18px;color: white;padding: 5px;font-weight: 900;">Address Name - <span class="addressNickName">' + address.AddressNickName + '</span><button style="margin-top: -1.5px;" class="btn btn-warning pull-right" value="' + address.AddressId + '" onclick="selectAddress(' + address.AddressId + ',true);">Modify</button><button style="margin-right : 5px; margin-top: -1.5px;" class="btn btn-success pull-right" value="' + address.AddressId + '" onclick="selectAddress(' + address.AddressId + ');">Select</button></p>' +
                    '<p><b>Address - </b> <span class="addressVal">' + address.addressVal + '</span>,<span class="areaVal">' + address.areaVal + '</span>,<span class="mandalVal">' + address.Mandal + '</span></p>' +
                    '<p><b>City - </b><span class="cityVal">' + address.cityVal + '</span>,<b> District - </b><span class="districtVal">' + address.district + '</span>,<b> State - </b><span class="stateVal">' + address.stateVal + '</span>,<b> Pincode - </b><span class="zipcodeVal">' + address.zipcodeVal + '</span></p>' +
                    '<p><b>Landmark - </b><span class="landMarkVal">' + address.Landmark + '</span></p>' +
                    '<p style="display: none;"><label class="latitude">' + address.LatVal + '</label> <label class="logitude">' + address.LngVal + '</label></p>' +
                    '</div>';
        });
    }

    var addressModalHtml = '<div id="addressListModal" class="modal fade" role="dialog">' +
            '<div class="modal-dialog modal-lg" style="width: 80%">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal" style="margin-top: 6px;">&times;</button>' +
            '<h4 class="modal-title" style="border:0px;">Address List</h4>' +
            '</div>' +
            '<div class="modal-body addressListModalBody">' +
            '<div class="newAddress">' +
            '<div id="editaddress" style=""> <!-- l2v -->' +
            '<div class="col-md-12 col-sm-12 col-xs-12 update_address" id="l2vupdate_address" style="display:block; border:0px;background:#f1f3f4;">' +
            '<!--div class="col-md-12"><h4>Delivery Address</h4></div--><br>' +
            '<div class="col-md-4 col-sm-4 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Address Nick Name</label>' +
            '<input id="address_nick_name" name="address_nick_name" type="text" class="form-control clearAddressData" value="">' +
            '<input id="selected_address_id" name="selected_address_id" type="text" class="form-control" value="' + sessionStorage.getItem('address_id') + '" style="display:none;">' +
            '</div>' +
            '</div>' +
            '<div class="col-md-4 col-sm-4 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Address:</label>' +
            '<textarea id="address1" class="form-control clearAddressData"></textarea>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Country:</label>' +
            '<input id="country" name="country" type="text" class="form-control " value="India" disabled>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">State / Province:</label>' +
            '<input type="text" class="form-control" list="l2vadministrative_area_level_111" id="administrative_area_level_1" value="" placeholder="select state">' +
            '<datalist id="l2vadministrative_area_level_111"><option>Telangana</option></datalist>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">City / Town:</label>' +
            '<input type="text" list="l2vlocality111" id="locality" class="form-control clearAddressData input-sm sa-bordnone" placeholder="select District" value="">' +
            '<datalist id="l2vlocality111"></datalist>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Area Location:</label>' +
            '<input type="text" list="l2vroute111" id="route" class="form-control clearAddressData" value="" placeholder="select area">' +
            '<datalist id="l2vroute111"></datalist>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Postal Code:</label>' +
            '<input class="form-control clearAddressData"  onchange="populatepopsetailsbypin(this.value)" id="postal_code" name="srch-term" type="number" size="18" value="" placeholder="Postal Code">' +
            '</div>' +
            '</div>' +
            '<div class="col-md-4 col-sm-4 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Landmark:</label>' +
            '<textarea name="job_name" id="autocomplete" onfocusout="getAddressLatLong(value)" autocomplete="off" required="required" class="form-control clearAddressData new-status ui-autocomplete-input" placeholder="Landmark"></textarea>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">POP Name:</label>' +
            '<input class="form-control clearAddressData" id="popname" name="srch-term" type="text" size="18" value="" placeholder="popname" disabled>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Primery Mobile No:</label>' +
            '<input class="form-control clearAddressData" id="pcontactno" name="srch-term" type="number" size="11" value="" placeholder="Primery contect no">' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Alternative contact No:</label>' +
            '<input class="form-control clearAddressData" id="alcontactno" name="srch-term" type="number" size="11" value="" placeholder="Alternative contect no">' +
            '</div>' +
            '</div>' +
            '<div class="col-md-3 col-sm-3 col-xs-12">' +
            '<br>' +
            '<div class="form-group" style="margin-top : 10px;">' +
            '<input class="form-control" id="district" name="srch-term" type="hidden" size="18" placeholder="District" value="">' +
            '<input type="hidden" class="form-control" id="popid" value="" style="display:inline;">' +
            '<input type="hidden" class="clearAddressData" value="" name="latitude" id="latitude">' +
            '<input type="hidden" class="clearAddressData" value="" name="longitude" id="longitude">' +
            '<a onclick="updateaddresspopn();" style="cursor:pointer;" class="update_address_btn">Save Address</a>' +
            '<a onclick="clearAddressData();" style="cursor:pointer;cursor:pointer;margin-left: 10px !important;background-color: darkred; color: #fff;padding: 8px 10px;border-radius: 0px;text-align: center;height: 34px;display: inline;font-size: 12px;line-height: 0px;text-decoration: none;" class="clear_address_btn">Clear Address</a>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-12 existingAddress" id="addressList" style="padding: 0px;">' + addressListHtml + '<div class="clearfix"></div></div>' +
            '<div class="clearfix"></div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>';
    //console.log(addressModalHtml);
    $(".loader").hide();
    $('#patientAddressList').html(addressModalHtml);
    $('#addressListModal').modal('show');
}

function renderModalPrescription(prescriptionId){
	var myModalLabel = "Prescription Files";
	var trackresult="";
    var i = 1;
	prescriptionId = prescriptionId.replace(/\-/g,'_');
	prescriptionId = prescriptionId+'_file';
    var preimgval = sessionStorage.getItem(prescriptionId);
    //console.log(preimgval);
    if (preimgval != 'undefined' && preimgval != null && preimgval != ""){
		preimgval = JSON.parse(preimgval);
		$.each(preimgval, function (key, val) {
			console.log(val);
			if(typeof val.fullpath!="undefined"){
				var name=(typeof val.filename!="undefined")?val.filename:"Prescription file "+(i+1);
				trackresult += "<div class='col-xs-12'><div class='col-xs-12' style='margin:10px;'>"+i+". "+name+ " &nbsp; &nbsp; <a href='"+val.fullpath+"' target='_blank' class='track_btn'> View </a></div></div>";
			}else{
				sessionStorage.removeItem(prescriptionId);
			}
		});
		if(trackresult==""){
			trackresult += "<div class='col-xs-12'><div class='col-xs-12' style='margin:10px;'> File is not found. </div></div>";
		}
    }else{
        trackresult += "<div class='col-xs-12'><div class='col-xs-12' style='margin:10px;'> File is not found. </div></div>";
    }
    //htmlBanner += "</div>";
    var modalfooter = "<button type='button' onclick='' class='btn btn-default sa-success' data-dismiss='modal'>close</button>";
	
	$("#myModalLabel").html(myModalLabel);
	$("#trackresult").html(trackresult);
	$("#modalfooter").html(modalfooter);
	$("#Modal_for_all").modal("show");
	//$("#Modal_for_all").modal('show');
	/*	
    $("#l2vmodal_headername").html("select Prescription");
    $("#l2vmodal_body").html(htmlBanner);
    $("#l2vmodal_footer").html(htmlBannerfooter);*/
}

function renderpendingorder(response) {
    ordersdetails = response;
    ////console.log(ordersdetails);return;
    var htmlBanner = '<br><section class="container-fluid">' +
            '<article class="main_content">' +
            '<div class="tab-content custom_tab_content">' +
            '<div role="tabpanel" class="tab-pane fade in active">' +
            '<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
            '<div class="table-responsive">' +
            '<table id="example1" cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">' +
            '<thead>' +
            '<tr>' +
            '<th>MRN</th>' +
            '<th>Order No.</th>' +
            '<th>Order DID.</th>' +
            '<th>Order Date</th>' +
            '<th>Schedule Date</th>' +
            '<th style="max-width:450px;">Items Name</th>' +
            '<th>Total Amount</th>' +
            '<th>Source</th>' +
            '<th>Status</th>' +
            '<th style="min-width:70px;">Track</th>' +
            //'<th style="min-width:70px;">View</th>' +
            '<th style="min-width:70px;">Edit</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';

    if (parseInt(ordersdetails.countn) > 0) {
        $.each(ordersdetails.data, function (key, val) {
            if (val.order.order_status.last_updated_by === 'undefined') {
                val.order.order_status.last_updated_by = "Na";
            }
            var itemname = "";
            htmlBanner += '<tr><td>' + val.order.patientinfo.mrn + '</td>' +
			'<td>' + val._id + '</td>' +
			'<td>' + val.odid + '</td>' +
			'<td>' + val.order.order_status.created_date + '</td>' +
			'<td>' + changedate(val.order.patientinfo.scheduled_date) + '</td>';
            if (typeof val.order.orderitem != "undefined" || (val.order.orderitem != null)) {
                $.each(val.order.orderitem, function (key, val1) {
                    if (val1.itemname != "" || val.OStatus == "8")
                        itemname += '' + val1.itemname + ',';
                });
            }
            htmlBanner += '<td>' + itemname + '</td>' +
			'<td>' + val.order.patientinfo.net_amount + '</td>' +
			'<td>' +channel[val.channel]+ '</td>' +
			//'<td>' + val.data[0].Nomenclature + '</td>' +
			'<td>' + val.data.Nomenclature + '</td>' +
			'<td><a onclick="trackOrder(' + val._id + ')" class="track_btn">Track</a></td>';
            //'<td> <a onclick="vieworder(' + val._id + ')" target="_new" class="view">View</a> </td>';
            if (parseInt(val.OStatus) == 24) {
				htmlBanner += '<td><a onclick="editOrderDetails(' + val._id + ',0);" class="track_btn">Open</a></td></tr>';
            } else {
				htmlBanner += '<td></td></tr>';
            }
        });
    } else {
        htmlBanner += '<tr><td colspan="8"> Data is not found.</td><tr>';
    }
    htmlBanner += '</tbody>' +
            '</table>' +
            '</div>' +
            ' </div>' +
            '</div>' +
            '</div>' +
            '</article>' +
            '<div class="modal fade in" id="l2vtrack" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">' +
            '<div class="modal-dialog" style="width:80%;">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>' +
            '<h3 class="modal-title" style="width:300px;" id="l2vtrackhead"></h3>' +
            '<label id="l2vhforhomefacility" style="width: auto;margin-top: -24px;margin-bottom: 0px;height: 21px;margin-right: 34px;" class="pull-right label label-success popup_label"></label>' +
            '</div>' +
            '<div class="modal-body" style="overflow:auto; background: #fff;" id="l2vtrackresult">' +
            '</div>' +
            '<div class="modal-footer" id="l2vtrackfooter">' +
            '<button type="button" class="btn btn-default sa-success" data-dismiss="modal" style="color:#fff;">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>'
    '</section>';
    $(".loader").hide();
    $("#l2vsearch_custom").hide();
    //$("#Custom_body").html(htmlBanner);
    //$("#l2orderdetailsdiv").css("display", "block");
    $('#Custom_search').html('');
    $("#Custom_body").html(htmlBanner);

    // $("#l2orderdetailsdiv").html(htmlBanner);
    //$("#l2ordercreatediv").css("display", "none");

}

function rendercompletedorder(response) {
    ordersdetails = response;
    var htmlBanner = '<br><section class="container-fluid">' +
            '<article class="main_content">' +
            '<div class="tab-content custom_tab_content">' +
            '<div role="tabpanel" class="tab-pane fade in active">' +
            '<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
            '<div class="table-responsive">' +
            '<table id="example1" cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">' +
            '<thead>' +
            '<tr>' +
            '<th>MRN</th>' +
            '<th>Customer Name</th>' +
            '<th>Order No.</th>' +
            '<th>Order DID.</th>' +
            '<th>Work Order ID</th>' +
            '<th>Vendor Name</th>' +
            '<th>Location</th>' +
            '<th>Source</th>' +
            '<th>Order Created Date </th>' +
            '<th>Order Status</th>' +
            '<th>Order Details</th>' +
            '<th>Track</th>' +
            '<th>Re-order</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';
    if (parseInt(ordersdetails.countn) > 0) {
        $.each(ordersdetails.data, function (key, val) {
            ////console.log(val._id);
            var patientname = val.order.patientinfo.name;
            patientname = patientname.replace("null", "");
            htmlBanner += '<tr><td>' + val.order.patientinfo.mrn + '</td>' +
			'<td>' + patientname + '</td>' +
			'<td>' + val._id + '</td>' +
			'<td>' + val.odid + '</td>' +
			'<td>' + val.wodid + '</td>' +
			'<td>' + ((typeof val.order.provider_info!="undefined")?((typeof val.order.provider_info[0].associate_name!="undefined")?val.order.provider_info[0].associate_name:""):"")+ '</td>' +
			'<td>' + val.order.patientinfo.city + '</td>' +
			'<td>' + channel[val.channel] + '</td>' +
			'<td>' + val.order.order_status.created_date + '</td>' +
			'<td>' + val.data.Nomenclature + '</td>' +
			'<td><a onclick="vieworder(' + val._id + ')" class="view">view</a></td>' +
			'<td><a onclick="trackOrder(' + val._id + ')" class="track_btn">Track</a></td>' +
			'<td><a onclick=editOrderDetails(' + val._id + ',"reorder"); class="track_btn">Order</a></td><tr>';
        });
    } else {
        htmlBanner += '<tr><td colspan="12"> Data is not found.</td><tr>';
    }
    htmlBanner += '</tbody>' +
            '</table>' +
            '</div>' +
            ' </div>' +
            '</div>' +
            '</div>' +
            '</article>' +
            '<div class="modal fade in" id="l2vtrack" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">' +
            '<div class="modal-dialog" style="width:80%;">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>' +
            '<h3 class="modal-title" style="width:300px;" id="l2vtrackhead"></h3>' +
            '<label id="l2vhforhomefacility" style="width: auto;margin-top: -24px;margin-bottom: 0px;height: 21px;margin-right: 34px;" class="pull-right label label-success popup_label"></label>' +
            '</div>' +
            '<div class="modal-body" style="overflow:auto; background: #fff;" id="l2vtrackresult">' +
            '</div>' +
            '<div class="modal-footer" id="l2vtrackfooter">' +
            '<button type="button" class="btn btn-default sa-success" data-dismiss="modal" style="color:#fff;">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>'
    '</section>';
    $(".loader").hide();
    $("#l2vsearch_custom").hide();
    //$("#Custom_body").html(htmlBanner);	
    //$("#l2orderdetailsdiv").css("display", "block");
    $('#Custom_search').html('');
    $("#Custom_body").html(htmlBanner);
    $//("#l2orderdetailsdiv").html(htmlBanner);
    //$("#l2ordercreatediv").css("display", "none");
}


function editOrderHtml(response) {
    //console.log(response);
    if (typeof response == 'string') {
        response = JSON.parse(response);
    }
    if (response.countn <= 0) {
        alert('No data found');
        return false;
    }
    var orderDetails = response.data.order;

    render_actiontab_for_mrn(); //pharma_widgets();
    renderBanner();
    renderorderHeader(response);
	var categoryId="";
	$.each(response.data.order.orderitem, function (key, val) {
		if((typeof val.category != "undefined") && (typeof val.roleBasedService != 1)){
			categoryId = val.category;
			return false;
		}
	});
	
	if(jQuery.inArray(categoryId, splitone) !== -1){
    //if ((categoryId <= 7 || categoryId === 10) && categoryId!==4) {
        category = 'splitOne';
    } else {
        category = 'splitTwo';        
    }	
	
    var htmlBanner = addDrugSearchItemsList(category, 1, response);
    var referedby = '';
    if (typeof orderDetails.patientinfo.referedby != 'undefined') {
        referedby = orderDetails.patientinfo.referedby;
    }

    var referred_mrn = '';
    if (typeof orderDetails.patientinfo.referred_mrn != 'undefined') {
        referred_mrn = orderDetails.patientinfo.referred_mrn;
    }

    var coupon = '';
    if (typeof orderDetails.patientinfo.coupon != 'undefined') {
        coupon = orderDetails.patientinfo.coupon;
    }

    var source_of_referral = '';
    if (typeof orderDetails.patientinfo.source_of_referral != 'undefined') {
        source_of_referral = orderDetails.patientinfo.source_of_referral;
    }

    //console.log(htmlBanner);
    var htmlRefferBanner = "<section class='container-fluid coupon_block'>" +
	"<div class='col-lg-7'>" +
	"<div class='col-lg-3'>" +
	"<label style='color:#408DAE; font-weight:bold;'>Source of Referral*</label><br>" +
	"<select type='text' id='l2vsourcereferral' class='form-control' style='min-width:140px;'><option value=''>Choose officer id</option></select>" +
	"</div>" +
	"<!--div class='col-lg-4'>" +
	"<label style='color:#408DAE; font-weight:bold;'>Coupon</label><br>" +
	"<input type='text' placeholder='Please enter coupon code' id='l2vCoupanCode' value='" + coupon + "' class='form-control' style='width:140px; display:inline-block;'>" + "&nbsp;<button onclick='applycoupen()' class='btn btn-danger' style='background:#277B72; height:35px; line-height:26px; padding-left:6px; padding-right:6px;'>Remove</button><br>" + "<b style='font-size:12px; color:#d22;'>Note:*Re-apply the Coupon Code When Add/Edit item </b>" +
	"</div-->" +
	"<div class='col-lg-4'>" +
	"<label style='color:#408DAE; font-weight:bold;'>Coupon</label><br>" +
	"<input type='text' placeholder='Please enter coupon code' disabled='disabled' value='" + coupon + "' id='l2vCoupanCode' data-code='' class='form-control' style='width:140px; display:inline-block;'>" + "&nbsp;<button onclick='removecoupen()' class='btn btn-danger' style='height:35px; line-height:26px; padding-left:6px; padding-right:6px;'>Remove</button><br>" + "<a style='font-size:12px; color:#3E3C6C; font-weight:bold; cursor:pointer;' onclick='showcoupon()'>View Coupons</a><br>" + "<b style='font-size:12px; color:#d22;'>Note:*Re-apply the Coupon Code When Add/Edit item </b>" +
	"</div>" +
	"<div class='col-lg-3'>" +
	"<label style='color:#408DAE; font-weight:bold;'>Referred By*</label><br>" +
	"<input type='text' onkeyup='findofferid();' list='referedbylist' value='" + referedby + "' placeholder='Please officer id' id='l2vreferby' class='form-control referedbylist' style='min-width:140px;'><datalist id='referedbylist'></datalist>" +
	"</div>" +
	"<div class='col-lg-2'>" +
	"<label style='color:#408DAE; font-weight:bold; min-width:150px;'>Referred by mrn</label><br>" +
	"<input type='number' placeholder='Please enter mrn.' id='l2vsreferbymrn' class='form-control' value='" + referred_mrn + "' style='min-width:150px;'>" +
	"</div>" +
	"<div class='col-lg-4'></div>" +
	"</div>";
	if (sessionStorage.getItem('orderMode') == 'update'){
		htmlRefferBanner +="<div class='col-lg-12' align='right'><button onclick='updateDrugOrder()' class='btn btn-success'> Assign To Vendor </button><br><br></div>";
	}else{
		htmlRefferBanner +="<div class='col-lg-12' align='right'><button onclick='createNewDrugOrder()' class='btn btn-success'> Book </button><br><br></div>";
	}
	htmlRefferBanner +="</section>" +
	"<div class='modal fade' id='couponlistmodal' role='dialog'>" +
	"<div class='modal-dialog'>" +
	"<!-- Modal content-->" +
	"<div class='modal-content'>" +
	"<div class='modal-header'>" +
	"<button type='button' class='close' data-dismiss='modal'>&times;</button>" +
	"<h4 class='modal-title'>Coupon List</h4>" +
	"</div>" +
	"<div class='modal-body' align='left'>" +
	"<table border='1' style='margin:10px; width:95%;'><thead><tr style='background:#0F7C75; color:#fff;'><th>Coupons Name</th><th>Description</th><th>Action</th></tr></thead><tbody id='couponlist'>" +
	"</tbody></table>" +
	"</div>" +
	"<div class='modal-footer'>" +
	"<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>" +
	"</div>" +
	"</div>" +
	"</div>" +
	"</div>";
    htmlBanner += '<div id="patientAddressList"></div>';
    htmlBanner += htmlRefferBanner;
    //console.log(htmlBanner);
    $('#Custom_body').html(htmlBanner);
	setTimeout(function () {
		newCheckpricefrommdm();
		var _dataforvendor = {"systemType": "l2pharma"};
		var associateId = orderDetails.provider_info[0].associate_id;
		sessionStorage.setItem('associate_id', associateId);
		_ajaxEventHandler("vendor_list", _dataforvendor, cbk_setvendorinselecttag);
		if (source_of_referral != 'undefined' && $.trim(source_of_referral) != '') {
			$('#l2vsourcereferral option[value=' + source_of_referral + ']').attr('selected', true);
		}
		cbk_open_patient_orders(response);
	}, 500);
	
    //timeslotselect();
    //console.log(selectedDrugsList);
}


function trackOrderView(result){
	var modalfooter='<button type="button" class="btn btn-default sa-success" data-dismiss="modal" style="color:#fff;">Close</button>';
	var myModalLabel="Order Tracking Status";
	var trackresult="";
	if(result.status==1){
		var tdata = ''; 
		if(result.data.order_log.length <= 0){
			tdata = '<h4>No Data</h4>';
			$('#trackresult').html(tdata);
			$('#track').modal('show');
		}else{
			tdata="<table class='table table-responsive'><thead><tr>"+
			"<th>Order</th>"+
			"<th>User Name</th>"+
			"<th>User ID</th>"+
			"<th>Role</th>"+
			"<th>Action</th>"+
			"<th>Order Status</th>"+
			"<th>Updated On</th>"+
			"<th>Text</th>"+
			"</tr></thead><tbody>";
			$.each(result.data.order_log, function (key, val) {
				tdata +='<tr><td>'+val.wodid+'</td>'+
				'<td>'+val.actionByName+'</td>'+
				'<td>'+val.actionById+'</td>'+
				'<td>'+val.role+'</td>'+
				'<td>'+val.action+'</td>'+
				'<td>'+((typeof val.status_name !="undefined")?val.status_name:"")+'</td>'+
				'<td>'+val.created_date+'</td>'+
				'<td>'+val.reason+'</td></tr>';
			});
			tdata += '</tbody></table>';
			trackresult = tdata;
		}		
	}else{
		trackresult = result.message;
	}
	$(".loader").hide();
	$("#myModalLabel").html(myModalLabel);
	$("#trackresult").html(trackresult);
	$("#modalfooter").html(modalfooter);
	$("#Modal_for_all").modal('show');
}


function cbk_wallet_transction_history(result){
	var modalfooter='<button type="button" class="btn btn-default sa-success" data-dismiss="modal" style="color:#fff;">Close</button>';
	var myModalLabel="Wallet Transaction History";
	var trackresult="";
	if(result.status==1){
		var tdata = ''; 
		if(result.data.length <= 0){
			tdata = '<h4>No Data Found</h4>';
			$('#trackresult').html(tdata);
			$('#track').modal('show');
		}else{
			tdata="<table class='table table-responsive'><thead><tr>"+
			"<th>Transactions</th>"+
			"<th>Credit</th>"+
			"<th>Debit</th>"+
			"<th>Validity</th>"+
			"</tr></thead><tbody>";
			$.each(result.data,function(key,val){
				var credit="-";
				var debit="-";
				if((parseFloat(val.amount)<0)){
					debit=val.amount.toString().replace('-','');;
				}else{
					credit=val.amount.toString().replace('+','');
				}
				tdata +='<tr><td>'+val.dateCreated.dayOfMonth+"-"+
				(parseInt(val.dateCreated.month)+1)+"-"+
				val.dateCreated.year+" "+
				val.dateCreated.hourOfDay+":"+
				val.dateCreated.minute+":"+
				val.dateCreated.second+
				"<br>Wallet Reference # "+val.walletID+"<br>"+
				((typeof val.description!='undefined')?val.description:"")+
				'</td>'+
				'<td>'+credit+'</td>'+
				'<td>'+debit+'</td>'+
				'<td>'+((typeof val.validityDateStr!='undefined')?val.validityDateStr:"")+'</td></tr>';
			});
			tdata += '</tbody></table>';
			trackresult = tdata;
		}		
	}else{
		trackresult = result.message;
	}
	$(".loader").hide();
	$("#myModalLabel").html(myModalLabel);
	$("#trackresult").html(trackresult);
	$("#modalfooter").html(modalfooter);
	$("#Modal_for_all").modal('show');
}

function cbk_getprescriptionCP(result){
	var modalfooter='<button type="button" class="btn btn-default sa-success" data-dismiss="modal" style="color:#fff;">Close</button>';
	var myModalLabel="Customer Uploaded Prescriptions";
	var trackresult="";
	if(result.status==1){
		var tdata = ""; 
		var check=0;
		$.each(result.Data,function(key,val){
			//if(val.ehr_type=="22"){
				tdata+="<div class='col-xs-12'><div class='col-xs-12' style='margin:10px;'>"+$.trim(val.prescrption_date)+" &nbsp;&nbsp;&nbsp;<a href='"+$.trim(val.path)+"' target='_blank' class='track_btn'> View </a></div></div>";
				check=1;
			//}
		});
		if(check==0){
			trackresult = '<h5>File is not Found</h5>';
		}else{
			trackresult = "<div class='row'>"+tdata+"</div>";
		}		
	}else{
		trackresult = '<h5>File is not Found</h5>';
	}
	$(".loader").hide();
	$("#myModalLabel").html(myModalLabel);
	$("#trackresult").html(trackresult);
	$("#modalfooter").html(modalfooter);
	$("#Modal_for_all").modal('show');
}

function past_prescriptionview(ordersdetails){
	$("#right_side").toggle();
	var htmlBanner="";
	ordersdetails=JSON.parse(ordersdetails);
	if(ordersdetails.status=="1"){		
		//console.log(ordersdetails.data);
		$.each(ordersdetails.data,function(key,val){
			htmlBanner+='<div><table>';
			htmlBanner+='<tr><td><b>Order Date : - </b>'+val.order_date+'</td></tr>';
			htmlBanner+='<tr><td><a class="btn btn-info" target="_blank" href="'+val.filepath+'"> View </a></td></tr>';
			htmlBanner+='</table></div>';
		});
	}else{
		//console.log(ordersdetails.message);
	}
	$("#right_side_header span").html("Last 3 months prescription");
	if($.trim(htmlBanner)==""){
		htmlBanner="<div>Data is not found.</div>";
	}
	$("#showdetails").html(htmlBanner);
	$(".loader").hide();
}




function prepareOrder(mdmData,selectedDrugDetails){
    var htmlBanner = '';
    var lineItemDetailsArray = mdmData.lineItemList;
    var i =1;
    $.each(mdmData.medicineDeliveryChargesList,function(key,value){
        console.log('slot-'+key+'---');
        console.log(value);
        var htmlLineItem = '';
        var itemCodeList = value.services;
        var lineItems = [];
        var totalDiscount = 0;
        var totalGross = 0;
        var totalNetAmount = 0;
        var totalWalletAmount = 0;
        var deliveryCharges =  value.OMSNetAmount;
        console.log(itemCodeList);
        $.each(itemCodeList,function(itemkey,itemvalue){
                lineItemDetailsArray.some(function(item){
                    if(item.code == itemvalue){
                        console.log(item);
                        lineItems.push(item);
                    }
                });
            });
            console.log(lineItems);
            var i =1;
          $.each(lineItems,function(lineItemKey,lineItemvalue){
              console.log(lineItemvalue);
              var metadata = selectedDrugDetails.filter(function(item){
                 return (item.codedid == lineItemvalue.code);
              });
              metadata = metadata[0];
              console.log(metadata);
              var discount = ((typeof lineItemvalue.discountAmount != 'undefined') ? lineItemvalue.discountAmount : 0) +
                             ((typeof lineItemvalue.apportionedDiscountAmount != 'undefined') ? lineItemvalue.apportionedDiscountAmount : 0) +
                             ((typeof lineItemvalue.orderApportionedDiscountAmount != 'undefined') ? lineItemvalue.orderApportionedDiscountAmount : 0);   
                    
                totalDiscount = totalDiscount + discount;
                totalDiscount = parseFloat(totalDiscount).toFixed(2);
                totalGross = totalGross + parseFloat(lineItemvalue.grossAmount);
                totalNetAmount = totalNetAmount + parseFloat(lineItemvalue.OMSNetAmount);
                totalWalletAmount = totalWalletAmount + parseFloat(lineItemvalue.apportionedWalletAmount);
                console.log(totalWalletAmount);
                var showRx = 'display:none;';
                if((lineItemvalue.prescribed === true) || (lineItemvalue.prescribed == 'true')){
                    showRx = '';
                }
              htmlLineItem += "<tr class='rowdrug' id='rowdrug-"+i+"'>" +
                "<td>" +
                "<div class='form-group'>" +
                "<input type='text'disabled class='form-control' name='drugsearch' data-split='split-"+key+"' value='"+lineItemvalue.itemName+"' data-codedid='"+metadata.codedid+"' data-id='"+metadata.id+"' data-category='"+metadata.category+"' data-priceperunit='"+metadata.priceperunit+"' data-packsize='"+metadata.packsize+"' data-manufacturerid='"+metadata.manufacturerid+"' data-manufacturer='"+metadata.manufacturer+"' data-id='"+metadata.id+"' >" +
                "</div>" +
                "</td>" +
                "<td>" +
                "<div class='form-group'>" +
                "<input type='text' disabled  class='form-control' name='pharmaname' value='"+metadata.pharma+"' id='pharmaname'>" +
                "</div>" +
                "</td>" +
                "<td>" +
                "<input type='text' class='form-control' name='doctorname' id='doctorname'>" +
                "</td>" +
                "<td><label name='l2vsetrxotg' id='l2vsetrxotg'  data-rxset='' style='"+showRx+"'><span class='rx'>Rx</span></label></td>" +
                "<td>" +
                "<input type='text' disabled value='"+lineItemvalue.unitPrice+"' name='itemmrpval' class='form-control itemmrpval' id='itemmrpval'>" +
                "</td>" +
                "<td><input type='number' min='1' class='form-control' value="+lineItemvalue.sessions+" onchange='calculate(event,this);' onkeyup='calculate(event,this);' data-split='split-"+key+"' name='quantity' id='quantity'></td>" +
                "<td>" +
                "<input type='text' disabled data-mrp=''  class='form-control grossamount' name='grossamount' value='"+lineItemvalue.grossAmount+"' id='grossamount'>" +
                "</td>" +
                "<td>" +
                "<input type='text' disabled  class='form-control' name='discountAmount' value='"+discount+"' id='discountamount'>" +
                "</td>" +
                "<td><input disabled type='text'  class='form-control' data-walletamt='' name='netAmount' value='"+lineItemvalue.OMSNetAmount+"' id='netamount' data-cartCouponApplied=''></td>" +
                "<td><label id='l2vaccept' title='hello'><a href='#'><i class='fa fa-info cust_check' aria-hidden='true'></i></a></label><label name='l2vcancel' data-split='split-"+key+"' id='l2vcancel' data-value='"+i+"' onclick='cancellineitemdiag(this);'><i class='fa fa-times cust_times' aria-hidden='true'></i></label></td>" +
                "</tr> ";
              i++; 
          });  
        
        totalNetAmount = (totalNetAmount + deliveryCharges) - totalWalletAmount;
        totalNetAmount = parseFloat(totalNetAmount).toFixed(2);
        totalWalletAmount = parseFloat(totalWalletAmount).toFixed(2);
        var timeslot = $('.timeslot').html();
        htmlBanner += "<section data-sectionid='split-" + key + "' class='container-fluid new-order-by-category split-" + key + "' name='drug_orders' id='l2vsearch_custom' >" +
            "<section class='complete_order_search drug-order-gross-details' style='background:#ECF8F8; border: 1px #C4C4C4 solid; margin:15px 0px -4px 0px;'>" +
            "<article class='col-md-12 col-sm-12 col-xs-12 mobile_mp'>" +
			"<div class='row'>"+
			"<!--div class='col-md-2 col-sm-2 col-xs-12' align='center'>" +
            "<label style='color:#408DAE'>Choose the slot :</label>" +            
			"<button name='job_name' onclick='open_slot_modal();' id='selecttimeslot' class='btn btn-success'>Select slot</button>"+            
            "</div-->"+
			"<div class='col-md-2 col-sm-2 col-xs-12' align='center'>";
			if (sessionStorage.getItem('orderMode') == 'update'){
				htmlBanner += "<label style='color:#408DAE'>Preferred Time Slot :</label><br><label class='timeslot' style='color:#408DAE'>"+timeslot+"</label>";
				//sessionStorage.setItem("reject_default_vendor_id",mdmData.provider_info[0].associate_id);
			}else{
				htmlBanner += "<label style='color:#408DAE'>Choose the slot :</label>"+
				"<button name='job_name' onclick=open_slot_modal(\"split-"+key+"\"); id='selecttimeslot' class='btn btn-success'>Select slot</button>"+
				"<label class='timeslot' style='color:#408DAE'></label>";
				sessionStorage.setItem("reject_default_vendor_id","");
			}
            htmlBanner += "</div>"+
			"<div class='col-md-2 col-sm-1 col-xs-12'>" +            
            "<label style='color:#408DAE'>Vendor Pharma Name :</label>" +
            "<select name='vendorname' id='vendorname' class='form-control select-vendorname new-status' style='width:90%'>" +
            "<option value='0' selected='selected'>Select Vendor</option>" +
            "</select>" +
            "</div>" +
			
	    "<div class='col-md-2 col-xs-12'>" +
            "<label style='color:#408DAE'>Gross Amount &nbsp; : &nbsp; &#8377;&nbsp; <span  class='l2vitemtotalamountgross' id='l2vitemtotalamountgross'> "+totalGross+" </span></label>" +
            "<label style='color:#408DAE'>Used Wallet Amount : &nbsp; &#8377;&nbsp; <span class='l2vitemwalletamount' id='l2vitemwalletamount'> "+totalWalletAmount+" </span></label>" +
            "</div>" +
            "<div class='col-md-2 col-xs-12'>" +
            "<label style='color:#408DAE'>Discount Amount &nbsp; : &nbsp; &#8377;&nbsp; <span class='l2vitemtotalamountdiscount' id='l2vitemtotalamountdiscount'> "+totalDiscount+" </span></label>" +
            "<label style='color:#408DAE'>Delivery Charge &nbsp; : &nbsp; &#8377;&nbsp; <span class='l2vdeliverycharge' id='l2vdeliverycharge'> "+deliveryCharges+" </span></label>" +
	    "<input class='medicine_delivery' id='medicine_delivery' data-id='' data-codedid='' data-item_mrp='' data-item_gross='' data-item_net='' data-item_discount='' data-ignoreToPartner='' value='0' type='hidden'>"+
            "</div>" +
            "<div class='col-md-2 col-xs-12'>" +
            "<label style='color:#408DAE'>Net Amount &nbsp; : &nbsp; &#8377;&nbsp; <span class='l2vitemtotalamount' id='l2vitemtotalamount'> "+totalNetAmount+" </span></label>" +
            "<label style='color:#408DAE'>Prepaid Amount &nbsp; : &nbsp; &#8377;&nbsp; <span class='l2vprepaidamount' id='l2vprepaidamount'> 0 </span></label>" +
            "</div>"+
	    "</article>"+
            "</section>" +
            "<section class='drug-order-items'><div class='col-md-12 col-sm-12 col-xs-12 mp'>" +
            "<div class=''>" +
            "<table class='table cust_table_order table-condensed table-bordered table-striped medicine_home_order_table' id='mtable'>" +
            "<thead>" +
            "<tr>" +
            "<th style='width: 23%;'>" +
            "Brand Name" +
            "</th>" +
            "<th style='width: 20%;'>" +
            "Pharmaceutical Name" +
            "</th>" +
            "<th>" +
            " Doctor Name" +
            "</th>" +
            "<th>" +
            "Type" +
            "</th>" +
            "<th>" +
            "Item MRP" +
            "</th>" +
            "<th style='width:80px;'>" +
            "Order Qty" +
            "</th>" +
            "<th>" +
            "Gross Amount" +
            "</th>" +
            "<th>" +
            "Discount" +
            "</th>" +
            "<th>" +
            "Net Amount" +
            "</th>" +
            "<th>" +
            " Actions" +
            "</th> " +
            "</tr>" +
            "</thead>" +
            "<tbody>";
    
        htmlBanner += htmlLineItem;
        
        htmlBanner += "</tbody>" +
            "</table>" +
            "</div>" +
            "<div class='col-lg-12' align='right'>" +
            "<label></label>";
    
    htmlBanner +="<input type='checkbox' readonly name='checkboxprescriptionsms' id='checkboxprescriptionsms' data-status='0'>&nbsp;" +
            "<span style='color:#222; font-size:13px; font-weight: bold;' id='checkboxprescriptionsmsname'>Prescription Required</span>&nbsp;" +
            "<button onclick=l2prescptionuploadl2('split-" + key + "') class='btn btn-success'>Add Prescription</button>&nbsp;" +
            "<button onclick=openprescriptionmadal('split-" + key + "') id='l2vopenprescriptionmadal' class='btn btn-success'>View Prescription</button>&nbsp;";
	
    htmlBanner +="</div>" +
            "</div><div class='modal fade split-" + key + "_uploadpresc' id='' role='dialog'>" +
            "<div class='modal-dialog'>" +
            "<!-- Modal content-->" +
            "<div class='modal-content'>" +
            "<div class='modal-header'>" +
            "<button type='button' class='close' data-dismiss='modal'>&times;</button>" +
            "<h4 class='modal-title'>Upload Prescription </h4>" +
            "</div>" +
            "<div class='modal-body'>" +
            "<form  id='split-" + key + "_form'  method='post' enctype='multipart/form-data'>" +
            "<input type='file' name='pic[]' data-id='split-" + key + "' id='l2prescptionname' multiple>" +
            "<input type='hidden' name='mrn' value='" + sessionStorage.getItem('patientmrn') + "' id='orderMrn'>" +
            "<input type='hidden' name='orderid' value='' id='orderid'>" +
            "<button type='button' class='btn btn-success' data-dismiss='modal' onclick=l2prescptionuploadfroml2('split-" + key + "') >Upload</button>" +
            "</form>" +
            "</div>" +
            "<div class='modal-footer'>" +
            "<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>" +
            "</div>" +
            "</div>" +
            "</div>" +
            "</div><!--input id='medicine_delivery' data-id='' data-codedid='' data-item_mrp='' data-item_gross='' data-item_net='' data-item_discount='' data-ignoreToPartner='' value='0' type='hidden'--></section></section>";

    });
    
    return htmlBanner;
}
