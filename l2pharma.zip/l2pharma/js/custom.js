var vendorList = 0;
var checkSum = '';
var selectedDrugsList = [];
var activeSection = 0;
var activeDrugSearch = false;
var currentReqt;
var rowcount = 0;
var selecteddiag = '';
var selectedDrugDetails = [];
var mdmLineItemList = [];
var para_val_del = '';
var updateCategory = '';
var global_selecteddiag='';
var global_serviceable=0;
//var global_serviceable=1;

function patient_search(searchType, searchText, records_per_page, pagenumber, responsefun) {
	records_per_page = records_per_page || 10;
	pagenumber = pagenumber || 1;
	responsefun = responsefun || 'patient_search_list';
	var _data = {searchType: searchType, searchText: searchText, records_per_page: records_per_page, pagenumber: pagenumber};
	_ajaxEventHandler("customerSearch", _data, responsefun, SHOW_LOADER);
	$("#patientsearchvalue").val(searchText);
	$("#patientsearchtype").val(searchType);
}

function open_patient_details() {
	var searchText = $("#patientsearchvalue").val();
	var searchType = $("#patientsearchtype").val();
	sessionStorage.setItem('orderMode', 'new');
	if(searchType=="mobile"){
		patient_search(searchType, searchText, 10, 1, patient_search_list);
	}else{
		patient_search(searchType, searchText, 10, 1, cbk_open_patient_records);
	}
	//patient_search(searchType, searchText, 10, 1, cbk_open_patient_records);
}

function cbk_open_patient_records(response) {
    if (typeof response.status != "undefined" && response.status == 1){
        for (var i = 0; i < sessionStorage.length; i++){
			if (sessionStorage.key(i).substring(0, 14) == 'new_drug_order') {
				sessionStorage.removeItem(sessionStorage.key(i));
			}
        }

        checkSum = '.split-0';
        var Obj = response.data.customerList[0];
        //sessionStorage.setItem("patientid", ""); // required
		sessionStorage.setItem('orderMode',"new");
		sessionStorage.setItem('orderid', "");
        sessionStorage.setItem("name", Obj.salutation + " " + Obj.firstName + " " + Obj.lastName);
        sessionStorage.setItem("salutation", Obj.salutation);
        sessionStorage.setItem("patientfname", Obj.firstName);
        sessionStorage.setItem("patientlname", Obj.lastName);
        sessionStorage.setItem("patientmrn", Obj.mrn);
        //sessionStorage.setItem("mrn", Obj.mrn);
        //sessionStorage.setItem("displaygender", Obj.Gender);
        sessionStorage.setItem("patientgender", setgender(Obj.gender));
        sessionStorage.setItem("patientdob", Obj.dob);
        sessionStorage.setItem("age", age_calculation(sessionStorage.getItem("patientdob"))); // required
        sessionStorage.setItem("email", Obj.email);
        sessionStorage.setItem("contactno", Obj.mobile);
        sessionStorage.setItem("alternetcontactno", ""); // required
        sessionStorage.setItem("servicetype", "2");
        sessionStorage.setItem("TagName", Obj.tagsList.toString());
        //addressVal
        if(typeof Obj.defaultAddressDetails[0] != 'undefined'){
            sessionStorage.setItem("area", Obj.defaultAddressDetails[0].areaVal);
            sessionStorage.setItem("landmark", Obj.defaultAddressDetails[0].landmark);
            sessionStorage.setItem("city", Obj.defaultAddressDetails[0].cityVal);
            sessionStorage.setItem("district", Obj.defaultAddressDetails[0].district);
            sessionStorage.setItem("state", Obj.defaultAddressDetails[0].stateVal);
            sessionStorage.setItem("country", Obj.defaultAddressDetails[0].countryVal);
            sessionStorage.setItem("zipcode", Obj.defaultAddressDetails[0].zipcodeVal);
            sessionStorage.setItem("longitude", Obj.defaultAddressDetails[0].lngVal);
            sessionStorage.setItem("latitude", Obj.defaultAddressDetails[0].latVal);
            sessionStorage.setItem("address_id", Obj.defaultAddressDetails[0].addressId);
            sessionStorage.setItem("address_type_id", Obj.defaultAddressDetails[0].addressType);
            sessionStorage.setItem("address_nickname", Obj.defaultAddressDetails[0].addressNickName);
            var address = Obj.defaultAddressDetails[0].addressVal + ", " +
            Obj.defaultAddressDetails[0].areaVal + ", " +
            Obj.defaultAddressDetails[0].cityVal + ", " +
            Obj.defaultAddressDetails[0].stateVal + ", " +
            Obj.defaultAddressDetails[0].countryVal + ", " +
            Obj.defaultAddressDetails[0].zipcodeVal;
            sessionStorage.setItem("address", address);
        }else{
            sessionStorage.setItem("area", '');
            sessionStorage.setItem("landmark", '');
            sessionStorage.setItem("city", '');
            sessionStorage.setItem("district", '');
            sessionStorage.setItem("state", '');
            sessionStorage.setItem("country", '');
            sessionStorage.setItem("zipcode", '');
            sessionStorage.setItem("longitude", '');
            sessionStorage.setItem("latitude", '');
            sessionStorage.setItem("address_id", '');
            sessionStorage.setItem("address_type_id", '');
            sessionStorage.setItem("address_nickname", '');
            sessionStorage.setItem("address", '');
			alert("Please add the Address before adding the Medicine.");
        }
        sessionStorage.setItem("walletstatus", "0")

        //remain
        sessionStorage.setItem("ordersmscreate", "0");
        sessionStorage.setItem("doctorid", "");
        sessionStorage.setItem("doctorname", "");
        $("#address1").val(sessionStorage.getItem('address'));
        $("#locality").val(sessionStorage.getItem('city'));
        $("#administrative_area_level_1").val(sessionStorage.getItem('state'));
        $("#route").val(sessionStorage.getItem('district'));
        $("#postal_code").val(sessionStorage.getItem('zipcode'));
        $("#autocomplete").val(sessionStorage.getItem('landmark'));
        $("#popname").val(sessionStorage.getItem('popname'));
        $("#popid").val(sessionStorage.getItem('facility_id'));
        $("#latitude").val(sessionStorage.getItem('latitude'));
        $("#longitude").val(sessionStorage.getItem('longitude'));
        $("#pcontactno").val(sessionStorage.getItem('contactno'));
        $("#alcontactno").val(sessionStorage.getItem('alternetcontactno'));
        render_actiontab_for_mrn(); //pharma_widgets();
        renderBanner();
        renderorderHeader();
        cbk_open_patient_orders({countn: 0});
        renderCreateOrder();
		check_servisablepincode();
        //timeslotselect();
	} else {
       $(".loader").hide();
       alert('Please provide correct mrn code');
       $('#patientsearchvalue').val('');
	}
}

//open the order tab with and without order id
function cbk_open_patient_orders(response) {
	$(".loader").hide();
	sessionStorage.setItem("orderstatuscurorder", "");
	sessionStorage.setItem("encounterid", "");
	sessionStorage.setItem("source_of_referral", "");
	sessionStorage.setItem("prescription_file_length", "0");
	_ajaxEventHandler("getsource_of_referral", "", cbk_getsource_of_referral, '');
	//console.log(response);
	if (response.countn < 1) {
		renderCreateOrder(response);
	}
	var _datamrn = {"mrn": sessionStorage.getItem("patientmrn")};
	//check mrn is related to corporate or not.
	sessionStorage.setItem("mrncoporateid", "");
	sessionStorage.setItem("mrncoporatename", "");
	_ajaxEventHandler("get_customer_type", _datamrn, cbk_get_customer_type,'');
	if (response.countn > 0) {} 
	else {
		if ($.trim(sessionStorage.getItem("encounterid")) != "") {
			$("#l2vopenprescriptionmadal").show();
		} else {
			$("#l2vopenprescriptionmadal").hide();
		}
		sessionStorage.setItem("walletstatus", "0");
		newCheckpricefrommdm();
	}
	getwalletamt();
}

// Wallet //
function getwalletamt(){
	var _datamrn = {"mrn": sessionStorage.getItem("patientmrn")};
    _ajaxEventHandler("getwalletamt", _datamrn, cbk_getwalletamt, '');
}

function cbk_getwalletamt(res) {
	//console.log(res);
	if (res.status == 1) {
		var walletamount = res.amount;
        walletamount = parseFloat(walletamount.replace(/,/g, "")).toFixed(2);
        sessionStorage.setItem("walletamount", walletamount);
        $("#l2vwalletamt").html(walletamount);
        //$(".l2vwalletamt").html(walletamount);
	} else {
		$("#l2vwalletamt").html(0);
        //$(".l2vwalletamt").html(0);
        sessionStorage.setItem("walletamount", 0);
	}
	$(".loader").hide();
}
// End Wallet //

function cbk_getsource_of_referral(data){
	var obj = '';
	if (typeof data == 'string') {
		obj = JSON.parse(data);
	} else {
		obj = data;
	}
	var str = "<option value=''>Choose refferal source</option>";
    if (obj.status == 1 || obj.status == '1') {
		$.each(obj.data, function (key, val) {
		str += "<option value='" + $.trim(val.name) + "'>" + $.trim(val.name) + "</option>";
		});
	}
	$("#l2vsourcereferral").html(str);
    if (sessionStorage.getItem("source_of_referral") != "") {
		var referral = sessionStorage.getItem("source_of_referral");
        //console.log($('#l2vsourcereferral').html());
        //console.log(referral);
        $('#l2vsourcereferral').val($.trim(referral));
	}
}

function cbk_get_customer_type(res){
	if (res.status === "0"){
		sessionStorage.setItem("mrncoporateid", "");
		sessionStorage.setItem("mrncoporatename", "");
	} else {
		if (typeof res.data != "undefined") {
			sessionStorage.setItem("mrncoporateid", res.data.ID);
			sessionStorage.setItem("mrncoporatename", res.data.name);
		}
	}
	$(".loader").hide();
}

//function callallorder(){
function get_allorder() {
	dashboard_widgets_render();
	dashboard_search_render("all_orders");
	$("#fromdate").val(todayDate());
	$("#todate").val(todayDate());
	$('#l2search').attr('onclick', 'callallorder1()');
	var formdate = $("#fromdate").val();
	var todate = $("#todate").val();
	var city = $("#city").val();
	var status = $("#status_serach").val();
	var _data = {city: city, formdate: formdate, todate: todate, status: status};
	_ajaxEventHandler("all_orders", _data, allordersview, SHOW_LOADER);
}

function getwidgetCount() {
	//renderWidgets();
	dashboard_widgets_render();
    $(".loader").hide();
}

function allOrders(ajaxMethod, SuccessFn, withSearch, skip, pagination){        
	//console.log(pagination);
	withSearch = withSearch || false;
	ajaxMethod = ajaxMethod || false;
	pagination = pagination || false;
	skip = skip || '1';
	sessionStorage.setItem("ajaxMethod", ajaxMethod);
	sessionStorage.setItem("SuccessFn", SuccessFn);
	sessionStorage.setItem("withSearch", withSearch);
	sessionStorage.setItem("pagination", pagination);
	sessionStorage.setItem("skip", skip);
	var searchFn = 'allOrders("' + ajaxMethod + '","' + SuccessFn + '",' + true + ',1,' + pagination + ')';
    sessionStorage.removeItem('reject_default_vendor_id');
	if (withSearch === false) {
		dashboard_search_render(ajaxMethod);
		$("#fromdate").val(todayDate());
		$("#todate").val(todayDate());
		if (ajaxMethod == 'all_orders') {
			getwidgetCount();
		}
	}
	$('#l2search').attr('onclick', searchFn);
	var formdate = $("#fromdate").val();
	var todate = $("#todate").val();
	var city = $("#city").val();
	var status = $("#status_serach").val();
	var searchvalue = $("#searchvalue").val();
	var searchtext = $("#searchtext").val();
	if (new Date(formdate) > new Date(todate)) {
		alert("Todate greater than  Form Date");
		return false;
	}
	var _data = {city: city, formdate: formdate, todate: todate, status: status};
	if ((ajaxMethod == 'rx_not_upload')) {
		$("#todate").attr("disabled", "disabled");
		$("#fromdate").attr("disabled", "disabled");
		$("#status_serach").attr("disabled", "disabled");
		var _data = {city: city};
	}

	if (ajaxMethod == 'reminder_request') {
		$("#status_serach").attr("disabled", "disabled");
		$("#city").attr("disabled", "disabled");
		_data = {};
	}
	_data.customsearch = false;
	if (withSearch === true) {
		if(searchtext=="orderidser" && $.trim(searchvalue)!=""){
			_data.orderidser = searchvalue;
		}else if(searchtext=="orderdidser" && $.trim(searchvalue)!=""){
			_data.orderdidser = searchvalue;
		}else if(searchtext=="mrn" && $.trim(searchvalue)!=""){
			_data.mrn = searchvalue;
		}
		
		if($("#vendor_serach").val()!="undefined" && $("#vendor_serach").val()!="0"){
			_data.vendorid = $.trim($("#vendor_serach").val());
		}
		
		/*if (ajaxMethod == 'rx_not_upload') {
			var _data = {city: city, orderidser: orderidser};
		}*/

		if (ajaxMethod == 'reminder_request') {
		var _data = {formdate: formdate, todate: todate};
		}
		_data.customsearch = true;
	}
	_data.pagination = true;
	_data.skip = skip;
	_data.limit = 10;
	_data.sortBy = "DESC";
	_data.dateFilter = "created_date";
	//console.log(SuccessFn);
	_customeDataTable(_data, ajaxMethod, SuccessFn, SHOW_LOADER)
}

function _customeDataTable(_data, ajaxMethod, SuccessFn, showLoader) {
	showLoader = showLoader || 1;
    if (showLoader == '1') {
		$(".loader").show();
	}
	_data.method = ajaxMethod;
	_data.type = "l2pharma";
	//var url = baseRestUrl+medicineSupplyUrl+'getMedOrdersByFilter';
	var url = RestServiceURL + medicineSupplyUrl + 'getMedOrdersByFilter';
	$("#Custom_body").customeDataTable({
		data: _data,
        orderby: 0,
        actionurl: url,
        actiontype: "POST",
        tableprepare: SuccessFn,
        pagination: _data.pagination,
        perpage: _data.limit,
        customsearch: _data.customsearch
	});
	$(".loader").hide();
}


function selectDrug(id) {
	$this = $('#' + id);
	var pop = sessionStorage.getItem('facility_id');       
	var datalist = $('.data-search-select').find('.data_druglist [value="' + selecteddiag + '"]');
	//console.log(datalist.length);
	//console.log(datalist.data('mrp'));
	var s_mrp = parseFloat(datalist.data('mrp')).toFixed(2);
	var brand = datalist.data('brand');
	var codedid = datalist.data('codedid');
	var discountAmount = datalist.data('discountamount');
	var netAmount = datalist.data('netamount');
	var pharmaname = datalist.data('pharma');
	var prescribed = datalist.data('prescribed');
	var category = '';
	var categoryId = datalist.data('category');
	var manufacturerId = datalist.data('manufacturerid');
	var manufacturer = datalist.data('manufacturer');
	var packsize = datalist.data('packsize');
	var id = datalist.data('id');
	var priceperunit = datalist.data('priceperunit');
	var sectionId = 'new-drug-order-' + manufacturerId;
	if ($('#Custom_body ' + checkSum).length <= 0) {
		var drugHtml = addDrugSearchItemsList(sectionId, checkSum.replace('.', ''));
		$(".coupon_block").before(drugHtml);
		var prescriptionObj = sectionId + '_file';
		var prescriptionObjLength = sectionId + '_file_length';
		sessionStorage.setItem(prescriptionObj, "");
		sessionStorage.setItem(prescriptionObjLength, "");
		var _dataforvendor = {"systemType": "l2pharma"};
		_ajaxEventHandler("vendor_list", _dataforvendor, cbk_setvendorinselecttag, '');
	} else {

		$(checkSum).find('table tbody').append($(checkSum).find('table tbody tr:last').clone().find('input').val('').end());
        $(checkSum + ' table tbody tr:last').attr('id', 'rowdrug-' + rowcount);
        $(checkSum + ' table tbody tr:last #l2vcancel').attr('data-value', rowcount);
	}
	//debugger;
	//alert(rowcount);
	//var currentRowId = $(checkSum + ' table tbody tr:last').attr('id').replace('rowdrug-','');
	//var currentRowId = $(checkSum + ' table tbody tr:last').index();
	//alert(currentRowId);
	//var currentRow = checkSum + ' table tbody tr:eq(' + rowcount + ')';
	var currentRow = checkSum + ' table #rowdrug-' + rowcount;
	alert(currentRow);
	//console.log(currentRowId);
	//console.log(currentRow);
	//$(checkSum + ' table tbody tr:last').attr('id', 'rowdrug-' + rowcount);
	//$(checkSum + ' table tbody tr:last').attr('id', 'rowdrug-' + rowcount);
	//$(checkSum + ' table tbody tr:last').attr('id','rowdrug-'+rowcount);
	//alert(checkSum);
	$(currentRow).find("input[name=drugsearch]").attr('data-codedid', codedid);
	$(currentRow).find("input[name=drugsearch]").attr('data-id', id);
	$(currentRow).find("input[name=drugsearch]").attr('data-category', categoryId);
	$(currentRow).find("input[name=drugsearch]").attr('data-priceperunit', priceperunit);
	$(currentRow).find("input[name=drugsearch]").attr('data-packsize', packsize);
	$(currentRow).find("input[name=drugsearch]").attr('data-manufacturerid', manufacturerId);
	$(currentRow).find("input[name=drugsearch]").attr('data-manufacturer', manufacturer);
	$(currentRow).find("input[name=drugsearch]").val(selecteddiag);
	$(currentRow).find("input[name=pharmaname]").val(pharmaname);
	$(currentRow).find("input[name=quantity]").val('1');
	$(currentRow).find("input[name=itemmrpval]").val(s_mrp);
	$(currentRow).find("input[name=discountAmount]").val(discountAmount);
	$(currentRow).find("input[name=netAmount]").val(netAmount);
	$(currentRow).find("input[name=grossamount]").val(s_mrp);
	console.log('11111');
	//debugger; 
	//newCheckpricefrommdm();
	//settimeslot();
	$this.val('');
	rowcount = rowcount +1;
}

function calculate(e, $this) {
	//console.log(checkSum);
	//console.log(e.type);
	if (e.type == 'keyup' || e.type == 'focusout' || e.type == 'change' || e.type == 'focus') {
		$rowId = $($this).parents('tr').attr('id');
		var splitOrder = $($this).attr('data-split');
		//console.log($rowId);
		$qty = $('.'+splitOrder).find('#' + $rowId).find('input[name="quantity"]').val();
		//console.log($qty);
		if ($qty > 0 && e.type == 'focusout') {
			return;
		}
		$currentDrug = $('.'+splitOrder).find('#' + $rowId).find('input[name="drugsearch"]').val();
		$pricePerUnit = $('.'+splitOrder).find('#' + $rowId).find('input[name="itemmrpval"]').val();
		//console.log($rowId);
		if (($qty <= 0 && $qty != '') || ($qty == '' && e.type == 'focusout')) {
			$('.'+splitOrder).find('#' + $rowId).find('input[name="quantity"]').val(1)
			$qty = 1;
		}
		if ($qty == '') {
			$qty = 0;
		}
		$mrp = parseFloat(parseFloat($pricePerUnit) * parseInt($qty)).toFixed(2);
		$('.'+splitOrder).find('#' + $rowId).find('input[name="grossamount"]').val($mrp);
		var orderGlobalDetails = splitOrderGlobalDetails();
		newCheckpricefrommdm();
		updateSplitOrderDetails(orderGlobalDetails);
	}
}

function cancellineitemdiag(val) {
	var rowIndex = '#rowdrug-' + $(val).attr("data-value");
	para_val_del = $(val).attr("data-split");
	console.log(para_val_del);
	$index = $("." + para_val_del).find("table tbody tr").length;
	var itemtoRemove = $('.' + para_val_del).find(rowIndex + " input[name=drugsearch]").val();
	console.log(itemtoRemove); //return false;
	//return false;
	console.log($index);
	if ($index > 1) {
		console.log(selectedDrugsList);
        $('.' + para_val_del).find(rowIndex).remove();
        selectedDrugsList.splice($.inArray(itemtoRemove, selectedDrugsList), 1);
	} else{
		if (sessionStorage.getItem('orderMode') != 'update'){
			$("." + para_val_del).remove();
			selectedDrugsList.splice($.inArray(itemtoRemove, selectedDrugsList), 1);
		}
	}
	console.log(sessionStorage.getItem('orderMode'));
	console.log(selectedDrugsList);

	var orderGlobalDetails = splitOrderGlobalDetails(para_val_del,rowIndex);
	console.log(orderGlobalDetails);
	newCheckpricefrommdm();
	updateSplitOrderDetails(orderGlobalDetails);
	var codeid = $(val).attr('data-codeid');
	delete doctorNameList[codeid];
	console.log(doctorNameList);
}   


var showcoupenmmsg = 2;
function new_cbk_checkpricefrommdm(response) {                
	var countitem = 0;
	var coupon = $("#l2vCoupanCode").val();
	var countinvalidcounpen = 0;
	var couponApplied = false;
	var couponApplieditem = false;
	if (typeof response == 'string') {
		var Obj = JSON.parse(response);
	} else {
		var Obj = response;
	}

	// Obj = response;
	var walletstatus = sessionStorage.getItem("walletstatus");
	if (Obj.status == 1) {
		var objData = Obj.data;
		//checkSum = '.split-'+$.trim(objData.medicineDeliveryCharges);
		console.log(checkSum);
		var medicineDeliveryChargesList = objData.medicineDeliveryChargesList;
		$.each(medicineDeliveryChargesList, function(key, value){
			var itemList = value.services;
			var datalist = $('.data-search-select').find('.data_druglist [value="' + selecteddiag + '"]');
			var currentItem = datalist.data('codedid');
			console.log(currentItem)
			if ($.inArray(currentItem, itemList) !== - 1){
			checkSum = '.split-' + $.trim(value.OMSNetAmount);
			}
		});
		selectDrug('drugsearch');
		//var checkprescriptioncount = 0;

		couponApplied = Obj.couponApplied;
		$(".l2vitemwalletamount").html(0);
		$(".l2vitemtotalamount").html(0);
		$(".l2vitemtotalamountgross").html(0);
		$(".l2vitemtotalamountdiscount").html(0);
		console.log(objData);
		$.each(objData.lineItemList, function (key, val){
			console.log(val);
			var checkprescriptioncount = 0;
			$itemCode = $.trim(val.code);
			alert(checkSum);
			$rowId = '#' + $(checkSum).find('input[data-codedid="' + $itemCode + '"]').parents('tr').attr('id');
			console.log($rowId);
			var dis = parseFloat(val.discountAmount) +
			((typeof val.apportionedDiscountAmount != 'undefined') ? parseFloat(val.apportionedDiscountAmount) : 0) +
			((typeof val.orderApportionedDiscountAmount != 'undefined') ? parseFloat(val.orderApportionedDiscountAmount) : 0);
			//alert(dis);
			$(checkSum).find($rowId + ' input[name="discountAmount"]').val(dis);
			$(checkSum).find($rowId + ' input[name="grossamount"]').val(val.grossAmount);
			$(checkSum).find($rowId + ' input[name="itemmrpval"]').val((val.unitPrice).toFixed(2));
			$(checkSum).find($rowId + ' input[name="grossamount"]').attr("data-mrp", val.unitPrice);
			//$(checkSum).find($rowId + ' input[name="netAmount"]').val(val.netAmount);
			$(checkSum).find($rowId + ' input[name="netAmount"]').val(val.OMSNetAmount);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-cartCouponApplied', val.cartCouponApplied);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-cartDiscountApplied', val.cartDiscountApplied);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-cartDiscountApportionedAmount', val.cartDiscountApportionedAmount);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-couponValue', val.couponValue);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-discountApplied', val.discountApplied);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-invoiceTo', val.invoiceTo);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-orderDiscountApplied', val.orderDiscountApplied);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-penalty_amount', val.penalty_amount);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-orderApportionedDiscountAmount', val.orderApportionedDiscountAmount);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-cartDiscountApportionedAmount', val.cartDiscountApportionedAmount);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-apportionedCouponAmount', val.apportionedCouponAmount);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-apportionedWalletAmount', val.apportionedWalletAmount);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-maxQuantity', val.maxQuantity);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-minQuantity', val.minQuantity);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-voucherApportionedAmount', val.voucherApportionedAmount);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-grossAmount', val.grossAmount);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-MRP', val.MRP);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-OMSNetAmount', val.OMSNetAmount);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-netAmount', val.netAmount);
			$(checkSum).find($rowId + ' input[name="netAmount"]').attr('data-discountAmount', val.discountAmount);
			if (val.couponApplied == true) {
				couponApplieditem = val.couponApplied;
			}
			if (walletstatus != 1 || walletstatus != "1") {
				var wallet = (typeof val.apportionedWalletAmount == "undefined" || val.apportionedwalletamount == '') ? 0 : val.apportionedWalletAmount;
				$(checkSum).find($rowId + ' input[name="netamount"]').attr("data-walletamt", wallet);
				//usedwalletAmount = usedwalletAmount + wallet;
				//$(checkSum).find($rowId + ' input[name="netamount"]').attr("data-walletamt",
			}
			countitem = countitem + 1;
			var prescribedval = val.prescribed;
			if (prescribedval === true) {
				$(checkSum).find($rowId + ' label[name="l2vsetrxotg"]').show();
				$(checkSum).find($rowId + ' label[name="l2vsetrxotg"]').attr("data-rxset", "true");
				checkprescriptioncount = 1;
			} else if (prescribedval === false) {
				$(checkSum).find($rowId + ' label[name="l2vsetrxotg"]').attr("data-rxset", "false");
				$(checkSum).find($rowId + ' label[name="l2vsetrxotg"]').css('display', 'none');
			} else {
				$(checkSum).find($rowId + ' label[name="l2vsetrxotg"]').attr("data-rxset", "");
				$(checkSum).find($rowId + ' label[name="l2vsetrxotg"]').css('display', 'none');
			}
			//alert($(checkSum+" .l2vitemwalletamount").html());
			//wallet 
			$(checkSum + " .l2vitemwalletamount").html((parseFloat($(checkSum + " #l2vitemwalletamount").html()) + parseFloat(wallet)).toFixed(2));
			//payable
			$(checkSum + " .l2vitemtotalamount").html(((parseFloat($(checkSum + " #l2vitemtotalamount").html()) + parseFloat(val.payabaleAmount)) - parseFloat(wallet)).toFixed(2));
			//gross
			$(checkSum + " .l2vitemtotalamountgross").html((parseFloat($(checkSum + " .l2vitemtotalamountgross").html()) + parseFloat(val.grossAmount)).toFixed(2));
			//discount
			$(checkSum + " .l2vitemtotalamountdiscount").html((parseFloat($(checkSum + " .l2vitemtotalamountdiscount").html()) + parseFloat(dis)).toFixed(2));

			if (objData.addMedicineDeliveryCharges == true && (typeof objData.medicineDeliveryChargesList != "undefined")){
				$i = 0;
				$.each(objData.medicineDeliveryChargesList, function(keyval, delval){
					if (jQuery.inArray($itemCode, delval.services) !== - 1){
						$(checkSum + " .l2vdeliverycharge").html($.trim(objData.medicineDeliveryChargesList[$i].OMSNetAmount));
						$(checkSum + " .medicine_delivery").attr("data-codedid", $.trim(objData.medicineDeliveryChargesList[$i].code));
						$(checkSum + " .medicine_delivery").attr("data-item_mrp", $.trim(objData.medicineDeliveryChargesList[$i].unitPrice));
						$(checkSum + " .medicine_delivery").attr("data-item_gross", $.trim(objData.medicineDeliveryChargesList[$i].grossAmount));
						$(checkSum + " .medicine_delivery").attr("data-item_net", $.trim(objData.medicineDeliveryChargesList[$i].OMSNetAmount));
						$(checkSum + " .medicine_delivery").attr("data-item_discount", $.trim(objData.medicineDeliveryChargesList[$i].discountAmount));
						$(checkSum + " .medicine_delivery").attr("data-ignoreToPartner", $.trim(objData.medicineDeliveryChargesList[$i].ignoreToPartner));
						$(checkSum + " .medicine_delivery").val("1");
					}
					$i = $i + 1;
				});
			} else{
				$(checkSum + " .l2vdeliverycharge").html("0");
				$(checkSum + " .medicine_delivery").val("0");
				$(checkSum + " .medicine_delivery").attr("data-id", "");
				$(checkSum + " .medicine_delivery").attr("data-codedid", "");
				$(checkSum + " .medicine_delivery").attr("data-item_mrp", 0);
				$(checkSum + " .medicine_delivery").attr("data-item_gross", 0);
				$(checkSum + " .medicine_delivery").attr("data-item_net", 0);
				$(checkSum + " .medicine_delivery").attr("data-item_discount", 0);
				$(checkSum + " .medicine_delivery").attr("data-ignoreToPartner", "");
			}
		});
		//("section[name='drug_orders']").each(function(finalval){
		//var final_sectionId="."+$(this).attr("data-sectionid");
		$netAmount = (parseFloat($(checkSum).find("#l2vitemtotalamount").html()) + parseFloat($(checkSum).find(".medicine_delivery").attr("data-item_net"))).toFixed(2);
		$(checkSum).find('.l2vitemtotalamount').html($netAmount);
		console.log($netAmount);
		//gross
		$grossAmount = (parseFloat($(checkSum).find(".l2vitemtotalamountgross").html()) + parseFloat($(checkSum).find(".medicine_delivery").attr("data-item_net"))).toFixed(2);
		$(checkSum).find('.l2vitemtotalamountgross').html($grossAmount);
		console.log($grossAmount);
		
		if ($.trim(coupon) != "" && (objData.couponApplied == "true")) {
			if (showcoupenmmsg == 2) {
				alert("Coupon " + coupon + " is applied successfully.");
				_data = {coupen_name: ($.trim($("#l2vCoupanCode").val()))}
				_ajaxEventHandler("coupendetails", _data, cbk_coupendetails, SHOW_LOADER);
				showcoupenmmsg = 1;
			}
		} else if ($.trim(coupon) != "") {
			if (showcoupenmmsg == 2) {
				alert("Invalid coupon " + coupon);
				showcoupenmmsg = 0;
				$("#l2vCoupanCode").val("");
				$("#l2vreferby").val("");
			}
		}

		if (objData.addMedicineDeliveryCharges == true && (typeof objData.medicineDeliveryChargesList != "undefined")) {
			$(checkSum).find("#l2vdeliverycharge").html($.trim(objData.medicineDeliveryCharges));
			$(checkSum).find("#medicine_delivery").attr("data-codedid", $.trim(objData.medicineDeliveryChargesList[0].code));
			$(checkSum).find("#medicine_delivery").attr("data-item_mrp", $.trim(objData.medicineDeliveryChargesList[0].unitPrice));
			$(checkSum).find("#medicine_delivery").attr("data-item_gross", $.trim(objData.medicineDeliveryChargesList[0].grossAmount));
			$(checkSum).find("#medicine_delivery").attr("data-item_net", $.trim(objData.medicineDeliveryChargesList[0].netAmount));
			$(checkSum).find("#medicine_delivery").attr("data-item_discount", $.trim(objData.medicineDeliveryChargesList[0].discountAmount));
			$(checkSum).find("#medicine_delivery").attr("data-ignoreToPartner", $.trim(objData.medicineDeliveryChargesList[0].ignoreToPartner));
			$(checkSum).find("#medicine_delivery").val("1");
		} else {
			$(checkSum).find("#l2vdeliverycharge").html("0");
			$(checkSum).find("#medicine_delivery").val("0");
			$(checkSum).find("#medicine_delivery").attr("data-id", "");
			$(checkSum).find("#medicine_delivery").attr("data-codedid", "");
			$(checkSum).find("#medicine_delivery").attr("data-item_mrp", 0);
			$(checkSum).find("#medicine_delivery").attr("data-item_gross", 0);
			$(checkSum).find("#medicine_delivery").attr("data-item_net", 0);
			$(checkSum).find("#medicine_delivery").attr("data-item_discount", 0);
			$(checkSum).find("#medicine_delivery").attr("data-ignoreToPartner", "");
		}

		$(checkSum).find('#l2vitemtotalamount').attr('data-voucherAmount', objData.voucherAmount);
		var walletamountavailable = parseFloat(sessionStorage.getItem("walletamount"));
		$("#l2vwalletamt").html(walletamountavailable - parseFloat(objData.walletAmount));
		//sessionStorage.setItem('walletamount', remainwallet);
	}
	$(".loader").hide();
}


function l2prescptionuploadl2(sectionId) {
	$("." + sectionId + "_uploadpresc").modal("show");
}

function l2prescptionuploadfroml2(sectionId,prescriptionId) {
	var formClass = sectionId + "_form";
	var formData = new FormData($('#' + formClass)[0]);
	var prescriptionobj = prescriptionId + '_file';
	prescriptionobj = prescriptionobj.replace(/\-/g, '_');
	var prescriptionfiles = [];
	if ($.trim(sessionStorage.getItem(prescriptionobj)) != null && sessionStorage.getItem(prescriptionobj) != "undefined" && $.trim(sessionStorage.getItem(prescriptionobj)) != ""){
		//prescriptionfiles.push(JSON.parse(sessionStorage.getItem(prescriptionobj)));
		$.merge(prescriptionfiles, JSON.parse(sessionStorage.getItem(prescriptionobj)));
	}
	$.ajax({
		url: RestServiceURL + 'medicine_supply.php/v1/prescription_upload_l2screen',
		data: formData,
		cache: false,
		contentType: false,
		processData: false,
		type: 'POST',
		success: function (data) {
			var result = data;
			if (typeof data == 'string') {
				result = JSON.parse(data);
			}
			if (result.status == 1){
				$.each(result.data, function (key, val) {
					if (val.status == 1){
						prescriptionfiles.push(val.data);
					}
				});
				if (prescriptionfiles.length > 0){
					sessionStorage.setItem(prescriptionobj, JSON.stringify(prescriptionfiles));
					//console.log(prescriptionfiles);
					$('.' + sectionId).find("#l2vopenprescriptionmadal").show();
					$('.' + sectionId).find("#vendorname").removeAttr('disabled');
					$('.' + sectionId).find("#checkboxprescriptionsms").prop("checked", false);
				}
			} else if (result.status == 0) {
				alert(result.message[0].message);
			} else {
				alert("some thing Wrong, Please try again !")
			}
		}
	});
	document.getElementById(formClass).reset();
}

function l2prescptionupload() {
	var formData = new FormData($("#formsum")[0]);
	formData.append('order_id', $('#orderid').val());
	var vendorname = sessionStorage.getItem('loginname');
	formData.append('mrn', sessionStorage.getItem('patientmrn'));
	$.ajax({
		url: RestServiceURL + 'medicine_supply.php/v1/prescription_upload_link',
		data: formData,
		cache: false,
		contentType: false,
		processData: false,
		type: 'POST',
		success: function (data) {
			//console.log(data);
			var result = '';
			if (typeof data == 'string') {
				result = JSON.parse(data);
			} else {
				result = data;
			}
			if (result.status == 1) {
				alert('Prescription uploaded.');
				$('.hideAllDetails').hide();
				$('.removeActive').removeClass('active');
				$('.veiwOrderDetails').addClass("active");
				$('#veiwOrderDetails').addClass('active in');
				$("#viewOrder").modal("hide");
			}
			else {
				alert("some Thing Wrong  Please try again !")
			}
		}
	});
}

function showaddress() {
	$("#l2edit").toggle();
}

function updateaddresspopn() {
	if ($("#address1").val() == "") {
	alert('Please enter address');
			return;
	}
	if ($("#postal_code").val() == "" || $("#postal_code").val() == 0 || $("#postal_code").val() == "0") {
	alert('Please enter postal code');
			return;
	}
	if ($("#administrative_area_level_1").val() == "") {
	alert('Please enter state.');
			return;
	}
	if (($("#pcontactno").val() == "") || ($("#pcontactno").val().length < 10)) {
	alert('Please enter contact no.');
			return;
	}
	var showdelvaddress = $("#address1").val() + ", " + $("#route").val() + ", " + $("#locality").val() + ", " + $("#administrative_area_level_1").val() + ", " + $("#postal_code").val();
	$("#showdelvaddress").html(showdelvaddress);
	$("#showdelvpop").html($("#popname").val());
	sessionStorage.setItem("popname", $("#popname").val());
	sessionStorage.setItem("facility_id", $("#popid").val());
	sessionStorage.setItem("state", $("#administrative_area_level_1").val());
	var addressActionType = $('#actionType').val();
	var addressNickName = $('#address_nick_name').val();
	var district = $('#district').val();
	var latitude = $('#latitude').val();
	var longitude = $('#longitude').val();
	var addressId = $('#selected_address_id').val();
	var address1 = $('#address1').val();
	var stateVal = $('#administrative_area_level_1').val();
	var locality = $('#locality').val();
	var route = $('#route').val();
	var zipcodeVal = $('#postal_code').val();
	var landmark = $('#autocomplete').val();
	var contactno = $('#pcontactno').val();
	var alternetcontactno = $('#alternetcontactno').val();
	var _dataAddress = {
	action: (addressId) ? 'update' : 'add', // add or update
			addressId: addressId, //Mandatory if action=="update"
			mrn: sessionStorage.getItem('patientmrn'),
			createdBy: "",
			createdByType: "",
			stateVal: stateVal,
			addressVal: address1,
			cityVal: locality,
			addressType: 1,
			addressNickName: addressNickName,
			zipcodeVal: zipcodeVal,
			isActive: 1,
			countryVal: "India",
			lngVal: longitude,
			district: district,
			customerId: "CH333218",
			latVal: latitude,
			landmark: landmark,
			defaultAddress: "1",
			areaVal: route
	};		
	_ajaxEventHandler("modifyAddress", _dataAddress, cbk_setNewAddress, '');		
}

function cbk_setNewAddress(response) {
	var responseData = response;
			if (typeof response == 'string') {
	responseData = JSON.parse(response);
	}
	//console.log(responseData);
	if (responseData.status == 0 || responseData.status == '0') {
	alert(responseData.message);
			return false;
	}
	var currentAddress = responseData.data.addressDetails;
	var district = $('#district').val();
	var latitude = $('#latitude').val();
	var longitude = $('#longitude').val();
	var addressId = currentAddress.AddressId;
	var address1 = $('#address1').val();
	var stateVal = $('#administrative_area_level_1').val();
	var country = $('#country').val();
	var locality = $('#locality').val();
	var latitude = $('#latitude').val();
	var longitude = $('#longitude').val();
	var route = $('#route').val();
	var zipcodeVal = $('#postal_code').val();
	var landmark = $('#autocomplete').val();
	var contactno = $('#pcontactno').val();
	var address_nick_name = $('#address_nick_name').val();
	var alternetcontactno = $('#alternetcontactno').val();
	var address = address_nick_name+', '+address1 + ", " + route + ", " + locality + ", " + stateVal + ", " + country + ", " + zipcodeVal;
	sessionStorage.setItem("landmark", landmark);
	sessionStorage.setItem("city", locality);
	sessionStorage.setItem("district", district);
	sessionStorage.setItem("state", stateVal);
	sessionStorage.setItem("country", country);
	sessionStorage.setItem("zipcode", zipcodeVal);
	sessionStorage.setItem("address_id", addressId);
	sessionStorage.setItem("address_nickname", address_nick_name);
	sessionStorage.setItem("address", address);
	sessionStorage.setItem("latitude", latitude);
	sessionStorage.setItem("longitude", longitude);
	sessionStorage.setItem("route", route);
	$('#showdelvaddress').html(address);
	$('#addressListModal').modal('hide');
	check_servisablepincode();
}

 function cbk_setvendorinselecttag(res) {
	var associate_id = sessionStorage.getItem('associate_id');
	var Obj = '';
	if (typeof res == 'string') {
		Obj = JSON.parse(res);
	} else {
		Obj = res;
	}
	if (associate_id == '' || associate_id == 'undefined') {
		var htmlBanner = '<option value="0" selected>Select Vendor</option>';
	} else {
		var htmlBanner = '<option value="0">Select Vendor</option>';
	}
	if (Obj.status == '1' || Obj.staus == 1) {
		$.each(Obj.data, function (key, val) {
			var selected = '';
			if (associate_id == val.userinfo.USER_ID) {
				selected = 'selected';
			}
			htmlBanner += '<option ' + selected + ' data-address="' + val.userinfo.ADDRESS + '" value="' + val.userinfo.USER_ID + '">' + val.userinfo.USER_NAME +
			'</option>';
		});
	}
	sessionStorage.setItem('associate_id', '');
	$(".select-vendorname").html(htmlBanner);
}

function cbk_setvendorList(res) {
	var Obj = '';
	if (typeof res == 'string') {
		Obj = JSON.parse(res);
	} else {
		Obj = res;
	}
	var htmlBanner = '<option value="0" selected>Select Vendor</option>';
	if (Obj.status == '1' || Obj.staus == 1) {
		$.each(Obj.data, function (key, val) {
			var selected = "";
			if (sessionStorage.getItem("reject_default_vendor_id") != null && sessionStorage.getItem("reject_default_vendor_id") != "" && val.userinfo.USER_ID == sessionStorage.getItem("reject_default_vendor_id")){
				selected = "selected";
			}
			htmlBanner += '<option data-address="' + val.userinfo.ADDRESS + '" value="' + val.userinfo.USER_ID + '" ' + selected + '>' + val.userinfo.USER_NAME +
			'</option>';
		});
	}
	$("#vendor").html(htmlBanner);
}

function cbk_setvendorList_search(res) {
	var Obj = '';
	if (typeof res == 'string') {
		Obj = JSON.parse(res);
	} else {
		Obj = res;
	}
	var htmlBanner = '<option value="0" selected>Select Vendor</option>';
	if (Obj.status == '1' || Obj.staus == 1) {
		$.each(Obj.data, function (key, val) {
			var selected = "";
			if (sessionStorage.getItem("reject_default_vendor_id") != null && sessionStorage.getItem("reject_default_vendor_id") != "" && val.userinfo.USER_ID == sessionStorage.getItem("reject_default_vendor_id")){
				selected = "selected";
			}
			htmlBanner += '<option data-address="' + val.userinfo.ADDRESS + '" value="' + val.userinfo.USER_ID + '" ' + selected + '>' + val.userinfo.USER_NAME +
			'</option>';
		});
	}
	$("#vendor_serach").html(htmlBanner);
}


function updateDeliveryAddress() {
	var newAdddress = $('#deliveryAddress').val();
	//console.log(newAdddress);
	$('#showdelvaddress').html(newAdddress);
	sessionStorage.setItem("address", newAdddress);
	$("#updateAddressModel").toggle();
}

function createNewDrugOrder() {
	//check_servisablepincode();
	
	
	if(sessionStorage.getItem("loginid") == '' || sessionStorage.getItem("loginid") == null || sessionStorage.getItem("loginname") == '' || sessionStorage.getItem("loginname") == null){
		alert('User details doesn`t exist');
		return;
	}
	
	if(global_serviceable==0){
		 alert('Sorry! This location is not serviceable. Please choose a different address.');
		return;
	}
	var referedby = "";
	var sourceofreferral = "";
	var referredmrn = "";
	// 1 - yes 2 - no 
	var couponitem = "";
	if($('.rowdrug').length <= 0){
		alert('Please select product');
		return;
	}
	if ($("#l2vreferby").val() == "") {
		alert('Please enter the referring Officer ID. If none, then please enter 9999.');
		return;
	} else {
		referedby = $("#l2vreferby").val();
	}

	if ($("#l2vsourcereferral option:selected").val() == "") {
	alert('Please select a source.');
			return;
	} else {
	sourceofreferral = $("#l2vsourcereferral option:selected").val();
	}

	referredmrn = $("#l2vsreferbymrn").val();
	if (sessionStorage.getItem("zipcode") == "" || sessionStorage.getItem("zipcode")== 0 || sessionStorage.getItem("zipcode")=="0") {
		alert('Please enter a postal code');
		return;
	}
	
	
	if((sessionStorage.getItem('orderMode') != 'update') && ($('#applywallet').prop("checked") == false)){
		var l2vwalletamt = $('#l2vwalletamt').text();
		if(l2vwalletamt != ''){
			l2vwalletamt = parseFloat(l2vwalletamt);
			if(l2vwalletamt > 0){
					var applyWallet = confirm('Do you wish to apply the wallet amount?');
					if(applyWallet == true){
						$('#applywallet').prop('checked', true);
						applywallet();
						return;
					}
				}
			}
	}
	

	var loginid = sessionStorage.getItem("loginid");
	var loginname = sessionStorage.getItem("loginname");
	var name = sessionStorage.getItem('displayname');
	var salutation = sessionStorage.getItem("salutation");
	var patientfname = sessionStorage.getItem('patientfname');
	var patientmname = sessionStorage.getItem('patientmname');
	var patientlname = sessionStorage.getItem('patientlname');
	var age = sessionStorage.getItem('displayage');
	var gender = sessionStorage.getItem('patientgender');
	var contactno = sessionStorage.getItem('contactno');
	var alternetcontactno = sessionStorage.getItem('alternetcontactno');
	if (contactno == "") {
		contactno = sessionStorage.getItem('contactno');
	}
	if (alternetcontactno == "") {
		alternetcontactno = (sessionStorage.getItem('alternetcontactno') == "Array") ? "" : sessionStorage.getItem('alternetcontactno');
	}
	var email = sessionStorage.getItem('email');
	var tagsfororder = (sessionStorage.getItem('tagsfororder') == null) ? "" : sessionStorage.getItem('tagsfororder');
	//var referedby=$.trim($("#l2vreferby").val());

	var doorno = "";
	var popname = sessionStorage.getItem('popname');
	var facility_id = sessionStorage.getItem('facility_id');
	var home_pop = sessionStorage.getItem('home_popname');
	var home_fc_id = sessionStorage.getItem('home_facility_id');
	var landmark = sessionStorage.getItem('landmark');
	var address1 = sessionStorage.getItem('address');
	var area = sessionStorage.getItem('area');
	var countrydistrict = sessionStorage.getItem('district');
	var state = sessionStorage.getItem('state');
	var zipcode = sessionStorage.getItem('zipcode');
	var longitude = sessionStorage.getItem('longitude');
	var latitude = sessionStorage.getItem('latitude');
	var addressId = sessionStorage.getItem('address_id');
	var payment_method = $("#payment_method option:selected").val();
	//var coupon = $("#coupon").val();
	var coupon = $("#l2vCoupanCode").val();
	if (showcoupenmmsg == 0) {
		coupon = "";
	}

	//for call
	var mrn = sessionStorage.getItem('patientmrn');
	var lead_id = (typeof sessionStorage.getItem('lead_id') != "undefined") ? sessionStorage.getItem('lead_id') : "";
	var callNumber = sessionStorage.getItem('callNumber');
	var orderid = sessionStorage.getItem('orderid');
	var encounterid = sessionStorage.getItem('encounterid');
	var patientid = sessionStorage.getItem('patientid');
	var orderwid = sessionStorage.getItem('orderwid');
	var orderwdid = sessionStorage.getItem('orderwdid');
	var doctorid = sessionStorage.getItem('doctorid');
	var doctorname = sessionStorage.getItem('doctorname');
	var mrncoporateid = sessionStorage.getItem('mrncoporateid');
	var mrncoporatename = sessionStorage.getItem('mrncoporatename');
	var ordersmscreate = (typeof (sessionStorage.getItem("ordersmscreate")) == "undefined") ? "0" : sessionStorage.getItem("ordersmscreate");
	var ezzetab_sms = sessionStorage.getItem('ezzetab_sms');
	var placedfromdoctorplace = sessionStorage.getItem("placedfromdoctorplace");
	var orderstatuscurorder = sessionStorage.getItem("orderstatuscurorder");
	var l2vprepaidamountcheck = $("#l2vprepaidamount").html();
	var medicine_delivery = 0;
	var deliveryarray = [];
	if ($("#medicine_delivery").val() == "1") {
		medicine_delivery = $("#medicine_delivery").attr("data-item_mrp");
		deliveryarray.push({
			item_code: $("#medicine_delivery").attr("data-codedid"),
			quantity: "1",
			gross_amount: $("#medicine_delivery").attr("data-item_gross"),
			item_mrp: $("#medicine_delivery").attr("data-item_mrp"),
			discount_amount: $("#medicine_delivery").attr("data-item_discount"),
			net_amount: $("#medicine_delivery").attr("data-item_net"),
			ignoreToPartner: $("#medicine_delivery").attr("data-ignoreToPartner")
		});
	}

	var totalOrders = [];
	var totalgross = '0.00';
	var totalnet = '0.00';
	var totaldiscount = '0.00';
	var totalUsedWalletAmount = '0.00';
	var totalVoucherAmount = '0.00';
	var check_anyerror = 0;
	$('.new-order-by-category').each(function () {
		$this = $(this);
		var sectionId = $this.attr('data-sectionid');
		//check if any RX item is available(set prescription later and send message) or not (set vendor) 
		var rxisavailable = 0;
		var otgisavailable = 0;
		var sendsmsforpprescription = 0;
		$this.find('label[name=l2vsetrxotg]').each(function () {
			if ($.trim($(this).attr("data-rxset")) == "true") {
				rxisavailable = rxisavailable + 1;
			}
		});

		$('.select-vendorname').each(function(key, value){
		if(($(this).val() == "0") && $(this).is(':disabled') !== true){
				alert("Please select vendor.");
				check_anyerror = 1;
				return;
		}
		});

		if (sessionStorage.getItem("orderstatuscurorder") == "24") {
			if ($("#vendorname").val() === "0") {
				alert("Please select vendor.");
				check_anyerror = 1;
				return;
			}
			
		   // return false;
			if (sessionStorage.getItem(sectionId) == "") {
				var r = confirm("Please upload the Prescription.");
				if (r == true) {
					l2prescptionuploadl2();
					check_anyerror = 1;
					return;
				}
			}
		} else {
			if (sessionStorage.getItem("encounterid") != "" && sessionStorage.getItem("orderstatusencounterid") != "6") {
				sendsmsforpprescription = 0;
			} else {
				if ((sessionStorage.getItem("encounterid") == "") && (sessionStorage.getItem(sectionId) != "")) {
					sendsmsforpprescription = 0;
				} else {
					sendsmsforpprescription = 1;
				}
			}
		}

		var vendorid = $this.find("#vendorname option:selected").val();
		var vendorname = $this.find("#vendorname option:selected").text();
		var vendoraddress = $this.find("#vendorname option:selected").attr("data-address");
		if (vendorid == "0") {
			var vendorid = "";
			var vendorname = "";
		}

		var currentNetAmount = $.trim($this.find("#l2vitemtotalamount").html());
		if (currentNetAmount != '') {
			totalnet = parseFloat(totalnet) + parseFloat(currentNetAmount);
			totalnet = parseFloat(totalnet).toFixed(2);
		}

		var deliveryAmount = $.trim($this.find("#l2vdeliverycharge").html());
		if (deliveryAmount != '') {
			deliveryAmount = parseFloat(deliveryAmount).toFixed(2);
		}

		var currentGrossAmount = $.trim($this.find("#l2vitemtotalamountgross").html());
		if (currentGrossAmount != '') {
			totalgross = parseFloat(totalgross) + parseFloat(currentGrossAmount);
			totalgross = parseFloat(totalgross).toFixed(2);
		}

		var currentDiscountAmount = $.trim($this.find("#l2vitemtotalamountdiscount").html());
		if (currentDiscountAmount != '') {
			totaldiscount = parseFloat(totaldiscount) + parseFloat(currentDiscountAmount);
			totaldiscount = parseFloat(totaldiscount).toFixed(2);
		}
		var currentUsedWalletAmount = $.trim($this.find("#l2vitemwalletamount").html());
		if (currentUsedWalletAmount != '') {
			totalUsedWalletAmount = parseFloat(totalUsedWalletAmount) + parseFloat(currentUsedWalletAmount);
			totalUsedWalletAmount = parseFloat(totalUsedWalletAmount).toFixed(2);
		}

		var currentVoucherAmount = $.trim($this.find('#l2vitemtotalamount').attr('data-voucherAmount'));
		if (currentVoucherAmount != '') {
			totalVoucherAmount = parseFloat(totalVoucherAmount) + parseFloat(currentVoucherAmount);
			totalVoucherAmount = parseFloat(totalVoucherAmount).toFixed(2);
		}
		
		var scheduletimeforordr = $.trim($this.find(".timeslot").html());
		if ((typeof scheduletimeforordr == "undefined") || scheduletimeforordr == ""){
			alert("Please choose a prefered delivery time slot.");
			check_anyerror = 1;
			return false;
		}

		var prescriptionfile = [];
		$this.find('.rowdrug').each(function () {
			var drugsearchInput = $(this).find('input[name=drugsearch]');
			var drugName = drugsearchInput.val();
			if ($.trim(drugName) != "") {
				var codedidval = drugsearchInput.attr("data-codedid");
				var prescriptionObj = 'split_'+codedidval + '_file';                
				if (sessionStorage.getItem(prescriptionObj) != null){
				$.merge(prescriptionfile,JSON.parse(sessionStorage.getItem(prescriptionObj)));
				}
			}
		});
		//console.log(prescriptionfile);
		//alert(prescriptionfile);
		var newOrderItems = newOrderByCategory($this);
		newOrderItems.push({
			codedid: sessionStorage.getItem('DCCode'),
			itemname: 'DDO',
			brandname: "DDO",
			pharmaname: "",
			doctorname: "",
			item_mrp: parseFloat(deliveryAmount),
			discountamount: 0,
			item_wallet: 0,
			coupon: "",
			code: "",
			priceperunit: "",
			category: "1",
			subcategory_id: "",
			item_code: sessionStorage.getItem('DCCode'),
			quantity: "1",
			type: "2",
			MRP: parseFloat(deliveryAmount),
			gross_amount: parseFloat(deliveryAmount),
			net_amount: parseFloat(deliveryAmount),
			wallet_amount: 0,
			voucher_amount: 0,
			markup_amount: 0,
			cli: 0,
			coupon_amount: 0,
			is_cashless: "",
			invoiceto: "",
			reportto: "1",
			payment_code: "0",
			corporateinvoiceemail: "",
			corporatereportemail: "",
			roleBasedService: 1,
			doctor: "",
			discount_amount: 0,
			old_item_mrp: parseFloat(deliveryAmount),
			old_gross_amount: parseFloat(deliveryAmount),
			old_discount_amount: 0,
			old_net_amount: parseFloat(deliveryAmount),
			manufacturer_id: "",
			manufacturer: "",
			packsize: "",
			prescribed: "1",
			cartDiscountApplied: false,
			discountApplied: false,
			cartCouponApplied: false,
			orderDiscountApplied: false,
			lineItemDiscountAmount: 0,
			cartDiscountApportionedAmount: 0,
			orderApportionedDiscountAmount: 0,
			isReturnable: true,
			isWaiver: false,
			role:9,
			skill:"1"
		});
		totalOrders.push({
			mrn: mrn,
			address_id: addressId,
			order_id: sessionStorage.getItem('orderid'),
			associate_id: vendorid,
			associate_branch_id: "",
			service_type: "2",
			scheduled_date: scheduletimeforordr,
			payment_code: "0",
			creation_type: 1,
			application_no: "",
			surge_amount: 1,
			mode_of_service: 1,
			report_required:((typeof $this.find('#checkboxprescriptionsms').val() != "undefined")?$this.find('#checkboxprescriptionsms').val():0),
			report_delivery_date: "",
			slot_transaction_id: [],
			deliveryCharges: deliveryAmount,
			prescription_images:prescriptionfile,
			/*prescription_file: [
			 [
			 prescriptionfile
			 ]
			 ],*/
			order_item: newOrderItems
		});
	});
	if (check_anyerror == 1){
		return false;
	}
	var deduct_the_wallet = 0;
	if (parseFloat(totalUsedWalletAmount) > 1){
		deduct_the_wallet = 1;
	}
	var payment_info_coupon_amount = 0;
	var _data = {
		orderMode: sessionStorage.getItem('orderMode'),
		mrn: mrn,
		channel: 2,
		source_of_referral: $('#l2vsourcereferral').val(),
		referral_id: referedby,
		created_by_id: loginid,
		created_by_name: loginname,
		referral_mrn: referredmrn,
		orders: totalOrders,
		deduct_the_wallet:deduct_the_wallet,
		payment_info: {
		payment_amount: parseFloat(totalnet),
			payment_service: "COD",
			source_type: "",
			payment_mode: 0,
			payment_reference_id: "",
			wallet_amount: parseFloat(totalUsedWalletAmount),
			coupon: coupon,
			//coupon_amount: parseInt(totaldiscount),
			coupon_amount: parseFloat(payment_info_coupon_amount),
			gross_amount: parseFloat(totalgross),
			voucher_assoc_code: "",
			voucher_code: "",
			voucher_amount: parseFloat(totalVoucherAmount)
		}
	};
	//console.log(_data);
	//return false;
	_ajaxEventHandler("createTransaction", _data, cbk_createdrugorder, SHOW_LOADER, "POST", orderUrl);
	doctorNameList = {};
}

function cbk_createdrugorder(response) {
	$(".loader").hide();
	var Obj = response;
	if (typeof response == 'string') {
		Obj = JSON.parse(response);
	}
	if (Obj.status == "1") {
		alert(Obj.message);
		$("section[class='new-order-by-category']").each(function(){
			var prescriptionObj_remove = $(this).attr("data-sectionid") + '_file';
			prescriptionObj_remove = prescriptionObj_remove.replace(/\-/g, '_');
			if (sessionStorage.getItem(prescriptionObj_remove) != null){
				sessionStorage.removeItem(prescriptionObj_remove);
			}
		});
		global_serviceable=0;
		sessionStorage.setItem('orderid', "");
		sessionStorage.setItem('orderwid', "");
		sessionStorage.setItem('orderwdid', "");
		sessionStorage.setItem("encounterid", "");
		sessionStorage.setItem("prescriptionobj", "");
		sessionStorage.setItem("placedfromdoctorplace", "0");
		$("#l2vreferby").val("");
		var _data = {"orderid": ""}
		_ajaxEventHandler("open_patient_orders", _data, cbk_open_patient_orders, '');
		newordertab();
	} else {
		alert(Obj.message);
	}
}

function newOrderByCategory($this) {
	var lineitems = [];
	$this.find('.rowdrug').each(function () {

	var drugsearchInput = $(this).find('input[name=drugsearch]');
	//var drugAmountDetails = $(this).find('input[name=netAmount]');
	var drugName = drugsearchInput.val();
	console.log(drugName);
	if ($.trim(drugName) != "") {
		var codedidval = drugsearchInput.attr("data-codedid");
		console.log(codedidval);
		if ((typeof codedidval != "undefined") && codedidval != "" && codedidval != "0") {
			var couponitems = "";
			if ($.trim($("#l2vCoupanCode").attr("data-code")) == codedidval) {
				couponitems = $("#l2vCoupanCode").val();
				couponitem = codedidval;
			}
			var item_wallet = 0;
			var currentLineItem = [];
			currentLineItem = mdmLineItemList.filter(function(item){
				if(typeof item.codedid != 'undefined'){
					return (codedidval == item.codedid);
				}else if(typeof item.code != 'undefined'){
					return (codedidval == item.code);
				}else if(typeof item.item_code != 'undefined'){
					return (codedidval == item.item_code);
				}
			});   
			if(typeof mdmLineItemList[0].apportionedWalletAmount == 'undefined'){
				item_wallet = currentLineItem.wallet_amount;
			}else{
				item_wallet = currentLineItem.apportionedWalletAmount;
			}
			currentLineItem = currentLineItem[0];
			console.log(currentLineItem);
			lineitems.push({
			codedid: codedidval,
			brandname: drugName,
			itemname: drugName,
			pharmaname: $(this).find('input[name="pharmaname"]').val(),
			doctorname: $(this).find('input[name="doctorname"]').val(),
			item_mrp: parseFloat($(this).find('input[name="itemmrpval"]').val()),
			discountamount: parseFloat($(this).find('input[name="discountAmount"]').val()),
			item_wallet: item_wallet, //(drugAmountDetails.attr("data-walletamt")) ? drugAmountDetails.attr("data-walletamt") : 0,
			coupon: couponitems,
			code: drugsearchInput.attr("data-id"),
			priceperunit: drugsearchInput.attr("data-priceperunit"),
			category: drugsearchInput.attr("data-category"),
			subcategory_id: "",
			item_code: codedidval,
			quantity: $(this).find('input[name="quantity"]').val(),
			type: "2",
			MRP: parseFloat($(this).find('input[name="itemmrpval"]').val()),
			gross_amount: parseFloat($(this).find('input[name="grossamount"]').val()),
			net_amount: parseFloat($(this).find('input[name="netAmount"]').val()),
			wallet_amount: ((typeof currentLineItem!="undefined")?currentLineItem.apportionedWalletAmount:0), //parseFloat(drugAmountDetails.attr("data-apportionedwalletamount")),
			voucher_amount: ((typeof currentLineItem!="undefined")?currentLineItem.voucherApportionedAmount:0),//parseFloat(drugAmountDetails.attr("data-voucherApportionedAmount")),
			markup_amount: 0,
			cli: 0,
			coupon_amount: ((typeof currentLineItem!="undefined")?currentLineItem.couponValue:0),//parseFloat(drugAmountDetails.attr("data-couponValue")),
			is_cashless: "",
			invoiceto: "",
			reportto: "'" + ((typeof currentLineItem!="undefined")?currentLineItem.invoiceTo:0) + "'", //drugAmountDetails.attr("data-invoiceTo"),
			payment_code: "0",
			corporateinvoiceemail: "",
			corporatereportemail: "",
			roleBasedService: 0,
			doctor: $(this).find('input[name="doctorname"]').val(),
			discount_amount: parseFloat($(this).find('input[name="discountAmount"]').val()),
			old_item_mrp: 0, //parseFloat(drugAmountDetails.attr("data-MRP")),
			old_gross_amount: 0, //parseFloat(drugAmountDetails.attr("data-grossAmount")),
			old_discount_amount: 0, //parseFloat(drugAmountDetails.attr("data-discountAmount")),
			old_net_amount: 0, //parseFloat(drugAmountDetails.attr("data-netAmount")),
			manufacturer_id: drugsearchInput.attr("data-manufacturerid"),
			manufacturer: drugsearchInput.attr("data-manufacturer"),
			packsize: drugsearchInput.attr("data-packsize"),
			prescribed: ($(this).find('label[name="l2vsetrxotg"]').data("rxset") == true) ? "1" : "0",
			prescription_required:($(this).find('label[name="l2vsetrxotg"]').data("rxset") == true) ? "1" : "0",
			cartDiscountApplied: (currentLineItem.cartDiscountApplied == 'true') ? true : false,  //(drugAmountDetails.attr("data-cartdiscountapplied") == "true") ? true : false,
			discountApplied: (currentLineItem.discountApplied == 'true') ? true : false, //(drugAmountDetails.attr("data-discountapplied") == "true") ? true : false,
			cartCouponApplied: (currentLineItem.cartCouponApplied == 'true') ? true : false, //(drugAmountDetails.attr("data-cartcouponapplied") == "true") ? true : false,
			orderDiscountApplied: (currentLineItem.orderDiscountApplied == 'true') ? true : false, //(drugAmountDetails.attr("data-orderdiscountapplied") == "true") ? true : false,
			lineItemDiscountAmount: 0,
			cartDiscountApportionedAmount: currentLineItem.cartDiscountApportionedAmount, //parseFloat(drugAmountDetails.attr("data-cartdiscountapportionedamount")),
			orderApportionedDiscountAmount: currentLineItem.orderApportionedDiscountAmount, //parseFloat(drugAmountDetails.attr("data-orderapportioneddiscountamount")),
			isReturnable: true,
			isWaiver: false
			});
		}
	}
	});
	//console.log(lineitems); return false;
	return lineitems;
}

function applywallet() {
	newCheckpricefrommdm();
}

function newordertab() {
	doctorNameList = {};
	for (var i = 0; i < sessionStorage.length; i++){
		if (sessionStorage.key(i).substring(0, 14) == 'new_drug_order') {
			sessionStorage.removeItem(sessionStorage.key(i));
		}
	}
	$("#vendorname").val("0");
	sessionStorage.setItem('orderid', "");
	sessionStorage.setItem('orderwid', "");
	sessionStorage.setItem('orderwdid', "");
	sessionStorage.setItem("encounterid", "");
	sessionStorage.setItem("prescriptionobj", "");
	sessionStorage.setItem("orderstatuscurorder", "");
	sessionStorage.setItem('orderMode', 'new');
	$("#l2vreferby").val("");
	var _data = {"orderid": ""}
	var mrn = sessionStorage.getItem('patientmrn');
	selectedDrugsList = [];
	patient_search('mrn', mrn, 10, 1, cbk_open_patient_records);
	$("#l2orderdetailsdiv").css("display", "none");
	$("#l2ordercreatediv").css("display", "block");
	$("#l2vsearch_custom").show();
	$("#l2v_completeorder").removeClass("active");
	$("#l2v_pendingorder").removeClass("active");
	$("#l2v_neworder").addClass("active");
	$("#l2vwalletbutton").show();
}

function l2vpendingorder() {
	$("#l2edit").hide();
	var mrn = sessionStorage.getItem('patientmrn');
	var _data = {orderStatus: [6], mrn: mrn, businessId: ["2"], dateFilter:"created_date", sortBy:"DESC",NotInActionON:["orderStatus"]}; 
	_ajaxEventHandler("orders", _data, cbk_pendingorder, SHOW_LOADER, "POST", operationUrl);
	//pharma_widgets
	showcoupenmmsg = 2;
}

function l2vcompleteorder() {
	$("#l2edit").hide();
	var mrn = sessionStorage.getItem('patientmrn');
	var _data = {orderStatus: [6], mrn: mrn, businessId: ["2"], dateFilter:"created_date", sortBy:"DESC"};
	_ajaxEventHandler("orders", _data, cbk_completedorder, SHOW_LOADER, "POST", operationUrl);
	//pharma_widgets
	showcoupenmmsg = 2;
}

function l2vreturnorder() {
	sessionStorage.setItem('orderMode','return');
	$("#l2edit").hide();
	var mrn = sessionStorage.getItem('patientmrn');
	var _data = {orderStatus: [19], mrn: mrn,  businessId: ["2"], dateFilter:"created_date", sortBy:"DESC"};
	_ajaxEventHandler("orders", _data, cbk_returnorder, SHOW_LOADER, "POST", operationUrl);
	//pharma_widgets
	showcoupenmmsg = 2;
}

function cbk_pendingorder(response) {
	renderpendingorder(response);
	$("#l2v_pendingorder").addClass("active");
	$("#l2v_neworder").removeClass("active");
	$("#l2v_completeorder").removeClass("active");
	//console.log(response);
	$(".loader").hide();
}

function cbk_completedorder(response) {
	rendercompletedorder(response);
	$("#l2v_completeorder").addClass("active");
	$("#l2v_neworder").removeClass("active");
	$("#l2v_pendingorder").removeClass("active");
	//console.log(response);
	$(".loader").hide();
}

function cbk_returnorder(response) {
	rendercompletedorder(response);
	$("#l2v_retrunorder").addClass("active");
	$("#l2v_neworder").removeClass("active");
	$("#l2v_completeorder").removeClass("active");
	$("#l2v_pendingorder").removeClass("active");
	//console.log(response);
	$(".loader").hide();
}

//single order  view 
function vieworder(order_id) {
	checkSum = '.splitOne-0';
	var _data = {orderid: order_id};
	sessionStorage.setItem('orderid',order_id);
	_ajaxEventHandler("getorderdetails", _data, showorderview, SHOW_LOADER);
}

function openDetails(contentId, orderId, itemCode) {
	orderId = orderId || false;
	itemCode = itemCode || false;
	$('.hideAllDetails').hide();
	$('.removeActive').removeClass('active');
	$('.innerModal').addClass("active");
	$('#innerModal').addClass('active in');
	if (orderId !== false) {
		$('#log_omorder_id').val(orderId);
		$('#log_item_id').val(itemCode);
	}
	$('#' + contentId).show();
}

function hideAllDetails() {
	$('.hideAllDetails').hide();
}

function showAddressList() {
	var mrn = sessionStorage.getItem("patientmrn");
	var _datamrn = {mrn: mrn};
	_ajaxEventHandler("getAddress", _datamrn, cbk_getAddress, '');
}

function cbk_getAddress(response) {
	if (typeof response == 'string') {
		var patientAddressJson = JSON.parse(response);
	} else {
		var patientAddressJson = response;
	}
	var patientAddressArray = [];
	if (patientAddressJson.status == 1) {
		patientAddressArray = patientAddressJson.data.addressDetails;
	}
	patientAddressList(patientAddressArray);
}

function selectAddress(addressId, modify) {
	modify = modify || false;
	var addressDivId = '#' + addressId;
	var landmark = $(addressDivId).find('.landMarkVal').text();
	var cityVal = $(addressDivId).find('.cityVal').text();
	var areaVal = $(addressDivId).find('.areaVal').text();
	var stateVal = $(addressDivId).find('.stateVal').text();
	var zipcodeVal = $(addressDivId).find('.zipcodeVal').text();
	var countryVal = sessionStorage.getItem("country");
	var latitude = $(addressDivId).find('.latitude').text();
	var longitude = $(addressDivId).find('.logitude').text();
	var addressNickName = $(addressDivId).find('.addressNickName').text();
	var district = $(addressDivId).find('.districtVal').text();
	var addressVal = $(addressDivId).find('.addressVal').text();
	var address = addressVal + ", " + areaVal + ", " + cityVal + ", " + stateVal + ", " + countryVal + ", " + zipcodeVal;
	var contactno = sessionStorage.getItem("contactno");
	var alternetcontactno = sessionStorage.getItem("alternetcontactno");
	if (modify == true) {
		$('#address_nick_name').val(addressNickName);
		$('#address1').val(addressVal);
		$('#administrative_area_level_1').val(stateVal);
		$('#locality').val(cityVal);
		$('#route').val(areaVal);
		$('#postal_code').val(zipcodeVal);
		$('#autocomplete').val(landmark);
		$('#pcontactno').val(contactno);
		$('#latitude').val(latitude);
		$('#longitude').val(longitude);
		$('#alternetcontactno').val(alternetcontactno);
		$('.update_address_btn').html('Update Address');
	} else {
		sessionStorage.setItem("landmark", landmark);
		sessionStorage.setItem("city", cityVal);
		sessionStorage.setItem("district", district);
		sessionStorage.setItem("state", stateVal);
		sessionStorage.setItem("country", countryVal);
		sessionStorage.setItem("zipcode", zipcodeVal);
		sessionStorage.setItem("address_nickname", addressNickName);
		sessionStorage.setItem("address", address);
		sessionStorage.setItem("address_id", addressId);
		sessionStorage.setItem("address", address);
		sessionStorage.setItem("address_id", addressId);
		sessionStorage.setItem("latitude", latitude);
		sessionStorage.setItem("longitude", longitude);
		$('#showdelvaddress').html(address);
		$('#addressListModal').modal('hide');
	}
	$('#selected_address_id').val(addressId);
	check_servisablepincode();
}

var presModule = '';        
function openprescriptionmadal(prescriptionId,containerId) {
presModule = containerId;
$(".loader").hide();
renderModalPrescription(prescriptionId);
}

function clearAddressData() {
	$('.clearAddressData').val('');
	$('.update_address_btn').text('Save Address');
	$('#selected_address_id').val('');
}


function reorderfun(orderid, type) {
	if (type == 0) {
		sessionStorage.setItem('orderid', orderid);
	}
	sessionStorage.setItem("encounterid", "");
	$("#l2vopenprescriptionmadal").css("display", "none");
	var _data = {"orderid": orderid};
	_ajaxEventHandler("getorderdetails", _data, cbk_open_patient_orders, '');
	$("#l2vsearch_custom").show();
	$("#l2v_completeorder").removeClass("active");
	$("#l2v_pendingorder").removeClass("active");
	$("#l2v_neworder").addClass("active");
	showcoupenmmsg = 2;
}

function editOrderDetails(order_id, orderType) {
	doctorNameList = {};
	orderType = orderType || 'update';
	sessionStorage.setItem('orderMode', orderType);
	sessionStorage.setItem('orderid', order_id);
	var _data = {orderid: order_id};
	_ajaxEventHandler("getorderdetails", _data, editOrderHtml, SHOW_LOADER);
}

//order assign to vendor 
function assignvendor(omorder_id) {
	var vendor_id = $('#vendor').val();
	var vendor_name = $('#vendor option:selected').text();
	var vendoraddress = $("#vendor option:selected").data("address");
	var loginid = sessionStorage.getItem("loginid");
	var loginname = sessionStorage.getItem("loginname");
	var _data = {
		order_id: omorder_id,
		actionById: loginid,
		actionByName: loginname,
		source: "L2",
		comment: "",
		reason: "Assigned Vendor",
		status: 21, //*
		associate_id: vendor_id
	};
	if (vendor_id == '' || vendor_name == '') {
		alert("Please Select All Fields.");
		return false;
	}
	//console.log(_data);
	_ajaxEventHandler("order/change/status", _data, hidecbk, SHOW_LOADER, "POST", operationUrl);
}

function hidecbk() {
	location.reload();
} 

function trackOrder(orderid) {
	if (orderid == "") {
		alert("Please Select the Correct Order.")
	} else {
		var _data = {order_id: orderid};
		_ajaxEventHandler('ordertrack', _data, trackOrderView, SHOW_LOADER, "POST", "operation.php/v1/");
	}
}

function orderlogsubmit() {
	var omorder_id = $('#log_omorder_id').val();
	var item_ids = $('#log_item_id').val();
	var logreasons = $('#orderlogreasons').val();
	var role = 'L2Pharma';
	if ($.trim(logreasons) == '') {
		alert('Please fill the Log information.');
		//return false;
	} else {
		var vendorid = sessionStorage.getItem('loginid');
		var vendorname = sessionStorage.getItem('loginname');
		var _data = {omorder_id: omorder_id, item_ids: item_ids, rejectreasons: logreasons, vendorid: vendorid, vendorname: vendorname, role: role};
		_ajaxEventHandler("create_log", _data, logorderhide, SHOW_LOADER);
	}
}
function logorderhide() {
	alert('Log submitted successfully.');
	$(".loader").hide();
	$('#viewOrder').modal('hide');
	$('.hideAllDetails').hide();
	$('.removeActive').removeClass('active');
	$('.veiwOrderDetails').addClass("active");
	$('#veiwOrderDetails').addClass('active in');
}

function showwallethistory(mrn){
	var _data = {mrn:mrn};
	_ajaxEventHandler("wallet_transaction_history", _data, cbk_wallet_transction_history, NO_SHOW_LOADER);
}

function open_cp_prescription(mrn){
	var _data = {mrn:mrn};
	_ajaxEventHandler("getPrescriptionCP", _data, cbk_getprescriptionCP);
}

function open_3monthprecription(mrn){
	var _data = {mrn:mrn};
	var data = _ajaxEventHandler("monthviseprecription", _data, past_prescriptionview, SHOW_LOADER);
}

function open_refillbymrn(mrn){
	var _data = {mrn:mrn};
	var data = _ajaxEventHandler("reminder_request", _data, refillviewbymrn, SHOW_LOADER);
}

function open_slot_modal(sectionId){
	var header_data = "";
	var body_data = "";
	var itemcode = "";
	activeSection = sectionId;
	$('.' + sectionId).find("input[name=drugsearch]").each(function (){
		itemcode = $(this).attr("data-codedid");
		return false;
		//break;
	});
	//alert(global_serviceable);
	if(global_serviceable==0){
		 alert('Sorry! This location is not serviceable. Please choose a different address.');
		return;
	}
	
	if ($.trim(itemcode) == ""){
		alert("Please enter test name");
		return false;
	}
	if ($.trim(sessionStorage.getItem("zipcode")) == ""){
		alert("Please provide proper pincode.");
		return false;
	}
	//var tommorowDate = $("#selecttimeslot").attr("data-scheduled_date").split(" ");     
	//var tommorowDate = $("#selecttimeslot").attr("data-scheduled_date").split(" ");     
	header_data += '<h4 class="modal-title" id="myModalLabel">Choose the slot</h4><span id="walletbal"></span>';
	body_data += '<div>' +
	"<div class='input-group date datepicker orderdatediv' id='orderdatediv'>" +
	"<input id='mainorderdate' type='text' onchange='fetch_slot();' class='form-control' value='" + tommorowDate() + "' readonly=''>" +
	"<span class='input-group-addon'>" +
	"<i class='fa fa-calendar' aria-hidden='true'></i>" +
	"</span>" +
	"</div>" +
	"</div>" +
	'<div id="londing_view">' +
	'<div class="loader" style="display:block"></div>' +
	'</div>' +
	'<div id="slotdiv"></div>';
	$("#myModalLabel").html(header_data);
	$("#trackresult").html(body_data);
	$("#Modal_for_all").modal("show");
	//$("#mainorderdate").val();
	fetch_slot(itemcode, tommorowDate());
}

function fetch_slot(itemcode, defaultDateSlot = ""){
	if (itemcode == ""){
		$("input[name=item_reject]").each(function (){
			itemcode = $(this).val;
			return false;
			//break;
		});
		if ($.trim(itemcode) == ""){
			alert("Please enter test name");
			return false;
		}
	}
	if (defaultDateSlot == ""){
		defaultDateSlot = $("#mainorderdate").val();
	}

	var _data = {
		from_date:defaultDateSlot,
		to_date:defaultDateSlot,
		business_id:"2",
		sub_business_id:"9",
		service_did:itemcode,
		//pop_id:$("#selecttimeslot").attr("data-popid"),
		patient_mrn:$.trim(sessionStorage.getItem("patientmrn")),
		patient_age:$("#selecttimeslot").attr("age"),
		patient_gender:"",
		preferred_officer:"",
		pin_code:$.trim(sessionStorage.getItem("zipcode")),
		order_latitude:$.trim(sessionStorage.getItem("latitude")),
		order_longitude:$.trim(sessionStorage.getItem("longitude")),
		check_ddo_availability:"N"
	}
	//console.log(_data);
	_ajaxEventHandler('fetch_slots', _data, response_fetch_slot, SHOW_LOADER, "POST", "operation.php/v1/");
}

function response_fetch_slot(response){
	//console.log(response);
	$(".loader").hide();
	var senddate = $("#mainorderdate").val();
	var htmlstring = "";
	if (response.success === "1"){
		$.each(response.data[senddate], function (key, val) {
			if (val.is_booked != 1){
				var from_time = senddate + " " + val.from_time;
				var to_time = senddate + " " + val.to_time;
				htmlstring += "<button class='btn btn-success' style='margin:5px;' onclick='booktheslot(\"" + val.transaction_id + "\",\"" + senddate + "\",\"" + val.from_time + "\",\"" + val.to_time + "\")'>" + datetime24to12(from_time) + " - " + datetime24to12(to_time) + "</button>";
			}
		});
		if (htmlstring == ""){
			htmlstring = "<br><label>Slots are not available.</label>";
		}
		$("#slotdiv").html(htmlstring);
	} else{
		//console.log(response.message);
		alert(response.message);
	}
}

function booktheslot(transaction_id, selected_date, from_time, to_time){
	$('.' + activeSection).find(".timeslot").attr("data_starttime", from_time);
	$('.' + activeSection).find(".timeslot").attr("data_endtime", to_time);
	$('.' + activeSection).find(".timeslot").attr("data_date", selected_date);
	$('.' + activeSection).find(".timeslot").attr("data_trasactionid", transaction_id);
	$('.' + activeSection).find(".timeslot").html(selected_date + " " + to_time);
	$("#Modal_for_all").modal("hide");
	//"bookedselecttime"
}

function prescriptionLinkSMS(orderid, componenetno){
	var _data = {
		order_id:orderid,
		component_id:componenetno
	};
	var data = _ajaxEventHandler("prescription-upload-link", _data, cbk_prescriptionLinkSMS, SHOW_LOADER, "POST", "operation.php/v1/orders/notification/send/");
}

function cbk_prescriptionLinkSMS(result){
	if (result.success == 1){
		alert(result.message);
	} else{
		alert(result.message);
	}
	$(".loader").hide();
}

function cancelorder(orderid){
	var loginid = sessionStorage.getItem("loginid");
	var loginname = sessionStorage.getItem("loginname");
	var r = prompt("Please enter Cancel Reason:", "");
	if (r == null || r == ""){

	}else {
		var _data = {
			order_id:[orderid],
			reason:r,
			reason_text:r,
			comment:"cancel",
			actionById:loginid,
			actionByName:loginname,
			scheduled_date:"",
			reasonType:1,
			source:6,
			categoryId:"1",
			subCategoryId:"2",
			role:"customer",
			disable_mad_rule:1
		};
        var data = _ajaxEventHandler("orderCancel", _data, cbk_cancelorder, SHOW_LOADER, "POST", "operation.php/v1/");
    }
}

function cbk_cancelorder(result){
	console.log(result);
	$('#viewOrder').modal('hide');
	$(".loader").hide();
}

function updateDrugOrder(){
	var referedby = "";
	var sourceofreferral = "";
	var referredmrn = "";
		// 1 - yes 2 - no 
	var couponitem = "";
	if ($("#l2vreferby").val() == "") {
		alert('Please enter the referring Officer ID. If none, then please enter 9999.');
	} else {
		referedby = $("#l2vreferby").val();                        
	}

	if ($("#l2vsourcereferral option:selected").val() == "") {
		alert('Please select source.');
	} else {
		sourceofreferral = $("#l2vsourcereferral option:selected").val();
	}

	referredmrn = $("#l2vsreferbymrn").val();
	if ($("#postal_code").val() == "" || $("#postal_code").val() == 0 || $("#postal_code").val() == "0") {
		alert('Please enter postal code');
		return;
	}

	var loginid = sessionStorage.getItem("loginid");
	var loginname = sessionStorage.getItem("loginname");
	var name = sessionStorage.getItem('displayname');
	var salutation = sessionStorage.getItem("salutation");
	var patientfname = sessionStorage.getItem('patientfname');
	var patientmname = sessionStorage.getItem('patientmname');
	var patientlname = sessionStorage.getItem('patientlname');
	var age = sessionStorage.getItem('displayage');
	var gender = sessionStorage.getItem('patientgender');
	var contactno = sessionStorage.getItem('contactno');
	var alternetcontactno = sessionStorage.getItem('alternetcontactno');
	if (contactno == "") {
		contactno = sessionStorage.getItem('contactno');
	}
	if (alternetcontactno == "") {
		alternetcontactno = (sessionStorage.getItem('alternetcontactno') == "Array") ? "" : sessionStorage.getItem('alternetcontactno');
	}
	var email = sessionStorage.getItem('email');
	var tagsfororder = (sessionStorage.getItem('tagsfororder') == null) ? "" : sessionStorage.getItem('tagsfororder');
	//var referedby=$.trim($("#l2vreferby").val());

	var doorno = "";
	var popname = sessionStorage.getItem('popname');
	var facility_id = sessionStorage.getItem('facility_id');
	var home_pop = sessionStorage.getItem('home_popname');
	var home_fc_id = sessionStorage.getItem('home_facility_id');
	var landmark = sessionStorage.getItem('landmark');
	var address1 = sessionStorage.getItem('address');
	var area = sessionStorage.getItem('area');
	var area = sessionStorage.getItem('area');
	var countrydistrict = sessionStorage.getItem('district');
	var state = sessionStorage.getItem('state');
	var zipcode = sessionStorage.getItem('zipcode');
	var longitude = sessionStorage.getItem('longitude');
	var latitude = sessionStorage.getItem('latitude');
	var addressId = sessionStorage.getItem('address_id');
	var payment_method = $("#payment_method option:selected").val();
	//var coupon = $("#coupon").val();
	var coupon = $("#l2vCoupanCode").val();
	if (showcoupenmmsg == 0) {
		coupon = "";
	}

	//for call
	var mrn = sessionStorage.getItem('patientmrn');
	var lead_id = (typeof sessionStorage.getItem('lead_id') != "undefined") ? sessionStorage.getItem('lead_id') : "";
	var callNumber = sessionStorage.getItem('callNumber');
	var orderid = sessionStorage.getItem('orderid');
	var encounterid = sessionStorage.getItem('encounterid');
	var patientid = sessionStorage.getItem('patientid');
	var orderwid = sessionStorage.getItem('orderwid');
	var orderwdid = sessionStorage.getItem('orderwdid');
	var doctorid = sessionStorage.getItem('doctorid');
	var doctorname = sessionStorage.getItem('doctorname');
	var mrncoporateid = sessionStorage.getItem('mrncoporateid');
	var mrncoporatename = sessionStorage.getItem('mrncoporatename');
	var ordersmscreate = (typeof (sessionStorage.getItem("ordersmscreate")) == "undefined") ? "0" : sessionStorage.getItem("ordersmscreate");
	var ezzetab_sms = sessionStorage.getItem('ezzetab_sms');
	var placedfromdoctorplace = sessionStorage.getItem("placedfromdoctorplace");
	var orderstatuscurorder = sessionStorage.getItem("orderstatuscurorder");
	var l2vprepaidamountcheck = $("#l2vprepaidamount").html();
	var medicine_delivery = 0;
	var deliveryarray = [];
	if ($("#medicine_delivery").val() == "1") {
		medicine_delivery = $("#medicine_delivery").attr("data-item_mrp");
		deliveryarray.push({
			item_code: $("#medicine_delivery").attr("data-codedid"),
			quantity: "1",
			gross_amount: $("#medicine_delivery").attr("data-item_gross"),
			item_mrp: $("#medicine_delivery").attr("data-item_mrp"),
			discount_amount: $("#medicine_delivery").attr("data-item_discount"),
			net_amount: $("#medicine_delivery").attr("data-item_net"),
			ignoreToPartner: $("#medicine_delivery").attr("data-ignoreToPartner")
		});
	}
	var totalOrders = [];
	var totalgross = '0.00';
	var totalnet = '0.00';
	var totaldiscount = '0.00';
	var totalUsedWalletAmount = '0.00';
	var totalVoucherAmount = '0.00';
	var check_anyerror = 0;
	$('.new-order-by-category').each(function () {
		$this = $(this);
		var sectionId = $this.attr('data-sectionid');
		//check if any RX item is available(set prescription later and send message) or not (set vendor) 
		var rxisavailable = 0;
		var otgisavailable = 0;
		var sendsmsforpprescription = 0;
        $this.find('label[name=l2vsetrxotg]').each(function () {
			if ($.trim($(this).attr("data-rxset")) == "true") {
				rxisavailable = rxisavailable + 1;
			}
        });
             //   if (rxisavailable > 0) {
        if ($("#vendorname").val() == "0") {
			alert("Please select vendor.");
			check_anyerror = 1;
			return;
        }
        if (sessionStorage.getItem("orderstatuscurorder") == "24") {
			if ($("#vendorname").val() === "0") {
				alert("Please select vendor.");
				check_anyerror = 1;
				return;
			}
        } else {
			if (sessionStorage.getItem("encounterid") != "" && sessionStorage.getItem("orderstatusencounterid") != "6") {
				sendsmsforpprescription = 0;
			} else {
				if ((sessionStorage.getItem("encounterid") == "") && (sessionStorage.getItem(sectionId) != "")) {
					sendsmsforpprescription = 0;
				} else {
					sendsmsforpprescription = 1;
				}
			}
        }

        var vendorid = $this.find("#vendorname option:selected").val();
		var vendorname = $this.find("#vendorname option:selected").text();
		var vendoraddress = $this.find("#vendorname option:selected").attr("data-address");
		if (vendorid == "0") {
			var vendorid = "";
			var vendorname = "";
        }

        var currentNetAmount = $.trim($this.find("#l2vitemtotalamount").html());
		if (currentNetAmount != '') {
			totalnet = parseFloat(totalnet) + parseFloat(currentNetAmount);
			totalnet = parseFloat(totalnet).toFixed(2);
        }

        var deliveryAmount = $.trim($this.find("#l2vdeliverycharge").html());
		if (deliveryAmount != '') {
			deliveryAmount = parseFloat(deliveryAmount).toFixed(2);
        }
        var currentGrossAmount = $.trim($this.find("#l2vitemtotalamountgross").html());
		if (currentGrossAmount != '') {
			totalgross = parseFloat(totalgross) + parseFloat(currentGrossAmount);
			totalgross = parseFloat(totalgross).toFixed(2);
        }


        var currentDiscountAmount = $.trim($this.find("#l2vitemtotalamountdiscount").html());
		if (currentDiscountAmount != '') {
			totaldiscount = parseFloat(totaldiscount) + parseFloat(currentDiscountAmount);
            totaldiscount = parseFloat(totaldiscount).toFixed(2);
        }

        //var payment_info_coupon_amount = 0;
        /*if (currentDiscountAmount != '') {
         totaldiscount = parseFloat(totaldiscount) + parseFloat(currentDiscountAmount);
         totaldiscount = parseFloat(totaldiscount).toFixed(2);
         }*/

        var currentUsedWalletAmount = $.trim($this.find("#l2vitemwalletamount").html());
        if (currentUsedWalletAmount != '') {
			totalUsedWalletAmount = parseFloat(totalUsedWalletAmount) + parseFloat(currentUsedWalletAmount);
            totalUsedWalletAmount = parseFloat(totalUsedWalletAmount).toFixed(2);
        }

        var currentVoucherAmount = $.trim($this.find('#l2vitemtotalamount').attr('data-voucherAmount'));
        if (currentVoucherAmount != '') {
			totalVoucherAmount = parseFloat(totalVoucherAmount) + parseFloat(currentVoucherAmount);
			totalVoucherAmount = parseFloat(totalVoucherAmount).toFixed(2);
        }
        var scheduletimeforordr = $.trim($this.find(".timeslot").html());
        if ((typeof scheduletimeforordr == "undefined") || scheduletimeforordr == ""){
			alert("Please choose the preferred delivery time slot.");
			check_anyerror = 1;
			return false;
        }

        var prescriptionfile = [];
        $this.find('.rowdrug').each(function () {
            var drugsearchInput = $(this).find('input[name=drugsearch]');
            var drugName = drugsearchInput.val();
            if ($.trim(drugName) != "") {
                var codedidval = drugsearchInput.attr("data-codedid");
                var prescriptionObj = 'split_'+codedidval + '_file';                
                if (sessionStorage.getItem(prescriptionObj) != null){
                $.merge(prescriptionfile,JSON.parse(sessionStorage.getItem(prescriptionObj)));
                }
            }
        });
		var newOrderItems = newOrderByCategory($this);
		newOrderItems.push({
			codedid: sessionStorage.getItem('DCCode'),
			brandname: "DDO",
			itemname: 'DDO',
			pharmaname: "",
			doctorname: "",
			item_mrp: parseFloat(deliveryAmount),
			discountamount: 0,
			item_wallet: 0,
			coupon: "",
			code: "",
			priceperunit: "",
			category: "1",
			subcategory_id: "",
			item_code: sessionStorage.getItem('DCCode'),
			quantity: "1",
			type: "2",
			MRP: parseFloat(deliveryAmount),
			gross_amount: parseFloat(deliveryAmount),
			net_amount: parseFloat(deliveryAmount),
			wallet_amount: 0,
			voucher_amount: 0,
			markup_amount: 0,
			cli: 0,
			coupon_amount: 0,
			is_cashless: "",
			invoiceto: "",
			reportto: "1",
			payment_code: "0",
			corporateinvoiceemail: "",
			corporatereportemail: "",
			roleBasedService: 1,
			doctor: "",
			discount_amount: 0,
			old_item_mrp: parseFloat(deliveryAmount),
			old_gross_amount: parseFloat(deliveryAmount),
			old_discount_amount: 0,
			old_net_amount: parseFloat(deliveryAmount),
			manufacturer_id: "",
			manufacturer: "",
			packsize: "",
			prescribed: "1",
			cartDiscountApplied: false,
			discountApplied: false,
			cartCouponApplied: false,
			orderDiscountApplied: false,
			lineItemDiscountAmount: 0,
			cartDiscountApportionedAmount: 0,
			orderApportionedDiscountAmount: 0,
			isReturnable: true,
			isWaiver: false,
			role:9,
			skill:"1"
		});
		totalOrders.push({
			mrn: mrn,
			order_id: sessionStorage.getItem('orderid'),
			address_id: addressId,
			associate_id: vendorid,
			associate_branch_id: "",
			service_type: "2",
			scheduled_date: scheduletimeforordr,
			payment_code: "0",
			creation_type: 1,
			application_no: "",
			surge_amount: 1,
			mode_of_service: 1,
			report_required:((typeof $this.find('#checkboxprescriptionsms').val() != "undefined")?$this.find('#checkboxprescriptionsms').val():0),
			report_delivery_date: "",
			slot_transaction_id: [],
			deliveryCharges: deliveryAmount,
			prescription_images:prescriptionfile,
			/*prescription_file: [
			 [
			 prescriptionfile
			 ]
			 ],*/
			order_item: newOrderItems
		});
		//return false;
	});
	if (check_anyerror == 1){
		return false;
	}
	var deduct_the_wallet = 0;
	if (parseFloat(totalUsedWalletAmount) > 1){
		deduct_the_wallet = 1;
	}
	var payment_info_coupon_amount = 0;
	var _data = {
	orderMode: sessionStorage.getItem('orderMode'),
		mrn: mrn,
		channel: 2,
		source_of_referral: "Outbound",
		referral_id: referedby,
		created_by_id: loginid,
		created_by_name: loginname,
		referral_mrn: referredmrn,
		orders: totalOrders,
		deduct_the_wallet:deduct_the_wallet,
		payment_info: {
		payment_amount: parseFloat(totalnet),
				payment_service: "COD",
				source_type: "",
				payment_mode: 0,
				payment_reference_id: "",
				wallet_amount: parseFloat(totalUsedWalletAmount),
				coupon: coupon,
				//coupon_amount: parseInt(totaldiscount),
				coupon_amount: parseFloat(payment_info_coupon_amount),
				gross_amount: parseFloat(totalgross),
				voucher_assoc_code: "",
				voucher_code: "",
				voucher_amount: parseFloat(totalVoucherAmount)
		}
	};
	//console.log(_data);
	// return false;
	//console.log(_data);
	_ajaxEventHandler("updateOrder", _data, cbk_updateRejectedOrder, SHOW_LOADER, "POST");
}

function cbk_updateRejectedOrder(response){
	$(".loader").hide();
	//console.log(response);
	var Obj = response;
	if (typeof response == 'string') {
		Obj = JSON.parse(response);
	}
	if (Obj.status == "1") {
		alert(Obj.message);
		$("section[class='new-order-by-category']").each(function(){
			var prescriptionObj_remove = $(this).attr("data-sectionid") + '_file';
			prescriptionObj_remove = prescriptionObj_remove.replace(/\-/g, '_');
			if (sessionStorage.getItem(prescriptionObj_remove) != null){
				sessionStorage.removeItem(prescriptionObj_remove);
			}
		});
		sessionStorage.setItem('orderid', "");
		sessionStorage.setItem('orderwid', "");
		sessionStorage.setItem('orderwdid', "");
		sessionStorage.setItem("encounterid", "");
		sessionStorage.setItem("prescriptionobj", "");
		sessionStorage.setItem("placedfromdoctorplace", "0");
		$("#l2vreferby").val("");
		var _data = {"orderid": ""}
		_ajaxEventHandler("open_patient_orders", _data, cbk_open_patient_orders, '');
		newordertab();
	} else {
		alert(Obj.message);
	}
}

//search the medicine item
function loaddruglist(id) {
	var str = $('#' + id).val();
	var listid = $('#' + id).attr('list');
	var l2type = "medicine";
	if (str.length <= 0) {
		return false;
	}
	var dataList = $('.data-search-select').find('.data_druglist [value="' + str + '"]');
	if (dataList.length <= 0) {
		if (str.length > 3) {
		//console.log(activeDrugSearch);
			if (activeDrugSearch) {
			currentReqt.abort();
			}
			activeDrugSearch = true;
			var _data = {"filtercolumn": "name", "brandname": str, "listid": listid, "entitytype": l2type};
			_ajaxEventHandler("search_item", _data, cbk_loaddruglist, SHOW_LOADER);
		}
	} else {
		$this = $('#drugsearch');
		selecteddiag = $('#drugsearch').val();
		if ($.inArray(selecteddiag, selectedDrugsList) > - 1) {
			alert('Same item cannot be ordered twice.');
			$('#drugsearch').val('');
			return;
		}
	
		var datalist = $('.data-search-select').find('.data_druglist [value="' + selecteddiag + '"]');
		var drugCategory = datalist.data('category');
		drugCategory = parseFloat(drugCategory);
		console.log(updateCategory);
		if(sessionStorage.getItem('orderMode') != 'new'){
			if (($.inArray(drugCategory, splitone) > - 1) && (updateCategory != 'splitone')) {
				alert('Another category item can`t be selected');
				$('#drugsearch').val('');
					return;
			}else if(($.inArray(drugCategory, splittwo) > - 1) && (updateCategory != 'splittwo')){
				alert('Another category item cannot be selected.');
				$('#drugsearch').val('');
					return;
			}
		}
	
		var deletePrescFile = 'split_'+datalist.data('codedid')+'_file';
		sessionStorage.removeItem(deletePrescFile);

		var orderGlobalDetails = splitOrderGlobalDetails();
		global_selecteddiag=selecteddiag;
		
		//check_servisablepincode();
		//global_serviceable=1;
		selectedDrugsList.push(global_selecteddiag);
		newCheckpricefrommdm(global_selecteddiag);
		
		updateSplitOrderDetails(orderGlobalDetails);
	}    
}

function cbk_loaddruglist(response) {
	activeDrugSearch = false;
	if (typeof response === 'string') {
		var Obj = JSON.parse(response);
	} else {
		var Obj = response;
	}
	var listid = Obj.listid;
	var druglists = "";
	var objData = Obj.data;
	if (Obj.status === 1) {
		$i = 1;
		for (var key in objData) {
			$i++;
			druglists += '<option ' +
			'data-codedid="' + objData[key].code + '" ' +
			'data-id="' + objData[key].ID + '" ' +
			'data-prescribed="' + objData[key].prescribed + '" ' +
			'data-category="' + objData[key].categoryID + '" ' +
			'value="' + objData[key].name + '" ' +
			'data-minQuantity="' + objData[key].minQuantity + '" ' +
			'data-maxQuantity="' + objData[key].maxQuantity + '" ' +
			'data-manufacturerid="' + objData[key].manufacturerID + '" ' +
			'data-packsize="' + objData[key].packSize + '" ' +
			'data-brand="' + objData[key].brand + '" ' +
			'data-priceperunit="' + objData[key].priceperunit + '" ' +
			'data-pharma="' + objData[key].pharma + '" ' +
			'data-discountamount="' + objData[key].discountamount + '" ' +
			'data-manufacturer="' + objData[key].manufacturer + '">';
			//console.log(druglists);
		}
		$('#' + listid).html(druglists);
			//console.log(druglists);
	} else {
	//alert(Obj.message);
		$('#drugsearch').val('');
	}
	$(".loader").hide();
}

function newCheckpricefrommdm(selecteddiag) {
	selecteddiag = selecteddiag || false;
	var coupon = "";
	var orderDate = todayDateforMDM();
	if ($.trim($("#l2vCoupanCode").attr("data-code")) == "") {
		coupon = $("#l2vCoupanCode").val();
	}
	var business = "2";
	var source = "CCO";
	if (sessionStorage.getItem("channel") !== null && sessionStorage.getItem("channel") !== "") {
		source = channel[parseInt(sessionStorage.getItem("channel"))];
	}

	var lineitems = [];
	var mrnno = sessionStorage.getItem("patientmrn");
	// var itemarray = $("#l2vCoupanCode").attr("data-code").split(',');
	$('input[name=drugsearch]').each(function () {
		$rowId = $(this).parents('tr').attr('id');
		$splitOrderId = $(this).attr('data-split');
		if ($.trim($(this).val()) !== "") {
			$drugName = $(this).val();
			var codedata = $(this).attr('data-codedid');
			if ((typeof codedata !== "undefined") && codedata !== "" && codedata !== "0") {
				lineitems.push({
					orderDate: orderDate,
					business: business,
					code: codedata,
					sessions: $('.'+$splitOrderId).find("#"+$rowId+' input[name="quantity"]').val(),
					source: source,
					mrn: mrnno,
					engage_at: '1',
					zipcode: sessionStorage.getItem('zipcode')
				});
			}
		}
    });
	if (selecteddiag) {
		var datalist = $('.data-search-select').find('.data_druglist [value="' + selecteddiag + '"]');
		selectedDrugDetails.push({
			id : datalist.data('id'),
			codedid : datalist.data('codedid'),
			pharma : datalist.data('pharma'),
			prescribed : datalist.data('prescribed'),
			category : datalist.data('category'),
			manufacturerid : datalist.data('manufacturerid'),
			manufacturer : datalist.data('manufacturer'),
			packsize : datalist.data('packsize'),
			priceperunit : datalist.data('priceperunit')
		});
		lineitems.push({
			orderDate: orderDate,
			business: business,
			code: datalist.data('codedid'),
			sessions: '1',
			source: source,
			mrn: mrnno,
			engage_at: '1',
			zipcode: sessionStorage.getItem('zipcode')
		});
	}
	console.log(lineitems); //return false;
	var walletstatus = sessionStorage.getItem("walletstatus");
	var _data = {
		method: "domain/Order",
		type: "POST",
		orderDate: orderDate,
		source: source,
		coupon: coupon,
		useWallet: "false",
		LineItems: lineitems
	};
	if (($("#applywallet").prop('checked') == true) && (parseInt(walletstatus) != 1)) {
		_data.useWallet = "true";
	}
	console.log(_data);
	_ajaxEventHandler("checkpricefrommdm", _data, prepare_body_checkpricefrommdm, NO_SHOW_LOADER);
}

function prepare_body_checkpricefrommdm(response) {
	var orederHtmlBody = '';
	var countitem = 0;
	var coupon = $("#l2vCoupanCode").val();
	if (typeof response == 'string') {
		var Obj = JSON.parse(response);
	} else {
		var Obj = response;
	}
	// Obj = response;
	var walletstatus = sessionStorage.getItem("walletstatus");
	if (Obj.status === 1) {
		var objData = Obj.data;
		var DDCode = objData.medicineDeliveryChargesList[0].code;
		sessionStorage.setItem('DCCode',DDCode);
		mdmLineItemList = objData.lineItemList;
		var htmlData = prepareOrder(objData, selectedDrugDetails);
		sessionStorage.setItem('associate_id',$('#vendorname').val());
		$("#split-order").html(htmlData);
		var _dataforvendor = {"systemType": "l2pharma"};
		_ajaxEventHandler("vendor_list", _dataforvendor, cbk_setvendorinselecttag, '');
	}
	$('#drugsearch').val('');
	$(".loader").hide();
}        
                
function splitOrderGlobalDetails(para_val_del,rowIndex){
    para_val_del = para_val_del || false;
    rowIndex = rowIndex || false;
    var splitOrderDetails = [];
    if($('.new-order-by-category').length < 0){
        return false;
    }
    $('.new-order-by-category').each(function(){
		var currentCheckSum = $(this).attr('data-sectionid');
		var currentRowIndex = '#rowdrug-1';
		if ((currentCheckSum == para_val_del) && (rowIndex == currentRowIndex)){
			currentRowIndex = '#rowdrug-2';
		}
		console.log(currentCheckSum);
		splitOrderDetails.push({
			itemName :  $('.' + currentCheckSum).find(currentRowIndex).find('input[name="drugsearch"]').val(),
			splitName : (typeof $(this).attr('data-sectionid') != 'undefined') ? $(this).attr('data-sectionid') : '',
			timeslot : (typeof $(this).find('.timeslot').attr('data_trasactionid') != 'undefined') ? $(this).find('.timeslot').attr('data_trasactionid') : '',
			timestart : (typeof $(this).find('.timeslot').attr('data_starttime') != 'undefined') ? $(this).find('.timeslot').attr('data_starttime') : '',
			timesend : (typeof $(this).find('.timeslot').attr('data_endtime') != 'undefined') ? $(this).find('.timeslot').attr('data_endtime') : '',
			timeDate : (typeof $(this).find('.timeslot').attr('data_date') != 'undefined') ? $(this).find('.timeslot').attr('data_date') : '',
			vendorname : $(this).find('#vendorname').val()
		});
	});
	console.log(splitOrderDetails);
	return splitOrderDetails;
}  

function updateSplitOrderDetails(orderGlobalDetails){
    if(orderGlobalDetails == false){
        return false;
    }
	setTimeout(function(){
		console.log(orderGlobalDetails);
	   // if(sessionStorage.getItem('orderMode') == 'new'){
		$('.new-order-by-category').each(function(){
			var currentCheckSum = '.' + $(this).attr('data-sectionid');
			console.log(currentCheckSum);
			console.log($(currentCheckSum).find('input[value="PROLIN 100MG CAPSULE 10"]').length);
			var splitOrderData = orderGlobalDetails.filter(function(item){
			return ($(currentCheckSum).find('input[value="' + item.itemName + '"]').length > 0);
			});
			splitOrderData = splitOrderData[0];
			console.log(splitOrderData);
			if(typeof splitOrderData !== 'undefined'){				
				$(currentCheckSum).find('#vendorname').val(splitOrderData.vendorname);
				if(sessionStorage.getItem('orderMode') == 'new'){
					var timeSlot = splitOrderData.timeDate + ' ' + splitOrderData.timesend;
					$(currentCheckSum).find('.timeslot').html(timeSlot);
					$(currentCheckSum).find('.timeslot').attr({
						'data_starttime' : splitOrderData.timestart,
						'data_endtime' : splitOrderData.timesend,
						'data_date' : splitOrderData.timeDate,
						'data_trasactionid' : splitOrderData.timeslot
					});
				}
			}else{
				$(currentCheckSum).find('#vendorname').val('0');
			}
		});
	},1500);
}

function showcoupon(){
	$("#couponlistmodal").modal("show");
	var orderDate=todayDateforMDM();
	var orderlevel=[];
	var itemlevel=[];
	orderlevel.push({
		orderDate: orderDate,
		pop: sessionStorage.getItem('facility_id'),
		business: "2",
		source: "CCO",
		mrn: sessionStorage.getItem('mrn'),
		cartCoupon:"1"
	});
	$('#Custom_body input[name=drugsearch]').each(function() {
		if($.trim($(this).val())!=""){	
			if(isNaN(parseInt($(this).attr("id").match(/\d+/g),10))){	var num="";	}
			else{	var num = parseInt($(this).attr("id").match(/\d+/g),10);	}
			var codedata = ''+((typeof ($('#druglist'+num+' [value="'+$("#drugsearch"+num).val()+'"]').data('codedid')) == "undefined")?$('input[value="'+$("#drugsearch"+num).val()+'"]').data('codedid'):($('#druglist'+num+' [value="'+$("#drugsearch"+num).val()+'"]').data('codedid')));
			if((typeof codedata != "undefined") && codedata!="" && codedata!="0"){				
				itemlevel.push({
					orderDate: orderDate,
					pop: sessionStorage.getItem('facility_id'),
					business: "2",
					code: codedata,
					source: "CCO",
					mrn: sessionStorage.getItem('mrn')
				});
			}			
		}		
	});
	var _data = {orderlevel:orderlevel,itemlevel:itemlevel};
	_ajaxEventHandler("coupenlist_all",_data,coupenlist_all_fun,NO_SHOW_LOADER);
}

function coupenlist_all_fun(data){
	var obj =JSON.parse(data);
	var str='';
	var i=0;
	$.each(obj,function(key,val){		
		i = i + 1;
		var codes="";
		console.log(val.name);
		$.each(val.code,function(key,valco){
			if(codes!=""){
				codes+=",";
			}
			codes+=valco;
		});
		str+='<tr><td>'+val.name+'</td><td>'+val.description+'</td><td><button data-id="'+val.name+'" class="btn btn-success" data-code="'+codes+'" onclick="copycoupon('+i+');" id="couponlistbtn'+i+'">Apply</button></td></tr>';
	});	
	$("#couponlist").html(str);
}  

function removecoupen() {
	$("#l2vCoupanCode").val("");
	$("#l2vCoupanCode").attr("data-code","");
	showcoupenmmsg=2;
        var orderGlobalDetails = splitOrderGlobalDetails();
        newCheckpricefrommdm();
        updateSplitOrderDetails(orderGlobalDetails);
}

function itemcancel(itemCode,orderId){
    $('#itemCancelOrderId').val(orderId);
    $('#itemCancelItemCode').val(itemCode);
    $('#itemCancelModel').modal('show');
}

var itemCancelOrderId = '';
function itemCancelSubmit(){
    $('#itemCancelReason_error').hide();
    if($('#itemCancelReason').val() == ''){
        $('#itemCancelReason_error').show();
        return false;
    }
    $('#itemCancelModel').hide();
    itemCancelOrderId = $('#itemCancelOrderId').val();
    var _data = {
                "order_id": $('#itemCancelOrderId').val(),
                "item_code": $('#itemCancelItemCode').val(),
                "cancel_reason": $('#itemCancelReason').val(),
                "actionById": sessionStorage.getItem("loginid"),
                "actionByName": sessionStorage.getItem("loginname")
                };
	_ajaxEventHandler("orders/lineitem/cancel",_data,cbk_item_cancel,SHOW_LOADER);
}

function cbk_item_cancel(response){
    alert('Item Cancelled Successfully');
    $('#viewOrder').hide();
    vieworder(itemCancelOrderId);
}

function returnOrder(orderId){
    sessionStorage.setItem('orderMode', 'return');
    sessionStorage.setItem('orderid', orderId);
    var _data = {orderid: orderId};
    _ajaxEventHandler("getorderdetails", _data, editOrderHtml, SHOW_LOADER);
}

var deletePresId = '';
var deleteFrom = 'order';
function deletePres($this,$delete){
    deletePresId = $this;
    deleteFrom = $delete;
	var orderid = (sessionStorage.getItem('orderid')!=null)?sessionStorage.getItem('orderid'):"";
	if(orderid==""){
		var _data = {
			"url":$($this).attr('data-fullpath')
			
		};
	}else{
		var _data = {
			"order_id":sessionStorage.getItem('orderid'),
			"filename":$($this).attr('data-filename')
		};
	}
    _ajaxEventHandler("deletePrescription", _data, cbk_deletePresc, SHOW_LOADER);
}

function cbk_deletePresc(response){
    $(".loader").hide();
	console.log(typeof response);
	if(typeof response == 'string'){
            response = JSON.parse(response);
	}
        if(response.status == 0){
            alert(response.message);
            return;
        }
    
    $(".loader").hide();
    if(deleteFrom != 'view'){
         $(deletePresId).parent('div').remove();
    }else{
         $(deletePresId).parents('tr').remove();
         if($('#tblGrid').find('tr').length <= 1 ){
             $('#tblGrid').remove();
         }
         return;
    }
    var presSessId = $(deletePresId).attr('data-presid');
    prescSessData = sessionStorage.getItem(presSessId);
    var modifiedSessData = JSON.parse(prescSessData);
    prescSessData = JSON.parse(prescSessData);
    var delefileName = $(deletePresId).attr('data-filename');
    $.each(prescSessData,function(key,value){
        if(value['filename'] == delefileName){
            modifiedSessData.splice(key, 1);
        }
    });
    sessionStorage.setItem(presSessId,JSON.stringify(modifiedSessData));
    if($('.preImgages').length <= 0){
        $("#Modal_for_all").modal("hide");
        $('.'+presModule).find('#checkboxprescriptionsms').prop('checked',true);
        sessionStorage.removeItem(presSessId);
        $('.'+presModule).find('#vendorname').val('0');
        $('.'+presModule).find('#vendorname').attr('disabled',true);
    }
}

var doctorNameList = {};
function addDoctorName($id,$value){
    doctorNameList[$id] = $value;
    console.log(doctorNameList);
    console.log(typeof doctorNameList);
}

function getLatLong(address){
    var area = $('#route').val();
    address = area+' '+address;
    getAddressLatLong(address);
}

//check servisable pincode
function check_servisablepincode(){
	var pincodevalue=sessionStorage.getItem("zipcode");
	_data={};
	//alert(pincodevalue);
	_ajaxEventHandler("pincodeVerification?filter_codes="+pincodevalue, _data, cbk_check_servisablepincode, SHOW_LOADER, "GET", External_delivery);
}

function cbk_check_servisablepincode(response){
	$(".loader").hide();
	console.log(response);
	var serviceable=0;
	var pincodevalue=sessionStorage.getItem("zipcode");
	console.log(typeof response);
	if(typeof response == 'string'){
		response = JSON.parse(response);
	}
	if(response.status == 0){
		global_serviceable=0;
		alert(response.message);
		return;
	}else{
		$.each(response.data,function(key,val){		
			if(typeof val.postal_code != "undefined"){
				if(typeof val.postal_code.pin != "undefined"){
					if(val.postal_code.pin==pincodevalue){
						serviceable=1;
					}
				}
			}
		});
	}
	if(serviceable==1){
		global_serviceable=1;
		//alert("serviceable");
		if (!($.inArray(global_selecteddiag, selectedDrugsList) != -1)){
			selectedDrugsList.push(global_selecteddiag);
			newCheckpricefrommdm(global_selecteddiag);
			global_selecteddiag="";
		}
	}else{
		global_serviceable=0;
		alert("Sorry! This location is not serviceable.");
	}
}
   
 