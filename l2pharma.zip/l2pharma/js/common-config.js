//var RestServiceURL = sessionStorage.getItem('base_url')+"OMS1/api/medicine_supply.php/v1/";
var RestServiceURL = sessionStorage.getItem('base_url')+"OMS/api/";
var medicineSupplyUrl = 'medicine_supply.php/v1/';
var operationUrl = 'operation.php/v1/';
var orderUrl = 'order.php/v1/';
var External_delivery = 'external_delivery.php/v1/delhivery/';
var SHOW_LOADER = "1";
var NO_SHOW_LOADER = "0";

var placeSearch, autocomplete;
var componentForm = {
    route: 'long_name',
    locality: 'long_name',
    administrative_area_level_1: 'short_name',
    country: 'long_name',
    postal_code: 'short_name'
};

function initAutocomplete() {
    // Create the autocomplete object, restricting the search to geographical // location types.
    autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */
                    (document.getElementById('autocomplete')), {types: ['geocode']}
            );
    // When the user selects an address from the dropdown, populate the address   // fields in the form.
    autocomplete.addListener('place_changed', fillInAddress);
}

function fillInAddress() {
    var place = autocomplete.getPlace();
    for (var component in componentForm) {
        document.getElementById(component).value = '';
        document.getElementById(component).disabled = false;
    }
    for (var i = 0; i < place.address_components.length; i++) {
        $("#address1").val('');
        alert(place.address_components);
        var addressType = place.address_components[i].types[0];
        if (componentForm[addressType]) {
            var pincode = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = pincode;
            if (addressType == "postal_code")
            {
                var _data = {pincode: pincode};
                _ajaxEventHandler("Getpopnamefrompincode", _data, cbk_getpopnamefrompincode, SHOW_LOADER);
            }
        }
    }
    var latitude = place.geometry.location.lat();
    var longitude = place.geometry.location.lng();
    $("#longitude").val(longitude);
    $("#latitude").val(latitude);
}

function geolocate() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            var geolocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
                center: geolocation,
                radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
        });
    }
}

function getAddressLatLong(address) {
    var geocoder = new google.maps.Geocoder();
    geocoder.geocode({address: address}, function (results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
            var latitude = results[0].geometry.location.lat();
            var longitude = results[0].geometry.location.lng();
            $('#latitude').val(latitude);
            $('#longitude').val(longitude);
        }
    });
}

//common ajax call
function _ajaxEventHandler(_method,payload,responce,showLoader=1,methodtype="POST",route_file=medicineSupplyUrl){
	if(showLoader=='1')
	{$(".loader").show();}
	var url = RestServiceURL+route_file+_method;
	var result = $.ajax({
		url: url, 
		type: methodtype,
    	data: JSON.stringify(payload),
    	contentType: "application/json",
        success: responce,
		error:errormsg
    });
	return result;
}

function logout() {
    sessionStorage.clear();
    window.location = "logout.php";
}

function usersession() {
    if ($.trim(sessionStorage.getItem('loginid')) == "" && $.trim(sessionStorage.getItem('loginname')) == "") {
        logout();
    }
}
usersession();

function errormsg(error){
	console.log(error);
	//alert(error);
	$(".loader").hide();
}

//service type in an array
var servicetype = {
	"1" : "Consultation Order",
	"2" : "Drug Order",
	"3" : "Diagnostics Order",
	"4" : "Facilitation Order",
	"5" : "Care@Home Order",
	"30" : "Assessment Order"
};

var channel = {
	1:"CP",
	2:"CCO",
	3:"Android App",
	4:"Corporate Portal",
	5:"IOS App",
	6:"L2 Pharma",
	7:"Officer App"
};

var paymentModeName = {
	0:"COD",
	1:"Prepaid (payU)",
	2:"Prepaid (ICICI)",
	3:"Prepaid (Mobikwik)",
	4:"Prepaid (ccavenue)",
	5:"Prepaid (ITZCASH)",
	6:"Prepaid (paytm)",
	7:"Prepaid (AIRTEL)",
	8:"Prepaid (PaytmQR)"
};

var splitone = [1,2,3,5,6,7,10];
var splittwo = [11,12,13,4];

var madicinecat = {
	"" : "",
	"0" : "0",
	"1" : "Prescription - Brand",
	"2" : "OTC",
	"3" : "Personal Care",
	"4" : "Surgical",
	"5" : "Prescription - Speciality",
	"6" : "Baby Care",
	"7" : "Prescription - Generic"
};

function age_calculation(dob){
	dob = new Date(dob);
	var today = new Date();
	return Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
}

function setgender(valu){
	var valu= $.trim(valu);
	var setgender="";
	if(valu=="1" || valu=="F"){setgender="Female";}
	else if(valu=="2" || valu=="M"){setgender="Male";}
	else if(valu=="3"){setgender="Other";}
	else if(valu=="Female"){setgender="Female";}
	else if(valu=="Male"){setgender="Male";}
	else{setgender="Not Stated";}
	return setgender;
}

// Date time format
function todayDateforMDM() {
	var monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
	var d = new Date(),
	//month = '' + (d.getMonth() + 1),
	month = ''+monthNames[d.getMonth()],
	day = ''+d.getDate(),
	hour = ''+d.getHours(),
	minute = ''+d.getMinutes(),
	second = ''+d.getSeconds(),
	year = d.getFullYear();
	if (month.length < 2) month = '0' + month;
	if (day.length < 2) day = '0' + day;
	if (hour.length < 2) hour = '0' + hour;
	if (minute.length < 2) minute = '0' + minute;
	if (second.length < 2) second = '0' + second;
	return [day,month,year].join('-')+" "+[hour,minute,second].join(':');
}

function todayDatetime() {
	var d = new Date(),
	month = '' + (d.getMonth() + 1),
	day = '' + d.getDate(),
	year = d.getFullYear();
	hour = d.getHours();
	minute = d.getMinutes();
	if (month.length < 2) month = '0' + month;
	if (day.length < 2) day = '0' + day;
	if (hour.length < 2) hour = '0' + hour;
	if (minute.length < 2) minute = '0' + minute;
	return ([year, month, day].join('-')+" "+[hour, minute].join(':'));
}

function todayDate() {
	var d = new Date(),
	month = '' + (d.getMonth() + 1),
	day = '' + d.getDate(),
	year = d.getFullYear();
	hour = d.getHours();
	minute = d.getMinutes();
	if (month.length < 2) month = '0' + month;
	if (day.length < 2) day = '0' + day;
	if (hour.length < 2) hour = '0' + hour;
	if (minute.length < 2) minute = '0' + minute;
	return ([year, month, day].join('-'));
}

function tommorowDate() {
	var d = new Date(new Date().getTime() + 24 * 60 * 60 * 1000),
	month = '' + (d.getMonth() + 1),
	day = '' + d.getDate(),
	year = d.getFullYear();
	hour = d.getHours();
	minute = d.getMinutes();
	if (month.length < 2) month = '0' + month;
	if (day.length < 2) day = '0' + day;
	if (hour.length < 2) hour = '0' + hour;
	if (minute.length < 2) minute = '0' + minute;
	return ([year, month, day].join('-'));
}

function changedate(dt) {
    if (typeof dt != 'undefined') {
        return dt.replace('T', ' ').replace('.000Z', '');
    }else{
		return "-";
	}
}

function datetime24to12(date24){
	var date24 = date24.split(' ');
	var time = date24[1].slice(0, 8);
	var H = +time.substr(0, 2);
	var h = (H % 12) || 12;
	var ampm = H < 12 ? "AM" : "PM";
	time = h + time.substr(2, 3) + ampm;
	return time;
}



/*

var placeSearch, autocomplete;
var componentForm = {
  route: 'long_name',
  locality: 'long_name',
  administrative_area_level_1: 'short_name',
  country: 'long_name',
  postal_code: 'short_name' 
};
function initAutocomplete() {
	// Create the autocomplete object, restricting the search to geographical // location types.
	autocomplete = new google.maps.places.Autocomplete(
		/** @type {!HTMLInputElement} */
		/*(document.getElementById('autocomplete')),{types: ['geocode']}
	);
	// When the user selects an address from the dropdown, populate the address   // fields in the form.
	autocomplete.addListener('place_changed', fillInAddress);
}
function fillInAddress() {
	// Get the place details from the autocomplete object.
	var place = autocomplete.getPlace();
	for (var component in componentForm) {
		document.getElementById(component).value = '';
		document.getElementById(component).disabled = false;
	}
	// Get each component of the address from the place details
	// and fill the corresponding field on the form.
	for (var i = 0; i < place.address_components.length; i++) {
		$("#address1").val('');
	  //alert(place.address_components);
		var addressType = place.address_components[i].types[0];
		if (componentForm[addressType]) {
			var pincode = place.address_components[i][componentForm[addressType]];
			document.getElementById(addressType).value = pincode;
			if(addressType=="postal_code")
			{
				var _data={pincode:pincode};
				_ajaxEventHandler("Getpopnamefrompincode",_data,cbk_getpopnamefrompincode,SHOW_LOADER);
			}
		}
	}
	//document.getElementById("latlong1").value =(place.geometry.location.lat())+','+(place.geometry.location.lng());
	var latitude = place.geometry.location.lat();
	var longitude = place.geometry.location.lng();
	$("#longitude").val(longitude);
	$("#latitude").val(latitude);
}

function geolocate() {
	
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var geolocation = {
        lat: position.coords.latitude,
        lng: position.coords.longitude		
      };
	  
      var circle = new google.maps.Circle({
        center: geolocation,
        radius: position.coords.accuracy
      });
	  
      autocomplete.setBounds(circle.getBounds());
	  
    });
  }
}


*/

