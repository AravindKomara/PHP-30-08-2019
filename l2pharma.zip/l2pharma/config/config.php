<?php ob_start();session_start();
$base_url="http://172.26.7.111/";
$serverhostpath="http://172.26.7.111/";
$dialerpath="http://ccuat.callhealth.com/agent/l2_status_update.php";
$public_dialerpath="http://ccuat.callhealth.com/agent/l2_status_update.php";
$callback_url="http://172.26.7.111/cco/callrequest";
?>