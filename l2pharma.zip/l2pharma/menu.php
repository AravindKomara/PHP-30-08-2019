<section class="tabs_overlay" id="pharma_menu">
<div class='container-fluid'>
	<article class='medicine_details'>
		<div class='col-md-8 col-sm-8 col-xs-8'>
			<h1 style='font-size:20px;'>Medicine Orders</h1>
		</div>
		<div class='col-md-4 col-sm-4' style="text-align:right;">
			<input  type='hidden' id='exporttype' value='Ordersdata' name='type'>
			<!--a href='#' onclick='exportcsv()'  class='export_csv_btn pull-right'>Export CSV</a-->
			<button id="backbutton" onclick="allOrders('all_orders','allordersview',false,1,true);" class='btn btn-success' style="display:none; max-width:150px; float:right; margin-top:5px;">Back</button>
		</div>
	</article>
</div> 
</section>
<section class='patientBannerInfo' id='patientBannerInfo'></section>
<section class="pharma_widgets" id="pharma_widgets"></section>
<section class="Custom_Search" id="Custom_search"></section>
<section class="custom_body" id="Custom_body" style="display:block; margin-bottom: 72px;"></section>