<?php
include_once("config/config.php");
//if ($_COOKIE["_chz_id"] != null) {
if(true) {
 // print_r($_GET);exit;
  $sessionId = $_GET['sessionId'];
  $phone = "1234djhtf";
  if(isset($sessionId) && trim($sessionId)!==""){
     if(isset($phone) && trim($phone)!==""){
        if(preg_match("/^\d+$/", $phone)) {
            $response = validate_the_request($securl,$sessionId,$phone);//validating session
            if($response == "1") {
               header("location:dashboard.php");
            } else {
               $_SESSION['invalidmethod'] = "Invalid User";
                header("location:index.php");
        }
       } else {
          echo 'phone number should contain only numbers';
          exit;
       }      
  }else{
      echo 'phone number should not be empty';
      exit;
  }
  }else{
      echo 'sessionId should not be empty';
      exit;
  }

 } 

    function validate_the_request($securl,$sessionkey) { 
        $url = $securl . "/api/validateSessionKey";
        $header = array('x-session-key:' . $sessionkey);
        $result = common_curl_call($url, "", $header, "post");
        $result = json_decode($result);
        print_r($result);exit;
        $status = 0;
        if ($result->status == "1") {
            if (isset($result->officer->accessRoles)) {
                foreach ($result->officer->accessRoles as $role) {
                    if ($role == "l2pharma_viewer") {
                        $status = 1;
                    }
                }
            }
        }
        if ($status == 1) {
            $_SESSION['user_name'] = $result->agent_id;
            $_SESSION['user_id'] = $result->agent_name;
            if(isset($_GET['patient_mobile'])){
                $_SESSION['patient_mobile'] = $_GET['patient_mobile'];
                $_SESSION['type'] = "agent";
            }  
            return "1";
        } else {
            return "0";
        }
    }

    //common curl call
    function common_curl_call($url, $param, $header, $method) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        if ($param != "") {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
        }
        if ($method == "post") {
            curl_setopt($ch, CURLOPT_POST, true);
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        $resultcurl = curl_exec($ch);
        // print_r($resultcurl);exit;
        curl_close($ch);
        return $resultcurl;
    }

?>