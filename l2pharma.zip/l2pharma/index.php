﻿<?php
include_once("config/config.php");
//echo "<pre>";
//print_r($_GET);exit;
$sessionId = $_GET['crmSessionId'];
$phone = ($_GET['phone'])?$_GET['phone']:"";

// for test
$_SESSION['crmSessionId']="xyz";//temporary purpose
$_SESSION['l2_user_name']="test";//temporary purpose
$_SESSION['l2_user_id']="test";
$_SESSION['patient_mobile']=""; 
//$_SESSION['patient_mobile']="7780241401";
header("location:dashboard.php");

// end for test	 
if(isset($sessionId) && trim($phone) !== "") {
	if (preg_match("/^\d+$/", $phone)){
		$response = validate_the_request($securl,$sessionId, $phone); //validating session
		if ($response == "1") {			
			header("location:dashboard.php");
		} else {
			echo 'session key received but not validated';
			exit;
		}
	} else {
		echo 'phone number should contain only numbers';
		exit;
	}
}elseif (isset($sessionId) && trim($phone)==""){
    $response = validate_the_request($securl,$sessionId,""); //validating session
    if ($response == "1") { 
            header("location:dashboard.php");    
    } else {
           echo 'session key received but not validated';
           exit;      
    }
} else {
    echo 'sessionId should not be empty';
    exit;
}

function validate_the_request($securl,$sessionId,$phone) {
    $url = $securl . "/api/validateSessionKeyId";    
    $header = array('x-session-key-id:' . $sessionId);	
    $result = common_curl_call($url, "", $header, "post");
    $result = json_decode($result); 
    $status = 0;
    if ($result->status == "1") {
		if($result->roleId=="97"){
			$status = 1;
		}
    }
    if ($status == 1) {
        $_SESSION['crmSessionId']=$sessionId;//temporary purpose
        $_SESSION['l2_user_name']=$result->officer->fname;//temporary purpose
        $_SESSION['l2_user_id']=$_GET['userId'];
		$_SESSION['patient_mobile']=$phone;
        $_SESSION['type'] = "agent";
        if (trim($phone) !== "") {
            $_SESSION['patient_mobile'] = $phone;
        }
        return "1";
    } else {
        return "0";
    }
}

function common_curl_call($url, $param,$header,$method) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    if ($param != "") {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
    }
    if ($method == "post") {
        curl_setopt($ch, CURLOPT_POST, true);
    }
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    $resultcurl = curl_exec($ch);
    // print_r($resultcurl);exit;
    curl_close($ch);
    return $resultcurl;
}
?>