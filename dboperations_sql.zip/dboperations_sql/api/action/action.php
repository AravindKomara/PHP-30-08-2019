<?php

ini_set('memory_limit', '-1');
require 'dbo.php';

class Action {

    public function userRegistration($payload) {
        // print_r($payload);exit;
        $dboobj = new Dbo; //creating object for db operations file
        $apidata['uname'] = $payload->uname;
        $apidata['uemail'] = $payload->uemail;
        $apidata['upassword'] = $payload->upassword;
        $apidata['umobile'] = $payload->umobile;
        $res = $dboobj->insert("user_details", $apidata);
        if ($res == "inserted") {
            $response['status'] = 1;
            $response['message'] = "Data inserted successfully";
        }
        return $response;
    }

    public function userLogin($payload) {
        // print_r($payload);exit;
        $select = "*";
        $dboobj = new Dbo;
        $response = array();
        $where = array();
        $sort_columun = "created_on";
        if (empty($payload)) {
            // $select = "uname,uemail";
            $res = $dboobj->get("user_details", $select, $where, "result", $sort_columun, "DESC", 9999);
        } else {
            $where['uemail'] = $payload->uemail;
            $where['upassword'] = $payload->upassword;
            $res = $dboobj->get("user_details", $select, $where, "row", $sort_columun, "DESC", 9999);
        }

        // print_r($res);exit;
        if (count($res) > 0) {
            $response['status'] = 1;
            $response['message'] = "User Logged In Successfully";
            $response['data'] = $res;
        } else {
            $response['status'] = 0;
            $response['message'] = "User Login Failed";
            $response['data'] = $res;
        }
        return $response;
    }

    public function userUpdate($payload) {
        // print_r($payload);exit;
        $dboobj = new Dbo;
        $where['uid'] = (int) $payload->uid;
        $setdata['uname'] = $payload->uname;
        $setdata['uemail'] = $payload->uemail;
        $setdata['upassword'] = $payload->upassword;
        $setdata['umobile'] = $payload->umobile;

        $res = $dboobj->update("user_details", $where, $setdata);
        //print_r($res);exit;
        if ($res == 1) {
            $response['status'] = 1;
            $response['message'] = "Data updated successfully";
        }
        return $response;
    }

    public function userGetDetails($payload) {
        //print_r($payload->condition_type);exit;
        $response = array();
        $where = array();
        $select = "*";
        $dboobj = new Dbo;
        $sort_columun = "created_on";
        $condtion_type = "";
        if (!empty($payload->condition_type)) {
            $condtion_type = $payload->condition_type;
        }
        if (!empty($payload->uid)) {
            $where['uid'] = $payload->uid;
        }
        if (!empty($payload->uemail)) {
            $where['uemail'] = $payload->uemail;
        }
        if (count($where) > 1 && empty($condtion_type)) {
            $response['status'] = 0;
            $response['message'] = "More than one  where condtion is there, we have to specify the condition type ex: AND,OR";
            return $response;
        }
        $res = $dboobj->get($select, "user_details", $where, $condtion_type, $sort_columun, "DESC", 9999);
        // print_r($res); exit;
        if (count($res) > 0) {
            $response['status'] = 1;
            $response['message'] = "Data get successfully";
            $response['data'] = $res;
        } else {
            $response['status'] = 0;
            $response['message'] = "Data not found";
            $response['data'] = $res;
        }
        return $response;
    }

    public function userDelete($payload) {
        // print_r($payload);exit;
        $dboobj = new Dbo;
        $where['uid'] = (int) $payload->uid;
        $res = $dboobj->delete("user_details", $where);
        if ($res == "deleted") {
            $response['status'] = 1;
            $response['message'] = "Data deleted successfully";
        }else{
            $response['status'] = 0;
            $response['message'] = "Data deletion is failed";
        }
        return $response;
    }

    public function userLike($payload) {
        // print_r($payload);exit;
        $response = array();
        $select = "*";
        $dboobj = new Dbo;
        $sort_columun = "created_on";
        $where_columun = $payload->column_name;
        $like_type = $payload->like_type;
        $like_text = $payload->like_text;
        $like_end_text = isset($payload->like_end_text) ? $payload->like_end_text : "";
        if(empty($where_columun)) {
            $response['status'] = 0;
            $response['message'] = "please provide the cloumn name and it should not be empty";
            return $response;
        }
        $res = $dboobj->like($select, "user_details", $where_columun, $like_text, $like_end_text, $like_type, $sort_columun, "DESC", 9999);
      //print_r($res);exit;
        if (count($res) > 0) {
            $response['status'] = 1;
            $response['message'] = "Data get successfully";
            $response['data'] = $res;
        } else {
            $response['status'] = 0;
            $response['message'] = "Data not found";
            $response['data'] = $res;
        }
        return $response;
    }

    public function userJoin($payload) {
        //print_r($payload);exit;
        $response = array();
        $where = array();
        $select = "*";
        $dboobj = new Dbo;
        $sort_columun = "created_on";
        $fromTableName = $payload->from_table;
        $toTableName = $payload->to_table;
        $localField = $payload->local_field;
        $foreignField = $payload->foreign_field;
        $condtion_type = "";
        if (!empty($payload->condition_type)) {
            $condtion_type = $payload->condition_type;
        }
        if (!empty($payload->uid)) {
            $where[$fromTableName . "." . 'uid'] = $payload->uid;
        }
        if (!empty($payload->uemail)) {
            $where[$fromTableName . "." . 'uemail'] = $payload->uemail;
        }
        if (count($where) > 1 && empty($condtion_type)) {
            $response['status'] = 0;
            $response['message'] = "More than one  where condtion is there, we have to specify the condition type ex: AND,OR";
            return $response;
        }
        $select = $fromTableName . "." . "uname" . "," . $fromTableName . "." . "upincode" . "," . $toTableName . "." . "city" . "," . $toTableName . "." . "state" . " ";

        $res = $dboobj->join($select, $fromTableName, $toTableName, $localField, $foreignField, $where, $condtion_type, $sort_columun, "DESC", 9999);
        //print_r($res);exit;
        if (count($res) > 0) {
            $response['status'] = 1;
            $response['message'] = "Data get successfully";
            $response['countn'] = count($res);
            $response['data'] = $res;
        } else {
            $response['status'] = 0;
            $response['message'] = "Data not found";
            $response['countn'] = count($res);
            $response['data'] = $res;
        }
        return $response;
    }

}

?>
