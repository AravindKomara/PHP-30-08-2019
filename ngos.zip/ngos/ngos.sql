-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 12, 2018 at 06:57 AM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ngos`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `email` varchar(110) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `name`, `email`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', '698d51a19d8a121ce581499d7b701668');

-- --------------------------------------------------------

--
-- Table structure for table `auth_inter_types`
--

CREATE TABLE `auth_inter_types` (
  `id` int(11) NOT NULL,
  `auth_type` varchar(50) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_inter_types`
--

INSERT INTO `auth_inter_types` (`id`, `auth_type`, `added_on`) VALUES
(1, 'Desigination', '2018-07-14 07:59:19'),
(2, 'International Ngos Network', '2018-07-06 11:15:49'),
(3, 'International', '2018-07-06 11:15:49'),
(4, 'International and All India', '2018-07-11 12:54:22');

-- --------------------------------------------------------

--
-- Table structure for table `auth_national_types`
--

CREATE TABLE `auth_national_types` (
  `id` int(11) NOT NULL,
  `auth_type` varchar(50) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_national_types`
--

INSERT INTO `auth_national_types` (`id`, `auth_type`, `added_on`) VALUES
(1, 'Desigination', '2018-07-14 08:05:17'),
(2, 'All India', '2018-07-06 11:13:36'),
(3, 'South India', '2018-07-06 11:13:36'),
(4, 'North India', '2018-07-06 11:13:57'),
(5, 'East India', '2018-07-06 11:13:57'),
(6, 'West India', '2018-07-06 11:14:16');

-- --------------------------------------------------------

--
-- Table structure for table `auth_persons`
--

CREATE TABLE `auth_persons` (
  `auth_id` int(11) NOT NULL,
  `auth_name` varchar(60) CHARACTER SET utf8 DEFAULT ' ',
  `auth_jobtype` varchar(60) DEFAULT NULL,
  `auth_type` varchar(90) DEFAULT NULL,
  `auth_country` varchar(150) DEFAULT NULL,
  `auth_state` varchar(150) DEFAULT '',
  `auth_district` varchar(150) DEFAULT ' ',
  `auth_mobile` varchar(10) DEFAULT NULL,
  `auth_desgination` varchar(150) DEFAULT NULL,
  `auth_image` varchar(120) DEFAULT NULL,
  `auth_description` text,
  `auth_position` varchar(120) DEFAULT NULL,
  `display_order` int(11) DEFAULT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_persons`
--

INSERT INTO `auth_persons` (`auth_id`, `auth_name`, `auth_jobtype`, `auth_type`, `auth_country`, `auth_state`, `auth_district`, `auth_mobile`, `auth_desgination`, `auth_image`, `auth_description`, `auth_position`, `display_order`, `added_on`) VALUES
(1, 'A1', 'Authorisation Person', 'International', 'Angola', NULL, NULL, 'XXXXXXXXXX', 'International', 'uploads/admin/persons/db_error3.JPG', 'bhyt', '', NULL, '2018-09-17 12:11:53'),
(2, 'A3', 'Authorisation Person', 'International', 'Bangladesh', NULL, NULL, 'XXXXXXXXXX', 'International Ngos Network', 'uploads/admin/persons/db_error4.JPG', 'rty', '', NULL, '2018-09-17 12:16:35'),
(3, 'A3', 'Authorisation Person', 'International', 'Algeria', NULL, NULL, 'XXXXXXXXXX', 'International Ngos Network', 'uploads/admin/persons/db_error5.JPG', 'frrth', '', NULL, '2018-09-17 12:17:29'),
(4, 'A1', 'Authorisation Person', 'International', 'Antarctica', NULL, NULL, 'XXXXXXXXXX', 'International Ngos Network', 'uploads/admin/persons/db_error6.JPG', 'wfet', '', NULL, '2018-09-17 12:23:25');

-- --------------------------------------------------------

--
-- Table structure for table `auth_person_types`
--

CREATE TABLE `auth_person_types` (
  `id` int(11) NOT NULL,
  `auth_type` varchar(50) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_person_types`
--

INSERT INTO `auth_person_types` (`id`, `auth_type`, `added_on`) VALUES
(1, 'Desigination', '2018-07-14 08:06:31'),
(9, 'verification', '2018-07-23 09:38:16'),
(10, 'meetings', '2018-07-23 09:38:17'),
(11, 'settings', '2018-07-23 10:16:58'),
(12, 'rgrget', '2018-07-23 10:17:25'),
(13, 'fewgre', '2018-07-23 10:17:56');

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `bn_id` int(11) NOT NULL,
  `bn_text` text NOT NULL,
  `bn_type` varchar(20) NOT NULL,
  `bn_country` varchar(50) DEFAULT NULL,
  `bn_state` varchar(50) DEFAULT NULL,
  `bn_district` varchar(50) DEFAULT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`bn_id`, `bn_text`, `bn_type`, `bn_country`, `bn_state`, `bn_district`, `added_on`) VALUES
(1, 'Home Bannerr', 'Home', NULL, NULL, NULL, '2018-07-19 07:28:51'),
(2, 'International Bannerr', 'International', NULL, NULL, NULL, '2018-07-19 07:29:16'),
(3, 'National Bannerr', 'National', NULL, NULL, NULL, '2018-07-19 07:32:33'),
(4, 'State Bannerr', 'State', NULL, NULL, NULL, '2018-07-19 07:32:50'),
(5, 'District Bannerr', 'District', NULL, NULL, NULL, '2018-07-19 07:33:06'),
(6, 'India Banner', 'International', 'India', NULL, NULL, '2018-07-19 07:47:16'),
(7, 'Andhra Pradesh Banner', 'State', NULL, 'Andhra Pradesh ', NULL, '2018-07-19 07:50:00'),
(8, 'Guntur Banner', 'District', NULL, NULL, 'Guntur', '2018-07-19 07:50:34'),
(9, 'Austraila Baner', 'International', 'Australia', NULL, NULL, '2018-07-20 04:53:44'),
(10, 'Assaam Banner', 'State', NULL, 'Assam ', NULL, '2018-07-20 04:54:01'),
(11, 'Legality Bannerr', 'Legality', NULL, NULL, NULL, '2018-07-23 09:52:13'),
(12, 'Gallery Bannerr', 'Gallery', NULL, NULL, NULL, '2018-07-23 09:52:32'),
(13, 'Emailservice Bannerr', 'Emailservice', NULL, NULL, NULL, '2018-07-23 09:52:58'),
(14, 'Offer Bannerr', 'Offers', NULL, NULL, NULL, '2018-07-23 10:03:05');

-- --------------------------------------------------------

--
-- Table structure for table `brouchers`
--

CREATE TABLE `brouchers` (
  `br_id` int(11) NOT NULL,
  `type` varchar(30) NOT NULL,
  `br_document` varchar(225) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `cid` int(11) NOT NULL,
  `sortname` varchar(3) NOT NULL,
  `cname` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`cid`, `sortname`, `cname`) VALUES
(1, 'AF', 'Afghanistan'),
(2, 'AL', 'Albania'),
(3, 'DZ', 'Algeria'),
(4, 'AS', 'American Samoa'),
(5, 'AD', 'Andorra'),
(6, 'AO', 'Angola'),
(7, 'AI', 'Anguilla'),
(8, 'AQ', 'Antarctica'),
(9, 'AG', 'Antigua And Barbuda'),
(10, 'AR', 'Argentina'),
(11, 'AM', 'Armenia'),
(12, 'AW', 'Aruba'),
(13, 'AU', 'Australia'),
(14, 'AT', 'Austria'),
(15, 'AZ', 'Azerbaijan'),
(16, 'BS', 'Bahamas The'),
(17, 'BH', 'Bahrain'),
(18, 'BD', 'Bangladesh'),
(19, 'BB', 'Barbados'),
(20, 'BY', 'Belarus'),
(21, 'BE', 'Belgium'),
(22, 'BZ', 'Belize'),
(23, 'BJ', 'Benin'),
(24, 'BM', 'Bermuda'),
(25, 'BT', 'Bhutan'),
(26, 'BO', 'Bolivia'),
(27, 'BA', 'Bosnia and Herzegovina'),
(28, 'BW', 'Botswana'),
(29, 'BV', 'Bouvet Island'),
(30, 'BR', 'Brazil'),
(31, 'IO', 'British Indian Ocean Territory'),
(32, 'BN', 'Brunei'),
(33, 'BG', 'Bulgaria'),
(34, 'BF', 'Burkina Faso'),
(35, 'BI', 'Burundi'),
(36, 'KH', 'Cambodia'),
(37, 'CM', 'Cameroon'),
(38, 'CA', 'Canada'),
(39, 'CV', 'Cape Verde'),
(40, 'KY', 'Cayman Islands'),
(41, 'CF', 'Central African Republic'),
(42, 'TD', 'Chad'),
(43, 'CL', 'Chile'),
(44, 'CN', 'China'),
(45, 'CX', 'Christmas Island'),
(46, 'CC', 'Cocos (Keeling) Islands'),
(47, 'CO', 'Colombia'),
(48, 'KM', 'Comoros'),
(49, 'CG', 'Congo'),
(50, 'CD', 'Congo The Democratic Republic Of The'),
(51, 'CK', 'Cook Islands'),
(52, 'CR', 'Costa Rica'),
(53, 'CI', 'Cote D\'Ivoire (Ivory Coast)'),
(54, 'HR', 'Croatia (Hrvatska)'),
(55, 'CU', 'Cuba'),
(56, 'CY', 'Cyprus'),
(57, 'CZ', 'Czech Republic'),
(58, 'DK', 'Denmark'),
(59, 'DJ', 'Djibouti'),
(60, 'DM', 'Dominica'),
(61, 'DO', 'Dominican Republic'),
(62, 'TP', 'East Timor'),
(63, 'EC', 'Ecuador'),
(64, 'EG', 'Egypt'),
(65, 'SV', 'El Salvador'),
(66, 'GQ', 'Equatorial Guinea'),
(67, 'ER', 'Eritrea'),
(68, 'EE', 'Estonia'),
(69, 'ET', 'Ethiopia'),
(70, 'XA', 'External Territories of Australia'),
(71, 'FK', 'Falkland Islands'),
(72, 'FO', 'Faroe Islands'),
(73, 'FJ', 'Fiji Islands'),
(74, 'FI', 'Finland'),
(75, 'FR', 'France'),
(76, 'GF', 'French Guiana'),
(77, 'PF', 'French Polynesia'),
(78, 'TF', 'French Southern Territories'),
(79, 'GA', 'Gabon'),
(80, 'GM', 'Gambia The'),
(81, 'GE', 'Georgia'),
(82, 'DE', 'Germany'),
(83, 'GH', 'Ghana'),
(84, 'GI', 'Gibraltar'),
(85, 'GR', 'Greece'),
(86, 'GL', 'Greenland'),
(87, 'GD', 'Grenada'),
(88, 'GP', 'Guadeloupe'),
(89, 'GU', 'Guam'),
(90, 'GT', 'Guatemala'),
(91, 'XU', 'Guernsey and Alderney'),
(92, 'GN', 'Guinea'),
(93, 'GW', 'Guinea-Bissau'),
(94, 'GY', 'Guyana'),
(95, 'HT', 'Haiti'),
(96, 'HM', 'Heard and McDonald Islands'),
(97, 'HN', 'Honduras'),
(98, 'HK', 'Hong Kong S.A.R.'),
(99, 'HU', 'Hungary'),
(100, 'IS', 'Iceland'),
(101, 'IN', 'India'),
(102, 'ID', 'Indonesia'),
(103, 'IR', 'Iran'),
(104, 'IQ', 'Iraq'),
(105, 'IE', 'Ireland'),
(106, 'IL', 'Israel'),
(107, 'IT', 'Italy'),
(108, 'JM', 'Jamaica'),
(109, 'JP', 'Japan'),
(110, 'XJ', 'Jersey'),
(111, 'JO', 'Jordan'),
(112, 'KZ', 'Kazakhstan'),
(113, 'KE', 'Kenya'),
(114, 'KI', 'Kiribati'),
(115, 'KP', 'Korea North'),
(116, 'KR', 'Korea South'),
(117, 'KW', 'Kuwait'),
(118, 'KG', 'Kyrgyzstan'),
(119, 'LA', 'Laos'),
(120, 'LV', 'Latvia'),
(121, 'LB', 'Lebanon'),
(122, 'LS', 'Lesotho'),
(123, 'LR', 'Liberia'),
(124, 'LY', 'Libya'),
(125, 'LI', 'Liechtenstein'),
(126, 'LT', 'Lithuania'),
(127, 'LU', 'Luxembourg'),
(128, 'MO', 'Macau S.A.R.'),
(129, 'MK', 'Macedonia'),
(130, 'MG', 'Madagascar'),
(131, 'MW', 'Malawi'),
(132, 'MY', 'Malaysia'),
(133, 'MV', 'Maldives'),
(134, 'ML', 'Mali'),
(135, 'MT', 'Malta'),
(136, 'XM', 'Man (Isle of)'),
(137, 'MH', 'Marshall Islands'),
(138, 'MQ', 'Martinique'),
(139, 'MR', 'Mauritania'),
(140, 'MU', 'Mauritius'),
(141, 'YT', 'Mayotte'),
(142, 'MX', 'Mexico'),
(143, 'FM', 'Micronesia'),
(144, 'MD', 'Moldova'),
(145, 'MC', 'Monaco'),
(146, 'MN', 'Mongolia'),
(147, 'MS', 'Montserrat'),
(148, 'MA', 'Morocco'),
(149, 'MZ', 'Mozambique'),
(150, 'MM', 'Myanmar'),
(151, 'NA', 'Namibia'),
(152, 'NR', 'Nauru'),
(153, 'NP', 'Nepal'),
(154, 'AN', 'Netherlands Antilles'),
(155, 'NL', 'Netherlands The'),
(156, 'NC', 'New Caledonia'),
(157, 'NZ', 'New Zealand'),
(158, 'NI', 'Nicaragua'),
(159, 'NE', 'Niger'),
(160, 'NG', 'Nigeria'),
(161, 'NU', 'Niue'),
(162, 'NF', 'Norfolk Island'),
(163, 'MP', 'Northern Mariana Islands'),
(164, 'NO', 'Norway'),
(165, 'OM', 'Oman'),
(166, 'PK', 'Pakistan'),
(167, 'PW', 'Palau'),
(168, 'PS', 'Palestinian Territory Occupied'),
(169, 'PA', 'Panama'),
(170, 'PG', 'Papua new Guinea'),
(171, 'PY', 'Paraguay'),
(172, 'PE', 'Peru'),
(173, 'PH', 'Philippines'),
(174, 'PN', 'Pitcairn Island'),
(175, 'PL', 'Poland'),
(176, 'PT', 'Portugal'),
(177, 'PR', 'Puerto Rico'),
(178, 'QA', 'Qatar'),
(179, 'RE', 'Reunion'),
(180, 'RO', 'Romania'),
(181, 'RU', 'Russia'),
(182, 'RW', 'Rwanda'),
(183, 'SH', 'Saint Helena'),
(184, 'KN', 'Saint Kitts And Nevis'),
(185, 'LC', 'Saint Lucia'),
(186, 'PM', 'Saint Pierre and Miquelon'),
(187, 'VC', 'Saint Vincent And The Grenadines'),
(188, 'WS', 'Samoa'),
(189, 'SM', 'San Marino'),
(190, 'ST', 'Sao Tome and Principe'),
(191, 'SA', 'Saudi Arabia'),
(192, 'SN', 'Senegal'),
(193, 'RS', 'Serbia'),
(194, 'SC', 'Seychelles'),
(195, 'SL', 'Sierra Leone'),
(196, 'SG', 'Singapore'),
(197, 'SK', 'Slovakia'),
(198, 'SI', 'Slovenia'),
(199, 'XG', 'Smaller Territories of the UK'),
(200, 'SB', 'Solomon Islands'),
(201, 'SO', 'Somalia'),
(202, 'ZA', 'South Africa'),
(203, 'GS', 'South Georgia'),
(204, 'SS', 'South Sudan'),
(205, 'ES', 'Spain'),
(206, 'LK', 'Sri Lanka'),
(207, 'SD', 'Sudan'),
(208, 'SR', 'Suriname'),
(209, 'SJ', 'Svalbard And Jan Mayen Islands'),
(210, 'SZ', 'Swaziland'),
(211, 'SE', 'Sweden'),
(212, 'CH', 'Switzerland'),
(213, 'SY', 'Syria'),
(214, 'TW', 'Taiwan'),
(215, 'TJ', 'Tajikistan'),
(216, 'TZ', 'Tanzania'),
(217, 'TH', 'Thailand'),
(218, 'TG', 'Togo'),
(219, 'TK', 'Tokelau'),
(220, 'TO', 'Tonga'),
(221, 'TT', 'Trinidad And Tobago'),
(222, 'TN', 'Tunisia'),
(223, 'TR', 'Turkey'),
(224, 'TM', 'Turkmenistan'),
(225, 'TC', 'Turks And Caicos Islands'),
(226, 'TV', 'Tuvalu'),
(227, 'UG', 'Uganda'),
(228, 'UA', 'Ukraine'),
(229, 'AE', 'United Arab Emirates'),
(230, 'GB', 'United Kingdom'),
(231, 'US', 'United States'),
(232, 'UM', 'United States Minor Outlying Islands'),
(233, 'UY', 'Uruguay'),
(234, 'UZ', 'Uzbekistan'),
(235, 'VU', 'Vanuatu'),
(236, 'VA', 'Vatican City State (Holy See)'),
(237, 'VE', 'Venezuela'),
(238, 'VN', 'Vietnam'),
(239, 'VG', 'Virgin Islands (British)'),
(240, 'VI', 'Virgin Islands (US)'),
(241, 'WF', 'Wallis And Futuna Islands'),
(242, 'EH', 'Western Sahara'),
(243, 'YE', 'Yemen'),
(244, 'YU', 'Yugoslavia'),
(245, 'ZM', 'Zambia'),
(246, 'ZW', 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` int(8) NOT NULL DEFAULT '0',
  `state_id` int(8) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `state_id`, `name`) VALUES
(1, 1, 'North Andaman'),
(2, 1, 'South Andaman'),
(3, 1, 'Nicobar'),
(5, 2, 'Anantapur'),
(6, 2, 'Chittoor'),
(7, 2, 'East Godavari'),
(8, 2, 'Guntur'),
(11, 2, 'Kadapa'),
(12, 2, 'Krishna'),
(13, 2, 'Kurnool'),
(18, 2, 'Prakasam'),
(20, 2, 'Srikakulam'),
(21, 2, 'Sri Potti Sri Ramulu Nellore'),
(22, 2, 'Vishakhapatnam'),
(23, 2, 'Vizianagaram'),
(25, 2, 'West Godavari'),
(27, 3, 'Anjaw'),
(28, 3, 'Changlang'),
(29, 3, 'East Siang'),
(30, 3, 'East Kameng'),
(31, 3, 'Kurung Kumey'),
(32, 3, 'Lohit'),
(33, 3, 'Lower Dibang Valley'),
(34, 3, 'Lower Subansiri'),
(35, 3, 'Papum Pare'),
(36, 3, 'Tawang'),
(37, 3, 'Tirap'),
(38, 3, 'Dibang Valley'),
(39, 3, 'Upper Siang'),
(40, 3, 'Upper Subansiri'),
(41, 3, 'West Kameng'),
(42, 3, 'West Siang'),
(43, 4, 'Baksa'),
(44, 4, 'Barpeta'),
(45, 4, 'Bongaigaon'),
(46, 4, 'Cachar'),
(47, 4, 'Chirang'),
(48, 4, 'Darrang'),
(49, 4, 'Dhemaji'),
(50, 4, 'Dima Hasao'),
(51, 4, 'Dhubri'),
(52, 4, 'Dibrugarh'),
(53, 4, 'Goalpara'),
(54, 4, 'Golaghat'),
(55, 4, 'Hailakandi'),
(56, 4, 'Jorhat'),
(57, 4, 'Kamrup'),
(58, 4, 'Kamrup Metropolitan'),
(59, 4, 'Karbi Anglong'),
(60, 4, 'Karimganj'),
(61, 4, 'Kokrajhar'),
(62, 4, 'Lakhimpur'),
(63, 4, 'Morigaon'),
(64, 4, 'Nagaon'),
(65, 4, 'Nalbari'),
(66, 4, 'Sivasagar'),
(67, 4, 'Sonitpur'),
(68, 4, 'Tinsukia'),
(69, 4, 'Udalguri'),
(70, 5, 'Araria'),
(71, 5, 'Arwal'),
(72, 5, 'Aurangabad'),
(73, 5, 'Banka'),
(74, 5, 'Begusarai'),
(75, 5, 'Bhagalpur'),
(76, 5, 'Bhojpur'),
(77, 5, 'Buxar'),
(78, 5, 'Darbhanga'),
(79, 5, 'East Champaran'),
(80, 5, 'Gaya'),
(81, 5, 'Gopalganj'),
(82, 5, 'Jamui'),
(83, 5, 'Jehanabad'),
(84, 5, 'Kaimur'),
(85, 5, 'Katihar'),
(86, 5, 'Khagaria'),
(87, 5, 'Kishanganj'),
(88, 5, 'Lakhisarai'),
(89, 5, 'Madhepura'),
(90, 5, 'Madhubani'),
(91, 5, 'Munger'),
(92, 5, 'Muzaffarpur'),
(93, 5, 'Nalanda'),
(94, 5, 'Nawada'),
(95, 5, 'Patna'),
(96, 5, 'Purnia'),
(97, 5, 'Rohtas'),
(98, 5, 'Saharsa'),
(99, 5, 'Samastipur'),
(100, 5, 'Saran'),
(101, 5, 'Sheikhpura'),
(102, 5, 'Sheohar'),
(103, 5, 'Sitamarhi'),
(104, 5, 'Siwan'),
(105, 5, 'Supaul'),
(106, 6, 'Chandigarh'),
(107, 7, 'Bastar'),
(108, 7, 'Bijapur'),
(109, 7, 'Bilaspur'),
(110, 7, 'Dantewada'),
(111, 7, 'Dhamtari'),
(112, 7, 'Durg'),
(113, 7, 'Jashpur'),
(114, 7, 'Janjgir-Champa'),
(115, 7, 'Korba'),
(116, 7, 'Koriya'),
(117, 7, 'Kanker'),
(118, 7, 'Kabirdham (formerly Kawardha)'),
(119, 7, 'Mahasamund'),
(120, 7, 'Narayanpur'),
(121, 7, 'Raigarh'),
(122, 7, 'Rajnandgaon'),
(123, 7, 'Raipur'),
(124, 7, 'Surguja'),
(125, 8, 'Dadra and Nagar Haveli'),
(126, 9, 'Daman'),
(127, 9, 'Diu'),
(128, 10, 'Central Delhi'),
(129, 10, 'East Delhi'),
(130, 10, 'New Delhi'),
(131, 10, 'North Delhi'),
(132, 10, 'North East Delhi'),
(133, 10, 'North West Delhi'),
(134, 10, 'South Delhi'),
(135, 10, 'South West Delhi'),
(136, 10, 'West Delhi'),
(137, 11, 'North Goa'),
(138, 11, 'South Goa'),
(139, 12, 'Ahmedabad'),
(140, 12, 'Amreli district'),
(141, 12, 'Anand'),
(142, 12, 'Banaskantha'),
(143, 12, 'Bharuch'),
(144, 12, 'Bhavnagar'),
(145, 12, 'Dahod'),
(146, 12, 'The Dangs'),
(147, 12, 'Gandhinagar'),
(148, 12, 'Jamnagar'),
(149, 12, 'Junagadh'),
(150, 12, 'Kutch'),
(151, 12, 'Kheda'),
(152, 12, 'Mehsana'),
(153, 12, 'Narmada'),
(154, 12, 'Navsari'),
(155, 12, 'Patan'),
(156, 12, 'Panchmahal'),
(157, 12, 'Porbandar'),
(158, 12, 'Rajkot'),
(159, 12, 'Sabarkantha'),
(160, 12, 'Surendranagar'),
(161, 12, 'Surat'),
(162, 12, 'Tapi'),
(163, 12, 'Vadodara'),
(164, 12, 'Valsad'),
(165, 13, 'Ambala'),
(166, 13, 'Bhiwani'),
(167, 13, 'Faridabad'),
(168, 13, 'Fatehabad'),
(169, 13, 'Gurgaon'),
(170, 13, 'Hissar'),
(171, 13, 'Jhajjar'),
(172, 13, 'Jind'),
(173, 13, 'Karnal'),
(174, 13, 'Kaithal'),
(175, 13, 'Kurukshetra'),
(176, 13, 'Mahendragarh'),
(177, 13, 'Mewat'),
(178, 13, 'Palwal'),
(179, 13, 'Panchkula'),
(180, 13, 'Panipat'),
(181, 13, 'Rewari'),
(182, 13, 'Rohtak'),
(183, 13, 'Sirsa'),
(184, 13, 'Sonipat'),
(185, 13, 'Yamuna Nagar'),
(186, 14, 'Bilaspur'),
(187, 14, 'Chamba'),
(188, 14, 'Hamirpur'),
(189, 14, 'Kangra'),
(190, 14, 'Kinnaur'),
(191, 14, 'Kullu'),
(192, 14, 'Lahaul and Spiti'),
(193, 14, 'Mandi'),
(194, 14, 'Shimla'),
(195, 14, 'Sirmaur'),
(196, 14, 'Solan'),
(197, 14, 'Una'),
(198, 15, 'Anantnag'),
(199, 15, 'Badgam'),
(200, 15, 'Bandipora'),
(201, 15, 'Baramulla'),
(202, 15, 'Doda'),
(203, 15, 'Ganderbal'),
(204, 15, 'Jammu'),
(205, 15, 'Kargil'),
(206, 15, 'Kathua'),
(207, 15, 'Kishtwar'),
(208, 15, 'Kupwara'),
(209, 15, 'Kulgam'),
(210, 15, 'Leh'),
(211, 15, 'Poonch'),
(212, 15, 'Pulwama'),
(213, 15, 'Rajouri'),
(214, 15, 'Ramban'),
(215, 15, 'Reasi'),
(216, 15, 'Samba'),
(217, 15, 'Shopian'),
(218, 15, 'Srinagar'),
(219, 15, 'Udhampur'),
(220, 16, 'Bokaro'),
(221, 16, 'Chatra'),
(222, 16, 'Deoghar'),
(223, 16, 'Dhanbad'),
(224, 16, 'Dumka'),
(225, 16, 'East Singhbhum'),
(226, 16, 'Garhwa'),
(227, 16, 'Giridih'),
(228, 16, 'Godda'),
(229, 16, 'Gumla'),
(230, 16, 'Hazaribag'),
(231, 16, 'Jamtara'),
(232, 16, 'Khunti'),
(233, 16, 'Koderma'),
(234, 16, 'Latehar'),
(235, 16, 'Lohardaga'),
(236, 16, 'Pakur'),
(237, 16, 'Palamu'),
(238, 16, 'Ramgarh'),
(239, 16, 'Ranchi'),
(240, 16, 'Sahibganj'),
(241, 16, 'Seraikela Kharsawan'),
(242, 16, 'Simdega'),
(243, 16, 'West Singhbhum'),
(244, 17, 'Bagalkot'),
(245, 17, 'Bangalore Rural'),
(246, 17, 'Bangalore Urban'),
(247, 17, 'Belgaum'),
(248, 17, 'Bellary'),
(249, 17, 'Bidar'),
(250, 17, 'Bijapur'),
(251, 17, 'Chamarajnagar'),
(252, 17, 'Chikkamagaluru'),
(253, 17, 'Chikkaballapur'),
(254, 17, 'Chitradurga'),
(255, 17, 'Davanagere'),
(256, 17, 'Dharwad'),
(257, 17, 'Dakshina Kannada'),
(258, 17, 'Gadag'),
(259, 17, 'Gulbarga'),
(260, 17, 'Hassan'),
(261, 17, 'Haveri district'),
(262, 17, 'Kodagu'),
(263, 17, 'Kolar'),
(264, 17, 'Koppal'),
(265, 17, 'Mandya'),
(266, 17, 'Mysore'),
(267, 17, 'Raichur'),
(268, 17, 'Shimoga'),
(269, 17, 'Tumkur'),
(270, 17, 'Udupi'),
(271, 17, 'Uttara Kannada'),
(272, 17, 'Ramanagara'),
(273, 17, 'Yadgir'),
(274, 18, 'Alappuzha'),
(275, 18, 'Ernakulam'),
(276, 18, 'Idukki'),
(277, 18, 'Kannur'),
(278, 18, 'Kasaragod'),
(279, 18, 'Kollam'),
(280, 18, 'Kottayam'),
(281, 18, 'Kozhikode'),
(282, 18, 'Malappuram'),
(283, 18, 'Palakkad'),
(284, 18, 'Pathanamthitta'),
(285, 18, 'Thrissur'),
(286, 18, 'Thiruvananthapuram'),
(287, 18, 'Wayanad'),
(288, 19, 'Lakshadweep'),
(289, 20, 'Agar'),
(290, 20, 'Alirajpur'),
(291, 20, 'Anuppur'),
(292, 20, 'Ashok Nagar'),
(293, 20, 'Balaghat'),
(294, 20, 'Barwani'),
(295, 20, 'Betul'),
(296, 20, 'Bhind'),
(297, 20, 'Bhopal'),
(298, 20, 'Burhanpur'),
(299, 20, 'Chhatarpur'),
(300, 20, 'Chhindwara'),
(301, 20, 'Damoh'),
(302, 20, 'Datia'),
(303, 20, 'Dewas'),
(304, 20, 'Dhar'),
(305, 20, 'Dindori'),
(306, 20, 'Guna'),
(307, 20, 'Gwalior'),
(308, 20, 'Harda'),
(309, 20, 'Hoshangabad'),
(310, 20, 'Indore'),
(311, 20, 'Jabalpur'),
(312, 20, 'Jhabua'),
(313, 20, 'Katni'),
(314, 20, 'Khandwa (East Nimar)'),
(315, 20, 'Khargone (West Nimar)'),
(316, 20, 'Mandla'),
(317, 20, 'Mandsaur'),
(318, 20, 'Morena'),
(319, 20, 'Narsinghpur'),
(320, 20, 'Neemuch'),
(321, 20, 'Panna'),
(322, 20, 'Raisen'),
(323, 20, 'Rajgarh'),
(324, 20, 'Ratlam'),
(325, 20, 'Rewa'),
(326, 20, 'Sagar'),
(327, 20, 'Satna'),
(328, 20, 'Sehore'),
(329, 20, 'Seoni'),
(330, 20, 'Shahdol'),
(331, 20, 'Shajapur'),
(332, 20, 'Sheopur'),
(333, 20, 'Shivpuri'),
(334, 20, 'Sidhi'),
(335, 20, 'Singrauli'),
(336, 20, 'Tikamgarh'),
(337, 20, 'Ujjain'),
(338, 20, 'Umaria'),
(339, 20, 'Vidisha'),
(340, 21, 'Ahmednagar'),
(341, 21, 'Akola'),
(342, 21, 'Amravati'),
(343, 21, 'Aurangabad'),
(344, 21, 'Beed'),
(345, 21, 'Bhandara'),
(346, 21, 'Buldhana'),
(347, 21, 'Chandrapur'),
(348, 21, 'Dhule'),
(349, 21, 'Gadchiroli'),
(350, 21, 'Gondia'),
(351, 21, 'Hingoli'),
(352, 21, 'Jalgaon'),
(353, 21, 'Jalna'),
(354, 21, 'Kolhapur'),
(355, 21, 'Latur'),
(356, 21, 'Mumbai City'),
(357, 21, 'Mumbai suburban'),
(358, 21, 'Nanded'),
(359, 21, 'Nandurbar'),
(360, 21, 'Nagpur'),
(361, 21, 'Nashik'),
(362, 21, 'Osmanabad'),
(363, 21, 'Parbhani'),
(364, 21, 'Pune'),
(365, 21, 'Raigad'),
(366, 21, 'Ratnagiri'),
(367, 21, 'Sangli'),
(368, 21, 'Satara'),
(369, 21, 'Sindhudurg'),
(370, 21, 'Solapur'),
(371, 21, 'Thane'),
(372, 21, 'Wardha'),
(373, 21, 'Washim'),
(374, 21, 'Yavatmal'),
(375, 22, 'Bishnupur'),
(376, 22, 'Churachandpur'),
(377, 22, 'Chandel'),
(378, 22, 'Imphal East'),
(379, 22, 'Senapati'),
(380, 22, 'Tamenglong'),
(381, 22, 'Thoubal'),
(382, 22, 'Ukhrul'),
(383, 22, 'Imphal West'),
(384, 23, 'East Garo Hills'),
(385, 23, 'East Khasi Hills'),
(386, 23, 'Jaintia Hills'),
(387, 23, 'Ri Bhoi'),
(388, 23, 'South Garo Hills'),
(389, 23, 'West Garo Hills'),
(390, 23, 'West Khasi Hills'),
(391, 24, 'Aizawl'),
(392, 24, 'Champhai'),
(393, 24, 'Kolasib'),
(394, 24, 'Lawngtlai'),
(395, 24, 'Lunglei'),
(396, 24, 'Mamit'),
(397, 24, 'Saiha'),
(398, 24, 'Serchhip'),
(399, 25, 'Dimapur'),
(400, 25, 'Kiphire'),
(401, 25, 'Kohima'),
(402, 25, 'Longleng'),
(403, 25, 'Mokokchung'),
(404, 25, 'Mon'),
(405, 25, 'Peren'),
(406, 25, 'Phek'),
(407, 25, 'Tuensang'),
(408, 25, 'Wokha'),
(409, 25, 'Zunheboto'),
(410, 26, 'Angul'),
(411, 26, 'Boudh (Bauda)'),
(412, 26, 'Bhadrak'),
(413, 26, 'Balangir'),
(414, 26, 'Bargarh (Baragarh)'),
(415, 26, 'Balasore'),
(416, 26, 'Cuttack'),
(417, 26, 'Debagarh (Deogarh)'),
(418, 26, 'Dhenkanal'),
(419, 26, 'Ganjam'),
(420, 26, 'Gajapati'),
(421, 26, 'Jharsuguda'),
(422, 26, 'Jajpur'),
(423, 26, 'Jagatsinghpur'),
(424, 26, 'Khordha'),
(425, 26, 'Kendujhar (Keonjhar)'),
(426, 26, 'Kalahandi'),
(427, 26, 'Kandhamal'),
(428, 26, 'Koraput'),
(429, 26, 'Kendrapara'),
(430, 26, 'Malkangiri'),
(431, 26, 'Mayurbhanj'),
(432, 26, 'Nabarangpur'),
(433, 26, 'Nuapada'),
(434, 26, 'Nayagarh'),
(435, 26, 'Puri'),
(436, 26, 'Rayagada'),
(437, 26, 'Sambalpur'),
(438, 26, 'Subarnapur (Sonepur)'),
(439, 26, 'Sundergarh'),
(440, 27, 'Karaikal'),
(441, 27, 'Mahe'),
(442, 27, 'Pondicherry'),
(443, 27, 'Yanam'),
(444, 28, 'Amritsar'),
(445, 28, 'Barnala'),
(446, 28, 'Bathinda'),
(447, 28, 'Firozpur'),
(448, 28, 'Faridkot'),
(449, 28, 'Fatehgarh Sahib'),
(450, 28, 'Fazilka[6]'),
(451, 28, 'Gurdaspur'),
(452, 28, 'Hoshiarpur'),
(453, 28, 'Jalandhar'),
(454, 28, 'Kapurthala'),
(455, 28, 'Ludhiana'),
(456, 28, 'Mansa'),
(457, 28, 'Moga'),
(458, 28, 'Sri Muktsar Sahib'),
(459, 28, 'Pathankot'),
(460, 28, 'Patiala'),
(461, 28, 'Rupnagar'),
(462, 28, 'Ajitgarh (Mohali)'),
(463, 28, 'Sangrur'),
(464, 28, 'Shahid Bhagat Singh Nagar'),
(465, 28, 'Tarn Taran'),
(466, 29, 'Ajmer'),
(467, 29, 'Alwar'),
(468, 29, 'Bikaner'),
(469, 29, 'Barmer'),
(470, 29, 'Banswara'),
(471, 29, 'Bharatpur'),
(472, 29, 'Baran'),
(473, 29, 'Bundi'),
(474, 29, 'Bhilwara'),
(475, 29, 'Churu'),
(476, 29, 'Chittorgarh'),
(477, 29, 'Dausa'),
(478, 29, 'Dholpur'),
(479, 29, 'Dungapur'),
(480, 29, 'Ganganagar'),
(481, 29, 'Hanumangarh'),
(482, 29, 'Jhunjhunu'),
(483, 29, 'Jalore'),
(484, 29, 'Jodhpur'),
(485, 29, 'Jaipur'),
(486, 29, 'Jaisalmer'),
(487, 29, 'Jhalawar'),
(488, 29, 'Karauli'),
(489, 29, 'Kota'),
(490, 29, 'Nagaur'),
(491, 29, 'Pali'),
(492, 29, 'Pratapgarh'),
(493, 29, 'Rajsamand'),
(494, 29, 'Sikar'),
(495, 29, 'Sawai Madhopur'),
(496, 29, 'Sirohi'),
(497, 29, 'Tonk'),
(498, 29, 'Udaipur'),
(499, 30, 'East Sikkim'),
(500, 30, 'North Sikkim'),
(501, 30, 'South Sikkim'),
(502, 30, 'West Sikkim'),
(503, 31, 'Ariyalur'),
(504, 31, 'Chennai'),
(505, 31, 'Coimbatore'),
(506, 31, 'Cuddalore'),
(507, 31, 'Dharmapuri'),
(508, 31, 'Dindigul'),
(509, 31, 'Erode'),
(510, 31, 'Kanchipuram'),
(511, 31, 'Kanyakumari'),
(512, 31, 'Karur'),
(513, 31, 'Krishnagiri'),
(514, 31, 'Madurai'),
(515, 31, 'Nagapattinam'),
(516, 31, 'Nilgiris'),
(517, 31, 'Namakkal'),
(518, 31, 'Perambalur'),
(519, 31, 'Pudukkottai'),
(520, 31, 'Ramanathapuram'),
(521, 31, 'Salem'),
(522, 31, 'Sivaganga'),
(523, 31, 'Tirupur'),
(524, 31, 'Tiruchirappalli'),
(525, 31, 'Theni'),
(526, 31, 'Tirunelveli'),
(527, 31, 'Thanjavur'),
(528, 31, 'Thoothukudi'),
(529, 31, 'Tiruvallur'),
(530, 31, 'Tiruvarur'),
(531, 31, 'Tiruvannamalai'),
(532, 31, 'Vellore'),
(533, 31, 'Viluppuram'),
(534, 31, 'Virudhunagar'),
(535, 33, 'Dhalai'),
(536, 33, 'North Tripura'),
(537, 33, 'South Tripura'),
(538, 33, 'Khowai[7]'),
(539, 33, 'West Tripura'),
(540, 34, 'Agra'),
(541, 34, 'Aligarh'),
(542, 34, 'Allahabad'),
(543, 34, 'Ambedkar Nagar'),
(544, 34, 'Auraiya'),
(545, 34, 'Azamgarh'),
(546, 34, 'Bagpat'),
(547, 34, 'Bahraich'),
(548, 34, 'Ballia'),
(549, 34, 'Balrampur'),
(550, 34, 'Banda'),
(551, 34, 'Barabanki'),
(552, 34, 'Bareilly'),
(553, 34, 'Basti'),
(554, 34, 'Bijnor'),
(555, 34, 'Budaun'),
(556, 34, 'Bulandshahr'),
(557, 34, 'Chandauli'),
(558, 34, 'Chhatrapati Shahuji Maharaj Nagar[8]'),
(559, 34, 'Chitrakoot'),
(560, 34, 'Deoria'),
(561, 34, 'Etah'),
(562, 34, 'Etawah'),
(563, 34, 'Faizabad'),
(564, 34, 'Farrukhabad'),
(565, 34, 'Fatehpur'),
(566, 34, 'Firozabad'),
(567, 34, 'Gautam Buddh Nagar'),
(568, 34, 'Ghaziabad'),
(569, 34, 'Ghazipur'),
(570, 34, 'Gonda'),
(571, 34, 'Gorakhpur'),
(572, 34, 'Hamirpur'),
(573, 34, 'Hardoi'),
(574, 34, 'Hathras'),
(575, 34, 'Jalaun'),
(576, 34, 'Jaunpur district'),
(577, 34, 'Jhansi'),
(578, 34, 'Jyotiba Phule Nagar'),
(579, 34, 'Kannauj'),
(580, 34, 'Kanpur'),
(581, 34, 'Kanshi Ram Nagar'),
(582, 34, 'Kaushambi'),
(583, 34, 'Kushinagar'),
(584, 34, 'Lakhimpur Kheri'),
(585, 34, 'Lalitpur'),
(586, 34, 'Lucknow'),
(587, 34, 'Maharajganj'),
(588, 34, 'Mahoba'),
(589, 34, 'Mainpuri'),
(590, 34, 'Mathura'),
(591, 34, 'Mau'),
(592, 34, 'Meerut'),
(593, 34, 'Mirzapur'),
(594, 34, 'Moradabad'),
(595, 34, 'Muzaffarnagar'),
(596, 34, 'Panchsheel Nagar district (Hapur)'),
(597, 34, 'Pilibhit'),
(598, 34, 'Pratapgarh'),
(599, 34, 'Raebareli'),
(600, 34, 'Ramabai Nagar (Kanpur Dehat)'),
(601, 34, 'Rampur'),
(602, 34, 'Saharanpur'),
(603, 34, 'Sant Kabir Nagar'),
(604, 34, 'Sant Ravidas Nagar'),
(605, 34, 'Shahjahanpur'),
(606, 34, 'Shamli[9]'),
(607, 34, 'Shravasti'),
(608, 34, 'Siddharthnagar'),
(609, 34, 'Sitapur'),
(610, 34, 'Sonbhadra'),
(611, 34, 'Sultanpur'),
(612, 34, 'Unnao'),
(613, 34, 'Varanasi'),
(614, 35, 'Almora'),
(615, 35, 'Bageshwar'),
(616, 35, 'Chamoli'),
(617, 35, 'Champawat'),
(618, 35, 'Dehradun'),
(619, 35, 'Haridwar'),
(620, 35, 'Nainital'),
(621, 35, 'Pauri Garhwal'),
(622, 35, 'Pithoragarh'),
(623, 35, 'Rudraprayag'),
(624, 35, 'Tehri Garhwal'),
(625, 35, 'Udham Singh Nagar'),
(626, 35, 'Uttarkashi'),
(627, 36, 'Bankura'),
(628, 36, 'Bardhaman'),
(629, 36, 'Birbhum'),
(630, 36, 'Cooch Behar'),
(631, 36, 'Dakshin Dinajpur'),
(632, 36, 'Darjeeling'),
(633, 36, 'Hooghly'),
(634, 36, 'Howrah'),
(635, 36, 'Jalpaiguri'),
(636, 36, 'Kolkata'),
(637, 36, 'Maldah'),
(638, 36, 'Murshidabad'),
(639, 36, 'Nadia'),
(640, 36, 'North 24 Parganas'),
(641, 36, 'Paschim Medinipur'),
(642, 36, 'Purba Medinipur'),
(643, 36, 'Purulia'),
(644, 36, 'South 24 Parganas'),
(645, 36, 'Uttar Dinajpur'),
(646, 32, 'Adilabad'),
(647, 32, 'Bhadradri Kothagudem'),
(648, 32, 'Hyderabad'),
(649, 32, 'Jagtial'),
(650, 32, 'Jangaon'),
(651, 32, 'Jayashankar Bhupalapally'),
(652, 32, 'Jogulamba Gadwal'),
(653, 32, 'Kamareddy'),
(654, 32, 'Karimnagar'),
(655, 32, 'Khammam'),
(656, 32, 'Kumarambheem Asifabad'),
(657, 32, 'Mahabubabad'),
(658, 32, 'Mahabubnagar'),
(659, 32, 'Mancherial'),
(660, 32, 'Medak'),
(661, 32, 'Medchal–Malkajgiri'),
(662, 32, 'Nagarkurnool'),
(663, 32, 'Nalgonda'),
(664, 32, 'Nirmal'),
(665, 32, 'Nizamabad'),
(666, 32, 'Peddapalli'),
(667, 32, 'Rajanna Sircilla'),
(668, 32, 'RangaReddy'),
(669, 32, 'Sangareddy'),
(670, 32, 'Siddipet'),
(671, 32, 'Suryapet'),
(672, 32, 'Vikarabad'),
(673, 32, 'Wanaparthy'),
(674, 32, 'Warangal Rural'),
(675, 32, 'Warangal Urban'),
(676, 32, 'Yadadri Bhuvanagiri');

-- --------------------------------------------------------

--
-- Table structure for table `enquirys`
--

CREATE TABLE `enquirys` (
  `enq_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `comment` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'reply_notsent',
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enquirys`
--

INSERT INTO `enquirys` (`enq_id`, `name`, `email`, `mobile`, `comment`, `status`, `added_on`) VALUES
(2, 'Aravind Komara', 'abc@gmail.com', '7416674136', 'abcde...', 'reply_notsent', '2018-07-13 05:16:41'),
(3, 'Aravind Komara', 'aravind@omkieit.com', '7416674136', 'Well Come to international NGOs Net Work Online adverting park ( 1 ) There was a time when no discourse on poverty, development, globalisation, democracy or governance was complete without the term ‘NGO’ (non-governmental organisations, also called non-profit organisations or charities) figuring in it. But lately, they have been in the news for all the wrong reasons – partly due to the misdeeds of a few organisations and partly because of a right-leaning government hardening its stance on foreign aid. Types of legal entities The different legal entities under which a civil society organisations can register themselves are: Registered societies Societies Registration Act, 1860 is a central act for registering not-for-profit organisations. Almost all the states in India have adopted (with modifications, if any) the central Act for creating state level authorities for registering various types of not-', 'reply_notsent', '2018-07-13 05:28:33');

-- --------------------------------------------------------

--
-- Table structure for table `exams_details`
--

CREATE TABLE `exams_details` (
  `exam_id` int(11) NOT NULL,
  `exam_name` varchar(120) NOT NULL,
  `exam_date` varchar(120) NOT NULL,
  `exam_time` varchar(20) NOT NULL,
  `exam_duration` varchar(20) NOT NULL,
  `total_questions` varchar(20) NOT NULL,
  `total_marks` varchar(20) NOT NULL,
  `total_qmarks` varchar(20) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exams_details`
--

INSERT INTO `exams_details` (`exam_id`, `exam_name`, `exam_date`, `exam_time`, `exam_duration`, `total_questions`, `total_marks`, `total_qmarks`, `added_on`) VALUES
(1, 'Exam1', '28/08/2018', '03:09 PM', '03:10 PM', '3', '3', '2', '2018-08-07 04:55:58');

-- --------------------------------------------------------

--
-- Table structure for table `exam_answer_details`
--

CREATE TABLE `exam_answer_details` (
  `aid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `question_num` int(11) NOT NULL,
  `selected_answer` varchar(10) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_answer_details`
--

INSERT INTO `exam_answer_details` (`aid`, `uid`, `exam_id`, `question_id`, `question_num`, `selected_answer`, `added_on`) VALUES
(1, 1, 1, 1, 1, 'B', '2018-08-28 09:39:07'),
(2, 1, 1, 2, 2, 'C', '2018-08-28 09:39:10'),
(3, 1, 1, 6, 3, 'B', '2018-08-28 09:39:14');

-- --------------------------------------------------------

--
-- Table structure for table `exam_questions`
--

CREATE TABLE `exam_questions` (
  `question_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `question_name` text NOT NULL,
  `answer1` varchar(555) NOT NULL,
  `answer2` varchar(555) NOT NULL,
  `answer3` varchar(555) NOT NULL,
  `answer4` varchar(555) NOT NULL,
  `correct_answer` varchar(5) NOT NULL,
  `added_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_questions`
--

INSERT INTO `exam_questions` (`question_id`, `exam_id`, `question_number`, `question_name`, `answer1`, `answer2`, `answer3`, `answer4`, `correct_answer`, `added_on`) VALUES
(1, 1, 1, 'fghgjytj', 'yjyujk', 'uykyuk', 'uykuyk', 'kyuk', 'B', '2018-08-07 05:27:35'),
(2, 1, 2, 'fdgfhrgth', 'yj', 'jytj', 'jytjyuj', 'jytj', 'C', '2018-08-07 05:27:47'),
(6, 1, 3, 'wfe54y56hh', 'tht5h', 'hythyth', 'h5yh5yjh', 'h5y6hy', 'B', '2018-08-07 05:41:00');

-- --------------------------------------------------------

--
-- Table structure for table `exam_results`
--

CREATE TABLE `exam_results` (
  `er_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `total_marks` int(11) NOT NULL,
  `qualify_marks` int(11) NOT NULL,
  `your_marks` int(11) NOT NULL,
  `result_status` varchar(20) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_results`
--

INSERT INTO `exam_results` (`er_id`, `uid`, `exam_id`, `total_marks`, `qualify_marks`, `your_marks`, `result_status`, `added_on`) VALUES
(1, 1, 1, 3, 2, 3, 'qualified', '2018-08-28 10:25:31');

-- --------------------------------------------------------

--
-- Table structure for table `exam_users`
--

CREATE TABLE `exam_users` (
  `uid` int(11) NOT NULL,
  `name` varchar(125) NOT NULL,
  `email` varchar(125) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `password` varchar(125) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_users`
--

INSERT INTO `exam_users` (`uid`, `name`, `email`, `mobile`, `password`, `added_on`) VALUES
(1, 'Sony', 'admin@gmail.com', '7416674136', '202cb962ac59075b964b07152d234b70', '2018-08-23 07:11:21');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `gid` int(11) NOT NULL,
  `event_name` varchar(225) NOT NULL,
  `organized_by` varchar(225) NOT NULL,
  `date` varchar(50) NOT NULL,
  `location` varchar(225) NOT NULL,
  `description` text NOT NULL,
  `images` text NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`gid`, `event_name`, `organized_by`, `date`, `location`, `description`, `images`, `added_on`) VALUES
(2, 'regtfbrh', 'rghyghytj', 'ytjjhytj', 'tyhjtmyjytj', 'myjkytjuyjkyukuk7il8ol8oliliymujytjytj', 'uploads/admin/gallery/blog-post-31.jpg,uploads/admin/gallery/blog-post-41.jpg,uploads/admin/gallery/recent-post-11.jpg,uploads/admin/gallery/recent-post-1w1.jpg,uploads/admin/gallery/recent-post-21.jpg', '2018-08-04 07:18:34'),
(3, 'gthythy', 'yjhytj', 'hnthn', 'bgnhht', 'nthnythn', 'uploads/admin/gallery/recent-post-22.jpg,uploads/admin/gallery/recent-post-2w1.jpg,uploads/admin/gallery/recent-post-3.jpg,uploads/admin/gallery/recent-post-3w.jpg', '2018-08-04 07:18:50');

-- --------------------------------------------------------

--
-- Table structure for table `legality`
--

CREATE TABLE `legality` (
  `id` int(11) NOT NULL,
  `legality_text` text NOT NULL,
  `admin_id` int(11) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `legality`
--

INSERT INTO `legality` (`id`, `legality_text`, `admin_id`, `added_on`) VALUES
(1, 'Coming soon........jyukyukui\r\n', 1, '2018-07-12 05:19:36');

-- --------------------------------------------------------

--
-- Table structure for table `membership_schemes`
--

CREATE TABLE `membership_schemes` (
  `ms_id` int(11) NOT NULL,
  `ms_scheme` varchar(250) NOT NULL,
  `ms_type` varchar(20) NOT NULL,
  `price` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `membership_schemes`
--

INSERT INTO `membership_schemes` (`ms_id`, `ms_scheme`, `ms_type`, `price`) VALUES
(1, 'International Ngo\'s Network Member Ship', 'International', '2,00,000'),
(2, 'National Ngo\'s Network Member Ship', 'National', '1,00,000'),
(3, 'State Ngo\'s Network Member Ship', 'State', '50,000'),
(4, 'District  Ngo\'s Network Member Ship', 'District', '10,000');

-- --------------------------------------------------------

--
-- Table structure for table `ngos`
--

CREATE TABLE `ngos` (
  `ng_id` int(11) NOT NULL,
  `member_id` varchar(10) NOT NULL,
  `password` varchar(120) NOT NULL,
  `type` varchar(20) NOT NULL,
  `reg_type` varchar(20) NOT NULL DEFAULT 'not free',
  `country` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `district` varchar(20) DEFAULT NULL,
  `profile_pic` varchar(120) DEFAULT NULL,
  `tru_pre_name` varchar(50) NOT NULL,
  `tru_pre_same` varchar(50) NOT NULL,
  `tru_pre_of` varchar(50) NOT NULL,
  `tru_pre_email` varchar(50) DEFAULT NULL,
  `tru_pre_pancard` varchar(20) NOT NULL,
  `try_pre_mobilecode` varchar(10) DEFAULT NULL,
  `tru_pre_mobile1` varchar(20) DEFAULT NULL,
  `mobile_visible_status` varchar(10) NOT NULL,
  `tru_pre_mobile2` varchar(20) NOT NULL,
  `tru_pre_landline` varchar(20) NOT NULL,
  `tru_pre_govproof` varchar(120) DEFAULT NULL,
  `tru_sec_name` varchar(50) NOT NULL,
  `tru_sec_same` varchar(50) NOT NULL,
  `tru_sec_of` varchar(50) NOT NULL,
  `tru_sec_email` varchar(50) NOT NULL,
  `tru_sec_pancard` varchar(20) NOT NULL,
  `tru_sec_mobile1` varchar(20) NOT NULL,
  `tru_sec_mobile2` varchar(20) NOT NULL,
  `tru_sec_landline` varchar(20) NOT NULL,
  `tru_sec_govproof` varchar(120) DEFAULT NULL,
  `membership_status` varchar(10) NOT NULL DEFAULT 'inactive',
  `mobile_status` varchar(10) NOT NULL DEFAULT 'inactive',
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ngos`
--

INSERT INTO `ngos` (`ng_id`, `member_id`, `password`, `type`, `reg_type`, `country`, `state`, `district`, `profile_pic`, `tru_pre_name`, `tru_pre_same`, `tru_pre_of`, `tru_pre_email`, `tru_pre_pancard`, `try_pre_mobilecode`, `tru_pre_mobile1`, `mobile_visible_status`, `tru_pre_mobile2`, `tru_pre_landline`, `tru_pre_govproof`, `tru_sec_name`, `tru_sec_same`, `tru_sec_of`, `tru_sec_email`, `tru_sec_pancard`, `tru_sec_mobile1`, `tru_sec_mobile2`, `tru_sec_landline`, `tru_sec_govproof`, `membership_status`, `mobile_status`, `added_on`) VALUES
(1, 'INNW463208', '111', 'District', 'not free', NULL, NULL, 'Chittoor', 'uploads/INNW463208/documents/PaytmQRbanner_AravindKomara2.pdf', 'Komara Aravind', 'hytjythj', 'hjuyjkkjuy', 'aravind@omkieit.com', 'thjhjuk', '852', '555465565', '', '654656565', '5787878786', 'uploads/INNW463208/documents/PaytmQRbanner_AravindKomara.pdf', 'ghrthyrj', 'jhytjyt', 'jytj', 'yjyukukuk@gmail.com', 'ngnhht', '46546543', '546545', '68969', 'uploads/INNW463208/documents/PaytmQRbanner_AravindKomara1.pdf', 'inactive', 'active', '2018-07-30 10:17:43'),
(2, 'INNW497081', 'd41d8cd98f00b204e9800998ecf8427e', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', '', '', 'aravind@omkieit.com', '', '973', '59595959', '', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'inactive', '2018-07-31 09:35:22'),
(3, 'INNW762304', '698d51a19d8a121ce581499d7b701668', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', '', '', 'aravind@omkieit.com', '', '1246', '654654688', '', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'active', '2018-07-31 09:36:21'),
(4, 'INNW768021', '698d51a19d8a121ce581499d7b701668', 'International', 'free', '', NULL, NULL, NULL, 'Aravind Komara', '', '', NULL, '', NULL, NULL, '', '', '', NULL, '', '', '', 'aravind@omkieit.com', '', '', '', '', NULL, 'inactive', 'inactive', '2018-08-01 11:31:58'),
(5, 'INNW235690', '698d51a19d8a121ce581499d7b701668', 'International', 'free', '', NULL, NULL, NULL, 'Ajay', '', '', NULL, '', NULL, NULL, '', '', '', NULL, '', '', '', 'aravind@omkieit.com', '', '', '', '', NULL, 'inactive', 'inactive', '2018-08-01 11:34:50'),
(6, 'INNW765319', '698d51a19d8a121ce581499d7b701668', 'State', 'free', NULL, '', NULL, NULL, 'Aravind Komara', '', '', NULL, '', NULL, NULL, '', '', '', NULL, '', '', '', 'aravind@omkieit.com', '', '', '', '', NULL, 'inactive', 'inactive', '2018-08-01 11:38:13'),
(7, 'INNW149236', 'd41d8cd98f00b204e9800998ecf8427e', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', '', '', 'aravind@omkieit.com', '', '32', '455778', '', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'inactive', '2018-08-04 09:40:54'),
(8, 'INNW431958', 'd41d8cd98f00b204e9800998ecf8427e', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', '', '', 'aravind@omkieit.com', '', '501', '34548578', '', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'inactive', '2018-08-04 09:41:33'),
(9, 'INNW601432', 'd41d8cd98f00b204e9800998ecf8427e', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', '', '', 'aravind@omkieit.com', '', '501', '57368', '', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'inactive', '2018-08-04 09:42:28'),
(10, 'INNW950248', 'd41d8cd98f00b204e9800998ecf8427e', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', '', '', 'aravind@omkieit.com', '', '91', '7416674136', '', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'active', '2018-08-04 09:44:01'),
(11, 'INNW685794', 'd41d8cd98f00b204e9800998ecf8427e', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', '', '', 'aravind@omkieit.com', '', '91', '7416674136', '', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'active', '2018-08-04 09:49:49'),
(12, 'INNW403216', '698d51a19d8a121ce581499d7b701668', 'International', 'free', '', NULL, NULL, NULL, 'sfddgrthytj', '', '', NULL, '', NULL, NULL, '', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'inactive', '2018-08-07 09:21:17'),
(13, 'INNW710962', 'd41d8cd98f00b204e9800998ecf8427e', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', '', '', 'aravind@omkieit.com', '', '91', '7416674136', 'no', '', '', NULL, 'ghrthyrj', '', '', '', '', '', '', '', NULL, 'inactive', 'inactive', '2018-09-15 08:51:51'),
(14, 'INNW893025', 'd41d8cd98f00b204e9800998ecf8427e', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', '', '', 'aravind@omkieit.com', '', '375', '27752772725', 'no', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'inactive', '2018-09-15 08:56:37'),
(15, 'INNW817324', 'd41d8cd98f00b204e9800998ecf8427e', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', '', '', 'aravind@omkieit.com', '', '501', '59595959', 'no', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'inactive', '2018-09-15 08:58:15'),
(16, 'INNW530129', 'd41d8cd98f00b204e9800998ecf8427e', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', 'hytjythj', '', 'aravind@omkieit.com', '', '994', '127787878', 'no', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'inactive', '2018-10-08 12:18:39'),
(17, 'INNW085362', 'd41d8cd98f00b204e9800998ecf8427e', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', 'hytjythj', '', 'aravind@omkieit.com', '', '', '27752772725', 'no', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'inactive', '2018-10-08 12:21:25'),
(18, 'INNW237061', 'd41d8cd98f00b204e9800998ecf8427e', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', '', 'hjuyjkkjuy', 'aravind@omkieit.com', '', '32', '6554', 'no', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'inactive', '2018-10-08 12:24:40'),
(19, 'INNW597362', 'd41d8cd98f00b204e9800998ecf8427e', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', '', 'hjuyjkkjuy', 'aravind@omkieit.com', '', '501', '54554876', 'no', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'inactive', '2018-10-08 12:26:05'),
(20, 'INNW376149', 'd41d8cd98f00b204e9800998ecf8427e', 'International', 'not free', '', NULL, NULL, NULL, 'Aravind Komara', 'hytjythj', '', 'aravind@omkieit.com', '', '375', '54554876', 'no', '', '', NULL, '', '', '', '', '', '', '', '', NULL, 'inactive', 'inactive', '2018-10-08 12:32:36');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `nid` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `notification_text` text NOT NULL,
  `type` varchar(220) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`nid`, `admin_id`, `notification_text`, `type`, `added_on`) VALUES
(1, 1, 'International meetings Notification22', 'International meetings', '2018-07-23 12:05:44'),
(2, 1, 'National meetings Notification1', 'National meetings', '2018-07-23 12:05:57'),
(3, 1, 'State meetings Notification', 'State meetings', '2018-07-23 12:06:07'),
(4, 1, 'District meetings Notification', 'District meetings', '2018-07-23 12:06:15'),
(5, 1, 'Jobs Notification', 'Jobs', '2018-07-23 12:06:25'),
(6, 1, 'Events Notification', 'Events', '2018-07-23 12:06:32'),
(7, 1, 'Emergency services Notification', 'Emergency services', '2018-07-23 12:06:41'),
(8, 1, 'Emergency meetings Notification', 'Emergency meetings', '2018-07-23 12:06:50'),
(9, 1, 'Emergency protocol Notification', 'Emergency protocol', '2018-07-23 12:06:58');

-- --------------------------------------------------------

--
-- Table structure for table `notification_types`
--

CREATE TABLE `notification_types` (
  `nt_id` int(11) NOT NULL,
  `nt_name` varchar(225) NOT NULL,
  `type` varchar(255) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification_types`
--

INSERT INTO `notification_types` (`nt_id`, `nt_name`, `type`, `added_on`) VALUES
(1, 'International meeting\'s notification', 'International meetings', '2018-07-23 12:21:18'),
(2, 'National meeting\'s notification', 'National meetings', '2018-07-23 12:21:18'),
(3, 'State meeting\'s notification', 'State meetings', '2018-07-23 12:21:18'),
(4, 'District meeting\'s notification', 'District meetings', '2018-07-23 12:21:18'),
(5, 'Job\'s notification', 'Jobs', '2018-07-23 12:21:18'),
(6, 'Events\'s notification', 'Events', '2018-07-23 12:21:18'),
(8, 'Emergency services notification', 'Emergency services', '2018-07-23 12:21:18'),
(9, 'Emergency meeting\'s notification', 'Emergency meetings', '2018-07-23 12:21:18'),
(10, 'Emergency protocal  notification', 'Emergency protocol', '2018-07-23 12:21:18');

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `off_id` int(11) NOT NULL,
  `off_type` varchar(20) DEFAULT NULL,
  `off_image` varchar(520) NOT NULL,
  `off_desc` text NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`off_id`, `off_type`, `off_image`, `off_desc`, `added_on`) VALUES
(1, 'International', 'uploads/admin/offers/3cf55c3dad99cc4d97e87d120b1e1f25.jpg', 'swdfreu', '2018-07-04 09:23:09'),
(2, 'International', 'uploads/admin/offers/bike.jpg', 'bike', '2018-07-04 12:33:02'),
(4, 'National', 'uploads/admin/offers/recent-post-4.jpg', 'adwqfwef', '2018-07-18 06:57:22'),
(5, 'National', 'uploads/admin/offers/blog-post-1.jpg', 'defwefwefewf', '2018-07-18 06:57:33'),
(8, 'State', 'uploads/admin/offers/blog-post-4.jpg', 'fwefwefwre', '2018-07-18 06:57:58'),
(9, 'State', 'uploads/admin/offers/recent-post-1.jpg', 'fwefwregf', '2018-07-18 06:58:04'),
(10, 'District', 'uploads/admin/offers/recent-post-2.jpg', 'fwefewfwer', '2018-07-18 06:58:16'),
(11, 'District', 'uploads/admin/offers/recent-post-2w.jpg', 'fefewffg', '2018-07-18 06:58:21'),
(12, 'District', 'uploads/admin/offers/recent-post-7.jpg', 'fwefwrefg', '2018-07-18 06:58:27'),
(13, 'International', 'uploads/admin/offers/avatar-author1.jpg', 'gryty6ty6u', '2018-07-18 07:24:59'),
(14, 'International', 'uploads/admin/offers/blog-post-11.jpg', 'rgrtgrtyty', '2018-07-18 07:25:04'),
(15, 'International', 'uploads/admin/offers/blog-post-22.jpg', 'fghrth', '2018-07-18 07:25:10'),
(16, 'International', 'uploads/admin/offers/recent-post-6.jpg', 'egttyt', '2018-07-18 07:25:19');

-- --------------------------------------------------------

--
-- Table structure for table `otp`
--

CREATE TABLE `otp` (
  `oid` int(11) NOT NULL,
  `otp_id` varchar(10) DEFAULT NULL,
  `otp` varchar(10) DEFAULT NULL,
  `posted_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `otp`
--

INSERT INTO `otp` (`oid`, `otp_id`, `otp`, `posted_on`) VALUES
(1, 'kanGHc', '7210', '2018-07-31 09:35:23'),
(2, '8dDSyt', '5862', '2018-08-04 09:40:54'),
(3, 'wXNMZs', '7631', '2018-08-04 09:41:34'),
(4, 'RtLWuN', '6549', '2018-08-04 09:42:28'),
(5, 'wXh0qT', '5371', '2018-09-15 08:51:51'),
(6, 'ywPLJN', '9523', '2018-09-15 08:56:37'),
(7, 'xKUsrz', '9246', '2018-09-15 08:58:15'),
(8, '79xdHM', '8059', '2018-10-08 12:18:40'),
(9, 'Lp7MsR', '0217', '2018-10-08 12:21:25'),
(10, '2N5Amt', '1639', '2018-10-08 12:24:40'),
(11, 'dCnU4B', '9764', '2018-10-08 12:26:05'),
(12, 's1af0z', '7831', '2018-10-08 12:32:36');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `pid` int(11) NOT NULL,
  `member_id` varchar(50) NOT NULL,
  `name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `payment_for` varchar(50) NOT NULL,
  `service_provider` varchar(50) NOT NULL,
  `amount` varchar(225) NOT NULL,
  `txnID` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `referal_moderations`
--

CREATE TABLE `referal_moderations` (
  `rid` int(11) NOT NULL,
  `memberid` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `referal_moderations`
--

INSERT INTO `referal_moderations` (`rid`, `memberid`, `amount`, `status`, `added_on`) VALUES
(1, 'INNW762304', '1', 'approved', '2018-08-01 09:15:52');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(8) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `name`) VALUES
(1, 'Andaman and Nicobar '),
(2, 'Andhra Pradesh '),
(3, 'Arunachal Pradesh '),
(4, 'Assam '),
(5, 'Bihar '),
(6, 'Chandigarh '),
(7, 'Chhattisgarh '),
(8, 'Dadra and Nagar Haveli '),
(9, 'Daman and Diu '),
(10, 'Delhi '),
(11, 'Goa '),
(12, 'Gujarat '),
(13, 'Haryana '),
(14, 'Himachal Pradesh '),
(15, 'Jammu and Kashmir '),
(16, 'Jharkhand '),
(17, 'Karnataka '),
(18, 'Kerala '),
(19, 'Lakshdweep '),
(20, 'Madhya Pradesh '),
(21, 'Maharashtra '),
(22, 'Manipur '),
(23, 'Meghalaya '),
(24, 'Mizoram '),
(25, 'Nagaland '),
(26, 'Odisha'),
(27, 'Puducherry '),
(28, 'Punjab '),
(29, 'Rajasthan '),
(30, 'Sikkim '),
(31, 'Tamil Nadu '),
(32, 'Telangana'),
(33, 'Tripura '),
(34, 'Uttar Pradesh '),
(35, 'Uttarakhand '),
(36, 'West Bengal ');

-- --------------------------------------------------------

--
-- Table structure for table `trust_details`
--

CREATE TABLE `trust_details` (
  `tr_id` int(11) NOT NULL,
  `ng_id` int(11) NOT NULL,
  `member_id` varchar(20) NOT NULL,
  `tr_name` varchar(50) NOT NULL,
  `tr_reg_date` varchar(50) NOT NULL,
  `tr_pancard` varchar(20) NOT NULL,
  `tr_12AA_num` varchar(20) NOT NULL,
  `tr_80G_num` varchar(20) DEFAULT NULL,
  `tr_FCRA_num` varchar(20) NOT NULL,
  `tr_1023_num` varchar(20) NOT NULL,
  `tr_35AC_num` varchar(20) NOT NULL,
  `tr_501C_num` varchar(20) NOT NULL,
  `tr_nitiayog_num` varchar(20) NOT NULL,
  `tr_3IT_dates` text NOT NULL,
  `tr_3AR_dates` text NOT NULL,
  `tr_3FCRA_dates` text NOT NULL,
  `tr_new_proj` varchar(20) DEFAULT NULL,
  `tr_runnig_proj` varchar(10) NOT NULL,
  `tr_landline` varchar(20) NOT NULL,
  `tr_mobile` varchar(20) NOT NULL,
  `tr_email` varchar(50) NOT NULL,
  `tr_refid` varchar(20) NOT NULL,
  `tr_refby` varchar(20) DEFAULT NULL,
  `tr_refid_gift` varchar(20) DEFAULT NULL,
  `tr_refid_gift_from` varchar(255) DEFAULT NULL,
  `tr_ref_money_status` varchar(20) DEFAULT 'Withdraw',
  `tr_bill_proof` varchar(120) NOT NULL,
  `tr_regcer_proof` varchar(120) NOT NULL,
  `tr_pancard_proof` varchar(120) NOT NULL,
  `tr_12AA_proof` varchar(120) NOT NULL,
  `tr_80G_proof` varchar(120) NOT NULL,
  `tr_FCRA_proof` varchar(120) NOT NULL,
  `tr_1023_proof` varchar(120) NOT NULL,
  `tr_35AC_proof` varchar(120) NOT NULL,
  `tr_501C_proof` varchar(120) NOT NULL,
  `tr_nitiayog_proof` varchar(120) NOT NULL,
  `tr_3IT_dat_proof` varchar(120) NOT NULL,
  `tr_3AR_dat_proof` varchar(120) NOT NULL,
  `tr_3FCRA_dat_proof` varchar(120) NOT NULL,
  `tr_new_proj_proof` varchar(120) NOT NULL,
  `tr_running_proj_proof` varchar(120) NOT NULL,
  `tr_paper_cutting_proof` varchar(120) NOT NULL,
  `tr_photo` varchar(120) NOT NULL,
  `tr_FCRA_audit_proof` varchar(120) NOT NULL,
  `tr_currentbill_proof` varchar(120) NOT NULL,
  `tr_passport_proof` varchar(120) NOT NULL,
  `tr_membership_fee` varchar(20) DEFAULT NULL,
  `tr_servicetax_fee` varchar(20) DEFAULT NULL,
  `tr_total_amount` varchar(20) DEFAULT NULL,
  `tr_text` text,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trust_details`
--

INSERT INTO `trust_details` (`tr_id`, `ng_id`, `member_id`, `tr_name`, `tr_reg_date`, `tr_pancard`, `tr_12AA_num`, `tr_80G_num`, `tr_FCRA_num`, `tr_1023_num`, `tr_35AC_num`, `tr_501C_num`, `tr_nitiayog_num`, `tr_3IT_dates`, `tr_3AR_dates`, `tr_3FCRA_dates`, `tr_new_proj`, `tr_runnig_proj`, `tr_landline`, `tr_mobile`, `tr_email`, `tr_refid`, `tr_refby`, `tr_refid_gift`, `tr_refid_gift_from`, `tr_ref_money_status`, `tr_bill_proof`, `tr_regcer_proof`, `tr_pancard_proof`, `tr_12AA_proof`, `tr_80G_proof`, `tr_FCRA_proof`, `tr_1023_proof`, `tr_35AC_proof`, `tr_501C_proof`, `tr_nitiayog_proof`, `tr_3IT_dat_proof`, `tr_3AR_dat_proof`, `tr_3FCRA_dat_proof`, `tr_new_proj_proof`, `tr_running_proj_proof`, `tr_paper_cutting_proof`, `tr_photo`, `tr_FCRA_audit_proof`, `tr_currentbill_proof`, `tr_passport_proof`, `tr_membership_fee`, `tr_servicetax_fee`, `tr_total_amount`, `tr_text`, `added_on`) VALUES
(1, 1, 'INNW463208', 'wfggrb', 'gbrgbg', 'bgbrgb', 'brgbrgb', '', 'bgbrgbrg', 'brgbrtb', '4545', 'gr', 'geg', 'gbrgth', 'hrtghrgh', 'brgbrgbrg', NULL, 'rgbrgbrgth', 'hrthrthtrh', 'rhrthrthfgrth', 'hrthrth@gmail.com', '5b5ee5c7d7355', '', NULL, NULL, NULL, 'uploads/INNW463208/documents/PaytmQRbanner_AravindKomara3.pdf', 'uploads/INNW463208/documents/PaytmQRbanner_AravindKomara4.pdf', 'uploads/INNW463208/documents/Aravind_Komara.pdf', 'uploads/INNW463208/documents/Aravind_Komara1.pdf', 'uploads/INNW463208/documents/Aravind_Komara2.pdf', 'uploads/INNW463208/documents/Aravind_Komara3.pdf', 'uploads/INNW463208/documents/Aravind_Komara4.pdf', 'uploads/INNW463208/documents/Aravind_Komara5.pdf', 'uploads/INNW463208/documents/Aravind_Komara6.pdf', 'uploads/INNW463208/documents/Aravind_Komara7.pdf', 'uploads/INNW463208/documents/Aravind_Komara8.pdf', 'uploads/INNW463208/documents/Aravind_Komara9.pdf', 'uploads/INNW463208/documents/Aravind_Komara10.pdf', 'uploads/INNW463208/documents/Aravind_Komara11.pdf', 'uploads/INNW463208/documents/Aravind_Komara12.pdf', 'uploads/INNW463208/documents/Aravind_Komara13.pdf', 'uploads/INNW463208/documents/Aravind_Komara14.pdf', 'uploads/INNW463208/documents/Aravind_Komara15.pdf', 'uploads/INNW463208/documents/Aravind_Komara16.pdf', 'uploads/INNW463208/documents/PaytmQRbanner_AravindKomara5.pdf', NULL, NULL, NULL, 'frthytjythj', '2018-07-30 10:17:43'),
(2, 2, 'INNW497081', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5b602d5b03cc5', '', '0', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-07-31 09:35:23'),
(3, 3, 'INNW762304', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5b602d953eec6', '', '1', NULL, 'approved', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-07-31 09:36:21'),
(4, 4, 'INNW768021', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5b619a2e4f038', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-08-01 11:31:58'),
(5, 5, 'INNW235690', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5b619ada5680f', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-08-01 11:34:50'),
(6, 6, 'INNW765319', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5b619ba5bb09f', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '50000', '9000', '59000', '', '2018-08-01 11:38:13'),
(7, 7, 'INNW149236', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5b6574a6962df', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-08-04 09:40:54'),
(8, 8, 'INNW431958', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5b6574ce09049', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-08-04 09:41:34'),
(9, 9, 'INNW601432', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5b657504b9a26', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-08-04 09:42:28'),
(10, 10, 'INNW950248', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5b6575619cf5f', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-08-04 09:44:01'),
(11, 11, 'INNW685794', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5b6576bd244c0', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-08-04 09:49:49'),
(12, 12, 'INNW403216', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5b69648d70b3d', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-08-07 09:21:17'),
(13, 13, 'INNW710962', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5b9cc82782e06', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-09-15 08:51:51'),
(14, 14, 'INNW893025', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5b9cc94595a72', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-09-15 08:56:37'),
(15, 15, 'INNW817324', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5b9cc9a77ce39', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-09-15 08:58:15'),
(16, 16, 'INNW530129', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5bbb4b2025d20', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-10-08 12:18:40'),
(17, 17, 'INNW085362', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5bbb4bc56f9c9', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-10-08 12:21:25'),
(18, 18, 'INNW237061', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5bbb4c8818664', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-10-08 12:24:40'),
(19, 19, 'INNW597362', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5bbb4cdd88e7e', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-10-08 12:26:05'),
(20, 20, 'INNW376149', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '5bbb4e64a21c7', '', '0', NULL, 'Withdraw', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '200000', '36000', '236000', '', '2018-10-08 12:32:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `auth_inter_types`
--
ALTER TABLE `auth_inter_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `auth_national_types`
--
ALTER TABLE `auth_national_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `auth_persons`
--
ALTER TABLE `auth_persons`
  ADD PRIMARY KEY (`auth_id`);

--
-- Indexes for table `auth_person_types`
--
ALTER TABLE `auth_person_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`bn_id`);

--
-- Indexes for table `brouchers`
--
ALTER TABLE `brouchers`
  ADD PRIMARY KEY (`br_id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquirys`
--
ALTER TABLE `enquirys`
  ADD PRIMARY KEY (`enq_id`);

--
-- Indexes for table `exams_details`
--
ALTER TABLE `exams_details`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `exam_answer_details`
--
ALTER TABLE `exam_answer_details`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `exam_questions`
--
ALTER TABLE `exam_questions`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `exam_results`
--
ALTER TABLE `exam_results`
  ADD PRIMARY KEY (`er_id`);

--
-- Indexes for table `exam_users`
--
ALTER TABLE `exam_users`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `legality`
--
ALTER TABLE `legality`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `membership_schemes`
--
ALTER TABLE `membership_schemes`
  ADD PRIMARY KEY (`ms_id`);

--
-- Indexes for table `ngos`
--
ALTER TABLE `ngos`
  ADD PRIMARY KEY (`ng_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`nid`);

--
-- Indexes for table `notification_types`
--
ALTER TABLE `notification_types`
  ADD PRIMARY KEY (`nt_id`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`off_id`);

--
-- Indexes for table `otp`
--
ALTER TABLE `otp`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `referal_moderations`
--
ALTER TABLE `referal_moderations`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trust_details`
--
ALTER TABLE `trust_details`
  ADD PRIMARY KEY (`tr_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `auth_inter_types`
--
ALTER TABLE `auth_inter_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `auth_national_types`
--
ALTER TABLE `auth_national_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `auth_persons`
--
ALTER TABLE `auth_persons`
  MODIFY `auth_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `auth_person_types`
--
ALTER TABLE `auth_person_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `bn_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `brouchers`
--
ALTER TABLE `brouchers`
  MODIFY `br_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=247;

--
-- AUTO_INCREMENT for table `enquirys`
--
ALTER TABLE `enquirys`
  MODIFY `enq_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `exams_details`
--
ALTER TABLE `exams_details`
  MODIFY `exam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `exam_answer_details`
--
ALTER TABLE `exam_answer_details`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `exam_questions`
--
ALTER TABLE `exam_questions`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `exam_results`
--
ALTER TABLE `exam_results`
  MODIFY `er_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `exam_users`
--
ALTER TABLE `exam_users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `legality`
--
ALTER TABLE `legality`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `membership_schemes`
--
ALTER TABLE `membership_schemes`
  MODIFY `ms_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ngos`
--
ALTER TABLE `ngos`
  MODIFY `ng_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `nid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `notification_types`
--
ALTER TABLE `notification_types`
  MODIFY `nt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `offers`
--
ALTER TABLE `offers`
  MODIFY `off_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `otp`
--
ALTER TABLE `otp`
  MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `referal_moderations`
--
ALTER TABLE `referal_moderations`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `trust_details`
--
ALTER TABLE `trust_details`
  MODIFY `tr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
