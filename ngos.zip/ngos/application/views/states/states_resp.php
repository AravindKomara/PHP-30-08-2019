

<!-- CONTENT AREA -->
<div class="content-area">

    <!-- PAGE -->
    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->

    <!-- PAGE-->
    <section class="page-section">
        <div class="container">
           <div class="message-box">
                <?php
                if (!empty($state_banner_text->bn_text)) {
                    ?> <div class="message-box-inner">
                        <h2><?= $state_banner_text->bn_text ?> </h2>
                    </div>
                <?php } else {
                    ?><div class="message-box-inner">
                        <h2>This is International Ngos Network Only For Advertising Purpose vsfdgfh</h2>
                    </div>
                <?php }
                ?>
            </div>
        </div>
    </section>
    <!-- /PAGE -->
    <section class="page-section">
        <div class="container">



            <div class="tab-content">

                <!-- tab 2 -->
                <div class="tab-pane fade active in" id="tab-2" >
                    <div class="row">

                        <?php
                        foreach ($districts as $d) {
                             $district = str_replace(" ","_",$d->name);
                            ?> <div class="col-md-2 col-sm-6">
                                <div class="thumbnail no-border no-padding">
                                    <div class="media">
                                        <a href='<?= base_url('district_uniqngos/'.$district)?>' class="districts" data-sid="<?= $d->id ?>"><h4 align=""><?= $d->name ?></h4></a>
                                    </div>
                                </div>
                            </div> 
                        <?php }
                        ?>





                    </div>









                </div>
            </div>

            <!-- tab 3 -->

        </div>

</div>
</section>
<!-- /PAGE -->              
</div>
<!-- /CONTENT AREA -->

<script src="https://code.jquery.com/jquery-3.3.1.js"
        integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
crossorigin="anonymous"></script>

<script>

    $(".states").click(function () {
        var sid = $(this).attr("data-sid");
        //alert(sid);

        $.ajax({
            url: "<?= base_url('States/get_state_districts') ?>", 
            type: "POST", 
            data:{
                state_id : sid
            }, 
            
            success: function (response) {
               
            }

        });

    });
</script>