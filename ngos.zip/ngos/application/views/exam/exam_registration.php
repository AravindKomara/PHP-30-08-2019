
<!-- CONTENT AREA -->
<div class="content-area reg_success">

    <section class="page-section">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade active in" id="tab-2" style="">
                    <div class="">
                        <div class="col-md-12 col-sm-6 col-md-offset-">									
                            <div class="row">
                                <div class="message-box">
                                    <div class="message-box-inner">
                                        <h2>Register </h2>
                                    </div>
                                </div>

                                <div class='col-md-6' style='border-right:1px solid lightgray'>
                                    <form method="post" id="exam_register_form">
                                        <div class="form-group row">
                                            <div class="col-md-6 col-sm-6">
                                                <label for="ex1" style="color:initial;">Name</label>
                                                <input class="form-control" name="name" placeholder="Your Name...."  type="text" required="">

                                            </div>

                                        </div>

                                        <div class="form-group row">
                                            <div class="col-md-6 col-sm-6">
                                                <label for="ex1" style="color:initial;">Email</label>
                                                <span id="email_err"></span>
                                                <input class="form-control" name="email" id="entered_email" placeholder="Your Email...."  type="email" onblur="verify_email()" required="">

                                            </div>

                                        </div>

                                        <div class="form-group row">
                                            <div class="col-md-6 col-sm-6">
                                                <label for="ex1" style="color:initial;">Mobile</label>
                                                <span id="mobile_err"></span>
                                                <input class="form-control" name="mobile" id="entered_mobile" placeholder="Your Mobile...."  onblur="verify_mobile()" type="text" required="">

                                            </div>

                                        </div>

                                        <div class="form-group row">
                                            <div class="col-md-6 col-sm-6">
                                                <label for="ex1" style="color:initial;">Password</label>
                                                <input class="form-control" name="password" placeholder="**********"  type="password" required="">

                                            </div>

                                        </div>

                                        <div class="form-group row">
                                            <div class="col-md-6 col-sm-6">
                                                <label for="ex1" style="color:initial;">Confirm Password</label>
                                                <input class="form-control" name="cpassword" placeholder="**********"   type="password" required="">

                                            </div>

                                        </div>

                                        <div class="col-md-12 col-sm-12">
                                            <center id="email_success">

                                                <button class='btn btn-md btn-info' id="exam_register">Register</button>&nbsp;&nbsp;&nbsp;&nbsp;
                                                <a class='btn btn-md btn-info' href="<?= base_url('exam_login') ?>" >Login</a>&nbsp;&nbsp;&nbsp;&nbsp;
                                            </center>

                                        </div>

                                    </form>



                                </div>	
                            </div>
                        </div>
                    </div>
                </div>

            </div>
    </section>
    <!-- /PAGE -->              
</div>
<!-- /CONTENT AREA -->


<script>
    $("#exam_register_form").on('submit', function (e) {
        e.preventDefault();
        // alert();

        $.ajax({
            url: "<?= base_url('Exam/register') ?>", // Url to which the request is send
            type: "POST", // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false, // The content type used when sending data to the server.
            cache: false, // To unable request pages to be cached
            processData: false, // To send 
            success: function (response) {
                if (response === 'register') {
                    $("#email_success").html('<font style="color:green;font-size:25px;">Registration is  successfully completed .....</font>');
                    $("#email_success").fadeOut(4000);
                    setTimeout(function () {
                        window.location.href = "<?php echo base_url('exam_login') ?>";
                    }, 3000);

                }
            }
        });

    });

    function verify_email() {
        //alert();
        var email = $("#entered_email").val();
        $.ajax({
            url: "<?= base_url('Exam/verify_email') ?>",
            type: "POST",
            data: {
                email: email
            },
            success: function (response) {
                if (response === 'email_exists') {
                    $("#email_err").html('<font style="color:red;font-size:25px;">Email already exists .....</font>');
                    $("#exam_register").val(1);
                    disable_button();
                    $("#email_err").fadeOut(5000);

                } else {
                    $("#exam_register").val(0);
                    disable_button();
                }
            }
        });
    }

    function verify_mobile() {
        //alert();
        var mobile = $("#entered_mobile").val();
        $.ajax({
            url: "<?= base_url('Exam/verify_mobile') ?>",
            type: "POST",
            data: {
                mobile: mobile
            },
            success: function (response) {
                if (response === 'mobile_exists') {
                    $("#mobile_err").html('<font style="color:red;font-size:20px;">Mobile already exists .....</font>');
                    $("#exam_register").val(1);
                    disable_button();
                    $("#mobile_err").fadeOut(5000);

                } else {
                    $("#exam_register").val(0);
                    disable_button();
                }
            }
        });
    }

    function disable_button() {
        if ($("#exam_register").val() === '1') {
            $("#exam_register").prop('disabled', true);
        } else {
            $("#exam_register").prop('disabled', false);
        }
    }
</script>