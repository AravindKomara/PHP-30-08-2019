<?php
$status = $this->Exam_model->get_uniq_UserandQuestion_answer($ques->exam_id, $ques->question_id, $ques->question_number);
?>  <div class="tab-pane active" role="tabpanel" id="<?= $ques->question_number ?>">

    <p id=""><strong>Q<?= $ques->question_number ?>.</strong>&nbsp;<?= $ques->question_name ?>  </p>

    <div class="ansbox ques_option active false" id="">
        <input type="hidden" name="ques_no" id="question_no" value="<?= $ques->question_number ?>">
        <input type="hidden" name="exam_id" id="excam_id" value="<?= $ques->exam_id ?>">
        <input type="hidden" name="ques_id" id="question_id" value="<?= $ques->question_id ?>">
        <span  data-option="A">A</span>
        <?php
        if (!empty($status->selected_answer) && $status->selected_answer == 'A') {
            ?> <input class="select_option" type="radio" name="option" value="A" checked="">
        <?php } else {
            ?><input class="select_option" type="radio" name="option" value="A">
        <?php }
        ?>

        <label> <?= $ques->answer1 ?></label>

    </div>
    <div class="ansbox ques_option1" id="">
        <span  data-option="B">B</span>
        <?php
        if (!empty($status->selected_answer) && $status->selected_answer == 'B') {
            ?> <input class="select_option" type="radio" name="option" value="B" checked="">
        <?php } else {
            ?><input class="select_option" type="radio" name="option" value="B">
        <?php }
        ?>
        <label><?= $ques->answer2 ?></label>

    </div>
    <div class="ansbox ques_option1" id="">
        <span  data-option="C">C</span>
        <?php
        if (!empty($status->selected_answer) && $status->selected_answer == 'C') {
            ?> <input class="select_option" type="radio" name="option" value="C" checked="">
        <?php } else {
            ?><input class="select_option" type="radio" name="option" value="C">
        <?php }
        ?>
        <label> <?= $ques->answer3 ?></label>

    </div>
    <div class="ansbox ques_option1" id="">
        <span  data-option="D">D</span>
        <?php
        if (!empty($status->selected_answer) && $status->selected_answer == 'D') {
            ?> <input class="select_option" type="radio" name="option" value="D" checked="">
        <?php } else {
            ?><input class="select_option" type="radio" name="option" value="D">
        <?php }
        ?>
        <label> <?= $ques->answer4 ?></label>

    </div>

</div>

  


        <script>

            $(".select_option").click(function () {
                var option = $(this).val();
                var examid = $("#excam_id").val();
                var qid = $("#question_id").val();
                var qno = $("#question_no").val();
                //  alert(option);

                $.ajax({
                    url: '<?= base_url() ?>Exam/user_seleted_option',
                    type: 'POST',
                    data: {
                        selected_answer: option,
                        exam_id: examid,
                        question_id: qid,
                        question_no: qno

                    },
                    success: function (response) {
                     

                    }
                });

            });

        </script>