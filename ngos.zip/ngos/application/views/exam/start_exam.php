<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Exam Questions</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
        <link rel="shortcut icon" href="<?= base_url('') ?>assets/admin/img/Ngo.png">
        <style>
            .tab-content{

                /* background:pink;
                color:#fff; */

            }
            .ansbox span {
                float: left;
                margin-right: 10px;
                width: 20px;
                height: 20px;
                border: 1px solid #cccccc;
                border-radius: 50%;
                text-align: center;
                font-size: 12px;
                line-height: 18px;
                font-weight: bold;
                margin-top: 3px;
                padding-left: 1px;
            }
            .ansbox {
                clear: both;
                overflow: hidden;
                margin-bottom: 12px;
                border: 1px solid #cccccc;
                padding: 10px 15px;
                border-radius: 5px;
                cursor: pointer;
            }
            .rhspart {
                width: 30%;
                float: right;
                /* background-color: #dcdcdc; */
                text-align: center;
                padding-top: 5px;
            }
            .rhspart ul li a{
                background: green;
                font-weight: bold;
                color: #fff;
                padding: 8px 16px;
            }
            .lhspart{
                float:left;
                width:70%;
            }
            .ques-cont{

                display: block;
                clear: both;
                overflow: hidden;
                padding: 10px 0;
            }

            .nav-tabs .nav-link {
                border: 0px;
                border-top-left-radius: 0rem;
                border-top-right-radius: 0rem;
            }
            .nav-tabs {
                border-bottom: 0px;
            }
            .nav-tabs .nav-item.show .nav-link, .nav-tabs .nav-link.active {
                color: #fff;
                background-color: red;
                /* border-color: #dee2e6 #dee2e6 #fff; */
            }
            .nav-tabs .nav-item {
                margin: 2px;
            }
            .rhspart ul li:last-child a {
                background: #fff;
                font-weight: bold;
                color: #fff;
            }

            .rhspart ul li:last-child .nav-link.active{
                background: #fff;
            }
            .nav-tabs .nav-link {
                border: 0px;
                width: 49px;
                height: 39px;
                padding: 7px;
            }
        </style>
    </head>
    <body>
        <h2>Time Left <p id="demo"></p></h2>  
        <?php
        $date = explode('/', $exams->exam_date);
        $dateformat = implode('-', $date);
        $dateformat = explode('-', $dateformat);
        $monthNum = $dateformat[1];
        $monthName = date('F', mktime(0, 0, 0, $monthNum, 10)); // March
        $time = date("H:i", strtotime($exams->exam_duration));
        $datetime = $monthName . ' ' . $dateformat[0] . ' ' . $dateformat[2] . ' ' . $time;
        ?>


        <div class="container">
            <!-- <div class="row"> -->
            <div class="ques-cont">
            <!-- <section> -->
                <div class="rhspart">
                    <ul class="nav nav-tabs" role="tablist">
                        <?php
                        $questions = $this->Admin_model->get_uniq_exam_questionCount($exams->exam_id);
                        foreach ($questions as $ques) {
                            ?> <li role="presentation" class="nav-item q">
                                <a href="#<?php echo $ques->question_number; ?> " class="nav-link disable ques_num"  data-exnum="<?= $ques->exam_id ?>" data-qnum="<?= $ques->question_number ?>" data-toggle="tab" aria-controls="step1" role="tab">
                                    <?= $ques->question_number ?>
                                </a>
                            </li>
                        <?php }
                        ?>
                        <li role="presentation" class="nav-item">
                            <a href="#complete" class="nav-link disable" data-toggle="tab" aria-controls="complete" role="tab">

                            </a>
                        </li>
                    </ul>
                </div>
                <div class="lhspart answer_res">
                    <form role="form">
                        <div class="tab-content ques_resp">

                            <?php
                            $i = 1;
                            foreach ($questions as $ques) {
                                if ($i == 1) {
                                    $status = $this->Exam_model->get_uniq_UserandQuestion_answer($ques->exam_id, $ques->question_id, $ques->question_number);
                                    ?>  <div class="tab-pane active" role="tabpanel" id="<?= $ques->question_number ?>">

                                        <p id=""><strong>Q<?= $ques->question_number ?>.</strong>&nbsp;<?= $ques->question_name ?>  </p>

                                        <div class="ansbox ques_option active false" id="">
                                            <input type="hidden" name="ques_no" id="question_no" value="<?= $ques->question_number ?>">
                                            <input type="hidden" name="exam_id" id="excam_id" value="<?= $ques->exam_id ?>">
                                            <input type="hidden" name="ques_id" id="question_id" value="<?= $ques->question_id ?>">
                                            <span  data-option="A">A</span>
                                            <?php
                                            if (!empty($status->selected_answer) && $status->selected_answer == 'A') {
                                                ?> <input class="select_option" type="radio" name="option" value="A" checked="">
                                            <?php } else {
                                                ?><input class="select_option" type="radio" name="option" value="A">
                                            <?php }
                                            ?>

                                            <label> <?= $ques->answer1 ?></label>

                                        </div>
                                        <div class="ansbox ques_option1" id="">
                                            <span  data-option="B">B</span>
                                            <?php
                                            if (!empty($status->selected_answer) && $status->selected_answer == 'B') {
                                                ?> <input class="select_option" type="radio" name="option" value="B" checked="">
                                            <?php } else {
                                                ?><input class="select_option" type="radio" name="option" value="B">
                                            <?php }
                                            ?>
                                            <label><?= $ques->answer2 ?></label>

                                        </div>
                                        <div class="ansbox ques_option1" id="">
                                            <span  data-option="C">C</span>
                                            <?php
                                            if (!empty($status->selected_answer) && $status->selected_answer == 'C') {
                                                ?> <input class="select_option" type="radio" name="option" value="C" checked="">
                                            <?php } else {
                                                ?><input class="select_option" type="radio" name="option" value="C">
                                            <?php }
                                            ?>
                                            <label> <?= $ques->answer3 ?></label>

                                        </div>
                                        <div class="ansbox ques_option1" id="">
                                            <span  data-option="D">D</span>
                                            <?php
                                            if (!empty($status->selected_answer) && $status->selected_answer == 'D') {
                                                ?> <input class="select_option" type="radio" name="option" value="D" checked="">
                                            <?php } else {
                                                ?><input class="select_option" type="radio" name="option" value="D">
                                            <?php }
                                            ?>
                                            <label> <?= $ques->answer4 ?></label>

                                        </div>

                                    </div>
                                <?php }
                                ?>
                                <?php
                                $i++;
                            }
                            ?>









                            <div class="tab-pane" role="tabpanel" id="complete">
                               
                                <h3>Complete</h3>
                                <p>You have successfully completed all questions.</p>

                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <button type="button"  id="submit_exam" style="display:none;">Submit</button>
                    </form>

                </div>
                <!-- </section> -->
            </div>
        </div>

        <!-- Trigger the modal with a button -->
        <button type="button" class="btn btn-info btn-lg" id="exam_submit" data-toggle="modal" data-target="#myModal" style="display:none;">Open Modal</button>

        <!-- Modal -->
        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"></h4>
                    </div>
                    <div class="modal-body">
                        <p>Time UP And Your Answers are submitted</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>

            </div>
        </div>


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

        <script>

            // Set the date we're counting down to
            var countDownDate = new Date("<?php echo $datetime; ?> ").getTime();

// Update the count down every 1 second
            var x = setInterval(function () {

                // Get todays date and time
                var now = new Date().getTime();

                // Find the distance between now and the count down date
                var distance = countDownDate - now;

                // Time calculations for days, hours, minutes and seconds
                var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                // Output the result in an element with id="demo"


                if (days === 0) {
                    document.getElementById("demo").innerHTML = hours + "h " + minutes + "m " + seconds + "s ";
                }

                if (hours === 0) {
                    document.getElementById("demo").innerHTML = minutes + "minutes " + seconds + "seconds ";
                }

                if (minutes === 0) {
                    document.getElementById("demo").innerHTML = seconds + "seconds ";
                }



                // If the count down is over, write some text 
                if (distance < 0) {
                    clearInterval(x);
                    document.getElementById("submit_exam").click();
                }
            }, 1000);
        </script>


        <script>

            $("#submit_exam").click(function () {
                // alert();
                document.getElementById("exam_submit").click();
                $.ajax({
                    url: '<?= base_url() ?>Exam/get_exam_marks',
                    type: 'POST',
                    data: {
                      


                    },
                    success: function (response) {
                         $(".answer_res").html(response);

                    }
                });

            });


            $(document).ready(function () {
                //Initialize tooltips
                $('.nav-tabs > li a[title]').tooltip();

                //Wizard
                $('a[data-toggle="tab"]').on('show.bs.tab', function (e) {

                    var $target = $(e.target);

                    if ($target.parent().hasClass('disabled')) {
                        return false;
                    }
                });

                $(".next-step").click(function (e) {
                    alert();
                    var $active = $('.nav-tabs li>a.active');
                    $active.parent().next().removeClass('disabled');
                    nextTab($active);

                });
                $(".prev-step").click(function (e) {
                    alert();
                    var $active = $('.nav-tabs li>a.active');
                    prevTab($active);

                });
            });


            function nextTab(elem) {
                $(elem).parent().next().find('a[data-toggle="tab"]').click();
            }
            function prevTab(elem) {
                $(elem).parent().prev().find('a[data-toggle="tab"]').click();
            }

            $(".ques_num").click(function () {
                var examid = $(this).attr("data-exnum");
                var qnum = $(this).attr("data-qnum");
                //  alert(qnum);
                //   alert(examid);

                $.ajax({
                    url: '<?= base_url() ?>Exam/show_uniq_question',
                    type: 'POST',
                    data: {
                        qnum: qnum,
                        examid: examid


                    },
                    success: function (response) {
                        $(".ques_resp").html(response);

                    }
                });
            });

            $(".select_option").click(function () {
                var option = $(this).val();
                var examid = $("#excam_id").val();
                var qid = $("#question_id").val();
                var qno = $("#question_no").val();
                //  alert(option);

                $.ajax({
                    url: '<?= base_url() ?>Exam/user_seleted_option',
                    type: 'POST',
                    data: {
                        selected_answer: option,
                        exam_id: examid,
                        question_id: qid,
                        question_no: qno

                    },
                    success: function (response) {
                     

                    }
                });

            });

        </script>
    </body>
</html>