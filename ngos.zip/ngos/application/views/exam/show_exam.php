

<!-- CONTENT AREA -->
<div class="content-area">

    <!-- PAGE --> <?php
    if ($this->session->flashdata('login_fail')) {
        ?>
        <div class="alert alert-danger text-center" style="z-index:1055;margin:auto;position:absolute;top:5px;right:500px;"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo $this->session->flashdata('login_fail') ?>
        </div>
    <?php } ?>

    <?php
    if ($this->session->flashdata('update_pass_sucs')) {
        ?>
        <div class="alert alert-success text-center" style="z-index:1055;margin:auto;position:absolute;top:5px;right:500px;"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo $this->session->flashdata('update_pass_sucs') ?>
        </div>
    <?php } ?>

    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->


    <section class="page-section">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade active in" id="tab-2" style="">
                    <div class="">
                        <div class="col-md-12 col-sm-6 col-md-offset-">									
                            <div class="row">
                                <div class="message-box">
                                    <div class="message-box-inner">
                                        <font id="exam_start" style="font-size:40px;color:#ffffff;">Exam will be starts in <p id="demo"></p></h2>
                                    </div>
                                </div>

                                <div class='col-md-6 col-md-offset-3'>


                                    <?php
                                    header('Access-Control-Allow-Origin: *');
                                    header("Access-Control-Allow-Credentials: true");
                                    header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
                                    header('Access-Control-Max-Age: 1000');
                                    header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');

                                    $date = explode('/', $exams->exam_date);
                                    $dateformat = implode('-', $date);
                                    $dateformat = explode('-', $dateformat);
                                    $monthNum = $dateformat[1];
                                    $monthName = date('F', mktime(0, 0, 0, $monthNum, 10)); // March
                                    $time = date("H:i", strtotime($exams->exam_time));
                                    $datetime = $monthName . ' ' . $dateformat[0] . ' ' . $dateformat[2] . ' ' . $time;


                                    $date1 = explode('/', $exams->exam_date);
                                    $dateformat1 = implode('-', $date1);
                                    $dateformat1 = explode('-', $dateformat1);
                                    $monthNum1 = $dateformat1[1];
                                    $monthName1 = date('F', mktime(0, 0, 0, $monthNum1, 10)); // March
                                    $time1 = date("H:i", strtotime($exams->exam_duration));
                                    $datetime1 = $monthName1 . ' ' . $dateformat1[0] . ' ' . $dateformat1[2] . ' ' . $time1;
                                    ?>
                                </div>

                            </div>	
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- /PAGE -->              
</div>
<!-- /CONTENT AREA -->








<script>

    // Set the date we're counting down to
    var countDownDate = new Date("<?php echo $datetime; ?> ").getTime();

// Update the count down every 1 second
    var x = setInterval(function () {

        // Get todays date and time
        var now = new Date().getTime();

        // Find the distance between now and the count down date
        var distance = countDownDate - now;

        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Output the result in an element with id="demo"


        if (days === 0) {
            document.getElementById("demo").innerHTML = hours + "Hours " + minutes + "Minutes " + seconds + "Seconds ";
        }

        if (hours === 0) {
            document.getElementById("demo").innerHTML = minutes + "Minutes " + seconds + "Seconds ";
        }

        if (minutes === 0) {
            document.getElementById("demo").innerHTML = seconds + "Seconds ";
        }




        // If the count down is over, write some text 
        if (distance < 0) {
            clearInterval(x);
            examduration();
            document.getElementById("exam_start").innerHTML = ' <button type="button" class="btn btn-warning btn-lg" onclick="myfunction()">Start Exam</button>';




        } else {

        }
    }, 1000);
</script>

<script>
    function examduration() {
        // Set the date we're counting down to
        // alert();
        var countDownDate = new Date("<?php echo $datetime1; ?> ").getTime();


// Update the count down every 1 second
        var x = setInterval(function () {

            // Get todays date and time
            var now = new Date().getTime();

            // Find the distance between now and the count down date
            var distance = countDownDate - now;

            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Output the result in an element with id="demo"


            if (days === 0) {
                document.getElementById("demo").innerHTML = hours + "h " + minutes + "m " + seconds + "s ";
            }

            if (hours === 0) {
                document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s ";
            }

            if (minutes === 0) {
                document.getElementById("demo").innerHTML = seconds + "s ";
            }





            // If the count down is over, write some text 
            if (distance < 0) {
                //alert(distance);
                clearInterval(x);
                document.getElementById("exam_start").innerHTML = ' <button type="button" class="btn btn-danger btn-lg">EXPIRED</button>';
            }
        }, 1000);
    }

    function myfunction() {
        window.location.href = "<?php echo base_url('questions') ?>";
    }
</script>
