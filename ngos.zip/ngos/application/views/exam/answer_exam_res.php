<div class="lhspart">
    <form role="form">
        <div class="tab-content ques_resp">

            <?php
            $examid = "";
            $marks = 0;
            $total_marks = 0;
            $qualify_marks = 0;
            foreach ($answers as $ans) {
                $totmarks = $this->Exam_model->exam_details($ans->exam_id);
                $status = $this->Exam_model->get_total_marks_ofuser($ans->exam_id, $ans->question_id, $ans->question_num);
                if (!empty($status)) {
                    if ($status->correct_answer == $ans->selected_answer) {
                        $marks++;
                        $examid = $ans->exam_id;
                        $total_marks = $totmarks->total_marks;
                        $qualify_marks = $totmarks->total_qmarks;
                    }
                }
                ?>  

            <?php }
            if($marks == $qualify_marks || $marks > $qualify_marks  ){
                $status = 'qualified';
                $mraks_resp = $this->Exam_model->exam_results_details($examid,$total_marks,$qualify_marks,$marks,$status);
            }else{
                $status = 'notqualified';
                $mraks_resp = $this->Exam_model->exam_results_details($examid,$total_marks,$qualify_marks,$marks,$status);
            }
           
            ?>


            <h2>Your Total Marks: <?= $marks ?></h2>







            <div class="clearfix"></div>
        </div>

    </form>

</div>