<?php
if ($this->session->flashdata('nat_ngo_fail')) {
                                ?>
                                <div class="alert alert-danger text-center" style="z-index:1055;margin:auto;position:absolute;top:5px;right:500px;"> 
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <?php echo $this->session->flashdata('nat_ngo_fail') ?>
                                </div>
    <?php } ?>

<!-- CONTENT AREA -->
<div class="content-area">

    <!-- PAGE -->
    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->

    <!-- PAGE-->
    <section class="page-section">
        <div class="container">
            <div class="message-box">
                <?php
                if (!empty($banner->bn_text)) {
                    ?> <div class="message-box-inner">
                        <h2><?= $banner->bn_text ?> </h2>
                    </div>
                <?php } else {
                    ?><div class="message-box-inner">
                        <h2>This is International Ngos Network Only For Advertising Purpose </h2>
                    </div>
                <?php }
                ?>
            </div>
        </div>
    </section>
    <!-- /PAGE -->
    <section class="page-section">
        <div class="container">



            <div class="tab-content">

                <!-- tab 2 -->
                <div class="tab-pane fade active in" id="tab-2">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="">
                                <div class="message-box-inner">
                                    <p align="center" style='font-size:19px;color:black'>This Site is 100% legal ,
                                        any member registered will be paid GST 18% service tax Government of India </p>
                                   
                                </div>
                               
                                <div class="social-box">
                                    <li align="center" style='font-size:19px;color:blue'><a href="#">Our Youtube link</a></li>
                                    <li align="center" style='font-size:19px;color:blue'><a href="#">Our Facebook link</a></li>
                                    <li align="center" style='font-size:19px;color:blue'><a href="#">Our Twitter link</a></li>
                                </div>
                                
                                 <div class="social-box">
                                    <li align="center" style='font-size:19px;color:blue'><a href="<?= base_url('exam_registration')?>"> INNW Job's online  exam notification</a></li>
                                   
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="">
                                 
                                <div class="message-box-inner">
                                    <?php
                                    if(!empty($notifications)){
                                        foreach($notifications as $nt){
                                            $type = str_replace(' ', '_', $nt->type);
                                            ?> <span style='color:red'><a href='<?= base_url('view_notification/'.$type)?>' target="_blank"><span class="blinking" style='font-size:'><?=$nt->nt_name?></span> </a></span>
                                     <?php   }
                                        
                                    }
                                    ?>
                                  
                                  
                                   
                                </div>
                            </div>
                        </div>
                        

                        <?php
                        $memebership = $this->Ngos_model->get_memebership_details();
                        foreach ($memebership as $ms) {
                            ?><div class="col-md-12 col-sm-6">
                                <div class="thumbnail no-border no-padding">
                                    <div class="media">
                                        <div class=''>
                                            <div class='col-md-6 col-sm-6'>
                                                <h3><?=$ms->ms_scheme?> </h3>
                                            </div>
                                            <div class='col-md-3 col-sm-6'>
                                                <h3>Price Rs <?=$ms->price?> /- </h3>
                                            </div>
                                            <div class='col-md-3 col-sm-6'>
                                                <h4> 
                                                    <span style='color:red'><a href='<?= base_url('registration/'.$ms->ms_type)?>'><span class="blinking" style='font-size:'>Add Your Profile</span> </a></span>&nbsp;  
                                                    <?php
                                                    $brtype = $this->Admin_model->get_brocuher_type($ms->ms_type);
                                                    if(!empty($brtype->br_document)){
                                                        ?> <span style='color:red'><a href='<?= base_url('').$brtype->br_document?>' target="_blank"><span class="blinking" style='font-size:'>View Brochure</span><embed src="<?= base_url('').$brtype->br_document?>" width="500" height="375" style="display:none;"type='application/pdf'> </a></span>
                                                   <?php }
                                                    ?>
                                                   
                                                  
                                                    
                                                    
                                                    
                                                    
                                                </h4>
                                            </div>
                                        </div>	
                                    </div>
                                </div>
                            </div>
                        <?php }
                        ?>



                       


                       

                    </div>
                </div>

                <!-- tab 3 -->

            </div>

        </div>
    </section>
    <!-- /PAGE -->              
</div>
<!-- /CONTENT AREA -->