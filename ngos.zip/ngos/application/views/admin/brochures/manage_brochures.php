<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Manage Brouchers</h1>
        </div>
        <!--End Page Header -->
    </div>


    <div class="row">
        <div class="col-lg-12">
            <!-- Form Elements -->
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-12">

                            <div class="table-responsive">
                                <form method="post" > 
                                    <table class="table table-striped table-responsive table-hover">
                                        <thead>
                                            <tr>
                                                <th><input type="checkbox" name="chk_b" id="check_all" class="checkall"></th>

                                                <th>Broucher Type</th>

                                                <th>View/Download Broucher</th>

                                                <th><i class="fa fa-pencil-square-o"></i></th>
                                                <th><i class="fa fa-trash-o"></i></th>
                                            </tr>
                                        </thead>

                                        <tbody id="search_resp">
                                            <?php
                                            foreach ($brouchers as $br) {
                                                ?><tr id="brouch_response<?= $br->br_id ?>">
                                                    <td><input type="checkbox" name="users[]" value=""  class="checkbox1"/></td>

                                                    <td>
                                                        <a href="javascript:void(0)"><?= $br->type ?></a>
                                                    </td> 

                                                    <td>
                                                        <a href='<?= base_url('') . $br->br_document ?>' target="_blank">View/Download Brochure<embed src="<?= base_url('') . $br->br_document ?>" width="500" height="375" style="display:none;"type='application/pdf'> </a> 
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;"  class="btn btn-success btn-xs  edit_broucher"  data-br-type="<?= $br->type ?>" data-br-id="<?= $br->br_id ?>" data-toggle="modal" data-target="#edit_broucher_pop"><i class="fa fa-pencil-square-o"></i></a>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;" class="btn btn-danger btn-xs  delete_broucher" data-br-id="<?= $br->br_id ?>" data-toggle="modal" data-target="#del_broucher_pop"><i class="fa fa-trash-o "></i></a>
                                                    </td>
                                                </tr>
                                            <?php }
                                            ?>


                                        </tbody>

                                    </table>



                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- end page-wrapper -->
</body>

</html>


<div id="edit_broucher_pop" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close edit_broucher_close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit Broucher</h4>
            </div>
            <div class="modal-body">
                <form id="edit_brocher_form">


                    <div class="form-group row">
                        <div class="col-md-12">
                            <label for="ex1" style="color:initial;">Type</label>
                            <input class="form-control" name="brochuer_type"  id="br_edittype" type="text" value="" readonly="">
                        </div>   
                    </div>


                    <div class="form-group row">
                        <div class="col-md-12">
                            <font style="color:red;font-size:25px;">Note:(Only PDF document's are allowed)</font><br>
                            <label for="ex1" style="color:initial;">Upload PDF Document</label>
                            <input type="file" id="add_brouch"  name="brochu_document" style="display:none"  required=""/>
                            <img class="show_img"  src="<?= base_url('assets/admin/img/upload.png') ?>" style='height:90px;width:220px;object-fit: contain;cursor:pointer;'id="upfile1" /> 

                        </div>
                    </div>

                    <input type="hidden" name="broucher_id" value=""  id="br_editid">
                    <input class="form-control btn btn-success" id="submit_person" type="Submit" value="Save">

                </form>
            </div>

        </div>

    </div>
</div>


<div id="del_broucher_pop" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close del_broucher_close" id="close-approve-popup" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Are you sure you want to delete.?</h4>
            </div>
            <div class="modal-body">
                <input type="hidden" id="br_id">
                <input type="hidden" id="cid_">
                <button type="submit" class="btn btn-success" id="del_yes" autofocus>Yes</button>
                <button type="submit" class="btn btn-danger" data-dismiss="modal" style="float:right;" >No</button>

            </div>
        </div>

    </div>
</div>


<script
    src="https://code.jquery.com/jquery-3.3.1.js"
    integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
crossorigin="anonymous"></script>

<script>
    $(".delete_broucher").click(function () {
        var br_id = $(this).attr("data-br-id");
        $("#br_id").val(br_id);
    });

    $(".edit_broucher").click(function () {
        var br_id = $(this).attr("data-br-id");
        var br_type = $(this).attr("data-br-type");
        $("#br_editid").val(br_id);
        $("#br_edittype").val(br_type);
    });

    $("body").on('click', '#upfile1', function () {
        $("#add_brouch").trigger('click');
    });


    $("#del_yes").click(function () {
        var brid = $("#br_id").val();
        // alert(authid);

        $.ajax({
            url: "<?= base_url('admin/_Admin/delete_broucher') ?>",
            type: "POST",
            data: {
                brid: brid
            },
            success: function (response) {
                if (response === 'deleted') {

                    $("#brouch_response" + brid).html('<div class="alert alert-info alert-dismissible">\n\
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
<strong>Sucess!</strong> Deleted successfully.\n\
</div>');
                    $(".del_broucher_close").click();
                    $("#brouch_response" + brid).fadeOut(5000);

                }

            }
        });
    });


    $("#edit_brocher_form").on('submit', (function (event) {
        event.preventDefault();
        $.ajax({
            url: "<?= base_url('admin/_Admin/add_brocuhers') ?>",
            type: "POST",
            data: new FormData(this),
            cache: false,
            contentType: false,
            processData: false,

            success: function (response) {
                if (response === 'submitted') {
                    $(".edit_broucher_close").click();

                    window.location.reload();


                } else if (response === 'submit_all') {
                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Oops!</strong> Please select all data.\n\
  </div>');
                }
            }
        });
    }));
</script>
