

<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Add International Broucher</h1>
            <font id="limt_persons" style="color:red;font-size:20px;"></font>
        </div>
        <!--End Page Header -->
        <div class="show_res" style="position:absolute;top:89px;z-index:1063;right:421px;"></div>

        <form id="add_brocher_form">
           

            <div class="form-group row">
                <div class="col-md-4">
                    <label for="ex1" style="color:initial;">Type</label>
                    <input class="form-control" name="brochuer_type"  type="text" value="International" readonly="">
                </div>   
            </div>


            <div class="form-group row">
                <div class="col-md-8">
                    <font style="color:red;font-size:25px;">Note:(Only PDF document's are allowed)</font><br>
                    <label for="ex1" style="color:initial;">Upload PDF Document</label>
                    <input type="file" id="add_brouch"  name="brochu_document" style="display:none"  required=""/>
                    <img class="show_img"  src="<?= base_url('assets/admin/img/upload.png') ?>" style='height:90px;width:220px;object-fit: contain;cursor:pointer;'id="upfile1" /> 

                </div>
            </div>
              <div class="row col-md-2">
                <input class="form-control btn btn-success" id="submit_person" type="Submit" value="Add Broucher">
            </div>
        </form>
    </div>
</div>



<script src="<?= base_url('assets/admin') ?>/plugins/jquery-1.10.2.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/bootstrap/bootstrap.min.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/metisMenu/jquery.metisMenu.js"></script>

<script src="<?= base_url('assets/admin') ?>/scripts/siminta.js"></script>

<script src="<?= base_url('assets/admin') ?>/plugins/morris/raphael-2.1.0.min.js"></script>

<script>
                        $("body").on('click', '#upfile1', function () {
                            $("#add_brouch").trigger('click');
                        });


                        $("#add_brocher_form").on('submit', (function (event) {
                            event.preventDefault();
                            $.ajax({
                                url: "<?= base_url('admin/_Admin/add_brocuhers') ?>",
                                type: "POST",
                                data: new FormData(this),
                                cache: false,
                                contentType: false,
                                processData: false,

                                success: function (response) {
                                    if (response === 'submitted') {

                                        $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Sucess!</strong> Data has been added successfully.\n\
  </div>');

                                        document.getElementById('add_brocher_form').reset();
                                        $(".show_res").fadeOut(2000);
                                        window.location.reload();


                                    } else if (response === 'submit_all') {
                                        $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Oops!</strong> Please select all data.\n\
  </div>');
                                    }
                                }
                            });
                        }));
</script>