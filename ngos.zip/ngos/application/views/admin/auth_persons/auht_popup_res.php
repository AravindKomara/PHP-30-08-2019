<div class="col-md-12">
<div class="col-md-4 pad-right-10">
    <div class="n-img">
                                                <img src='<?= base_url('') . $auth_person->auth_image ?>' style='height:140px;float:left;width:164px;border:2px solid #000;'>
                                            </div>
</div>
<div class="col-md-7 pad-left-0" >
     <div class="matter" style="text-align:left;">
                                             
                                                <p>Designation: (<?= $auth_person->auth_desgination.' '.$auth_person->auth_jobtype ?>)</p>
                                                
                                                <p>Name: <?= $auth_person->auth_name ?></p>
                                                <b>Mobile: +91 <?= $auth_person->auth_mobile ?></b>
                                                <?php
                                                if($auth_person->auth_type == 'International'){
                                                    ?><p>Country: <?= $auth_person->auth_country ?></p>
                                               <?php }elseif($auth_person->auth_type == 'National'){
                                                   ?><p>Country: <?= $auth_person->auth_country ?></p>
                                              <?php }elseif($auth_person->auth_type == 'State'){
                                                  ?><p>State: <?= $auth_person->auth_state ?></p>
                                             <?php }else{
                                                 ?><p>District: <?= $auth_person->auth_district ?></p>
                                             <?php }
                                                ?>
                                                                        </div>
</div>
    <div class="col-md-12">
 <p><?= $auth_person->auth_description	 ?></p>   
    </div>
</div>                                    
                                      