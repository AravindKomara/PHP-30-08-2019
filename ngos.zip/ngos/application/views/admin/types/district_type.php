

<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Add District Types</h1>
        </div>
        <!--End Page Header -->
        <div class="show_res" style="position:absolute;top:89px;z-index:1063;right:421px;"></div>

        <form id="add_types_form">
            <div class="form-group row">
                <div class="col-md-12">
                    <label for="ex1" style="color:initial;">Add Types</label>
                    <input class="form-control" name="add_type_options" placeholder="District Types"  type="text" required="">
                    <input class="form-control" name="add_type"  type="hidden" value="<?= $type ?>" readonly="">
                </div>

            </div>
            <div class="row col-md-2">
                <input class="form-control btn btn-success" id="submit_banner" type="Submit" value="Add Types">
            </div>
        </form>
        <br><br>
        <h2>Manage Types</h2>
        <div class="row">
            <div class="col-lg-12">
                <!-- Form Elements -->
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-sm-12">

                                <div class="table-responsive">
                                    <form method="post" > 
                                        <table class="table table-striped table-responsive table-hover">
                                            <thead>
                                                <tr>
                                                    <th><input type="checkbox" name="chk_b" id="check_all" class="checkall"></th>

                                                    <th>Type</th>
                                                    <th><i class="fa fa-pencil-square-o"></i></th>
                                                    <th><i class="fa fa-trash-o"></i></th>
                                                </tr>
                                            </thead>

                                            <tbody id="search_resp">
                                                <?php
                                                foreach ($types as $t) {
                                                    ?><tr id="type_response<?= $t->id ?>">
                                                        <td><input type="checkbox" name="users[]" value=""  class="checkbox1"/></td>

                                                        <td>
                                                            <a href="javascript:void(0)"><?= $t->auth_type ?></a>
                                                        </td> 

                                                        <td>
                                                            <a href="javascript:void(0)"  class="btn btn-success btn-xs  edit_type_text"  data-type-text= "<?= $t->auth_type ?>" data-type-id="<?= $t->id ?>" data-toggle="modal" data-target="#edit_type_pop"><i class="fa fa-pencil-square-o"></i></a>
                                                        </td>
                                                        <td>
                                                            <a href="javascript:;" class="btn btn-danger btn-xs  delete_type" data-type-id="<?= $t->id ?>" data-toggle="modal" data-target="#del_type_pop"><i class="fa fa-trash-o "></i></a>
                                                        </td>
                                                    </tr>
                                                <?php }
                                                ?>


                                            </tbody>

                                        </table>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<div id="edit_type_pop" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close edit_auth_close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit Type</h4>
            </div>
            <div class="modal-body">
                <div class="form-group row">
                    <div class="col-md-12">
                        <label for="ex1" style="color:initial;">Type</label>
                        <input class="form-control" name="edit_text" value=""  type="text" id="type_text">
                        <input type="hidden" id="type_id">
                        <input type="hidden" id="get_type" value="<?= $type ?>">
                    </div>

                </div>
                <div class="row col-md-2">
                    <input class="form-control btn btn-success" id="edit_type_yes" type="Submit" value="Submit">
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>




<div id="del_type_pop" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close del_type_close" id="close-approve-popup" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Are you sure you want to delete.?</h4>
            </div>
            <div class="modal-body">
                 <input type="hidden" id="type_id">
                 <input type="hidden" id="get_type" value="<?= $type ?>">
                <button type="submit" class="btn btn-success" id="type_del_yes" autofocus>Yes</button>
                <button type="submit" class="btn btn-danger" data-dismiss="modal" style="float:right;" >No</button>

            </div>
        </div>

    </div>
</div>

<script src="<?= base_url('assets/admin') ?>/plugins/jquery-1.10.2.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/bootstrap/bootstrap.min.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/metisMenu/jquery.metisMenu.js"></script>

<script src="<?= base_url('assets/admin') ?>/scripts/siminta.js"></script>

<script src="<?= base_url('assets/admin') ?>/plugins/morris/raphael-2.1.0.min.js"></script>

<script>

    $("#add_types_form").on('submit', (function (event) {
        event.preventDefault();
        $.ajax({
            url: "<?= base_url('admin/_Admin/add_types') ?>",
            type: "POST",
            data: new FormData(this),
            cache: false,
            contentType: false,
            processData: false,

            success: function (response) {
                if (response === 'submitted') {

                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Sucess!</strong> Data has been added successfully.\n\
  </div>');

                    document.getElementById('add_types_form').reset();
                    window.location.reload();


                } else if (response === 'submit_all') {
                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Oops!</strong> Please select all data.\n\
  </div>');
                }
            }
        });
    }));


    $(".edit_type_text").click(function () {
        var text = $(this).attr("data-type-text");
        var id = $(this).attr("data-type-id");

        //alert(text);
        //  alert(id);

        $("#type_text").val(text);
        $("#type_id").val(id);
    });


    $("#edit_type_yes").click(function () {
        var id = $("#type_id").val();
        var text = $("#type_text").val();
        var type = $("#get_type").val();
        //  alert(id);
        //  alert(text);
        //   alert(type);

        $.ajax({
            url: "<?= base_url('admin/_Admin/edit_desig_type') ?>",
            type: "POST",
            data: {
                id: id,
                text: text,
                type: type
            },
            success: function (response) {
                if (response === 'edited') {

                    $("#type_response" + id).html('<div class="alert alert-info alert-dismissible">\n\
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
<strong>Sucess!</strong> Edited successfully.\n\
</div>');
                    $(".edit_auth_close").click();
                    // $("#type_response"+id).fadeOut(5000);
                    window.location.reload();

                }

            }
        });
    });
    
    
     $(".delete_type").click(function () {
        var id = $(this).attr("data-type-id");
       // alert(id);
        $("#type_id").val(id);
    });


    $("#type_del_yes").click(function () {
        var id = $("#type_id").val();
         var type = $("#get_type").val();
       // alert(id);
       //   alert(type);

        $.ajax({
            url: "<?= base_url('admin/_Admin/delete_type') ?>",
            type: "POST",
            data: {
                id: id,
                type: type
            },
            success: function (response) {
                if (response === 'deleted') {
                   
                    $("#type_response" + id).html('<div class="alert alert-info alert-dismissible">\n\
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
<strong>Sucess!</strong> Deleted successfully.\n\
</div>');
   
    $("#type_response"+id).fadeOut(3000);
      $(".del_type_close").click();
      window.location.reload();
                  
          }

            }
        });
    });


</script>