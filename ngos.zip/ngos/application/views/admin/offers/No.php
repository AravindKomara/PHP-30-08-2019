

<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">National Offers</h1>
            <font id="limt_offer" style="color:red;font-size:20px;"></font>
        </div>
        <!--End Page Header -->
        <div class="show_res" style="position:absolute;top:89px;z-index:1063;right:421px;"></div>

        <form id="add_offer_form">
            <div class="form-group row">
                <div class="col-md-4">
                    <label for="ex1" style="color:initial;">Offer Type</label>
                    <input class="form-control" name="offer_type"  id="offer_type" type="text" readonly value="National">
                </div>
                <div class="col-md-8">

                    <img src="<?= base_url('assets/admin/img/upload.png') ?>" style='height:90px;width:120px;object-fit: contain;cursor:pointer;'id="upfile1" /> 
                    <input type="file" id="file1"  name="offer_image" style="display:none" />
                    <label for="ex1" style="color:initial;">Upload Image</label>
                </div>
            </div>

            <div class="row col-md-2">
                <label for="ex1" style="color:initial;">Description:</label>
               <textarea rows="30" cols="150" name="description"></textarea>
                <input class="form-control btn btn-success" id="submit_offers" type="Submit" value="Add offer">
            </div>
        </form>
    </div>
</div>

<script src="<?= base_url('assets/admin') ?>/plugins/jquery-1.10.2.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/bootstrap/bootstrap.min.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/metisMenu/jquery.metisMenu.js"></script>

<script src="<?= base_url('assets/admin') ?>/scripts/siminta.js"></script>
Page-Level Plugin Scripts
<script src="<?= base_url('assets/admin') ?>/plugins/morris/raphael-2.1.0.min.js"></script>

<script>
    $("body").on('click', '#upfile1', function () {
        $("#file1").trigger('click');
    });

    $("#add_offer_form").on('submit', (function (event) {
        event.preventDefault();
        $.ajax({
            url: "<?= base_url('admin/_Admin/add_offers') ?>",
            type: "POST",
            data: new FormData(this),
            cache: false,
            contentType: false,
            processData: false,

            success: function (response) {
                if (response === 'submitted') {
                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Sucess!</strong> Data has been added successfully.\n\
  </div>');
                    document.getElementById('sub_form').reset();
                    window.location.reload();
                } else if (response === 'count') {
                    $("#limt_offer").html('We already added 6 offers,if we want add one more offer please delete any one of the offer!!!');
                    $("#submit_offers").prop('disabled', true);
                } else if (response === 'submit_all') {
                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Oops!</strong> Please select all data.\n\
  </div>');
                }
            }
        });
    }));
</script>