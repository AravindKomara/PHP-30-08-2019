<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Manage National Offers</h1>
        </div>
        <!--End Page Header -->
    </div>


    <div class="row">
        <div class="col-lg-12">
            <!-- Form Elements -->
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-12">

                            <div class="table-responsive">
                                <form method="post" > 
                                    <table class="table table-striped table-responsive table-hover">
                                        <thead>
                                            <tr>
                                                <th><input type="checkbox" name="chk_b" id="check_all" class="checkall"></th>
                                                <th>Offer pic</th>
                                                 <th>Offer Type</th>
                                                <th>Offer Description</th>
                                                <th><i class="fa fa-pencil-square-o"></i></th>
                                                <th><i class="fa fa-trash-o"></i></th>
                                            </tr>
                                        </thead>

                                        <tbody id="search_resp">
                                            <?php
                                            foreach ($offers as $off) {
                                                ?><tr id="offer_response<?= $off->off_id ?>">
                                                    <td><input type="checkbox" name="users[]" value=""  class="checkbox1"/></td>
                                                    <td>
                                                        <?php
                                                        if (!empty($off->off_image)) {
                                                            ?><img src='<?= base_url() . $off->off_image ?>' width="50" alt="">
                                                        <?php } else {
                                                            ?><img src='<?= base_url('') ?>assets/admin/img/Ngo.png' width="50" alt="">
                                                        <?php }
                                                        ?> 
                                                    </td>
                                                    <td>
                                                        <a href="javascript:void(0)"><?= $off->off_type ?></a>
                                                    </td> 
                                                    <td>
                                                        <a href="javascript:void(0)"><?= $off->off_desc ?></a>
                                                    </td> 
                                                    
                                                    <td>
                                                        <a href="<?= base_url('edit_offers/' . $off->off_id) ?>"  target="_new" class="btn btn-success btn-xs  edit_offer"  data-nge-id="<?= $off->off_id ?>"><i class="fa fa-pencil-square-o"></i></a>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;" class="btn btn-danger btn-xs  delete_offer" data-ngd-id="<?= $off->off_id ?>" data-toggle="modal" data-target="#del_offer_pop"><i class="fa fa-trash-o "></i></a>
                                                    </td>
                                                </tr>
                                            <?php }
                                            ?>


                                        </tbody>

                                    </table>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- end page-wrapper -->
</body>

</html>


<div id="del_offer_pop" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close del_offer_close" id="close-approve-popup" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Are you sure you want to delete.?</h4>
            </div>
            <div class="modal-body">
                <input type="hidden" id="offer_id">
                <input type="hidden" id="cid_">
                <button type="submit" class="btn btn-success" id="del_yes" autofocus>Yes</button>
                <button type="submit" class="btn btn-danger" data-dismiss="modal" style="float:right;" >No</button>

            </div>
        </div>

    </div>
</div>


<script
    src="https://code.jquery.com/jquery-3.3.1.js"
    integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
crossorigin="anonymous"></script>

<script>
    $(".delete_offer").click(function () {
        var offer_id = $(this).attr("data-ngd-id");
        //alert(ng_id);
        $("#offer_id").val(offer_id);
    });


    $("#del_yes").click(function () {
        var offerid = $("#offer_id").val();
       // alert(offerid);

        $.ajax({
            url: "<?= base_url('admin/_Admin/delete_offer') ?>",
            type: "POST",
            data: {
                offerid: offerid
            },
            success: function (response) {
                if (response === 'deleted') {
                   
                    $("#offer_response" + offerid).html('<div class="alert alert-info alert-dismissible">\n\
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
<strong>Sucess!</strong> Deleted successfully.\n\
</div>');
     $(".del_offer_close").click();
    $("#offer_response"+offerid).fadeOut(5000);
                  
          }

            }
        });
    });
</script>
