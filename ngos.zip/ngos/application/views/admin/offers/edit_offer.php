

<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Edit Offers</h1>
        </div>
        <!--End Page Header -->
        <div class="show_res" style="position:absolute;top:89px;z-index:1063;right:421px;"></div>

        <form id="edit_offer_form">
            <div class="form-group row">
                <div class="col-md-4">
                    <label for="ex1" style="color:initial;">Offer Type</label>
                    <?php
                    if (!empty($offer->off_type)) {
                        ?><input class="form-control" name="offer_type"  id="offer_type" type="text" readonly value="<?= $offer->off_type ?>">
                    <?php } else {
                        ?><input class="form-control" name="offer_type"  id="offer_type" type="text" readonly value="International">
                    <?php }
                    ?>

                </div>
            </div>

            <div class="form-group row">
                <div class="col-md-8">
                    <?php
                    if (!empty($offer->off_image)) {
                        echo '<img src=' . base_url() . $offer->off_image . '  style="height:190px;width:180px;">';
                        ?><img src="<?= base_url('assets/admin/img/upload.png') ?>" style='height:90px;width:120px;object-fit: contain;cursor:pointer;'id="upfile1" /> 
                        <input type="file" id="file1"  name="offer_image" style="display:none"/>
                        <label for="ex1" style="color:initial;">Change Photo</label>
                    <?php } else {
                        ?><img src="<?= base_url('assets/admin/img/upload.png') ?>" style='height:90px;width:120px;object-fit: contain;cursor:pointer;'id="upfile1" /> 
                        <input type="file" id="file1"  name="offer_image" style="display:none"/>
                        <label for="ex1" style="color:initial;">Upload Image</label>
                    <?php }
                    ?>

                </div>
            </div>
            <div class="form-group row">
                <div class="row col-md-12">
                    <label for="ex1" style="color:initial;">Description:</label>
                    <?php
                    if (!empty($offer->off_desc)) {
                        ?><textarea class="form-control br_0" name="description" rows="20" cols="30"><?= $offer->off_desc ?></textarea>
                    <?php } else {
                        ?><textarea class="form-control br_0" name="description" rows="20" cols="30"></textarea>
                    <?php }
                    ?>
                </div>
            </div>
            <input type="hidden" name="offer_id" value="<?= $offer->off_id ?>">
            <div class="row col-md-2">
                <input class="form-control btn btn-success" id="submit_teams" type="Submit" value="Save">
            </div>
        </form>
    </div>
</div>

<script src="<?= base_url('assets/admin') ?>/plugins/jquery-1.10.2.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/bootstrap/bootstrap.min.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/metisMenu/jquery.metisMenu.js"></script>

<script src="<?= base_url('assets/admin') ?>/scripts/siminta.js"></script>
Page-Level Plugin Scripts
<script src="<?= base_url('assets/admin') ?>/plugins/morris/raphael-2.1.0.min.js"></script>

<script>
    $("body").on('click', '#upfile1', function () {
        $("#file1").trigger('click');
    });

    $("#edit_offer_form").on('submit', (function (event) {
        event.preventDefault();
        $.ajax({
            url: "<?= base_url('admin/_Admin/edit_offer_details') ?>",
            type: "POST",
            data: new FormData(this),
            cache: false,
            contentType: false,
            processData: false,

            success: function (response) {
                if (response === 'submitted') {
                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Sucess!</strong> Data has been added successfully.\n\
  </div>');
                    document.getElementById('edit_offer_form').reset();
                    window.location.reload();
                } else if (response === 'submit_all') {
                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Oops!</strong> Please select all data.\n\
  </div>');
                }
            }
        });
    }));
</script>