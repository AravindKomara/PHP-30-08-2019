<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Manage State Users</h1>
        </div>
        <!--End Page Header -->
    </div>


    <div class="row">
        <div class="col-lg-12">
            <!-- Form Elements -->
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-12">

                            <div class="table-responsive">
                                <form method="post" > 
                                    <table class="table table-striped table-responsive table-hover">
                                        <thead>
                                            <tr>
                                                <th><input type="checkbox" name="chk_b" id="check_all" class="checkall"></th>

                                                <th>Profile pic</th>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>State</th>
                                                <th>Paid Status</th>
                                                <th>UserDetails</th>
                                                <th><i class="fa fa-trash-o"></i></th>
                                            </tr>
                                        </thead>

                                        <tbody id="search_resp">
                                            <?php
                                            foreach ($users as $u) {
                                                
                                               
                                                ?><tr id="member_response<?= $u->member_id ?>">
                                                    <td><input type="checkbox" name="users[]" value=""  class="checkbox1"/></td>
                                                    <td>
                                                        <?php
                                                        if (!empty($u->profile_pic)) {
                                                            ?><img src='<?= base_url() . $u->profile_pic ?>' width="50" alt="">
                                                        <?php } else {
                                                            ?><img src='<?= base_url('') ?>assets/admin/img/Ngo.png' width="50" alt="">
                                                        <?php }
                                                        ?> 
                                                    </td>
                                                    
                                                    <td>
                                                        <a href="javascript:void(0)"><?= $u->tru_pre_name ?></a>
                                                    </td> 
                                                    <td>
                                                        <a href="javascript:void(0)"><?= $u->tru_pre_mobile1 ?></a>
                                                    </td>
                                                    
                                                    <td>
                                                        <a href="javascript:void(0)"><?= $u->state ?></a>
                                                    </td>
                                                    
                                                     <td>
                                                        <a href="javascript:void(0)"><?= $u->membership_status ?></a>
                                                    </td>

                                                   <td>
                                                        <a href="<?= base_url('shadow_login/'.$u->member_id) ?>"  target="_new" class="btn btn-success btn-xs  edit_ngo"  data-nge-id="<?= $u->member_id ?>">User Details</a>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;" class="btn btn-danger btn-xs  delete_member_person" data-mem-id="<?= $u->member_id ?>" data-toggle="modal" data-target="#del_user_pop"><i class="fa fa-trash-o "></i></a>
                                                    </td>
                                                </tr>
                                            <?php }
                                            ?>


                                        </tbody>

                                    </table>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- end page-wrapper -->
</body>

</html>


<div id="del_user_pop" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close del_memb_close" id="close-approve-popup" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Are you sure you want to delete.?</h4>
            </div>
            <div class="modal-body">
                <input type="hidden" id="member_id">
                <input type="hidden" id="cid_">
                <button type="submit" class="btn btn-success" id="del_yes" autofocus>Yes</button>
                <button type="submit" class="btn btn-danger" data-dismiss="modal" style="float:right;" >No</button>

            </div>
        </div>

    </div>
</div>



<script>
   $(".delete_member_person").click(function () {
        var memb_id = $(this).attr("data-mem-id");
        //alert(memb_id);
        $("#member_id").val(memb_id);
    });


    $("#del_yes").click(function () {
        var memberid = $("#member_id").val();
        // alert(memberid);

        $.ajax({
            url: "<?= base_url('admin/_Admin/delete_member_person') ?>",
            type: "POST",
            data: {
                memid: memberid
            },
            success: function (response) {
                if (response === 'deleted') {

                    $("#member_response" + memberid).html('<div class="alert alert-info alert-dismissible">\n\
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
<strong>Sucess!</strong> Deleted successfully.\n\
</div>');
                    $(".del_memb_close").click();
                    $("#member_response" + memberid).fadeOut(5000);

                }

            }
        });
    });
</script>
