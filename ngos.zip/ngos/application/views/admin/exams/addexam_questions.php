<?php
 $questions = $this->Admin_model->get_uniq_exam_questionCount($examid);
 $count = count($questions);
?>

<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Add Exam Questions</h1>
            <h3 class="page-header">Exam Name: <?= $exams->exam_name ?></h3>
            <h3 class="page-header">Total Number Of Questions: <?= $exams->total_questions ?></h3>
             <h3 class="page-header">Added Questions: <?= $count ?></h3>
            <h3 class="page-header">Total Marks: <?= $exams->total_marks ?></h3>
            <h3 class="page-header">Qualify Marks: <?= $exams->total_qmarks ?></h3>
           
        </div>
        <!--End Page Header -->
        <div class="show_res" style="position:absolute;top:89px;z-index:1063;right:421px;"></div>

        <form id="add_questions_form">
            <div class="form-group row">
               
                <div class="col-md-4">
                     <label for="ex1" style="color:initial;">Question Number</label>
                    <input class="form-control" name="question_number" placeholder="Question Number"  type="text" required="">
                </div>

             


            </div>
            
            <div class="form-group row">
                <div class="col-md-12">
                    <label for="ex1" style="color:initial;">Question Name</label>
                    <textarea class="form-control br_0  " name="question_name" rows="15" cols="15"></textarea>


                </div>

            </div>
            <div class="form-group row">
                <label for="ex1" style="color:initial;">Answer 1</label>
                <div class="col-md-1">
                    <input class="form-control" name="option1" placeholder="A"  type="text" required="" readonly="">
                </div>

                <div class="col-md-6">              
                    <input class="form-control" name="option1_ans1" placeholder="Enter Answer 1"  type="text" required="">
                </div>


            </div>
            <div class="form-group row">
                <label for="ex1" style="color:initial;">Answer 2</label>
                <div class="col-md-1">
                    <input class="form-control" name="option1" placeholder="B"  type="text" required="" readonly="">
                </div>

                <div class="col-md-6">              
                    <input class="form-control" name="option1_ans2" placeholder="Enter Answer 2"  type="text" required="">
                </div>


            </div>
            <div class="form-group row">
                <label for="ex1" style="color:initial;">Answer 3</label>
                <div class="col-md-1">
                    <input class="form-control" name="option1" placeholder="C"  type="text" required="" readonly="">
                </div>

                <div class="col-md-6">              
                    <input class="form-control" name="option1_ans3" placeholder="Enter Answer 3"  type="text" required="">
                </div>


            </div>
            <div class="form-group row">
                <label for="ex1" style="color:initial;">Answer 4</label>
                <div class="col-md-1">
                    <input class="form-control" name="option4" placeholder="D"  type="text" required="" readonly="">
                </div>

                <div class="col-md-6">              
                    <input class="form-control" name="option1_ans4" placeholder="Enter Answer 4"  type="text" required="">
                </div>


            </div>

            <div class="form-group row">
                <div class="col-md-4">
                    <input type="hidden" name="correct_answer" value="" id="get_answer">
                    <label for="ex1" style="color:initial;">Choose Correct Answer </label><br>
                    <select name="Desigination" style="height:50px;width:335px;" id="select_answer" required="">
                        <option value="Choose Correct Answer">Choose Correct Answer</option>
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                        <option value="D">D</option>

                    </select> 
                </div>
            </div>
            
               <div class="form-group row">
                <div class="col-md-12">
                   <?php
                if($exams->total_questions == $count){
                    ?>   <font style="color:red;font-size:20px;">We Already Added  <?= $exams->total_questions ?> Questions to the exam,if we want to add one more question please delete any one of the question</font>
               <?php }else{
                   $count = $exams->total_questions - $count ;
                    
                   ?> 
                    <font style="color:green;font-size:25px;">Remaining Number Of Questions We Have to Add : <?= $count ?></font>
              <?php }
                
                ?>
                </div>   
            </div>
            <font id="limt_questions" style="color:red;font-size:20px;"></font>
            <div class="row col-md-2">
                <input type="hidden" name="totl_questions"  id="total_ques" value="<?= $exams->total_questions ?>">
                <input type="hidden" name="exam_id" value="<?= $exams->exam_id ?>">
                <input type="hidden" name="" id="remaining_count" value="<?= $count ?>">
                <input class="form-control btn btn-success" id="submit_question" type="Submit" value="Add Question">
            </div>
        </form>
    </div>
</div>

<script src="<?= base_url('assets/admin') ?>/plugins/jquery-1.10.2.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/bootstrap/bootstrap.min.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/metisMenu/jquery.metisMenu.js"></script>

<script src="<?= base_url('assets/admin') ?>/scripts/siminta.js"></script>

<script src="<?= base_url('assets/admin') ?>/plugins/morris/raphael-2.1.0.min.js"></script>

<script  src="<?= base_url('') ?>assets/admin/js/ckeditor/ckeditor.js"></script>
<script  src="<?= base_url('') ?>assets/admin/js/ckfinder/ckfinder.js"></script>

<script>

    $("#select_answer").on('change', function () {
        var answer = $(this).val();
      //  alert(answer);
        $("#get_answer").val(answer);

    });

    $("#add_questions_form").on('submit', (function (event) {
        event.preventDefault();
        var totalcount = $("#total_ques").val();
        var count = $("#remaining_count").val();
       // alert(totalcount);
      //  alert(count);
        if(totalcount === count){
             $("#submit_question").prop('disabled',true);
            $("#limt_questions").html('We already added '+totalcount+' questions to the exam  ,if we want add one more question, please delete any one of the question!!!');
            $("#limt_questions").fadeOut(7000);
          $("#submit_question").prop('disabled',false);
        }else{
         $("#submit_question").prop('disabled',false);
          $.ajax({
            url: "<?= base_url('admin/Admin_search/add_exam_questions') ?>",
            type: "POST",
            data: new FormData(this),
            cache: false,
            contentType: false,
            processData: false,

            success: function (response) {
                if (response === 'submitted') {

                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Sucess!</strong> Data has been added successfully.\n\
  </div>');

                    document.getElementById('add_questions_form').reset();
                    window.location.reload();


                } else if (response === 'notsubmitted') {
                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Oops!</strong> Please select all data.\n\
  </div>');
                }
            }
        });  
        }
        
    }));
</script>