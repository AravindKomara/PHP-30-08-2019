<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Manage Exams</h1>
        </div>
        <!--End Page Header -->
    </div>


    <div class="row">
        <div class="col-lg-12">
            <!-- Form Elements -->
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-12">

                            <div class="table-responsive">
                                <form method="post" > 
                                    <table class="table table-striped table-responsive table-hover">
                                        <thead>
                                            <tr>
                                                <th><input type="checkbox" name="chk_b" id="check_all" class="checkall"></th>

                                                <th>Exam Name</th>
                                                 <th>Exam Date</th>
                                                 <th>Exam Start Time</th>
                                                 <th>Exam End Time</th>
                                                <th>Total Questions</th>
                                                 <th>Total Marks</th>
                                                 <th>Total Qualify Marks</th>
                                               <th>Add Questions<i class="fa fa-pencil-square-o"></i></th>
                                                <th>View Questions<i class="fa fa-pencil-square-o"></i></th>
                                                <th>Edit Questions<i class="fa fa-pencil-square-o"></i></th>
                                              
                                                <th>Delete<i class="fa fa-trash-o"></i></th>
                                            </tr>
                                        </thead>

                                        <tbody id="exam_resp">
                                            <?php
                                            $offset = 0;
                                            if (!empty($exams)) {
                                                //$member = $this->Ngos_model->get_ngo_membership_details($u->member_id);
                                               
                                                ?><tr id="exam_response<?= $exams->exam_id ?>">
                                                    <td><input type="checkbox" name="users[]" value=""  class="checkbox1"/></td>
                                                    
                                                    
                                                    <td>
                                                        <a href="javascript:void(0)"><?= $exams->exam_name ?></a>
                                                    </td> 
                                                    <td>
                                                        
                                                        <a href="javascript:void(0)"><?= $exams->exam_date ?> </a>
                                                    </td>
                                                    
                                                    <td>
                                                        <a href="javascript:void(0)">  <?= $exams->exam_time ?></a>
                                                    </td>
                                                    
                                                    <td>
                                                        <a href="javascript:void(0)"><?= $exams->exam_duration ?> minutes</a>
                                                    </td>
                                                    
                                                      <td>
                                                        <a href="javascript:void(0)"><?= $exams->total_questions ?></a>
                                                    </td>
                                                    
                                                      <td>
                                                        <a href="javascript:void(0)"><?= $exams->total_marks ?></a>
                                                    </td>
                                                    
                                                      <td>
                                                        <a href="javascript:void(0)"><?= $exams->total_qmarks ?></a>
                                                    </td>
                                                    
                                                     <td>
                                                        <a href="<?= base_url('exam_questions/'.$exams->exam_id) ?>"  target="_blank" class="btn btn-success btn-xs  exam_questi"  data-nge-id="<?= $exams->exam_id ?>">Add Exam Questions</a>
                                                    </td>
                                                    
                                                     <td>
                                                        <a href="<?= base_url('viewexam_questions/'.$exams->exam_id.'/'.$offset) ?>"  target="_blank" class="btn btn-success btn-xs  exam_questi"  data-nge-id="<?= $exams->exam_id ?>">View Exam Questions</a>
                                                    </td>

                                                    <td>
                                                        <a href="<?= base_url('edit_exam_details/'.$exams->exam_id) ?>"  target="_blank" class="btn btn-success btn-xs  edit_exam_detai"  data-nge-id="<?= $exams->exam_id ?>">Edit Exam Details</a>
                                                    </td>
                                                    
                                                    <td>
                                                        <a href="javascript:;" class="btn btn-danger btn-xs  delete_exam" data-exid="<?= $exams->exam_id ?>" data-toggle="modal" data-target="#exam_del_pop"><i class="fa fa-trash-o "></i></a>
                                                    </td>
                                                </tr>
                                            <?php 
                                            }
                                            ?> 


                                        </tbody>

                                    </table>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- end page-wrapper -->
</body>

</html>


<div id="exam_del_pop" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close exam_close" id="close-approve-popup" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Are you sure you want to delete.?</h4>
            </div>
            <div class="modal-body">
                <input type="hidden" id="exam_id">
                <input type="hidden" id="cid_">
                <button type="submit" class="btn btn-success" id="del_yes" autofocus>Yes</button>
                <button type="submit" class="btn btn-danger" data-dismiss="modal" style="float:right;" >No</button>

            </div>
        </div>

    </div>
</div>


<script>
    $(".delete_exam").click(function () {
        var exid = $(this).attr("data-exid");
       // alert(exid);
        $("#exam_id").val(exid);
    });


    $("#del_yes").click(function () {
        var examid = $("#exam_id").val();
         //alert(examid);

        $.ajax({
            url: "<?= base_url('admin/Admin_search/delete_exam') ?>",
            type: "POST",
            data: {
                examid: examid
            },
            success: function (response) {
                if (response === 'deleted') {

                    $("#exam_response" + examid).html('<div class="alert alert-info alert-dismissible">\n\
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
<strong>Sucess!</strong> Deleted successfully.\n\
</div>');
                    $(".exam_close").click();
                    $("#exam_response" + examid).fadeOut(5000);

                }

            }
        });
    });
</script>
