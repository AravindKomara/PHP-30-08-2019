

<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Edit Exam Details</h1>
            <font id="limt_persons" style="color:red;font-size:20px;"></font>
        </div>
        <!--End Page Header -->
        <div class="show_res" style="position:absolute;top:89px;z-index:1063;right:421px;"></div>

        <form id="edit_exam_form">
            <div class="form-group row">
                <div class="col-md-4">
                    <label for="ex1" style="color:initial;">Exam Name</label>
                    <?php
                    if(!empty($exams->exam_name)){
                        ?> <input class="form-control" name="exam_name" placeholder="Exam Name"  value="<?=$exams->exam_name?>" type="text" required="">
                   <?php }else{
                       ?><input class="form-control" name="exam_name" placeholder="Exam Name"  type="text" required="">
                  <?php }
                    ?>
                    
                </div>

            </div>
            <div class="form-group row">
                <div class="col-md-4">
                    <label for="ex1" style="color:initial;">Exam Date</label>
                     <?php
                    if(!empty($exams->exam_date)){
                        ?> <input class="form-control datepicker-here" name="exam_date"  placeholder="Exam Date" type="text" id="date" value="<?=$exams->exam_date?>" data-language='en' data-position='right top' required>
                   <?php }else{
                       ?> <input class="form-control datepicker-here" name="exam_date"  placeholder="Exam Date" type="text" id="date" data-language='en' data-position='right top' required>
                  <?php }
                    ?>
                   
                </div>   
            </div>

            <div class="form-group row">
                <div class="col-md-4">
                    <label for="ex1" style="color:initial;">Exam Start Time</label>
                     <?php
                    if(!empty($exams->exam_time)){
                        ?>  <input class="form-control" name="exam_time"  placeholder="Exam Time" type="text" id="time" value="<?=$exams->exam_time?>" required>
                   <?php }else{
                       ?>  <input class="form-control" name="exam_time"  placeholder="Exam Time" type="text" id="time" required>
                  <?php }
                    ?>
                    
                   
                </div>   
            </div>




            <div class="form-group row">
                <div class="col-md-4">
                    <label for="ex1" style="color:initial;">Exam End Time</label>
                     <?php
                    if(!empty($exams->exam_duration)){
                        ?> <input class="form-control" name="exam_duration"    placeholder="Exam Duration" type="text" id="time1" value="<?=$exams->exam_duration?>" required="">
                   <?php }else{
                       ?>  <input class="form-control" name="exam_duration"    placeholder="Exam Duration" type="text"  id="time1" required="">
                  <?php }
                    ?>
                    
                </div>   
            </div>

            <div class="form-group row">
                <div class="col-md-4">
                    <label for="ex1" style="color:initial;">Total Questions</label>
                     <?php
                    if(!empty($exams->total_questions)){
                        ?>  <input class="form-control" name="total_questions"  type="text" placeholder="Total Questions" value="<?=$exams->total_questions?>" required="">
                   <?php }else{
                       ?>  <input class="form-control" name="total_questions"  type="text" placeholder="Total Questions" required="">
                  <?php }
                    ?>
                   
                </div>   
            </div>

            <div class="form-group row">
                <div class="col-md-4">
                    <label for="ex1" style="color:initial;">Total Marks</label>
                     <?php
                    if(!empty($exams->total_marks)){
                        ?>  <input class="form-control" name="total_marks"  type="text" placeholder="Total Marks" value="<?=$exams->total_marks?>" required="">
                   <?php }else{
                       ?>  <input class="form-control" name="total_marks"  type="text" placeholder="Total Marks" required="">
                  <?php }
                    ?>
                    
                </div>   
            </div>

            <div class="form-group row">
                <div class="col-md-4">
                    <label for="ex1" style="color:initial;">Qualifying Marks</label>
                    <?php
                    if(!empty($exams->total_qmarks)){
                        ?>    <input class="form-control" name="total_qmarks"  type="text" placeholder="Qualifying Marks" value="<?=$exams->total_qmarks?>" required="">
                   <?php }else{
                       ?>    <input class="form-control" name="total_qmarks"  type="text" placeholder="Qualifying Marks" required="">
                  <?php }
                    ?>
                  
                </div>   
            </div>


            <input type="hidden" name="exam_id" value="<?=$exams->exam_id?>">


            <div class="row col-md-2">
                <input class="form-control btn btn-success" id="submit_exam" type="Submit" value="Save">
            </div>
        </form>
    </div>
</div>



<script src="<?= base_url('assets/admin') ?>/plugins/jquery-1.10.2.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/bootstrap/bootstrap.min.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/metisMenu/jquery.metisMenu.js"></script>

<script src="<?= base_url('assets/admin') ?>/scripts/siminta.js"></script>

<script src="<?= base_url('assets/admin') ?>/plugins/morris/raphael-2.1.0.min.js"></script>


<!-- JQUERY Time Picker --->
<script src="<?= base_url('') ?>assets/admin/js/timepicki.js"></script>

<!-- JQUERY Date Picker --->
<script src="<?= base_url('') ?>assets/admin/js/datepicker.js"></script>
<script src="<?= base_url('') ?>assets/admin/js/datepicker.en.js"></script>





<script>
    $("#time").timepicki();//time picker
</script>
<script>
    $("#time1").timepicki();//time picker
</script>

<script>
    $('#date').datepicker({//date picker
    });
</script>


<script>

    $("#edit_exam_form").on('submit', (function (event) {
        event.preventDefault();
        $.ajax({
            url: "<?= base_url('admin/Admin_search/edit_examination_details') ?>",
            type: "POST",
            data: new FormData(this),
            cache: false,
            contentType: false,
            processData: false,

            success: function (response) {
                if (response === 'submitted') {

                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Sucess!</strong> Data has been added successfully.\n\
  </div>');

                    document.getElementById('edit_exam_form').reset();
                    $(".show_res").fadeOut(5000);
                    window.location.reload();


                } else if (response === 'notsubmitted') {
                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Oops!</strong> Please select all data.\n\
  </div>');
                } else {
                    $("#limt_persons").html('We already added 7 persons to the ' + response + '  ,if we want add one more person please delete any one of the person!!!');
                    $("#submit_person").prop('disabled', true);
                }
            }
        });
    }));
</script>

