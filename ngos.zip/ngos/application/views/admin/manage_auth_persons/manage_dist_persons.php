<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Manage District Persons</h1>
        </div>
        <!--End Page Header -->
    </div>
    
      <div class="row">
        <div class="col-lg-12">
            <!-- Form Elements -->
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <form method="post" id="search_auth_form">
                                <div class="input-group">
                                    <input type="hidden" name="auth_type" value="District">
                                    <input type="text" class="form-control" id="search_input" name="auth_name" placeholder="Search for Authorization Person by state..." required>
                                    <span class="input-group-btn">
                                        <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i></button>
                                    </span>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class="row">
        <div class="col-lg-12">
            <!-- Form Elements -->
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-12">

                            <div class="table-responsive">
                                <form method="post" > 
                                    <table class="table table-striped table-responsive table-hover search_auth_resp">
                                        <thead>
                                            <tr>
                                                <th><input type="checkbox" name="chk_b" id="check_all" class="checkall"></th>

                                                <th>Profile pic</th>

                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>Type</th>
                                                <th>Desigination</th>
                                                <th>State</th>
                                                <th>District</th>
                                                <th><i class="fa fa-pencil-square-o"></i></th>
                                                <th><i class="fa fa-trash-o"></i></th>
                                            </tr>
                                        </thead>

                                        <tbody id="search_resp">
                                            <?php
                                            foreach ($auth_persons as $ia) {
                                                $state_name = "";
                                                $state  = $this->Admin_model->get_state_of_district($ia->auth_district);
                                                if(!empty($state)){
                                                 $state_name = $this->Admin_model->get_state_name($state->state_id);   
                                              }
                                               
                                                ?><tr id="auth_response<?= $ia->auth_id ?>">
                                                    <td><input type="checkbox" name="users[]" value=""  class="checkbox1"/></td>
                                                    <td>
                                                        <?php
                                                        if (!empty($ia->auth_image)) {
                                                            ?><img src='<?= base_url() . $ia->auth_image ?>' width="50" alt="">
                                                        <?php } else {
                                                            ?><img src='<?= base_url('') ?>assets/admin/img/Ngo.png' width="50" alt="">
                                                        <?php }
                                                        ?> 
                                                    </td>
                                                    <td>
                                                        <a href="javascript:void(0)"><?= $ia->auth_name ?></a>
                                                    </td> 
                                                    <td>
                                                        <a href="javascript:void(0)"><?= $ia->auth_mobile ?></a>
                                                    </td> 
                                                    <td>
                                                        <a href="javascript:void(0)"><?= $ia->auth_type ?></a>
                                                    </td> 
                                                    <td>
                                                        <a href="javascript:void(0)"><?= $ia->auth_desgination ?></a>
                                                    </td> 
                                                    
                                                     <td>
                                                         <?php
                                                         if(!empty($state_name->name)){
                                                         $statename = str_replace(" ","_",$state_name->name);
                                                         if(!empty($statename)){
                                                            ?> <a href="<?= base_url('state_uniqngos/'.$statename)?>" target="_new"><?= $state_name->name ?></a> 
                                                         <?php  } }
                                                         ?>
                                                        
                                                    </td>
                                                    <td>
                                                          <?php
                                                         $districtname = str_replace(" ","_",$ia->auth_district);
                                                         ?>
                                                        <a href="<?= base_url('district_uniqngos/'.$districtname)?>" target="_new"><?= $ia->auth_district ?></a>
                                                    </td>
                                                    <td>
                                                        <a href="<?= base_url('edit_auth_person/' . $ia->auth_id) ?>"  target="_new" class="btn btn-success btn-xs  edit_ngo"  data-nge-id="<?= $ia->auth_id ?>"><i class="fa fa-pencil-square-o"></i></a>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;" class="btn btn-danger btn-xs  delete_auth_person" data-ngd-id="<?= $ia->auth_id ?>" data-toggle="modal" data-target="#del_auth_pop"><i class="fa fa-trash-o "></i></a>
                                                    </td>
                                                </tr>
                                            <?php }
                                            ?>


                                        </tbody>

                                    </table>
                                    
                                     <div class="clear text-center">
                                        <ul class="pagination">
                                            <?php echo $this->pagination->create_links(); ?>
                                        </ul>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- end page-wrapper -->
</body>

</html>


<div id="del_auth_pop" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close del_auth_close" id="close-approve-popup" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Are you sure you want to delete.?</h4>
            </div>
            <div class="modal-body">
                <input type="hidden" id="auth_pers_id">
                <input type="hidden" id="cid_">
                <button type="submit" class="btn btn-success" id="del_yes" autofocus>Yes</button>
                <button type="submit" class="btn btn-danger" data-dismiss="modal" style="float:right;" >No</button>

            </div>
        </div>

    </div>
</div>



<script>
    $(".delete_auth_person").click(function () {
        var ng_id = $(this).attr("data-ngd-id");
        //alert(ng_id);
        $("#auth_pers_id").val(ng_id);
    });


    $("#del_yes").click(function () {
        var authid = $("#auth_pers_id").val();
       // alert(authid);

        $.ajax({
            url: "<?= base_url('admin/_Admin/delete_auth_person') ?>",
            type: "POST",
            data: {
                authid: authid
            },
            success: function (response) {
                if (response === 'deleted') {
                   
                    $("#auth_response" + authid).html('<div class="alert alert-info alert-dismissible">\n\
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
<strong>Sucess!</strong> Deleted successfully.\n\
</div>');
     $(".del_auth_close").click();
    $("#auth_response"+authid).fadeOut(5000);
                  
          }

            }
        });
    });
    
    $(function () {
          $("#search_input").autocomplete({
                  source: "<?= base_url('admin/Admin_search/get_authnames?type=District') ?>",
        });
   });
   
    $("#search_auth_form").on('submit', (function (e) {
// $(".roller-clue").addClass("roller");
        $('#search_resp').html('<img src="<?= base_url('assets/images/load.gif') ?>" alt="" width="50" height="50" />');
        e.preventDefault();
        $.ajax({
            url: "<?= base_url('admin/Admin_search/getSearchpersonRow') ?>", // Url to which the request is send
            type: "POST", // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false, // The content type used when sending data to the server.
            cache: false, // To unable request pages to be cached
            processData: false, // To send 
            success: function (data) {
                $('.search_auth_resp').html(data);
                $("#search_input").val("");

            }

        });


    }));
</script>
