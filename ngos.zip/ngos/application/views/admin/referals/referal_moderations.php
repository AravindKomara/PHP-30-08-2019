
<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Referral Moderations</h1>
            <font id="ref_statusresp" style="color:green;font-size:20px;"></font>
        </div>
        <!--End Page Header -->

    </div>

    <div class="row">
        <div class="col-lg-12">
            <!-- Form Elements -->
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="table-responsive">
                                <table class="table table-striped table-advance table-hover">
                                    <thead>
                                        <tr>
                                            <th><input type="checkbox" name="chk_b" id="check_all" class="checkall"></th>
                                            <th> MemberID</th>
                                            <th> Amount</th>
                                            <th> Status</th>

                                            <th>DateTime </th>

                                            <th><i class="fa fa-trash-o"></i></th>
                                        </tr>
                                    </thead>


                                    <tbody>
                                        <?php
                                        if (!empty($referals)) {
                                            foreach ($referals as $rf) {
                                                ?>  <input type="hidden" name="memberid" value="<?= $rf->memberid ?>" id="mem_id">

                                            <tr id="refral_resp<?= $rf->rid ?>">
                                                <td><input type="checkbox" name="users[]" value=""  class="checkbox1"/></td>

                                                <td><a href="" target="_blank" ><?= $rf->memberid ?></a></td>
                                                <td><a href="" target="_blank" ><?= $rf->amount ?></a></td>
                                                <td>
                                                    <?php
                                                    if($rf->status == 'pending'){
                                                       ?> <select name="Desigination" style="height:36px;width:110px;" id="update_payment_status" required="">
                                                        <option value="pending">pending</option>
                                                        <option value="approved">approve</option>
                                                         <option value="reject">reject</option>

                                                    </select>
                                                  <?php  }elseif($rf->status == 'approved'){
                                                      ?><a href="" target="_blank" >Approved</a></td>
                                                 <?php }else{
                                                     ?><select name="Desigination" style="height:36px;width:110px;" id="update_payment_status" required="">
                                                        <option value="rejected">rejected</option>
                                                        <option value="approved">approve</option>
                                                       
                                                    </select>
                                                <?php }
                                                    
                                                    ?>

                                                     
                                                </td>



                                                <td><a href="" target="_blank" ><?= date('d-m-Y', strtotime($rf->added_on)) ?></a></td>


                                                <td>
                                                    <a href="javascript:;" class="btn btn-danger btn-xs  delete_refrecord" data-rid = "<?= $rf->rid ?>" data-memid="<?= $rf->memberid ?>" data-toggle="modal"  data-target="#delete_ref_pop">Delete</a>
                                                </td>

                                            </tr>
                                            <?php
                                        }
                                    }
                                    ?>



                                    </tbody>


                                </table>



                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>





<div id="delete_ref_pop" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" id="close-referal-popup" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Are you sure you want to permanently delete  referral record...?</h4>
            </div>
            <div class="modal-body">

                <input type="hidden" id="refid">
                <input type="hidden" id="refmemid">
                <button type="submit" class="btn btn-success" id="delete_yes" autofocus>Yes</button>
                <button type="submit" class="btn btn-danger" data-dismiss="modal" style="float:right;" >No</button>

            </div>
        </div>

    </div>
</div>

<script>



    $('#update_payment_status').on('change', function () {
        var value = $(this).val();
        //  alert(value);
        var memberid = $("#mem_id").val();

        //  alert(memberid);
        $.ajax({
            url: '<?= base_url('admin/Admin_search/update_refmoney_status') ?>',
            type: 'POST',
            data: {
                value: value,
                memberid: memberid
            },
            success: function (response) {
                if (response === 'success') {
                    //alert(response);
                    $('#ref_statusresp').html('Payment status updated successfully !!!!');
                    window.location.reload();
                }

            }
        });

    });




    $(".delete_refrecord").click(function () {
        var id = $(this).attr('data-rid');
        //alert(id);
        var memid = $(this).attr('data-memid');
        // alert(memid);
        $("#refid").val(id);
        $("#refmemid").val(memid);
    });

    $("#delete_yes").click(function () {
        var id = $("#refid").val();
        // alert(id);
        var memberid = $("#refmemid").val();
        //  alert(memberid);
        $.ajax({
            url: "<?= base_url('admin/Admin_search/delete_refrecord') ?>",
            type: "POST",
            data: {
                id: id,
                memberid: memberid

            },
            success: function (response) {
                if (response === 'success') {
                    $("#refral_resp" + id).html('<div class="alert alert-info alert-dismissible">\n\
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
<strong>Sucess!</strong> Deleted successfully.\n\
</div>');

                    $("#close-referal-popup").click();
                    $("#refral_resp" + id).fadeOut(5000);
                    window.location.reload();
                } else {

                }
            }
        });
    });


</script>

