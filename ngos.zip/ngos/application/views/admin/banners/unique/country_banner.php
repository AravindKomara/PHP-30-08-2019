

<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Add Country Banner</h1>
        </div>
        <!--End Page Header -->
        <div class="show_res" style="position:absolute;top:89px;z-index:1063;right:421px;"></div>

        <form id="add_banner_form">
            <div class="form-group row">
                <div class="col-md-12">
                    <label for="ex1" style="color:initial;">Banner Text</label>
                    <input class="form-control" name="banner_text" placeholder="Banner Text"  type="text" required="">
                    
                </div>

            </div>



            <div class="form-group row">
                <div class="col-md-4">
                    <label for="ex1" style="color:initial;">Type</label>
                    <input class="form-control" name="banner_type"  type="text" value="International" readonly="">
                </div>   
            </div>

            <div class="form-group row">
                <div class="col-md-4">
                    <input type="hidden" name="banner_country" value="Afghanistan" id="get_count_banner">
                    <label for="ex1" style="color:initial;">Country</label><br>
                    <select name="State" style="height:50px;width:335px;" id="uniq_count_banner" required="">
                        <?php
                        $countries = $this->States_districts->get_all_countries();
                        foreach ($countries as $c) {
                            ?><option value="<?= $c->cname ?>"><?= $c->cname ?></option>
                        <?php }
                        ?>
                    </select>


                </div>
            </div>





            <div class="row col-md-2">
                <input class="form-control btn btn-success" id="submit_banner" type="Submit" value="Add Banner">
            </div>
        </form>
    </div>
</div>

<script src="<?= base_url('assets/admin') ?>/plugins/jquery-1.10.2.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/bootstrap/bootstrap.min.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/metisMenu/jquery.metisMenu.js"></script>

<script src="<?= base_url('assets/admin') ?>/scripts/siminta.js"></script>

<script src="<?= base_url('assets/admin') ?>/plugins/morris/raphael-2.1.0.min.js"></script>

<script>

    $("#uniq_count_banner").on('change', function () {
        var country = $(this).val();
       // alert(country);
        $("#get_count_banner").val(country);

    });


    $("#add_banner_form").on('submit', (function (event) {
        event.preventDefault();
        $.ajax({
            url: "<?= base_url('admin/_Admin/add_unique_banners') ?>",
            type: "POST",
            data: new FormData(this),
            cache: false,
            contentType: false,
            processData: false,

            success: function (response) {
                if (response === 'submitted') {

                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Sucess!</strong> Data has been added successfully.\n\
  </div>');

                    document.getElementById('add_banner_form').reset();
                    window.location.reload();


                } else if (response === 'submit_all') {
                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Oops!</strong> Please select all data.\n\
  </div>');
                }
            }
        });
    }));
</script>