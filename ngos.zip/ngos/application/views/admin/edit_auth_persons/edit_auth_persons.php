
<?php
if (!empty($auth_person)) {
    ?> <div id="page-wrapper">

        <div class="row">
            <!-- Page Header -->
            <div class="col-lg-12">
                <h1 class="page-header">Edit AuthPerson</h1>
            </div>
            <!--End Page Header -->
            <div class="show_res" style="position:absolute;top:89px;z-index:1063;right:421px;"></div>

            <form id="edit_auth_form">
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="ex1" style="color:initial;">Name</label>
                        <input class="form-control" name="person_name" placeholder="Name"  value="<?= $auth_person->auth_name ?>" type="text" required="">
                    </div>

                </div>
                <?php
                if (!empty($auth_person->auth_jobtype)) {
                    ?><div class="form-group row">
                        <div class="col-md-4">
                            <label for="ex1" style="color:initial;">Job Type</label>
                            <input class="form-control" name="person_jobtype"  type="text" value="<?= $auth_person->auth_jobtype ?>" readonly="">
                        </div>   
                    </div>
                <?php }
                ?>





                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="ex1" style="color:initial;">Mobile</label>
                        <input class="form-control" name="person_mobile"  placeholder="Mobile Number" value="<?= $auth_person->auth_mobile ?>" type="text" required="">
                    </div>   
                </div>

                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="ex1" style="color:initial;">Type</label>
                        <input class="form-control" name="person_type"  type="text"  value="<?= $auth_person->auth_type ?>" readonly="">
                    </div>   
                </div>

                <div class="form-group row">
                    <div class="col-md-12">
                        <label for="ex1" style="color:initial;">Description</label><br>
                        <textarea class="form-control br_0 " name="person_des" rows="5" id="ap_br_des"><?= $auth_person->auth_description ?></textarea>										

                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-4">
                        <input type="hidden" name="pers_desig" value="" id="get_desg">
                        <label for="ex1" style="color:initial;">Desigination</label><br>
                        <select name="Desigination" style="height:50px;width:335px;" id="uniq_desig" required="">
                            <?php
                            if ($auth_person->auth_type == 'International') {
                                $in_types = $this->Admin_model->get_all_in_types();
                                foreach ($in_types as $it) {
                                    ?><option value="<?= $it->auth_type ?>"<?php
                                    if ($auth_person->auth_desgination == $it->auth_type) {
                                        echo 'selected';
                                    }
                                    ?>> <?php echo $it->auth_type ?></option>

                                    <?php
                                }
                            } elseif ($auth_person->auth_type == 'National') {
                                $in_types = $this->Admin_model->get_all_nat_types();
                                foreach ($in_types as $it) {
                                    ?><option value="<?= $it->auth_type ?>"<?php
                                    if ($auth_person->auth_desgination == $it->auth_type) {
                                        echo 'selected';
                                    }
                                    ?>> <?php echo $it->auth_type ?></option>
                                            <?php
                                        }
                                    } elseif ($auth_person->auth_type == 'State') {
                                        $in_types = $this->Admin_model->get_all_auth_types();
                                        foreach ($in_types as $it) {
                                            ?><option value="<?= $it->auth_type ?>"<?php
                                    if ($auth_person->auth_desgination == $it->auth_type) {
                                        echo 'selected';
                                    }
                                    ?>> <?php echo $it->auth_type ?></option>
                                            <?php
                                        }
                                    } else {
                                        $in_types = $this->Admin_model->get_all_auth_types();
                                        foreach ($in_types as $it) {
                                            ?><option value="<?= $it->auth_type ?>"<?php
                                    if ($auth_person->auth_desgination == $it->auth_type) {
                                        echo 'selected';
                                    }
                                    ?>> <?php echo $it->auth_type ?></option>
                                            <?php
                                        }
                                    }
                                    ?> 


                        </select> 
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-4">

                        <?php
                        if (!empty($auth_person->auth_country)) {
                            ?><input type="hidden" name="auth_residence" value="<?= $auth_person->auth_country ?>" id="get_auth_residence">
                            <label for="ex1" style="color:initial;">Country</label><br>
                            <input type="hidden" name="auth_res" value="country">
                            <select name="State" style="height:50px;width:335px;" id="uniq_count_person" required="">
                                <?php
                                $countries = $this->States_districts->get_all_countries();
                                foreach ($countries as $c) {
                                    ?><option value="<?= $c->cname ?>"<?php
                                    if ($auth_person->auth_country == $c->cname) {
                                        echo 'selected';
                                    }
                                    ?>> 
                                        <?php echo $c->cname ?></option>

                                <?php } ?> 

                            </select>


                        <?php } elseif (!empty($auth_person->auth_type == 'National')) {
                            ?><input type="hidden" name="auth_res" value="national"> 
                            <label for="ex1" style="color:initial;">Country</label><br>
                            <input class="form-control" type="text" name="auth_residence" value="India" readonly="">  
                        <?php } elseif (!empty($auth_person->auth_state)) {
                            ?> <input type="hidden" name="auth_residence" value="<?= $auth_person->auth_state ?>" id="get_auth_residence"> 
                            <label for="ex1" style="color:initial;">State</label><br>
                            <input type="hidden" name="auth_res" value="state">
                            <select name="Desigination" style="height:50px;width:335px;" id="uniq_perstate" required="">
                                <?php
                                $states = $this->States_districts->all_indian_states();
                                foreach ($states as $s) {
                                    ?><option value="<?= $s->name ?>"<?php
                                    if ($auth_person->auth_state == $s->name) {
                                        echo 'selected';
                                    }
                                    ?>> <?php echo $s->name ?></option>

                                <?php } ?>  

                            </select>
                        <?php } else {
                            ?> <input type="hidden" name="auth_residence" value="<?= $auth_person->auth_district ?>" id="get_auth_residence"> 
                            <label for="ex1" style="color:initial;">District</label><br>
                            <input type="hidden" name="auth_res" value="district">
                            <select name="Desigination" style="height:50px;width:335px;" id="uniq_district" required="">
                                <?php
                                $dist = $this->States_districts->get_district($auth_person->auth_district);
                                $districts = $this->States_districts->get_all_districts_state($dist->state_id);
                                foreach ($districts as $d) {
                                    ?><option value="<?= $d->name ?>"<?php
                                    if ($auth_person->auth_district == $d->name) {
                                        echo 'selected';
                                    }
                                    ?>> <?php echo $d->name ?></option>

                                <?php } ?>  

                            </select>
                        <?php }
                        ?>


                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-8">
                        <?php
                        if (!empty($auth_person->auth_image)) {
                            echo '<img class="show_img" src=' . base_url() . $auth_person->auth_image . '  style="height:190px;width:180px;">';
                            ?><img src="<?= base_url('assets/admin/img/upload.png') ?>" style='height:90px;width:120px;object-fit: contain;cursor:pointer;'id="upfile1" /> 
                            <input type="file" id="person_img"  name="person_image" style="display:none" onchange="previewFile()"/>
                            <label for="ex1" style="color:initial;">Change Photo</label>
                        <?php } else {
                            ?><img class="show_img" src="<?= base_url('assets/admin/img/upload.png') ?>" style='height:90px;width:120px;object-fit: contain;cursor:pointer;'id="upfile1" /> 
                            <input type="file" id="person_img"  name="person_image" style="display:none" onchange="previewFile()"/>
                            <label for="ex1" style="color:initial;">Upload Image</label>
                        <?php }
                        ?>



                    </div>
                </div>



                <input type="hidden" name="auth_id" value="<?= $auth_person->auth_id ?>">


                <div class="row col-md-2">
                    <input class="form-control btn btn-success" id="submit_person" type="Submit" value="Submit">
                </div>
            </form>
        </div>
    </div>

    <?php
} else {
    echo 'grg';
}
?>

<script src="<?= base_url('assets/admin') ?>/plugins/jquery-1.10.2.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/bootstrap/bootstrap.min.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/metisMenu/jquery.metisMenu.js"></script>

<script src="<?= base_url('assets/admin') ?>/scripts/siminta.js"></script>

<script src="<?= base_url('assets/admin') ?>/plugins/morris/raphael-2.1.0.min.js"></script>

<script  src="<?= base_url('') ?>assets/admin/js/ckeditor/ckeditor.js"></script>
<script  src="<?= base_url('') ?>assets/admin/js/ckfinder/ckfinder.js"></script>

<script>

    $("body").on('click', '#upfile1', function () {
        $("#person_img").trigger('click');
    });

    $("#uniq_count_person").on('change', function () {
        var country = $(this).val();
        //  alert(country);
        $("#get_auth_residence").val(country);

    });

    $("#uniq_perstate").on('change', function () {
        var state = $(this).val();
        //  alert(state);
        $("#get_auth_residence").val(state);

    });

    $("#uniq_district").on('change', function () {
        var district = $(this).val();
        //  alert(district);
        $("#get_auth_residence").val(district);

    });

    $("#uniq_desig").on('change', function () {
        var designation = $(this).val();
        //  alert(designation);
        $("#get_desg").val(designation);

    });

    function previewFile() {
        var preview = document.querySelector('.show_img');
        var file = document.querySelector('input[type=file]').files[0];
        var reader = new FileReader();

        reader.onloadend = function () {
            preview.src = reader.result;
        }

        if (file) {
            reader.readAsDataURL(file);
        } else {
            preview.src = "";
        }
    }


    $("#edit_auth_form").on('submit', (function (event) {
        event.preventDefault();
        //   alert();
        $.ajax({

            url: "<?= base_url('admin/_Admin/edit_auth_persons') ?>",
            type: "POST",
            data: new FormData(this),
            cache: false,
            contentType: false,
            processData: false,

            success: function (response) {
                response =  $.trim(response);
                if (response === 'submitted') {

                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
<strong>Sucess!</strong> Data has been added successfully.\n\
</div>');
                    window.location.reload();




                } else if (response === 'submit_all') {
                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
<strong>Oops!</strong> Please select all data.\n\
</div>');
                }
            }
        });
    }));
</script>