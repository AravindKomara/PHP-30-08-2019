<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>NGO | Welcome Admin</title>
        <!-- Core CSS - Include with every page -->
        <link href="<?= base_url('') ?>assets/admin/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
        <link href="<?= base_url('') ?>assets/admin/font-awesome/css/font-awesome.css" rel="stylesheet" />
        <link href="<?= base_url('') ?>assets/admin/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
        <link href="<?= base_url('') ?>assets/admin/css/style.css" rel="stylesheet" />
        <link href="<?= base_url('') ?>assets/admin/css/main-style.css" rel="stylesheet" />
        <!-- Page-Level CSS -->
        <link href="<?= base_url('') ?>assets/admin/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <link rel="shortcut icon" href="<?= base_url('') ?>assets/admin/img/Ngo.png">
        <link href="<?= base_url('assets/css/jquery-ui.min.css') ?>" rel="stylesheet" >
        
        <!--  Time Picker CSS --->
        <link rel="stylesheet" type="text/css" href="<?= base_url('') ?>assets/admin/css/timepicki.css"/>

          <!--  Date Picker CSS --->
         <link rel="stylesheet" type="text/css" href="<?= base_url('') ?>assets/admin/css/datepicker.css"/>
         

         
         
        <style type="text/css">

            .ui-autocomplete.ui-front.ui-menu.ui-widget.ui-widget-content{
                height:100px;
                overflow-y: scroll;
                overflow-x: hidden;
                position: absolute;
                top: 230px;
                left: 280px;
                width: 1040px;
                display: none;
            }
        </style>



        <!-- Auto search CSS --->    
        <!--        <link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.css"  rel="stylesheet">-->
        <!-- Auto search Script --->    

        <!-- scripts for bootstrap model --->    
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>









    </head>
    <body>
        <!--  wrapper -->
        <div id="wrapper">
            <!-- navbar top -->
            <nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
                <!-- navbar-header -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="javascript:void(0);">
                        <img src="<?= base_url('assets/admin') ?>/img/Ngo.png" alt="" />
                    </a>
                </div>
                <!-- end navbar-header -->
                <!-- navbar-top-links -->
                <ul class="nav navbar-top-links navbar-right">
                    <!-- main dropdown -->

                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user fa-3x"></i>
                        </a>
                        <!-- dropdown user-->
                        <ul class="dropdown-menu dropdown-user">
                            <li><a href="#"><i class="fa fa-user fa-fw"></i>User Profile</a>
                            </li>
                            <li><a href="#"><i class="fa fa-gear fa-fw"></i>Settings</a>
                            </li>
                            <li class="divider"></li>
                            <li><a href="<?= base_url('logout') ?>"><i class="fa fa-sign-out fa-fw"></i>Logout</a>
                            </li>
                        </ul>
                        <!-- end dropdown-user -->
                    </li>
                    <!-- end main dropdown -->
                </ul>
                <!-- end navbar-top-links -->

            </nav>
            <!-- end navbar top -->

            <!-- navbar side -->
            <nav class="navbar-default navbar-static-side" role="navigation">
                <!-- sidebar-collapse -->
                <div class="sidebar-collapse">
                    <!-- side-menu -->
                    <ul class="nav" id="side-menu">
                        <li>
                            <!-- user image section-->
                            <div class="user-section">
                                <div class="user-section-inner">
                                    <img src="<?= base_url('assets/admin') ?>/img/user.jpg" alt="">
                                </div>
                                <div class="user-info">
                                    <div><strong>Aravind Komara</strong></div>
                                    <div class="user-text-online">
                                        <span class="user-circle-online btn btn-success btn-circle "></span>&nbsp;Online
                                    </div>
                                </div>
                            </div>
                            <!--end user image section-->
                        </li>

                        <li class="selected">
                            <a href="<?= base_url('dashboard') ?>"><i class="fa fa-dashboard fa-fw"></i>Dashboard</a>
                        </li>

                        <li>
                            <a href="<?= base_url('add_legality') ?>">Add Legality</a>
                        </li>

                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-bar-chart-o fa-fw"></i> Add Common Banners<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?= base_url('add_home_banner_text/' . 'Home') ?>">Add Home Banner</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('add_inter_banner_text/' . 'International') ?>">Add International Banner</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('add_nat_banner_text/' . 'National') ?>">Add National Banner</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('add_sta_banner_text/' . 'State') ?>">Add State Banner</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('add_dist_banner_text/' . 'District') ?>">Add  District Banner</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('add_legality_banner_text/' . 'Legality') ?>">Add  Legality Banner</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('add_offer_banner_text/' . 'Offers') ?>">Add  Offer Banner</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('add_gallery_banner_text/' . 'Gallery') ?>">Add  Gallery Banner</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('add_emailservice_banner_text/' . 'Emailservice') ?>">Add  Emailservice Banner</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>

                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-caret-square-o-up"></i> Add Unique Banners<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?= base_url('add_country_banner_text/') ?>">Unique Country Banner</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('add_state_banner_text/') ?>">Unique State Banner</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('add_district_banner_text/') ?>">Unique District Banner</a>
                                </li>

                            </ul>
                            <!-- second-level-items -->
                        </li>

                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-globe"></i> Manage Unique Banners<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?= base_url('manage_country_banner_text/') ?>">Manage Country Banner</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('manage_state_banner_text/') ?>">Manage State Banner</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('manage_district_banner_text/') ?>">Manage District Banner</a>
                                </li>

                            </ul>
                            <!-- second-level-items -->
                        </li>

                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-dot-circle-o"></i> Add Desigination Types<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?= base_url('add_international_types') ?>">International</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('add_national_types') ?>">National</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('add_state_types') ?>">State</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('add_district_types') ?>">District</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>


                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-object-ungroup"></i> Add Authorization Persons<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?= base_url('add_international_persons') ?>">International Persons</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('add_national_persons') ?>">National Persons</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('add_state_persons') ?>">State Persons</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('add_district_persons') ?>">District Persons</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>

                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-object-group"></i> Manage Authorization Persons<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?= base_url('manage_international_persons') ?>">International Persons</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('manage_national_persons') ?>">National Persons</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('manage_state_persons') ?>">State Persons</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('manage_district_persons') ?>">District Persons</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>

                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-flask"></i> Add Offers<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?= base_url('international_offers') ?>">International Offers</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('national_offers') ?>"> National Offers</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('state_offers') ?>"> State Offers</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('district_offers') ?>"> District Offers</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>

                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-gavel"></i> Manage Offers<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li >
                                    <a href="<?= base_url('manage_international_offers/' . 'International') ?>">Manage International Offers</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('manage_national_offers/' . 'National') ?>"> Manage National Offers</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('manage_state_offers/' . 'State') ?>"> Manage State Offers</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('manage_district_offers/' . 'District') ?>"> Manage District Offers</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>


                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-users"></i> Manage Users<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li >
                                    <a href="<?= base_url('manage_international_users') ?>">International Users</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('manage_national_users') ?>">National Users</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('manage_state_users') ?>">State Users</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('manage_district_users') ?>">District Users</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>
                        
                         <li>
                            <a href="javascript:void(0);"><i class="fa fa-users"></i> Manage Free Users<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li >
                                    <a href="<?= base_url('manage_finternational_users') ?>">Free International Users</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('manage_fnational_users') ?>">Free National Users</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('manage_fstate_users') ?>">Free State Users</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('manage_fdistrict_users') ?>">Free District Users</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>

                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-bell"></i> Add Notifications<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?= base_url('add_int_meeting_notifi/' . 'International_meetings') ?>">International meetings</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('add_nat_meeting_notifi/' . 'National_meetings') ?>">National meetings</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('add_state_meeting_notifi/' . 'State_meetings') ?>">State meetings</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('add_dist_meeting_notifi/' . 'District_meetings') ?>">District meetings</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('add_jobs_notifi/' . 'Jobs') ?>">Jobs</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('add_events_notifi/' . 'Events') ?>">Events</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('add_emergency_service_notifi/' . 'Emergency_services') ?>">Emergency Services</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('add_emergency_meeting_notifi/' . 'Emergency_meetings') ?>">Emergency Meetings</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('add_emergency_protocol_notifi/' . 'Emergency_protocol') ?>">Emergency Protocol</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>


                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-ticket"></i> Add Brochures<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?= base_url('international_brochure') ?>">Add International Brochure</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('national_brochure') ?>">Add National Brochure</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('state_brochure') ?>">Add State Brochure</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('district_brochure') ?>">Add District Brochure</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>

                        <li>
                            <a href="<?= base_url('manage_brochures') ?>">Manage Brochures</a>
                        </li>

                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-spinner"></i> Free Registration<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li >
                                    <a href="<?= base_url('free_international_users') ?>">International Users</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('free_national_users') ?>">National Users</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('free_state_users') ?>">State Users</a>
                                </li>

                                <li>
                                    <a href="<?= base_url('free_district_users') ?>">District Users</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>

                        <li>
                            <a href="<?= base_url('enquiry_moderations') ?>">User Enquiries</a>
                        </li> 
                        
                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-money"></i> Referral Money Moderations<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li >
                                    <a href="<?= base_url('pending_referal_moderations') ?>">Pending Referrals</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('approved_referal_moderations') ?>">Approved Referrals</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('rejected_referal_moderations') ?>">Rejected Referrals</a>
                                </li>

                               
                            </ul>
                            <!-- second-level-items -->
                        </li>
                        

                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-file-image-o"></i> Add Gallery<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li >
                                    <a href="<?= base_url('add_gallery') ?>">Add Events</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>
                        
                         <li>
                            <a href="javascript:void(0);"><i class="fa fa-file-image-o"></i> Manage Gallery<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li >
                                    <a href="<?= base_url('manage_gallery') ?>">Manage Events</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>
                        
                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-money"></i> Exams Moderations<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?= base_url('add_exams') ?>">Add Exams</a>
                                </li>
                                <li>
                                    <a href="<?= base_url('view_exams') ?>">View Exams</a>
                                </li>
                                

                               
                            </ul>
                            <!-- second-level-items -->
                        </li>
                        

                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-bar-chart-o fa-fw"></i> Empty Box 1<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li >
                                    <a href="<?= base_url('add_gallery') ?>">Add Events</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>

                        <li>
                            <a href="javascript:void(0);"><i class="fa fa-bar-chart-o fa-fw"></i> Empty Box 2<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li >
                                    <a href="<?= base_url('add_gallery') ?>">Add Events</a>
                                </li>
                            </ul>
                            <!-- second-level-items -->
                        </li>
                    </ul>
                    <!-- end side-menu -->
                </div>
                <!-- end sidebar-collapse -->
            </nav>
            <!-- end navbar side -->


            <!--        javascript:void(0);-->








