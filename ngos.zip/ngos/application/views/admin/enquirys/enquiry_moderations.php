
<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Enquries Moderations</h1>
        </div>
        <!--End Page Header -->

    </div>

    <div class="row">
        <div class="col-lg-12">
            <!-- Form Elements -->
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="table-responsive">
                                <table class="table table-striped table-advance table-hover">
                                    <thead>
                                        <tr>
                                            <th><input type="checkbox" name="chk_b" id="check_all" class="checkall"></th>

                                            <th> UserName</th>
                                            <th> Email</th>
                                            <th> Mobile</th>
                                            <th>Description</th>
                                            <th>DateTime </th>
                                            <th><i class="fa fa-pencil-square-o"></i></th>
                                            <th><i class="fa fa-trash-o"></i></th>
                                        </tr>
                                    </thead>


                                    <tbody>
                                        <?php
                                        if (!empty($enqs)) {
                                            foreach ($enqs as $eq) {
                                                ?> <tr id="enq_resp<?= $eq->enq_id ?>">
<td><input type="checkbox" name="users[]" value=""  class="checkbox1"/></td>

                                                    <td> <a href="" target="_blank" ><?= $eq->name ?></a></td>
                                                    <td>
                                                        <a href="" target="_blank" ><?= $eq->email ?></a>
                                                    </td>
                                                    <td>
                                                        <a href="" target="_blank" ><?= $eq->mobile ?></a>
                                                    </td>
                                                  
                                                    <td><?= word_limiter($eq->comment, 5) ?><a href="javascript:;" class="enq_view" data-toggle="modal" data-id="<?= $eq->enq_id ?>" data-target="#enqmsg" style="color: red">more</a></td>

                                                    <td> <a href="" target="_blank" ><?= date('d-m-Y', strtotime($eq->added_on)) ?></a></td>

                                                    <td>
                                                        <a href="javascript:;" class="btn btn-success btn-xs  send_reply" data-enqid = "<?= $eq->enq_id ?>" data-email = "<?= $eq->email ?>"    data-toggle="modal"  data-target="#reply_mail_pop">Reply</a>

                                                    </td>
                                                    <td>
                                                        <a href="javascript:;" class="btn btn-danger btn-xs  delete_enq" data-rid = "<?= $eq->enq_id ?>" data-toggle="modal"  data-target="#delete_mail_pop"><i class="fa fa-times"></i></a>
                                                    </td>

                                                </tr>
                                                <?php
                                            }
                                        }
                                        ?>



                                    </tbody>


                                </table>



                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="enqmsg" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">View Message</h4>
            </div>
            <div class="modal-body" id="view_enq">

            </div>
        </div>
    </div>
</div>

<div id="reply_mail_pop" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" id="close-reply-popup" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Send Reply</h4>
            </div>
            <div class="modal-body reply_res">
                <form id="send_reply_form" method="POST">
                <div class="form-group row">
                    <div class="col-md-12">
                        <label for="ex1" style="color:initial;">User Email</label>
                        <input class="form-control" name="user_email" value=""  type="text" id="view_email" readonly="">
                        <input type="hidden" name="enqid" id="enq_eid">
                        
                    </div>

                </div>
                <div class="form-group row">
                    <div class="col-md-12">
                        <label for="ex1" style="color:initial;">Message</label>
                        <textarea class="form-control br_0 " name="reply_message" placeholder="Write message here..."rows="8" cols="8"></textarea>
                        
                    </div>

                </div>
                <div class="row col-md-4">
                    <input class="form-control btn btn-success"  type="Submit" value="Send reply">
                </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>



<div id="delete_mail_pop" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" id="close-delete-popup" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Are you sure you want to delete enquiry...?</h4>
            </div>
            <div class="modal-body">

                <input type="hidden" id="enqid">
                <button type="submit" class="btn btn-success" id="delete_yes" autofocus>Yes</button>
                <button type="submit" class="btn btn-danger" data-dismiss="modal" style="float:right;" >No</button>

            </div>
        </div>

    </div>
</div>

<script>



    $('.enq_view').click(function () {
        var eid = $(this).attr('data-id');
        $.ajax({
            url: '<?= base_url('admin/Admin_search/get_enquriry_message') ?>',
            type: 'POST',
            data: {
                eid: eid
            },
            success: function (response) {
                $('#view_enq').html(response);
            }
        });

    });
    
    $(".send_reply").click(function () {
        var email = $(this).attr("data-email");
        var id = $(this).attr("data-enqid");

        //alert(text);
        //  alert(id);

        $("#view_email").val(email);
        $("#enq_eid").val(id);
    });
    
       $("#send_reply_form").on('submit', (function (event) {
        event.preventDefault();
       // alert();
        $.ajax({
            url: "<?= base_url('admin/Admin_search/enquriry_reply') ?>",
            type: "POST",
            data: new FormData(this),
            cache: false,
            contentType: false,
            processData: false,

            success: function (response) {
                if (response === 'mail_sent') {
                    $(".reply_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Success!</strong> Reply sent successfully.\n\
  </div>');
                 
                   $("#close-reply-popup").click();
                } else if (response === 'mail_notsent') {
                    $(".reply_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Oops!</strong> Reply not sent\n\
  </div>');
                }
            }
        });
    }));


    $(".delete_enq").click(function () {
        var id = $(this).attr('data-rid');
        $("#enqid").val(id);
    });

    $("#delete_yes").click(function () {
        var id = $("#enqid").val();
        alert(id);

        $.ajax({
            url: "<?= base_url('admin/Admin_search/delete_enquriry') ?>",
            type: "POST",
            data: {
                enqid: id

            },
            success: function (response) {
                if (response === 'success') {
                    $("#enq_resp" + id).html('<div class="alert alert-info alert-dismissible">\n\
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
<strong>Sucess!</strong> Deleted successfully.\n\
</div>');

                    $("#close-delete-popup").click();
                    $("#enq_resp" + id).fadeOut(5000);
                } else {

                }
            }
        });
    });


</script>

