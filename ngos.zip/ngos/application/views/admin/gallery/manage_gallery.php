<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Manage Gallery</h1>
        </div>
        <!--End Page Header -->
    </div>


    <div class="row">
        <div class="col-lg-12">
            <!-- Form Elements -->
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-12">

                            <div class="table-responsive">
                                <form method="post" > 
                                    <table class="table table-striped table-responsive table-hover">
                                        <thead>
                                            <tr>
                                                <th><input type="checkbox" name="chk_b" id="check_all" class="checkall"></th>

                                                <th>Event Name</th>
                                                <th>Organizied By</th>
                                                <th>Date</th>
                                                <th>Location</th>
                                                <th>Description</th>
                                                <th>UserDetails</th>
                                                <th><i class="fa fa-trash-o"></i></th>
                                            </tr>
                                        </thead>

                                        <tbody id="search_resp">
                                            <?php
                                            foreach ($gallery as $g) {
                                                
                                               
                                                ?><tr id="gallery_response<?= $g->gid ?>">
                                                    <td><input type="checkbox" name="users[]" value=""  class="checkbox1"/></td>
                                                    
                                                    
                                                    <td>
                                                        <a href="javascript:void(0)"><?= $g->event_name ?></a>
                                                    </td> 
                                                    <td>
                                                        <a href="javascript:void(0)"><?= $g->organized_by ?></a>
                                                    </td>
                                                    
                                                    <td>
                                                        <a href="javascript:void(0)"><?= $g->date ?></a>
                                                    </td>
                                                    
                                                     <td>
                                                        <a href="javascript:void(0)"><?= $g->location ?></a>
                                                    </td>
                                                    
                                                     <td>
                                                        <a href="javascript:void(0)"><?= $g->description ?></a>
                                                    </td>

                                                   <td>
                                                        <a href="<?= base_url('edit_gallery/'.$g->gid) ?>"  target="_new" class="btn btn-success btn-xs">Edit Gallery</a>
                                                    </td>
                                                    <td>
                                                        <a href="javascript:;" class="btn btn-danger btn-xs  delete_gallery" data-gid="<?= $g->gid ?>" data-toggle="modal" data-target="#del_gallery_pop"><i class="fa fa-trash-o "></i></a>
                                                    </td>
                                                </tr>
                                            <?php }
                                            ?>


                                        </tbody>

                                    </table>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- end page-wrapper -->
</body>

</html>


<div id="del_gallery_pop" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close del_gallery_close" id="close-approve-popup" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Are you sure you want to delete.?</h4>
            </div>
            <div class="modal-body">
                <input type="hidden" id="gallery_id">
                <input type="hidden" id="cid_">
                <button type="submit" class="btn btn-success" id="del_yes" autofocus>Yes</button>
                <button type="submit" class="btn btn-danger" data-dismiss="modal" style="float:right;" >No</button>

            </div>
        </div>

    </div>
</div>



<script>
  $(".delete_gallery").click(function () {
        var gid = $(this).attr("data-gid");
      //  alert(gid);
        $("#gallery_id").val(gid);
    });


    $("#del_yes").click(function () {
        var galleryid = $("#gallery_id").val();
        // alert(galleryid);

        $.ajax({
            url: "<?= base_url('admin/Admin_search/delete_gallery') ?>",
            type: "POST",
            data: {
                gid: galleryid
            },
            success: function (response) {
                if (response === 'deleted') {

                    $("#gallery_response" + galleryid).html('<div class="alert alert-info alert-dismissible">\n\
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
<strong>Sucess!</strong> Deleted successfully.\n\
</div>');
                    $(".del_gallery_close").click();
                    $("#gallery_response" + galleryid).fadeOut(5000);

                }

            }
        });
    });
</script>
