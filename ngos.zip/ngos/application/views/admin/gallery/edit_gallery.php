

<div id="page-wrapper">

    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Edit Gallery</h1>
        </div>
        <!--End Page Header -->
        <div class="show_res" style="position:absolute;top:89px;z-index:1063;right:421px;"></div>


        <form id="edit_gallery_form">
            <div class="form-group row">
                <div class="col-md-4">
                    <label for="ex1" style="color:initial;">Event Name</label>
                    <?php
                    if(!empty($gallery->event_name)){
                        ?><input class="form-control" name="event_name" placeholder="Event Name"  value="<?=$gallery->event_name?>" type="text" required="">
                   <?php } else{
                       ?><input class="form-control" name="event_name" placeholder="Event Name"  type="text" required="">
                  <?php }
                    ?>
                    
                </div>

            </div>
            <div class="form-group row">
                <div class="col-md-4">
                    <label for="ex1" style="color:initial;">Organizied By</label>
                    <?php
                    if(!empty($gallery->organized_by)){
                        ?> <input class="form-control" name="event_by" placeholder="Organizied By" value="<?=$gallery->organized_by?>" type="text">
                   <?php } else{
                       ?> <input class="form-control" name="event_by" placeholder="Organizied By" type="text">
                  <?php }
                    ?>
                   
                </div>   
            </div>




            <div class="form-group row">
                <div class="col-md-4" >
                    <label for="ex1" style="color:initial;">Date</label>
                     <?php
                    if(!empty($gallery->date)){
                        ?> <input class="form-control" name="event_date"  placeholder="Date" value="<?=$gallery->date?>" type="text" required="">
                   <?php } else{
                       ?> <input class="form-control" name="event_date"  placeholder="Date" type="text" required="">
                  <?php }
                    ?>
                    

                </div>   
            </div>


            <div class="form-group row">
                <div class="col-md-4">
                    <label for="ex1" style="color:initial;">Location</label>
                    <?php
                    if(!empty($gallery->location)){
                        ?>  <input class="form-control" name="event_location"  value="<?=$gallery->location?>" type="text" placeholder="Location">
                   <?php } else{
                       ?> <input class="form-control" name="event_location"  type="text" placeholder="Location">
                  <?php }
                    ?>
                   
                </div>   
            </div>

            <div class="form-group row">
                <div class="col-md-12">
                    <label for="ex1" style="color:initial;">Description</label><br>
                    <?php
                    if(!empty($gallery->description)){
                        ?>  <textarea class="form-control br_0" name="event_des" rows="5" placeholder="Write about event...."><?=$gallery->description?></textarea>
                   <?php } else{
                       ?> <textarea class="form-control br_0" name="event_des" rows="5" placeholder="Write about event...."></textarea>
                  <?php }
                    ?>
                    										

                </div>
            </div>


<!--            <div class="form-group row">
                <div class="col-md-8">
                    <?php
                    if(!empty($gallery->images)){
                        $images = explode(',',$gallery->images);
                        foreach ($images as $img) {
                            echo '<img class="show_img" src=' . base_url() . $img . '  style="height:190px;width:180px;">';
                        }
                        ?>   <label for="ex1" style="color:initial;">Upload Images</label>
                    <div id="selected_file" style="display:inline;width:150px;height:90px;"  class=""></div>
                    <h5 style="color:red;font-size:15px;">Maximum 10 images only allowed</h5>
                    <input type="file" id="gallery_img"  name="gallery_image[]" style="display:none" required="" multiple/>
                    <img class="show_img" src="<?= base_url('assets/admin/img/upload.png') ?>" style='height:80px;width:200px;object-fit: contain;cursor:pointer;'id="upfile1" /> 
                    <font id="img_err" style="color:red;font-size:40px;"></font>
                   <?php } else{
                       ?>  <label for="ex1" style="color:initial;">Upload Images</label>
                    <div id="selected_file" style="display:inline;width:150px;height:90px;"  class=""></div>
                    <h5 style="color:red;font-size:15px;">Maximum 10 images only allowed</h5>
                    <input type="file" id="gallery_img"  name="gallery_image[]" style="display:none" required="" multiple/>
                    <img class="show_img" src="<?= base_url('assets/admin/img/upload.png') ?>" style='height:80px;width:200px;object-fit: contain;cursor:pointer;'id="upfile1" /> 
                    <font id="img_err" style="color:red;font-size:40px;"></font>
                  <?php }
                    ?>
                   

                </div>
            </div>-->
            <div class="row col-md-2">
                <input type="hidden" name="gallery_id" value="<?=$gallery->gid?>">
                <input class="form-control btn btn-success" id="submit_gallery" type="Submit" value="Save">
            </div>
        </form>
    </div>
</div>



<script src="<?= base_url('assets/admin') ?>/plugins/jquery-1.10.2.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/bootstrap/bootstrap.min.js"></script>
<script src="<?= base_url('assets/admin') ?>/plugins/metisMenu/jquery.metisMenu.js"></script>

<script src="<?= base_url('assets/admin') ?>/scripts/siminta.js"></script>

<script src="<?= base_url('assets/admin') ?>/plugins/morris/raphael-2.1.0.min.js"></script>

<script>

    $("body").on('click', '#upfile1', function () {
        $("#gallery_img").trigger('click');
    });




    function previewImages() {

        var fileCount = this.files.length;
        //alert(fileCount);
        if (fileCount > 10) {
            $("#img_err").html('Please select 10 images only !!!');
            $("#submit_gallery").prop('disabled', true);
            $("#img_err").fadeOut(7000);
        } else {
            $("#submit_gallery").prop('disabled', false);
            var $preview = $('#selected_file').empty();
            if (this.files)
                $.each(this.files, readAndPreview);

            function readAndPreview(i, file) {

                if (!/\.(jpe?g|png|gif)$/i.test(file.name)) {
                    //return alert(file.name + " is not an image");
                } // else...

                var reader = new FileReader();

                if (/\.(jpe?g|png|gif)$/i.test(file.name)) {
                    $(reader).on("load", function () {
                        $preview.append($("<img/>", {src: this.result, height: 115, width: 115}));

                    });
                } else if (/\.(mp4)$/i.test(file.name)) {
                    $(reader).on("load", function () {
                        $preview.append($("<video/>", {src: this.result, height: 100}));

                    });
                }

                reader.readAsDataURL(file);

            }



        }

    }
    $('#gallery_img').on("change", previewImages);



    $("#edit_gallery_form").on('submit', (function (event) {
        event.preventDefault();

        //  alert();
        $.ajax({
            url: "<?= base_url('admin/Admin_search/editgallery_data') ?>",
            type: "POST",
            data: new FormData(this),
            cache: false,
            contentType: false,
            processData: false,

            success: function (response) {
                if (response === 'updated') {

                    $(".show_res").html('<div class="alert alert-info alert-dismissible">\n\
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>\n\
    <strong>Sucess!</strong> Data has been added successfully.\n\
  </div>');

                
                    $(".show_res").fadeOut(5000);
                    window.location.reload();
                } else {
                    alert(response);
                }
            }

        });
    }));
</script>