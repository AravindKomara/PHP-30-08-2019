<div id="page-wrapper">
    <div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Dashboard</h1>   
        </div>
        <!--End Page Header -->
        
    </div>
</div>
<!-- end page-wrapper -->
</div>
<!-- end wrapper -->

<!-- Core Scripts - Include with every page -->
<script src="<?= base_url('') ?>assets/admin/plugins/jquery-1.10.2.js"></script>
<script src="<?= base_url('') ?>assets/admin/plugins/bootstrap/bootstrap.min.js"></script>
<script src="<?= base_url('') ?>assets/admin/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="<?= base_url('') ?>assets/admin/plugins/pace/pace.js"></script>
<script src="<?= base_url('') ?>assets/admin/scripts/siminta.js"></script>
<!-- Page-Level Plugin Scripts-->
<script src="<?= base_url('') ?>assets/admin/plugins/morris/raphael-2.1.0.min.js"></script>
<script src="<?= base_url('') ?>assets/admin/plugins/morris/morris.js"></script>
<script src="<?= base_url('') ?>assets/admin/scripts/dashboard-demo.js"></script>

</body>

</html>
