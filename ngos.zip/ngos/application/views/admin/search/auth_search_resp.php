<thead>
    <tr>
        <th><input type="checkbox" name="chk_b" id="check_all" class="checkall"></th>

        <th>Profile pic</th>

        <th>Name</th>
        <th>Mobile</th>
        <th>Type</th>
        <th>Desigination</th>
        <?php
        if($type == 'International'){
            ?><th>Country</th>
       <?php }else if($type == 'National'){
            ?><th>Country</th>
        <?php }else if($type == 'State'){
            ?><th>State</th>
      <?php }else{
            ?><th>District</th>
      <?php  }
        ?>
        
        <th><i class="fa fa-pencil-square-o"></i></th>
        <th><i class="fa fa-trash-o"></i></th>
    </tr>
</thead>

<tbody id="search_resp">
    <?php
    foreach ($auth_persons as $ia) {
        ?><tr id="auth_response<?= $ia->auth_id ?>">
            <td><input type="checkbox" name="users[]" value=""  class="checkbox1"/></td>
            <td>
                <?php
                if (!empty($ia->auth_image)) {
                    ?><img src='<?= base_url() . $ia->auth_image ?>' width="50" alt="">
                <?php } else {
                    ?><img src='<?= base_url('') ?>assets/admin/img/Ngo.png' width="50" alt="">
                <?php }
                ?> 
            </td>
            <td>
                <a href="javascript:void(0)"><?= $ia->auth_name ?></a>
            </td> 
            <td>
                <a href="javascript:void(0)"><?= $ia->auth_mobile ?></a>
            </td> 
            <td>
                <a href="javascript:void(0)"><?= $ia->auth_type ?></a>
            </td> 

            <td>
                <a href="javascript:void(0)"><?= $ia->auth_desgination ?></a>
            </td> 
            
            <?php
        if($type == 'International'){
            ?><td>
                <a href="javascript:void(0)"><?= $ia->auth_country ?></a>
            </td>
       <?php }else if($type == 'National'){
            ?><td>
                <a href="javascript:void(0)"><?= $ia->auth_country ?></a>
            </td>
        <?php }else if($type == 'State'){
            ?><td>
                <a href="javascript:void(0)"><?= $ia->auth_state ?></a>
            </td>
      <?php }else{
            ?><td>
                <a href="javascript:void(0)"><?= $ia->auth_district ?></a>
            </td>
      <?php  }
        ?>
            
            <td>
                <a href="<?= base_url('edit_auth_person/' . $ia->auth_id) ?>"  target="_new" class="btn btn-success btn-xs  edit_ngo"  data-nge-id="<?= $ia->auth_id ?>"><i class="fa fa-pencil-square-o"></i></a>
            </td>
            <td>
                <a href="javascript:;" class="btn btn-danger btn-xs  delete_auth_person" data-ngd-id="<?= $ia->auth_id ?>" data-toggle="modal" data-target="#del_auth_pop"><i class="fa fa-trash-o "></i></a>
            </td>
        </tr>
    </tbody>
<?php }
?>

