

<!-- CONTENT AREA -->
<div class="content-area">

    <!-- PAGE --> <?php
    if ($this->session->flashdata('update_pass_fail')) {
        ?>
        <div class="alert alert-danger text-center" style="z-index:1055;margin:auto;position:absolute;top:5px;right:500px;"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo $this->session->flashdata('update_pass_fail') ?>
        </div>
    <?php } ?>
  
    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->


    <section class="page-section">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade active in" id="tab-2" style="">
                    <div class="">
                        <div class="col-md-12 col-sm-6 col-md-offset-">									
                            <div class="row">
                                <div class="message-box">
                                    <div class="message-box-inner">
                                        <h2>Change Password</h2>
                                    </div>
                                </div>

                                <div class='col-md-6 col-md-offset-3'>
                                    <form method="POST" action="<?= base_url('update_password')?>">

                                        <div class="col-md-12 col-sm-2">
                                            <input type='text' class='form-control' name="member_id" placeholder='Member ID' required>
                                        </div>
                                        <div class="col-md-12 col-sm-12">
                                            <input type='password' class='form-control' name="new_pass" placeholder='New Password' required>
                                        </div>
                                        <div class="col-md-12 col-sm-12">
                                            <input type='password' class='form-control' name="confirm_pass" placeholder='Confirm Password' required>
                                        </div>


                                        <div class="col-md-12 col-sm-12">											
                                            <center><button class='btn btn-md btn-info'>Change Password</button></center>
                                        </div>
                                    </form>
                                </div>

                            </div>	
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- /PAGE -->              
</div>
<!-- /CONTENT AREA -->


