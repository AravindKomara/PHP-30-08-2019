
<!-- CONTENT AREA -->
<div class="content-area reg_success">

    <!-- PAGE -->
    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->

    <!-- PAGE-->
    <section class="page-section">
        <div class="container">
            <div class="message-box">
                <div class="message-box-inner">
                    <h2>This is National Ngos Network Park </h2>
                </div>
            </div>
        </div>
    </section>
    <!-- /PAGE -->
    <section class="page-section">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade active in" id="tab-2" style="">
                    <div class="">
                        <div class="col-md-12 col-sm-6 col-md-offset-">									
                            <div class="row">
                                <div class="message-box">
                                    <div class="message-box-inner">
                                        <h2>Profile Register </h2>
                                    </div>
                                </div>





                                <div class='col-md-6' style='border-right:1px solid lightgray'>
                                    <form method="post" id="ngo_reg_form" enctype="multipart/form-data">
                                        <div class="col-md-12 col-sm-12">
                                            <h5 class='text-center'>Trust, Managing Trustee & Scocity, President (Scocity or Trust & Personal Details)</h5>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <input type='text' class='form-control' value='Managing Trustee or President Name' readonly>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <input type='text' class='form-control' name ="tru_pre_name" placeholder='Name' required>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <input type='text' class='form-control' value='Sure Name' readonly>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <input type='text' class='form-control' name="tru_pre_same" placeholder='Name'>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <input type='text' class='form-control' value='S/O W/O D/O others' readonly>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <input type='text' class='form-control' name ="tru_pre_of" placeholder='Name'>
                                        </div>

                                      
                                        <div class="col-md-6 col-sm-6">
                                            <input type='text' class='form-control' value='Personal Pan Card Number' readonly>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <input type='text' class='form-control' name="tru_pre_pancard"  placeholder='Number'>
                                        </div>

                                       
                                        <div class="col-md-6 col-sm-6">
                                            <input type='text' class='form-control' value='Other Mobile Number' readonly>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <input type='text' class='form-control' name="tru_pre_mobile2" placeholder='Number'>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <input type='text' class='form-control' value='Your Working From' readonly>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <input type='text' class='form-control' name="tru_pre_landline" placeholder='Yes/No'>
                                        </div>

                                        <div class="col-md-6 col-sm-6">
                                            <input type='text' class='form-control'  value='Your Personal Study Certificates'  readonly>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <input type='file' class='form-control'name="tru_pre_govproof" placeholder='Number'>
                                        </div>

                                        <div class="col-md-6 col-sm-6">
                                            <input type='text' class='form-control'  value='ProfilePic'  readonly>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <input type='file' class='form-control' name="profile_pic" placeholder='Number' >
                                        </div>
                                        <div class="col-md-12 col-sm-12">


                                        </div>


                                </div>


                                <div class='col-md-6'>

                                    <div class="col-md-12 col-sm-12">
                                        <h5 class='text-center'>Trust, Managing Trustee & Scocity, President (Scocity or Trust & Personal Details)</h5>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='Trustee or Securtary Name' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tru_sec_name" placeholder='Name' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control'  value='Sure Name' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tru_sec_same" placeholder='Name'>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='S/O W/O D/O others' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tru_sec_of" placeholder='Name'>
                                    </div>

                                    <div class="col-md-6 col-sm-6">
                                        <input type='email' class='form-control' value='E-Mail Id' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='email' class='form-control' name="tru_sec_email" placeholder='email'>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='Personal Pan Card Number' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tru_sec_pancard" placeholder='Number' >
                                    </div>

                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='Mobile Number' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tru_sec_mobile1" placeholder='Number'>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='Other Mobile Number' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tru_sec_mobile2" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='Your Working From' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tru_sec_landline" placeholder='Yes/No'>
                                    </div>


                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='Your Personal Study Certificates'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tru_sec_govproof" placeholder='Number' >
                                    </div>

                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='Choice 4 Digit Password'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='password' class='form-control' name="password" placeholder='Password' >
                                    </div>

                                    <div class="col-md-12 col-sm-12">


                                    </div>






                                </div>
                                <div class="col-md-12 col-sm-12">
                                    <h5 class='text-center'>(Scocity or Trust & Personal Details)</h5>
                                </div>

                                <div class='col-md-6'>


                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='Trust or Scocity  Name'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='name' class='form-control' name="tr_name" placeholder='Name' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='Trust or Scocity   Registration Date' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_reg_date" placeholder='Name' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='Trust or Scocity  Pan Card Number' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_pancard" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='12AA Registration Number' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_12AA_num" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='80G Registration Number ' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_80Gnum" placeholder='Number'  >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='F C R A Registration Number' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_FCRA_num" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='10 & 23 Registration Number ' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_1023_num" placeholder='Number' >
                                    </div>

                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='35 1&2 AC Registration Number' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control'name="tr_35AC_num"  placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='501 C Registration Number' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_501C_num" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='Niti aayog certificate Registration Number' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_nitiayog_num" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='3 year IT Returns Dates'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_3IT_dates" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='3 year Audit Reports Dates'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_3AR_dates" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='3 year FCRA Returns Dates'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_3FCRA_dates" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='New Projects Reports'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' namee="tr_new_proj" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='Any Running project Reports (Yes or No)'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_runnig_proj" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='Youtube Link'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_landline" placeholder='Link' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='Facebook Link'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_mobile" placeholder='Link' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='email' class='form-control' value='Your Website'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='email' class='form-control' name="tr_email" placeholder='Your Website' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='Reference Id Number'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' name="tr_refid" id="get_refcode" onblur="calculate_refamount()" placeholder='Enter your refer code' >
                                        <font id="ref_code_error" style="color: red;font-size: 25px;"></font>
                                    </div>

                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='Reference Id 10% GiftAmount'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control show_dis_amnt' name="tr_refid_gift" placeholder='Number' >
                                    </div>

                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='Passport  Copy '  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_passport_proof" placeholder='Name' >
                                    </div>



                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control'  value='Country'  readonly>
                                        <input type="hidden" name="country" value="" id="get_count">
                                    </div>

                                    <div class="col-md-6 col-sm-6">
                                        <select class="form-control" style=" height:40px;" id="uniq_country">
                                            <?php
                                            $countries = $this->States_districts->get_all_countries();
                                            foreach ($countries as $c) {
                                                ?><option value="<?= $c->cname ?>"><?= $c->cname ?></option>
                                            <?php }
                                            ?>
                                        </select>


                                    </div>
                                    <div class="col-md-12 col-sm-12">


                                    </div>

                                </div>



                                <div class='col-md-6'>


                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='Trust Deed or Society Baila  Copy '  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_bill_proof" placeholder='Name' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='Trust or Scocity   Registration Certificate' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_regcer_proof" placeholder='Name' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='Trust or Scocity  Pan Card Number Copy' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_pancard_proof" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='12AA Registration Number Copy' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_12AA_proof" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='80G Registration Number Copy ' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_80G_proof" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='F C R A Registration Number Copy' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_FCRA_proof" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='10 & 23 Registration Number Copy ' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_1023_proof" placeholder='Number' >
                                    </div>

                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='35 1&2 AC Registration Number Copy' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_35AC_proof" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='501 C Registration Number Copy' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_501C_proof" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='text' class='form-control' value='niti aayog certificate' readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_nitiayog_proof" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='3 year IT Returns Dates' required readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_3IT_dat_proof" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='3 year Audit Reports Dates'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_3AR_dat_proof" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='3 year FCRA Returns Dates'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_3FCRA_dat_proof" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='New Projects Reports'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_new_proj_proof" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='Any Running project Reports'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name = "tr_running_proj_proof" placeholder='Number' >
                                    </div>

                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='Paper Cutting Copies'  readonlyd>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_paper_cutting_proof" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='Photos Copies'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_photo" placeholder='Number' >
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='FCRA Audit Peports'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_FCRA_audit_proof" placeholder='Number' >
                                    </div>




                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='Your Certificates Copy'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='file' class='form-control' name="tr_currentbill_proof" placeholder='Number' >
                                    </div>

                                  

                                    

                                    <div class="col-md-12 col-sm-12">


                                    </div>

                                </div>

                                <div class='col-md-6'>
                                    <div class="col-md-6 col-sm-6">
                                        <input type='' class='form-control' value='Text'  readonly>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <textarea rows="5" cols="50"  name="tr_text" placeholder="Describe yourself here..." style=" height: 129px; width: 530px;"></textarea>

                                    </div>
                                </div>

                                <div class="col-md-12 col-sm-12">
                                    <input type="checkbox" name="check_click" id='check_click'> I agree to the terms and conditions<br>
                                </div>



                                <div class="col-md-12 col-sm-12">
                                    <center>
                                        <p style="color: green;font-size: 25px;">These site is 100% legal and ngo's will be paid 18% GST to GOVERNMENT OF INDIA</p>
                                        <button class='btn btn-md btn-info'>Submit</button>&nbsp;&nbsp;&nbsp;&nbsp; <button class='btn btn-md btn-info'>Edit</button>
                                    </center>

                                </div>


                                <input type="hidden" name="reg_type" value="<?= $type ?>">
                                 <input type="hidden" name="reg_type1" value="<?= $_SESSION['reg_type'] ?>">
                                 <input type='hidden' class='form-control' id="primary_email" name="tru_pre_email" value="Empty" placeholder='email'>
                                 <input type="hidden" name="mobilecode" value="XXXXXXXXXX" id="get_mobilecode">
                                 <input type='hidden' class='form-control' id="primary_mobile" name="tru_pre_mobile1" value="XXXXXXXXXX" placeholder='Number' required="">
                                 <input type='hidden' class='form-control' name="mobile_visible_status" placeholder='Hide/Display' value="hide" required="">

                                </form>

                            </div>	
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- /PAGE -->              
</div>
<!-- /CONTENT AREA -->


<script>

    $("#uniq_country").on('change', function () {
        var country = $(this).val();
        // alert(country);
        $("#get_count").val(country);

    });

    $("#uniq_mobile_code").on('change', function () {
        var mobilecode = $(this).val();
     //  alert(mobilecode);
        $("#get_mobilecode").val(mobilecode);

    });

    $('input[type="checkbox"]').click(function () {
        if ($(this).prop("checked") === true) {
            // alert("Checkbox is checked.");
            $("#ngo_reg_form").on('submit', function (e) {
                e.preventDefault();
                // alert();

             
                    $.ajax({
                        url: "<?= base_url('Ngos/ngo_register') ?>", // Url to which the request is send
                        type: "POST", // Type of request to be send, called as method
                        data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                        contentType: false, // The content type used when sending data to the server.
                        cache: false, // To unable request pages to be cached
                        processData: false, // To send 
                        success: function (response) {
                            $('.reg_success').html('<img class="text-center" src="<?= base_url('assets/img/right.png') ?>" alt="" width="50" height="50" /> <br> <span align="center" style="color:green">Registration completed successfully...</span>');
                            $('.reg_success').html('<span align="center" style="color:green; font-size:50px;">Your MemberID Is:'+response+'</span>');
                            $(".reg_success").show();
                           

                        }
                    });

                

            });
        } else if ($(this).prop("checked") === false) {
            alert("Please accept the terms and conditions..");
        }
    });


    function calculate_refamount() {
        var refcode = $("#get_refcode").val();
        var price = $('#reg_price').val();
        var discount = (10 / 100) * price;
        //alert(discount);
        $.ajax({
            url: "<?= base_url('Ngos/validate_refcode') ?>",
            type: "POST",
            data: {
                refcode: refcode
            },
            success: function (response) {
                if (response === 'valid') {
                    $(".show_dis_amnt").val(discount);
                    $("#ref_code_error").fadeOut();
                } else {
                    $("#ref_code_error").html("Referal Code is in valid...");
                    //  $("#ref_code_error").fadeOut(5000);
                }
            }
        });

    }

</script>

