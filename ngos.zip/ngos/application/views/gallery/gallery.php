

<!-- CONTENT AREA -->
<div class="content-area">

    <!-- PAGE --> <?php
    if ($this->session->flashdata('update_pass_fail')) {
        ?>
        <div class="alert alert-danger text-center" style="z-index:1055;margin:auto;position:absolute;top:5px;right:500px;"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo $this->session->flashdata('update_pass_fail') ?>
        </div>
    <?php } ?>

    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->
    <section class="page-section">
        <div class="container">
            <div class="message-box">
                <?php
                if (!empty($banner->bn_text)) {
                    ?> <div class="message-box-inner">
                        <h2><?= $banner->bn_text ?> </h2>
                    </div>
                <?php } else {
                    ?><div class="message-box-inner">
                        <h2>This is International Ngos Network Only For Advertising Purpose </h2>
                    </div>
                <?php }
                ?>
            </div>
        </div>
    </section>


    <section class="page-section">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade active in" id="tab-2" style="">
                    <div class="">
                        <div class="col-md-12 col-sm-6 col-md-offset-">									
                            <div class="row">
                                <div class="message-box">
                                    <div class="message-box-inner">
                                        <h2>Events</h2>
                                    </div>
                                </div>
                                <font id="ref_resp" style="color:green;font-size:20px;"></font>
                                <div class='col-md-6 col-md-offset-3'>
                                    <div class="table-responsive">
                                        <form method="post" > 
                                            <?php
                                            if (!empty($gallery)) {
                                                ?><table class="table table-striped table-responsive table-hover">
                                                    <thead>
                                                        <tr>


                                                            <th>Event Date</th>
                                                            <th>Event Name</th>
                                                            <th>Event Organized By</th>
                                                            <th>Event Location</th>

                                                            <th>Images</th>


                                                        </tr>
                                                    </thead>

                                                    <tbody>
                                                        <?php
                                                        foreach ($gallery as $g) {
                                                            ?> <tr id="gallery_response<?= $g->gid ?>">

                                                                <td>
                                                                    <a href="javascript:void(0)"><?= date('m-d-Y', strtotime($g->date)) ?></a>
                                                                </td> 
                                                                <td>
                                                                    <a href="javascript:void(0)"><?= $g->event_name ?></a>
                                                                </td> 
                                                                <td>
                                                                    <a href="javascript:void(0)"><?= $g->organized_by ?></a>
                                                                </td> 
                                                                <td>
                                                                    <a href="javascript:void(0)"><?= $g->location ?></a>
                                                                </td> 
                                                                <td>
                                                                    <a href="<?= base_url('event_details/' . $g->gid) ?>"  class="btn btn-success btn-xs">View Images</a>
                                                                </td> 



                                                            </tr>

                                                        <?php }
                                                        ?>


                                                    </tbody>

                                                </table>
                                            <?php } else {
                                                ?> <div class="message-box">
                                                    <div class="message-box-inner">
                                                        <h3 style="color: red;">Sorry!!!!  don't have any events </h3>
                                                    </div>
                                                </div>

                                            <?php }
                                            ?>



                                        </form>
                                    </div>
                                </div>

                            </div>	
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- /PAGE -->              
</div>
<!-- /CONTENT AREA -->

<script>
    $(".with_draw").click(function () {
        /// alert(); 
        var memberid = $(this).attr("data-nge-id");
        var amount = $(this).attr("data-amount");

        $.ajax({
            url: "<?= base_url('Ngos/refmoney_withdraw') ?>",
            type: "POST",
            data: {
                memberid: memberid,
                amount: amount

            },
            success: function (response) {
                if (response === 'inserted') {
                    $("#ref_resp").html('Your requset has been submitted,we will credit money to your account within 7 business days!!!');
                    $("#ref_resp").fadeOut(15000);
                    //  window.location.reload();
                } else if (response === 'alredy_inserted') {
                    $("#ref_resp").html('we are already received your requset,please be patitence we will credit money to your account as soon as possible!!!');
                    $("#ref_resp").fadeOut(15000);
                    // window.location.reload();
                }
            }
        });
    });
</script>


