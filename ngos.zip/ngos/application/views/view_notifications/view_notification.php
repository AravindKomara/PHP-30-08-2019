

<!-- CONTENT AREA -->
<div class="content-area">

    <!-- PAGE -->
    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->

    <!-- PAGE-->
    <section class="page-section">
        <div class="container">
            <div class="message-box">
                <?php
                if (!empty($banner->bn_text)) {
                    ?> <div class="message-box-inner">
                        <h2><?= $banner->bn_text ?> </h2>
                    </div>
                <?php } else {
                    ?><div class="message-box-inner">
                        <h2>This is International Ngos Network Only For Advertising Purpose </h2>
                    </div>
                <?php }
                ?>
            </div>
        </div>
    </section>
    <!-- /PAGE -->
    <section class="page-section">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade active in" id="tab-2" style="">
                    <div class="">
                        <div class="col-md-12 col-sm-6 col-md-offset-">
                         <?php
                         if(!empty($notification->notification_text)){
                             ?><p><?=$notification->notification_text?></p>
                        <?php }else{
                            ?> <p>Coming soon........</p>
                        <?php }
                         ?>
                           
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- /PAGE -->              
</div>
<!-- /CONTENT AREA -->

