<?php
if ($this->session->flashdata('dt_ngo_fail')) {
                                ?>
                                <div class="alert alert-danger text-center" style="z-index:1055;margin:auto;position:absolute;top:5px;right:500px;"> 
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <?php echo $this->session->flashdata('dt_ngo_fail') ?>
                                </div>
    <?php } ?>

<!-- CONTENT AREA -->
<div class="content-area states_resp">

    <!-- PAGE -->
    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->

    <!-- PAGE-->
    <section class="page-section">
        <div class="container">
            <div class="message-box">
                <?php
                if (!empty($banner->bn_text)) {
                    ?> <div class="message-box-inner">
                        <h2><?= $banner->bn_text ?> </h2>
                    </div>
                <?php } else {
                    ?><div class="message-box-inner">
                        <h2>This is International Ngos Network Only For Advertising Purpose </h2>
                    </div>
                <?php }
                ?>
            </div>
        </div>
    </section>
    <!-- /PAGE -->
    <section class="page-section">
        <div class="container">



            <div class="tab-content">

                <!-- tab 2 -->
                <div class="tab-pane fade active in" id="tab-2" >
                    <div class="row">

                        <?php
                        foreach ($states as $s) {
                            $state = str_replace(" ","_",$s->name);
                            ?> <div class="col-md-2 col-sm-6">
                                <div class="thumbnail no-border no-padding">
                                    <div class="media">
                                        <a href="javascript:void(0)" class="get_districts" data-sid="<?=$s->id?>"><h4 align=""><?= $s->name ?></h4></a>
                                       
                                    </div>
                                </div>
                            </div> 
                        <?php }
                        ?>





                    </div>









                </div>
            </div>

            <!-- tab 3 -->

        </div>
        
        </section>

</div>

<!-- /PAGE -->              

<!-- /CONTENT AREA -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>

    $(".get_districts").click(function () {
        var sid = $(this).attr("data-sid");
      // alert(sid);

        $.ajax({
            url: "<?= base_url('States/get_state_districts') ?>", 
            type: "POST", 
            data:{
                state_id : sid 
            }, 
            
            success: function (response) {
                 $(".states_resp").fadeOut();
               $(".auth_resp").html(response);
              
            }

        });

    });
</script>