<?php
// header('Cache-Control: no cache'); //no cache
//session_cache_limiter('private_no_expire'); // works
//session_cache_limiter('public'); // works too
//session_start();
?>                        
<div class="col-md-12">
    <div class="nav-left">
        <ul>
            <li><a href="<?= base_url('change_password') ?>"> Change password</a></li>
<?php
if ($udetails->membership_status == 'inactive') {
    ?><li><a href="<?= base_url('account_payment') ?>">Make payment</a></li>
            <?php }
            ?>

            <li><a href="<?= base_url('refral_bonus') ?>">Referral Points</a></li>
            <li><a href="<?= base_url('logout_user') ?>">Logout</a></li>

        </ul>
    </div>
    <div class="right-area">
        <div class='col-md-6' style='border-right:1px solid lightgray'>
            <form method="post" id="ngo_edit_form" enctype="multipart/form-data">
                <div class="col-md-12 col-sm-12">
                    <h5 class='text-center'>Trust, Managing Trustee & Scocity, President (Scocity or Trust & Personal Details)</h5>
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='text' class='form-control' value='Managing Trustee or President Name' readonly>
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='text' class='form-control' name ="tru_pre_name" value="<?php
                if (!empty($udetails->tru_pre_name)) {
                    echo $udetails->tru_pre_name;
                } else {
                    
                }
            ?>" placeholder='Name' >
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='text' class='form-control' value='Sure Name' readonly>
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='text' class='form-control' name="tru_pre_same" value="<?php
                    if (!empty($udetails->tru_pre_same)) {
                        echo $udetails->tru_pre_same;
                    } else {
                        
                    }
            ?>" placeholder='Name' >
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='text' class='form-control' value='S/O W/O D/O others' readonly>
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='text' class='form-control' name ="tru_pre_of" value="<?php
                    if (!empty($udetails->tru_pre_of)) {
                        echo $udetails->tru_pre_of;
                    } else {
                        
                    }
                    ?>" placeholder='Name' >
                </div>

                <div class="col-md-6 col-sm-6">
                    <input type='email' class='form-control' value='E-Mail Id' readonly>
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='email' class='form-control' name="tru_pre_email" value="<?php
                           if (!empty($udetails->tru_pre_email)) {
                               echo $udetails->tru_pre_email;
                           } else {
                               
                           }
                           ?>" placeholder='email' >
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='text' class='form-control' value='Personal Pan Card Number' readonly>
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='text' class='form-control' name="tru_pre_pancard"  value="<?php
                           if (!empty($udetails->tru_pre_pancard)) {
                               echo $udetails->tru_pre_pancard;
                           } else {
                               
                           }
                           ?>" placeholder='Number' >
                </div>

                <div class="col-md-6 col-sm-6">
                    <input type='text' class='form-control' value='Mobile Number' readonly>
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='number' class='form-control' name="tru_pre_mobile1"  value="<?php
                           if (!empty($udetails->tru_pre_mobile1)) {
                               echo $udetails->tru_pre_mobile1;
                           } else {
                               
                           }
                           ?>" placeholder='Number' >
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='text' class='form-control' value='Other Mobile Number' readonly>
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='number' class='form-control' name="tru_pre_mobile2" value="<?php
                    if (!empty($udetails->tru_pre_mobile2)) {
                        echo $udetails->tru_pre_mobile2;
                    } else {
                        
                    }
                           ?>" placeholder='Number' >
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='text' class='form-control' value='You are working from' readonly>
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='number' class='form-control' name="tru_pre_landline"  value="<?php
                           if (!empty($udetails->tru_pre_landline)) {
                               echo $udetails->tru_pre_landline;
                           } else {
                               
                           }
                           ?>" placeholder='Number' >
                </div>

                <div class="col-md-6 col-sm-6">
                    <input type='text' class='form-control'  value='Your personal study certificates'  readonly>
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='file' class='form-control'name="tru_pre_govproof" placeholder='Number' >
                </div>

                <div class="col-md-6 col-sm-6">
                    <input type='text' class='form-control'  value='ProfilePic'  readonly>
                </div>
                <div class="col-md-6 col-sm-6">
                    <input type='file' class='form-control' name="profile_pic" placeholder='Number' >
                </div>
                <div class="col-md-12 col-sm-12">


                </div>


        </div>


        <div class='col-md-6'>

            <div class="col-md-12 col-sm-12">
                <h5 class='text-center'>Trust, Managing Trustee & Scocity, President (Scocity or Trust & Personal Details)</h5>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='Trustee or Securtary Name' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tru_sec_name" value="<?php
                       if (!empty($udetails->tru_sec_name)) {
                           echo $udetails->tru_sec_name;
                       } else {
                           
                       }
                       ?>" placeholder='Name' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control'  value='Sure Name' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tru_sec_same" value="<?php
                       if (!empty($udetails->tru_sec_same)) {
                           echo $udetails->tru_sec_same;
                       } else {
                           
                       }
                       ?>" placeholder='Name' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='S/O W/O D/O others' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tru_sec_of" value="<?php
                       if (!empty($udetails->tru_sec_of)) {
                           echo $udetails->tru_sec_of;
                       } else {
                           
                       }
                       ?>" placeholder='Name' >
            </div>

            <div class="col-md-6 col-sm-6">
                <input type='email' class='form-control' value='E-Mail Id' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='email' class='form-control' name="tru_sec_email" value="<?php
                if (!empty($udetails->tru_sec_email)) {
                    echo $udetails->tru_sec_email;
                } else {
                    
                }
                       ?>" placeholder='email' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='Personal Pan Card Number' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tru_sec_pancard" value="<?php
                if (!empty($udetails->tru_sec_pancard)) {
                    echo $udetails->tru_sec_pancard;
                } else {
                    
                }
                ?>" placeholder='Number' >
            </div>

            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='Mobile Number' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='number' class='form-control' name="tru_sec_mobile1" value="<?php
                       if (!empty($udetails->tru_sec_mobile1)) {
                           echo $udetails->tru_sec_mobile1;
                       } else {
                           
                       }
                       ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='Other Mobile Number' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='number' class='form-control' name="tru_sec_mobile2" value="<?php
                       if (!empty($udetails->tru_sec_mobile2)) {
                           echo $udetails->tru_sec_mobile2;
                       } else {
                           
                       }
                       ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='You are working from' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='number' class='form-control' name="tru_sec_landline"  value="<?php
                       if (!empty($udetails->tru_sec_landline)) {
                           echo $udetails->tru_sec_landline;
                       } else {
                           
                       }
                       ?>" placeholder='Number' >
            </div>


            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='Your personal study certificates'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tru_sec_govproof" placeholder='Number' >
            </div>

            <!--                                    <div class="col-md-6 col-sm-6">
                                                    <input type='' class='form-control' value='Password'  readonly>
                                                </div>
                                                <div class="col-md-6 col-sm-6">
                                                    <input type='password' class='form-control' name="password" placeholder='Password' >
                                                </div>-->

            <div class="col-md-12 col-sm-12">


            </div>






        </div>
        <div class="col-md-12 col-sm-12">
            <h5 class='text-center'>(Scocity or Trust & Personal Details)</h5>
        </div>

        <div class='col-md-6'>


            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='Trust or Scocity  Name'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='name' class='form-control' name="tr_name" value="<?php
                       if (!empty($udetails->tr_name)) {
                           echo $udetails->tr_name;
                       } else {
                           
                       }
                       ?>" placeholder='Name' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='Trust or Scocity   Registration Date' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_reg_date" value="<?php
                if (!empty($udetails->tr_reg_date)) {
                    echo $udetails->tr_reg_date;
                } else {
                    
                }
                ?>" placeholder='Name' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='Trust or Scocity  Pan Card Number' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_pancard" value="<?php
                       if (!empty($udetails->tr_pancard)) {
                           echo $udetails->tr_pancard;
                       } else {
                           
                       }
                       ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='12AA Registration Number' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_12AA_num" value="<?php
                       if (!empty($udetails->tr_12AA_num)) {
                           echo $udetails->tr_12AA_num;
                       } else {
                           
                       }
                       ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='80G Registration Number ' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_80Gnum" value="<?php
                       if (!empty($udetails->tr_80Gnum)) {
                           echo $udetails->tr_80Gnum;
                       } else {
                           
                       }
                       ?>" placeholder='Number'  >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='F C R A Registration Number' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_FCRA_num" value="<?php
                if (!empty($udetails->tr_FCRA_num)) {
                    echo $udetails->tr_FCRA_num;
                } else {
                    
                }
                       ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='10 & 23 Registration Number ' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_1023_num" value="<?php
                if (!empty($udetails->tr_1023_num)) {
                    echo $udetails->tr_1023_num;
                } else {
                    
                }
                ?>" placeholder='Number' >
            </div>

            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='35 1&2 AC Registration Number' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='number' class='form-control'name="tr_35AC_num"  value="<?php
                       if (!empty($udetails->tr_35AC_num)) {
                           echo $udetails->tr_35AC_num;
                       } else {
                           
                       }
                       ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='501 C Registration Number' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_501C_num" value="<?php
                       if (!empty($udetails->tr_501C_num)) {
                           echo $udetails->tr_501C_num;
                       } else {
                           
                       }
                       ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='Niti aayog certificate Registration Number' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_nitiayog_num" value="<?php
                       if (!empty($udetails->tr_nitiayog_num)) {
                           echo $udetails->tr_nitiayog_num;
                       } else {
                           
                       }
                       ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='3 year IT Returns Dates'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_3IT_dates" value="<?php
                if (!empty($udetails->tr_3IT_dates)) {
                    echo $udetails->tr_3IT_dates;
                } else {
                    
                }
                       ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='3 year Audit Reports Dates'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_3AR_dates" value="<?php
                if (!empty($udetails->tr_3AR_dates)) {
                    echo $udetails->tr_3AR_dates;
                } else {
                    
                }
                ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='3 year FCRA Returns Dates'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_3FCRA_dates" value="<?php
                       if (!empty($udetails->tr_3FCRA_dates)) {
                           echo $udetails->tr_3FCRA_dates;
                       } else {
                           
                       }
                       ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='New Projects Reports'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' namee="tr_new_proj" value="<?php
                       if (!empty($udetails->tr_new_proj)) {
                           echo $udetails->tr_new_proj;
                       } else {
                           
                       }
                       ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='Any Running project Reports (Yes or No)'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_runnig_proj" value="<?php
                       if (!empty($udetails->tr_runnig_proj)) {
                           echo $udetails->tr_runnig_proj;
                       } else {
                           
                       }
                       ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='Trust Or Society Land Number'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_landline" value="<?php
            if (!empty($udetails->tr_landline)) {
                echo $udetails->tr_landline;
            } else {
                
            }
            ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='Trust Or Society Phone Number'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_mobile" value="<?php
                    if (!empty($udetails->tr_mobile)) {
                        echo $udetails->tr_mobile;
                    } else {
                        
                    }
                    ?>" placeholder='Number' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='email' class='form-control' value='Trust Or Society E-Mail Id'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='email' class='form-control' name="tr_email" value="<?php
                    if (!empty($udetails->tr_email)) {
                        echo $udetails->tr_email;
                    } else {
                        
                    }
                    ?>" placeholder='E- mail Id' >
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='Reference Id Number'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_refid" value="<?php
            if (!empty($udetails->tr_refid)) {
                echo $udetails->tr_refid;
            } else {
                
            }
                    ?>" placeholder='Number' >
            </div>

            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='Reference Id 10% GiftAmount'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' name="tr_refid_gift" value="<?php
                    if (!empty($udetails->tr_refid_gift)) {
                        echo $udetails->tr_refid_gift;
                    } else {
                        
                    }
                    ?>" placeholder='Number' >
            </div>

            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='Passport  Copy '  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_passport_proof" placeholder='Name' >
            </div>




<?php
if ($udetails->type == 'International') {
    ?><div class="col-md-6 col-sm-6">
                    <input type='' class='form-control'  value='Country'  readonly>

                </div>

                <div class="col-md-6 col-sm-6">

                    <input type="hidden" name="auth_residence" value="<?= $udetails->country ?>" id="get_auth_residence">

                    <input type="hidden" name="auth_res" value="country">
                    <select name="State" style=" height:40px;width:225px;" id="uniq_count_person">
                                <?php
                                $countries = $this->States_districts->get_all_countries();
                                foreach ($countries as $c) {
                                    ?><option value="<?= $c->cname ?>"<?php
                                    if ($udetails->country == $c->cname) {
                                        echo 'selected';
                                    }
                                    ?>> 
        <?php echo $c->cname ?></option>

    <?php } ?> 

                    </select>
                </div>


<?php } elseif ($udetails->type == 'National') {
    ?><div class="col-md-6 col-sm-6">
                    <input type='' class='form-control'  value='Country'  readonly>

                </div>

                <div class="col-md-6 col-sm-6">
                    <input type="hidden" name="auth_res" value="national"> 
                    <input type='text' class='form-control'  name="country" value='India'  readonly> 
                </div>
<?php } elseif ($udetails->type == 'State') {
    ?> <div class="col-md-6 col-sm-6">
                    <input type='' class='form-control'  value='State'  readonly>

                </div>

                <div class="col-md-6 col-sm-6">
                    <input type="hidden" name="auth_residence" value="<?= $udetails->state ?>" id="get_auth_residence"> 
                    <label for="ex1" style="color:initial;">State</label><br>
                    <input type="hidden" name="auth_res" value="state">
                    <select name="Desigination" style=" height:40px;width:225px;" id="uniq_perstate">
    <?php
    $states = $this->States_districts->all_indian_states();
    foreach ($states as $s) {
        ?><option value="<?= $s->name ?>"<?php
        if ($udetails->state == $s->name) {
            echo 'selected';
        }
        ?>> <?php echo $s->name ?></option>

    <?php } ?>  

                    </select>
                </div>
<?php } else {
    ?> <div class="col-md-6 col-sm-6">
                    <input type='' class='form-control'  value='District'  readonly>

                </div>

                <div class="col-md-6 col-sm-6">
                    <input type="hidden" name="auth_residence" value="<?= $udetails->district ?>" id="get_auth_residence"> 

                    <input type="hidden" name="auth_res" value="district">
                    <select name="Desigination" style=" height:40px;width:225px;" id="uniq_district">
    <?php
    $dist = $this->States_districts->get_district($udetails->district);
    $districts = $this->States_districts->get_all_districts_state($dist->state_id);
    foreach ($districts as $d) {
        ?><option value="<?= $d->name ?>"<?php
        if ($udetails->district == $d->name) {
            echo 'selected';
        }
        ?>> <?php echo $d->name ?></option>

    <?php } ?>  

                    </select>
                </div>
<?php }
?>


            <div class="col-md-12 col-sm-12">


            </div>

        </div>





        <div class='col-md-6'>


            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='Trust Deed or Society Baila  Copy '  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_bill_proof" placeholder='Name' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_bill_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='Trust or Scocity   Registration Certificate' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_regcer_proof" placeholder='Name' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_regcer_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='Trust or Scocity  Pan Card Number Copy' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_pancard_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_pancard_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='12AA Registration Number Copy' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_12AA_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_12AA_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='80G Registration Number Copy ' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_80G_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_80G_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='F C R A Registration Number Copy' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_FCRA_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_FCRA_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='10 & 23 Registration Number Copy ' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_1023_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_1023_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>

            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='35 1&2 AC Registration Number Copy' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_35AC_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_35AC_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='501 C Registration Number Copy' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_501C_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_501C_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='text' class='form-control' value='niti aayog certificate' readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_nitiayog_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_nitiayog_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='3 year IT Returns Dates'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_3IT_dat_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_3IT_dat_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='3 year Audit Reports Dates'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_3AR_dat_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_3AR_dat_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='3 year FCRA Returns Dates'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_3FCRA_dat_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_3FCRA_dat_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='New Projects Reports'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_new_proj_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_new_proj_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='Any Running project Reports'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name = "tr_running_proj_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_running_proj_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>

            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='Paper Cutting Copies' require readonlyd>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_paper_cutting_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_paper_cutting_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='Photos Copies'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_photo" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_photo ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='FCRA Audit Peports'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_FCRA_audit_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_FCRA_audit_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>




            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='Current Bill'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <input type='file' class='form-control' name="tr_currentbill_proof" placeholder='Number' >
                <a href="javascript:void(0)" class="show_certificate" data-img="<?= base_url() . $udetails->tr_currentbill_proof ?>" data-toggle="modal" data-target="#display_modal">Download File</a>
            </div>

            <!--            <div class="col-md-6 col-sm-6">
                            <input type='' class='form-control' value='Membership Fee'  readonly>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <input type='text' class='form-control' name="tr_membership_fee" value=""  readonly="">
                        </div>
            
            
            
                        <div class="col-md-6 col-sm-6">
                            <input type='' class='form-control' value='ServiceTax 18%'  readonly>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <input type='text' class='form-control' name="tr_servicetax_fee" value=""  readonly="">
                        </div>
            
                        <div class="col-md-6 col-sm-6">
                            <input type='' class='form-control' value='Total Amount'  readonly>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <input type='text' class='form-control' name="tr_total_amount" value=""  readonly="">
                        </div>-->


            <div class="col-md-12 col-sm-12">


            </div>

        </div>

        <div class='col-md-6'>
            <div class="col-md-6 col-sm-6">
                <input type='' class='form-control' value='Text'  readonly>
            </div>
            <div class="col-md-6 col-sm-6">
                <textarea rows="5" cols="50"  name="tr_text" placeholder="Describe yourself here..." style=" height: 129px; width: 530px;"></textarea>

            </div>
        </div>

        <div class="col-md-12 col-sm-12">
            <input type="checkbox" name="check_click" id='check_click'> I agree to the terms and conditions<br>
        </div>



        <div class="col-md-12 col-sm-12">
            <center>
                <p style="color: green;font-size: 25px;">These site is 100% legal and ngo's will be paid 18% GST to GOVERNMENT OF INDIA</p>
                <button class='btn btn-md btn-info'>Submit</button>&nbsp;&nbsp;&nbsp;&nbsp; <button class='btn btn-md btn-info'>Edit</button>
            </center>

        </div>
        <input type="hidden" name="reg_type" value="">

        </form>
    </div>


</div>
</div>


<div id="display_modal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close del_memb_close" id="close-approve-popup" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Modal Header</h4>
            </div>
            <div class="modal-body">
                <h2 class="img_res"></h2>
                <h4 class="doc_res"></h4>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>


<script>
    $(".show_certificate").click(function () {

        var file = $(this).attr("data-img");
        var ext = file.split('.').pop();
        //alert(ext);
        if (ext === 'jpg' || ext === 'jpeg' || ext === 'png') {
            // alert(ext);
            $(".doc_res").html("<img src='" + file + "'+'width=140 height=140' >");
        } else {

            $(".img_res").html("<iframe src='" + file + "'+'width=0 height=0 visibility:hidden' ></iframe>");
            $(".doc_res").html('<font style="color:green;font-size:20px;">Your file is downloaded successfully!!!</font>');
            $(".del_memb_close").click();
            $(".img_res").fadeOut();
        }
    });


    $("#ngo_edit_form").on('submit', function (e) {
        e.preventDefault();
        alert();

        $.ajax({
            url: "<?= base_url('Ngos/ngo_update') ?>", // Url to which the request is send
            type: "POST", // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false, // The content type used when sending data to the server.
            cache: false, // To unable request pages to be cached
            processData: false, // To send 
            success: function (response) {
                $('.reg_success').html('<img class="text-center" src="<?= base_url('assets/img/right.png') ?>" alt="" width="50" height="50" /> <br> <span align="center" style="color:green">Registration completed successfully...</span>');
                $(".reg_success").show();
                setTimeout(function () {
                    $(".reg_success").html(response);
                }, 3000);

            }
        });

    });


//    $('input[type="checkbox"]').click(function () {
//        if ($(this).prop("checked") == true) {
//            // alert("Checkbox is checked.");
//            
//        } else if ($(this).prop("checked") == false) {
//            alert("Checkbox is unchecked.");
//        }
//    });
</script>






