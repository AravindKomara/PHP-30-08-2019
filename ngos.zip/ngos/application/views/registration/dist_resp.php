<div class="col-md-4">

    <label for="ex1" style="color:initial;">Districts</label><br>
 <input type="hidden" name="person_district" value="" id="get_perdist">
    <select class="form-control" style="height:50px;width:335px;" id="uniq_district">
        <?php
        foreach ($districts as $d) {
            ?><option value="<?= $d->name ?>"><?= $d->name ?></option>
        <?php }
        ?>
    </select>


</div>



<script>
    $("#uniq_district").on('change', function () {
        var district = $(this).val();
        // alert(district);
     
        $("#get_perdist").val(district);
        $("#get_dist_banner").val(district);

    });
</script>