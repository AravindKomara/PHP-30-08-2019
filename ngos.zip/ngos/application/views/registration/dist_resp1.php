<div class="col-md-6 col-sm-6">
    <input type="hidden" name="district" value="" id="get_district">

    <select class="form-control" style="height:40px;width:269px;" id="uniq_district">
        <?php
        foreach ($districts as $d) {
            ?><option value="<?= $d->name ?>"><?= $d->name ?></option>
        <?php }
        ?>
    </select>


</div>



<script>
    $("#uniq_district").on('change', function () {
        var district = $(this).val();
        //  alert(district);
        $("#get_district").val(district);

        $("#get_perdist").val(district);
        $("#get_dist_banner").val(district);

    });
</script>