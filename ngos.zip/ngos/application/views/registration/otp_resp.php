<div class="otp_again_resp">
    <form id="OTPVerifForm" method="post">
        <div class="col-xs-12 text-center">
            <div class="form-group">
                <h3>Thank you for registering with us,Please note down your member ID for login... </h3><br>
                <h3>Your Member ID: <?= $memberid ?></h3><br>


            </div>
        </div>
        <div class="col-xs-12 show_timer" text-center></div>
        <div class="col-xs-12" text-center>
            <div class="form-group">
                <input type="number" name="otp" class=" form-control" maxlength="4" placeholder="Enter OTP..." required>
                <input type="hidden" name="otp_id" value="<?= $otpid ?>">
                <input type="hidden" name="member_id" value="<?= $memberid ?>">
                <input type="hidden" id="mobile_num" value="<?= $number ?>">

            </div>
        </div>
        <div class="col-xs-12 text-center">
            <div class="form-group">
                <button type="submit" class="btn btn-primary">VERIFY</button>
                <span id="otp_msg_resp"></span>
            </div>
        </div>

    </form>
    <p>Click <a href="javascript:;" id="otp_again" data-num="<?= $number ?>" data-mem="<?= $memberid ?>"><span class="label label-danger label-mini">here</span></a> to re-generate OTP</p>
<!--<small>(If you not get any OTP please reload the page)</small>-->
</div>


<script>
//    $(document).ready(function () {
//        var mobile = $("#mobile_num").val();
//        var sec = 55;
//        var timer = setInterval(function () {
//            if (sec !== -1) {
//                $(".show_timer").html('<p align="center"><font style="color:green;font-size:20px;">Your OTP will receive in   '  +sec--+  'seconds</font></p>');
//            }
//            else{
//             $(".show_timer").val(mobile);  
//            }
//        },1000);
//    });




    $("body").on('submit', '#OTPVerifForm', (function (e) {
        //$("#OTPVerifForm").('submit', (function (e) {
        // $(".roller-clue").addClass("roller");
        $('#otp_msg_resp').html('<img src="<?= base_url('assets/images/load.gif') ?>" alt="" width="80" height="80" />');
        e.preventDefault();
        $.ajax({
            url: "<?= base_url('Ngos/verify_otp') ?>", // Url to which the request is send
            type: "POST", // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false, // The content type used when sending data to the server.
            cache: false, // To unable request pages to be cached
            processData: false, // To send 
            success: function (response) {
                //   alert(data);
                if (response === 'success') {
                    $('#otp_msg_resp').html('<img class="text-center" src="<?= base_url('assets/img/right.png') ?>" alt="" width="50" height="50" /> <br> <span align="center" style="color:green">Verified...</span>');
                    $("#otp_msg_resp").show();
                    setTimeout(function () {
                        window.location.href = "<?= base_url('Ngos/reg_success') ?>";
                    }, 3000);

                } else {
                    $('#otp_msg_resp').html('<img src="<?= base_url('assets/images/wrong.jpeg') ?>" alt="" width="50" height="50" /><br> <span style="color:red">Not Verified</span>');
                    $("#otp_msg_resp").delay(3000).fadeOut(1500);
                    $("#otp_msg_resp").show();
                    setTimeout(function () {
                        location.reload();
                    }, 2000);
                }

                //$("#succes_msg").delay(6000).fadeOut(1500);
            }

        });


    }));




    $('#otp_again').click(function () {
        var num = $(this).attr('data-num');
        var mem = $(this).attr('data-mem');
        alert(num);
        $('#otp_msg_resp').html('<img src="<?= base_url('assets/images/load.gif') ?>" alt="" width="80" height="80" />');
        $.ajax({
            url: '<?= base_url() ?>Ngos/sendOTPagain',
            type: 'POST',
            data: {
                num: num,
                mem: mem
            },
            success: function (data) {
                $('.otp_again_resp').html(data);
            }

        });
    });
</script>