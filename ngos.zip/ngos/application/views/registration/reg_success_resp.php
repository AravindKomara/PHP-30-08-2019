<!-- CONTENT AREA -->
<div class="content-area">

    <!-- PAGE -->
    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->

    <!-- PAGE-->
    <section class="page-section">
        <div class="container">
            <div class="message-box">
                <div class="message-box-inner">
                    <h3 style='color:white'>This is International Ngos Network Online Park </h3>
                </div>
            </div>
        </div>
    </section>
    <!-- /PAGE -->
    <section class="page-section">
        <div class="container">



            <div class="tab-content">

                <!-- tab 2 -->
                <div class="tab-pane fade active in" id="tab-2">
                    <div class="row">
                        <div class="col-md-9 col-sm-6">
                            <div class="">
                                <div class="message-box-inner text-center">
                                    <p style='font-size:19px;color:blue'>This Site is 100% legal ,
                                        any member registered will be paid GST 18% service tax Government of India </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
<!--                            <input type='search' class='form-control' placeholder='ID Number Search ' > -->
                        </div>
                        
                        
                   <!-- Pay U Money Submitting Form --->
                        <form id="payment_form" method="post" action="<?= base_url('payment') ?>">
                            <div class="col-xs-12 text-center">
                                <div class="form-group">
                                    <h3>Thank you for registering with us,Please note down your member ID for login...</h3><br>
                                    <h3>Your Member ID: <?= $_SESSION['mem_id'] ?></h3><br>
                                    <p style="font-size:15px;">Click <a href="javascript:;" id="" data-price="<?= $_SESSION['tot_amt'] ?>"><b><span class="label label-danger label-mini">here</span></b></a> and pay <b style="font-size: 20px;"> Rs <?= $_SESSION['tot_amt'] ?> /- </b> to activate your account</p>

                                </div>
                            </div>

                            <?php
                            $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 10);//generating txnID for transaction
                            ?>
                            <input type="hidden" name="mem_id" value="<?= $_SESSION['mem_id'] ?>">
                            
                 <!-- Pay U Money Mandatory Fields --->                        
                            <input type="hidden" name="key" value="B9vV3QMo">
                            <input type="hidden" name="txnid" value="<?= $txnid ?>">
                            <input type="hidden" name="amount"   value="<?= $_SESSION['tot_amt'] ?>">
                            <input type="hidden" name="firstname" value="<?= $_SESSION['fname'] ?>">
                            <input type="hidden" name="email" value="<?= $_SESSION['email'] ?>">
                            <input type="hidden" name="phone" value="<?= $_SESSION['mobile'] ?>">
                            <input type="hidden" name="productinfo" value="Member Payment">
                            <input type="hidden" name="surl" value="<?= base_url('Payments/success/online?txnid=' . $txnid) ?>">
                            <input type="hidden" name="furl" value="<?= base_url('Payments/failure') ?>">
               <!-- End Pay U Money Mandatory Fields --->        
                             


                            <div class="col-xs-12 text-center">
                                <div class="form-group">
                               
                                    <button type="submit" class="btn btn-success">Pay via Pay U Money</button>
                                    <span id="otp_msg_resp"></span>
                                </div>
                            </div>

                        </form>
              <!-- End of Pay U Money Submitting Form --->
  
                    </div>
                </div>

                <!-- tab 3 -->

            </div>

        </div>
    </section>
    <!-- /PAGE -->              
</div>
<!-- /CONTENT AREA -->
