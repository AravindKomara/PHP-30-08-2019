
<?php
    if ($this->session->flashdata('intern_ngo_fail')) {
        ?>
        <div class="alert alert-danger text-center" style="z-index:1055;margin:auto;position:absolute;top:5px;right:500px;"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo $this->session->flashdata('intern_ngo_fail') ?>
        </div>
    <?php } ?>


<!-- CONTENT AREA -->
<div class="content-area states_resp">

    <!-- PAGE -->
    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->

    <!-- PAGE-->
    <section class="page-section">
        <div class="container">
            <div class="message-box">
                <?php
                if (!empty($banner->bn_text)) {
                    ?> <div class="message-box-inner">
                        <h2><?= $banner->bn_text ?> </h2>
                    </div>
                <?php } else {
                    ?><div class="message-box-inner">
                        <h2>This is International Ngos Network Only For Advertising Purpose </h2>
                    </div>
                <?php }
                ?>
            </div>
        </div>
    </section>
    <!-- /PAGE -->
    <section class="page-section">
        <div class="container">



            <div class="tab-content">

                <!-- tab 2 -->
                <div class="tab-pane fade active in" id="tab-2" >
                    <div class="row">

                      <?php
                        foreach ($countries as $c) {
                            $country = str_replace(" ", "_", $c->cname);
                            ?> <div class="col-md-2 col-sm-6">
                                <div class="thumbnail no-border no-padding">
                                    <div class="media">
                                        <a href='<?= base_url('international_uniqngos/' . $country) ?>'><h4 align=""><?= $c->cname ?></h4></a>

                                    </div>
                                </div>
                            </div> 
                        <?php }
                        ?>






                    </div>

                </div>
            </div>
        </div>
</div>
</section>
         
</div>


