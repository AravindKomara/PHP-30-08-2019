<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge"><![endif]-->
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Welcome to International Ngo,s Network</title>

        <!-- Favicon -->
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?= base_url('') ?>assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="shortcut icon" href="<?= base_url('') ?>assets/ico/favicon.ico">

        <!-- CSS Global -->
        <link href="<?= base_url('') ?>assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?= base_url('') ?>assets/plugins/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet">
        <link href="<?= base_url('') ?>assets/plugins/fontawesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="<?= base_url('') ?>assets/plugins/prettyphoto/css/prettyPhoto.css" rel="stylesheet">
        <link href="<?= base_url('') ?>assets/plugins/owl-carousel2/assets/owl.carousel.min.css" rel="stylesheet">
        <link href="<?= base_url('') ?>assets/plugins/owl-carousel2/assets/owl.theme.default.min.css" rel="stylesheet">
        <link href="<?= base_url('') ?>assets/plugins/animate/animate.min.css" rel="stylesheet">

        <!-- Theme CSS -->
        <link href="<?= base_url('') ?>assets/css/theme.css" rel="stylesheet">
        <link href="<?= base_url('') ?>assets/css/theme-green-1.css" rel="stylesheet" id="theme-config-link">

        <!-- Head Libs -->
        <script src="<?= base_url('') ?>assets/plugins/modernizr.custom.js"></script>


        <!--[if lt IE 9]>
        <script src="assets/plugins/iesupport/html5shiv.js"></script>
        <script src="assets/plugins/iesupport/respond.min.js"></script>
        <![endif]-->
        <style>
            .goog-te-gadget-icon {display:none;}
            .sf-menu .selectlang a:hover {color: #232323 !important; }
            .blinking{
                animation:blinkingText 1s infinite;
            }
            .blinking{
                animation:blinkingText 2s infinite;
            }
            @keyframes blinkingText{
                0%{		color: green;	}
                49%{	color: green;	}
                50%{	color: black;	}
                99%{	color:blue;	}
                100%{	color: green;	}
            }


            .p-list li{
                margin-left: 21px;
                display: inline-block;
            }
            .n-img{
                overflow:hidden;
            }
            .pad{
                padding-left:0px;
                padding-right:0px;
            }
            .matter p{
                margin-bottom:0px;
            }
            .matter{
                text-align: center;
            }
            .message-box {    
    background-color: #46b8da;  

    right: 25px ;
    left: 25px;
}
.navigation {
   
    line-height: 2;
}
.matter p{
        font-size: 13px;
}
        </style>




    </head>
    <body id="home" class="wide">


        <!-- WRAPPER -->
        <div class="wrapper">

            <!-- Popup: Shopping cart items -->
            <div class="modal fade popup-cart" id="popup-" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="container">
                        <div class="cart-items">
                            <div class="cart-items-inner">
                                <div class="media">
                                    <a class="pull-left" href="#"><img class="media-object item-image" src="<?= base_url('') ?>assets/img/preview/shop/order-1s.jpg" alt=""></a>
                                    <p class="pull-right item-price">$450.00</p>
                                    <div class="media-body">
                                        <h4 class="media-heading item-title"><a href="#">1x Standard Product</a></h4>
                                        <p class="item-desc">Lorem ipsum dolor</p>
                                    </div>
                                </div>
                                <div class="media">
                                    <p class="pull-right item-price">$450.00</p>
                                    <div class="media-body">
                                        <h4 class="media-heading item-title summary">Subtotal</h4>
                                    </div>
                                </div>
                                <div class="media">
                                    <div class="media-body">
                                        <div>
                                            <a href="#" class="btn btn-theme btn-theme-dark" data-dismiss="modal">Close</a><!--
                                            --><a href="#" class="btn btn-theme btn-theme-transparent btn-call-checkout">Checkout</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /Popup: Shopping cart items -->



            <!-- HEADER -->
            <header class="header fixed">
                <div class="header-wrapper col-md-12">
                    <!--                   <div class="container" style="width:1300px;">-->
                    <div class="col-md-12 pad">
                <div class="">
                    <ul class="p-list" style="margin-bottom:0px;">
                        <?php
                        if (!empty($auth_persons)) {
                            foreach ($auth_persons as $a) {
                                ?> <li>
                                    <div class="n-img">
                                        <img src='<?= base_url('') . $a->auth_image ?>' style='height:140px;float:left;width:164px;border:2px solid #000;'>
                                    </div>
                                    <div class="matter">
                                        <!--                                        <a data-toggle="modal" data-target="#myModal modal-lg">-->
                                        <a  style="cursor:pointer!important;" class="auth_details" data-authid="<?= $a->auth_id ?>" data-toggle="modal" data-target="#auth_modal">View Profile</a>
                                        <p><?= $a->auth_desgination ?>  </p>
                                        <p><?= $a->auth_jobtype ?></p>
                                        <p><?= $a->auth_name ?></p>
                                        <b>+91 <?= $a->auth_mobile ?></b>


                                    </div>
                                </li>
                            <?php }
                        } else {
                            ?>  <section class="page-section">
                                <div class="container">
                                    
                                    <div class="message-box">
                                        <div class="message-box-inner">
                                            <h3 style="color: red;">Sorry!!!! Authorisation Person's Details Are Not Found </h3>
                                        </div>

                                    </div>
                                </div>
                            </section>
                        <?php }
                        ?>
                       
                    </ul>


                </div>
                </div>
            </div>
                        <!--                        <div class="col-md-5">
                                                    <div class="cart-wrapper" style="margin-top:10px;display: inline-flex;">
                                                         <div>
                                                                                <img src='<?= base_url('') ?>assets/img/profile.jpg' style='height:140px;float:left'>
                                                         </div>
                                                          
                                                    </div>
                                                </div>-->

                   
                    <!-- Mobile menu toggle button -->
                    <a href="#" class="menu-toggle btn btn-theme-transparent"><i class="fa fa-bars"></i></a>
                    <!-- /Mobile menu toggle button -->

                    <div class="navigation-wrapper">
                        <div class="container-fluid ">
                            <!-- Navigation -->
                            <nav class="navigation closed clearfix">
                                <a href="#" class="menu-toggle-close btn"><i class="fa fa-times"></i></a>
                                <ul class="nav sf-menu">
                                    <li class="active"><a href="<?= base_url('home') ?>">Home</a>
                                    </li>

                                    <li><a href="<?= base_url('login') ?>">Your Profile Login</a>
                                    </li>
                                    <li><a href="<?= base_url('districts') ?>">District Ngo's Network Park</a>
                                    </li>

                                    <li><a href="<?= base_url('states') ?>">State Ngo's Network Park </a>
                                    </li>
                                    <li><a href="<?= base_url('national_uniqngos/' . 'national_ngos') ?>">National Ngo's Network Park</a>
                                    </li>

                                    <li><a href="<?= base_url('international') ?>">International Ngo's Network Park </a>
                                    </li>

                                    <li><a href="<?= base_url('legality') ?>">Legality</a></li>
                                    <li><a href="<?= base_url('offers') ?>">Our Business Offer</a>
                                    </li>
                                    <li><a href="<?= base_url('offers') ?>">Gallery</a>
                                    </li>
                                    <li><a href="<?= base_url('emailservice') ?>">Email-Service</a>
                                    </li>
                                    <li><div id="google_translate_element"></div></li>
                                    <!-- <li><a href="#">Notification</a></li> -->
                                </ul>
                            </nav>
                            <!-- /Navigation -->
                        </div>
                    </div>
            </header>
            <!-- /HEADER -->
        </div>


        <div id="auth_modal" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close del_memb_close" id="close-approve-popup" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Profile Details</h4>
                    </div>
<!--                    <input type="hidden" id="pop_auth_id">-->
                    <div class="auth_res">


                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>

            </div>
        </div> 

        <div id="ngo_modal" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close del_memb_close" id="close-approve-popup" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Login</h4>
                    </div>
<!--                    <input type="hidden" id="pop_auth_id">-->
                   <div class='col-md-6 col-md-offset-3'>
                                    <form method="POST" action="<?= base_url('profile')?>">

                                        <div class="col-md-12 col-sm-2">
                                            <input type='text' class='form-control' name="member_id" placeholder='MemberID' required>
                                        </div>
                                        <div class="col-md-12 col-sm-12">
                                            <input type='password' class='form-control' name="password" placeholder='Password' required>
                                        </div>


                                        <div class="col-md-12 col-sm-12">											
                                            <center><button class='btn btn-md btn-info'>Login</button> &nbsp;&nbsp;&nbsp;&nbsp; <button class='btn btn-md btn-info'>Forgot Password</button> </center>
                                        </div>
                                    </form>
                                </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>

            </div>
        </div>         










        <!-- google trnaselater -->
        <script type="text/javascript">
            function googleTranslateElementInit() {
                new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
            }
        </script>
        <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

        <!-- google traselater end -->
        <!-- JS Global -->
        <script src="<?= base_url('') ?>assets/plugins/jquery/jquery-1.11.1.min.js"></script>
        <script src="<?= base_url('') ?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?= base_url('') ?>assets/plugins/bootstrap-select/js/bootstrap-select.min.js"></script>
        <script src="<?= base_url('') ?>assets/plugins/superfish/js/superfish.min.js"></script>
        <script src="<?= base_url('') ?>assets/plugins/prettyphoto/js/jquery.prettyPhoto.js"></script>
        <script src="<?= base_url('') ?>assets/plugins/owl-carousel2/owl.carousel.min.js"></script>
        <script src="<?= base_url('') ?>assets/plugins/jquery.sticky.min.js"></script>
        <script src="<?= base_url('') ?>assets/plugins/jquery.easing.min.js"></script>
        <script src="<?= base_url('') ?>assets/plugins/jquery.smoothscroll.min.js"></script>
        <script src="<?= base_url('') ?>assets/plugins/smooth-scrollbar.min.js"></script>
        <!-- JS Page Level -->
        <script src="<?= base_url('') ?>assets/js/theme.js"></script>
        <!--[if (gte IE 9)|!(IE)]><!-->
        <script src="<?= base_url('') ?>assets/plugins/jquery.cookie.js"></script>


        <script>
            $(".auth_details").click(function () {
                var authid = $(this).attr("data-authid");
                //  alert(authid);
                $.ajax({
                    url: "<?= base_url('Ngos/view_uniq_authperson') ?>",
                    type: "POST",
                    data: {
                        authid: authid
                    },
                    success: function (response) {
                        $(".auth_res").html(response);
                    }
                });


            });
        </script>