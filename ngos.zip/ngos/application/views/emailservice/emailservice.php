
<!-- CONTENT AREA -->
<div class="content-area reg_success">

    <!-- PAGE -->
    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->

    <!-- PAGE-->
    <section class="page-section">
        <div class="container">
            <div class="message-box">
                <?php
                if (!empty($banner->bn_text)) {
                    ?> <div class="message-box-inner">
                        <h2><?= $banner->bn_text ?> </h2>
                    </div>
                <?php } else {
                    ?><div class="message-box-inner">
                        <h2>This is International Ngos Network Only For Advertising Purpose </h2>
                    </div>
                <?php }
                ?>
            </div>
        </div>
    </section>
    <!-- /PAGE -->
    <section class="page-section">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade active in" id="tab-2" style="">
                    <div class="">
                        <div class="col-md-12 col-sm-6 col-md-offset-">									
                            <div class="row">
                                <div class="message-box">
                                    <div class="message-box-inner">
                                        <h2>Contact Us </h2>
                                    </div>
                                </div>

                                <div class='col-md-6' style='border-right:1px solid lightgray'>
                                    <form method="post" id="email_form">
                                        <div class="form-group row">
                                            <div class="col-md-6 col-sm-6">
                                                <label for="ex1" style="color:initial;">Name</label>
                                                <input class="form-control" name="name" placeholder="Your Name...."  type="text" required="">

                                            </div>

                                        </div>

                                        <div class="form-group row">
                                            <div class="col-md-6 col-sm-6">
                                                <label for="ex1" style="color:initial;">Email</label>
                                                <input class="form-control" name="email" placeholder="Your Email...."  type="email" required="">

                                            </div>

                                        </div>

                                        <div class="form-group row">
                                            <div class="col-md-6 col-sm-6">
                                                <label for="ex1" style="color:initial;">Mobile</label>
                                                <input class="form-control" name="mobile" placeholder="Your Mobile...."  type="text" required="">

                                            </div>

                                        </div>

                                        <div class="form-group row">
                                            <div class="col-md-6 col-sm-6">
                                                <label for="ex1" style="color:initial;">Comment</label>
                                                <textarea rows="4" cols="50" name="comment" placeholder="Write something...."></textarea>

                                            </div>

                                        </div>

                                         <div class="col-md-12 col-sm-12">
                                    <center id="email_success">
                                        
                                        <button class='btn btn-md btn-info'>Send Email</button>&nbsp;&nbsp;&nbsp;&nbsp;
                                    </center>

                                </div>

                                    </form>



                                </div>	
                            </div>
                        </div>
                    </div>
                </div>

            </div>
    </section>
    <!-- /PAGE -->              
</div>
<!-- /CONTENT AREA -->


<script>
       $("#email_form").on('submit', function (e) {
        e.preventDefault();
       // alert();

        $.ajax({
            url: "<?= base_url('Ngos/send_email') ?>", // Url to which the request is send
            type: "POST", // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false, // The content type used when sending data to the server.
            cache: false, // To unable request pages to be cached
            processData: false, // To send 
            success: function (response) {
                if(response === 'email_sent'){
                    $("#email_success").html('<font style="color:green;font-size:25px;">Email Sent Successfully,We will get back soon.....</font>');
                    $("#email_success").fadeOut(5000);
                    document.getElementById('email_form').reset();
                }
               
               
            }
        });

    });
</script>