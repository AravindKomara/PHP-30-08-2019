

<!-- CONTENT AREA -->
<div class="content-area">

    <!-- PAGE -->
    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->

    <!-- PAGE-->
    <section class="page-section">
        <div class="container">
            <div class="message-box">
                <div class="message-box-inner">
                    <h3 style='color:white'>This is International Ngos Network Only For Advertising Purpose </h3>
                </div>
            </div>
        </div>
    </section>
    <!-- /PAGE -->
    <section class="page-section">
        <div class="container">



            <div class="tab-content">

                <!-- tab 2 -->
                <div class="tab-pane fade active in" id="tab-2">
                    <div class="row">
                        <div class="col-md-9 col-sm-6">
                            <div class="">
                                <div class="message-box-inner">
                                    <p style='font-size:19px;color:blue'>This Site is 100% legal ,
                                        any member registered will be paid GST 18% service tax Government of India </p>
                                </div>
                            </div>
                        </div>
<!--                        <div class="col-md-3 col-sm-6">
                            <input type='search' class='form-control' placeholder='ID Number Search ' > 
                        </div>-->

                        <br><br><br>
                        
                        <?php
                        if(!empty($offers)){
                        foreach($offers as $off ){
                            ?><div class="col-md-2 col-sm-3">

                                <img src='<?= base_url(). $off->off_image?>'   style="width: 200px;height: 200px;"class='img-responsive'>
                                <center><?=$off->off_desc?></center>
                           

                        </div>
                        <?php } 
                        
                        }else{
                           ?><section class="page-section">
                                <div class="container">
                                    <div class="message-box">
                                        <div class="message-box-inner">
                                            <h3 style="color: red;">Sorry!!!! Presently we are not giving any offers </h3>
                                        </div>

                                    </div>
                                </div>
                            </section>
                      <?php }
                        ?>
                    </div>
                </div>

                <!-- tab 3 -->

            </div>

        </div>
    </section>
    <!-- /PAGE -->              
</div>
<!-- /CONTENT AREA -->
