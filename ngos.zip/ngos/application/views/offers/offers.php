<!-- CONTENT AREA -->
<div class="content-area">

    <!-- PAGE -->
    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->

    <!-- PAGE-->
    <section class="page-section">
        <div class="container">
            <div class="message-box">
                <?php
                if (!empty($banner->bn_text)) {
                    ?> <div class="message-box-inner">
                        <h2><?= $banner->bn_text ?> </h2>
                    </div>
                <?php } else {
                    ?><div class="message-box-inner">
                        <h2>This is International Ngos Network Only For Advertising Purpose </h2>
                    </div>
                <?php }
                ?>
            </div>
        </div>
    </section>
    <!-- /PAGE -->
    <section class="page-section">
        <div class="container">



            <div class="tab-content">

                <!-- tab 2 -->
                <div class="tab-pane fade active in" id="tab-2">
                    <div class="row">
                        <div class="col-md-9 col-sm-6">
                            <div class="">
                                <div class="message-box-inner">
                                    <p style='font-size:19px;color:blue'>This Site is 100% legal ,
                                        any member registered will be paid GST 18% service tax Government of India </p>
                                </div>
                            </div>
                        </div>
                        
                        
<!--                        <div class="col-md-3 col-sm-6">
                            <input type='search' class='form-control' placeholder='ID Number Search ' > 
                        </div>-->
                        
                         <?php
                        $memebership = $this->Ngos_model->get_memebership_details();
                        foreach ($memebership as $ms) {
                            ?><div class="col-md-12 col-sm-6">
                                <div class="thumbnail no-border no-padding">
                                    <div class="media">
                                        <div class=''>
                                            <div class='col-md-6 col-sm-6'>
                                                <h3><?=$ms->ms_scheme?> </h3>
                                            </div>
                                            <div class='col-md-3 col-sm-6'>
                                                 <h3>Our business Offer</h3>
                                            </div>
                                            <div class='col-md-3 col-sm-6'>
                                                <h3> <span style='color:red'><a href='<?= base_url('your_offers/'.$ms->ms_type)?>'><span class="blinking" style='font-size:'>Check Your Business</span> </a></span></h3>
                                            </div>
                                        </div>	
                                    </div>
                                </div>
                            </div>
                        <?php }
                        ?>


                        





                    </div>
                </div>

                <!-- tab 3 -->

            </div>

        </div>
    </section>
    <!-- /PAGE -->              
</div>
<!-- /CONTENT AREA -->
