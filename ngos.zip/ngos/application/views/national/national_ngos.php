

<!-- CONTENT AREA -->

<div class="content-area">

    <!-- PAGE -->
    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->


    
    <section class="page-section">
        <div class="col-md-12">
            <div class="message-box">
                 <?php
                if(!empty($national_banner_text->bn_text)){
                   ?> <div class="message-box-inner">
                    <h2><?=$national_banner_text->bn_text?> </h2>
                </div>
             <?php   }else{
                 ?><div class="message-box-inner">
                    <h2>This is International Ngos Network Online Park </h2>
                </div>
           <?php  }
                ?>
               
            </div>
        </div>
    </section>
    
   <section class="page-section">

        <div class="col-md-12 pad">
            <!--                    <div class="col-md-12">-->
            <!--                        <div class="col-md-2">
                                        <div class="logo">
                                        <a href="index.html"><img src="<?= base_url('') ?>assets/img/Ngo.png" alt="Bella Shop"/></a>
                                        </div>
                                    </div>-->
            <div class="col-md-12 pad">
                <div class="" style="margin-top:5px;">

                  <ul class="p-list">
                        <?php
                        if (!empty($ngos)) {
                            foreach ($ngos as $a) {
                                ?> <li>
                                    <div class="n-img">
                                         <p>Member ID_<?= $a->member_id ?></p>
                                        <img src='<?= base_url('') . $a->profile_pic ?>' style='height:140px;float:left;width:164px;border:2px solid #000;'>
                                    </div>
                                    <div class="matter">
                                        <!--                                        <a data-toggle="modal" data-target="#myModal modal-lg">-->
                                        <a  style="cursor:pointer!important;" class="auth_details" data-authid="<?= $a->ng_id ?>" data-toggle="modal" data-target="#ngo_modal">View Profile</a>
                                        <p><?= $a->tru_pre_name ?></p>
                                        <b>+91 <?= $a->tru_pre_mobile1 ?></b>


                                    </div>
                                </li>
                            <?php }
                        } else {
                            ?>  <section class="page-section">
                                <div class="container">
                                    <div class="message-box">
                                        <div class="message-box-inner">
                                            <h3 style="color: red;">Sorry!!!! NGO's Details Are Not Found </h3>
                                        </div>

                                    </div>
                                </div>
                            </section>
                        <?php }
                        ?>
                        
                    </ul>

                </div>
            </div>
        </div>
    </section>
    <!-- /PAGE -->              
</div>
<!-- /CONTENT AREA -->


<script>
    $(".auth_details").click(function () {
                var authid = $(this).attr("data-authid");
                // alert(authid);
                $.ajax({
                    url: "<?= base_url('Ngos/view_uniq_authperson') ?>",
                    type: "POST",
                    data: {
                        authid: authid
                    },
                    success: function (response) {
                        $(".auth_res").html(response);
                    }
                });


            });
</script>