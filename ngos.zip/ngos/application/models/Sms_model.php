<?php

class SMS_model extends CI_Model {
   public function __construct() {
       parent::__construct();
   }
   
    public function SMS_otp_registration($number) {
        require('Textlocal.class.php');//sending SMS by using Textlocal.class.php=>must include this class in your appilication

        $data['otp'] = random_string('numeric', 4);//generating random 4 digit OTP
        $data['otp_id'] = random_string('alnum', 6);//generating 6 digit uniqID for each OTP 
        $this->db->insert('otp', $data);//inserting in OTP table
        $res = $this->db->where('oid', $this->db->insert_id())->get('otp')->row();//getting recently inserted OTP details
       //message details
        $Textlocal = new Textlocal(false, false, 'nKXXYtlJodU-47RdqYa4R4efAFp3E9G8mUTleqZPy5'); //API KEY
       
        $numbers = array($number);//number
        $sender = 'NGOSNW';//sender name
        //our message and Textlocal SMS template must be same 
        $message = 'Thank you for registering with us. Please enter your OTP : ' . $data['otp'] . ' to verify your account.';
        $response = $Textlocal->sendSms($numbers, $message, $sender);//calling sendSms method in Textlocal class
        return $res->otp_id;//returning OTPID for my requriment,defaultly we will return response
    }
   
    public function SMS_blast_notification($totalnumbers, $ntype) {
        // Account details
        $apiKey = urlencode('nKXXYtlJodU-47RdqYa4R4efAFp3E9G8mUTleqZPy5');//API KEY
        
        // Message details
        $numbers = $totalnumbers;//numbers are converted from array to string in _Admin controller
        $sender = urlencode('NGOSNW');//sender name
        //our message and Textlocal SMS template must be same 
        $message = rawurlencode('Notification received at ' . $ntype . '.Check at https://tx.gl/r/309a/#AdvdTrack#');
        $data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);// Prepare data for POST request
        // Send the POST request with cURL
        $ch = curl_init('https://api.textlocal.in/send/');//calling send method
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
        // Process your response here
        return $response;
    }
}
