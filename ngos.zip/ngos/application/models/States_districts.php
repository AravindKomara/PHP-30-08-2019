<?php

class States_districts extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function all_indian_states() {
        $res = $this->db->get('states')->result();
        return $res;
    }

    public function get_all_countries() {
        $res = $this->db->get('countries')->result();
        return $res;
    }

    public function get_uniqstate_districts($state_id) {
        $res = $this->db->where('state_id', $state_id)->get('districts')->result();
        return $res;
    }
    
   public function get_uniqstate_name($state_id) {
        $res = $this->db->where('id', $state_id)->get('states')->row();
        return $res;
    }

    public function get_uniqcountry_ngos($country) {
        $res = $this->db->where('type', 'International')->where('country', $country)->get('ngos')->result();
        return $res;
    }

    public function get_national_ngos($national) {
        $res = $this->db->where('type', 'National')->where('country', 'India')->get('ngos')->result();
        return $res;
    }

    public function get_uniqstate_ngos($state) {
        $res = $this->db->where('type', 'State')->where('state', $state)->get('ngos')->result();
        return $res;
    }

    public function get_uniqdistrict_ngos($district) {
        $res = $this->db->where('type', 'District')->where('district', $district)->get('ngos')->result();
        return $res;
    }

    public function get_district($dist) {
        $res = $this->db->where('name', $dist)->get('districts')->row();
        return $res;
    }

    public function get_all_districts_state($stateid) {
        $res = $this->db->where('state_id', $stateid)->get('districts')->result();
        return $res;
    }

}
