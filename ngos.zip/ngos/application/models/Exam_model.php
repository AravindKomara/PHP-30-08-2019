<?php

class Exam_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function insert_user($data = array()) {
        $res = $this->db->insert('exam_users', $data);
        return $res;
    }

    public function check_login_details($email, $password) {
        $res = $this->db->where('email', $email)->where('password', $password)->get('exam_users')->row();
        return $res;
    }

    public function verify_email($email) {
        $res = $this->db->where('email', $email)->get('exam_users')->row();
        return $res;
    }

    public function verify_mobile($mobile) {
        $res = $this->db->where('mobile', $mobile)->get('exam_users')->row();
        return $res;
    }

    public function get_uniq_useranswers() {
        $res = $this->db->where('uid', $_SESSION['userid'])->get('exam_answer_details')->result();
        return $res;
    }

    public function get_uniq_UserandQuestion_answer($examid, $questionid, $questionnum) {
        $res = $this->db->where('uid', $_SESSION['userid'])->where('exam_id', $examid)->where('question_id', $questionid)->where('question_num', $questionnum)->get('exam_answer_details')->row();
        return $res;
    }

    public function insert_answer_details($data = array()) {
        $res = $this->db->insert('exam_answer_details', $data);
        return $res;
    }

    public function update_answer_details($examid, $questionid, $questionnum, $selected_answer) {
        $res = $this->db->where('uid', $_SESSION['userid'])->where('exam_id', $examid)->where('question_id', $questionid)->where('question_num', $questionnum)->update('exam_answer_details', array("selected_answer" => $selected_answer));
        return $res;
    }

    public function get_exam_marks_ofuser() {
        $res = $this->db->where('uid', $_SESSION['userid'])->get('exam_answer_details')->result();
        return $res;
    }

    public function get_total_marks_ofuser($examid, $questionid, $questionnum) {
        $res = $this->db->where('exam_id', $examid)->where('question_id', $questionid)->where('question_number', $questionnum)->get('exam_questions')->row();
        return $res;
    }

    public function get_user_exam_status($examid, $questionid, $questionnum) {
        $res = $this->db->where('uid', $_SESSION['userid'])->where('exam_id', $examid)->where('question_id', $questionid)->where('question_num', $questionnum)->get('exam_answer_details')->row();
        return $res;
    }

    public function exam_details($examid) {
        $res = $this->db->where('exam_id', $examid)->get('exams_details')->row();
        return $res;
    }

    public function exam_results_details($examid, $total_marks, $qualify_marks, $marks, $status) {
        $data = array("uid" => $_SESSION['userid'],
            "exam_id" => $examid,
            "total_marks" => $total_marks,
            "qualify_marks" => $qualify_marks,
            "your_marks" => $marks,
            "result_status" => $status);
        $res = $this->db->insert('exam_results', $data);
        return $res;
    }

}
