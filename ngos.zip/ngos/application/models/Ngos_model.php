<?php

class Ngos_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function get_memebership_details() {
        $res = $this->db->get('membership_schemes')->result();
        return $res;
    }

    public function get_uniqoffers_details($offerid) {
        $res = $this->db->where('off_id', $offerid)->get('offers')->row();
        return $res;
    }

    public function get_offers_details($type) {
        $res = $this->db->where('off_type', $type)->limit(6)->get('offers')->result();
        return $res;
    }

    public function delete_offer($offerid) {
        $res = $this->db->where('off_id', $offerid)->delete('offers');
        return $res;
    }

    public function get_ngo_details($ngid) {
        $res = $this->db->where('ng_id', $ngid)->get('ngos')->row();
        return $res;
    }

    public function get_ngo_membership_details($memberid) {
        $res = $this->db->where('member_id', $memberid)->get('trust_details')->row();
        return $res;
    }

    public function check_login_details($memberid, $password) {
        $res = $this->db->where('member_id', $memberid)->where('password', $password)->get('ngos')->row();
        return $res;
    }

    public function get_membership_price($type) {
        $res = $this->db->where('ms_type', $type)->get('membership_schemes')->row();
        return $res;
    }

    public function insert_enquiry_details($data = array()) {
        $res = $this->db->insert('enquirys', $data);
        if ($res) {
            return TRUE;
        }
    }

   

    public function verify_otp($otp_id) {
        $res = $this->db->where('otp_id', $otp_id)->get('otp')->row();
        return $res;
    }

    public function get_refperson_details($refid) {
        $res = $this->db->where('tr_refid', $refid)->get('trust_details')->row();
        return $res;
    }

    public function ref_amount_credit($memberid, $refname, $refamount) {
        $res = $this->db->where('member_id', $memberid)->update('trust_details', array("tr_refid_gift" => $refamount, "tr_refid_gift_from" => $refname));
        return $res;
    }

    public function update_member_password($memberid, $password) {
        $res = $this->db->where('member_id', $memberid)->update('ngos', array("password" => $password));
        return $res;
    }

    public function check_referal_code($code) {
        $res = $this->db->where('tr_refid', $code)->get('trust_details')->row();
        return $res;
    }

    public function get_all_indian_numbers() {
        $res = $this->db->query("SELECT tru_pre_mobile1 FROM ngos WHERE try_pre_mobilecode = 91")->result();
        return $res;
    }

   
    
     public function get_all_primary_emails() {
        $res = $this->db->query("SELECT tru_pre_email FROM ngos")->result();
        return $res;
    }
    
     public function update_member_mobilestatus($memberid){
        $res = $this->db->where('member_id',$memberid)->update('ngos',array("mobile_status"=>"active"));
        return $res;
    }
    
    public function update_member_status(){
        $res = $this->db->where('member_id',$_SESSION['mem_id'])->update('ngos',array("membership_status"=>"active"));
        return $res;
    }

}
