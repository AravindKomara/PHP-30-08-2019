<?php

Class Admin_Model extends CI_Model {

    public function verify_login_details($email, $password) {
        $res = $this->db->where('email', $email)->where('password', md5($password))->get('admin')->row();
        return $res;
    }

    public function insert_banners($data = array()) {
        $res = $this->db->insert('banners', $data);
        return $res;
    }

    public function get_dist_banner_text($type, $district) {
        $res = $this->db->where('bn_type', $type)->where('bn_district', $district)->get('banners')->row();
        return $res;
    }

    public function get_state_banner_text($type, $state) {
        $res = $this->db->where('bn_type', $type)->where('bn_state', $state)->get('banners')->row();
        return $res;
    }

    public function get_national_banner_text($national) {
        $res = $this->db->where('bn_type', $national)->get('banners')->row();
        return $res;
    }

    public function get_international_banner_text($type, $country) {
        $res = $this->db->where('bn_type', $type)->where('bn_country', $country)->get('banners')->row();
        return $res;
    }

    public function get_dist_auth_persons($district) {
        $res = $this->db->where('auth_type', 'District')->where('auth_district', $district)->limit(7)->get('auth_persons')->result();
        return $res;
    }

    public function get_state_auth_persons($state) {
        $res = $this->db->where('auth_type', 'State')->where('auth_state', $state)->limit(7)->get('auth_persons')->result();
        return $res;
    }

    public function get_national_auth_persons($national) {
        $res = $this->db->where('auth_type', $national)->limit(7)->get('auth_persons')->result();
        return $res;
    }

    public function get_international_auth_persons($country) {
        $res = $this->db->query("SELECT * FROM auth_persons WHERE auth_type LIKE '%" . 'International' . "%' AND auth_country LIKE '%" . $country . "%' AND NOT auth_position = 'International Top'  LIMIT 7 ")->result();
        return $res;
    }

    public function get_allinternational_auth_persons() {
        $res = $this->db->query("SELECT * FROM auth_persons WHERE auth_type LIKE '%" . 'International' . "%' AND   auth_position = 'International Top'  LIMIT 7 ")->result();
        return $res;
//     $res = $this->db->where('auth_type','International')->limit(7)->get('auth_persons')->result();
//     return $res;
    }

    public function get_all_inter_auth_persons() {
        $res = $this->db->where('auth_type', 'International')->get('auth_persons')->result();
        return $res;
    }

    public function getInternationalPersons($per_page, $offset) {
        $res = $this->db->order_by("auth_id", "asc")->where('auth_type', 'International')->get('auth_persons', $per_page, $offset)->result();
        return $res;
    }

// public function get_inter_persons_count(){
//     $this->db->where('auth_type','International');
//     $res = $this->db->count_all_results('auth_persons');
//     return $res;
// }

    public function get_all_national_auth_persons() {
        $res = $this->db->where('auth_type', 'National')->get('auth_persons')->result();
        return $res;
    }

    public function getNationalPersons($per_page, $offset) {
        $res = $this->db->order_by("auth_id", "asc")->where('auth_type', 'National')->get('auth_persons', $per_page, $offset)->result();
        return $res;
    }

    public function get_all_state_auth_persons() {
        $res = $this->db->where('auth_type', 'State')->get('auth_persons')->result();
        return $res;
    }

    public function getStatePersons($per_page, $offset) {
        $res = $this->db->order_by("auth_id", "asc")->where('auth_type', 'State')->get('auth_persons', $per_page, $offset)->result();
        return $res;
    }

    public function get_all_district_auth_persons() {
        $res = $this->db->where('auth_type', 'District')->get('auth_persons')->result();
        return $res;
    }

    public function getDistrictPersons($per_page, $offset) {
        $res = $this->db->order_by("auth_id", "asc")->where('auth_type', 'District')->get('auth_persons', $per_page, $offset)->result();
        return $res;
    }

    public function get_uniq_auth_person($authid) {
        $res = $this->db->where('auth_id', $authid)->get('auth_persons')->row();
        return $res;
    }

    public function get_all_in_types() {
        $res = $this->db->get('auth_inter_types')->result();
        return $res;
    }

    public function get_all_nat_types() {
        $res = $this->db->get('auth_national_types')->result();
        return $res;
    }

    public function get_all_auth_types() {
        $res = $this->db->get('auth_person_types')->result();
        return $res;
    }

    public function add_inter_types($data = array()) {
        $res = $this->db->insert('auth_inter_types', $data);
        return $res;
    }

    public function add_nat_types($data = array()) {
        $res = $this->db->insert('auth_national_types', $data);
        return $res;
    }

    public function add_auth_types($data = array()) {
        $res = $this->db->insert('auth_person_types', $data);
        return $res;
    }

    public function delete_auth_person($authid) {
        $res = $this->db->where('auth_id', $authid)->delete('auth_persons');
        return $res;
    }

    public function get_all_inter_users() {
        $res = $this->db->where('type', 'International')->get('ngos')->result();
        return $res;
    }
    
     public function get_all_freeinter_users() {
        $res = $this->db->where('type', 'International')->where('reg_type', 'free')->get('ngos')->result();
        return $res;
    }

    public function get_all_nat_users() {
        $res = $this->db->where('type', 'National')->get('ngos')->result();
        return $res;
    }
    
     public function get_all_freenat_users() {
        $res = $this->db->where('type', 'National')->where('reg_type', 'free')->get('ngos')->result();
        return $res;
    }

    public function get_all_state_users() {
        $res = $this->db->where('type', 'State')->get('ngos')->result();
        return $res;
    }
    
     public function get_all_freestate_users() {
        $res = $this->db->where('type', 'State')->where('reg_type', 'free')->get('ngos')->result();
        return $res;
    }

    public function get_all_dist_users() {
        $res = $this->db->where('type', 'District')->get('ngos')->result();
        return $res;
    }
    
     public function get_all_freedist_users() {
        $res = $this->db->where('type', 'District')->where('reg_type', 'free')->get('ngos')->result();
        return $res;
    }

    public function get_all_details_ofuser($memberid) {
        $res = $this->db->query("SELECT * FROM ngos,trust_details t JOIN ngos n ON t.member_id = n.member_id WHERE t.member_id = '" . $memberid . " '")->row();
        return $res;
    }

    public function delete_member_person($membid) {
        $res = $this->db->where('member_id', $membid)->delete('ngos');
        $res1 = $this->db->where('member_id', $membid)->delete('trust_details');
        if ($res && $res1) {
            return 'deleted';
        }
    }

    public function get_all_auth_persons() {
        $res = $this->db->query("SELECT * FROM auth_persons WHERE auth_position LIKE '%" . 'Header' . "%'  LIMIT 7 ")->result();
        return $res;
    }

    public function get_uniq_auth_person_details($authid) {
        $res = $this->db->where('auth_id', $authid)->get('auth_persons')->row();
        return $res;
    }

    public function insert_legality_text($data = array()) {
        $res = $this->db->insert('legality', $data);
        return $res;
    }

    public function insert_notification_text($data = array()) {
        $res = $this->db->insert('notifications', $data);
        return $res;
    }

    public function get_legality_text() {
        $res = $this->db->get('legality')->row();
        return $res;
    }

    public function get_notification_text($type) {
        $res = $this->db->where('type', $type)->get('notifications')->row();
        return $res;
    }

    public function get_all_notifications_types() {
        $res = $this->db->get('notification_types')->result();
        return $res;
    }

    public function get_banner($type) {
        $res = $this->db->where('bn_type', $type)->get('banners')->row();
        return $res;
    }

    public function update_banner($id, $data = array()) {
        $res = $this->db->where('bn_id', $id)->update("banners", $data);
        return $res;
    }

    public function inser_broucher($data = array()) {
        $res = $this->db->insert('brouchers', $data);
        return $res;
    }

    public function get_uniqbrocuher_details($brid) {
        $res = $this->db->where('br_id', $brid)->get('brouchers')->row();
        return $res;
    }

    public function get_brocuher_type($type) {
        $res = $this->db->where('type', $type)->get('brouchers')->row();
        return $res;
    }

    public function get_all_brouchers() {
        $res = $this->db->get('brouchers')->result();
        return $res;
    }

    public function delete_broucher($brid) {
        $res = $this->db->where('br_id', $brid)->delete('brouchers');
        return $res;
    }

    public function search_auth_names($type, $name) {
        if ($type == 'International') {
            $this->db->select('*');
            $this->db->from('auth_persons');
            $this->db->like('auth_name', $name);
            $this->db->or_like('auth_country', $name);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                foreach ($query->result_array() as $row) {
                    $row_set[] = $row['auth_name']; //build an array
                    $row_set[] = $row['auth_country'];
                }
                echo json_encode($row_set); //format the array into json data
            }
        } else if ($type == 'National') {
            $this->db->select('*');
            $this->db->from('auth_persons');
            $this->db->like('auth_name', $name);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                foreach ($query->result_array() as $row) {
                    $row_set[] = $row['auth_name']; //build an array
                }
                echo json_encode($row_set); //format the array into json data
            }
        } else if ($type == 'State') {
            $this->db->select('*');
            $this->db->from('auth_persons');
            $this->db->like('auth_name', $name);
            $this->db->or_like('auth_state', $name);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                foreach ($query->result_array() as $row) {
                    $row_set[] = $row['auth_name']; //build an array
                    $row_set[] = $row['auth_state'];
                }
                echo json_encode($row_set); //format the array into json data
            }
        } else {
            $this->db->select('*');
            $this->db->from('auth_persons');
            $this->db->like('auth_name', $name);
            $this->db->or_like('auth_district', $name);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                foreach ($query->result_array() as $row) {
                    $row_set[] = $row['auth_name']; //build an array
                    $row_set[] = $row['auth_district'];
                }
                echo json_encode($row_set); //format the array into json data
            }
        }
    }

    public function search_auth_person_row($type, $name) {
        if ($type == 'International') {
            $res = $this->db->query("SELECT * FROM auth_persons WHERE auth_name LIKE '%" . $name . "%' OR auth_country LIKE '%" . $name . "%'")->result();
            return $res;
        } else if ($type == 'National') {
            $res = $this->db->query("SELECT * FROM auth_persons WHERE auth_name LIKE '%" . $name . "%'")->result();
            return $res;
        } else if ($type == 'State') {
            $res = $this->db->query("SELECT * FROM auth_persons WHERE auth_name LIKE '%" . $name . "%' OR auth_state LIKE '%" . $name . "%'")->result();
            return $res;
        } else {
            $res = $this->db->query("SELECT * FROM auth_persons WHERE auth_name LIKE '%" . $name . "%' OR auth_district LIKE '%" . $name . "%'")->result();
            return $res;
        }
    }

    public function get_state_of_district($district) {
        $res = $this->db->where('name', $district)->get('districts')->row();
        return $res;
    }

    public function get_state_name($stateid) {
        $res = $this->db->where('id', $stateid)->get('states')->row();
        return $res;
    }

    public function getenquiry_moderations() {
        return $this->db->where('status', 'reply_notsent')->order_by('enq_id', 'desc')->get('enquirys')->result();
    }

    public function view_enquriry_message($enqid) {
        $res = $this->db->where('enq_id', $enqid)->get('enquirys')->row();
        return $res;
    }

    public function update_enquriry_status($enqid) {
        $res = $this->db->where('enq_id', $enqid)->update('enquirys', array("status" => "reply_sent"));
        return $res;
    }

    public function delete_enquriry($enqid) {
        $res = $this->db->where('enq_id', $enqid)->delete('enquirys');
        return $res;
    }

    public function insert_refmoney_records($data = array()) {
        $res = $this->db->insert('referal_moderations', $data);
        return $res;
    }

    public function check_refmoney_record($data = array()) {
        $res = $this->db->where($data)->get('referal_moderations')->row();
        return $res;
    }

    public function update_refmoney_status($memberid) {
        $res = $this->db->where('member_id', $memberid)->update('trust_details', array("tr_ref_money_status` " => "pending"));
        return $res;
    }

    public function getpendingreferal_moderations() {
        return $this->db->where('status', 'pending')->order_by('rid', 'desc')->get('referal_moderations')->result();
    }

    public function getapprovedreferal_moderations() {
        return $this->db->where('status', 'approved')->order_by('rid', 'desc')->get('referal_moderations')->result();
    }

    public function getrejectedreferal_moderations() {
        return $this->db->where('status', 'rejected')->order_by('rid', 'desc')->get('referal_moderations')->result();
    }

    public function update_refmoney_adminstatus($memberid, $status) {
        date_default_timezone_set('Asia/Kolkata');
        $date = date('Y/m/d H:i:s', time());
        $res = $this->db->where('memberid', $memberid)->update('referal_moderations', array("status" => $status, "added_on" => $date));
        $res = $this->db->where('member_id', $memberid)->update('trust_details', array("tr_ref_money_status" => $status));
        return $res;
    }

    public function delete_refralrecord($id, $memberid) {
        $res = $this->db->where('rid', $id)->delete('referal_moderations');
        return $res;
    }
    
     public function get_gallery() {
        $res = $this->db->get('gallery')->result();
        return $res;
    }
    public function get_event_details($gid) {
        $res = $this->db->where('gid', $gid)->get('gallery')->row();
        return $res;
    }
    
    public function update_gallery_data($gid,$data = array()) {
        $res = $this->db->where('gid', $gid)->update('gallery',$data);
        return $res;
    }
    
    public function delete_gallery_row($gid) {
        $res = $this->db->where('gid', $gid)->delete('gallery');
        return $res;
    }
    
    public function insert_exam_details($data = array()){
        $res = $this->db->insert('exams_details', $data);
        return $res;
    }
    
     public function get_allexam_details(){
        $res = $this->db->get('exams_details')->row();
        return $res;
    }
    
    
     public function get_uniq_exam_details($exid) {
        $res = $this->db->where('exam_id', $exid)->get('exams_details')->row();
        return $res;
    }
    
    public function update_exam_details($exid,$data = array()) {
        $res = $this->db->where('exam_id', $exid)->update('exams_details',$data);
        return $res;
    }
    
     public function delete_exam_row($exid) {
        $res = $this->db->where('exam_id', $exid)->delete('exams_details');
        return $res;
    }
    
     public function insert_exam_questions($data = array()){
        $res = $this->db->insert('exam_questions', $data);
        return $res;
    }
    
     public function get_uniq_exam_questionCount($exid) {
        $res = $this->db->where('exam_id', $exid)->get('exam_questions')->result();
        return $res;
    }
    
     public function getExamquestions($per_page, $offset,$examid) {
        $res = $this->db->order_by("question_number", "asc")->where('exam_id', $examid)->get('exam_questions', $per_page, $offset)->row();
        return $res;
    }
    
     public function update_exam_questions($examid,$questionid,$data = array()) {
        $res = $this->db->where('exam_id', $examid)->where('question_id',$questionid)->update('exam_questions',$data);
        return $res;
    }
    
     public function getuniqExamquestions($examid,$question_number) {
        $res = $this->db->order_by("question_number", "asc")->where('exam_id', $examid)->where('question_number', $question_number)->get('exam_questions')->row();
        return $res;
    }

}
