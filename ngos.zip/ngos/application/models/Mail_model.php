<?php

class Mail_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function sendEmail($body, $subject, $email) {
        $config = Array(//for gmail Settings
            'protocol' => 'smtp',
            'smtp_host' => 'host.omkieitsolutions.com',
            'smtp_port' => 465,
            'smtp_user' => 'noreply@ngosnetwork.org', // change it to yours
            'smtp_pass' => 'hjfhfh5354!12', // change it to yours
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        );


        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
//        $this->email->reply_to($email); //User email submited in form
        $this->email->from('noreply@ngosnetwork.org', 'ngosnetwork.org'); // change it to yours
        $this->email->to('aravind@omkieit.com');
//        $this->email->to(array($to,'custcare.basicneeds@gmail.com')); // change it to yours
        $this->email->subject($subject);
        $this->email->message($body);
        $res = $this->email->send();
        if ($res) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    public function sendEmail_OTP($subject, $email, $memberid) {
        $config = Array(//for gmail Settings
            'protocol' => 'smtp',
            'smtp_host' => 'ssl://smtp.gmail.com',
            'smtp_port' => 465,
            'smtp_user' => 'testing.trial15@gmail.com', // change it to yours
            'smtp_pass' => 'OmkiestnUll!00', // change it to yours
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        );

//        $config = Array(//for gmail Settings
//            'protocol' => 'smtp',
//            'smtp_host' => 'host.omkieitsolutions.com',
//            'smtp_port' => 465,
//            'smtp_user' => 'noreply@ngosnetwork.org', // change it to yours
//            'smtp_pass' => 'hj535412%dS', // change it to yours
//            'mailtype' => 'html',
//            'charset' => 'iso-8859-1',
//            'wordwrap' => TRUE
//        );

        $data['otp'] = random_string('numeric', 4);
        $data['otp_id'] = random_string('alnum', 6);
        $this->db->insert('otp', $data);
        $otp = $this->db->where('oid', $this->db->insert_id())->get('otp')->row();
        $message = 'Thank you for registering with us... Your memberID is : ' . $memberid . '<br> Please enter your OTP : ' . $data['otp'] . ' to verify your account.';

        $this->load->library('email', $config);
        $this->email->initialize($config);
        $this->email->set_newline("\r\n");
        $this->email->from('testing.trial15@gmail.com', 'ngosnetwork.org'); // change it to yours
        $this->email->to($email);
        $this->email->subject($subject);
        $this->email->message($message);
        $res = $this->email->send();
        if ($res) {
            return $otp->otp_id;
        } else {
            echo $this->email->print_debugger();
        }
    }

    public function EMAIL_blast_notification($emails, $type) {
        $config = Array(//for gmail Settings
            'protocol' => 'smtp',
            'smtp_host' => 'ssl://smtp.gmail.com',
            'smtp_port' => 465,
            'smtp_user' => 'testing.trial15@gmail.com', // change it to yours
            'smtp_pass' => 'Omkienutshell', // change it to yours
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        );
        
        
//        $config = Array(//for gmail Settings
//            'protocol' => 'smtp',
//            'smtp_host' => 'mail.ngosnetwork.org',
//            'smtp_port' => 465,
//            'smtp_user' => 'noreply@ngosnetwork.org', // change it to yours
//            'smtp_pass' => 'hjfhfh5354!12', // change it to yours
//            'mailtype' => 'html',
//            'charset' => 'iso-8859-1',
//            'wordwrap' => TRUE
//        );

        $subject = "Notification Received From NGOSNetwork";
        $message = '';
        if ($type == 'International meetings Notification') {
            $message = 'Notification received at ' . $type . '.Check at <a href = "http://www.ngosnetwork.org/view_notification/International_meetings">' . $type . '</a>';
        } elseif ($type == 'National meetings Notification') {
            $message = 'Notification received at ' . $type . '.Check at <a href = "http://www.ngosnetwork.org/view_notification/National_meetings">' . $type . '</a>';
        } elseif ($type == 'State meetings Notification') {
            $message = 'Notification received at ' . $type . '.Check at <a href = "http://www.ngosnetwork.org/view_notification/State_meetings">' . $type . '</a>';
        } elseif ($type == 'District meetings Notification') {
            $message = 'Notification received at ' . $type . '.Check at <a href = "http://www.ngosnetwork.org/view_notification/District_meetings">' . $type . '</a>';
        } elseif ($type == 'Jobs Notification') {
            $message = 'Notification received at ' . $type . '.Check at <a href = "http://www.ngosnetwork.org/view_notification/Jobs">' . $type . '</a>';
        } elseif ($type == 'Events Notification') {
            $message = 'Notification received at ' . $type . '.Check at <a href = "http://www.ngosnetwork.org/view_notification/Events">' . $type . '</a>';
        } elseif ($type == 'Emergency services Notification') {
            $message = 'Notification received at ' . $type . '.Check at <a href = "http://www.ngosnetwork.org/view_notification/Emergency_services">' . $type . '</a>';
        } elseif ($type == 'Emergency meetings Notification') {
            $message = 'Notification received at ' . $type . '.Check at <a href = "http://www.ngosnetwork.org/view_notification/Emergency_meetings">' . $type . '</a>';
        } else {
            $message = 'Notification received at ' . $type . '.Check at <a href = "http://www.ngosnetwork.org/view_notification/Emergency_protocol">' . $type . '</a>';
        }

        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->from('testing.trial15@gmail.com', 'ngosnetwork.org'); // change it to yours
        $this->email->to($emails); // change it to yours
        $this->email->subject($subject);
        $this->email->message($message);
        $res = $this->email->send();
        if ($res) {
            return 1;
        } else {
            return 0;
        }
    }

    public function send_enquriry_reply($to,$subject,$message) {
        $config = Array(//for gmail Settings
            'protocol' => 'smtp',
            'smtp_host' => 'ssl://smtp.gmail.com',
            'smtp_port' => 465,
            'smtp_user' => 'testing.trial15@gmail.com', // change it to yours
            'smtp_pass' => 'Omkienutshell', // change it to yours
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        );

//        $config = Array(//for gmail Settings
//            //'protocol' => 'smtp',
//            'smtp_host' => 'host.omkieitsolutions.com',
//            'smtp_port' => 465,
//            'smtp_user' => 'noreply@basicneeds.in', // change it to yours
//            'smtp_pass' => '^ghfgh#@#', // change it to yours
//            'mailtype' => 'html',
//            'charset' => 'iso-8859-1',
//            'wordwrap' => TRUE
//        );
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->from('testing.trial15@gmail.com', 'ngosnetwork.org'); // change it to yours
        $this->email->to($to); // change it to yours
        $this->email->subject($subject);
        $this->email->message($message);
        $res = $this->email->send();
        if ($res) {
            return 1;
        } else {
            return 0;
        }
    }

}
