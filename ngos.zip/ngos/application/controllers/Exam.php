<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');

class Exam extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('admin/Admin_model');
        $this->load->model('Ngos_model');
        $this->load->model('Mail_model');
        $this->load->model('States_districts');
        $this->load->model('Sms_model');
        $this->load->model('Exam_model');
        $this->load->model('Admin_model');
        
    }
    
    
    public function exam_registration(){
         $this->load->view('templates/header');
        $this->load->view('exam/exam_registration');
        $this->load->view('templates/footer');
    }
    
    public function register(){
        $data = array("name"=>$this->input->post('name'),
            "email"=>$this->input->post('email'),
            "mobile"=>$this->input->post('mobile'),
            "password"=> md5($this->input->post('password')));
        $res = $this->Exam_model->insert_user($data);
        if($res){
            echo 'register';
        }
    }
    
     public function exam_login(){
         $this->load->view('templates/header');
        $this->load->view('exam/exam_login');
        $this->load->view('templates/footer');
    }
    
    public function verify_user_details() {
        $email = $this->input->post('email');
        $password = md5($this->input->post('password'));
        $chk_profile = $this->Exam_model->check_login_details($email, $password);
        if ($chk_profile) {
            $session = array("userid" => $chk_profile->uid);
            $this->session->set_userdata($session); //setting sessions
            $this->show_exam();
        } else {
            $this->session->set_flashdata('login_fail', 'MemberID/Password incorrect');
            $this->login();
        }
    }
    
    public function verify_email(){
        $email = $this->input->post('email');
        $res = $this->Exam_model->verify_email($email);
        if($res){
            echo 'email_exists';
        }
    }
    
     public function verify_mobile(){
        $mobile = $this->input->post('mobile');
        $res = $this->Exam_model->verify_mobile($mobile);
        if($res){
            echo 'mobile_exists';
        }
    }


    public function show_exam(){
         $data['exams'] = $this->Admin_model->get_allexam_details();
        
         $this->load->view('templates/header');
        $this->load->view('exam/show_exam',$data);
        $this->load->view('templates/footer');
    }
    
    public function start_exam(){
         $data['exams'] = $this->Admin_model->get_allexam_details();
         //print_r($data['exams']);
        // $data['user_answers'] = $this->Admin_model->get_uniq_useranswers();
         $this->load->view('exam/start_exam',$data);
       
    }
    
    public function show_uniq_question(){
        $examid = $this->input->post('examid');
        $qnum = $this->input->post('qnum');
       $data['ques'] = $this->Admin_model->getuniqExamquestions($examid,$qnum);
      // print_r($data['ques']);
      // die();
       
        $this->load->view('exam/start_exam_res',$data);
    
    }
    
    public function user_seleted_option(){
        $examid = $this->input->post('exam_id');
         $question_id = $this->input->post('question_id');
         $question_num = $this->input->post('question_no');
         $selected_answer = $this->input->post('selected_answer');
         $data = array("uid"=>$_SESSION['userid'],
            "exam_id"=>$examid,
            "question_id"=>$question_id,
            "question_num"=>$question_num,
            "selected_answer"=>$selected_answer);
         
         $check_status = $this->Exam_model->get_user_exam_status($examid,$question_id,$question_num);
         if($check_status){
           $update = $this->Exam_model->update_answer_details($examid,$question_id,$question_num,$selected_answer);
             
         }else{
            $res = $this->Exam_model->insert_answer_details($data);  
         }
         
         
        
         
          
         
         
         
         
          
    }
    
    public function get_exam_marks(){
      $data['answers'] = $this->Exam_model->get_exam_marks_ofuser(); 
       $this->load->view('exam/answer_exam_res',$data);
      
    }
  
}
