
<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
class States extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('States_districts');
        $this->load->model('admin/Admin_model');
        $this->load->model('Sms_model');
    }

    public function districts() {
        $type = 'District';
       
        $data['states'] = $this->States_districts->all_indian_states();
        $data['banner'] = $this->Admin_model->get_banner($type);
        $this->load->view('templates/header');
        $this->load->view('districts/districts', $data);
        $this->load->view('templates/footer');
    }

    public function states() {
        $type = 'State';
        $data['states'] = $this->States_districts->all_indian_states();
        $data['banner'] = $this->Admin_model->get_banner($type);
        $this->load->view('templates/header');
        $this->load->view('states/states', $data);
        $this->load->view('templates/footer');
    }

    public function international() {
         $type = 'International';
        $data['auth_persons'] = $this->Admin_model->get_allinternational_auth_persons();
        $data['countries'] = $this->States_districts->get_all_countries();
        $data['banner'] = $this->Admin_model->get_banner($type);
       $this->load->view('templates/uniq_header',$data);
        $this->load->view('international/international', $data);
        $this->load->view('templates/footer');
    }

    public function get_state_districts() {
        $type = "State";
        $stateid = $this->input->post('state_id');
        $st_name = $this->States_districts->get_uniqstate_name($stateid);
        $data['auth_persons'] = $this->Admin_model->get_state_auth_persons($st_name->name);
         $data['state_banner_text'] = $this->Admin_model->get_state_banner_text($type,$st_name->name);
        $data['districts'] = $this->States_districts->get_uniqstate_districts($stateid);
        $this->load->view('templates/uniq_header',$data);
        $this->load->view('states/states_resp', $data);
        $this->load->view('templates/footer');
    }

    public function international_uniqngos($country) {
        $coun = str_replace("_", " ", $country);
        $type = "International";
        $data['ngos'] = $this->States_districts->get_uniqcountry_ngos($coun);
        $data['auth_persons'] = $this->Admin_model->get_international_auth_persons($coun);
        $data['international_banner_text'] = $this->Admin_model->get_international_banner_text($type,$coun);

         $this->load->view('templates/uniq_header',$data);
        $this->load->view('international/international_ngos', $data);
        $this->load->view('templates/footer');

//           $this->session->set_flashdata('intern_ngo_fail','Sorry!!! Ngo Details Are Not Found ');
//            $this->international();
    }

    public function national_uniqngos($national) {
        $type = 'National';
         $data['banner'] = $this->Admin_model->get_banner($type);
        $data['ngos'] = $this->States_districts->get_national_ngos($national);
        $data['auth_persons'] = $this->Admin_model->get_national_auth_persons($national);
        $data['national_banner_text'] = $this->Admin_model->get_banner($type);

        $this->load->view('templates/header');
        $this->load->view('national/national_ngos', $data);
        $this->load->view('templates/footer');

//          $this->session->set_flashdata('nat_ngo_fail','Sorry!!! Ngo Details Are Not Found ');
//          redirect(base_url());
    }

    public function state_uniqngos($state) {
        $sta  = str_replace("_", " ", $state);
        $type = "State";
        $data['ngos'] = $this->States_districts->get_uniqstate_ngos($sta);
        $data['auth_persons'] = $this->Admin_model->get_state_auth_persons($sta);
        //print_r($data['auth_persons']);
        $data['state_banner_text'] = $this->Admin_model->get_state_banner_text($type,$sta);
         $this->load->view('templates/uniq_header',$data);
        $this->load->view('states/state_ngos', $data);
        $this->load->view('templates/footer');
    }

    public function district_uniqngos($district) {
        $dist = str_replace("_", " ", $district);
        $type = "District";
        $data['ngos'] = $this->States_districts->get_uniqdistrict_ngos($dist);
        $data['auth_persons'] = $this->Admin_model->get_dist_auth_persons($dist);
        $data['dist_banner_text'] = $this->Admin_model->get_dist_banner_text($type,$dist);
        //print_r($data['auth_persons']);
        $this->load->view('templates/uniq_header',$data);
        $this->load->view('districts/district_ngos', $data);
        $this->load->view('templates/footer');

//           $this->session->set_flashdata('dt_ngo_fail','Sorry!!! Ngo Details Are Not Found ');
//           $this->districts();
    }

    public function get_districts() {
        $stateid = $this->input->post('state_id');
        $data['districts'] = $this->States_districts->get_uniqstate_districts($stateid);
        // print_r($data['districts']);
        $this->load->view('registration/dist_resp', $data);
    }
    
    public function get_districts_() {
        $stateid = $this->input->post('state_id');
        $data['districts'] = $this->States_districts->get_uniqstate_districts($stateid);
        // print_r($data['districts']);
        $this->load->view('registration/dist_resp1', $data);
    }
    
    public function event_details($gid){
        $data['event'] = $this->Admin_model->get_event_details($gid);
         $this->load->view('templates/header');
        $this->load->view('gallery/event_details', $data);
        $this->load->view('templates/footer');
    }

}
