<?php
use Restserver\Libraries\REST_Controller;
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

 
class Api extends REST_Controller{
    
    public function __construct()
    {
        parent::__construct();

        $this->load->model('States_districts');
    }
    
    function states_get(){
        $result = $this->States_districts->all_indian_states();
        if($result){
            $this->response($result,200);
        }else{
            $this->response('No record found',404);
        }
    }
}