<?php
//APPPATH.'libraries/Test.php';
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');

class Ngos extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // $this->load->library('test');
        $this->load->model('Ngos_model');
        $this->load->model('Sms_model');
        $this->load->model('States_districts');
        $this->load->model('Mail_model');
        $this->load->model('admin/Admin_model');
    }

    public function index() {
        //$this->load->library('Test');
       // $this->test->custom_libarary();
        $this->home();
      // $this->load->config('test');
      // $this->config->set_item('test','changing config settings from controller');
      // echo $this->config->item('test');
       // echo $this->test->hello();
    }

    public function home() {
        $type = 'Home';
        $data['banner'] = $this->Admin_model->get_banner($type);
        $data['notifications'] = $this->Admin_model->get_all_notifications_types();
        $this->load->view('templates/header');
        $this->load->view('home/home', $data);
        $this->load->view('templates/footer');
    }

    public function login() {

        $this->load->view('templates/header');
        $this->load->view('login/ngo_login');
        $this->load->view('templates/footer');
    }

    public function legality() {
        $type = 'Legality';
        $data['banner'] = $this->Admin_model->get_banner($type);
        $data['legality'] = $this->Admin_model->get_legality_text($type);
        $this->load->view('templates/header');
        $this->load->view('legality/legality', $data);
        $this->load->view('templates/footer');
    }

    public function offers() {
        $type = 'Offers';
        $data['banner'] = $this->Admin_model->get_banner($type);
        $this->load->view('templates/header');
        $this->load->view('offers/offers', $data);
        $this->load->view('templates/footer');
    }

    public function gallery() {
        $type = 'Gallery';
        $data['banner'] = $this->Admin_model->get_banner($type);
        $data['gallery'] = $this->Admin_model->get_gallery();
        $this->load->view('templates/header');
        $this->load->view('gallery/gallery', $data);
        $this->load->view('templates/footer');
    }

    public function emailservice() {
        $type = 'Emailservice';
        $data['banner'] = $this->Admin_model->get_banner($type);

        $this->load->view('templates/header');
        $this->load->view('emailservice/emailservice', $data);
        $this->load->view('templates/footer');
    }

    public function change_password() {
        if (!empty($_SESSION['memberid'])) {
            $this->load->view('templates/header');
            $this->load->view('login/change_password');
            $this->load->view('templates/footer');
        } else {
            $this->home();
        }
    }

    public function forgot_password() {
        if (!empty($_SESSION['memberid'])) {
            $this->load->view('templates/header');
            $this->load->view('login/forgot_password');
            $this->load->view('templates/footer');
        } else {
            $this->home();
        }
    }

    public function refral_bonus() {
        if (!empty($_SESSION['memberid'])) {
            $data['udetails'] = $this->Admin_model->get_all_details_ofuser($_SESSION['memberid']);

            $this->load->view('templates/header');
            $this->load->view('referal/referal', $data);
            $this->load->view('templates/footer');
        } else {
            $this->home();
        }
    }

    public function logout_user() {
        session_destroy();
        $this->index();
    }

    public function show_registration_page($type) {
        $data['type'] = $type;
        if ($type == 'International') {
            $price = $this->Ngos_model->get_membership_price($type);
            $price = str_replace(",", "", $price->price);
            $data['fee'] = $price;
            $this->load->view('templates/header');
            $this->load->view('registration/international_reg_page', $data);
            $this->load->view('templates/footer');
        } elseif ($type == 'National') {
            $price = $this->Ngos_model->get_membership_price($type);
            $price = str_replace(",", "", $price->price);
            $data['fee'] = $price;
            $this->load->view('templates/header');
            $this->load->view('registration/national_reg_page', $data);
            $this->load->view('templates/footer');
        } elseif ($type == 'State') {
            $price = $this->Ngos_model->get_membership_price($type);
            $price = str_replace(",", "", $price->price);
            $data['fee'] = $price;
            $this->load->view('templates/header');
            $this->load->view('registration/state_reg_page', $data);
            $this->load->view('templates/footer');
        } else {
            $price = $this->Ngos_model->get_membership_price($type);
            $price = str_replace(",", "", $price->price);
            $data['fee'] = $price;
            $this->load->view('templates/header');
            $this->load->view('registration/district_reg_page', $data);
            $this->load->view('templates/footer');
        }
    }

    public function show_offers_page($type) {
        $data['type'] = $type;
        $data['offers'] = $this->Ngos_model->get_offers_details($type);
        $this->load->view('templates/header');
        $this->load->view('offers/offers_page', $data);
        $this->load->view('templates/footer');
    }

    public function ngo_register() {
        
        $regtype = $this->input->post('reg_type1');
        
        $otp_details = array();
        $data = array(
            'tru_pre_name' => $this->input->post('tru_pre_name'),
            'tru_pre_same' => $this->input->post('tru_pre_same'),
            'tru_pre_of' => $this->input->post('tru_pre_of'),
            'tru_pre_email' => $this->input->post('tru_pre_email'),
            'tru_pre_pancard' => $this->input->post('tru_pre_pancard'),
            'try_pre_mobilecode' => $this->input->post('mobilecode'),
            'tru_pre_mobile1' => $this->input->post('tru_pre_mobile1'),
            'mobile_visible_status' => $this->input->post('mobile_visible_status'),
            'tru_pre_mobile2' => $this->input->post('tru_pre_mobile2'),
            'tru_pre_landline' => $this->input->post('tru_pre_landline'),
            'tru_sec_name' => $this->input->post('tru_sec_name'),
            'tru_sec_same' => $this->input->post('tru_sec_same'),
            'tru_sec_of' => $this->input->post('tru_sec_of'),
            'tru_sec_email' => $this->input->post('tru_sec_email'),
            'tru_sec_pancard' => $this->input->post('tru_sec_pancard'),
            'tru_sec_mobile1' => $this->input->post('tru_sec_mobile1'),
            'tru_sec_mobile2' => $this->input->post('tru_sec_mobile2'),
            'tru_sec_landline' => $this->input->post('tru_sec_landline'),
            'password' => md5($this->input->post('password')),
            'type' => $this->input->post('reg_type'),
            'reg_type' => $regtype,
            'country' => $this->input->post('country'),
            'state' => $this->input->post('state'),
            'district' => $this->input->post('district'),
            'member_id' => 'INNW' . random_string('numeric', 6)
        );



        $this->db->insert('ngos', $data);
        $inserted_id1 = $this->db->insert_id();
        $ngo_details = $this->Ngos_model->get_ngo_details($inserted_id1);
        $file_path = './uploads/' . $ngo_details->member_id . '/documents/';
        if (!is_dir($file_path)) {
            mkdir($file_path, 0777, TRUE); //0777=>permision of the folder to be created.777=>widest possible acess
        }

        for ($i = 1; $i <= 3; $i++) {
            $config['upload_path'] = './uploads/' . $ngo_details->member_id . '/documents/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf|doc|docx';
            $config['max_size'] = '5097512';
            $config['over_write'] = FALSE;


            $this->load->library('upload', $config);

            if ($i == 1 && !empty($_FILES['tru_pre_govproof']['name'])) {
                if (!$this->upload->do_upload('tru_pre_govproof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tru_pre_govproof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('ng_id', $inserted_id1)->update('ngos', $data);
                }
            } elseif ($i == 2 && !empty($_FILES['tru_sec_govproof']['name'])) {
                if (!$this->upload->do_upload('tru_sec_govproof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tru_sec_govproof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('ng_id', $inserted_id1)->update('ngos', $data);
                }
            } elseif ($i == 3 && !empty($_FILES['profile_pic']['name'])) {
                if (!$this->upload->do_upload('profile_pic')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['profile_pic'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('ng_id', $inserted_id1)->update('ngos', $data);
                }
            }
        }

        $this->ngo_trust_details($inserted_id1);
        $ngo_details1['member_id'] = $ngo_details->member_id;
        $ngo_membership_price = $this->Ngos_model->get_ngo_membership_details($ngo_details->member_id);
        $ngo_details1['price'] = $ngo_membership_price->tr_total_amount;

        if ($regtype != 'free') {
            //sending OTP for mobile
            $mobilecode = $this->input->post('mobilecode');
            if ($mobilecode == 91) {
                $number = $this->input->post('tru_pre_mobile1');
                $number1 = '91' . $number;
                $otpid = $this->send_regotp($number1);

                if ($otpid) {
                    $otp_details['otpid'] = $otpid;
                    $otp_details['number'] = $number1;
                    $otp_details['memberid'] = $ngo_details->member_id;
                    $otp_details['success'] = 'success';
                    //temporary sessions
                    $session = array("mem_id" => $ngo_details->member_id,
                        "tot_amt" => $ngo_membership_price->tr_total_amount,
                        "email" => $ngo_details->tru_pre_email,
                        "mobile" => $ngo_details->tru_pre_mobile1,
                        "fname" => $ngo_details->tru_pre_name);
                    $this->session->set_userdata($session);
                    echo $this->load->view('registration/otp_resp', $otp_details, TRUE);
                } else {
                    $otp_details['fail'] = 'fail';
                }
            } else {
                //sending OTP for email 
                $otpid = $this->send_emailforOTP($ngo_details->tru_pre_email, $ngo_details->member_id);
                if ($otpid) {
                    $otp_details['otpid'] = $otpid;
                    $otp_details['email'] = $ngo_details->tru_pre_email;
                    $otp_details['memberid'] = $ngo_details->member_id;
                    $otp_details['success'] = 'success';
                    //temporary sessions
                    $session = array("mem_id" => $ngo_details->member_id,
                        "tot_amt" => $ngo_membership_price->tr_total_amount,
                        "email" => $ngo_details->tru_pre_email,
                        "mobile" => $ngo_details->tru_pre_mobile1,
                        "fname" => $ngo_details->tru_pre_name);
                    $this->session->set_userdata($session);
                    echo $this->load->view('registration/email_otp_resp', $otp_details, TRUE);
                } else {
                    $otp_details['fail'] = 'fail';
                }
            }
        } else {
            echo $ngo_details->member_id;
        }
    }

    public function send_regotp($number) {
        if (!empty($number)) {
            $otpId = $this->Sms_model->SMS_otp_registration($number); //sending OTP to user registered mobile number
            return $otpId;
        } else {
            echo '<h4 style="color:red">Please Enter Valid Number..</h4>';
        }
    }

    public function verify_otp() {
        $otp_id = $this->input->post('otp_id');
        $memid = $this->input->post('member_id');
        $ver_otp = $this->Ngos_model->verify_otp($otp_id);
        if ($ver_otp->otp == $this->input->post('otp')) {
            $status = $this->Ngos_model->update_member_mobilestatus($memid);
            $res = $this->db->where('otp_id', $this->input->post('otp_id'))->delete('otp');
            if ($res) {
                echo 'success';
            }
        }
    }

    public function sendOTPagain() {
        $otp_details = array();
        $number = $this->input->post('num');

        $member = $this->input->post('mem');
        if (!empty($number)) {

            $otpId = $this->Sms_model->SMS_otp_registration($number);

            if ($otpId) {
                $otp_details['otpid'] = $otpId;
                $otp_details['number'] = $number;
                $otp_details['memberid'] = $member;
                $otp_details['success'] = 'success';
            } else {
                $otp_details['fail'] = 'fail';
            }
            // echo json_encode($s);   
            echo $this->load->view('registration/otp_resp', $otp_details, TRUE);
        } else {
            echo '<h4 style="color:red">Please Enter Valid Number..</h4>';
        }
    }

    public function reg_success() {
        $this->load->view('templates/header');
        $this->load->view('registration/reg_success_resp');
        $this->load->view('templates/footer');
    }

    public function ngo_trust_details($inserted_id1) {

        $price = 0;
        $auth_type = $this->input->post('auth_type');
        $ttype = $this->input->post('reg_type');
        if ($auth_type != 'admin') {
            if ($ttype == 'International') {
                $price = $this->Ngos_model->get_membership_price($ttype);
                $price = str_replace(",", "", $price->price);
                $price = $price;
            } elseif ($ttype == 'National') {
                $price = $this->Ngos_model->get_membership_price($ttype);
                $price = str_replace(",", "", $price->price);
                $price = $price;
            } elseif ($ttype == 'State') {
                $price = $this->Ngos_model->get_membership_price($ttype);
                $price = str_replace(",", "", $price->price);
                $price = $price;
            } else {
                $price = $this->Ngos_model->get_membership_price($ttype);
                $price = str_replace(",", "", $price->price);
                $price = $price;
            }
        }

        //membership amount calculation
        $menbership_fee = $price;
        $percentToGet = 18;
        $percentInDecimal = $percentToGet / 100;
        $tax = $percentInDecimal * $menbership_fee;
        $total_amount = $tax + $menbership_fee;

        $ngo_details = $this->Ngos_model->get_ngo_details($inserted_id1);
        $data1 = array(
            'ng_id' => $inserted_id1,
            'member_id' => $ngo_details->member_id,
            'tr_name' => $this->input->post('tr_name'),
            'tr_reg_date' => $this->input->post('tr_reg_date'),
            'tr_pancard' => $this->input->post('tr_pancard'),
            'tr_12AA_num' => $this->input->post('tr_12AA_num'),
            'tr_80G_num' => $this->input->post('tr_80Gnum'),
            'tr_FCRA_num' => $this->input->post('tr_FCRA_num'),
            'tr_1023_num' => $this->input->post('tr_1023_num'),
            'tr_35AC_num' => $this->input->post('tr_35AC_num'),
            'tr_501C_num' => $this->input->post('tr_501C_num'),
            'tr_nitiayog_num' => $this->input->post('tr_nitiayog_num'),
            'tr_3IT_dates' => $this->input->post('tr_3IT_dates'),
            'tr_3AR_dates' => $this->input->post('tr_3AR_dates'),
            'tr_3FCRA_dates' => $this->input->post('tr_3FCRA_dates'),
            'tr_new_proj' => $this->input->post('tr_new_proj'),
            'tr_runnig_proj' => $this->input->post('tr_runnig_proj'),
            'tr_landline' => $this->input->post('tr_landline'),
            'tr_mobile' => $this->input->post('tr_mobile'),
            'tr_email' => $this->input->post('tr_email'),
            'tr_refid' => uniqid(),
            'tr_refby' => '',
            'tr_refid_gift' => 0,
            'tr_membership_fee' => $price,
            'tr_servicetax_fee' => $tax,
            'tr_total_amount' => $total_amount,
            'tr_text' => $this->input->post('tr_text')
        );
        $this->db->insert('trust_details', $data1);
        $inserted_id2 = $this->db->insert_id();

        //referal code amount calculation
        $refcode = $this->input->post('tr_refid');
        if (!empty($refcode)) {
            $ref_pers_details = $this->Ngos_model->get_refperson_details($refcode);
            $ref_percent = 10;
            $refpersInDecimal = $ref_percent / 100;
            $refamount = $refpersInDecimal * $menbership_fee;
            $this->db->where('tr_id', $inserted_id2)->update('trust_details', array("tr_refby" => $ref_pers_details->member_id));
            $status = $this->Ngos_model->ref_amount_credit($ref_pers_details->member_id, $ngo_details->tru_pre_name, $refamount);
        }

        for ($i = 1; $i <= 20; $i++) {
            $config['upload_path'] = './uploads/' . $ngo_details->member_id . '/documents/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf|doc|docx';
            $config['max_size'] = '5097512';
            $config['over_write'] = FALSE;


            $this->load->library('upload', $config);
            $this->upload->initialize($config); //Make this line must be here.

            if ($i == 1 && !empty($_FILES['tr_bill_proof']['name'])) {
                if (!$this->upload->do_upload('tr_bill_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_bill_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 2 && !empty($_FILES['tr_regcer_proof']['name'])) {
                if (!$this->upload->do_upload('tr_regcer_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_regcer_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 3 && !empty($_FILES['tr_pancard_proof']['name'])) {
                if (!$this->upload->do_upload('tr_pancard_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_pancard_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 4 && !empty($_FILES['tr_12AA_proof']['name'])) {
                if (!$this->upload->do_upload('tr_12AA_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_12AA_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 5 && !empty($_FILES['tr_80G_proof']['name'])) {
                if (!$this->upload->do_upload('tr_80G_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_80G_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 6 && !empty($_FILES['tr_FCRA_proof']['name'])) {
                if (!$this->upload->do_upload('tr_FCRA_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_FCRA_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 7 && !empty($_FILES['tr_1023_proof']['name'])) {
                if (!$this->upload->do_upload('tr_1023_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_1023_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 8 && !empty($_FILES['tr_35AC_proof']['name'])) {
                if (!$this->upload->do_upload('tr_35AC_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_35AC_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 9 && !empty($_FILES['tr_501C_proof']['name'])) {
                if (!$this->upload->do_upload('tr_501C_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_501C_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 10 && !empty($_FILES['tr_nitiayog_proof']['name'])) {
                if (!$this->upload->do_upload('tr_nitiayog_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_nitiayog_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 11 && !empty($_FILES['tr_3IT_dat_proof']['name'])) {
                if (!$this->upload->do_upload('tr_3IT_dat_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_3IT_dat_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 12 && !empty($_FILES['tr_3AR_dat_proof']['name'])) {
                if (!$this->upload->do_upload('tr_3AR_dat_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_3AR_dat_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 13 && !empty($_FILES['tr_3FCRA_dat_proof']['name'])) {
                if (!$this->upload->do_upload('tr_3FCRA_dat_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_3FCRA_dat_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 14 && !empty($_FILES['tr_new_proj_proof']['name'])) {
                if (!$this->upload->do_upload('tr_new_proj_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_new_proj_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 15 && !empty($_FILES['tr_running_proj_proof']['name'])) {
                if (!$this->upload->do_upload('tr_running_proj_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_running_proj_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 16 && !empty($_FILES['tr_paper_cutting_proof']['name'])) {
                if (!$this->upload->do_upload('tr_paper_cutting_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_paper_cutting_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 17 && !empty($_FILES['tr_photo']['name'])) {
                if (!$this->upload->do_upload('tr_photo')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_photo'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 18 && !empty($_FILES['tr_FCRA_audit_proof']['name'])) {
                $this->load->library('upload', $config);
                $this->upload->initialize($config); //Make this line must be here.
                if (!$this->upload->do_upload('tr_FCRA_audit_proof')) {
                    echo $this->upload->display_errors();
                    // die();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_FCRA_audit_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 19 && !empty($_FILES['tr_currentbill_proof']['name'])) {
                if (!$this->upload->do_upload('tr_currentbill_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_currentbill_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            } elseif ($i == 20 && !empty($_FILES['tr_passport_proof']['name'])) {
                if (!$this->upload->do_upload('tr_passport_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_passport_proof'] = 'uploads/' . $ngo_details->member_id . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('tr_id', $inserted_id2)->update('trust_details', $data);
                }
            }
        }
    }

    public function ngo_member_login() {
        $memberid = $this->input->post('member_id');
        $password = md5($this->input->post('password'));
        $chk_profile = $this->Ngos_model->check_login_details($memberid, $password);
        if ($chk_profile) {
            $session = array("memberid" => $chk_profile->member_id,
                "ngid" => $chk_profile->ng_id,
                "type" => 'user');
            $this->session->set_userdata($session); //setting sessions
            $this->account_details();
        } else {
            $this->session->set_flashdata('login_fail', 'MemberID/Password incorrect');
            $this->login();
        }
    }

    public function view_uniq_authperson() {
        $authid = $this->input->post('authid');
        $data['auth_person'] = $this->Admin_model->get_uniq_auth_person_details($authid);
        //print_r($data['auth_person']);
        // die();

        $this->load->view('admin/auth_persons/auht_popup_res', $data);
    }

    public function account_details() {
        if ($_SESSION['type'] == 'admin' || $_SESSION['type'] == 'user') {
            $data['udetails'] = $this->Admin_model->get_all_details_ofuser($_SESSION['memberid']);
            //print_r($data['udetails']);
            //  die();
            $this->load->view('templates/header');
            $this->load->view('account/account_details', $data);
            $this->load->view('templates/footer');
        }
    }

    public function ngo_update() {
        $ngoid = $this->input->post('ngo_id');
        $ress = $this->Ngos_model->get_ngo_details($ngoid);
        $data = array(
            'tru_pre_name' => $this->input->post('tru_pre_name'),
            'tru_pre_same' => $this->input->post('tru_pre_same'),
            'tru_pre_of' => $this->input->post('tru_pre_of'),
            'tru_pre_email' => $this->input->post('tru_pre_email'),
            'tru_pre_pancard' => $this->input->post('tru_pre_pancard'),
            'tru_pre_mobile1' => $this->input->post('tru_pre_mobile1'),
            'tru_pre_mobile2' => $this->input->post('tru_pre_mobile2'),
            'tru_pre_landline' => $this->input->post('tru_pre_landline'),
            'tru_sec_name' => $this->input->post('tru_sec_name'),
            'tru_sec_same' => $this->input->post('tru_sec_same'),
            'tru_sec_of' => $this->input->post('tru_sec_of'),
            'tru_sec_email' => $this->input->post('tru_sec_email'),
            'tru_sec_pancard' => $this->input->post('tru_sec_pancard'),
            'tru_sec_mobile1' => $this->input->post('tru_sec_mobile1'),
            'tru_sec_mobile2' => $this->input->post('tru_sec_mobile2'),
            'tru_sec_landline' => $this->input->post('tru_sec_landline'),
            'password' => $ress->password,
            'type' => $this->input->post('reg_type'),
            'country' => $this->input->post('country'),
            'state' => $this->input->post('state'),
            'district' => $this->input->post('district'),
        );

        $this->db->where('member_id', $_SESSION['memberid'])->update('ngos', $data);
        for ($i = 1; $i <= 3; $i++) {
            $config['upload_path'] = './uploads/' . $_SESSION['memberid'] . '/documents/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf|doc|docx';
            $config['max_size'] = '5097512';
            $config['over_write'] = FALSE;


            $this->load->library('upload', $config);

            if ($i == 1 && !empty($_FILES['tru_pre_govproof']['name'])) {
                if (!$this->upload->do_upload('tru_pre_govproof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tru_pre_govproof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('ngos', $data);
                }
            } elseif ($i == 2 && !empty($_FILES['tru_sec_govproof']['name'])) {
                if (!$this->upload->do_upload('tru_sec_govproof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tru_sec_govproof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('ngos', $data);
                }
            } elseif ($i == 3 && !empty($_FILES['profile_pic']['name'])) {
                if (!$this->upload->do_upload('profile_pic')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['profile_pic'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('ngos', $data);
                }
            }
        }

        $this->ngo_trust_details_update();
        echo 'edit_success';
    }

    public function ngo_trust_details_update() {
        $memberid = $this->input->post('memberid');

        $ress = $this->Ngos_model->get_ngo_membership_details($memberid);


        $data1 = array(
            'tr_name' => $this->input->post('tr_name'),
            'tr_reg_date' => $this->input->post('tr_reg_date'),
            'tr_pancard' => $this->input->post('tr_pancard'),
            'tr_12AA_num' => $this->input->post('tr_12AA_num'),
            'tr_80G_num' => $this->input->post('tr_80Gnum'),
            'tr_FCRA_num' => $this->input->post('tr_FCRA_num'),
            'tr_1023_num' => $this->input->post('tr_1023_num'),
            'tr_35AC_num' => $this->input->post('tr_35AC_num'),
            'tr_501C_num' => $this->input->post('tr_501C_num'),
            'tr_nitiayog_num' => $this->input->post('tr_nitiayog_num'),
            'tr_3IT_dates' => $this->input->post('tr_3IT_dates'),
            'tr_3AR_dates' => $this->input->post('tr_3AR_dates'),
            'tr_3FCRA_dates' => $this->input->post('tr_3FCRA_dates'),
            'tr_new_proj' => $this->input->post('tr_new_proj'),
            'tr_runnig_proj' => $this->input->post('tr_runnig_proj'),
            'tr_landline' => $this->input->post('tr_landline'),
            'tr_mobile' => $this->input->post('tr_mobile'),
            'tr_email' => $this->input->post('tr_email'),
            'tr_membership_fee' => $ress->tr_membership_fee,
            'tr_servicetax_fee' => $ress->tr_servicetax_fee,
            'tr_total_amount' => $ress->tr_total_amount,
            'tr_text' => $this->input->post('tr_text')
        );
        $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data1);


        for ($i = 1; $i <= 20; $i++) {
            $config['upload_path'] = './uploads/' . $_SESSION['memberid'] . '/documents/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf|doc|docx';
            $config['max_size'] = '5097512';
            $config['over_write'] = FALSE;


            $this->load->library('upload', $config);
            $this->upload->initialize($config); //Make this line must be here.

            if ($i == 1 && !empty($_FILES['tr_bill_proof']['name'])) {
                if (!$this->upload->do_upload('tr_bill_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_bill_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 2 && !empty($_FILES['tr_regcer_proof']['name'])) {
                if (!$this->upload->do_upload('tr_regcer_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_regcer_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 3 && !empty($_FILES['tr_pancard_proof']['name'])) {
                if (!$this->upload->do_upload('tr_pancard_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_pancard_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 4 && !empty($_FILES['tr_12AA_proof']['name'])) {
                if (!$this->upload->do_upload('tr_12AA_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_12AA_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 5 && !empty($_FILES['tr_80G_proof']['name'])) {
                if (!$this->upload->do_upload('tr_80G_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_80G_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 6 && !empty($_FILES['tr_FCRA_proof']['name'])) {
                if (!$this->upload->do_upload('tr_FCRA_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_FCRA_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 7 && !empty($_FILES['tr_1023_proof']['name'])) {
                if (!$this->upload->do_upload('tr_1023_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_1023_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 8 && !empty($_FILES['tr_35AC_proof']['name'])) {
                if (!$this->upload->do_upload('tr_35AC_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_35AC_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 9 && !empty($_FILES['tr_501C_proof']['name'])) {
                if (!$this->upload->do_upload('tr_501C_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_501C_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 10 && !empty($_FILES['tr_nitiayog_proof']['name'])) {
                if (!$this->upload->do_upload('tr_nitiayog_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_nitiayog_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 11 && !empty($_FILES['tr_3IT_dat_proof']['name'])) {
                if (!$this->upload->do_upload('tr_3IT_dat_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_3IT_dat_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 12 && !empty($_FILES['tr_3AR_dat_proof']['name'])) {
                if (!$this->upload->do_upload('tr_3AR_dat_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_3AR_dat_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 13 && !empty($_FILES['tr_3FCRA_dat_proof']['name'])) {
                if (!$this->upload->do_upload('tr_3FCRA_dat_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_3FCRA_dat_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 14 && !empty($_FILES['tr_new_proj_proof']['name'])) {
                if (!$this->upload->do_upload('tr_new_proj_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_new_proj_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 15 && !empty($_FILES['tr_running_proj_proof']['name'])) {
                if (!$this->upload->do_upload('tr_running_proj_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_running_proj_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 16 && !empty($_FILES['tr_paper_cutting_proof']['name'])) {
                if (!$this->upload->do_upload('tr_paper_cutting_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_paper_cutting_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 17 && !empty($_FILES['tr_photo']['name'])) {
                if (!$this->upload->do_upload('tr_photo')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_photo'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 18 && !empty($_FILES['tr_FCRA_audit_proof']['name'])) {
                $this->load->library('upload', $config);
                $this->upload->initialize($config); //Make this line must be here.
                if (!$this->upload->do_upload('tr_FCRA_audit_proof')) {
                    echo $this->upload->display_errors();
                    // die();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_FCRA_audit_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 19 && !empty($_FILES['tr_currentbill_proof']['name'])) {
                if (!$this->upload->do_upload('tr_currentbill_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_currentbill_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            } elseif ($i == 20 && !empty($_FILES['tr_passport_proof']['name'])) {
                if (!$this->upload->do_upload('tr_passport_proof')) {
                    echo $this->upload->display_errors();
                } else {
                    $img_details = $this->upload->data();


                    $data['tr_passport_proof'] = 'uploads/' . $_SESSION['memberid'] . '/documents/' . $img_details['raw_name'] . $img_details['file_ext'];
                    $this->db->where('member_id', $_SESSION['memberid'])->update('trust_details', $data);
                }
            }
        }
    }

    public function addfree_inter_users() {
        if ($_SESSION['type'] == 'admin' && $_SESSION['reg_type'] == 'free') {
            $data['type'] = 'International';
            $this->load->view('templates/header');
            $this->load->view('free_registration/International', $data);
            $this->load->view('templates/footer');
        } else {
            redirect(base_url('dashboard'));
        }
    }

    public function addfree_nat_users() {
        if ($_SESSION['type'] == 'admin' && $_SESSION['reg_type'] == 'free') {
            $data['type'] = 'National';
            $this->load->view('templates/header');
            $this->load->view('free_registration/National', $data);
            $this->load->view('templates/footer');
        } else {
            redirect(base_url('dashboard'));
        }
    }

    public function addfree_state_users() {
        if ($_SESSION['type'] == 'admin' && $_SESSION['reg_type'] == 'free') {
            $data['type'] = 'State';
            $this->load->view('templates/header');
            $this->load->view('free_registration/State', $data);
            $this->load->view('templates/footer');
        } else {
            redirect(base_url('dashboard'));
        }
    }

    public function addfree_dist_users() {
        if ($_SESSION['type'] == 'admin' && $_SESSION['reg_type'] == 'free') {
            $data['type'] = 'District';
            $this->load->view('templates/header');
            $this->load->view('free_registration/District', $data);
            $this->load->view('templates/footer');
        } else {
            redirect(base_url('dashboard'));
        }
    }

    public function send_email() {
        $name = $this->input->post('name');
        $email = $this->input->post('email');
        $mobile = $this->input->post('mobile');
        $message = $this->input->post('comment');
        $subject = 'Enquiry From NGO Users';
        $body = "Name:   " . $name . "<br> Email:   " . $email . " <br> Mobile:   " . $mobile . " <br> Message:   " . $message . " ";
        $status = $this->Mail_model->sendEmail($body, $subject, $email);
        if ($status) {
            $data = array('name' => $name,
                'email' => $email,
                'mobile' => $mobile,
                'comment' => $message);
            $res = $this->Ngos_model->insert_enquiry_details($data);
            if ($res) {
                echo 'email_sent';
            }
        } else {
            echo 'fail';
        }
    }

    public function send_emailforOTP($email, $memberid) {

        $subject = 'Email Verification From NGOS Network';
        $otpId = $this->Mail_model->sendEmail_OTP($subject, $email, $memberid);
        if ($otpId) {
            return $otpId;
        } else {
            
        }
    }

    public function send_emailOTPagain() {
        $otp_details = array();
        $subject = 'Email Verification From NGOS Network';
        $email = $this->input->post('email');
        $memberid = $this->input->post('mem');
        $otpID = $this->input->post('otpID');
        $this->db->where('otp_id', $otpID)->delete('otp');
        $otpid = $this->Mail_model->sendEmail_OTP($subject, $email, $memberid);
        if ($otpid) {
            $otp_details['otpid'] = $otpid;
            $otp_details['email'] = $email;
            $otp_details['memberid'] = $memberid;
            $otp_details['success'] = 'success';

            echo $this->load->view('registration/email_otp_resp', $otp_details, TRUE);
        } else {
            $otp_details['fail'] = 'fail';
        }
    }

    public function update_password() {
        $memberid = $this->input->post('member_id');
        $password = md5($this->input->post('new_pass'));
        $update_pass = $this->Ngos_model->update_member_password($memberid, $password);
        if ($update_pass) {
            $this->session->set_flashdata('update_pass_sucs', 'Password is updated successfully');
            $this->login();
        } else {
            $this->session->set_flashdata('update_pass_fail', 'Password not updated');
            $this->forgot_password();
        }
    }

    public function validate_refcode() {
        $refcode = $this->input->post('refcode');
        $res = $this->Ngos_model->check_referal_code($refcode);
        if ($res) {
            echo 'valid';
        } else {
            echo 'invalid';
        }
    }

    public function view_notification($type) {
        $banner_type = 'Home';
        $type = str_replace('_', ' ', $type);
        $data['banner'] = $this->Admin_model->get_banner($banner_type);
        $data['notification'] = $this->Admin_model->get_notification_text($type);
        $this->load->view('templates/header');
        $this->load->view('view_notifications/view_notification', $data);
        $this->load->view('templates/footer');
    }

    public function refmoney_withdraw() {
        $memberid = $this->input->post('memberid');
        $data = array('memberid' => $memberid,
            'amount' => $this->input->post('amount'));
        $chk_status = $this->Admin_model->check_refmoney_record($data);
        if ($chk_status) {
            echo 'alredy_inserted';
        } else {
            $res = $this->Admin_model->insert_refmoney_records($data);
            $res1 = $this->Admin_model->update_refmoney_status($memberid);
            if ($res && $res1) {
                echo 'inserted';
            } else {
                echo 'not inserted';
            }
        }
    }

}
