<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
class Admin_search extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('admin/Admin_model');
        $this->load->model('Ngos_model');
        $this->load->model('Mail_model');
        $this->load->model('States_districts');
        $this->load->model('Sms_model');
        $this->load->helper('text');
    }

    public function get_authnames() {
        $type = $_GET['type'];
        if (isset($_GET['term'])) {
            $name = strtolower($_GET['term']);
            $this->Admin_model->search_auth_names($type, $name);
        }
    }

    public function getSearchpersonRow() {
        $type = $this->input->post('auth_type');
        $name = $this->input->post('auth_name');
        $person = $this->Admin_model->search_auth_person_row($type, $name);
        if (!empty($person)) {
            $data['auth_persons'] = $person;
            $data['type'] = $type;
            $this->load->view('admin/search/auth_search_resp', $data);
        } else {
            echo '<center><h4 class="text-center " style="color: red">No results found..</h4></center>';
        }
    }

    public function enquiry_moderations() {
        if (!empty($_SESSION['aid'])) {
            $data['enqs'] = $this->Admin_model->getenquiry_moderations();
            $this->load->view('admin/header');
            $this->load->view('admin/enquirys/enquiry_moderations', $data);
        } else {
            $this->index();
        }
    }

    public function get_enquriry_message() {
        $enqid = $this->input->post('eid');
        $enquiry = $this->Admin_model->view_enquriry_message($enqid);

        echo '
            <p>' . $enquiry->comment . '</p>
        ';
    }

    public function enquriry_reply() {
        $enqid = $this->input->post('enqid');
        $to_email = $this->input->post('user_email');
        $subject = "Reply From NGO'S Network";
        $message = $this->input->post('reply_message');
        $res = $this->Mail_model->send_enquriry_reply($to_email, $subject, $message);
        if ($res) {
            $status = $this->Admin_model->update_enquriry_status($enqid);
            echo 'mail_sent';
        } else {
            echo 'mail_notsent';
        }
    }

    public function delete_enquriry() {
        $enqid = $this->input->post('enqid');
        $respone = $this->Admin_model->delete_enquriry($enqid);
        if ($respone) {
            echo 'success';
        } else {
            echo 'fail';
        }
    }

    public function pending_referal_moderations() {
        if (!empty($_SESSION['aid'])) {
            $data['referals'] = $this->Admin_model->getpendingreferal_moderations();
            $this->load->view('admin/header');
            $this->load->view('admin/referals/referal_moderations', $data);
        } else {
            $this->index();
        }
    }

    public function approved_referal_moderations() {
        if (!empty($_SESSION['aid'])) {
            $data['referals'] = $this->Admin_model->getapprovedreferal_moderations();
            $this->load->view('admin/header');
            $this->load->view('admin/referals/referal_moderations', $data);
        } else {
            $this->index();
        }
    }

    public function rejected_referal_moderations() {
        if (!empty($_SESSION['aid'])) {
            $data['referals'] = $this->Admin_model->getrejectedreferal_moderations();
            $this->load->view('admin/header');
            $this->load->view('admin/referals/referal_moderations', $data);
        } else {
            $this->index();
        }
    }

    public function update_refmoney_status() {
        $memberid = $this->input->post('memberid');
        $value = $this->input->post('value');
        $status = $this->Admin_model->update_refmoney_adminstatus($memberid, $value);
        if ($status) {
            echo 'success';
        } else {
            echo 'fail';
        }
    }

    public function delete_refrecord() {
        $id = $this->input->post('id');
        $memberid = $this->input->post('memberid');

        $respone = $this->Admin_model->delete_refralrecord($id, $memberid);

        if ($respone) {
            echo 'success';
        } else {
            echo 'fail';
        }
    }

    public function addgallery_data() {
        $data = array("event_name" => $this->input->post('event_name'),
            "organized_by" => $this->input->post('event_by'),
            "date" => $this->input->post('event_date'),
            "location" => $this->input->post('event_location'),
            "description" => $this->input->post('event_des'),);

        if (!empty($_FILES['gallery_image']['name'])) {
            $files = $_FILES;
            $count = count($_FILES['gallery_image']['name']);
            
            for ($i = 0; $i < $count; $i++) {
                $_FILES['gallery_image']['name'] = $files['gallery_image']['name'][$i];
                $_FILES['gallery_image']['type'] = $files['gallery_image']['type'][$i];
                $_FILES['gallery_image']['tmp_name'] = $files['gallery_image']['tmp_name'][$i];
                $_FILES['gallery_image']['error'] = $files['gallery_image']['error'][$i];
                $_FILES['gallery_image']['size'] = $files['gallery_image']['size'][$i];

                $filepath = "uploads/admin/gallery/";
                if (!is_dir($filepath)) {
                    mkdir($filepath, 0777, TRUE);
                }

                $config['upload_path'] = "./uploads/admin/gallery/";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                $config['max_size'] = 102578544;
                $config['remove_spaces'] = FALSE;
                $config['overwrite'] = FALSE;

                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('gallery_image')) {
                    echo $this->upload->display_errors();
                } else {
                    $imgdata = $this->upload->data();
                    $imgname = 'uploads/admin/gallery/' . $imgdata['raw_name'] . $imgdata['file_ext'];  
                    $images[] = $imgname;
                }
            }
            
            $fileName = implode(',',$images);
            $data['images'] = $fileName;
            $res = $this->db->insert('gallery', $data);
            if ($res) {
                echo 'inserted';
            } else {
                echo 'notinserted';
            }
        }
    }
    
    public function manage_gallery() {
        if (!empty($_SESSION['aid'])) {
            $data['gallery'] = $this->Admin_model->get_gallery();
            $this->load->view('admin/header');
            $this->load->view('admin/gallery/manage_gallery',$data);
        } else {
            $this->index();
        }
    }
    
    public function edit_gallery($galleryid){
        $data['gallery'] = $this->Admin_model->get_event_details($galleryid);
         $this->load->view('admin/header');
         $this->load->view('admin/gallery/edit_gallery',$data);
    }
    
    
    public function editgallery_data() {
        $galleryid = $this->input->post('gallery_id');
        $data = array("event_name" => $this->input->post('event_name'),
            "organized_by" => $this->input->post('event_by'),
            "date" => $this->input->post('event_date'),
            "location" => $this->input->post('event_location'),
            "description" => $this->input->post('event_des'),);
        
        $res = $this->Admin_model->update_gallery_data($galleryid,$data);

       
            if ($res) {
                echo 'updated';
            } else {
                echo 'notupdated';
            }
        
    }
    
    public function delete_gallery(){
        $galleryid = $this->input->post('gid');
        $res = $this->Admin_model->delete_gallery_row($galleryid);
        if($res){
            echo 'deleted';
        }else{
            echo 'notdeleted';
        }
    }
    public function add_exams() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/exams/add_exams');
        } else {
            $this->index();
        }
    }
    
    public function view_exams() {
        if (!empty($_SESSION['aid'])) {
            $data['exams'] = $this->Admin_model->get_allexam_details();
            $this->load->view('admin/header');
            $this->load->view('admin/exams/view_exams',$data);
        } else {
            $this->index();
        }
    }
    
    public function add_exam_details(){
        $data = array("exam_name" => $this->input->post('exam_name'),
            "exam_date" => $this->input->post('exam_date'),
             "exam_time" => $this->input->post('exam_time'),
            "exam_duration" => $this->input->post('exam_duration'),
            "total_questions" => $this->input->post('total_questions'),
            "total_marks" => $this->input->post('total_marks'),
            "total_qmarks" => $this->input->post('total_qmarks'));
        
        $res = $this->Admin_model->insert_exam_details($data);
        if($res){
            echo 'submitted';
        }else{
            echo 'notsubmitted';
        }
    }
    
     public function delete_exam(){
        $examid = $this->input->post('examid');
        $res = $this->Admin_model->delete_exam_row($examid);
        if($res){
            echo 'deleted';
        }else{
            echo 'notdeleted';
        }
    }
    
     public function edit_exam_details($examid) {
        if (!empty($_SESSION['aid'])) {
            $data['exams'] = $this->Admin_model->get_uniq_exam_details($examid);
            // print_r($data['auth_person']);
            $this->load->view('admin/header');
            $this->load->view('admin/exams/edit_exam_details', $data);
        } else {
            $this->index();
        }
    }
    
    public function edit_examination_details(){
        $examid = $this->input->post('exam_id');
        $data = array("exam_name" => $this->input->post('exam_name'),
            "exam_date" => $this->input->post('exam_date'),
             "exam_time" => $this->input->post('exam_time'),
            "exam_duration" => $this->input->post('exam_duration'),
            "total_questions" => $this->input->post('total_questions'),
            "total_marks" => $this->input->post('total_marks'),
            "total_qmarks" => $this->input->post('total_qmarks'));
        
        $res = $this->Admin_model->update_exam_details($examid,$data);
        if($res){
            echo 'submitted';
        }else{
            echo 'notsubmitted';
        }
    }
    
    public function exam_questions($examid){
        if (!empty($_SESSION['aid'])) {
            $data['exams'] = $this->Admin_model->get_uniq_exam_details($examid);
           
            $data['examid'] = $examid;
            $this->load->view('admin/header');
            $this->load->view('admin/exams/addexam_questions', $data);
        } else {
            $this->index();
        }
    }
    
    public function add_exam_questions(){
        $data = array("exam_id" => $this->input->post('exam_id'),
            "question_number"=>$this->input->post('question_number'),
            "question_name" => $this->input->post('question_name'),
             "answer1" => $this->input->post('option1_ans1'),
            "answer2" => $this->input->post('option1_ans2'),
            "answer3" => $this->input->post('option1_ans3'),
            "answer4" => $this->input->post('option1_ans4'),
            "correct_answer" => $this->input->post('correct_answer'));
        
        $res = $this->Admin_model->insert_exam_questions($data);
        if($res){
            echo 'submitted';
        }else{
            echo 'notsubmitted';
        }
    }
    
    public function viewexam_questions($examid,$offset = 0){
        if (!empty($_SESSION['aid'])) {
            // Config setup
            $exam_id = $examid;
            $num_rows = $this->Admin_model->get_uniq_exam_questionCount($exam_id);
            $config['base_url'] = base_url() . 'admin/Admin_search/viewexam_questions/'.$exam_id;
            $config['total_rows'] = count($num_rows);
            $config['per_page'] = 1;
            //$config['uri_segment']       = 3;
            $config['num_links'] = 1000;
            $config['use_page_numbers'] = FALSE;
            $config['first_tag_open'] = $config['last_tag_open'] = $config['next_tag_open'] = $config['prev_tag_open'] = $config['num_tag_open'] = '<li>';
            $config['first_tag_close'] = $config['last_tag_close'] = $config['next_tag_close'] = $config['prev_tag_close'] = $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = "<li><a href='javascript:void(0);'><b>";
            $config['cur_tag_close'] = "</b></a></li>";
            $this->pagination->initialize($config);
            $data['question'] = $this->Admin_model->getExamquestions($config['per_page'], $offset,$exam_id); // take record of the table
           // print_r($data['question']);
           // die();
            $this->load->view('admin/header');
             $this->load->view('admin/exams/viewexam_questions', $data);
        } else {
            $this->index();
        }
        
    }
    
    public function edit_exam_questions(){
        $questionid = $this->input->post('question_id');
        $examid = $this->input->post('exam_id');
        $data = array("exam_id" => $examid,
            "question_number"=>$this->input->post('question_number'),
            "question_name" => $this->input->post('question_name'),
             "answer1" => $this->input->post('option1_ans1'),
            "answer2" => $this->input->post('option1_ans2'),
            "answer3" => $this->input->post('option1_ans3'),
            "answer4" => $this->input->post('option1_ans4'),
            "correct_answer" => $this->input->post('correct_answer'));
   
        $res = $this->Admin_model->update_exam_questions($examid,$questionid,$data);
        
        if($res){
            echo 'submitted';
        }else{
            echo 'notsubmitted';
        }
    }
    
   

}
