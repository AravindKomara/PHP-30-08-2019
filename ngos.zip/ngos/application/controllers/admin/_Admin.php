<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');

defined('BASEPATH') OR exit('No direct script access allowed');

class _Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('admin/Admin_model');
        $this->load->model('Ngos_model');
        $this->load->model('States_districts');
        $this->load->model('Sms_model');
        $this->load->model('Mail_model');
    }

    public function index() {
        $this->load->view('admin/login');
    }

    public function dashboard() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/dashboard');
        } else {
            $this->index();
        }
    }

    public function admin_login() {
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $res = $this->Admin_model->verify_login_details($email, $password);
        if ($res == TRUE) {
            $udata = array("aid" => $res->aid, 'admin' => $res->name);
            $this->session->set_userdata($udata);
            $this->dashboard();
        } else {
            $this->session->set_flashdata('login_fail', 'Incorrect email or password ');
            redirect(base_url('admin/_Admin/index'));
        }
    }

    public function logout() {
        session_destroy();
        $this->index();
    }

    public function Io() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/offers/Io');
        } else {
            $this->index();
        }
    }

    public function No() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/offers/No');
        } else {
            $this->index();
        }
    }

    public function So() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/offers/So');
        } else {
            $this->index();
        }
    }

    public function Doo() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/offers/Dist');
        } else {
            $this->index();
        }
    }

    public function add_inter_person() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/auth_persons/add_international_person');
        } else {
            $this->index();
        }
    }

    public function add_nation_person() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/auth_persons/add_national_person');
        } else {
            $this->index();
        }
    }

    public function add_state_person() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/auth_persons/add_state_person');
        } else {
            $this->index();
        }
    }

    public function add_dist_person() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/auth_persons/add_dist_person');
        } else {
            $this->index();
        }
    }

    public function add_home_banner_text($type) {
        if (!empty($_SESSION['aid'])) {
            $data['type'] = $type;
            $data['banner'] = $this->Admin_model->get_banner($type);
            $this->load->view('admin/header');
            $this->load->view('admin/banners/banner', $data);
        } else {
            $this->index();
        }
    }

    public function add_inter_banner_text($type) {
        if (!empty($_SESSION['aid'])) {
            $data['type'] = $type;
            $data['banner'] = $this->Admin_model->get_banner($type);
            $this->load->view('admin/header');
            $this->load->view('admin/banners/banner', $data);
        } else {
            $this->index();
        }
    }

    public function add_nat_banner_text($type) {
        if (!empty($_SESSION['aid'])) {
            $data['type'] = $type;
            $data['banner'] = $this->Admin_model->get_banner($type);
            $this->load->view('admin/header');
            $this->load->view('admin/banners/banner', $data);
        } else {
            $this->index();
        }
    }

    public function add_sta_banner_text($type) {
        if (!empty($_SESSION['aid'])) {
            $data['type'] = $type;
            $data['banner'] = $this->Admin_model->get_banner($type);
            $this->load->view('admin/header');
            $this->load->view('admin/banners/banner', $data);
        } else {
            $this->index();
        }
    }

    public function add_dist_banner_text($type) {
        if (!empty($_SESSION['aid'])) {
            $data['type'] = $type;
            $data['banner'] = $this->Admin_model->get_banner($type);
            $this->load->view('admin/header');
            $this->load->view('admin/banners/banner', $data);
        } else {
            $this->index();
        }
    }

    public function add_legality_banner_text($type) {
        if (!empty($_SESSION['aid'])) {
            $data['type'] = $type;
            $data['banner'] = $this->Admin_model->get_banner($type);
            $this->load->view('admin/header');
            $this->load->view('admin/banners/banner', $data);
        } else {
            $this->index();
        }
    }

    public function add_offer_banner_text($type) {
        if (!empty($_SESSION['aid'])) {
            $data['type'] = $type;
            $data['banner'] = $this->Admin_model->get_banner($type);
            $this->load->view('admin/header');
            $this->load->view('admin/banners/banner', $data);
        } else {
            $this->index();
        }
    }

    public function add_gallery_banner_text($type) {
        if (!empty($_SESSION['aid'])) {
            $data['type'] = $type;
            $data['banner'] = $this->Admin_model->get_banner($type);
            $this->load->view('admin/header');
            $this->load->view('admin/banners/banner', $data);
        } else {
            $this->index();
        }
    }

    public function add_emailservice_banner_text($type) {
        if (!empty($_SESSION['aid'])) {
            $data['type'] = $type;
            $data['banner'] = $this->Admin_model->get_banner($type);
            $this->load->view('admin/header');
            $this->load->view('admin/banners/banner', $data);
        } else {
            $this->index();
        }
    }

    public function add_country_banner_text() {
        if (!empty($_SESSION['aid'])) {

            $this->load->view('admin/header');
            $this->load->view('admin/banners/unique/country_banner');
        } else {
            $this->index();
        }
    }

    public function add_state_banner_text() {
        if (!empty($_SESSION['aid'])) {

            $this->load->view('admin/header');
            $this->load->view('admin/banners/unique/unq_state_banner');
        } else {
            $this->index();
        }
    }

    public function add_district_banner_text() {
        if (!empty($_SESSION['aid'])) {

            $this->load->view('admin/header');
            $this->load->view('admin/banners/unique/unq_district_banner');
        } else {
            $this->index();
        }
    }

    public function manage_country_banner_text() {
        if (!empty($_SESSION['aid'])) {

            $this->load->view('admin/header');
            $this->load->view('admin/banners/manage/manage_country_banner');
        } else {
            $this->index();
        }
    }

    public function manage_state_banner_text() {
        if (!empty($_SESSION['aid'])) {

            $this->load->view('admin/header');
            $this->load->view('admin/banners/manage/manage_state_banner');
        } else {
            $this->index();
        }
    }

    public function manage_district_banner_text() {
        if (!empty($_SESSION['aid'])) {

            $this->load->view('admin/header');
            $this->load->view('admin/banners/manage/manage_district_banner');
        } else {
            $this->index();
        }
    }

    public function add_international_types() {
        if (!empty($_SESSION['aid'])) {
            $data['types'] = $this->Admin_model->get_all_in_types();
            $data['type'] = 'International';
            $this->load->view('admin/header');
            $this->load->view('admin/types/international_type', $data);
        } else {
            $this->index();
        }
    }

    public function add_national_types() {
        if (!empty($_SESSION['aid'])) {
            $data['types'] = $this->Admin_model->get_all_nat_types();
            $data['type'] = 'National';
            $this->load->view('admin/header');
            $this->load->view('admin/types/national_type', $data);
        } else {
            $this->index();
        }
    }

    public function add_state_types() {
        if (!empty($_SESSION['aid'])) {
            $data['types'] = $this->Admin_model->get_all_auth_types();
            $data['type'] = 'State';
            $this->load->view('admin/header');
            $this->load->view('admin/types/state_type', $data);
        } else {
            $this->index();
        }
    }

    public function add_district_types() {
        if (!empty($_SESSION['aid'])) {
            $data['types'] = $this->Admin_model->get_all_auth_types();
            $data['type'] = 'District';
            $this->load->view('admin/header');
            $this->load->view('admin/types/district_type', $data);
        } else {
            $this->index();
        }
    }

    public function add_legality() {
        if (!empty($_SESSION['aid'])) {
            $data['legality'] = $this->Admin_model->get_legality_text();
            $this->load->view('admin/header');
            $this->load->view('admin/add_legality', $data);
        } else {
            $this->index();
        }
    }

    public function add_int_meeting_notifi($type) {
        if (!empty($_SESSION['aid'])) {
            $type = str_replace("_", " ", $type);
            $data['type'] = $type;
            $data['notification'] = $this->Admin_model->get_notification_text($type);
            $this->load->view('admin/header');
            $this->load->view('admin/notifications/add_notification', $data);
        } else {
            $this->index();
        }
    }

    public function add_nat_meeting_notifi($type) {
        if (!empty($_SESSION['aid'])) {
            $type = str_replace("_", " ", $type);
            $data['type'] = $type;
            $data['notification'] = $this->Admin_model->get_notification_text($type);
            $this->load->view('admin/header');
            $this->load->view('admin/notifications/add_notification', $data);
        } else {
            $this->index();
        }
    }

    public function add_state_meeting_notifi($type) {
        if (!empty($_SESSION['aid'])) {
            $type = str_replace("_", " ", $type);
            $data['type'] = $type;
            $data['notification'] = $this->Admin_model->get_notification_text($type);
            $this->load->view('admin/header');
            $this->load->view('admin/notifications/add_notification', $data);
        } else {
            $this->index();
        }
    }

    public function add_dist_meeting_notifi($type) {
        if (!empty($_SESSION['aid'])) {
            $type = str_replace("_", " ", $type);
            $data['type'] = $type;
            $data['notification'] = $this->Admin_model->get_notification_text($type);
            $this->load->view('admin/header');
            $this->load->view('admin/notifications/add_notification', $data);
        } else {
            $this->index();
        }
    }

    public function add_jobs_notifi($type) {
        if (!empty($_SESSION['aid'])) {
            $type = str_replace("_", " ", $type);
            $data['type'] = $type;
            $data['notification'] = $this->Admin_model->get_notification_text($type);
            $this->load->view('admin/header');
            $this->load->view('admin/notifications/add_notification', $data);
        } else {
            $this->index();
        }
    }

    public function add_events_notifi($type) {
        if (!empty($_SESSION['aid'])) {
            $type = str_replace("_", " ", $type);
            $data['type'] = $type;
            $data['notification'] = $this->Admin_model->get_notification_text($type);
            $this->load->view('admin/header');
            $this->load->view('admin/notifications/add_notification', $data);
        } else {
            $this->index();
        }
    }

    public function add_emergency_service_notifi($type) {
        if (!empty($_SESSION['aid'])) {
            $type = str_replace("_", " ", $type);
            $data['type'] = $type;
            $data['notification'] = $this->Admin_model->get_notification_text($type);
            $this->load->view('admin/header');
            $this->load->view('admin/notifications/add_notification', $data);
        } else {
            $this->index();
        }
    }

    public function add_emergency_meeting_notifi($type) {
        if (!empty($_SESSION['aid'])) {
            $type = str_replace("_", " ", $type);
            $data['type'] = $type;
            $data['notification'] = $this->Admin_model->get_notification_text($type);
            $this->load->view('admin/header');
            $this->load->view('admin/notifications/add_notification', $data);
        } else {
            $this->index();
        }
    }

    public function add_emergency_protocol_notifi($type) {
        if (!empty($_SESSION['aid'])) {
            $type = str_replace("_", " ", $type);
            $data['type'] = $type;
            $data['notification'] = $this->Admin_model->get_notification_text($type);
            $this->load->view('admin/header');
            $this->load->view('admin/notifications/add_notification', $data);
        } else {
            $this->index();
        }
    }

    public function international_brochure() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/brochures/inter_brochuer');
        } else {
            $this->index();
        }
    }

    public function national_brochure() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/brochures/national_brochuer');
        } else {
            $this->index();
        }
    }

    public function state_brochure() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/brochures/state_brochuer');
        } else {
            $this->index();
        }
    }

    public function district_brochure() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/brochures/district_brochuer');
        } else {
            $this->index();
        }
    }

    public function manage_brochures() {
        if (!empty($_SESSION['aid'])) {
            $data['brouchers'] = $this->Admin_model->get_all_brouchers();
            $this->load->view('admin/header');
            $this->load->view('admin/brochures/manage_brochures', $data);
        } else {
            $this->index();
        }
    }

    public function manage_international_persons($offset = 0) {
        if (!empty($_SESSION['aid'])) {
            // Config setup
            $num_rows = $this->Admin_model->get_all_inter_auth_persons();
            $config['base_url'] = base_url() . 'admin/_Admin/manage_international_persons';
            $config['total_rows'] = count($num_rows);
         
            $config['per_page'] = 7;
            //$config['uri_segment']       = 3;
            $config['num_links'] = 252;
            $config['use_page_numbers'] = FALSE;
            $config['first_tag_open'] = $config['last_tag_open'] = $config['next_tag_open'] = $config['prev_tag_open'] = $config['num_tag_open'] = '<li>';
            $config['first_tag_close'] = $config['last_tag_close'] = $config['next_tag_close'] = $config['prev_tag_close'] = $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = "<li><a href='javascript:void(0);'><b>";
            $config['cur_tag_close'] = "</b></a></li>";
            $this->pagination->initialize($config);
            $data['auth_persons'] = $this->Admin_model->getInternationalPersons($config['per_page'], $offset); // take record of the table
          //  print_r($data['auth_persons']);
            $this->load->view('admin/header');
              $this->load->view('admin/manage_auth_persons/manage_international_persons', $data);
        } else {
            $this->index();
        }
    }

    public function manage_national_persons($offset = 0) {
        if (!empty($_SESSION['aid'])) {
            // Config setup
            $num_rows = $this->Admin_model->get_all_national_auth_persons();
            $config['base_url'] = base_url() . 'admin/_Admin/manage_national_persons';
            $config['total_rows'] = count($num_rows);
            $config['per_page'] = 7;
            //$config['uri_segment']       = 3;
            $config['num_links'] = 252;
            $config['use_page_numbers'] = FALSE;
            $config['first_tag_open'] = $config['last_tag_open'] = $config['next_tag_open'] = $config['prev_tag_open'] = $config['num_tag_open'] = '<li>';
            $config['first_tag_close'] = $config['last_tag_close'] = $config['next_tag_close'] = $config['prev_tag_close'] = $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = "<li><a href='javascript:void(0);'><b>";
            $config['cur_tag_close'] = "</b></a></li>";
            $this->pagination->initialize($config);
            $data['auth_persons'] = $this->Admin_model->getNationalPersons($config['per_page'], $offset); // take record of the table
            $this->load->view('admin/header');
            $this->load->view('admin/manage_auth_persons/manage_national_persons', $data);
        } else {
            $this->index();
        }
    }

    public function manage_state_persons($offset = 0) {
        if (!empty($_SESSION['aid'])) {
            // Config setup
            $num_rows = $this->Admin_model->get_all_state_auth_persons();
            $config['base_url'] = base_url() . 'admin/_Admin/manage_state_persons';
            $config['total_rows'] = count($num_rows);
            $config['per_page'] = 7;
            //$config['uri_segment']       = 3;
            $config['num_links'] = 252;
            $config['use_page_numbers'] = FALSE;
            $config['first_tag_open'] = $config['last_tag_open'] = $config['next_tag_open'] = $config['prev_tag_open'] = $config['num_tag_open'] = '<li>';
            $config['first_tag_close'] = $config['last_tag_close'] = $config['next_tag_close'] = $config['prev_tag_close'] = $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = "<li><a href='javascript:void(0);'><b>";
            $config['cur_tag_close'] = "</b></a></li>";
            $this->pagination->initialize($config);
            $data['auth_persons'] = $this->Admin_model->getStatePersons($config['per_page'], $offset); // take record of the table
            $this->load->view('admin/header');
            $this->load->view('admin/manage_auth_persons/manage_state_persons', $data);
        } else {
            $this->index();
        }
    }

    public function manage_district_persons($offset = 0) {
        if (!empty($_SESSION['aid'])) {
            // Config setup
            $num_rows = $this->Admin_model->get_all_district_auth_persons();
            $config['base_url'] = base_url() . 'admin/_Admin/manage_district_persons';
            $config['total_rows'] = count($num_rows);
            $config['per_page'] = 7;
            //$config['uri_segment']       = 3;
            $config['num_links'] = 252;
            $config['use_page_numbers'] = FALSE;
            $config['first_tag_open'] = $config['last_tag_open'] = $config['next_tag_open'] = $config['prev_tag_open'] = $config['num_tag_open'] = '<li>';
            $config['first_tag_close'] = $config['last_tag_close'] = $config['next_tag_close'] = $config['prev_tag_close'] = $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = "<li><a href='javascript:void(0);'><b>";
            $config['cur_tag_close'] = "</b></a></li>";
            $this->pagination->initialize($config);
            $data['auth_persons'] = $this->Admin_model->getDistrictPersons($config['per_page'], $offset); // take record of the table
            $this->load->view('admin/header');
            $this->load->view('admin/manage_auth_persons/manage_dist_persons', $data);
        } else {
            $this->index();
        }
    }

    public function edit_auth_person($authid) {
        if (!empty($_SESSION['aid'])) {
            $data['auth_person'] = $this->Admin_model->get_uniq_auth_person($authid);
            // print_r($data['auth_person']);
            $this->load->view('admin/header');
            $this->load->view('admin/edit_auth_persons/edit_auth_persons', $data);
        } else {
            $this->index();
        }
    }

    public function manage_international_users() {
        if (!empty($_SESSION['aid'])) {
            $data['users'] = $this->Admin_model->get_all_inter_users();
            $this->load->view('admin/header');
            $this->load->view('admin/manage_users/international_users', $data);
        } else {
            $this->index();
        }
    }

    public function manage_national_users() {
        if (!empty($_SESSION['aid'])) {
            $data['users'] = $this->Admin_model->get_all_nat_users();
            $this->load->view('admin/header');
            $this->load->view('admin/manage_users/national_users', $data);
        } else {
            $this->index();
        }
    }

    public function manage_state_users() {
        if (!empty($_SESSION['aid'])) {
            $data['users'] = $this->Admin_model->get_all_state_users();
            $this->load->view('admin/header');
            $this->load->view('admin/manage_users/state_users', $data);
        } else {
            $this->index();
        }
    }
    
     public function manage_district_users() {
        if (!empty($_SESSION['aid'])) {
            $data['users'] = $this->Admin_model->get_all_dist_users();
            $this->load->view('admin/header');
            $this->load->view('admin/manage_users/district_users', $data);
        } else {
            $this->index();
        }
    }
    
     public function manage_finternational_users() {
        if (!empty($_SESSION['aid'])) {
            $data['users'] = $this->Admin_model->get_all_freeinter_users();
            $this->load->view('admin/header');
            $this->load->view('admin/manage_users/freeinternational_users', $data);
        } else {
            $this->index();
        }
    }
    
    public function manage_fnational_users() {
        if (!empty($_SESSION['aid'])) {
            $data['users'] = $this->Admin_model->get_all_freenat_users();
            $this->load->view('admin/header');
            $this->load->view('admin/manage_users/freenational_users', $data);
        } else {
            $this->index();
        }
    }
    
     public function manage_fstate_users() {
        if (!empty($_SESSION['aid'])) {
            $data['users'] = $this->Admin_model->get_all_freestate_users();
            $this->load->view('admin/header');
            $this->load->view('admin/manage_users/freestate_users', $data);
        } else {
            $this->index();
        }
    }
    
     public function manage_fdistrict_users() {
        if (!empty($_SESSION['aid'])) {
            $data['users'] = $this->Admin_model->get_all_freedist_users();
            $this->load->view('admin/header');
            $this->load->view('admin/manage_users/freedistrict_users', $data);
        } else {
            $this->index();
        }
    }

   

    public function free_international_users() {
        $session_data = array('type' => 'admin',
                              'reg_type' => 'free');
        $this->session->set_userdata($session_data);
        redirect(base_url('addfree_inter_users'));
    }

    public function free_national_users() {
        $session_data = array('type' => 'admin',
            'reg_type' => 'free');
        $this->session->set_userdata($session_data);
        redirect(base_url('addfree_nat_users'));
    }

    public function free_state_users() {
        $session_data = array('type' => 'admin',
            'reg_type' => 'free');
        $this->session->set_userdata($session_data);
        redirect(base_url('addfree_state_users'));
    }

    public function free_district_users() {
        $session_data = array('type' => 'admin',
            'reg_type' => 'free');
        $this->session->set_userdata($session_data);
        redirect(base_url('addfree_dist_users'));
    }

    public function add_gallery() {
        if (!empty($_SESSION['aid'])) {
            $this->load->view('admin/header');
            $this->load->view('admin/gallery/add_gallery');
        } else {
            $this->index();
        }
    }

    public function add_auth_persons() {
        $state = "";
        $name = $this->input->post('person_name');
        $type = $this->input->post('person_type');
        $jobtype = $this->input->post('person_jobtype');
        $mobile = $this->input->post('person_mobile');
        $description = $this->input->post('person_des');
        $desgn = $this->input->post('pers_desig');
        $postion = $this->input->post('pers_position');
        $country = $this->input->post('person_country');
        $state = $this->input->post('person_state');
        $district = $this->input->post('person_district');
        $file_path = './uploads/admin/persons/';
        if (!is_dir($file_path)) {
            mkdir($file_path, 0777, TRUE); //0777=>permision of the folder to be created.777=>widest possible acess
        }
        $totalpersons = '';
        $common = '';
        if ($type == 'International') {
            $totalpersons = $this->Admin_model->get_international_auth_persons($country);
            $common = $country;
        } elseif ($type == 'National') {
            
        } elseif ($type == 'State') {
            $totalpersons = $this->Admin_model->get_state_auth_persons($state);
            $common = $state;
        } elseif ($type == 'District') {
            $totalpersons = $this->Admin_model->get_dist_auth_persons($state);
            $stateid = $this->input->post('person_state_id');
            $statename = $this->Admin_model->get_state_name($stateid);   
            $state = $statename->name;
            $common = $district;
        }
        $count = count($totalpersons);
        if ($count == 7) {
            echo $country;
           
        } else {
            $config['upload_path'] = './uploads/admin/persons/';
            $config['allowed_types'] = 'jpg|png|jpeg';
            $config['max_size'] = '55097152';
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if (!$this->upload->do_upload('person_image')) {
                echo "<script>alert('Image Upload Error: " . $this->upload->display_errors() . "!')</script>";
                // exit;
            } else {
                $img_data = $this->upload->data();
                $img_path = 'uploads/admin/persons/' . $img_data['raw_name'] . $img_data['file_ext'];
                $res = $this->db->insert('auth_persons', array('auth_name' => $name, 'auth_jobtype' => $jobtype, 'auth_type' => $type, 'auth_country' => $country, 'auth_state' => $state, 'auth_district' => $district, 'auth_mobile' => $mobile, 'auth_desgination' => $desgn, 'auth_image' => $img_path, 'auth_description' => $description, 'auth_position' => $postion));
                if ($res) {
                     echo'submitted';
                }
            }
        }
    }

    public function edit_auth_persons() {
        $authid = $this->input->post('auth_id');
        $auth_person = $this->Admin_model->get_uniq_auth_person($authid);
        $country = $auth_person->auth_country;
        $state = $auth_person->auth_state;
        $district = $auth_person->auth_district;
        $name = $this->input->post('person_name');
        $type = $this->input->post('person_type');
        $jobtype = $this->input->post('person_jobtype');
        $mobile = $this->input->post('person_mobile');
        $desgn = $this->input->post('pers_desig');
        $description = $this->input->post('person_des');
        if (empty($desgn)) {
            $desgn = $auth_person->auth_desgination;
        }

        $auth = $this->input->post('auth_res');
        if ($auth == 'country') {
            $country = $this->input->post('auth_residence');
        } elseif ($auth == 'national') {
            $country = $this->input->post('auth_residence');
        } elseif ($auth == 'state') {
            $state = $this->input->post('auth_residence');
        } else {
            $district = $this->input->post('auth_residence');
        }



        $file_path = './uploads/admin/persons/';
        if (!is_dir($file_path)) {
            mkdir($file_path, 0777, TRUE); //0777=>permision of the folder to be created.777=>widest possible acess
        }

        // $filename = $_FILES['person_image']['name'];

        if (!empty($auth_person->auth_image) && empty($_FILES['person_image']['name'])) {
            $img_path = $auth_person->auth_image;
            $this->db->where('auth_id', $authid)->update('auth_persons', array('auth_image' => $img_path));
        } else {
            $config['upload_path'] = './uploads/admin/persons/';
            $config['allowed_types'] = 'jpg|png|jpeg';
            $config['max_size'] = '55097152';
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if (!$this->upload->do_upload('person_image')) {
                echo "<script>alert('Image Upload Error: " . $this->upload->display_errors() . "!')</script>";
                // exit;
            } else {
                $img_data = $this->upload->data();
                $img_path = 'uploads/admin/persons/' . $img_data['raw_name'] . $img_data['file_ext'];
                $this->db->where('auth_id', $authid)->update('auth_persons', array('auth_image' => $img_path));
            }
        }

        $res = $this->db->where('auth_id', $authid)->update('auth_persons', array('auth_name' => $name, 'auth_jobtype' => $jobtype, 'auth_type' => $type, 'auth_country' => $country, 'auth_state' => $state, 'auth_district' => $district, 'auth_mobile' => $mobile, 'auth_desgination' => $desgn, 'auth_description' => $description));
        if ($res) {

            echo 'submitted';
        }
    }

    public function delete_auth_person() {
        $authid = $this->input->post('authid');
        $res = $this->Admin_model->delete_auth_person($authid);
        if ($res) {
            echo 'deleted';
        } else {
            echo 'not_deleted';
        }
    }

    public function add_banners() {
        $data = array("bn_text" => $this->input->post('banner_text'),
            "bn_type" => $this->input->post('banner_type'),
            "bn_country" => $this->input->post('banner_country'),
            "bn_state" => $this->input->post('banner_state'),
            "bn_district" => $this->input->post('banner_district'));

        $chk_banner = $this->Admin_model->get_banner($this->input->post('banner_type'));
        if ($chk_banner) {
            $res = $this->Admin_model->update_banner($chk_banner->bn_id, $data);
            if ($res) {
                echo 'submitted';
            }
        } else {
            $res = $this->Admin_model->insert_banners($data);
            if ($res) {
                echo 'submitted';
            }
        }
    }

    public function add_unique_banners() {
        $type = $this->input->post('banner_type');
        $country = $this->input->post('banner_country');
        $state = $this->input->post('banner_state');
        $district = $this->input->post('banner_district');

        $data = array("bn_text" => $this->input->post('banner_text'),
            "bn_type" => $type,
            "bn_country" => $country,
            "bn_state" => $state,
            "bn_district" => $district);

        $chk_banner = '';

        if ($type == 'International') {
            $chk_banner = $this->Admin_model->get_international_banner_text($type, $country);
        } elseif ($type == 'State') {
            $chk_banner = $this->Admin_model->get_state_banner_text($type, $state);
        } else {
            $chk_banner = $this->Admin_model->get_dist_banner_text($type, $district);
        }


        if ($chk_banner) {
            $res = $this->Admin_model->update_banner($chk_banner->bn_id, $data);
            if ($res) {
                echo 'submitted';
            }
        } else {
            $res = $this->Admin_model->insert_banners($data);
            if ($res) {
                echo 'submitted';
            }
        }
    }

    public function manage_banners() {
        $type = $this->input->post('banner_type');
        $country = $this->input->post('banner_country');
        $state = $this->input->post('banner_state');
        $district = $this->input->post('banner_district');


        $chk_banner = '';

        if ($type == 'International') {
            $data['type'] = $type;
            $data['banner'] = $this->Admin_model->get_international_banner_text($type, $country);
            $this->load->view('admin/banners/manage/manage_banner_res', $data);
        } elseif ($type == 'State') {
            $data['type'] = $type;
            $data['banner'] = $this->Admin_model->get_state_banner_text($type, $state);
            $this->load->view('admin/banners/manage/manage_banner_res', $data);
        } else {
            $data['type'] = $type;
            $data['banner'] = $this->Admin_model->get_dist_banner_text($type, $district);
            $this->load->view('admin/banners/manage/manage_banner_res', $data);
        }
    }

    public function add_legality_text() {
        $data = array("legality_text" => $this->input->post('legality_text'),
            "admin_id" => $_SESSION['aid']);
        $chk = $this->Admin_model->get_legality_text();
        if ($chk) {
            $this->db->where('admin_id', $_SESSION['aid'])->update('legality', array('legality_text' => $this->input->post('legality_text')));
            echo 'submitted';
        } else {
            $res = $this->Admin_model->insert_legality_text($data);
            if ($res) {
                echo 'submitted';
            }
        }
    }

    public function add_notification_text() {
        $type = $this->input->post('notification_type');
        $data = array("admin_id" => $_SESSION['aid'],
            "notification_text" => $this->input->post('notification_text'),
            "type" =>$type ,
        );
        $chk = $this->Admin_model->get_notification_text($this->input->post('notification_type'));
        if ($chk) {
            $totalnumbers = array();//numbers array
            $totalemails = array();//emials array
            $ntype = $type.' '.'Notification';//conctantig type of notification for sending SMS
            $this->db->where('nid', $chk->nid)->update('notifications', array('notification_text' => $this->input->post('notification_text')));
            $allnumbers = $this->Ngos_model->get_all_indian_numbers();
            // print_r($allnumbers);
            foreach ($allnumbers as $n) {
                array_push($totalnumbers, '91' . $n->tru_pre_mobile1);//adding one by one numbers to array
            }
            // print_r($totalnumbers);
            if (!empty($totalnumbers)) {
                $totalnumbers = implode(',', $totalnumbers);//joing array elements with string ","
                $response = $this->Sms_model->SMS_blast_notification($totalnumbers,$ntype);//sending message to all ngos indian mobiles
                //print_r($response);
            } else {
                echo 'Indian Mobile Numbers Are Not There,SMS sendig is failed';
            }
            
            $allemails = $this->Ngos_model->get_all_primary_emails();
           // print_r($allemails);
             foreach ($allemails as $e) {
                array_push($totalemails,$e->tru_pre_email);//adding one by one emails to array
            }
           // print_r($totalemails);
    
             if (!empty($totalemails)) {    
                $totalemails = implode(',', $totalemails);//joing array elements with string ","
               // print_r($totalemails);
                $response = $this->Mail_model->EMAIL_blast_notification($totalemails,$ntype);//sending message to all ngos emails
                //print_r($response);
               
           
            } else {
                echo 'Emails are empty ,EMAIL sendig is failed';
            }
           
           

            echo 'submitted';
        } else {
            $res = $this->Admin_model->insert_notification_text($data);
            if ($res) {
                echo 'submitted';
            }
        }
    }

    public function add_types() {
        $type = $this->input->post('add_type');
        $type_options = $this->input->post('add_type_options');
        //print_r($type_options);
        $type_options = explode(',', $type_options);
        if ($type == 'International') {
            foreach ($type_options as $to) {
                $data = array('auth_type' => $to);
                $res = $this->Admin_model->add_inter_types($data);
            }
            echo 'submitted';
        } elseif ($type == 'National') {
            foreach ($type_options as $to) {
                $data = array('auth_type' => $to);
                $res = $this->Admin_model->add_nat_types($data);
            }
            echo 'submitted';
        } else {
            foreach ($type_options as $to) {
                $data = array('auth_type' => $to);
                $res = $this->Admin_model->add_auth_types($data);
            }
            echo 'submitted';
        }
    }

    public function edit_desig_type() {
        $id = $this->input->post('id');
        $text = $this->input->post('text');
        // echo $text;
        $type = $this->input->post('type');
        if ($type == 'International') {
            $res = $this->db->where('id', $id)->update('auth_inter_types', array('auth_type' => $text));
            if ($res) {
                echo 'edited';
            }
        } elseif ($type == 'National') {
            $res = $this->db->where('id', $id)->update('auth_national_types', array('auth_type' => $text));
            if ($res) {
                echo 'edited';
            }
        } else {
            $res = $this->db->where('id', $id)->update('auth_person_types', array('auth_type' => $text));
            if ($res) {
                echo 'edited';
            }
        }
    }

    public function delete_type() {
        $id = $this->input->post('id');
        $type = $this->input->post('type');
        if ($type == 'International') {
            $res = $this->db->where('id', $id)->delete('auth_inter_types');
            if ($res) {
                echo 'deleted';
            }
        } elseif ($type == 'National') {
            $res = $this->db->where('id', $id)->delete('auth_national_types');
            if ($res) {
                echo 'deleted';
            }
        } else {
            $res = $this->db->where('id', $id)->delete('auth_person_types');
            if ($res) {
                echo 'deleted';
            }
        }
    }

    public function shadow_login($memberid) {
        $udetails = $this->Admin_model->get_all_details_ofuser($memberid);
        $session_data = array('memberid' => $udetails->member_id,
            'logged_in' => TRUE,
            'type' => 'admin');
        $this->session->set_userdata($session_data);
        redirect(base_url('account'));
    }

    public function delete_member_person() {
        $membid = $this->input->post('memid');
        $res = $this->Admin_model->delete_member_person($membid);
        if ($res == 'deleted') {
            echo 'deleted';
        } else {
            echo 'not_deleted';
        }
    }

    public function add_offers() {
        $offer_type = $this->input->post('offer_type');
        $description = $this->input->post('description');
        $total_offers = $this->Ngos_model->get_offers_details($offer_type);
        $count = count($total_offers);
        if ($count == 6) {
            echo 'count';
        } else {
            $file_path = './uploads/admin/offers/';
            if (!is_dir($file_path)) {
                mkdir($file_path, 0777, TRUE); //0777=>permision of the folder to be created.777=>widest possible acess
            }

            $file1 = $_FILES['offer_image']['name'];

            if (empty($file1) || empty($offer_type) || empty($description)) {
                echo 'submit_all';
            } else {
                $config['upload_path'] = './uploads/admin/offers/';
                $config['allowed_types'] = 'jpg|png|jpeg';
                $config['max_size'] = '55097152';
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                if (!$this->upload->do_upload('offer_image')) {
                    echo "<script>alert('Image Upload Error: " . $this->upload->display_errors() . "!')</script>";
                    // exit;
                } else {
                    $img_data = $this->upload->data();

                    $img_path = 'uploads/admin/offers/' . $img_data['raw_name'] . $img_data['file_ext'];
                    $res = $this->db->insert('offers', array('off_type' => $offer_type, 'off_desc' => $description, 'off_image' => $img_path));
                    if ($res) {

                        echo 'submitted';
                    }
                }
            }
        }
    }

    public function manage_international_offers($type) {
        if (!empty($_SESSION['aid'])) {
            $data['type'] = $type;
            $data['offers'] = $this->Ngos_model->get_offers_details($type);
            $this->load->view('admin/header');
            $this->load->view('admin/offers/manage_Io', $data);
        } else {
            $this->index();
        }
    }

    public function manage_national_offers($type) {
        if (!empty($_SESSION['aid'])) {
            $data['type'] = $type;
            $data['offers'] = $this->Ngos_model->get_offers_details($type);
            $this->load->view('admin/header');
            $this->load->view('admin/offers/manage_No', $data);
        } else {
            $this->index();
        }
    }

    public function manage_state_offers($type) {
        if (!empty($_SESSION['aid'])) {
            $data['type'] = $type;
            $data['offers'] = $this->Ngos_model->get_offers_details($type);
            $this->load->view('admin/header');
            $this->load->view('admin/offers/manage_So', $data);
        } else {
            $this->index();
        }
    }

    public function manage_district_offers($type) {
        if (!empty($_SESSION['aid'])) {
            $data['type'] = $type;
            $data['offers'] = $this->Ngos_model->get_offers_details($type);
            $this->load->view('admin/header');
            $this->load->view('admin/offers/manage_Dist', $data);
        } else {
            $this->index();
        }
    }

    public function edit_offers($offerid) {
        if (!empty($_SESSION['aid'])) {
            $data['offer'] = $this->Ngos_model->get_uniqoffers_details($offerid);
            $this->load->view('admin/header');
            $this->load->view('admin/offers/edit_offer', $data);
        } else {
            $this->index();
        }
    }

    public function edit_offer_details() {
        $offerid = $this->input->post('offer_id');
        $offer_type = $this->input->post('offer_type');
        $description = $this->input->post('description');
        $offers = $this->Ngos_model->get_uniqoffers_details($offerid);
        $file_path = './uploads/admin/offers/';
        if (!is_dir($file_path)) {
            mkdir($file_path, 0777, TRUE); //0777=>permision of the folder to be created.777=>widest possible acess
        }

        if (!empty($offers->off_image) && empty($_FILES['offer_image']['name'])) {
            $img_path = $offers->off_image;
            $this->db->where('off_id', $offerid)->update('offers', array('off_image' => $img_path));
        } else {
            $config['upload_path'] = './uploads/admin/offers/';
            $config['allowed_types'] = 'jpg|png|jpeg';
            $config['max_size'] = '55097152';
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if (!$this->upload->do_upload('offer_image')) {
                echo "<script>alert('Image Upload Error: " . $this->upload->display_errors() . "!')</script>";
                // exit;
            } else {
                $img_data = $this->upload->data();

                $img_path = 'uploads/admin/offers/' . $img_data['raw_name'] . $img_data['file_ext'];
                $this->db->where('off_id', $offerid)->update('offers', array('off_image' => $img_path));
            }
        }

        $res = $this->db->where('off_id', $offerid)->update('offers', array('off_type' => $offer_type, 'off_desc' => $description));
        if ($res) {
            echo 'submitted';
        }
    }

    public function delete_offer() {
        $offerid = $this->input->post('offerid');
        $res = $this->Ngos_model->delete_offer($offerid);
        if ($res == 'deleted') {
            echo 'deleted';
        } else {
            echo 'not_deleted';
        }
    }

    public function add_brocuhers() {

        $brid = $this->input->post('broucher_id');
        $type = $this->input->post('brochuer_type');
        $data = array('type' => $type);

        $file_path = './uploads/admin/documents/';
        if (!is_dir($file_path)) {
            mkdir($file_path, 0777, TRUE);
        }
        $config['upload_path'] = './uploads/admin/documents/';
        $config['allowed_types'] = 'pdf';
        $config['max_size'] = '55097152';
        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        if (!$this->upload->do_upload('brochu_document')) {
            echo "<script>alert('Image Upload Error: " . $this->upload->display_errors() . "!')</script>";
            // exit;
        } else {
            $img_data = $this->upload->data();
            $img_path = 'uploads/admin/documents/' . $img_data['raw_name'] . $img_data['file_ext'];

            $data['br_document'] = $img_path;
            $brouchers = $this->Admin_model->get_uniqbrocuher_details($brid);
            if ($brouchers) {
                $this->db->where('br_id', $brouchers->br_id)->update('brouchers', array('br_document' => $img_path));
                echo 'submitted';
            } else {
                $res = $this->Admin_model->inser_broucher($data);
                if ($res) {
                    echo 'submitted';
                }
            }
        }
    }

    public function delete_broucher() {
        $brid = $this->input->post('brid');
        $res = $this->Admin_model->delete_broucher($brid);
        if ($res) {
            echo 'deleted';
        } else {
            echo 'not_deleted';
        }
    }

}
