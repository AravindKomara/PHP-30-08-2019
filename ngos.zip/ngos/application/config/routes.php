<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Ngos';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

//Ngos
$route['home'] = "Ngos/home";
$route['login'] = "Ngos/login";
$route['legality'] = "Ngos/legality";
$route['offers'] = "Ngos/offers";
$route['gallery'] = "Ngos/gallery";
$route['emailservice'] = "Ngos/emailservice";
$route['registration/(:any)'] = "Ngos/show_registration_page/$1";
$route['your_offers/(:any)'] = "Ngos/show_offers_page/$1";
$route['profile'] = "Ngos/ngo_member_login";
$route['account'] = "Ngos/account_details";
$route['addfree_inter_users'] = 'Ngos/addfree_inter_users';
$route['addfree_nat_users'] = 'Ngos/addfree_nat_users';
$route['addfree_state_users'] = 'Ngos/addfree_state_users';
$route['addfree_dist_users'] = 'Ngos/addfree_dist_users';
$route['forgot_password'] = 'Ngos/forgot_password';
$route['update_password'] = 'Ngos/update_password';
$route['refral_bonus'] = 'Ngos/refral_bonus';
$route['change_password'] = 'Ngos/change_password';
$route['logout_user'] = "Ngos/logout_user";
$route['view_notification/(:any)'] = "Ngos/view_notification/$1";




//States
$route['districts'] = "States/districts";
$route['states'] = "States/states";
$route['international'] = "States/international";
$route['state_uniqngos/(:any)'] = "States/state_uniqngos/$1";
$route['district_uniqngos/(:any)'] = "States/district_uniqngos/$1";
$route['national_uniqngos/(:any)'] = "States/national_uniqngos/$1";
$route['international_uniqngos/(:any)'] = "States/international_uniqngos/$1";
$route['event_details/(:any)'] = 'States/event_details/$1';

//Payments
$route['payment'] = "Payments/payment";
$route['account_payment'] = "Payments/account_payment";

//Admin
$route['_adngo'] = "admin/_Admin/index";
$route['welcome'] = "admin/_Admin/admin_login";
$route['dashboard'] = "admin/_Admin/dashboard";
$route['logout'] = "admin/_Admin/logout";
$route['international_offers'] = 'admin/_Admin/Io';
$route['national_offers'] = 'admin/_Admin/No';
$route['state_offers'] = 'admin/_Admin/So';
$route['district_offers'] = 'admin/_Admin/Doo';
$route['add_international_persons'] = 'admin/_Admin/add_inter_person';
$route['add_national_persons'] = 'admin/_Admin/add_nation_person';
$route['add_state_persons'] = 'admin/_Admin/add_state_person';
$route['add_district_persons'] = 'admin/_Admin/add_dist_person';
$route['add_home_banner_text/(:any)'] = 'admin/_Admin/add_home_banner_text/$1';
$route['add_inter_banner_text/(:any)'] = 'admin/_Admin/add_inter_banner_text/$1';
$route['add_nat_banner_text/(:any)'] = 'admin/_Admin/add_nat_banner_text/$1';
$route['add_sta_banner_text/(:any)'] = 'admin/_Admin/add_sta_banner_text/$1';
$route['add_dist_banner_text/(:any)'] = 'admin/_Admin/add_dist_banner_text/$1';
$route['add_legality_banner_text/(:any)'] = 'admin/_Admin/add_legality_banner_text/$1';
$route['add_offer_banner_text/(:any)'] = 'admin/_Admin/add_offer_banner_text/$1';
$route['add_gallery_banner_text/(:any)'] = 'admin/_Admin/add_gallery_banner_text/$1';
$route['add_emailservice_banner_text/(:any)'] = 'admin/_Admin/add_emailservice_banner_text/$1';
$route['manage_international_persons'] = 'admin/_Admin/manage_international_persons';
$route['manage_national_persons'] = 'admin/_Admin/manage_national_persons';
$route['manage_state_persons'] = 'admin/_Admin/manage_state_persons';
$route['manage_district_persons'] = 'admin/_Admin/manage_district_persons';
$route['edit_auth_person/(:num)'] = 'admin/_Admin/edit_auth_person/$1';
$route['manage_international_users'] = 'admin/_Admin/manage_international_users';
$route['manage_national_users'] = 'admin/_Admin/manage_national_users';
$route['manage_state_users'] = 'admin/_Admin/manage_state_users';
$route['manage_district_users'] = 'admin/_Admin/manage_district_users';
$route['shadow_login/(:any)'] = "admin/_Admin/shadow_login/$1";
$route['add_legality'] = 'admin/_Admin/add_legality';
$route['free_international_users'] = 'admin/_Admin/free_international_users';
$route['free_national_users'] = 'admin/_Admin/free_national_users';
$route['free_state_users'] = 'admin/_Admin/free_state_users';
$route['free_district_users'] = 'admin/_Admin/free_district_users';
$route['add_international_types'] = 'admin/_Admin/add_international_types';
$route['add_national_types'] = 'admin/_Admin/add_national_types';
$route['add_state_types'] = 'admin/_Admin/add_state_types';
$route['add_district_types'] = 'admin/_Admin/add_district_types';
$route['add_gallery'] = 'admin/_Admin/add_gallery';
$route['manage_international_offers/(:any)'] = 'admin/_Admin/manage_international_offers/$1';
$route['manage_national_offers/(:any)'] = 'admin/_Admin/manage_national_offers/$1';
$route['manage_state_offers/(:any)'] = 'admin/_Admin/manage_state_offers/$1';
$route['manage_district_offers/(:any)'] = 'admin/_Admin/manage_district_offers/$1';
$route['edit_offers/(:num)'] =  'admin/_Admin/edit_offers/$1';
$route['add_country_banner_text'] = 'admin/_Admin/add_country_banner_text';
$route['add_state_banner_text'] = 'admin/_Admin/add_state_banner_text';
$route['add_district_banner_text'] = 'admin/_Admin/add_district_banner_text';
$route['manage_country_banner_text'] = 'admin/_Admin/manage_country_banner_text';
$route['manage_state_banner_text'] = 'admin/_Admin/manage_state_banner_text';
$route['manage_district_banner_text'] = 'admin/_Admin/manage_district_banner_text';
$route['international_brochure'] = 'admin/_Admin/international_brochure';
$route['national_brochure'] = 'admin/_Admin/national_brochure';
$route['state_brochure'] = 'admin/_Admin/state_brochure';
$route['district_brochure'] = 'admin/_Admin/district_brochure';
$route['manage_brochures'] = 'admin/_Admin/manage_brochures';
$route['add_int_meeting_notifi/(:any)'] = 'admin/_Admin/add_int_meeting_notifi/$1';
$route['add_nat_meeting_notifi/(:any)'] = 'admin/_Admin/add_nat_meeting_notifi/$1';
$route['add_state_meeting_notifi/(:any)'] = 'admin/_Admin/add_state_meeting_notifi/$1';
$route['add_dist_meeting_notifi/(:any)'] = 'admin/_Admin/add_dist_meeting_notifi/$1';
$route['add_jobs_notifi/(:any)'] = 'admin/_Admin/add_jobs_notifi/$1';
$route['add_events_notifi/(:any)'] = 'admin/_Admin/add_events_notifi/$1';
$route['add_emergency_service_notifi/(:any)'] = 'admin/_Admin/add_emergency_service_notifi/$1';
$route['add_emergency_meeting_notifi/(:any)'] = 'admin/_Admin/add_emergency_meeting_notifi/$1';
$route['add_emergency_protocol_notifi/(:any)'] = 'admin/_Admin/add_emergency_protocol_notifi/$1';
$route['manage_finternational_users'] = 'admin/_Admin/manage_finternational_users';
$route['manage_fnational_users'] = 'admin/_Admin/manage_fnational_users';
$route['manage_fstate_users'] = 'admin/_Admin/manage_state_fusers';
$route['manage_fdistrict_users'] = 'admin/_Admin/manage_fdistrict_users';


//Admin_search
$route['enquiry_moderations'] = "admin/Admin_search/enquiry_moderations";
$route['pending_referal_moderations'] = "admin/Admin_search/pending_referal_moderations";
$route['approved_referal_moderations'] = "admin/Admin_search/approved_referal_moderations";
$route['rejected_referal_moderations'] = "admin/Admin_search/rejected_referal_moderations";
$route['manage_gallery'] = 'admin/Admin_search/manage_gallery';
$route['edit_gallery/(:any)'] = 'admin/Admin_search/edit_gallery/$1';
$route['add_exams'] = 'admin/Admin_search/add_exams';
$route['view_exams'] = 'admin/Admin_search/view_exams';
$route['edit_exam_details/(:any)'] = 'admin/Admin_search/edit_exam_details/$1';
$route['exam_questions/(:any)'] = 'admin/Admin_search/exam_questions/$1';
$route['viewexam_questions/(:any)/(:any)'] = 'admin/Admin_search/viewexam_questions/$1/$2';

//Exam
$route['exam_registration'] = 'Exam/exam_registration';
$route['exam_login'] = 'Exam/exam_login';
$route['verify_user_details'] = 'Exam/verify_user_details';
$route['show_exam'] = 'Exam/show_exam';
$route['questions'] = 'Exam/start_exam';









