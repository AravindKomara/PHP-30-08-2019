$("#filterordr").on('submit',(function(e){
        e.preventDefault();
       // alert();
        $.ajax({
           url:"<?=base_url('User/filter_order')?>",
           type:"POST",
           data:new FormData(this),
           cache:false,
           contentType:false,
           processData:false,
           success:function(response){
               $(".filter_resp").html(response);
           }
        });
    }));
    
    $("#orderdropwown").on('change',(function(e){
         e.preventDefault();
         //alert();
         var value = $(this).val();
         $("#orderdropwownvalue").val();
        // alert(value);
    }));