
<?php
class User_model extends CI_Model {
       function __construct(){
        parent::__construct();
		
    }
    
      public function apicall($url, $param, $header, $method) {
         // echo'hello';exit;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        if ($param != "") {
           // echo $param;exit;
            curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
        }
        if ($method == "post") {
            curl_setopt($ch, CURLOPT_POST, true);
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        $resultcurl = curl_exec($ch);
        //print_r($resultcurl);exit;
        curl_close($ch);
        return $resultcurl;
    }

}