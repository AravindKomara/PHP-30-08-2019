<style>
hr {
    border: none;
    height: 1px;
    /* Set the hr color */
    color: #333; /* old IE */
    background-color: #333; /* Modern Browsers */
}
</style>
<?php
$date=date('Y-m-d H:i:s');
$date1=date('Y-m-d');

?> 
<div class="row" style="margin-top:10px;">		
	<div class="col-md-12" style="margin-top:10px;">
		<div class="col-md-12 no-padding-lft-rft custom-tab-nav" style="background:#ebf6f8; border-left: 1px solid #ddd; border-top: 1px solid #ddd;border-right: 1px solid #ddd; padding-top: 2px;">
			<form name="filterordr" method="post" action="<?php echo base_url(); ?>user/approverequests">
			<div class="col-md-12 no-padding-lft-rft">
			<div class="col-md-4">
                            <input type="hidden" name="searchdropdown" value="1" id="orderdropwownvalue">
				<div class="col-md-6 no-padding-lft-rft">
					<select size="1" name="search_type" id="orderdropwown" class="btn dropdown-toggle select_search_value form-control pull-left" aria-controls="example" id="filter_type" style="background-color: #7BAE4D; color: #FFFFFF;height:33px;">					
						<option value="1" <?php if($search_type==1){echo "selected";}?>>Order #</option>
						<option value="2" <?php if($search_type==2){echo "selected";}?>>WO #</option>
						<!--option value="3" <?php if($search_type==3){echo "selected";}?>>Name</option-->
<!--						<option value="4" <?php if($search_type==4){echo "selected";}?>>Assigned To</option>-->
						<option value="5" <?php if($search_type==5){echo "selected";}?>>MRN</option>
					</select>	
				</div>					
				<div class="col-md-6 no-padding-lft-rft">
					<input class="searchauto-input form-control" name="searchtext" value="" style="margin-top: 3px;height:28px;" id="ordertext"  type="text" autocomplete="off" placeholder="Search Text">
				</div>
			</div>
				
				<div class="col-md-3 pull-left">
					<span class="col-md-3 no-padding-lft-rft" style="margin-top:5px;">From: </span>
					<div class="col-md-9 input-group">
						<input class="searchauto-input form-control" value="<?php echo $from_dt;?>" id="fromdate" name="fromdate" type="text" autocomplete="off" placeholder="Start Date">
						<span class="input-group-addon sa-bordnone datepick">
						<span class="glyphicon glyphicon-calendar"></span>
						</span>
					</div>
				</div>					
				<div class="col-md-3 pull-left">
					<span class="col-md-3 no-padding-lft-rft" style="margin-top:5px;">To: </span>
					<div class="col-md-9 input-group">
						<input class="searchauto-input form-control" value="<?php echo $to_dt;?>" id="todate" name="todate" type="text" autocomplete="off" placeholder="End Date">
						<span class="input-group-addon sa-bordnone datepick">
						<span class="glyphicon glyphicon-calendar"></span>
						</span>
					</div>
				</div>
				<div class="col-md-2">
				<button class="btn btn-primary form-control" type="submit" id="btn_view_filters"><i class="icon-search icon-white"></i>&nbsp;<span class=" visible-desktop">Search</span></button>
				</div>
				
			</div>
		</form>
		</div>
		<div class="col-md-12 no-padding-lft-rgt orderlist scroll" id="JS_main_content_scroll" style="border:1px solid #ddd;overflow: auto;">
			<ul class="nav navbar-nav symptoms " style="padding-top:10px; width:100%;">
				<li class="col-md-12 active" style="padding:10px;">
					<table class="table  table-hover table-responsive" id="">
					<thead>					
					 <tr>
						<th>Skill Name</th>
						<th>Officer Name</th>
						<th>Start Time</th>
						<th>End Time</th>
						<th>Duration</th>
						<th>Requested Date</th>
                                                <th>Actions</th>
					 </tr>						
					</thead>
					<tbody>	
					</tbody>
						<?php
                                               // print_r($officers);exit;
						if(!empty($officers) && $officers->status==1){
							foreach($officers->data as $officer)
							{
								echo "<tr>";
	                            echo "<td>".$officer->skill_name."</td>";
	                            echo "<td>".$officer->officer_name."</td>";
	                            echo "<td>".$officer->start_time."</td>";
	                            echo "<td>".$officer->end_time."</td>";
	                            echo "<td>".$officer->duration."</td>";
	                            echo "<td>".$officer->requested_date."</td>";
	                            echo "<td><button class='btn btn-success' onclick='request_type(\"".$officer->slot_availability_id."\",\"accept\")'>Accept Request</button></td>";
	                            echo "<td><button class='btn btn-danger' onclick='request_type(\"".$officer->slot_availability_id."\",\"reject\")'>Reject Request</button></td>";
								echo "</tr>";
								
							}
                                                }else{
                                                    echo "<tr align='center'><td colspan='10' style='color:red;font-size:25px;'>No Data Found </td></tr>";
                                                }
						?>
					</table>
				</li>
			</ul>
		</div>					
	</div>			
</div>	

