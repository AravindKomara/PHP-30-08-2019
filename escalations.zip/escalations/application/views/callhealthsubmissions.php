<style>
    hr {
        border: none;
        height: 1px;
        /* Set the hr color */
        color: #333; /* old IE */
        background-color: #333; /* Modern Browsers */
    }
    .no-padding-lft-rft { 
        margin-right:10px;
    }
</style>
<?php
$date = date('Y-m-d H:i:s');
$date1 = date('Y-m-d');
//echo $recipt_search_type;exit;
?>
<div class="row" style="margin-top:10px;">		
    <div class="col-md-12" style="margin-top:10px;">
        <div class="col-md-12 no-padding-lft-rft custom-tab-nav" style="background:#ebf6f8; border-left: 1px solid #ddd; border-top: 1px solid #ddd;border-right: 1px solid #ddd; padding-top: 2px;">
            <form name="filterordr" method="post" action="<?php echo base_url(); ?>user/callhealthsubmissions">
                <div class="col-md-12 no-padding-lft-rft">
                    <div class="col-md-5">
                        <input type="hidden" name="searchdropdown" value="<?=$search_type?>" id="orderdropwownvalue">
                        <div class="col-md-3 no-padding-lft-rft">
                            <select size="1" name="search_type" id="orderdropwown" class="btn dropdown-toggle select_search_value form-control pull-left" aria-controls="example" id="filter_type" style="background-color: #7BAE4D; color: #FFFFFF;height:33px;">					
                                <option value="1" 
                                    <?php if ($search_type == 1) {
                                     echo "selected";
                                    } ?>>Order #</option>
                           </select>	
                        </div>					
                        <div class="col-md-5 no-padding-lft-rft">
                            <input class="searchauto-input form-control" type="text" name="searchtext" value="<?=$search_txt?>" style="margin-top: 3px;height:28px;" id="ordertext"  type="text" autocomplete="off" placeholder="Search Text">
                        </div>
                
                        <div class="col-md-3 no-padding-lft-rft">
                            <select size="1" name="recipt_search_dropwown" id="recipt_search_dropwown" class="btn dropdown-toggle select_search_value form-control pull-left" aria-controls="example" id="filter_type" style="background-color: #7BAE4D; color: #FFFFFF;height:33px;">					
								<option value="pending"
								<?php if ($recipt_search_type == "pending") {
                                    echo "selected";
                                    }  ?>>Pending #</option>
                                                                
                                                                <option value="completed"
								<?php if ($recipt_search_type == "completed") {
                                    echo "selected";
                                    }  ?>>Completed #</option>
								
                                        
                                        
                                        <?php //if ($sessiondata["type"] == "superadmin" || $sessiondata["type"] == "associate_admin") { ?>
									<!--<option value="completed"
                                    <?php// if ($recipt_search_type == "completed") {
                                   // echo "selected";
                                   // }  ?>>Completed #</option>-->
                                <?php //} ?>
                           </select>	
                        </div>	
                    </div>

                    <div class="col-md-5 pull-left">
                        <div class="col-md-6 pull-left">
                            
							<span class="col-md-2 no-padding-lft-rft" style="margin-top:5px;">From: </span>
							<div class="col-md-8 input-group">
								<input class="searchauto-input form-control" value="<?php echo $from_dt; ?>" id="fromdate" name="fromdate" type="text" autocomplete="off" placeholder="Start Date">
								<span class="input-group-addon sa-bordnone datepick">
									<span class="glyphicon glyphicon-calendar"></span>
								</span>
							</div>
						</div>					
						<div class="col-md-6 pull-left">
							<span class="col-md-2 no-padding-lft-rft" style="margin-top:5px;">To: </span>
							<div class="col-md-8 input-group">
								<input class="searchauto-input form-control" value="<?php echo $to_dt; ?>" id="todate" name="todate" type="text" autocomplete="off" placeholder="End Date">
								<span class="input-group-addon sa-bordnone datepick">
									<span class="glyphicon glyphicon-calendar"></span>
								</span>
							</div>
						</div>
                    </div>
                    <div class="col-md-1">
                        <button class="btn btn-primary form-control" type="submit" id="btn_view_filters"><i class="icon-search icon-white"></i>&nbsp;<span class=" visible-desktop">Search</span></button>
                    </div>
                    <?php
                  //  echo $recipt_search_type;
                    if($sessiondata["type"] == "associate_admin"){
                       // ?> <div class="col-md-1">
                        <a href="#" class="btn btn-warning form-control" type="submit" id="recipt_submit" onclick="reciptSubmit()"><i class="icon-search icon-white"></i>&nbsp;<span class=" visible-desktop">Submit</span></a>
                    </div>
                    <?php }
                    ?>
                   

                </div>
            </form>
        </div>
        <div class="col-md-12 no-padding-lft-rgt orderlist scroll" id="JS_main_content_scroll" style="border:1px solid #ddd;overflow: auto;">
            <ul class="nav navbar-nav symptoms " style="padding-top:10px; width:100%;">
                <li class="col-md-12 active" style="padding:10px;">
                    <table class="table  table-hover table-responsive" id="">
                        <thead>					
                            <tr>
                                <?php
                                if($recipt_search_type == "pending" && $sessiondata["type"] == "associate_admin"){
									//echo "<th>Select</th>";
                                    echo '<th><input type="checkbox" name="allorders_select" value="1" onclick="selectAll()">Select All</th>';
								}
                                ?>
                                
                                <th style="text-align:center;">Type</th>
                                <th style="text-align:center;">Order DID#</th>
                                <th style="text-align:center;">MRN#</th>
                                <th style="text-align:center;">Billing ID#</th>
                                <th style="text-align:center;">Receipt ID#</th>
								<th style="text-align:center;">Amount</th>
								<?php
                                if($recipt_search_type != "pending"){
									echo "<th>Transaction Code</th>";
								}
                                ?>								
                            </tr>						
                        </thead>
                        <tbody>	
                        </tbody>
                        <?php
                        if (isset($ordersList->count) && ($ordersList->count > 0)) {
                            foreach($ordersList->receipts as $recipt){
                               // print_r($recipt->billing->patientinfo->service_type);
                                  echo "<tr>";
                                  if($recipt_search_type == "pending" && $sessiondata["type"] == "associate_admin"){
                                       echo "<td><input type='checkbox' onclick='uniqueselectAll()' name='order_select' value=".$recipt->billing->receiptinfo->receipt_id ." data-receipt-amount = ".$recipt->billing->receiptinfo->receipt_amount."  data-receipt-order_did='".$recipt->billing->billinginfo->order_did."' name='recipt_checkbox' class=select_check_all'/></td>";
                                  }
                                  echo "<td style='text-align:center;'>" . $business_name[$recipt->billing->patientinfo->service_type] . "</td>";
                                  echo "<td style='text-align:center;'>" . $recipt->billing->billinginfo->order_did . "</td>";
                                  echo "<td style='text-align:center;'>" . $recipt->billing->patientinfo->mrn . "</td>";
                                  echo "<td style='text-align:center;'>" . $recipt->billing->billinginfo->billingid . "</td>";
                                  echo "<td style='text-align:center;'>" . $recipt->billing->receiptinfo->receipt_id . "</td>";
								  echo "<td style='text-align:center;'>" . $recipt->billing->receiptinfo->receipt_amount . "</td>";
								  if($recipt_search_type != "pending"){
                                      echo "<td style='text-align:center;'>".(isset($recipt->billing->receiptinfo->phelp_transaction_id)?$recipt->billing->receiptinfo->phelp_transaction_id:'')."</td>";
                                  }
								  
								  
                                  echo "</tr>";
                            }
                            
                        }else{
                            echo "<tr align='center'><td colspan='10' style='color:red;font-size:25px;'>No Data Found </td></tr>";
                        }
                      
                        ?>
                    </table>
                </li>
            </ul>
        </div>					
    </div>			
</div>	

