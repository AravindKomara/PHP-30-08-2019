


        <div class="modal-content">  
            <?php
            $total_amount = 0;
            if ($type == 'order_search') {
                ?> <div class="modal-header" style="background-color:#7bae4d; color:#fff;">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Order Details</h4>
                </div>
                <div class="modal-body" id="order_details_resp">
                    <?php
                    if ($ordersList) {
                        $patitent = $ordersList->data[0]->order;
                        ?>
                        <div class="table-responsive">
                            <table summary="" class="table table-bordered table-hover">
                                <caption class="text-center" style="font-size: 25px;">Patient Details</caption>
                                <thead style="background-color:#7bae4d; color:#fff;">
                                    <tr>
                                        <th style="text-align:center;">Name</th>
                                        <th style="text-align:center;">Gender</th>
                                        <th style="text-align:center;">Age</th>
                                        <th style="text-align:center;">MRN</th>
                                        <th style="text-align:center;">Order DID</th>
                                        <th style="text-align:center;">Ordered On</th>

                                    </tr>
                                </thead>
                                <tbody>

                                    <tr>
                                        <td><?php
                                            if (!empty($patitent->patientinfo->name)) {
                                                echo $patitent->patientinfo->name;
                                            } else {
                                                echo 'N/A';
                                            }
                                            ?></td> 
                                        <td><?php
                                            if (!empty($patitent->patientinfo->gender)) {
                                                echo $patitent->patientinfo->gender;
                                            } else {
                                                echo 'N/A';
                                            }
                                            ?></td> 
                                        <td><?php
                                            if (!empty($patitent->patientinfo->age)) {
                                                echo $patitent->patientinfo->age;
                                            } else {
                                                echo 'N/A';
                                            }
                                            ?></td> 
                                        <td><?php
                                            if (!empty($patitent->patientinfo->mrn)) {
                                                echo $patitent->patientinfo->mrn;
                                            } else {
                                                echo 'N/A';
                                            }
                                            ?></td> 
                                        <td><?php
                                            if (!empty($ordersList->data[0]->odid)) {
                                                echo $ordersList->data[0]->odid;
                                            } else {
                                                echo 'N/A';
                                            }
                                            ?> </td> 
                                        <td><?php
                                            if (!empty($patitent->patientinfo->scheduled_date)) {
                                                $schedule_date = str_replace('T', ' ', $patitent->patientinfo->scheduled_date);
                                                $schedule_date = substr($schedule_date, 0, -5);
                                                $schedule_date = explode(' ', $schedule_date);
                                                $month = explode('-', $schedule_date[0]);
                                                $monthname = date("F", mktime(0, 0, 0, $month[1], 10));
                                                echo $monthname . ' ' . $month[2] . ',' . $month[0] . ' ' . $schedule_date[1];
                                            } else {
                                                echo 'N/A';
                                            }
                                            ?> </td> 
                                    </tr>


                                </tbody>

                            </table>
                        </div><!--end of .table-responsive-->

                        <div class="table-responsive">
                            <table summary="This table shows how to create responsive tables using Bootstrap's default functionality" class="table table-bordered table-hover">
                                <caption class="text-center" style="font-size: 25px;">Line Items</caption>
                                <thead style="background-color:#7bae4d; color:#fff;">
                                    <tr>
                                        <th style="text-align:center;">#</th>
                                        <th style="text-align:center;">Test Name</th>
                                        <th style="text-align:center;">Doctor</th>
                                        <th style="text-align:center;">Quantity</th>
                                        <th style="text-align:center;">Scheduled Date/Time</th>
                                        <th style="text-align:center;">Gross Amount</th>
                                        <th style="text-align:center;">Net Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $count = 0;
                                    foreach ($ordersList->data as $order) {
                                        $scheduledate = date_format(date_create($order->order->patientinfo->scheduled_date), "Y-m-d h:i a");
                                        foreach ($order->order->orderitem as $orderitems) {
                                            $count++;
                                            ?> <tr>
                                                <td style="text-align:center;"><?php
                                                    if (!empty($count)) {
                                                        echo $count;
                                                    } else {
                                                        'N/A';
                                                    }
                                                    ?></td>;
                                                <td style="text-align:center;"><?php
                                                    if (!empty($orderitems->itemname)) {
                                                        echo $orderitems->itemname;
                                                    } else {
                                                        'N/A';
                                                    }
                                                    ?></td>;

                                                <td style="text-align:center;"><?php
                                                    if (!empty($orderitems->doctor)) {
                                                        echo $orderitems->doctor;
                                                    } else {
                                                        'N/A';
                                                    }
                                                    ?></td>
                                                <td style="text-align:center;"><?php
                                                    if (!empty($orderitems->quantity)) {
                                                        echo $orderitems->quantity;
                                                    } else {
                                                        'N/A';
                                                    }
                                                    ?></td>

                                                <td style="text-align:center;"><?php
                                                    if (!empty($scheduledate)) {
                                                        echo $scheduledate;
                                                    } else {
                                                        'N/A';
                                                    }
                                                    ?></td>
                                                <td style="text-align:center;"><?php
                                                    if (!empty($orderitems->gross_amount)) {
                                                        echo $orderitems->gross_amount;
                                                    } else {
                                                        'N/A';
                                                    }
                                                    ?></td>	
                                                <td style="text-align:center;"><?php
                                                    if (!empty($orderitems->gross_amount)) {
                                                        echo $orderitems->net_amount;
                                                    } else {
                                                        'N/A';
                                                    }
                                                    ?></td>	


                                            </tr>

                                            <?php
                                            $final_amount = $orderitems->gross_amount + $orderitems->net_amount;
                                            $total_amount = $final_amount+$total_amount;
                                        }
                                    }
                                    ?>

                                </tbody>
                                <tfoot style="background-color:#7bae4d; color:#fff;">
                                    <tr>
                                        <td colspan="8" class="text-center" style="font-size:25px;">Total Amount (Inclusive Tax) <a href="" target="_blank"><?php echo $total_amount; ?>/-</a> </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div><!--end of .table-responsive-->


                    <?php }
                    ?>



                </div>


            <?php } elseif ($type == 're_allocate') {
                ?><div class="modal-header" style="background-color:#7bae4d; color:#fff;">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Re-Allocation</h4>
                </div>
                <div class="modal-body" id="order_details_resp">
                    <p>This is a large modal.</p>
                </div>
            <?php } elseif ($type == 'print_document') {
                ?><div class="modal-header" style="background-color:#7bae4d; color:#fff;">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Print Document</h4>
                </div>
                <div class="modal-body" id="order_details_resp">
                    <p>This is a large modal.</p>
                </div>
            <?php }
            ?>

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>


        </div>

<!--modal end-->