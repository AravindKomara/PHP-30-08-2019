<style>
.pn-ProductNav {
    /* Make this scrollable when needed */
    overflow-x: auto;
    /* We don't want vertical scrolling */
    overflow-y: hidden;
    /* Make an auto-hiding scroller for the 3 people using a IE */
    -ms-overflow-style: -ms-autohiding-scrollbar;
    /* For WebKit implementations, provide inertia scrolling */
    -webkit-overflow-scrolling: touch;
    /* We don't want internal inline elements to wrap */
    white-space: nowrap;
    /* Remove the default scrollbar for WebKit implementations */
    &::-webkit-scrollbar {
        display: none;
    }
}
</style>
<div class="col-md-12">
   <div class="container-fluid push-bot">
      <div class="row">
        <div class="col-md-12">		
            <nav class="navbar navbar-default pn-ProductNav"> 
	       <div class="navbar-header">
		   <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
		     <span class="sr-only">Toggle navigation</span>
		     <span class="icon-bar"></span>
		     <span class="icon-bar"></span>
		     <span class="icon-bar"></span>
		 </button>     
	       </div>  
	        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <ul>
                      <li>
                          <button <?php echo (in_array('pending',$menuList) === false) ? 'style="display : none;"' : ''; ?> class="<?php if($menu=="pending"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>user/pending'">Pending Orders</button>								
		      </li>
                        
		      <li>
                          <button <?php echo (in_array('reallocate',$menuList) === false) ? 'style="display : none;"' : ''; ?> class="<?php if($menu=="reallocate"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>user/reallocate'">Reallocation</button>
		      </li>
		
		      <li>
                          <button <?php echo (in_array('tobeassigned',$menuList) === false) ? 'style="display : none;"' : ''; ?> class="<?php if($menu=="tobeassigned"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>user/tobeassigned'">To Be Assigned</button>
                      </li>
		
		      <li>
                          <button <?php echo (in_array('completed',$menuList) === false) ? 'style="display : none;"' : ''; ?> class="<?php if($menu=="completed"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>user/completed'">Completed Orders</button>				
		      </li>
                        
		      <li>
                          <button <?php echo (in_array('printdocument',$menuList) === false) ? 'style="display : none;"' : ''; ?> class="<?php if($menu=="printdocument"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>user/printdocument'">Print Document</button>
		      </li>
                        
                      <li>
                        <button <?php echo (in_array('tobeconfirm',$menuList) === false) ? 'style="display : none;"' : ''; ?> class="<?php if($menu=="tobeconfirm"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>user/tobeconfirm'">To Be Confirm</button>
                      </li>
                
		      <li>
                         <button <?php echo (in_array('approverequests',$menuList) === false) ? 'style="display : none;"' : ''; ?> class="<?php if($menu=="approverequests"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>user/approverequests'">Approve Requests</button>
		      </li>
                        
		      <li>
                         <button <?php echo (in_array('paymentcollections',$menuList) === false) ? 'style="display : none;"' : ''; ?> class="<?php if($menu=="paymentcollections"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>user/paymentcollections'">Payment Collections</button>
		      </li>
                        
                      <li>
                          <button <?php echo (in_array('callhealthsubmissions',$menuList) === false) ? 'style="display : none;"' : ''; ?> class="<?php if($menu=="callhealthsubmissions"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>user/callhealthsubmissions'">CH Submissions</button>	
		      </li>
                      
                      <li>
                         <button <?php echo (in_array('reports',$menuList) === false) ? 'style="display : none;"' : ''; ?> class="<?php if($menu=="reports"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>user/reports'">Reports</button>
		      </li>
                    
                      <li>
                        <button <?php echo (in_array('sample_collections',$menuList) === false) ? 'style="display : none;"' : ''; ?> class="<?php if($menu=="sample_collections"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>user/sample_collections'">Sample Collections</button>
                      </li> 
                      
                      <li>
                        <button <?php echo (in_array('sample_submissions',$menuList) === false) ? 'style="display : none;"' : ''; ?> class="<?php if($menu=="sample_submissions"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>user/sample_submissions'">Sample Submissions</button>
                      </li> 
                      
                      <li>
                        <button <?php echo (in_array('refunds',$menuList) === false) ? 'style="display : none"' : ''; ?> class="<?php if($menu=="refunds"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>user/refunds'">Refunds</button>
                      </li>
                      <li>
                        <button <?php echo (in_array('thirdparty_collections',$menuList) === false) ? 'style="display : none"' : ''; ?> class="<?php if($menu=="thirdparty_collections"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>user/thirdparty_collections'">ThirdParty Collections</button>
                      </li>
                          
		  </ul>
	     </div>  
        </nav>
   </div>	
</div>
</div>