<style>
    hr {
        border: none;
        height: 1px;
        /* Set the hr color */
        color: #333; /* old IE */
        background-color: #333; /* Modern Browsers */
    }
    .no-padding-lft-rft { 
        margin-right:10px;
    }
</style>
<?php
$date = date('Y-m-d H:i:s');
$date1 = date('Y-m-d');
?>
<div class="row" style="margin-top:10px;">		
    <div class="col-md-12" style="margin-top:10px;">
        <div class="col-md-12 no-padding-lft-rft custom-tab-nav" style="background:#ebf6f8; border-left: 1px solid #ddd; border-top: 1px solid #ddd;border-right: 1px solid #ddd; padding-top: 2px;">
            <form name="filterordr" method="post" action="<?php echo base_url(); ?>user/refunds">
                <div class="col-md-12 no-padding-lft-rft">
                    <div class="col-md-4">
                        <input type="hidden" name="searchdropdown" value="<?= $search_type ?>" id="orderdropwownvalue">
                        <div class="col-md-4 no-padding-lft-rft">
                            <select size="1" name="search_type" id="orderdropwown" class="btn dropdown-toggle select_search_value form-control pull-left" aria-controls="example" id="filter_type" style="background-color: #7BAE4D; color: #FFFFFF;height:33px;">					
                                <option value="1" 
                                <?php
                                if ($search_type == 1) {
                                    echo "selected";
                                }
                                ?>>Order #</option>
                                <option value="5" 
                                        <?php
                                        if ($search_type == 5) {
                                            echo "selected";
                                        }
                                        ?>>MRN #</option>
                            </select>	
                        </div>					
                        <div class="col-md-4 no-padding-lft-rft">
                            <input class="searchauto-input form-control" type="text" name="searchtext" value="<?=$search_txt?>" style="margin-top: 3px;height:28px;" id="ordertext"  type="text" autocomplete="off" placeholder="Search Text">
                        </div>

                        <input type="hidden" name="refund_search_dropwown" value="" id="refund_search_dropwown_value">
                        <div class="col-md-3 no-padding-lft-rft">
                            <select size="1" name="search_type" id="refund_search_dropwown" class="btn dropdown-toggle select_search_value form-control pull-left" aria-controls="example" id="filter_type" style="background-color: #7BAE4D; color: #FFFFFF;height:33px;">					
                                <option value="1"
                                        <?php
                                        if ($refund_search_type == 1) {
                                            echo "selected";
                                        }
                                        ?>>INITIATED #</option>
                                 <option value="2"
                                        <?php
                                        if ($refund_search_type == 2) {
                                            echo "selected";
                                        }
                                        ?>>PROCESSING #</option>
                                  <option value="3"
                                        <?php
                                        if ($refund_search_type == 3) {
                                            echo "selected";
                                        }
                                        ?>>PROCESSED #</option>
                                <option value="4"
                                        <?php
                                        if ($refund_search_type == 4) {
                                            echo "selected";
                                        }
                                ?>>REJECTED #</option>
                              
                            </select>	
                        </div>	
                    </div>

                    <div class="col-md-3 pull-left">
                        <span class="col-md-3 no-padding-lft-rft" style="margin-top:5px;">From: </span>
                        <div class="col-md-6 input-group">
                            <input class="searchauto-input form-control" value="<?php echo $from_dt; ?>" id="fromdate" name="fromdate" type="text" autocomplete="off" placeholder="Start Date">
                            <span class="input-group-addon sa-bordnone datepick">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                    </div>					
                    <div class="col-md-3 pull-left">
                        <span class="col-md-3 no-padding-lft-rft" style="margin-top:5px;">To: </span>
                        <div class="col-md-6 input-group">
                            <input class="searchauto-input form-control" value="<?php echo $to_dt; ?>" id="todate" name="todate" type="text" autocomplete="off" placeholder="End Date">
                            <span class="input-group-addon sa-bordnone datepick">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-primary form-control" type="submit" id="btn_view_filters"><i class="icon-search icon-white"></i>&nbsp;<span class=" visible-desktop">Search</span></button>
                    </div> 

                </div>
            </form>
        </div>
        <div class="col-md-12 no-padding-lft-rgt orderlist scroll" id="JS_main_content_scroll" style="border:1px solid #ddd;overflow: auto;">
            <ul class="nav navbar-nav symptoms " style="padding-top:10px; width:100%;">
                <li class="col-md-12 active" style="padding:10px;">
                    <table class="table  table-hover table-responsive" id="">
                        <thead>					
                            <tr>
                                <th style="text-align:center;">Type</th>
                                <th style="text-align:center;">Order DID#</th>
                                <th style="text-align:center;">Check Receipts#</th>
                                <th style="text-align:center;">MRN</th>
                                <th style="text-align:center;">Amount</th>
                                <th style="text-align:center;">Name</th>
                                <th style="text-align:center;">Status</th>
                                <th style="text-align:center;">Actions</th>

                        </tr>						
                        </thead>
                        <tbody>	    
                        </tbody>
                        <?php
                        if (isset($ordersList) && $ordersList->countn > 0) {
                             //print_r($ordersList);exit;
                            foreach ($ordersList->data as $order) {   
                                $status = (string) $order->status;
                                $type = "";
                                if($order->action_level == 1){
                                  $type = "ORDER_LEVEL";  
                                }else{
                                   $type = "ITEM_LEVEL"; 
                                }
                               
                                $reason = isset($order->reason)?$order->reason:"";
                                echo "<tr>";
                                echo "<td style='text-align:center;'>" . $type . "</td>";
                                echo "<td style='text-align:center;'>" . $order->odid . "</td>";
                                echo "<td style='text-align:center;'><button class='btn btn-success btn-sm' onclick='refundOrder_recipts(\"" . $order->order_id . "\")' name='btnAdd' class='span1'>Check Receipts</button></td>";
                                echo "<td style='text-align:center;'>" . $order->mrn . "</td>";
                                echo "<td style='text-align:center;'>" . $order->amount . "</td>";
                                echo "<td style='text-align:center;'>" . $order->username . "</td>";
                                echo "<td style='text-align:center;'>" . $refund_status[$status] . "</td>";
                                if($order->status == 1){
                                    echo "<td style='text-align:center;'><button class='btn btn-success btn-sm' onclick='update_refundOrderStatus(\"" . $order->_id->{'$id'} . "\",\"" . $order->order_id . "\",\"" . $order->transaction_code . "\",\"" . $order->amount . "\",\"" . $order->type . "\",\"" . $reason . "\",\"2\")' name='btnAdd' class='span1'>Begin Processing</button></td>";
                                    echo "<td style='text-align:center;'><button class='btn btn-danger btn-sm'  onclick='update_refundOrderStatus(\"" . $order->_id->{'$id'} . "\",\"" . $order->order_id . "\",\"" . $order->transaction_code . "\",\"" . $order->amount . "\",\"" . $order->type . "\",\"" . $reason . "\",\"4\")' name='btnAdd' class='span1'>Reject</button></td>";
                                }else if($order->status == 2){
                                    echo "<td style='text-align:center;'><button class='btn btn-success btn-sm' onclick='update_refundOrderStatus(\"" . $order->_id->{'$id'} . "\",\"" . $order->order_id . "\",\"" . $order->transaction_code . "\",\"" . $order->amount . "\",\"" . $order->type . "\",\"" . $reason . "\",\"3\")' name='btnAdd' class='span1'>Complete Processing</button></td>";                       
                                }else{
                                    echo "<td style='text-align:center;'>N/A</td>";
                                }
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr align='center'><td colspan='10' style='color:red;font-size:25px;'>No Data Found </td></tr>";
                        }
                        ?>

                    </table>
                </li>
            </ul>
        </div>					
    </div>			
</div>	

