<style>
hr {
    border: none;
    height: 1px;
    /* Set the hr color */
    color: #333; /* old IE */
    background-color: #333; /* Modern Browsers */
}
</style>
<?php
$date=date('Y-m-d H:i:s');
$date1=date('Y-m-d');

?>
<div class="row" style="margin-top:10px;">		
	<div class="col-md-12" style="margin-top:10px;">
		<div class="col-md-12 no-padding-lft-rft custom-tab-nav" style="background:#ebf6f8; border-left: 1px solid #ddd; border-top: 1px solid #ddd;border-right: 1px solid #ddd; padding-top: 2px;">
			<form name="filterordr" method="post" action="<?php echo base_url(); ?>user/tobeconfirm">
			<div class="col-md-12 no-padding-lft-rft">
			<div class="col-md-4">	
                            <input type="hidden" name="searchdropdown" value="<?=$search_type?>" id="orderdropwownvalue">
				<div class="col-md-6 no-padding-lft-rft">
					<select size="1" name="search_type" id="orderdropwown" class="btn dropdown-toggle select_search_value form-control pull-left" aria-controls="example" id="filter_type" style="background-color: #7BAE4D; color: #FFFFFF;height:33px;">					
						<option value="1" <?php if($search_type==1){echo "selected";}?>>Order #</option>
						<option value="2" <?php if($search_type==2){echo "selected";}?>>WO #</option>
						<!--option value="3" <?php if($search_type==3){echo "selected";}?>>Name</option-->
<!--						<option value="4" <?php if($search_type==4){echo "selected";}?>>Assigned To</option>-->
						<option value="5" <?php if($search_type==5){echo "selected";}?>>MRN</option>
					</select>	
				</div>					
				<div class="col-md-6 no-padding-lft-rft">
					<input class="searchauto-input form-control" value="<?=$search_txt?>" style="margin-top: 3px;height:28px;" id="ordertext" name="searchtext" type="text" autocomplete="off" placeholder="Search Text">
				</div>
			</div>
				
			<div class="col-md-3 pull-left">
				<span class="col-md-3 no-padding-lft-rft" style="margin-top:5px;">From: </span>
				<div class="col-md-9 input-group">
					<input class="searchauto-input form-control" value="<?php echo $from_dt;?>" id="fromdate" name="fromdate" type="text" autocomplete="off" placeholder="Start Date">
					<span class="input-group-addon sa-bordnone datepick">
					<span class="glyphicon glyphicon-calendar"></span>
					</span>
				</div>
			</div>					
			<div class="col-md-3 pull-left">
				<span class="col-md-3 no-padding-lft-rft" style="margin-top:5px;">To: </span>
				<div class="col-md-9 input-group">
					<input class="searchauto-input form-control" value="<?php echo $to_dt;?>" id="todate" name="todate" type="text" autocomplete="off" placeholder="End Date">
					<span class="input-group-addon sa-bordnone datepick">
					<span class="glyphicon glyphicon-calendar"></span>
					</span>
				</div>
			</div>
			<div class="col-md-2">
			<button class="btn btn-primary form-control" type="submit" id="btn_view_filters"><i class="icon-search icon-white"></i>&nbsp;<span class=" visible-desktop">Search</span></button>
			</div>
				
			</div>
		</form>
		</div>
		<div class="col-md-12 no-padding-lft-rgt orderlist scroll" id="JS_main_content_scroll" style="border:1px solid #ddd;overflow: auto;">
			<ul class="nav navbar-nav symptoms " style="padding-top:10px; width:100%;">
				<li class="col-md-12 active" style="padding:10px;">
					<table class="table  table-hover table-responsive" id="">
					<thead>					
					 <tr>
						<th>Action</th>
						<th>Type</th>
						<th>Order#</th>
						<th>WO#</th>
						<th>Name</th>
						<th>Preference</th>
						<th>Schedule Time</th>
						<th>Location</th>
						<th>Assigned To</th>
						<th>Status</th>
					 </tr>						
					</thead>
					<tbody>	
					</tbody>
						<?php
						if($ordersList->countn>0){
							foreach($ordersList->data as $order){
								$application_no = isset($order->order->patientinfo->application_no)?$order->order->patientinfo->application_no:"";
								foreach($order->order->orderitem as $orderitems){
									//check the any line item is active or not
									if(isset($orderitems->item_status) && $orderitems->item_status!=null){
										if($orderitems->item_status!="8"){
											 $lineitem=1;
											 break;
										}else{
											$lineitem=0;
										}
									}else{
										$lineitem=1;
										break;
									}
								}
								// if active
								if($lineitem==1){
									$corpname = isset($order->order->patientinfo->corporatename)?$order->order->patientinfo->corporatename:"";
									$gender_pref = isset($order->order->patientinfo->gender_pref)?$order->order->patientinfo->gender_pref:"";
									$dbdateChange = str_replace(".000Z","",str_replace("T"," ",$order->order->patientinfo->scheduled_date));
									$dbdate = date("Y-m-d", strtotime($dbdateChange));
									$scheduledate = date("Y-m-d h:i a", strtotime($dbdateChange));
									$scheduledate1 = date("Y-m-d H:i:s", strtotime($dbdateChange));
									
									$order_t=0;
									if($order->order->patientinfo->service_type==5){								
										$order_t=isset($order->order->patientinfo->istransactioncare)?$order->order->patientinfo->istransactioncare:0;
										$conid=-1;
										if(isset($order->order->parentconsid)){	$conid=$order->order->parentconsid;	}
									}
									
									
									echo "<tr>";
									//echo "<td><button class='btn btn-success' onclick='getOfficers(\"".$order->order->patientinfo->order_id."\",\"".$order->order->patientinfo->scheduled_date."\",\"".$order->wid."\")'>Allocate</button></td>";
									
									if($sessiondata['type'] == "admin"){
										echo "<td><button class='btn btn-success' onclick='getOfficers(\"".$order->order->patientinfo->order_id."\",\"".$dbdateChange."\",\"".$order->wid."\",\"".$sessiondata['parent_userid']."\",\"".$sessiondata['userid']."\",\"".$application_no."\")'>Allocate</button></td>";  
									}else{
										echo "<td><button class='btn btn-success' onclick='getOfficers(\"".$order->order->patientinfo->order_id."\",\"".$dbdateChange."\",\"".$order->wid."\",\"\",\"\",\"".$application_no."\")'>Allocate</button></td>";
									}
									
									
									echo "<td>".$business_name[$order->order->patientinfo->service_type];
									if($order->order->patientinfo->service_type==5){
										if(($order_t!=0)){	echo '<span class="label label-danger">T</span>';}									
										if($conid==0){	echo '&nbsp;<span class="label label-danger">P</span>'; }
									}
									if($corpname!=""){
										echo '<div class="pull-left no-padding-lft-rt"><span  style="color:white;background-color:#21766f;">'.$corpname.'</span></div>';
									} 
									echo "</td>";
									echo "<td><a href='#' onclick='orderdetails(\"".$order->order->patientinfo->order_id."\")'>".$order->order->order_status->order_did."</a></td>";
									echo "<td><a href='#' onclick='trackorder(\"".$order->order->patientinfo->order_id."\")'>".$order->wodid."</a></td>";
									//echo "<td><a href='#' onclick='loadorderbypatient(\"".$order->order->patientinfo->order_id."\",\"".$order->order->patientinfo->mrn."\")'>".$order->order->patientinfo->name."</a></td>";
                                                                        echo "<td>".$order->order->patientinfo->name."</td>";
									echo "<td>".$gender_pref."</a></td>";
									echo "<td>".$scheduledate."</a></td>";
									echo "<td>".$order->order->patientinfo->address.", ".$order->order->patientinfo->landmark."</td>";
									if($order->WOStatus!=0 && isset($order->order->order_status->mhoname)){
										echo "<td>".$order->order->order_status->mhoname."</td>";
									}else{
										echo "<td>N/A</td>";
									}
									if (isset($order->data->Nomenclature)) {
                                          echo "<td>" . $order->data->Nomenclature . "</td>";
                                    } else {
                                        echo "<td></td>";
                                    }       
                                    /*if (isset($order->data[0]->Nomenclature)) {
                                          echo "<td>" . $order->data[0]->Nomenclature . "</td>";
                                    } else {
                                        echo "<td></td>";
                                    }*/
									echo "</tr>";
								}
							}
						}else{
                                                    echo "<tr align='center'><td colspan='10' style='color:red;font-size:25px;'>No Data Found </td></tr>";
                                                }
						?>
					</table>
				</li>
			</ul>
		</div>					
	</div>			
</div>	


<script>
var app = angular.module('mhoSearchApp', []);
app.controller('MainCtrl', function($scope) {});
app.directive('filterList', function($timeout) {
    return {
        link: function(scope, element, attrs) {
            
            var li = Array.prototype.slice.call(element[0].children);
            
            function filterBy(value) {
                li.forEach(function(el) {
                    el.className = el.textContent.toLowerCase().indexOf(value.toLowerCase()) !== -1 ? '' : 'ng-hide';
                });
            }
            
            scope.$watch(attrs.filterList, function(newVal, oldVal) {
                if (newVal !== oldVal) {
                    filterBy(newVal);
                }
            });
        }
    };
});

</script>