<style>
    label {
        vertical-align:middle;
    }
</style>
<!-- Common Modal -->
<div class="modal fade" id="commonModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" id="model_resp">
            <div class="modal-header" id="modal_header" style="background-color:#7bae4d; color:#fff;">
                <button type="button" class="close close_model" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Order Details</h4>
            </div>
            <div class="modal-body" id="modal_body">
                <p>This is a common modal.</p>
            </div>
            <div class="modal-footer" id="modal_footer">
                <button type="button" class="btn btn-default close_model">Close</button>
            </div>
        </div>
    </div>
</div>

<!--modal end-->

<div class="modal fade" id="common_action_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content" id="model_resp">
            <div class="modal-header" id="common_action_modal_header" style="background-color:#7bae4d; color:#fff;">
                <button type="button" class="close" id="close-action-popup" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Are you sure you want to generate report.?</h4>
            </div>
            <div class="modal-body" id="common_action_modal_body">

                <p>This is a common modal.</p>
            </div>

        </div>

    </div>
</div>

<script src="https://cdn.socket.io/socket.io-1.2.0.js"></script>
<script type="text/javascript">
	sessionStorage.setItem("escalation_dashboard_user_id", "<?php echo $sessiondata["userid"]; ?>");
	sessionStorage.setItem("escalation_dashboard_user_name", "<?php echo $sessiondata['username']; ?>");
	
</script> 
<script>
   //for selecting multiple options from dropdown
    $(document).ready(function() {
         $('.js-example-basic-multiple').select2({
               placeholder: "Select a city"
        });
        
    });
   
    function paymentmodenames(paymentmode){
        var paymenttype="";
        if(paymentmode == 0 || paymentmode == "0"){
            paymenttype = "Cash";
        }else if(paymentmode == 1 || paymentmode == "1"){
            paymenttype = "payU";
        }else if(paymentmode == 2 || paymentmode == "2"){
            paymenttype = "ICICI";
        }else if(paymentmode == 3 || paymentmode == "3"){
            paymenttype = "Mobikwik";
        }else if(paymentmode == 4 || paymentmode == "4"){
            paymenttype = "ccavenue";
        }else if(paymentmode == 5 || paymentmode == "5"){
            paymenttype = "ITZCASH";
        }else if(paymentmode == 6 || paymentmode == "6"){
            paymenttype = "paytm";
        }else if(paymentmode == 7 || paymentmode == "7"){
            paymenttype = "AIRTEL";
        }else{
            paymenttype = "PaytmQR";
        }
        return paymenttype;
    }
    
    function openreceipt(numbers) {
        $("#receiptbox" + numbers).toggle();
    }
    
    //common ajax call
    function _ajaxEventHandler(method, payload, functionName) {
        $.ajax({
            url: "<?php echo base_url(); ?>user/" + method,
            type: "POST",
            data: payload,
            //data: JSON.stringify(payload),
            //contentType: "application/json",
            success: functionName,
            error: function (jqXHR, exception) {
            getErrorMessage(jqXHR, exception);
           }
            
        });
    }
    
    // This function is used to get error message for all ajax calls
    function getErrorMessage(jqXHR, exception) {
        $(".loader").hide();
        var msg = '';
        if (jqXHR.status === 0) {
               msg = 'Not connect.\n Verify Network.';
        } else if (jqXHR.status == 404) {
               msg = 'Requested page not found. [404]';
        } else if (jqXHR.status == 500) {
               msg = 'Internal Server Error [500].';
        } else if (exception === 'parsererror') {
               msg = 'Requested JSON parse failed.';
        } else if (exception === 'timeout') {
               msg = 'Time out error.';
        } else if (exception === 'abort') {
               msg = 'Ajax request aborted.';
        } else {
               msg = 'Uncaught Error.\n' + jqXHR.responseText;
        }
         
        alert(msg);
    }
    
    //common ajax success resposne
    function commonSuccessResponse(response){
        console.log(response);
        if (typeof response == 'string') {
	     response = JSON.parse(response);
	} else {
             response = response;	
	}
        if(response.status == 1){
             alert(response.message);
             window.location.reload();
        }else{
           alert(response.message);
        }
            $('.loading').hide();
            $("#commonModal").modal("hide");
    }

    function changedate(dt) {
        if (dt === "NaN") {
            return "-";
        } else {
            dt = dt.replace(" ", "T");
            dt = dt.split('T');
            var time = dt[1].slice(0, 8);
            var H = +time.substr(0, 2);
            var h = (H % 12) || 12;
            var ampm = H < 12 ? "AM" : "PM";
            time = h + time.substr(2, 3) + ampm;
            return dt = dt[0] + ' ' + time;
        }
    }

    function convetamount(amount) {
        amount = amount.toString();//converting number to string
        var arr = amount.split('.');//spilting string after dot
        amount = arr[0] + '.00';//if it doesn't have numbers after dot adding two 00's
        if (arr[1]) {
            amount = arr[0] + '.' + arr[1].slice(0, 2);//showing only two digits after the dot
        }
        return amount;
    }

    //for order details
    function orderdetails(OrderID) {
        $('.loading').show();
        _ajaxEventHandler("getorderinformation", {orderid: OrderID}, resposeOf_order_info);
    }

    //response of order_info modal
    function resposeOf_order_info(response) {
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        var wallet_amount = 0;
        var voucher_amount = 0;
        var delivery_charge = 0;
        var total_grossamount = 0;
        var total_netamount = 0;
        var total_discountamount = 0;
        var total_payable_amount = 0;
        ordersdetails = JSON.parse(response);
        //console.log(ordersdetails);
        if (ordersdetails.data.message === "Success") {
            var i = 0;
            header_data +="<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
			"<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
			" <h5 class='modal-title' id='recieptdetails' style='margin:0;line-height: 1.428571;'>" +
			"<b>" + ordersdetails.data.data[0].order.patientinfo.name + "</b>" +
			"|" + ordersdetails.data.data[0].order.patientinfo.gender + "|" +
			"" + ordersdetails.data.data[0].order.patientinfo.age + "|" +
			"MRN:" + ordersdetails.data.data[0].order.patientinfo.mrn + "<br> " +
			"Order#:" + ordersdetails.data.data[0].odid + " |" +
			"Ordered On:" + changedate(ordersdetails.data.data[0].order.patientinfo.scheduled_date ? ordersdetails.data.data[0].order.patientinfo.scheduled_date : "NaN")+"<br><br>";
			
            if(ordersdetails.data.data[0].order.patientinfo.service_type == "3" || ordersdetails.data.data[0].order.patientinfo.service_type == "4"){
                header_data +=  "Laboratory Name:" + ordersdetails.data.data[0].order.provider_info[0].associate_name +"";
            }
            
            header_data += "</h5></div>";
            body_data +="<div class='modal-body' >" +
			"<div class='row'>" +
			"<div class='col-xs-12'>" +
			"<div class='orderdata' >" +
			"<div class='col-md-12' id='JS_main_content_scroll' style='overflow:auto; height:350px;padding:0;'>" +
			"<ul class='nav navbar-nav symptoms' style='width:100%;'>" +
			"<li class='col-xs-12 active'>" +
			"<table class='table table-striped table-bordered table-hover'>" +
			"<thead>" +
			"<tr>" +
			"<th width='30' style='text-align:center;'>#</th>" +
			"<th width='30' style='text-align:center;'>Test Name</th>" +
			"<th width='30' style='text-align:center;'>Doctor</th>" +
			"<th width='30' style='text-align:center;'>Quantity</th>" +
			"<th width='30' style='text-align:center;'>Scheduled Date/Time</th>" +
			"<th width='30' style='text-align:center;'>Gross Amount</th>" +
			"<th width='30' style='text-align:center;'>Net Amount</th>" +
			"</tr>" +
			"</thead>" +
			"<tbody class='doctors-available'>";
            //foreach loop            
            $.each(ordersdetails.data.data[0].order.orderitem, function (key, val){
				//console.log(val.item_status);
                if (val.item_status != "8"){
                    i = i + 1;
                    val.quantity = val.quantity ? val.quantity : 1;
                    val.gross_amount = val.gross_amount ? parseFloat(val.gross_amount) : 0;
                    val.net_amount = val.net_amount ? parseFloat(val.net_amount) : 0;
                    val.discount_amount = val.discount_amount ? parseFloat(val.discount_amount):0;

                    /*total_grossamount = parseFloat(total_grossamount) + parseFloat(val.gross_amount * val.quantity);//calaculating total gross amount
                    total_netamount = parseFloat(total_netamount) + parseFloat(val.net_amount * val.quantity);//calculating total net amount
                    total_discountamount = parseFloat(total_discountamount) + parseFloat(val.discount_amount);//calculating total discount amount*/
					
					total_grossamount = parseFloat(total_grossamount) + parseFloat(val.gross_amount);
					total_netamount = parseFloat(total_netamount) + parseFloat(val.net_amount);
					total_discountamount = parseFloat(total_discountamount) + parseFloat(val.discount_amount);
					
                    body_data += "<tr>" +
					"<td width='30' style='text-align:center;'>" + i + "</td>" +
					"<td width='30'  style='text-align:center;'>" + (val.itemname ? val.itemname : "Na") + "</td>" +
					"<td width='30' style='text-align:center;'>" + (val.doctor ? val.doctor : "Na") + "</td>" +
					"<td width='30' style='text-align:center;'>" + val.quantity + "</td>" +
					"<td width='30' style='text-align:center;'>" + changedate(ordersdetails.data.data[0].order.patientinfo.scheduled_date) + "</td>" +
					"<td width='30' style='text-align:center;'>" + val.gross_amount.toFixed(2) + "</td>" +
					"<td width='30'  style='text-align:center;'>" + val.net_amount.toFixed(2) + "</td>" +
					"</tr>";
                }
            });//end of foreach loop

            //calculating total payable amount
			
            wallet_amount = convetamount(ordersdetails.data.data[0].payment_info.wallet_amount ? ordersdetails.data.data[0].payment_info.wallet_amount : 0);
			//calling method
            voucher_amount = convetamount(ordersdetails.data.data[0].payment_info.voucher_amount ? ordersdetails.data.data[0].payment_info.voucher_amount : 0);
			//calling method
			
            delivery_charge = convetamount(ordersdetails.data.data[0].order.patientinfo.medicine_delivery_charge ? ordersdetails.data.data[0].order.patientinfo.medicine_delivery_charge : 0);//calling method
			
			if(parseFloat(delivery_charge)>0){
				total_payable_amount = (parseFloat(total_netamount) + parseFloat(delivery_charge)) - (parseFloat(wallet_amount) + parseFloat(voucher_amount));
			}else{
				total_payable_amount = parseFloat(total_netamount) - (parseFloat(wallet_amount) + parseFloat(voucher_amount));
			}

            body_data += "<tr>" +
			"<td colspan='6' width='30' style='text-align:right;'>Total GrossAmount:</td>" +
			"<td style='text-align:center;'>" + total_grossamount.toFixed(2) + "</td>" +
			"</tr>" +
			"<tr>" +
			"<td colspan='6' width='30' style='text-align:right;'>Total DiscountAmount:</td>" +
			"<td style='text-align:center;'>" + total_discountamount.toFixed(2) + "</td>" +
			"</tr>" +
			"<tr>" +
			"<td colspan='6' width='30' style='text-align:right;'>Total NetAmount:</td>" +
			"<td style='text-align:center;'>" + total_netamount.toFixed(2) + "</td>" +
			"</tr>" +			
			"<tr>" +
			"<td colspan='6' width='30' style='text-align:right;'>Total WalletAmount:</td>" +
			"<td style='text-align:center;'>" + wallet_amount + "</td>" +
			"</tr>" +
			"<tr>" +
			"<td colspan='6' width='30' style='text-align:right;'>Total VoucherAmount:</td>" +
			"<td style='text-align:center;'>" + voucher_amount + "</td>" +
			"</tr>";
			if(parseFloat(delivery_charge)>0){
				body_data += "<tr><td colspan='6' width='30' style='text-align:right;'>Total DeliveryCharges:</td>" +
				"<td style='text-align:center;'>" + delivery_charge + "</td>" +
				"</tr>";
			}	
			body_data += "<tr>" +
			"<td colspan='6' width='30' style='text-align:right;'>Total PaybleAmount:</td>" +
			"<td style='text-align:center;'>" + total_payable_amount.toFixed(2) + "</td>" +
			"</tr>" +
			"</tbody>" +
			"</table>" +
			"</li>" +
			"</ul>" +
			"</div>" +
			"</div>" +
			"</div>" +
			"</div>" +
			"</div>";
        } else {
            header_data +=
                    "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                    "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                    " <h5 class='modal-title' id='recieptdetails' style='margin:0;line-height: 1.428571;'>" +
                    "<font style='color:red;font-size:25px;'>Order dettails not found</font>"+
            "</h5>" +
                    " </div>";
        }
        footer_data+='<button type="button" class="btn btn-default close_model" data-dismiss="modal">Close</button>';

        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();
    }

    //for tracking order
    function trackorder(OrderID) {
        $('.loading').show();
        _ajaxEventHandler("trackorder", {orderid: OrderID}, resposeOf_workorder_info);
    }

    //response of tracking order modal
    function resposeOf_workorder_info(response) {
        //console.log(response);return;
        if (typeof response == 'string') {
                workordersdetails = JSON.parse(response);
        } else {
                workordersdetails = response;
        }
        console.log(workordersdetails.data.order_log);
        var header_data = "";
        var body_data = "";
        var footer_data = "";

        //if (workordersdetails.order_log !== 'undefined' && workordersdetails.order_log.length > 0) {
        if (workordersdetails.status == 1 && workordersdetails.data.order_log.length > 0) {
            var action = "";

            header_data +=
                    "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                    "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                    "<h3 class='modal-title' style='width:300px;' id='myModalLabel'>Order Tracking Status</h3>" +
                    "<!--<label id='hforhomefacility' style='width: auto;margin-top: -24px;margin-bottom: 0px;height: 21px; margin-right: 34px;' class='pull-right label label-success popup_label'><i>Home Facility</i> : " +(workordersdetails.data.order_log[0].popname  ? workordersdetails.data.order_log[0].popname : "N/A")+ "</label>-->" +
                    " </div>";
            body_data +=
                    "<div class='modal-body' >"+
                    "<div class='row'>"+
                    "<div class='col-xs-12'>"+
                    "<div class='orderdata' >"+
                    "<div class='col-md-12' id='JS_main_content_scroll' style='overflow:auto; height:350px;padding:0;'>"+
                    "<ul class='nav navbar-nav symptoms' style='width:100%;'>"+
                    "<li class='col-xs-12 active'>"+
                    "<table class='table table-striped table-bordered table-hover'>" +
                    "<thead>" +
                    "<tr>" +
                    "<th width='30'  style='text-align:center;'>Order</th>" +
                    "<th width='30'  style='text-align:center;'>User Name</th>" +
                    "<th width='30'  style='text-align:center;'>User Id</th>" +
                    "<th width='30'  style='text-align:center;'>Role</th>" +
                    "<th width='30'  vstyle='text-align:center;'>Action</th>" +
                    "<!--<th width='30'  style='text-align:center;'>Servicing Facility Name</th>-->" +
                    "<th width='30'  style='text-align:center;'>Order Status</th>" +
                    "<th width='30'  style='text-align:center;'>Updated On</th>" +
                    "<th width='30'  style='text-align:center;'>Reason</th>" +
                    "</tr>" +
                    "</thead>" +
                    "<tbody class='doctors-available'>";
            //foreach loop
            $.each(workordersdetails.data.order_log, function (key, val) {
                //  console.log(val.action);
                if (val.action !== null) {
                    action = val.action.charAt(0).toUpperCase() + val.action.slice(1);
                }
                if (action !== "Delivered") {
                    body_data += 
                            "<tr>" +
                            "<td width='30'  style='text-align:center;'>" + val.wodid + "</td>" +
                            "<td width='30' style='text-align:center;'>" +(val.actionByName  ? val.actionByName : "N/A")+ "</td>" +
                            "<td width='30' style='text-align:center;'>" +(val.actionById  ? val.actionById : "N/A")+ "</td>" +
                            "<td width='30' style='text-align:center;'>" +(val.role  ? val.role : "N/A")+ "</td>" +
                            "<td width='30' style='text-align:center;'>" +(val.action  ? val.action : "N/A")+ "</td>" +
                            "<!--<td width='30'  style='text-align:center;'>" +(val.popname  ? val.popname : "N/A")+ "</td>-->" +
                            "<td width='30'  style='text-align:center;'>" + (val.status_name?val.status_name:"") + "</td>" +
                            "<td width='30'  style='text-align:center;'>" + val.created_date + "</td>" +
                            "<td width='30'  style='text-align:center;'>" +(val.reason  ? val.reason : "N/A")+ "</td>" +
                            "</tr>";

                }

            });
            body_data += "</tbody>" +
                    "</table>" +
                    "</div>";

        } else {
            header_data +=
                    "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                    "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                    " <h5 class='modal-title' id='recieptdetails' style='margin:0;line-height: 1.428571;'>" +
                    "<font style='color:red;font-size:25px;'>"+workordersdetails.message+"</font>" +
                    "</h5>" +
                    " </div>";
        }
        
        footer_data+= '<button type="button" class="btn btn-default close_model" data-dismiss="modal">Close</button>';


        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();

    }

    //for print document
    function print_document(OrderID, ServicetypeID, ServicesubtypeID, MRN, BusinessName) {
        $('.loading').show();
        _ajaxEventHandler("print_document", {orderid: OrderID, servicetypeid: ServicetypeID, servicesubtypeid: ServicesubtypeID, mrn: MRN, businessname: BusinessName}, resposeOf_print_document);
    }

    //response of  printdocument popup   
    function resposeOf_print_document(response) {
        console.log(response);
        documentdetails = JSON.parse(response);
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        if (documentdetails.status === "1") {
            header_data +=
                    "<div class='modal-header' style='background-color:#7bae4d; color:#fff;'>" +
                    "<button type='button' class='close' data-dismiss='modal'>&times;</button>" +
                    "<h4 class='modal-title'>Print Document</h4>" +
                    "</div>";

            body_data +=
                    "<div class='modal-body'>" +
                    "<input type='hidden' name='order_id' id='order_id' value=''>" +
                    "<input type='hidden' name='mrn' id='mrn' value=''>" +
                    "<div class='container-fluid'>" +
                    "<div class='row'>" +
                    "<b><h4>" + documentdetails.businessname + "</h4></b>" +
                    "</div>";
            if (documentdetails.servicetypeid === "1") {
                body_data += "<div class='row'>" +
                        "<div class='col-md-4'>" +
                        "<span>Note Print</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>user/print_CommonPrescriptionDocument/" + documentdetails.orderid + "/" + documentdetails.businessname + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>";
                /*  "<div class='row' style='margin-top:10px;'>" +
                 "<div class='col-md-4'>" +
                 "<span>Consultation Bill Print</span>" +
                 "</div>" +
                 "<div class='col-md-4'>" +
                 "<a class='btn btn-default active' href='<?php echo base_url(); ?>user/printinvoicedocforecons/" + documentdetails.orderid + "/" + documentdetails.mrn + "'>" +
                 "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                 "</a>" +
                 "</div>" +
                 "</div>";*/
            } else if (documentdetails.servicetypeid === "2") {
                if (documentdetails.servicecubtypeid === "Via Consultation") {
                    body_data += "<div class='row'>" +
                            "<div class='col-md-4'>" +
                            "<span>Prescription Print</span>" +
                            "</div>" +
                            "<div class='col-md-4'>" +
                            "<a class='btn btn-default active'  href='<?php echo base_url(); ?>user/print_CommonPrescriptionDocument/" + documentdetails.orderid + "/" + documentdetails.businessname + "''>" +
                            "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                            "</a>" +
                            "</div>" +
                            "</div>";
                }
                body_data += "<div class='row' style='margin-top:10px;'>" +
                        "<div class='col-md-4'>" +
                        "<span>Drug Request</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>user/print_CommonInvoiceDocument/" + documentdetails.orderid + "/" + documentdetails.businessname + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>";
            } else if (documentdetails.servicetypeid === "5") {
                body_data += "<div class='row'>" +
                        "<div class='col-md-4'>" +
                        "<span>Note Print</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>user/print_CommonPrescriptionDocument/" + documentdetails.orderid + "/" + documentdetails.businessname + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>" +
                        "<div class='row' style='margin-top:10px;'>" +
                        "<div class='col-md-4'>" +
                        "<span>Home Care Bill</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>user/print_CommonInvoiceDocument/" + documentdetails.orderid + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>";
            } else if (documentdetails.servicetypeid === "30") {
                body_data += "<div class='row'>" +
                        "<div class='col-md-4'>" +
                        "<span>Note Print</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active'  href='<?php echo base_url(); ?>user/print_CommonPrescriptionDocument/" + documentdetails.orderid + "/" + documentdetails.businessname + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>" +
                        "<div class='row' style='margin-top:10px;'>" +
                        "<div class='col-md-4'>";
                if (documentdetails.servicecubtypeid === "103" || documentdetails.servicecubtypeid === "201") {
                    body_data += "<span>Invoice Print</span>";
                } else {
                    body_data += "<span>Home Care Bill</span>";
                }
                body_data += "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>user/print_CommonInvoiceDocument/" + documentdetails.orderid + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>";
            } else if (documentdetails.servicetypeid === "4") {
                body_data += "<div class='row'>" +
                        "<div class='col-md-4'>" +
                        "<span>Prescription Print</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>user/print_CommonPrescriptionDocument/" + documentdetails.orderid + "/" + documentdetails.businessname + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>" +
                        "<div class='row' style='margin-top:10px;'>" +
                        "<div class='col-md-4'>" +
                        "<span>Invoice Print</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>user/print_CommonInvoiceDocument/" + documentdetails.orderid + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>";


            } else {
                body_data += "<div class='row'>" +
                        "<div class='col-md-4'>" +
                        "<span>Prescription Print</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>user/print_CommonPrescriptionDocument/" + documentdetails.orderid + "/" + documentdetails.businessname + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>" +
                        "<div class='row' style='margin-top:10px;'>" +
                        "<div class='col-md-4'>" +
                        "<span>Invoice Print</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>user/print_CommonInvoiceDocument/" + documentdetails.orderid + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>";
            }

            "</div>" +
                    "</div>";

        } else {
            header_data +=
                    "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                    "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                    " <h5 class='modal-title' id='recieptdetails' style='margin:0;line-height: 1.428571;'>" +
                    "<font style='color:red;font-size:25px;'>Document  details not found</font>+"
            "</h5>" +
                    " </div>";
        }

        footer_data+= '<button type="button" class="btn btn-default close_model" data-dismiss="modal">Close</button>';
        
        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();
    }

    //for accept or reject Phelp request
    function request_type(slot_id, type) {
        $('.loading').show();
        _ajaxEventHandler("request_type", {slot_id: slot_id, request_type: type}, resposeOf_requstedtype);
    }
    //showing request response
    function resposeOf_requstedtype(response) {
        requestdetails = JSON.parse(response);
        console.log(requestdetails);
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        if (requestdetails.status === 1) {
            header_data +=
                    "<div class='modal-header'>" +
                    "<button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>" +
                    "<h3 class='modal-title' style='width:300px;' id='myModalLabel'>Request Status</h3>" +
                    "</div>";

            body_data +=
                    "<div class='modal-body' style='float:left; width:100%;'>";
            if (requestdetails.request_type === 'accept') {
                body_data += " <h5 class='modal-title' id='recieptdetails' style='margin:0;line-height: 1.428571;'>" +
                        "<font style='color:green;font-size:20px;'>" + requestdetails.message + "</font>" +
                        "</h5>";
            } else {
                body_data += " <h5 class='modal-title' id='recieptdetails' style='margin:0;line-height: 1.428571;'>" +
                        "<font style='color:red;font-size:20px;'>" + requestdetails.message + "</font>" +
                        "</h5>";
            }

            "</div>";
            window.location.reload();

        } else {
            header_data +=
                    "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                    "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                    " <h5 class='modal-title' id='recieptdetails' style='margin:0;line-height: 1.428571;'>" +
                    "<font style='color:red;font-size:25px;'>Request detials are not found</font>+"
            "</h5>" +
                    " </div>";
        }
        
        footer_data+= '<button type="button" class="btn btn-default close_model" data-dismiss="modal">Close</button>';
        
        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();
    }



    function received_money(user_name, user_id, recipt_id, billing_id) {
        $('.loading').show();
        _ajaxEventHandler("received_money", {user_name: user_name, user_id: user_id, recipt_id: recipt_id, billing_id: billing_id}, resposeOf_paymentmode_cash);
    }

    function resposeOf_paymentmode_cash(response) {
        $('.loading').hide();
        var Obj = JSON.parse(response);
        alert(Obj.message);
        if (Obj.status == "1") {
            window.location.reload();
        }
    }


// Get Officer List for allocation
    function getOfficers(orderid, schedule_data, workorder_id, associateid, branchid, application_no) {
        $('.loading').show();
        var data = {order_id: orderid, scheduled_date: schedule_data, workorder_id: workorder_id, associate_id: associateid, branch_id: branchid,application_no:application_no};
        _ajaxEventHandler("getOfficers_list", data, fun_getOfficers);
    }
    /*function getOfficers(orderid, schedule_data, workorder_id, roletype) {
        $('.loading').show();
        var data = {order_id: orderid, scheduled_date: schedule_data, workorder_id: workorder_id, roletype: roletype};
        _ajaxEventHandler("getOfficers_list", data, fun_getOfficers);
    }*/

    /*function getOfficers(orderid, schedule_data, workorder_id) {
     $('.loading').show();
     var data = {order_id: orderid, scheduled_date: schedule_data, workorder_id: workorder_id};
     _ajaxEventHandler("getOfficers_list", data, fun_getOfficers);
     }*/

    //calling getOfficers model
    function fun_getOfficers(response) {
        console.log(response);
        var Obj = JSON.parse(response);
        var header_data = "<h4 class='modal-title'>Select The Officer</h4>";
        var body_data = "";
        if (Obj.status == "1") {
            var i = 1;
            body_data += "<div style='max-height:300px; overflow:auto;'><table width='100%' style='border-collapse: collapse;' cellpadding='10'>";
            $.each(Obj.data, function (key, val) {
                body_data += "<tr>" +
                        "<td width='30' height='32' align='left'>" + i + ". </td><td>" + val.officer_name + "</td>" +
                        "<td align='right'><button class='btn btn-success' style='height:29px; padding:4px 12px;' onclick='selectOfficer(this);' data_officer_id='" + val.officer_id + "' data_officer_name='" + val.officer_name + "' data_associate_id='" + val.associate_id + "' data_branch_id='" + val.branch_id + "' data_order_id='" + Obj.orderid + "' data_scheduled_date='" + Obj.scheduled_date + "' data_workorder_id='" + Obj.workorder_id + "'>Select</button></td></tr>";
                i = i + 1;
            });
            body_data += "</table></div>";
        }else {
            body_data += "<div>" + Obj.message + "</div>";
        }
        //console.log(Obj.status);
        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $('.loading').hide();
        $("#commonModal").modal("show");
    }
// Get Officer List for allocation

// Force Allocation
    function selectOfficer(obj) {
        var data = {
            order_id: $(obj).attr("data_order_id"),
            scheduled_date: $(obj).attr("data_scheduled_date"),
            associate_id: $(obj).attr("data_associate_id"),
            branch_id: $(obj).attr("data_branch_id"),
            officer_id: $(obj).attr("data_officer_id"),
            officer_name: $(obj).attr("data_officer_name"),
            workorder_id: $(obj).attr("data_workorder_id")
        };
        $('.loading').show();
        _ajaxEventHandler("force_allocation", data, fun_force_allocation);
    }

    function fun_force_allocation(response) {
        console.log(response);
        var Obj = JSON.parse(response);
       //alert(Obj);
        if (Obj.status == "1" || Obj.status == 1) {
            alert(Obj.chiss_updation_order_log[0].message);
            location.reload();
 
        } else {
            alert(Obj[0].message);
            location.reload();
        }
    }
// Force Allocation

//For POP DropDown 
    /*$("document").ready(function () {
        $('#dropdownListpop').on('change', function () {
            var optionText = $("#dropdownList option:selected").text();
            $.ajax({
                type: "POST",
                url: "resetthesession",
                data: {popid: this.value},
                success: function (result) {
                    console.log(result);
                    $('.loading').hide();
                    window.location.replace(result);
                }
            });
        });
    });*/
    
  


    //call the socket for assign all careathome order apart from transaction order
    /*$("document").ready(function () {
     socket = io.connect('<?php echo socketpath; ?>');
     socket.on("connectAck",function() {
     var userid="<?php echo $sessiondata["userid"]; ?>";
     console.log('Client has connected to the server!');
     socket.emit('establishConnection',{officerId:userid,sessionKey:'xyz',appId:'OMS',deviceId:'222'});
     });
     
     socket.on('connected',function(){
     console.log('handshake completed with server');
     });
     
     socket.on('assignOrder', function(msg){
     
     var userid="<?php echo $sessiondata["userid"]; ?>";
     var username="<?php echo $sessiondata["username"]; ?>";
     
     //var userid='<?php echo $this->session->userdata('user_info')['userId']; ?>';
     //var username='<?php echo $this->session->userdata('user_info')['Name']; ?>';
     //alert(orderid);
     console.log('message received');
     console.log(msg);
     //console.log(msg.orderid);
     var transaction_id=sessionStorage.getItem('transactionid');
     console.log(transaction_id);
     debugger;
     
     if(msg.transaction_id==transaction_id)
     {
     if(msg.complete_status==transaction_id){
     alert('Allocation completed for all orders');
     location.reload();
     }
     if(msg.assign_status=="1"){
     
     console.log('message sent');
     var message=JSON.parse(msg.message);
     console.log(message[0].order_id);
     var date=message[0].schedule_date;
     
     socket.emit('message',{messageType:'eventAck',receipentId:userid,receipentAppId:'CHISS',payload:{messageId:msg.messageId,transaction_id:transaction_id}});
     
     var obj={"orderid":message[0].order_id,"userid":userid,"username":username,"message":message};
     obj=JSON.stringify(obj);
     console.log(obj);
     $.ajax({
     type: "POST",
     url: "<?php echo servicepath; ?>assignorders",
     data:obj,
     success: function(result){
     debugger;
     
     }
     });
     }
     }
     });
     
     socket.on('eventAck', function(msg){
     console.log('eventAck',msg); 
     //socket.emit('message',{messageType:'eventAck',payload:{messageId:msg.messageId}});
     console.log('chiss up');
     });
     });*/

    //assoign order by chiss 
    function allocateby_chissSocket(order_id, url, urlchiss, orderdid, scheduledate) {
        var userid = "<?php echo $sessiondata["userid"]; ?>";
        var orderids = [parseInt(order_id)];
        /*for (i = 0; i < selected.length; i++) {
         var res =selected[i].split(",");
         var oid=res[0];
         order_id=parseInt(oid);
         orderids.push(order_id);
         }*/
        debugger;
        var obj = {"orderid": orderids};
        obj = JSON.stringify(obj);
        console.log(obj);
        $.ajax({
            type: "POST",
            url: url + "orderStructurechiss",
            data: obj,
            success: function (result) {
                debugger;
                console.log(result);
                //console.log(event_type);debugger;
                var transaction_id = (new Date()).getTime();
                socket.emit('message', {receipentId: userid, receipentAppId: 'CHISS', receipentDeviceId: '', messageType: 'orderCreated', payload: {message: result, transaction_id: transaction_id}});
                sessionStorage.setItem('transactionid', transaction_id);
                var loginid = btoa(userid + "_" + transaction_id);
                //debugger;
                //alert(urlchiss+'/reallocate_list/'+loginid);
                window.open(urlchiss + '/reallocate_list/' + loginid, '_blank');
                //$('#orderfreeze').show();
                //$('#checkAvailibility').hide();				
            }
        });
    }



//For DateTime Picker 
    $(function () {
        $(".datepick").datepicker({
            format: 'dd-mm-yyyy',
            orientation: "top",
            autoclose: true,
            //endDate: new Date()

        }).on('changeDate', function (selected) {
            var date = new Date(selected['date']);
            var dd = date.getDate();
            if(dd<10) {
                dd='0'+dd;
            } 
            var month = date.getMonth() + 1;
            if(month<10) {
                month='0'+month;
            } 
            var finaldate = dd + "-" + month + "-" + date.getFullYear();
            //console.log(finaldate);
            $("#fromdatesearch").val(finaldate);
            $(this).prev('input').val(finaldate);
        });
    });

    /*$("#check_all").change(function () {
     $(".select_check_all").prop('checked', $(this).prop("checked"));
     });*/
    var reciptIds = [];
    function reciptSubmit() {
		reciptIds = [];
        //$('.loading').show();
        var receiptDetails = [];
        if ($("input:checkbox[name=order_select]:checked").length <= 0) {
            alert("please select atleast one recipt data");
            return false;
        }
        $("input:checkbox[name=order_select]:checked").each(function () {
            reciptIds.push($(this).val());
            $receiptOrderId = $(this).attr('data-receipt-order_did');
            $receiptAmount = $(this).attr('data-receipt-amount');
            receiptDetails[$receiptOrderId] = $receiptAmount;
        });
        console.log(receiptDetails);
        console.log(reciptIds.length);
        resposeOf_reciptSubmit_info(receiptDetails);

    }

    function resposeOf_reciptSubmit_info(response) {
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        var receiptData = "";
        if (reciptIds.length > 0) {
            receiptData = "<table class='table table-striped table-bordered table-hover'>" +
                    "<thead>" +
                    "<tr>" +
                    "<th style='text-align:right;'>Sno</th>" +
                    "<th style='text-align:center;'>Order ID</th>" +
                    "<th style='text-align:center;'>Receipt ID</th>" +
                    "<th style='text-align:center;'>Receipt Amount</th>" +
                    "</tr>" +
                    "</thead>" +
                    "<tbody>";
            $i = 1;
            $receiptAmount = 0;
            for (var key in response) {
                receiptData += "<tr>" +
                        "<td style='text-align:right;'>" + $i + "</td>" +
                        "<td style='text-align:center;'>" + key + "</td>" +
                        "<td style='text-align:center;'>" + reciptIds[$i - 1] + "</td>" +
                        "<td style='text-align:right;'>" + response[key] + "</td>" +
                        "</tr>";
                $i++;
                $receiptAmount += parseFloat(response[key]);
            }

            receiptData += "</tbody>" +
                    "<table><br/>";
        }
        header_data +=
                "<style>.error_clean{font-size: 12px;color: red;margin : 0px;}</style>" +
                "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                "<button type='button' class='close close_model' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                "<h3 class='modal-title' style='width:300px;' id='myModalLabel'>CallHealth Submissions</h3>" +
                " </div>";
        body_data +=
                "<div class='modal-body' >" +
                "<div class='row'>" +
                "<div class='col-xs-12'>" +
                "<div class='orderdata' >" +
                "<div class='col-md-12' id='JS_main_content_scroll' style='overflow:auto; height:350px;padding:0;'>" +
                receiptData +
                "<ul class='nav navbar-nav symptoms' style='width:100%;'>" +
                "<li class='col-xs-12 active'>" +
                "<table class='table table-striped table-bordered table-hover'>" +
                "<thead>" +
                "<tr>" +
                "<th width='30'  style='text-align:center;'>Type</th>" +
                "<th width='30'  style='text-align:center;'>Amount</th>" +
                "<th width='30'  style='text-align:center;'>Transaction Code</th>" +
                "</tr>" +
                "</thead>" +
                "<tbody class='doctors-available'>" +
                "<tr>" +
                "<td width='90'  style='text-align:center;'>" +
                '<input type="hidden" id="recipt_modal_select_value" name="item_code">' +
                '<select size="1" name="search_type" id="recipt_modal_select" onchange="selectreciptype()" class="submitrecipt btn dropdown-toggle select_search_value form-control pull-left" aria-controls="example"  style="background-color: #7BAE4D; color: #FFFFFF;height:33px;">' +
                '<option value="cmscode">CMS Code</option>' +
                '<option value="bankcode">Bank Trasaction Code</option>' +
                ' </select>' +
                '<p class="recipt_modal_select_error error_clean"></p>' +
                "</td>" +
                "<td width='30'  style='text-align:center;'>" +
                '<input type="text" value=' + $receiptAmount.toFixed(2) + ' id="recipt_amount" name="item_code" class="submitrecipt text-right" disabled>' +
                '<p class="recipt_amount_error error_clean"></p>' +
                "</td>" +
                "<td width='30'  style='text-align:center;'>" +
                '<input type="text" id="recipt_transcaction_code" name="item_code" class="submitrecipt">' +
                '<p class="recipt_transcaction_code_error error_clean"></p>' +
                "</td>" + "</tr>" +
                "</tbody>" +
                "</table>" +
              
                "</div>";

      footer_data +=
                '<div class="row">' +
                '<div class="col-md-3" ></div>' +
                '<div class="col-md-1" ></div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-primary"  Style="width:85px;" onclick="submitrecipt()">Submit</button>' +
                '</div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-danger"  Style="width:85px;" data-dismiss="modal">Cancel</button>' +
                '</div>' +
                '</div>' +
                '</div>';

        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();

    }

    function selectreciptype() {
        var value = $('#recipt_modal_select option:selected').val();
        //  alert(value);
        $("#recipt_modal_select_value").val(value);
    } 

    function submitrecipt() {
        var errorArray = {
            'recipt_modal_select_value': 'Code Type is required',
            'recipt_amount': 'Amount is required',
            'recipt_transcaction_code': 'Transaction code is required'
        };
        $('.error_clean').html('');
        var formData = [];
        var error = false;
        $('.submitrecipt').each(function () {
            $id = $(this).attr('id');
            $value = $(this).val();
            formData[$id] = $value;
            if ($value == '') {
                error = true;
                $error_msge = errorArray[$id];
                $('.' + $id + '_error').html($error_msge);
            }
        });
        console.log(formData);
        if (error === false) {
            var _data = {
                "transactionId": formData['recipt_transcaction_code'], //Mandatory
                "amount": formData['recipt_amount'], //Mandatory
                "type": formData['recipt_modal_select'],
                "receiptIds": reciptIds
            };
            console.log(_data);
            _ajaxEventHandler("submitReceiptPayment", {requestData: _data}, submitrecipt_info);
        }
        reciptIds = [];

    }

    function submitrecipt_info(response) {
        $('#modal_body').html(response);
        if (typeof response == 'string') {
            response = JSON.parse(response);
        }
        var msge = '<h4 class="text-center">' + response['message'] + '</h4>';
        $('#modal_body').html(msge);
        $("#modal_footer").html('');

        setTimeout(function () {
            window.location.reload();
        }, 2000);
    }

    $('.close_model').on('click', function () {
        console.log('button');
        $("#commonModal").modal("hide");
        $("input:checkbox[name=order_select]").removeAttr('checked');
    });

    //for refundorder recipts
    function refundOrder_recipts(OrderDID) {
        $('.loading').show();
        _ajaxEventHandler("refundOrder_recipts", {order_id: OrderDID}, resposeOf_refundOrder_recipts);
    }

    //response of refundorder recipts modal
    function resposeOf_refundOrder_recipts(response) {
        console.log(response);
        reciptdetails = JSON.parse(response);
        var reciptinfo = "";
        if((typeof (reciptdetails.data.advance_receipt) != "undefined")){
            reciptinfo = reciptdetails.data.advance_receipt ? reciptdetails.data.advance_receipt : 0;
        }else if(reciptdetails.status==1){
            reciptinfo = reciptdetails.data.billing.receiptinfo ? reciptdetails.data.billing.receiptinfo : 0;
        }
     
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        if (reciptinfo.length > 0) {
            header_data +=
                    "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                    "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                    "<h3 class='modal-title' style='width:300px;' id='myModalLabel'>Refund Receipt Details</h3>" +
                    " </div>";
            body_data +=
                    "<div class='modal-body' >" +
                    "<div class='row'>" +
                    "<div class='col-xs-12'>" +
                    "<div class='orderdata' >" +
                    "<div class='col-md-12' id='JS_main_content_scroll' style='overflow:auto; height:350px;padding:0;'>" +
                    "<ul class='nav navbar-nav symptoms' style='width:100%;'>" +
                    "<li class='col-xs-12 active'>" +
                    "<table class='table table-striped table-bordered table-hover'>" +
                    "<thead>" +
                    "<tr>" +
                    "<th width='30'  style='text-align:center;'>OrderID#</th>" +
                    "<th width='30'  style='text-align:center;'>ReceiptID#</th>" +
                    "<th width='30'  style='text-align:center;'>Receipt_amount</th>" +
                    "<th width='30'  style='text-align:center;'>Receipt_date</th>" +
                    "<th width='30'  vstyle='text-align:center;'>Payment_mode</th>" +
                    "<th width='30'  style='text-align:center;'>Payment_RefNo</th>" +
                    "<th width='30'  style='text-align:center;'>Submitted_date</th>" +
                    "</tr>" +
                    "</thead>" +
                    "<tbody class='doctors-available'>";
            //foreach loop
            $.each(reciptinfo, function (key, val) {
                body_data +=
                        "<tr>" +
                        "<td width='30' style='text-align:center;'>" + reciptdetails.data._id + "</td>" +
                        "<td width='30' style='text-align:center;'>" + (val.receipt_id ? val.receipt_id:"-")+ "</td>" +
                        "<td width='30' style='text-align:center;'>" + (val.receipt_amount ? val.receipt_amount:"-")+ "</td>" +
                        "<td width='30' style='text-align:center;'>" + changedate((val.receipt_date ? val.receipt_date:"NaN"))+ "</td>" +
                        "<td width='30' style='text-align:center;'>" + paymentmodenames((val.payment_mode ? val.payment_mode:"-"))+ "</td>" +
                        "<td width='30' style='text-align:center;'>" + (val.payment_ref_no  ? val.payment_ref_no:"-")+ "</td>" +
                        "<td width='30' style='text-align:center;'>" + changedate((val.submited_date ? val.submited_date:"NaN"))+ "</td>" +
                        "</tr>";
            });
            body_data += "</tbody>" +
                    "</table>" +
                    "</div>";
        } else {
            header_data +=
                    "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                    "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                    " <h5 class='modal-title' id='recieptdetails' style='margin:0;line-height: 1.428571;'>" +
                    "<font style='color:red;font-size:25px;'>Receipt details not found</font>" +
                    "</h5>" +
                    " </div>";
        }
        
        footer_data+= '<button type="button" class="btn btn-default close_model" data-dismiss="modal">Close</button>';
        
        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();

    }
    
    //refunds
     $("#refund_search_dropwown").on('change', (function (e) {
        e.preventDefault();
        var value = $(this).val();
        // alert(value);
        $("#refund_search_dropwown_value").val(value);

    }));
    
    var refundDataPayload = null;
    //for updating refund order status
    function update_refundOrderStatus(RefundID,OrderID,Trcode,Tramount,Trtype,Reason,Status) {
       
        var data = {
                refund_id:RefundID,
                order_id: OrderID,
                transaction_code: Trcode,
                amount: Tramount,
                transaction_type: Trtype,
                reason:Reason,
                status:Status,
                user_id:sessionStorage.getItem('escalation_dashboard_user_id'),
                username:sessionStorage.getItem('escalation_dashboard_user_name')
      
          };
          refundDataPayload = data;
       // console.log(_data);
        if(Status == "3"){
            processing_refundOrder_popup(data);
        }else{
            if(Status == "4"){ 
             _ajaxEventHandler("getCategorySubCataegory", "",openRefundRejectModal);               
        }else{
           _ajaxEventHandler("update_refundOrderStatus", data, commonSuccessResponse);  
        }   
      }
            
        $('.loading').hide();
    }
    
    function openRefundRejectModal(response){
        console.log(response);
        if (typeof response == 'string') {
                result = JSON.parse(response);
        } else {
                result = response;
        }
       
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        $('.loading').show();
        header_data +=
                "<div class='modal-header' style ='background-color:#7bae4d;color:#fff;padding:7px; border-bottom:none;'>" +
                "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                "<h5 class='modal-title' style='width:300px;' id='myModalLabel'>Are you sure you want to reject this order???</h5>" +
                "</div>";
        
        body_data +=
                '<div>'+
                "<div class='form-group'>"+
                "<label for='usr'>Reason:</label><br>"+
                '<select id="refundorderrejectreasons" style="width:550px; height:35px;" required="">'+
                '<option value="">Please select reason to reject </option>';
                $.each(result.data, function (key, val) {
                           if(val.subCategory == "Refund rejected"){
                                  body_data +='<option value="'+val.subCategoryDescription+'">'+val.subCategoryDescription+'</option>';		
                          }
               });
        body_data +=
                '</select>'+
                "</div>"+ 
		"<div class='form-group'>"+
                "<label for='usr'>Comment:</label>"+
                '<textarea name="job_name"  class="form-control new-status" style= "width:64%;" id="rejectRefundorderComment" placeholder="Enter Reason To Reject"></textarea>'+
                '<input type="hidden" value="'+refundDataPayload.order_id+'" id="refOrderid">'+
                "</div>"+   
		'</div>';
        footer_data +=
                '<div class="row">' +
                '<div class="col-md-2" ></div>' +
                '<div class="col-md-1" ></div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-primary" Style="width:85px;"  onclick="rejectRefundorder()">Submit</button>'+
                '</div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-danger" Style="width:85px;"  data-dismiss="modal">Cancel</button>';
                '</div>' +
                '</div>' +
                '</div>';
          
        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();
    }
    
    function rejectRefundorder(){ 
       var reason_text = $("#refundorderrejectreasons").val();
       refundDataPayload.reason_text = reason_text; 
       var comment_text = $("#rejectRefundorderComment").val();
       refundDataPayload.comment_text = comment_text;
       var orderID = $("#refOrderid").val();
       var _data = {
            order_id:parseInt(orderID),
            category: "Refund",
            sub_category: "Refund rejected",
            sub_category_description: reason_text        
      }; 
     if(reason_text === "" ){ 
         alert("please select the reason and click on submit");
         return false;  
     }else{
         console.log(_data);
        _ajaxEventHandler("rejectRefundOrder", _data, res_rejectRefundOrder);             
     }
   }
   
   function res_rejectRefundOrder(response){
       if (typeof response == 'string') {
                ticketdetails = JSON.parse(response);
        } else {
                ticketdetails = response;
        }
       if(ticketdetails.Result == "Success"){
           var ticketID = ticketdetails.Ticket[0].ticket_id;
          // console.log(ticketID);return;
           var _data = {
            refund_id:refundDataPayload.refund_id,
            order_id: refundDataPayload.order_id,
            transaction_code: refundDataPayload.transaction_code,
            amount: refundDataPayload.amount,
            transaction_type: refundDataPayload.transaction_type,
            reason:"",
            comment_text:refundDataPayload.comment_text,
            status:refundDataPayload.status,
            category: "Refund",
            sub_category: "Refund rejected",
            sub_category_description: refundDataPayload.reason_text,
            ticket_id:ticketID,
            user_id:sessionStorage.getItem('escalation_dashboard_user_id'),
            username:sessionStorage.getItem('escalation_dashboard_user_name')
      
         };
         console.log(_data);
          _ajaxEventHandler("update_refundOrderStatus", _data, commonSuccessResponse);
       }
   }
    function processing_refundOrder_popup(data) {
        console.log(data);
        var header_data = "";
        var body_data = "";
        var footer_data = "";

        header_data +=
                "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                "<h3 class='modal-title' style='width:300px;' id='myModalLabel'>Process Refund Order</h3>" +
                "</div>";
        body_data +=
                "<div class='modal-body' >" +
                "<div class='row'>" +
                "<div class='col-xs-12'>" +
                "<div class='orderdata' >" +
                "<div class='col-md-12' id='JS_main_content_scroll' style='overflow:auto; height:350px;padding:0;'>" +
                "<ul class='nav navbar-nav symptoms' style='width:100%;'>" +
                "<li class='col-xs-12 active'>" +
                "<table class='table table-striped table-bordered table-hover'>" +
                "<thead>" +
                "<tr>" +
                "<th width='30'  style='text-align:center;'>Payment Type</th>" +
                "<th width='30'  style='text-align:center;'>Amount</th>" +
                "<th width='30'  style='text-align:center;'>Transaction Code</th>" +
                "</tr>" +
                "</thead>" +
                "<tbody class='doctors-available'>" +
                "<tr>" +
                "<td width='90'  style='text-align:center;'>" +
                '<input type="hidden" id="refund_modal_select_value" name="item_code">' +
                '<select size="1" name="search_type" id="refund_modal_select" onchange="selectrefundype()" class="submitrecipt btn dropdown-toggle select_search_value form-control pull-left" aria-controls="example"  style="background-color: #7BAE4D; color: #FFFFFF;height:33px;">' +
                '<option value="creditcard">Credit Card</option>' +
                '<option value="debitcard">Debit Card</option>' +
                '<option value="netbanking">Net Banking</option>' +
                ' </select>' +
                '<p class="recipt_modal_select_error error_clean"></p>' +
                "</td>" +
                "<td width='30'  style='text-align:center;'>" +
                '<input type="text"  id="refund_amount" name="item_code" value = "'+data.amount+'" class="submitrecipt text-right">' +
                '<p class="recipt_amount_error error_clean"></p>' +
                "</td>" +
                "<td width='30'  style='text-align:center;'>" +
                '<input type="text" id="refund_transcaction_code" name="item_code" class="submitrecipt">' +
                '<p class="recipt_transcaction_code_error error_clean"></p>' +
                "</td>" + "</tr>" +
                "</tbody>" + 
                "</table><br>" +
               "<div style='text-align:center'>"+
               '<input type="hidden" id="refundId" name="item_code" class="submitrecipt" value="'+data.refund_id+'">' +
               '<input type="hidden" id="refund_original_amount" name="item_code" class="submitrecipt" value="'+data.amount+'">' +
               "<button type='button' class='btn btn-primary' onclick='process_refund_order("+data.order_id+","+data.status+")' style='width: 90px; margin: 0 auto;'>Submit</button>" +
               "</div>"+
               "</div>";
           

       footer_data+= '<button type="button" class="btn btn-default close_model" data-dismiss="modal">Close</button>';

        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();

    }
    
    function selectrefundype() {
        var value = $('#refund_modal_select option:selected').val();
        $("#refund_modal_select_value").val(value);
    }
    function process_refund_order(OrderId,Status) {
       var refundamount = $("#refund_original_amount").val();
       var amount = $("#refund_amount").val();
       var isnumfloat = /^[+-]?\d+(\.\d+)?$/.test(amount);
       if(isnumfloat == false){
             alert('Please enter amount and amount should be in  digits or float.');
             return false;
        }
        if(parseFloat(amount) > parseFloat(refundamount) ){
             alert('Please enter amount lessthan original amount.');
             return false;
        }
        if($("#refund_transcaction_code").val() == false){
             alert('Please enter transcaction code.');
             return false;
        }
        if($("#refund_transcaction_code").val() == ""){
             alert('Please enter transcaction code.');
             return false;
        }
        if($("#refund_modal_select").val() == ""){
             alert('Please select payment mode.');
             return false;
        }
       var _data = {
                refund_id:$("#refundId").val(),
                order_id: OrderId,
                transaction_code: $("#refund_transcaction_code").val(),
                amount: amount,
                transaction_type: $("#refund_modal_select").val(),
                reason:"",
                status:Status,
                user_id:sessionStorage.getItem('escalation_dashboard_user_id'),
                username:sessionStorage.getItem('escalation_dashboard_user_name')
      
          };
   
        console.log(_data);
        _ajaxEventHandler("update_refundOrderStatus", _data, commonSuccessResponse); 
   }
  
    function opengeneratereport_Modal(orderid) {
        // alert(orderid);
        var header_data = "";
        var body_data = "";
        header_data +=
                "<div class='modal-header close_model' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                "<h4 class='modal-title' style='width:300px;' id='myModalLabel'>Are you sure all the reports for particular order generated.????</h4>" +
                "</div>";
        body_data +=
                "<div class='modal-body' style='padding:5px;' >" +
                '<button type="button" class="btn btn-success" style="margin-bottom:25px;margin-right: 10px;" onclick="completeReports(\'' + orderid + '\')"">Yes</button>' +
                '<button type="submit" class="btn btn-danger" data-dismiss="modal" style="margin-bottom:25px;margin-right: 10px;">No</button>';

        $("#common_action_modal_header").html(header_data);
        $("#common_action_modal_body").html(body_data);
        $("#common_action_modal").modal("show");
        $('.loading').hide();
    }

    function completeReports(OrderID) {
        $('.loading').show();
        $('#common_action_modal').modal('hide');
        _ajaxEventHandler("completeReports", {order_id: OrderID}, commonSuccessResponse);
    }


    //getinng search dropdown values  
    $("#orderdropwown").on('change', (function (e) {
        e.preventDefault();
        var value = $(this).val();
        //  alert(value);
        $("#orderdropwownvalue").val(value);

    }));

    //getinng business dropdown values  
    $("#businessdropwown").on('change', (function (e) {
        e.preventDefault();
        var value = $(this).val();
        //  alert(value);
        $("#businessdropwownvalue").val(value);

    }));
    $("#recipt_search_dropwown").on('change', (function (e) {
        e.preventDefault();
        var value = $(this).val();
        //alert(value);
        $("#recipt_search_dropwown_value").val(value);

    }));

    function sample_submission_popup(orderIDs) {
        if(orderIDs == ""){
            return false;
        }
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        header_data +=
                "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                "<h4 class=''>Submit Samples</h4>" +
                "</h4>" +
                "</div>";
        body_data +=
                '<div class="row">' +
                 '<input type="hidden" id="sample_submission_orderids" name="item_code" value="'+orderIDs+'">' +
                '<div class="col-md-4" ><label>Pickup Boy From</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-2" ><input type="radio" name="pickupboyRadioOptions" onclick="" id="inlineRadio0" value="callhealth">CallHealth</div>' +
                '<div class="col-md-2" ><input type="radio" name="pickupboyRadioOptions" onclick="" id="inlineRadio1" value="vendor">Vendor</div>' +
                '</div><br>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Pickup Boy Name</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-2" ><input type="textbox" name="pickup_boy_name" id="pickup_boy_name" value="" style="height:30px;font-size:14pt;"size="25"></div>' +
                '</div><br>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Pickup Boy Mobile No</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-2" ><input type="textbox" name="pickup_boy_mobile" id="pickup_boy_mobile" value="" style="height:30px;font-size:14pt;"size="25"></div>' +
                '</div><br>' +
                '<div class="row">' +
                '<div class="col-md-4" ></div>' +
                '<div class="col-md-1" ></div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-primary"  Style="width:85px;" onclick="sendOTPforsamplesubmission();">Send OTP</button>' +
                '</div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-primary"  Style="width:85px;" onclick="sendOTPforsamplesubmission();">Resend</button>' +
                '</div>' +
                '</div>' +
                '</div><br>' +
                '<div class="row">' +
                '<div class="col-md-4" ></div>' +
                '<div class="col-md-1" ></div>' +
                '<div class="col-md-2" >' +
                '<input type="textbox" name="pickup_boy_mobile" id="pickup_boyOTP" value="" style="height:35px;font-size:14pt;"size="10">' +
                '</div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-success" Style="width:88px;" onclick="verifyOTPforsamplesubmission();">Verify OTP</button>' +
                '</div>' +
                '</div>' +
                '</div>';

        footer_data +=
                '<div class="row">' +
                '<div class="col-md-3" ></div>' +
                '<div class="col-md-1" ></div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-primary"  Style="width:85px;" onclick="sample_submission();">Submit</button>' +
                '</div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-danger"  Style="width:85px;" data-dismiss="modal">Cancel</button>' +
                '</div>' +
                '</div>' +
                '</div>';


        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();
    }
    function collect_samples(orderid,order_did) {
        var searchdropdown = 1;
        var searchtext = order_did;
  
        _ajaxEventHandler("sample_collections", {searchdropdown:searchdropdown,searchtext:searchtext,type:"sample_collection_popup_search"}, sample_collection_popup);
       
    }
    
    function print_collection_memo(orderid) {  
        _ajaxEventHandler("print_collection_memo", {orderid:orderid});     
    }
    
    var sampleType = null;
    function sample_collection_popup(response) {
        //console.log(response);
           var barcodedata = JSON.parse(response);
           if((typeof barcodedata.ordersList.data[0] != "undefined") && (typeof barcodedata.ordersList.data[0].order.patientinfo.barcode != "undefined")){
               sampleType = barcodedata.ordersList.data[0].order.patientinfo.barcode.sampleType;
           }
          // sampleType = (typeof barcodedata.ordersList.data[0].order.patientinfo.barcode.sampleType == "undefined") ? "" : barcodedata.ordersList.data[0].order.patientinfo.barcode.sampleType;
          // console.log(sampleType);
          // barcodedata = barcodedata.ordersList.data[0].order.patientinfo.barcode;
        //console.log(barcodedata.ordersList.data[0].order.patientinfo.barcode);
         
        
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        header_data +=
                "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                "<h4 class=''>Samples Collected</h4>" +
                "</h4>" +
                "</div>";
        body_data +=
                '<div class="row">' +
                '<div class="col-md-4" ><label>DD No</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-7" ><span>' + barcodedata.ordersList.data[0].odid + '</span></div>' +
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Red-Serum</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions0" onclick="choose_sampleoptiontype(this);" id="inlineRadio00" value="0" checked="checked">0</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions0" onclick="choose_sampleoptiontype(this);" id="inlineRadio01" value="1">1</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions0" onclick="choose_sampleoptiontype(this);" id="inlineRadio02" value="2">2</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions0" onclick="choose_sampleoptiontype(this);" id="inlineRadio03" value="3">3</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions0" onclick="choose_sampleoptiontype(this);" id="inlineRadio04" value="4">4</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions0" onclick="choose_sampleoptiontype(this);" id="inlineRadio05" value="5">5</div>' +
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Grey-Sodium flurodie</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions1" onclick="choose_sampleoptiontype(this);" id="inlineRadio10" value="0" checked="checked">0</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions1" onclick="choose_sampleoptiontype(this);" id="inlineRadio11" value="1">1</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions1" onclick="choose_sampleoptiontype(this);" id="inlineRadio12" value="2">2</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions1" onclick="choose_sampleoptiontype(this);" id="inlineRadio13" value="3">3</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions1" onclick="choose_sampleoptiontype(this);" id="inlineRadio14" value="4">4</div>' +
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Lavender - EDTA</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions2" onclick="choose_sampleoptiontype(this);" id="inlineRadio20" value="0" checked="checked">0</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions2" onclick="choose_sampleoptiontype(this);" id="inlineRadio21" value="1">1</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions2" onclick="choose_sampleoptiontype(this);" id="inlineRadio22" value="2">2</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions2" onclick="choose_sampleoptiontype(this);" id="inlineRadio23" value="3">3</div>' +
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Blue-Sodium citrate</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions3" onclick="choose_sampleoptiontype(this);" id="inlineRadio30" value="0" checked="checked">0</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions3" onclick="choose_sampleoptiontype(this);" id="inlineRadio31" value="1">1</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions3" onclick="choose_sampleoptiontype(this);" id="inlineRadio32" value="2">2</div>' +
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Black-ESR</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions4" onclick="choose_sampleoptiontype(this);" id="inlineRadio40" value="0" checked="checked">0</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions4" onclick="choose_sampleoptiontype(this);" id="inlineRadio41"  value="1">1</div>' +
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Urine Container-30 ML</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions5" onclick="choose_sampleoptiontype(this);" id="inlineRadio50" value="0" checked="checked">0</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions5" onclick="choose_sampleoptiontype(this);" id="inlineRadio51" value="1">1</div>' +
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Stool Container-30 ML</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions6" onclick="choose_sampleoptiontype(this);" id="inlineRadio60" value="0" checked="checked">0</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions6" onclick="choose_sampleoptiontype(this);" id="inlineRadio61" value="1">1</div>' +
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Green-Heparin</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions7" onclick="choose_sampleoptiontype(this);" id="inlineRadio70" value="0" checked="checked">0</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions7" onclick="choose_sampleoptiontype(this);" id="inlineRadio71" value="1">1</div>' +
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Sputurm Container</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions8" onclick="choose_sampleoptiontype(this);" id="inlineRadio80" value="0" checked="checked">0</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions8" onclick="choose_sampleoptiontype(this);" id="inlineRadio81" value="1">1</div>' +
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Green-Aerobic</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions9" onclick="choose_sampleoptiontype(this);" id="inlineRadio90" value="0" checked="checked">0</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions9" onclick="choose_sampleoptiontype(this);" id="inlineRadio91" value="1">1</div>' +
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Orange-Anarobic</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions10" onclick="choose_sampleoptiontype(this);" id="inlineRadio100" value="0" checked="checked">0</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions10" onclick="choose_sampleoptiontype(this);" id="inlineRadio101" value="1">1</div>' +
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Urine Container-5 L</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions11" onclick="choose_sampleoptiontype(this);" id="inlineRadio110" value="0" checked="checked">0</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions11" onclick="choose_sampleoptiontype(this);" id="inlineRadio111" value="1">1</div>' +
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Yellow-SST GEL</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions12" onclick="choose_sampleoptiontype(this);" id="inlineRadio120" value="0" checked="checked">0</div>' +
                '<div class="col-md-1" ><input type="radio" name="RadioOptions12" onclick="choose_sampleoptiontype(this);" id="inlineRadio121" value="1">1</div>' +
                '</div>' +
                '<div class="row">' +
                '<div class="col-md-4" ><label>Barcode</label></div>' +
                '<div class="col-md-1" ><label>:</label></div>' +
                '<div class="col-md-1" >';
                 if((typeof barcodedata.ordersList.data[0].order.patientinfo.barcode != "undefined")){
                      body_data += '<input type="textbox" name="barcode" id="bar_code" value="'+barcodedata.ordersList.data[0].order.patientinfo.barcode.barcode[0]+'">';
                 }else{
                     body_data += '<input type="textbox" name="barcode" id="bar_code" placeholder="Enter Barccode" value="">';
                 }
                   
                '</div>';

        footer_data +=
                '<div class="row">' +
                '<div class="col-md-3" ></div>' +
                '<div class="col-md-1" ></div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-primary"  Style="width:85px;" onclick="samplecollection_submission('+barcodedata.ordersList.data[0]._id+');">Submit</button>' +
                '</div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-warning"  Style="width:85px;" data-dismiss="modal">Cancel</button>' +
                '</div>' +
                '</div>' +
                '</div>';
        
           // alert(sampleType[i]);
            
         

        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        
        //for radiobuttons checking
        for (var i = 0; i < 13; i++) { 
            if(sampleType!=null && (typeof (sampleType[i]) != "undefined")){   
            $radioValue = sampleType[i];
              $('input[name=RadioOptions'+i+']').removeAttr('checked');//first unchecking all the radiobuttons of each row
              $("#inlineRadio"+i+$radioValue).prop("checked",true);//by using id we are checking radio button 
            }
        }
        
        $("#commonModal").modal("show");
        $('.loading').hide();
        }

    var sample_colletions_array = [];
    var totalSample = 13;
    var isSelectAnySample=0;
    
    function choose_sampleoptiontype(obj) {
        
        var Samples=[];
        for (var i = 0; i < totalSample; i++) {  
                if(typeof($('input[name=RadioOptions'+i+']:checked').val())!="undefined"){                
                       if($('input[name=RadioOptions'+i+']:checked').val()>0 && isSelectAnySample==0){
                           isSelectAnySample=1;
                       }
                Samples.push($('input[name=RadioOptions'+i+']:checked').val());
                
              }else{
                alert("Please select the sample.");
                return;
            }
        }
        if(isSelectAnySample==0 || Samples.length!=13){
            alert("Please select the sample.");
            return;
        }else{
            sample_colletions_array = Samples;
        }
            console.log(sample_colletions_array);    
    }

    function samplecollection_submission(OrderID) {
     
         if(sample_colletions_array.length === 0){
             sample_colletions_array = ["0","0","0","0","0","0","0","0","0","0","0","0","0"];
         }
           if(isSelectAnySample === 0 && sampleType != null){
                  sample_colletions_array = sampleType.slice();
           }
         console.log(sample_colletions_array);
         var barcode = $("#bar_code").val();
         if (barcode == "") {
              alert('Please enter the barcode.');
              return false;
         }
         if (sample_colletions_array.length >= 14) {
                alert('only 13 samples are allowed');
                return false;
         }
         var _data = {
                order_id: OrderID,
                option: 3,
                barcode: barcode,
                sampleType: sample_colletions_array,
                status:102,
                source:"PHELP",
                comment:"",
                actionById:sessionStorage.getItem('escalation_dashboard_user_id'),
                actionByName:sessionStorage.getItem('escalation_dashboard_user_name'),
                latitude:21.34539,
                longitude:78.456456
                
          };
         console.log(_data); 
         _ajaxEventHandler("samplecollections_submission", _data, commonSuccessResponse);
    }
    
  
    
    function sendOTPforsamplesubmission(){
        var mobileno = $("#pickup_boy_mobile").val();
        var isnum = /^\d+$/.test(mobileno);
        if (mobileno == "") {
             alert('Please enter the mobile No.');
             return false;
        }
        if(isnum == false || mobileno.length >=11){
             alert('Please enter only 10 digits.');
             return false;
        }

        var _data = {
            method:"api/otp/generate",
            type:"post",
            mobile:mobileno,
            email:"callhealth77test@gmail.com",
            keyValue:"MHO00213",
            keyType:"ISP",
            sourceType:"Mobile-APP"
        };
            console.log(_data);
         _ajaxEventHandler("send_verify_samplesubmit_OTP", _data, resOf_send_verifyOTP);
    }

 
   var isOTPVerified=0;
   function verifyOTPforsamplesubmission(){
        var OTPvalue = $("#pickup_boyOTP").val();
        //alert(OTPvalue);
        var mobileno = $("#pickup_boy_mobile").val();
            if (OTPvalue == "") {
                alert('Please enter the OTP.');
                return false;
            }
            if (mobileno == "") {
                alert('Please enter the mobile No.');
                return false;
            }
        var _data = {
            method:"api/otp/validate",
            type:"post",
            mobile:mobileno,
            email:"callhealth77test@gmail.com",
            keyValue:"MHO00213",
            keyType:"ISP",
            sourceType:"Mobile-APP",
            otp:OTPvalue
        };
            console.log(_data);
         _ajaxEventHandler("send_verify_samplesubmit_OTP", _data, resOf_send_verifyOTP);
    }
    
    function resOf_send_verifyOTP(response){
        console.log(response);
        response = JSON.parse(response);
        if(response.status == 1){
            if(response.message == "Valid Otp."){
                isOTPVerified = 1;
            }
            alert(response.message);
        }else{
           alert(response.message);
        }
    }
    
    function sample_submission() {
        var orderIDs = $("#sample_submission_orderids").val();
        var ordreids = orderIDs.split(',').map(Number);
        var pickUpBoyType = $("input[name='pickupboyRadioOptions']:checked").val();
        var pickUpBoyName = $("#pickup_boy_name").val();
        var pickUpBoyNo = $("#pickup_boy_mobile").val();
        if (isOTPVerified == 1) {      
            var _data = {
                order_id: ordreids,
                status:103,
                source:"Doctor",
                comment:"",
                actionById:sessionStorage.getItem('escalation_dashboard_user_id'),
                actionByName:sessionStorage.getItem('escalation_dashboard_user_name'),
                latitude:21.34539,
                longitude:78.456456,
                pickUpBoyName:pickUpBoyName,
                pickUpBoyNo:pickUpBoyNo,
                pickUpBoyType:pickUpBoyType
            };
           // console.log(_data);return
         _ajaxEventHandler("samplecollections_submission", _data, commonSuccessResponse);

        } else {
           alert('OTP not match,please check once and enter again');
           return false;
        }

    }
    
  
  function allEqual(arr) {
  return new Set(arr).size == 1;
}

  $("#samplesubmit_button").click(function (e) {
        e.preventDefault();
        var assocIDs =  [];
        var orderIDs = [];
        $("input:checkbox:checked").map(function () {
            orderIDs.push($(this).val());
            assocIDs.push($(this).attr("data-associate-id"));
           
        });
        var res = allEqual(assocIDs);
        if(allEqual(assocIDs)){}
        else{
            alert("Please select orders from the same LAB");
            return false;
        }
        console.log(orderIDs);
        console.log(assocIDs);
        sample_submission_popup(orderIDs);
      //  $('.loading').show();
       
    });
    
   function selectAll(){
    var selected=$('input[name="allorders_select"]:checked').val();
    if(selected){
        $('input[name="order_select"]').prop("checked", "checked");
    }else{
        $('input[name="order_select"]').prop("checked", false);
    }	
}

function uniqueselectAll(){
    var selected=$('input[name="order_select"]:checked').val();
    if(selected){
        $('input[name="allorders_select"]').prop("checked", false);
    }else{
       
    }	
}

    
</script>
</div>
</div>
</body>
</html>