<style>
    hr {
        border: none;
        height: 1px;
        /* Set the hr color */
        color: #333; /* old IE */
        background-color: #333; /* Modern Browsers */
    }
    .hidden {
        display:none;
    }
</style>
<?php
$date = date('Y-m-d H:i:s');
$date1 = date('Y-m-d');
?>
<div class="row" style="margin-top:10px;">		
    <div class="col-md-12" style="margin-top:10px;">
        <div class="col-md-12 no-padding-lft-rft custom-tab-nav" style="background:#ebf6f8; border-left: 1px solid #ddd; border-top: 1px solid #ddd;border-right: 1px solid #ddd; padding-top: 2px;">
            <form name="filterordr" method="post" action="<?php echo base_url(); ?>user/paymentcollections">
                <div class="col-md-12 no-padding-lft-rft">
                    <div class="col-md-4">	
                        <input type="hidden" name="searchdropdown" value="1" id="orderdropwownvalue">
                        <div class="col-md-6 no-padding-lft-rft">
                            <select size="1" name="search_type" id="orderdropwown" class="btn dropdown-toggle select_search_value form-control pull-left" aria-controls="example" id="filter_type" style="background-color: #7BAE4D; color: #FFFFFF;height:33px;">					
                                <option value="1" <?php if ($search_type == 1) {
    echo "selected";
} ?>>Order #</option>
                                
                                <option value="5" <?php if ($search_type == 5) {
    echo "selected";
} ?>>MRN</option>
                            </select>	
                        </div>					
                        <div class="col-md-6 no-padding-lft-rft">
                            <input class="searchauto-input form-control" value="<?php echo $search_txt; ?>" style="margin-top: 3px;height:28px;" id="ordertext" name="searchtext" type="text" autocomplete="off" placeholder="Search Text">
                        </div>
                    </div>

                    <div class="col-md-3 pull-left">
                        <span class="col-md-3 no-padding-lft-rft" style="margin-top:5px;">From: </span>
                        <div class="col-md-9 input-group">
                            <input class="searchauto-input form-control" value="<?php echo $from_dt; ?>" id="fromdate" name="fromdate" type="text" autocomplete="off" placeholder="Start Date">
                            <span class="input-group-addon sa-bordnone datepick">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                    </div>					
                    <div class="col-md-3 pull-left">
                        <span class="col-md-3 no-padding-lft-rft" style="margin-top:5px;">To: </span>
                        <div class="col-md-9 input-group">
                            <input class="searchauto-input form-control" value="<?php echo $to_dt; ?>" id="todate" name="todate" type="text" autocomplete="off" placeholder="End Date">
                            <span class="input-group-addon sa-bordnone datepick">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-primary form-control" type="submit" id="btn_view_filters"><i class="icon-search icon-white"></i>&nbsp;<span class=" visible-desktop">Search</span></button>
                    </div>

                </div>
            </form>
        </div>
        <div class="col-md-12 no-padding-lft-rgt orderlist scroll" id="JS_main_content_scroll" style="border:1px solid #ddd;overflow: auto;">
            <ul class="nav navbar-nav symptoms " style="padding-top:10px; width:100%;">
                <li class="col-md-12 active" style="padding:10px;">
                    <table class="table table-striped table-bordered table-hover table-responsive" id="">
                        <thead>					
                            <tr>
                                <th style="text-align:center;">Order DID#</th>
                                <th style="text-align:center;">Ordered Date</th>
                                <th style="text-align:center;">Bill ID#</th>
                                <th style="text-align:center;">Bill Date</th>
                                <th style="text-align:center;">No of Receipts</th>
                                <th style="text-align:center;">Collected Amount</th>
                                <th style="text-align:center;">Submitted Amount</th>
                                <th style="text-align:center;">Due Amount</th>
                                <th style="text-align:center;">Actions</th>						
                            </tr>						
                        </thead>
                        <tbody>
                            <?php
                            $i = 0;
                            //echo "<pre>";
                           // print_r($ordersList);exit;
                            if (isset($ordersList) && $ordersList->status == 1) {
                                foreach ($ordersList->data as $order) {
                                    if(empty($order->orderDetails))
                                    {
                                        continue;
                                    }
                                    //print_r($order->orderDetails);//exit;
                                    $reciptinfo = isset($order->billing) ? $order->billing->receiptinfo : 0;
                                    //$reciptinfo = json_decode($reciptinfo, true);
                                    if (is_array($reciptinfo) && isset($reciptinfo[0])) {
                                        $receiptcount = count($reciptinfo);
                                    } else {
                                        $receiptcount = 0;
                                    }
                                    $orderddate = date("Y-m-d h:i a", strtotime($order->orderDetails[0]->order->order_status->created_date));
                                    $billingdate = "";
                                    if (isset($order->billing)) {
                                        $billingdate = explode(".", str_replace("T", " ", $order->billing->billinginfo->billing_date));
                                        $billingdate = date("Y-m-d h:i a", strtotime($billingdate[0]));
                                    }

                                    $collected_amount = 0;
                                    $submitted_amount = 0;
                                    $due_amount = 0;
                                    echo "<tr>";
                                    echo "<td style='text-align:center;'>" . $order->billing->billinginfo->order_did . "</td>";
                                    echo "<td style='text-align:center;'>" . $orderddate . "</td>";
                                    echo "<td style='text-align:center;'>" . (isset($order->billing->billinginfo->billingid) ? $order->billing->billinginfo->billingid : '') . "</td>";
                                    echo "<td style='text-align:center;'>" . $billingdate . "</td>";
                                    $i = $i + 1;
                                    if (isset($order->billing->receiptinfo) && $receiptcount > 0) {
                                        foreach ($reciptinfo as $recipt) {
                                            $collected_amount = (float) $collected_amount + (float) $recipt->receipt_amount;
                                            if (isset($recipt->payment_collected) && (float) $recipt->payment_collected > 0) {
                                                $submitted_amount = (float) $submitted_amount + (float) $recipt->receipt_amount;
                                            }
                                        }
                                        $due_amount = (float) $collected_amount - $submitted_amount;
                                        $collected_amount = number_format((float) (floor($collected_amount)), 2, '.', '');
                                        $submitted_amount = number_format((float) (floor($submitted_amount)), 2, '.', '');
                                        $due_amount = number_format((float) (floor($due_amount)), 2, '.', '');
                                    }
                                    echo "<td style='text-align:center;'>" . $receiptcount . "</td>";
                                    echo "<td style='text-align:center;'>" . $collected_amount . "</td>";
                                    echo "<td style='text-align:center;'>" . $submitted_amount . "</td>";
                                    echo "<td style='text-align:center;'>" . $due_amount . "</td>";
                                    echo "<td style='text-align:center;'><button class='btn btn-success btn-sm' onclick='openreceipt(" . $i . ")' name='btnAdd' class='span1'><span class='glyphicon glyphicon-ok'></span></button></td>";
                                    echo "</tr>";
                                    ?>
                                    <tr style="background-color:#EBF6F8; display:none;" id="<?php echo "receiptbox" . $i; ?>"><td colspan="10" align="center">
                                            <br><table class="table" border="1" style="border-color:#fff;  width:90%; background-color:#FBFDFD;">
                                                <thead>					
                                                    <tr>
                                                        <th style="text-align:center;">Recipt Id#</th>
                                                        <th style="text-align:center;">Recipt  Date</th>
                                                        <th style="text-align:center;">Payment Mode</th>
                                                        <th style="text-align:center;">Amount</th>
                                                        <!--th style="text-align:center;">Paid Amount</th>
                                                        <th style="text-align:center;">Cancled  Amount</th>
                                                        <th style="text-align:center;">Due Amount</th-->
                                                        <th style="text-align:center;">MHO Name</th>
                                                        <th style="text-align:center;">Action</th>
                                                    </tr>						
                                                </thead>
                                                <tbody>					
                                                    <?php
                                                    if (isset($order->billing->receiptinfo) && $receiptcount > 0) {
                                                        foreach ($reciptinfo as $recipt) {
                                                            $recipt_id = isset($recipt->receipt_id) ? $recipt->receipt_id : 'Na';

                                                            $recipt_date = explode(".", str_replace("T", " ", $recipt->receipt_date));
                                                            $recipt_date = date("Y-m-d h:i a", strtotime($recipt_date[0]));
                                                            $payment_mode = isset($recipt->payment_mode) ? $recipt->payment_mode : 'Na';
                                                            $receipt_amount = isset($recipt->receipt_amount) ? $recipt->receipt_amount : 'Na';
                                                            //$netamount = isset($billinginfo->net_amount) ? $billinginfo->net_amount : 'Na';
                                                            //$paidamount = isset($billinginfo->paid_amount) ? $billinginfo->paid_amount : 'Na';
                                                            //$cancledamount = isset($billinginfo->cancelled_amount) ? $billinginfo->cancelled_amount : 'Na';
                                                            //$dueamount = isset($billinginfo->due_amount) ? $billinginfo->due_amount : 'Na';
                                                            $mhoname = isset($recipt->mho_name) ? $recipt->mho_name : 'Na';

                                                            echo "<tr>";
                                                            echo "<td style='text-align:center;'>" . $recipt_id . "</td>";
                                                            echo "<td style='text-align:center;'>" . $recipt_date . "</td>";
                                                            echo "<td style='text-align:center;'>" . $payment_mode . "</td>";
                                                            echo "<td style='text-align:center;'>" . $receipt_amount . "</td>";
                                                            //echo "<!--td style='text-align:center;'>".$paidamount."</td>";
                                                            //echo "<td style='text-align:center;'>".$cancledamount."</td>";
                                                            //echo "<td style='text-align:center;'>".$dueamount."</td-->";
                                                            echo "<td style='text-align:center;'>" . $mhoname . "</td>";

                                                            if ($sessiondata['type'] != "superadmin") {
                                   
                                                                if (strtolower($payment_mode) == 'cash' && (int) $recipt->payment_submited < 1 && (int) $recipt->payment_collected > 0) {
                                                                    echo "<td style='text-align:center;'><button class='btn btn-success btn-sm' onclick='received_money(\"" . $sessiondata['username'] . "\",\"" . $sessiondata['userid'] . "\",\"" . $recipt_id . "\",\"" . $order->billing->billinginfo->billingid . "\")' name='btnAdd' class='span1'> Payment Received </button></td>";
                                                                } else {
                                                                    echo "<td style='text-align:center;'>Na</td>";
                                                                }
                                                                echo "</tr>";
                                                                ?>
                                            <?php }
                                        }
                                    } ?>

                                                </tbody>
                                            </table><br>
                                        </td></tr>
    <?php
    }
} else {
    echo "<tr align='center'><td colspan='10' style='color:red;font-size:25px;'>No Data Found </td></tr>";
}
?>
                        </tbody>
                    </table>
                </li>
            </ul>
        </div>					
    </div>
</div>	
<div id="myDIV">

</div>

<script>
    function billrecipt_details(billlid) {
        var x = document.getElementById("myDIV");
        if (x.style.display === "none") {
            x.style.display = "block";
        } else {
            x.style.display = "none";
        }
    }
</script>
