<?php
$page = $_SERVER['PHP_SELF'];
$sec = "60";
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Page Auto refresh meta tag --->
        <!--meta http-equiv="refresh" content="<?php echo $sec ?>;URL='<?php echo $page ?>'"-->

        <title>Escalation Dashboard</title>
        <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/css/datepicker.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/css/bootstrap-datetimepicker.css" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/fonts/open-sans/open-sans.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-glyphicons.css">
        <link href="<?php echo base_url(); ?>assets/css/common-doc-styles.min.css" rel="stylesheet">

        <script src="<?php echo base_url(); ?>assets/js/jquery-1.11.0.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
        <!--script src="<?php echo base_url(); ?>assets/js/custom.js"></script-->
        <script src="<?php echo base_url(); ?>assets/js/bootstrap-datepicker.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/bootstrap-datetimepicker.js"></script>

        <!-- Dropdown multiselect CSS & JS  -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>

        <style>
            .slick-track{
                width: 737px !important;
            }
            #dataTables-example_paginate{
                border:0px solid #ccc; padding:5px 10px;
            }

            #dataTables-example_paginate a{
                font-style:bold; font-size:15px; padding:3px;
                cursor:pointer;
                text-decoration:none;
            }

            #dataTables-example_paginate span a.paginate_button{
                padding:3px 6px; background-color:#ccc; margin:0px 1px;
            }
            #dataTables-example_paginate span a.current{
                padding:3px 6px; background-color:#65b43d; margin:0px 1px;
            }

            .loading {
                margin: 0 auto 0;
                text-align: center;
                width: 100%;
                background-color:#000;
                opacity:0.6;
                height:100%;
                position:absolute;
                z-index:999;
                display:none;
            }
            .img_sc {
                margin: 15% auto 0;
                opacity: 1;
                z-index: 99999;
            }
            #selectionList1{ height: 365px !important; }
            .navbar { margin-bottom: 0px !important;}

            .bdr { border-top:solid 1px #ccc; padding-top:10px;}
            .bdr:first-child { border-top:none; padding-top:0px;}
            .orderlist {
                max-height: 405px;
                overflow: scroll;
            }

            nav ul {
                display       : inline-block;
                float     	  : center;
                overflow      : hidden;
                padding       : 0; 
                text-decoration  : none; 
            }

            nav li {
                display         : inline-block;	
                list-style-type : none;
                text-decoration  : none; 
            }

            nav a {
                display          : block;
                text-decoration  : none; 
                color            : #676767;
                font-size        : 11pt;	
                width            : 150px;
                text-align       : center;
            }
            .activemenu {
                display          : block;	
                text-decoration  : none;  
                color            : #FFFFFF;
                font-size        : 11pt;
                background-color : #7BAE4D;	
                width            : 130px;
                text-align       : center;
                height           : 35px;
            }
            .inactivemenu {
                display          : block;	
                text-decoration  : none;  
                color            : #FFFFFF;
                font-size        : 11pt;
                background-color : #337ab7;	
                width            : 130px;
                text-align       : center;
                height           : 35px;
            }

            nav img {
                display : block;
                margin  : 0 auto;
            }
            .navbar-default {
                background-color: #fff !important;
                border-color: #fff !important;
            }
            .select2{
                width: 590px !important;
            }
        </style>
    </head>
    <body>
        <div class="loading">
            <img class="img_sc" align="middle" src="<?php echo base_url(); ?>assets/images/ajax_loader.gif">
        </div>
        <div class="container-fluid">
            <div class="row">
                <header class="top-header">		
                    <div class="col-md-12">
                        <div class="col-md-3">		
                            <a href="#"><img src="<?php echo base_url(); ?>assets/images/logo_2.png"></a>
                        </div>
                        <div class="col-md-9">
                            <div class="header-right">
                                <ul class="nav navbar-nav navbar-right">

                                    <li>
                                        <form method="POST" action="<?php echo base_url(); ?>user/citySearch">
                                            <?php if ($sessiondata["type"] == "superadmin") { ?>
                                                <select class="js-example-basic-multiple form-control"name="cities[]" multiple="multiple" id="dropdowncityList" data-live-search="true" data-style="btn-success">	
                                                    <?php
                                                       // print_r($cityList);exit;
                                                    if ($sessiondata["type"] == "superadmin") {
                                                        /* $popid = isset($sessiondata["popId"])?$sessiondata["popId"]:"0";
                                                          if($popid==$pops->popinfo->FACILITY_ID){
                                                          echo '<option selected value="0">ALL</option>';
                                                          }else{
                                                          echo '<option value="0">ALL</option>';
                                                          } */
                                                        foreach ($cityList as $cities) {
                                                            echo '<option value="' . $cities . '" ';
                                                            /* if(isset($popid) && $popid==$pops->popinfo->FACILITY_ID){
                                                              echo 'selected';
                                                              } */
                                                            echo ' >' . $cities . '</option>';
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            <?php } ?>
                                            <input type="hidden" name="pagename" id="pagename" value="<?= $menu ?>">
                                            <input type="hidden" name="fromDate" id="fromDate" value="<?= $from_dt ?>">
                                            <input type="hidden" name="toDate" id="toDate" value="<?= $to_dt ?>">
                                            <input type="hidden" name="fromdatesearch" id="fromdatesearch" value="">

                                            <button class="btn btn-primary" value="" id="">Search</button>
                                            <!-- <a class="btn btn-default active" value="" id="" href="">Search</a>-->&nbsp;
                                        </form>
                                    </li>	

                                    <li>Welcome <span class="span-blue"><b><?php echo $sessiondata['username']; ?></b></span></li>
<!--					<li class="dropdown" id="fat-menu"><span class="caret dropdown-toggle " data-toggle="dropdown" id="drop3"></span>
                                            <ul aria-labelledby="drop3" role="menu" class="dropdown-menu">
                                                    <li role="presentation"><a href="#" tabindex="-1" role="menuitem"><i class="fa fa-fw fa-user"></i>Profile</a></li>
                                                    <li role="presentation"><a href="#" tabindex="-1" role="menuitem"><i class="fa fa-fw fa-envelope"></i>Inbox</a></li>
                                                    <li role="presentation"><a href="#" tabindex="-1" role="menuitem"><i class="fa fa-fw fa-gear"></i>Settings</a></li>
                                                    <li class="divider" role="presentation"></li>
                                                    <li role="presentation"><a href="<?php echo base_url(); ?>user/logout" tabindex="-1" role="menuitem"><i class="fa fa-fw fa-power-off"></i>Logout</a></li>
                                            </ul>
                                    </li>-->
                                    <li>
                                        <a href="#" style="padding: 0px;color:#000;"><i class="fa fa-home fa-1x"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </header>
            </div>	
