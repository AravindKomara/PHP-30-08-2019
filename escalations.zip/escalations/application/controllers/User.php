<?php

include(APPPATH . 'controllers/ConfigEscalation.php');

class User extends ConfigEscalation {

    public function __construct() {
        parent::__construct();
        $this->load->library('pdf');
    }

    public function index() {
        $getheaderinfo = $this->input->request_headers();
        if (isset($getheaderinfo["Referer"])) {
            $Referer = preg_replace('/[^A-Za-z0-9\-]/', '', $getheaderinfo["Referer"]);
            //if(in_array($Referer, Associate_adminURLs)){
            if (strpos($Referer, associate_url) !== false || strpos($Referer, associate_url1) !== false) {
            //if (strpos($Referer, associate_url) !== false) {
                //for associate
                if ($this->input->get("session") !== null) {
                    //validate associate admin
                    $r = $this->validate_the_request("associate_admin", $this->input->get("session")); //validating cookies
                    if ($r == "1") {
                        redirect('user/pending');
                    } else {
                        $this->logout();
                    }
                } else {
                    $this->logout();
                }
            }

            // else if(in_array($Referer, Super_adminURLs)){
            else if (strpos($Referer, sec_url) !== false) {

                //for SEC - super admin
                if ($_COOKIE["_chz_id"] != null) {
                    //validate
                    $r = $this->validate_the_request("superadmin", $_COOKIE["_chz_id"]); //validating cookies
                    if ($r == "1") {
                        if ($_GET['type'] == "finance_admin/") {//for refunds case
                            // print_r($_GET['type']);exit;
                            redirect('user/refunds'); //redirecting to refunds page
                        } else {
                            redirect('user/pending');
                        }
                    } else {
                        $this->logout();
                    }
                } else {
                    $this->logout();
                }
            }
            // else if(in_array($Referer, Super_adminURLs)){
            else if (strpos($Referer, oms_url) !== false) {
                $data = array(
                    'userid' => "T10326",
                    'username' => "Aravind Komara",
                    'type' => 'superadmin',
                    'popId' => "0",
                    'admin_type' => "superadmin"
                );
                $this->session->set_userdata('userinfo', $data);
                if ($_GET['type'] == "finance_admin") {
                    $data = array(
                    'userid' => "T10326",
                    'username' => "Aravind Komara",
                    'type' => 'finance_admin',
                    'popId' => "0",
                    'admin_type' => "finance_admin"
                         
                );
                    $this->session->set_userdata('userinfo', $data);
                    redirect('user/refunds');
                } else {
                    redirect('user/pending');
                }
            } else {
                $this->logout();
            }
        } else {
            $this->logout();
        }
    }

    public function trackorder() {
        if ($this->input->is_ajax_request()) {
            $orderid = $this->input->post('orderid');
            $parameter["status"] = "1";
            $parameter['order_id'] = $orderid;
            $url = serverhostpath . "OMS/api/operation.php/v1/ordertrack";
            $header = array('Content-Type: application/json');
            $param = json_encode($parameter);
            $data = $this->common_curl_call($url, $param, $header, "post");
            echo $data;
        } else {
            $data = array("status" => "0", "message" => "Order tracking details are not avaliable");
            echo json_encode($data);
        }
    }

    public function getorderinformation() {
        $data = array("status" => "0", "data" => array());
        $userinfo = $this->session->userdata('userinfo');
        if (isset($userinfo['popId'])) {
            $orderid = $this->input->post("orderid");
            $data["status"] = "1";
            $data["data"] = $this->filterData(array("orderid" => $orderid));
            //print_r($data);exit;
            echo json_encode($data);
        } else {
            echo json_encode($data);
        }
    }
    

    public function pending() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "pending");
        $userinfo = $this->session->userdata('userinfo');
        $this->updatesession($userinfo);
        // print_r($userinfo);exit;
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            //print_r($parameter);exit;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        //print_r($parameter);exit;
        $data['menu'] = "pending";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();

        $data['cityList'] = $this->getallcities();
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
        //print_r($data['cityList']);exit;
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view('pending');
        $this->load->view("footer");
    }

    public function reallocate() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "reallocate");
        $userinfo = $this->session->userdata('userinfo');
        $this->updatesession($userinfo);
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            //print_r($parameter);exit;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        // print_r($parameter);
        $data['menu'] = "reallocate";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();
        $data['popList'] = $this->getallpop();
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
        $data['cityList'] = $this->getallcities();
        //  print_r($data["ordersList"]);exit;
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view('reallocate');
        $this->load->view("footer");
    }

    public function tobeassigned() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "tobeassigned");
        $userinfo = $this->session->userdata('userinfo');
        $this->updatesession($userinfo);
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        $data['menu'] = "tobeassigned";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();
        $data['popList'] = $this->getallpop();
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
        $data['cityList'] = $this->getallcities();
        //print_r($data);exit;
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view('tobeassign');
        $this->load->view("footer");
    }

    public function completed() {
        date_default_timezone_set("Asia/Kolkata");
        $userinfo = $this->session->userdata('userinfo');
        $parameter = array("pagename" => "completed");
        //$parameter['componentType'] = "";
        $parameter['status'] = 1;
        $this->updatesession($userinfo);
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $business_search_type = $this->input->post('business_searchdropdown');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            $parameter["business_search_type"] = $business_search_type;
            
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['business_search_type'] = $business_search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['business_search_type'] = "all";
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        $data['menu'] = "completed";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();
        $data['popList'] = $this->getallpop();
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
        $data['cityList'] = $this->getallcities();
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view('completed');
        $this->load->view("footer");
    }

    public function printdocument() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "printdocument");
        $userinfo = $this->session->userdata('userinfo');
        $this->updatesession($userinfo);
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        $data['menu'] = "printdocument";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();
        $data['popList'] = $this->getallpop();
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
        $data['cityList'] = $this->getallcities();
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view('printdocument');
        $this->load->view("footer");
    }

    public function tobeconfirm() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "tobeconfirm");
        $userinfo = $this->session->userdata('userinfo');
        $this->updatesession($userinfo);
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        $data['menu'] = "tobeconfirm";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();
        $data['cityList'] = $this->getallcities();
        $data['popList'] = $this->getallpop();
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view('tobeconfirm');
        $this->load->view("footer");
    }

    public function approverequests() {
        $userinfo = $this->session->userdata('userinfo');
        $this->updatesession($userinfo);
        date_default_timezone_set("Asia/Kolkata");
        $parameter["api_key"] = chissapikey;
        $parameter["status"] = "3";
        if ($userinfo['type'] == 'associate_admin') {
            $parameter["associate_id"] = $userinfo['parent_userid'];
            $parameter["branch_id"] = $userinfo['userid'];
        } else {
            $parameter["associate_id"] = "";
            $parameter["branch_id"] = "";
        }
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["from_date"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["to_date"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $parameter["from_date"] = date('Y-m-d', strtotime(date('Y-m-d')));
            $parameter["to_date"] = date('Y-m-d', strtotime(date('Y-m-d')));
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        $url = chissurl . "api/get_officer_availability";
        $param = json_encode($parameter);
        //print_r($param);exit;
        $header = array('Content-Type: application/json');
        $data['officers'] = $this->common_curl_call($url, $param, $header, "post");
        $data['officers'] = json_decode($data['officers']);
        $data['menu'] = "approverequests";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['popList'] = $this->getallpop();
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
        $data['cityList'] = $this->getallcities();
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view('approverequests');
        $this->load->view("footer");
    }

    public function request_type() {
        $slotId = $this->input->post('slot_id');
        $type = $this->input->post('request_type');
        if ($type == 'accept') {
            $filter = array(
                "api_key" => chissapikey,
                "rejected_availability_ids" => array(),
                "approved_availability_ids" => array($slotId)
            );
        } else {
            $filter = array(
                "api_key" => chissapikey,
                "rejected_availability_ids" => array($slotId),
                "approved_availability_ids" => array()
            );
        }

        $data['request_type'] = $type;
        $data = json_encode($data);
        $url = $url = chissurl . "api/confirmofficeravailability";
        $param = json_encode($filter);
        $header = array('Content-Type: application/json');
        $data = $this->common_curl_call($url, $param, $header, "post");
        echo $data;
    }

    public function paymentcollections() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "paymentcollections");
        $userinfo = $this->session->userdata('userinfo');
        $this->updatesession($userinfo);
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data["ordersList"] = $this->filterData($parameter);
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        // print_r($parameter);exit;
        $data['menu'] = "paymentcollections";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();
        $data['cityList'] = $this->getallcities();
        $data['popList'] = $this->getallpop();
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
        //print_r($data["ordersList"]);exit;
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view('paymentcollections');
        $this->load->view("footer");
    }

    public function callhealthsubmissions() {
        date_default_timezone_set("Asia/Kolkata");
        $userinfo = $this->session->userdata('userinfo');
        $this->updatesession($userinfo);
      //print_r($userinfo);exit;
        $parameter = array("pagename" => "callhealthsubmissions");
        $parameter["submitted_to_CH"] = false;
        $recipt_search_type = $this->input->post('recipt_search_dropwown');
		//print_r($this->input->post()); exit;
		
		if(!isset($recipt_search_type)){
			$recipt_search_type="pending";
		}else{
			if($recipt_search_type=="completed"){
				$parameter["submitted_to_CH"] = true;
			}
		}		
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('search_type');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            // $parameter["search_type"] = $search_type;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['recipt_search_type'] = $recipt_search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['recipt_search_type'] = $recipt_search_type;
            $data["ordersList"] = $this->filterData($parameter);
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        // print_r($parameter);exit;
        // echo $data['recipt_search_type'];exit;
        $data['menu'] = "callhealthsubmissions";
        $data['recipt_search_type'] = $recipt_search_type;
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();
        $data['cityList'] = $this->getallcities();
        $data['popList'] = $this->getallpop();
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
        //print_r( $data['recipt_search_type']);exit;
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view('callhealthsubmissions');
        $this->load->view("footer");
    }

    public function refunds() {
        date_default_timezone_set("Asia/Kolkata");
        $userinfo = $this->session->userdata('userinfo');
        $this->updatesession($userinfo);
        //print_r($userinfo);exit;
        $this->session->set_userdata('userinfo', $userinfo);  //updating session information
        $parameter = array("pagename" => "refunds");
        $refunds_search_type = $this->input->post('refund_search_dropwown');
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            $parameter["refund_search_type"] = $refunds_search_type;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['refund_search_type'] = $refunds_search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['refund_search_type'] = 1;
            $data["ordersList"] = $this->filterData($parameter);
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }

        $data['menu'] = "refunds";
        $data['sessiondata'] = $userinfo;
        $data['refund_status'] = $this->refund_status();
        $data['popList'] = $this->getallpop();
        $data['cityList'] = $this->getallcities();
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo); //calling menu validation method
        //print_r($menuData['menuList']);exit;
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view('refunds');
        $this->load->view("footer");
    }

    public function reports() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "reports");
        $userinfo = $this->session->userdata('userinfo');
        $this->updatesession($userinfo);
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            //print_r($parameter);exit;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        //print_r($parameter);exit;
        $data['menu'] = "reports";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();
        $data['popList'] = $this->getallpop();
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
        $data['cityList'] = $this->getallcities();
        //print_r($data);exit;
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view('reports');
        $this->load->view("footer");
    }

    public function sample_collections() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "sample_collections");
        $userinfo = $this->session->userdata('userinfo');
        $this->updatesession($userinfo);
        $type = "";
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $type = $this->input->post('type');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            //print_r($parameter);exit;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        //print_r($parameter);exit;
        $data['menu'] = "sample_collections";
        $data['sessiondata'] = $userinfo;
        $data['business_name'] = $this->business_name();
        $data['cityList'] = $this->getallcities();
        $data['popList'] = $this->getallpop();
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
        //print_r($data);exit;
        if ($type == "sample_collection_popup_search") {
            $data = json_encode($data);
            echo $data;
        } else {
            $this->load->view('header', $data);
            $this->load->view('menu', $menuData);
            $this->load->view('sample_collections');
            $this->load->view("footer");
        }
    }

    public function sample_submissions() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "sample_submissions");
        $userinfo = $this->session->userdata('userinfo');
        $this->updatesession($userinfo);
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            //print_r($parameter);exit;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        //print_r($parameter);exit;
        $data['menu'] = "sample_submissions";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();
        $data['cityList'] = $this->getallcities();
        $data['popList'] = $this->getallpop();
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
        //print_r($data);exit;
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view('sample_submissions');
        $this->load->view("footer");
    }
    
    public function thirdparty_collections() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "thirdparty_collections");
        $userinfo = $this->session->userdata('userinfo');
        $this->updatesession($userinfo);
        // print_r($userinfo);exit;
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            //print_r($parameter);exit;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        //print_r($parameter);exit;
        $data['menu'] = "thirdparty_collections";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();

        $data['cityList'] = $this->getallcities();
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
        //print_r($data['cityList']);exit;
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view('thirdparty_collections');
        $this->load->view("footer");
    }

    public function samplecollections_submission() {
        $userinfo = $this->session->userdata('userinfo');
        $requestData = array(
            "order_id" => $this->input->post('order_id'),
            "option" => (int) $this->input->post('option'),
            "barcode" => $this->input->post('barcode'),
            "sampleType" => $this->input->post('sampleType'),
            "status" => (int) $this->input->post('status'),
            "source" => $this->input->post('source'),
            "comment" => $this->input->post('comment'),
            "actionById" => $this->input->post('actionById'),
            "actionByName" => $this->input->post('actionByName'),
            "latitude" => $this->input->post('latitude'),
            "longitude" => $this->input->post('longitude'),
            "pickUpBoyName" => $this->input->post('pickUpBoyName'),
            "pickUpBoyNo" => $this->input->post('pickUpBoyNo'),
            "pickUpBoyType" => $this->input->post('pickUpBoyType')
        );
        $url = serverhostpath . 'OMS/api/operation.php/v1/order/change/status';
        $header = array('Content-Type: application/json');
        $requestData = json_encode($requestData);
        //echo $url;print_r($requestData);exit;
        $data = $this->common_curl_call($url, $requestData, $header, "POST");
        echo $data;
    }

    public function send_verify_samplesubmit_OTP() {
        $userinfo = $this->session->userdata('userinfo');
        $otp = $this->input->post('otp');
        $requestData = array(
            "method" => $this->input->post('method'),
            "type" => $this->input->post('type'),
            "mobile" => $this->input->post('mobile'),
            "email" => $this->input->post('email'),
            "keyValue" => $this->input->post('keyValue'),
            "keyType" => $this->input->post('keyType'),
            "sourceType" => $this->input->post('sourceType')
        );
        if ($otp != "") {
            $requestData['otp'] = $this->input->post('otp');
        };
        $url = choicepath."GenericAPIs";
        $header = array('Content-Type: application/json');
        $requestData = json_encode($requestData);
        //echo $url; print_r($requestData);exit;
        $data = $this->common_curl_call($url, $requestData, $header, "POST");
        echo $data;
    }

    public function submitReceiptPayment() {
        $userinfo = $this->session->userdata('userinfo');
        $requestData = $this->input->post('requestData');
        $requestData['associateId'] = '';
        $requestData['associateBranchId'] = '';
        $requestData['officerId'] = $userinfo['userid'];
        $requestData['officerName'] = $userinfo['username'];
        $url = serverhostpath .'OMS/api/operation.php/v1/phelpCashSubmission';
        $header = array('Content-Type: application/json');
        $requestData = json_encode($requestData);
        // print_r($requestData);exit;
        $data = $this->common_curl_call($url, $requestData, $header, "POST");
        echo $data;
        exit;
    }

    public function received_money() {
        $url = serverhostpath . "OMS/api/operation.php/v1/received_themoney_from_officer";
        $param = array(
            "recipt_id" => $this->input->post('recipt_id'),
            "billing_id" => $this->input->post('billing_id'),
            "user_name" => $this->input->post('user_name'),
            "user_id" => $this->input->post('user_id')
        );
        $param = json_encode($param);
        $header = array('Content-Type: application/json');
        $data = $this->common_curl_call($url, $param, $header, "post");
        echo $data;
    }

    public function getOfficers_list() {
		$userinfo = $this->session->userdata('userinfo');
        $order_id = $this->input->post('order_id');
        $scheduled_date = $this->input->post('scheduled_date');
        $workorder_id = $this->input->post('workorder_id');
        // $associate_id = $this->input->post('associate_id');
        // $branch_id = $this->input->post('branch_id');
		$associate_id = "";
		$branch_id="";
		if ($userinfo['type'] == 'associate_admin') {
			$associate_id = $userinfo['parent_userid']; //'parent_userid'
			$branch_id=$userinfo['userid']; //'userid'
		}
        $roleType = $this->input->post('roletype');
        $filter = array(
            "scheduled_date" => $scheduled_date,
            "order_id" => $order_id,
            "roleType" => $roleType,
            "associate_id" => $associate_id,
            "branch_id" => $branch_id
        );

        $url = serverhostpath . "OMS/api/operation.php/v1/fetch_officers";
        $param = json_encode($filter);
        $header = array('Content-Type: application/json');
        $data = $this->common_curl_call($url, $param, $header, "post");
        $data = json_decode($data);
        $data->orderid = $order_id;
        $data->scheduled_date = $scheduled_date;
        $data->workorder_id = $workorder_id;
        echo json_encode($data);
    }

    public function force_allocation() {
        $userinfo = $this->session->userdata('userinfo');

        //if(isset($userinfo['popId'])){
        $order_id = $this->input->post('order_id');
        $scheduled_date = $this->input->post('scheduled_date');
        $associate_id = $this->input->post('associate_id');
        $branch_id = $this->input->post('branch_id');
        $officer_id = $this->input->post('officer_id');
        $officer_name = $this->input->post('officer_name');
        $workorder_id = $this->input->post('workorder_id');

        if ($userinfo['type'] == 'superadmin') {
            $allocated_by = 1;
        } elseif ($userinfo['type'] == 'associate_admin') {
            $allocated_by = 2;
        }

        $order_info = array(
            "order_id" => (int) $order_id,
            "associate_id" => $associate_id,
            "workorder_id" => (int) $workorder_id,
            "branch_id" => $branch_id,
            "officer_id" => $officer_id,
            "officer_name" => $officer_name,
            "date_Changed" => false,
            "scheduled_date" => ''
        );

        $data = json_encode(
                array(
                    "allocated_by" => $allocated_by,
                    "assigning_officer_id" => $userinfo['userid'],
                    "assigning_officer_name" => $userinfo['username'],
                    "orders" => array($order_info)
                )
        );
        $url = serverhostpath . "OMS/api/operation.php/v1/orderallocation";
        //$param=json_encode($data);
        $header = array('Content-Type: application/json');
        $data = $this->common_curl_call($url, $data, $header, "post");
        echo $data;
    }

    public function print_document() {
        if ($this->input->is_ajax_request()) {
            $orderid = $this->input->post('orderid');
            $servicetypeid = $this->input->post('servicetypeid');
            $servicesubtypeid = $this->input->post('servicesubtypeid');
            $mrn = $this->input->post('mrn');
            $businessname = $this->input->post('businessname');
            $data["status"] = "1";
            $data['orderid'] = $orderid;
            $data['servicetypeid'] = $servicetypeid;
            $data['servicecubtypeid'] = $servicesubtypeid;
            $data['mrn'] = $mrn;
            $data['businessname'] = $businessname;
            echo json_encode($data);
        } else {
            $data = array("status" => "0", "message" => "no documents");
            echo json_encode($data);
        }
    }

    public function update_refundOrderStatus() {
        $userinfo = $this->session->userdata('userinfo');
        $requestData = array(
            "refund_id" => $this->input->post('refund_id'),
            "order_id" => $this->input->post('order_id'),
            "status" => (int) $this->input->post('status'),
            "transaction_type" => $this->input->post('transaction_type'),
            "transaction_code" => $this->input->post('transaction_code'),
            "amount" => (float) $this->input->post('amount'),
            "reason" => $this->input->post('reason'),
            "comment_text" => $this->input->post('comment_text'),
            "user_id" => $this->input->post('user_id'),
            "username" => $this->input->post('username'),
            "category" =>  $this->input->post('category'),
            "sub_category" => $this->input->post('sub_category'),
            "sub_category_description" => $this->input->post('sub_category_description'),
            "ticket_id" => $this->input->post('ticket_id')
        );
        $url = serverhostpath . 'OMS/api/operation.php/v1/update/refund/info';
        $header = array('Content-Type: application/json');
        $requestData = json_encode($requestData);
        // echo $url;
        //print_r($requestData);exit;
        $data = $this->common_curl_call($url, $requestData, $header, "POST");
        echo $data;
    }
    
    public function rejectRefundOrder() {
        $userinfo = $this->session->userdata('userinfo');
        $requestData = array(
            "order_id" => (int)$this->input->post('order_id'),
            "category" =>  $this->input->post('category'),
            "sub_category" => $this->input->post('sub_category'),
            "sub_category_description" => $this->input->post('sub_category_description')
            
        );
        $url = serverhostpath . 'OMS/api/operation.php/v1/generateTicket';
        //$url = serveruatv3path . 'OMS/api/operation.php/v1/generateTicket';
        $header = array('Content-Type: application/json');
        $requestData = json_encode($requestData);
        //echo $url; print_r($requestData);exit;
        $data = $this->common_curl_call($url, $requestData, $header, "POST");
        echo $data;
    }
    
    public function getCategorySubCataegory() {
        $url = serverhostpath . "OMS/api/operation.php/v1/requestForCallbackMdm";
        $data = $this->common_curl_call($url, "", "", "get"); //get method curl call
        echo $data;
     }

    public function completeReports() {
        $userinfo = $this->session->userdata('userinfo');
        $data = json_encode(
                array(
                    "order_id" => (string) $this->input->post('order_id'),
                    "actionById" => $userinfo['userid'],
                    "actionByName" => $userinfo['username'],
                    "source" => "Escaltion Dashboard",
                    "reasonType" => "1",
                    "latitude" => "",
                    "longitude" => "",
                    "status" => 6
                )
        );
        $url = serverhostpath . "OMS/api/operation.php/v1/order/change/status";
        // print_r(json_encode($data));exit;
        $header = array('Content-Type: application/json');
        $resposne = $this->common_curl_call($url, $data, $header, "post");
        echo $resposne;
    }

    public function refundOrder_recipts() {
        $order_id = (int) $this->input->post('order_id');
        $url = serverhostpath . "OMS/api/operation.php/v1/BillInfo";
        //echo $url;
        $param['order_id'] = $order_id;
        $param = json_encode($param);
        //print_r($param);exit;
        $header = array('Content-Type: application/json');
        $data = $this->common_curl_call($url, $param, $header, "post");
        echo $data;
    }

    //for invoice,homecare, drug bill print
    public function print_CommonInvoiceDocument() {
        $order_id = $this->uri->segment('3');
        $url = serverhostpath . "OMS/api/operation.php/v1/invoice?OrderID=$order_id";
        $data = $this->common_curl_call($url, "", "", "get"); //get method curl call
        //for downloading PDF file
        header('Cache-Control: public');
        header('Content-type: application/pdf');
        header('Content-Disposition: attachment; filename="invoice_' . $order_id . '.pdf"');
        header('Content-Length: ' . strlen($data));
        echo $data;
    }

    //for prescription,care@home, assement order bill
    public function print_CommonPrescriptionDocument() {
        $order_id = $this->uri->segment('3');
        $url = serverhostpath . "OMS/api/operation.php/v1/prescriptionprint?OrderID=$order_id";
        $data = $this->common_curl_call($url, "", "", "get"); //get method curl call
        //print_r($data);exit;
        header('Cache-Control: public');
        header('Content-type: application/pdf');
        header('Content-Disposition: attachment; filename="Prescription_' . $order_id . '.pdf"');
        header('Content-Length: ' . strlen($data));
        echo $data;

    }

    public function convert_number_to_words($number) {
        $hyphen = '-';
        $conjunction = ' and ';
        $separator = ', ';
        $negative = 'negative ';
        $decimal = ' point ';
        $dictionary = array(
            0 => 'zero',
            1 => 'one',
            2 => 'two',
            3 => 'three',
            4 => 'four',
            5 => 'five',
            6 => 'six',
            7 => 'seven',
            8 => 'eight',
            9 => 'nine',
            10 => 'ten',
            11 => 'eleven',
            12 => 'twelve',
            13 => 'thirteen',
            14 => 'fourteen',
            15 => 'fifteen',
            16 => 'sixteen',
            17 => 'seventeen',
            18 => 'eighteen',
            19 => 'nineteen',
            20 => 'twenty',
            30 => 'thirty',
            40 => 'fourty',
            50 => 'fifty',
            60 => 'sixty',
            70 => 'seventy',
            80 => 'eighty',
            90 => 'ninety',
            100 => 'hundred',
            1000 => 'thousand',
            1000000 => 'million',
            1000000000 => 'billion',
            1000000000000 => 'trillion',
            1000000000000000 => 'quadrillion',
            1000000000000000000 => 'quintillion'
        );

        if (!is_numeric($number)) {
            return false;
        }

        if (($number >= 0 && (int) $number < 0) || (int) $number < 0 - PHP_INT_MAX) {
            // overflow
            trigger_error(
                    'Please enter numbers between -' . PHP_INT_MAX . ' and ' . PHP_INT_MAX, E_USER_WARNING
            );
            return false;
        }

        if ($number < 0) {
            return $negative . $this->convert_number_to_words(abs($number));
        }

        $string = $fraction = null;

        if (strpos($number, '.') !== false) {
            list($number, $fraction) = explode('.', $number);
        }

        switch (true) {
            case $number < 21:
                $string = $dictionary[$number];
                break;
            case $number < 100:
                $tens = ((int) ($number / 10)) * 10;
                $units = $number % 10;
                $string = $dictionary[$tens];
                if ($units) {
                    $string .= $hyphen . $dictionary[$units];
                }
                break;
            case $number < 1000:
                $hundreds = $number / 100;
                $remainder = $number % 100;
                $string = $dictionary[$hundreds] . ' ' . $dictionary[100];
                if ($remainder) {
                    $string .= $conjunction . $this->convert_number_to_words($remainder);
                }
                break;
            default:
                $baseUnit = pow(1000, floor(log($number, 1000)));
                $numBaseUnits = (int) ($number / $baseUnit);
                $remainder = $number % $baseUnit;
                $string = $this->convert_number_to_words($numBaseUnits) . ' ' . $dictionary[$baseUnit];
                if ($remainder) {
                    $string .= $remainder < 100 ? $conjunction : $separator;
                    $string .= $this->convert_number_to_words($remainder);
                }
                break;
        }

        if (null !== $fraction && is_numeric($fraction)) {
            $string .= $decimal;
            $words = array();
            foreach (str_split((string) $fraction) as $number) {
                $words[] = $dictionary[$number];
            }
            $string .= implode(' ', $words);
        }

        return $string;
    }
    
     public function print_collection_memo() {
         $order_id = $this->uri->segment('3');
       //print_r($order_id);exit;
        $url = serverhostpath . "OMS/api/operation.php/v1/sampleCollectionMemo?OrderID=$order_id";
        //echo $url;exit;
        $data = $this->common_curl_call($url, "", "", "get"); //get method curl call
        //for downloading PDF file
        header('Cache-Control: public');
        header('Content-type: application/pdf');
        header('Content-Disposition: attachment; filename="SampleCollection_memo_' . $order_id . '.pdf"');
        header('Content-Length: ' . strlen($data));
        echo $data;
     }
     
     public function citySearch(){
        $userinfo = $this->session->userdata('userinfo');
        $pagename = $this->input->post('pagename');
        $fromdatesearch = $this->input->post('fromdatesearch');
        $cityList = $this->input->post('cities');
        $this->updatesession($userinfo);
        $parameter = array(
                    "pagename" => $pagename,
                    "startDate" => date('Y-m-d', strtotime($this->input->post('fromDate'))),
                    "endDate" => date('Y-m-d', strtotime($this->input->post('toDate'))),
                    "cities" => $cityList
                );
        
        $data['from_dt'] = $this->input->post('fromDate');
        $data['to_dt'] = $this->input->post('toDate');
        if(!empty($fromdatesearch)){
           $parameter['startDate'] = date('Y-m-d', strtotime($this->input->post('fromdatesearch')));
           $data['from_dt'] =$this->input->post('fromdatesearch');
        }
       if(!empty($cityList)){       
           $data['cityList'] = $cityList;
        }else{
           $data['cityList'] = $this->getallcities();
        }
        $data["ordersList"] = $this->filterData($parameter);
       // print_r( $data["ordersList"]);exit;
        $data['menu'] = $pagename;
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();
        $data['search_txt'] = "";
        $data['search_type'] = 1;
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
       // print_r($data['popList']);exit;
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view($pagename);
        $this->load->view("footer");
        
       
       
     }
     
     
     
    
}
