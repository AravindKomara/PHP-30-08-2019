<?php

class ConfigEscalation extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function filterData($parameter) {
        //print_r($parameter);exit;
        $userinfo = $this->session->userdata('userinfo');
        $filterorderstatus = $this->mappingOrderStatuses();
       // print_r($filterorderstatus);exit;
        if (isset($userinfo["popId"])) {
            $filter = array("dateFilter" => "scheduled_date");
            date_default_timezone_set("Asia/Kolkata");
            $url = serverhostpath . "OMS/api/operation.php/v1/orders";
            
            if (isset($parameter["orderid"]) && $parameter["orderid"] != "") {
                $filter = array("order_id" => $parameter["orderid"]);
            } else {
                if (!isset($parameter['startDate'])) {
                    $filter['startDate'] = date("Y-m-d");
                    $filter['endDate'] = date("Y-m-d");
                } else {
                    $filter['startDate'] = $parameter["startDate"];
                    $filter['endDate'] = $parameter["endDate"];
                }
	
                if (isset($userinfo["popId"]) && $userinfo["popId"] != "0") {
                    $filter["facilityId"] = array($userinfo["popId"]);
                }

                if (isset($parameter["search_txt"])) {
                    if ($parameter["search_type"] == 1 && trim($parameter["search_txt"]) != "") {
                        $filter = array('order_did' => $parameter["search_txt"],"status"=>1);                  
                        $url = serverhostpath . "OMS/api/operation.php/v1/order/search";
                    } elseif ($parameter["search_type"] == 2 && trim($parameter["search_txt"]) != "") {
                        $filter = array('workorder_did' => $parameter["search_txt"],"status"=>1);
                        $url = serverhostpath . "OMS/api/operation.php/v1/order/search";
                    }elseif ($parameter["search_type"] == 3 && trim($parameter["search_txt"]) != "") {
                        $filter = array('patient_name' => $parameter["search_txt"],"status"=>1);
                         $url = serverhostpath . "OMS/api/operation.php/v1/order/search";
                    } elseif ($parameter["search_type"] == 4 && trim($parameter["search_txt"]) != "") {
                        $filter = array('officerId' => array($parameter["search_txt"]),"status"=>1);
                         $url = serverhostpath . "OMS/api/operation.php/v1/order/search";
                    } elseif ($parameter["search_type"] == 5 && trim($parameter["search_txt"]) != "") {
                        $filter = array('mrn' => $parameter["search_txt"],"status"=>1);
                         $url = serverhostpath . "OMS/api/operation.php/v1/order/search";
                    }
                }
                
                 if (isset($parameter["business_search_type"])) {
                     $parameter["business_search_type"] = (int)$parameter["business_search_type"];
                     if ($parameter["business_search_type"] == 1) {
                        $filter['componentType'] = $parameter["business_search_type"];
                    } elseif ($parameter["business_search_type"] == 2) {
                        $filter['componentType'] = $parameter["business_search_type"];
                    }elseif ($parameter["business_search_type"] == 3) {
                        $filter['componentType'] = $parameter["business_search_type"];
                    } elseif ($parameter["business_search_type"] == 4) {
                        $filter['componentType'] = $parameter["business_search_type"];
                    } elseif ($parameter["business_search_type"] == 5) {
                        $filter['componentType'] = $parameter["business_search_type"];
                    }
                 }
                
                //for getting cities
                 if (isset($parameter["cities"])) {
                     $filter["city"] = $parameter["cities"];
                 }

                if ($parameter["pagename"] == "pending") {
                    $filter["orderStatus"] = $filterorderstatus[$parameter["pagename"]]['filterstatues'];
                } else if ($parameter["pagename"] == "reallocate") {
                    $filter["orderStatus"] = $filterorderstatus[$parameter["pagename"]]['filterstatues'];
                } else if ($parameter["pagename"] == "tobeassigned") {
                    $filter["orderStatus"] = $filterorderstatus[$parameter["pagename"]]['filterstatues'];
                } else if ($parameter["pagename"] == "completed") {
                    $filter["orderStatus"] = $filterorderstatus[$parameter["pagename"]]['filterstatues'];    
                } else if ($parameter["pagename"] == "printdocument") {
                    $filter["orderStatus"] = $filterorderstatus[$parameter["pagename"]]['filterstatues'];
                } else if ($parameter["pagename"] == "tobeconfirm") {
                    $filter["orderStatus"] = $filterorderstatus[$parameter["pagename"]]['filterstatues'];
                } else if ($parameter["pagename"] == "paymentcollections") {
                    $url = serverhostpath . "OMS/api/operation.php/v1/receipts/cash";    
                } else if ($parameter["pagename"] == "callhealthsubmissions") {
                    $filter["submitted_to_CH"] = $parameter["submitted_to_CH"];
                    if (isset($parameter["search_txt"]) && (int)$parameter["search_type"]==1) {
                            $filter["search_type"] = $parameter["search_type"];
                            $filter["search_txt"] = $parameter["search_txt"];
                    }
                    $url = serverhostpath . "OMS/api/operation.php/v1/receiptsPendingToCH";
                } else if ($parameter["pagename"] == "sample_collections") {
                    $filter["businessId"] = array("3");
                    $filter["orderStatus"] = $filterorderstatus[$parameter["pagename"]]['filterstatues'];
                    
                } else if ($parameter["pagename"] == "sample_submissions") {
                    $filter["businessId"] = array("3");
                    $filter["orderStatus"] = $filterorderstatus[$parameter["pagename"]]['filterstatues'];
                    
                } else if ($parameter["pagename"] == "reports") {
                    $filter["businessId"] = array("3");
                    $filter["orderStatus"] = $filterorderstatus[$parameter["pagename"]]['filterstatues'];
                } else if ($parameter["pagename"] == "refunds") {
                    $url = serverhostpath . "OMS/api/operation.php/v1/order/refund";
                    if (isset($parameter["refund_search_type"]) && !empty($parameter["refund_search_type"])) {
                        $filter["search_refund_status"] = $parameter["refund_search_type"];
                        $filter["type"] = "REFUND";
                    } else {
                        $filter["search_refund_status"] = 1;
                    }
                }else if ($parameter["pagename"] == "thirdparty_collections") {
                    $filter["businessId"] = array("3");
                    $filter["orderStatus"] = $filterorderstatus[$parameter["pagename"]]['filterstatues'];
                }
            }

            if ($userinfo["type"] == 'associate_admin') {
                $filter["associateId"] = $userinfo["parent_userid"];
                $filter["associateBranchId"] = $userinfo["userid"];
            } else {
                $filter["associateId"] = "";
                $filter["associateBranchId"] = "";
            }

            $param = json_encode($filter);
            //echo $url;print_r($param);exit;		
            $header = array('Content-Type: application/json');
            $data = $this->common_curl_call($url, $param, $header, "post");
            //print_r($data);exit;
            return json_decode($data);
        } else {
            redirect('logout');
        }
    }

    public function validate_the_request($roletype, $parameters) {
        if ($roletype == "superadmin") {
            $url = securl . "/api/validateSessionKey";
            $header = array('x-session-key:' . $parameters);
            $resultpckg = $this->common_curl_call($url, "", $header, "post");
            $resultpckg = json_decode($resultpckg);
            $set = 0;
            if ($resultpckg->status == "1") {
                if (isset($resultpckg->officer->accessRoles)) {
                    foreach ($resultpckg->officer->accessRoles as $role) {
                        if ($role == 'escalation_dashboard_viewer') {
                            $set = 1;
                        }else if($role == 'escaltion_dashboard_refund_viewer'){
							$set = 1;
						}
                    }
                }
            }
            if ($set == 1) {
                $data = array(
                    'session_id' => $resultpckg->sessionKey,
                    'userid' => $resultpckg->officer->officerId,
                    'username' => ($resultpckg->officer->fname . " " . $resultpckg->officer->lname),
                    'parent_userid' => $resultpckg->officer->officerId,
                    'parent_username' => ($resultpckg->officer->fname . " " . $resultpckg->officer->lname),
                    'email' => $resultpckg->officer->email,
                    'type' => $roletype,
                    'admin_type' => "superadmin",
                    'popId' => "0"
                );
                $this->session->set_userdata('userinfo', $data);
                return "1";
            } else {
                return "0";
            }
        } else if ($roletype == "associate_admin") {
            $url = serverhostpath . "OMS/api/auth.php/v1/gettokendata";
            $param = json_encode(array("token" => $parameters));
            $header = array('Content-Type: application/json');
            $resultpckg = $this->common_curl_call($url, $param, $header, "post");
            //print_r($resultpckg); exit;
            $resultpckg = json_decode($resultpckg);
            if ($resultpckg->status == "1") {
                if (isset($resultpckg->branch_id)) {
                    $data = array(
                        'session_id' => $resultpckg->session,
                        'userid' => $resultpckg->branch_id,
                        'username' => $resultpckg->branch_name,
                        'parent_userid' => $resultpckg->associate_id,
                        'parent_username' => $resultpckg->associate_name,
                        'type' => "branch_admin",
                        'admin_type' => "associate_admin",
                        'popId' => "0"
                    );
                } else {
                    $data = array(
                        'session_id' => $resultpckg->session,
                        'userid' => "",
                        'username' => $resultpckg->branch_name,
                        'parent_userid' => $resultpckg->associate_id,
                        'parent_username' => $resultpckg->associate_name,
                        'type' => $roletype,
                        'admin_type' => "associate_admin",
                        'popId' => "0"
                    );
                }

                $this->session->set_userdata('userinfo', $data);
                return "1";
            } else {
                return "0";
            }
        }
    }

    //common curl call
    public function common_curl_call($url, $param, $header, $method) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        if ($param != "") {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
        }
        if ($method == "post") {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        } else {
            curl_setopt($ch, CURLOPT_HTTPHEADER, array());
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $resultcurl = curl_exec($ch);
        curl_close($ch);
        return $resultcurl;
    }

    public function refund_status() {
        $refund_status = array(
            "1" => "INITIATED",
            "2" => "PROCESSING",
            "3" => "PROCESSED",
            "4" => "REJECTED"
        );
        return $refund_status;
    }

    public function business_name() {
        $business_name = array(
            "1" => "Doctor Consultation",
            "2" => "Medicines",
            "3" => "Diagnostics",
            "4" => "Facilitation",
            "5" => "Care at Home",
            "6" => "Nursing",
            "7" => "Physiotherapy",
            "8" => "Bedside Attendant",
            "9" => "Speciality",
            "10" => "Doctor",
            "11" => "Equipment Rental",
            "12" => "Emotional Wellbeing",
            "13" => "Second Opinion",
            "14" => "Wellness",
            "15" => "Family Doctor",
            "16" => "Extended Services(blood bank)",
			"30" => "Assessment Order",
            "100" => "Package"
        );
        return $business_name;
    }
    
    public function mappingOrderStatuses() {
        $mappingorderstatuses = [
            "pending" => [
                "filterstatues" => [0,1,2,3,4,5,7,9,25,26,102,101],            
            ],
            "reallocate" => [
                "filterstatues" => [1,2,3,4,5,7,26],            
            ],
            "tobeassigned" => [
                "filterstatues" => [0,9,25],            
            ],
            "completed" => [
                "filterstatues" => [6,106],            
            ],
            "printdocument" => [
                "filterstatues" => [2,3,4,5,6],            
            ],
            "tobeconfirm" => [
                "filterstatues" => [25],            
            ],
            "paymentcollections" => [
                "filterstatues" => [6,106],            
            ],
           
            "sample_collections" => [
                "filterstatues" => [101],            
            ],
            "sample_submissions" => [
                "filterstatues" => [102],            
            ],
            "reports" => [
                "filterstatues" => [103],            
            ],
            "thirdparty_collections" => [
                "filterstatues" => [],            
            ]
        ];
        
        return $mappingorderstatuses;
    }
    
     public function AccessType() {
        $accesstype = array("read"=>1,"write"=>2);
        return $accesstype;
    }

    public function TABarray() {
        $tabarray = array(
            1 => "pending",
            2 => "reallocate",
            3 => "tobeassigned",
            4 => "completed",
            5 => "printdocument",
            6 => "tobeconfirm",
            7 => "approverequests",
            8 => "callhealthsubmissions",
            9 => "reports",
            10 => "sample_collections",
            11 => "sample_submissions",
            12 => "refunds",
            13 => "paymentcollections",
            14 => "thirdparty_collections"
        );
        return $tabarray;
    }

    public function MAPPINGROLE() {
        $mappingrole = [
            "superadmin" => [
                "accesstab" => [1,2,3,4,5,6,7,8,9,10,11,13,14],
                "accesstype" => [
                    "1" => 2,
                    "2" => 2,
                    "3" => 2,
                    "4" => 2,
                    "5" => 2,
                    "6" => 2,
                    "7" => 2,
                    "8" => 2,
                    "9" => 2,
                    "10" => 2,
                    "11" => 2,
                    "13" => 2,
                    "14" => 2
                ]
            ],
            "associate_admin" => [
                "accesstab" => [1,2,3,4,5,6,8,7,10,11,13,14],
                "accesstype" => [
                    "1" => 2,
                    "2" => 2,
                    "3" => 2,
                    "4" => 2,
                    "5" => 2,
                    "6" => 2,
         	    "7" => 2,
                    "8" => 2,
                    "10" => 2,
                    "11" => 2,
                    "13" => 2,
                    "14" => 2
                ]
            ],
            "branch_admin" => [
                "accesstab" => [1,2,3,4,5,6,7,8,10,11,13,14],
                "accesstype" => [
                    "1" => 2,
                    "2" => 2,
                    "3" => 2,
                    "4" => 2,
                    "5" => 2,
                    "6" => 2,
                    "7" => 2,
                    "8" => 2,
                    "10" => 2,
                    "11" => 2,
                    "13" => 2,
                    "14" => 2
                ]
            ],
            "finance_admin" => [
                "accesstab" => [8,12],
                "accesstype" => ["8" => 2, "12" => 2]
            ]
        ];
        
        return $mappingrole;
    }

    public function menuVisiblityValidation($sessiondata) {
        $userType = $sessiondata['type'];//admin type 
       // print_r($userType);exit;
        $menuRoleArray = $this->MAPPINGROLE(); //gettting rolemapping array
        $accesstabsArray = $menuRoleArray[$userType]['accesstab']; //admin wise accesstabs 
        $tabArray = $this->TABarray();//getting TABArray
        $menuList = array();
        foreach ($accesstabsArray as $value) {
            $menuList[] = $tabArray[$value]; //preparing menu visible array by rotating accesstabs array using TABARRAY
        }
        return $menuList;
    }

    public function getallpop() {
        $url = serverhostpath . 'OrderManagementRestServices/index.php/v1/getPOPList';
        $header = array('Content-Type: application/json');
        $reqparmt = json_encode(array('facility_id' => "-1"));
        $resultpckg = $this->common_curl_call($url, $reqparmt, $header, "post");
        $resultpckg = json_decode($resultpckg);
        //print_r($resultpckg->itemlist);exit;
        if (!empty($resultpckg)) {
            return $resultpckg->itemlist;
        } else {
            return "";
        }
    }
    
    //getting all cities list
    public function getallcities() {
        $url = serverhostpath . 'OMS/api/operation.php/v1/unique';
        $header = array('Content-Type: application/json');
        $reqparmt = json_encode(array('searchBy' => "city"));
        $resultpckg = $this->common_curl_call($url, $reqparmt, $header, "post");
        $resultpckg = json_decode($resultpckg);
       // print_r($resultpckg);exit;
        if (!empty($resultpckg)) {
            return $resultpckg;
        } else {
            return "";
        }
    }

    public function updatesession($sessiondata) {
      //  print_r($sessiondata['admin_type']);exit;
        if ($sessiondata['admin_type'] == "superadmin") {
            $sessiondata['type'] = $sessiondata['admin_type'];
        } else if ($sessiondata['admin_type'] == "associate_admin") {
            $sessiondata['type'] = $sessiondata['admin_type'];
        }else if($sessiondata['admin_type'] == "finance_admin"){
            $sessiondata['type'] = $sessiondata['admin_type'];
        }
       // print_r($sessiondata);exit;
        $this->session->set_userdata('userinfo', $sessiondata);  //updating session information
    }

    public function resetthesession() {
        $userinfo = $this->session->userdata('userinfo');
        $userinfo['popId'] = $this->input->post("popid");
        $this->session->set_userdata('userinfo', $userinfo);
    }

    public function logout() {
        $this->session->sess_destroy();
        $this->load->view("logout");
        /* $data["loginurl"] = securllogin;       
          $this->load->view("loginalert", $data);
          $this->load->view("footer"); */
    }

}

?>