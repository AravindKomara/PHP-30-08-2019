<?php include_once("config/config.php");
$uname = $_POST['username'];
$upass = $_POST['password'];			
$reqparmt = array(
	'email'=>$uname,
	'password'=>$upass
);
$reqparmt = json_encode($reqparmt);
$url = $serverhostpath.'OMS/api/medicine_supply.php/v1/AuthenticationPharmacist';
//print_R($reqparmt); exit;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_POSTFIELDS, $reqparmt);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER,array('Content-Type: application/json'));
$result = curl_exec($ch);
curl_close($ch);
$response=json_decode($result); 
if($response->status==1){
    $userdata = $response->data;
	if($userdata->userinfo->GROUP_ID=="10001"){
		$_SESSION['ph_user_name']=$userdata->userinfo->USER_NAME;
		$_SESSION['ph_user_id']=$userdata->userinfo->USER_ID;
		$_SESSION['ph_group_id']=$userdata->userinfo->GROUP_ID;
		header("location:dashboard.php");
	}else{
		$_SESSION['invalidmethod']="Invalid User";
		header("location:index.php");
	}
}else{	
	$_SESSION['invalidmethod']="User doesn't exist";
	header("location:index.php");
}
		
?>