<?php ob_start();session_start();
$base_url="http://172.26.7.111/";
$serverhostpath="http://172.26.7.111/";
?>