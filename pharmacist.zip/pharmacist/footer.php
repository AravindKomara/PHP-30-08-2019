<!-- Modal Footer for track -->
<div class="modal fade in" id="Modal_for_all" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" style="width:80%;">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
				<h3 class="modal-title" style="width:300px;" id="myModalLabel"></h3>
			</div>
			<div class="modal-body" style="float:left; width:100%; background: #fff;">
				<div class="col-md-12" id="trackresult"></div>
			</div>
			<div id="modalfooter" class="modal-footer"></div>
		</div>
	</div>
</div>

<script type="text/javascript">
	sessionStorage.setItem("pharmacist_user_id", "<?php echo $_SESSION["ph_user_id"]; ?>");
	sessionStorage.setItem("pharmacist_user_name", "<?php echo "".$_SESSION['ph_user_name']; ?>");
	sessionStorage.setItem("base_url", "<?php echo $base_url; ?>");
</script>    
<script src="js/common-config.js?v=1.0"></script>
<script src="js/custom.js?v=1.0"></script>
<script src="js/viewRender.js?v1.0"></script>
<script src="js/serverDataTables.js?v1.0"></script>
<script src="js/bootstrap-datepicker.js"></script>	
<script src="js/jquery.dataTables.min.js"></script>		
<script src="js/dataTables.bootstrap.min.js"></script>	

<script>	
	$("#btnOrderSearch").click(function () {
		if ($(".custom_search").hasClass("custom_searchpre"))
			$(".custom_search").removeClass("custom_searchpre");
		else
			$(".custom_search").addClass("custom_searchpre");
	});

	$(document).ready(function(){
		$(".loader").show();
		allOrders('all_orders', 'allordersview', false,1,true);
	});
	
	var today = new Date();
	$('body').on('click','.custom_search .datepicker', function() {
		$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true				
		});
	}).on('focus','.custom_search .datepicker', function() {
		$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true
		});
	});
	
	var today = new Date();
	$('body').on('click','#trackresult .datepicker', function() {
		$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true,
			startDate: today		
		});
	}).on('focus','#trackresult .datepicker', function() {
		$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true,
			startDate: today
		});
	});
	
	$('body').on('click','#trackresult .datepicker_monthyear', function() {
		$(this).datepicker({
			format: "yyyy-mm",
			viewMode: "months", 
			minViewMode: "months",
			autoclose: true,
			startDate: today
		});
	}).on('focus','#trackresult .datepicker_monthyear', function() {
		$(this).datepicker({
			format: "yyyy-mm",
			viewMode: "months", 
			minViewMode: "months",
			autoclose: true,
			startDate: today
		});
	});
	
	$('body').on('click','#showavailableslot .datepicker', function() {
		$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true,
			startDate: today
		});
	}).on('focus','#showavailableslot .datepicker', function() {
		$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true,
			startDate: today
		});
	}); 
	
	$("#vendordate").datepicker({
		'setStartDate': '+1d'		
	});
</script>
</body>
</html>