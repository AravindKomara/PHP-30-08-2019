var RestServiceURL = sessionStorage.getItem('base_url')+"OMS/api/";
//var RestServiceURL1 = sessionStorage.getItem('base_url')+"aravind/OMS/api/";

var SHOW_LOADER = "1";
var NO_SHOW_LOADER = "0";
var medicineSupplyUrl = 'medicine_supply.php/v1/';
var operationUrl = 'operation.php/v1/';
var orderUrl = 'order.php/v1/';
var External_delivery = 'external_delivery.php/v1/delhivery/';

//common ajax call
function _ajaxEventHandler(_method,payload,responce,showLoader=1,methodtype="POST",route_file="medicine_supply.php/v1/"){
	if(showLoader=='1')
	{$(".loader").show();}
	var url = RestServiceURL+route_file+_method;
	$.ajax({
		url: url, 
		type: methodtype,
    	data: JSON.stringify(payload),
    	contentType: "application/json",
        success: responce,
		error:errormsg
    });
}

function call_common_model(header_data,body_data,footer_data,model_size=""){
	if(model_size=="small"){
		$("#Modal_for_all .modal-dialog").attr("class","modal-dialog modal-sm");
	}else if(model_size=="medium"){
		$("#Modal_for_all .modal-dialog").attr("class","modal-dialog modal-md");
	}else if(model_size=="large"){
		$("#Modal_for_all .modal-dialog").attr("class","modal-dialog modal-lg");
	}else{
		$("#Modal_for_all .modal-dialog").attr("class","modal-dialog");
		$("#Modal_for_all .modal-dialog").css("width","80%"); 
	}
	$("#myModalLabel").html(header_data);
	$("#trackresult").html(body_data);
	$("#modalfooter").html(footer_data);
	$("#Modal_for_all").modal("show");
}

function errormsg(error){
	console.log(error);
	alert(error);
	$(".loader").hide();
}

//service type in an array
var servicetype = {
	"1" : "Consultation Order",
	"2" : "Drug Order",
	"3" : "Diagnostics Order",
	"4" : "Facilitation Order",
	"5" : "Care@Home Order",
	"30" : "Assessment Order"
};

var channel = {
	1:"CP",
	2:"CCO",
	3:"Android App",
	4:"Corporate Portal",
	5:"IOS App",
	6:"L2 Pharma",
	7:"Officer App"
};

var paymentModeName = {
	0:"COD",
	1:"Prepaid (payU)",
	2:"Prepaid (ICICI)",
	3:"Prepaid (Mobikwik)",
	4:"Prepaid (ccavenue)",
	5:"Prepaid (ITZCASH)",
	6:"Prepaid (paytm)",
	7:"Prepaid (AIRTEL)",
	8:"Prepaid (PaytmQR)"
};

function logout(){
	sessionStorage.clear();
	window.location = "logout.php";
}

function usersession(){
	if($.trim(sessionStorage.getItem('pharmacist_user_id'))=="" && $.trim(sessionStorage.getItem('pharmacist_user_name'))==""){
		logout();
	}
}
usersession();

function todayDate() {
	var d = new Date(),
	month = '' + (d.getMonth() + 1),
	day = '' + d.getDate(),
	year = d.getFullYear();
	hour = d.getHours();
	minute = d.getMinutes();
	if (month.length < 2) month = '0' + month;
	if (day.length < 2) day = '0' + day;
	if (hour.length < 2) hour = '0' + hour;
	if (minute.length < 2) minute = '0' + minute;
	return ([year, month, day].join('-'));
}

function tommorowDate() {
	var d = new Date(new Date().getTime() + 24 * 60 * 60 * 1000),
	month = '' + (d.getMonth() + 1),
	day = '' + d.getDate(),
	year = d.getFullYear();
	hour = d.getHours();
	minute = d.getMinutes();
	if (month.length < 2) month = '0' + month;
	if (day.length < 2) day = '0' + day;
	if (hour.length < 2) hour = '0' + hour;
	if (minute.length < 2) minute = '0' + minute;
	return ([year, month, day].join('-'));
}

/*function changedate(dt){ 
    if(typeof dt == 'undefined' || dt === "NaN"){
          return "-"; 
   }else{
        dt = dt.replace(" ", "T");
        dt = dt.split('T');
        var time = dt[1].slice(0, 10);
        time = time.slice(0, 8);
        var H = +time.substr(0, 2);
        var h = (H % 12) || 12;
        var ampm = H < 12 ? "AM" : "PM";
        time = h + time.substr(2, 6) +" "+ ampm;
        //console.log(time[1]);
        return dt = dt[0] + ' ' + time; 
   }	
}*/

function changedate(dt) {
    if (typeof dt != 'undefined') {
        return dt.replace('T',' ').replace('.000Z', '');
    }else{
		return "-";
	}
}

function settimeslot(orderdate = "", ordertime = ""){
    var date1 = todayDate();
    var date2 = $("#vendordate").val();
    var today = new Date();
    var time = today.getHours();
    var date1Updated = new Date(date1.replace(/-/g, '/'));
    //alert(date1Updated);
    var date2Updated = new Date(date2.replace(/-/g, '/'));
// alert(date2Updated);
    if (date1 === date2) {
        if (time <= 9) {
            $('#10amslot').attr('disabled', false);
            $('#2pmslot').attr('disabled', false);
            $('#6pmslot').attr('disabled', false);
        }
        if (time >= 10 && time <= 14) {
            $('#10amslot').attr('disabled', true);
            $("#vendortime option[value='18:00:00']").prop('selected', true);
            $('#2pmslot').attr('disabled', false);
            $('#6pmslot').attr('disabled', false);
        }
        if (time >= 14 && time <= 18) {
            $('#10amslot').attr('disabled', true);
            $('#2pmslot').attr('disabled', true);
            $("#vendortime option[value='22:00:00']").prop('selected', true);
            $('#6pmslot').attr('disabled', false);
        }
        if (time >= 18) {
            $('#10amslot').attr('disabled', true);
            $('#2pmslot').attr('disabled', true);
            $('#6pmslot').attr('disabled', true);
        }

    } else if (date1Updated < date2Updated) {
        $('#10amslot').attr('disabled', false);
        $('#2pmslot').attr('disabled', false);
        $('#6pmslot').attr('disabled', false);
        $("#vendortime option[value='14:00:00']").prop('selected', true);
    } else {
        $('#10amslot').attr('disabled', true);
        $('#2pmslot').attr('disabled', true);
        $('#6pmslot').attr('disabled', true);
    }
}


