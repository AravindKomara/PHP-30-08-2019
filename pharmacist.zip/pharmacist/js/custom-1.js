var RestServiceURL = sessionStorage.getItem('base_url') + "PharmaServices/v1/";
var PrecpitionPath = sessionStorage.getItem('base_url') + "medpharmacy/prescription/";
var OMSPrescrptionuploadUrl = sessionStorage.getItem('base_url') + "drugpresc/index.php?orderid=";
var SHOW_LOADER = "1";
var NO_SHOW_LOADER = "0";

function logout() {
    sessionStorage.clear();
    window.location = "logout.php";
}

function usersession() {
    if ($.trim(sessionStorage.getItem('loginid')) == "" && $.trim(sessionStorage.getItem('loginname')) == "") {
        logout();
    }
}
usersession();

function open_patient_records(patientid) {
    sessionStorage.setItem("patientid", patientid);
    var _data = {patientid: patientid};
    _ajaxEventHandler("open_patient_records", _data, cbk_open_patient_records);

    /* $.ajax({
     type: "POST", 
     url: "patientdashboard.php", 
     data:{patientid:patientid},
     success: function(result){
     window.clearTimeout(runCallback);
     $("#attendbutton").css("display","none");
     $("#endcallbutton").css("display","block");
     $("#applicationbody").html(result);
     }
     
     }); */


}

function cbk_open_patient_records(response) {

    window.clearTimeout(runCallback);
    var Obj = JSON.parse(response);
    var patientInfoObj = Obj.itemlist[0].order.patientinfo;
    var orderObj = Obj.itemlist[0].order.orderitem;
    clearMenu("ATTEND");
    renderBanner(patientInfoObj);
    renderCustomSearch();
    renderCreateOrder();

}

function getwidgetCount()
{
    var _data = {id: "1234"}
    _ajaxEventHandler("getwidgetCount", _data, cbk_getwidgetCount);

}
function cbk_getwidgetCount(response)
{
    renderWidgets(response);
    $(".loader").hide();

}


function auto_callsip(dialerpath, group_id, user_name, user_id) {
    //alert('1');
    var sip = $("#sip").val();
    sessionStorage.setItem("loginuserid", user_id);
    var _data = {group_id: group_id, status: "0", user_name: user_name, user_id: user_id, terminal_id: sip, dialerpath: dialerpath};
    _ajaxEventHandler("auto_callsip", _data, cbk_auto_callsip, SHOW_LOADER);
}
function cbk_auto_callsip(response) {
    $(".loader").hide();
    start_polling();
}

function rx() {

    var _data = {};
    var city = '';

    var _data = {city: city};
    var data = _ajaxEventHandler("all_orders", _data, allordersview, SHOW_LOADER);

    //console.
    //allordersview(data);
}


function _ajaxEventHandler(_method, payload, cbk, showLoader, ispharma) {
    showLoader = showLoader || 1;
    ispharma = ispharma || "yes";
    if (showLoader == '1')
    {
        $(".loader").show();
    }
    if (ispharma == "yes") {
        urldata = RestServiceURL + _method;
    } else {
        urldata = _method;
    }
    $.ajax({
        url: urldata,
        type: "POST",
        data: JSON.stringify(payload),
        contentType: "application/json",
        success: cbk,
        error: function () {
            $(".loader").hide();
        }
    });
}
/*function rejectorder(omorder_id){
 
 var r = confirm("Are You want Reject The Order");
 if (r == true) {
 var vendor_id=$('#vendor').val();
 
 var _data = {omorder_id:omorder_id};
 console.log(_data);
 var data=_ajaxEventHandler("rejectorder",_data,hidecbk,SHOW_LOADER);
 
 }
 
 }*/
function orderstatus(order_status) {
    if (order_status == 0) {
        return 'Unassigned';
    }
    if (order_status == 1) {
        return 'Assigned';
    }
    if (order_status == 2) {
        return 'Accepted';
    }
    if (order_status == 3) {
        return 'Started';
    }
    if (order_status == 4) {
        return 'Reached';
    }
    if (order_status == 5) {
        return 'InProgress';
    }
    if (order_status == 6) {
        return 'Completed';
    }
    if (order_status == 7) {
        return 'Rescheduled';
    }
    if (order_status == 8) {
        return 'Cancelled';
    }
    if (order_status == 9 || order_status == 24) {
        return 'Rejected';
    }
    if (order_status == 10) {
        return 'Reallocation';
    }
    if (order_status == 13) {
        return 'Item Bagged';
    }
    if (order_status == 14) {
        return 'Assigned to l2 pharmacist';
    }
    if (order_status == 15) {
        return 'Request for cancellation';
    }
    if (order_status == 16) {
        return 'Request for reschedule';
    }
    if (order_status == 17) {
        return 'Draft';
    }
    if (order_status == 18) {
        return 'Vendor Requested for Pickup';
    }
    if (order_status == 19) {
        return 'Return';
    }
    if (order_status == 20) {
        return 'Not Pickedup Imcomplete Order';
    }
    if (order_status == 21) {
        return 'L2 Assigned to Vendor';
    }
    if (order_status == 22) {
        return 'Payment submitted by MHO';
    }
    else {

        return '';
    }

}

function pressendsms(omid, mobileno) {
    var _data = {omsorder_id: omid, mobile: mobileno};
    var data = _ajaxEventHandler("sendprescriptionsms", _data, hidecbk, SHOW_LOADER);

}

function hidecbk(result) {
    result = result || '';
    console.log(result);
    $(".loader").hide();
    debugger;
    location.reload();
}
function rx_pending() {
    var _data = {};
    //var city=$("#city").val();

    //var _data = {city:city};
    var data = _ajaxEventHandler("rx_pending", _data, allordersview, SHOW_LOADER);

}
function vendor_completed_orders() {
    var vendorid = sessionStorage.getItem('loginid');
    var _data = {vendorid: vendorid};
    //var _data = {};
    //var city=$("#city").val();

    //var _data = {city:city};
    var data = _ajaxEventHandler("vendor_completed_orders", _data, allordersview, SHOW_LOADER);

}
function rejected() {
    var vendorid = sessionStorage.getItem('loginid');
    var _data = {vendorid: vendorid};
    //var city=$("#city").val();

    //var _data = {city:city};
    var data = _ajaxEventHandler("vendorrejected_orders", _data, allordersview, SHOW_LOADER);

}
function vieworder(orderid) {
    var _data = {id: orderid};
    var data = _ajaxEventHandler("order_details", _data, showorderview, SHOW_LOADER);
    console.log(data);

}
function vendor_assigned_orders() {
    var vendorid = sessionStorage.getItem('loginid');
    var _data = {vendorid: vendorid};

    var data = _ajaxEventHandler("vendor_assigned_orders", _data, allordersview, SHOW_LOADER);

}
function requested_pickup_orders() {
    var vendorid = sessionStorage.getItem('loginid');
    var _data = {vendorid: vendorid};


    var data = _ajaxEventHandler("requested_pickup_orders", _data, allordersview, SHOW_LOADER);

}


function assignlogisticsvendor(omorder_id) {
    //var vendor_id=$('#vendor').val();
    var action_id = sessionStorage.getItem('loginid');
    var action_name = sessionStorage.getItem('loginname');
    var vendor_name = $('#logisticsvendor  :selected').text();
    var vendor_val = $('#logisticsvendor').val();
    if (vendor_val == '') {
        alert("Please Select Logistics Vendor");
        return false;
    }
    var slot_transactionid = "";
    if (vendor_val == "Aramex") {
        var vendor_date = $('#vendordate').val();
        var vendor_time = $('#vendortime').val();
    } else {
        var vendor_date = $("#bookedselecttime").attr("data_date");
        var vendor_time = $("#bookedselecttime").attr("data_time");
        slot_transactionid = $("#bookedselecttime").attr("data_trasactionid");

    }

    if ($.trim(vendor_date) == "" || $.trim(vendor_time) == "") {
        alert("Please select the time slot");
        return false;
    } else if ($.trim(slot_transactionid) == "" && vendor_val != "Aramex") {
        alert("Please select the time slot");
        return false;
    }
    var _data = {logisticsvendor: vendor_name, omorder_id: omorder_id, vendor_date: vendor_date, vendor_time: vendor_time, action_id: action_id, action_name: action_name, slot_transactionid: slot_transactionid};
    //console.log(_data);	
    //var data=_ajaxEventHandler("assignlogisticsvendor",_data);
    var data = _ajaxEventHandler("assignlogisticsvendor", _data, hidecbk1, SHOW_LOADER);
    //console.log(data);

}

function updateprice(omorder_id, item_code, quantity, price, itemname, disamount, type) {

    $('#myPrice').modal('show');
    $('#quantity').val(quantity);
    $('#disamount').val(disamount);
    $('#qty').text(quantity);
    $('#iname').text(unescape(itemname));
    $('#changequantity1').val(quantity);
    $('#price1').val(price);
    $('#l2omorder_id').val(omorder_id);
    $('#item_code').val(item_code);
    $('#item_prescribed').val(type);
}



//viewbatchdetails
function viewbatchdetails(omorder_id, item_code, disamount) {
    $('#batchmodel').modal('show');
    $('#batch_disamount').val(disamount);
    $('#qty').text(quantity);
    //$('#iname').text(unescape(itemname));
    //$('#changequantity1').val(quantity);
    $('#vendor_batch_omorder_id').val(omorder_id);
    $('#batch_item_code').val(item_code);
    var _data = {omorder_id: omorder_id, item_code: item_code};
    $("#vendorupdatebatchprice").html('');
    $.ajax({
        type: "post",
        url: RestServiceURL + "getitemdetails",
        contentType: "application/json",
        data: JSON.stringify(_data),
        success: function (result) {
            ordersdetails = JSON.parse(result);
            $.each(ordersdetails.order.orderitem, function (key, val) {
                console.log(val.item_code + "---" + item_code);

                if (val.item_code == item_code) {

                    //console.log(val.itemname+"satish");
                    $('#iname1').text(val.itemname);
                    $('#bquantity').val(val.quantity);
                    $('#qty1').html(val.quantity);
                    var html = "";
                    var cnt = 0
                    $.each(val.batch, function (key1, val1) {
                        console.log(key1);
                        cnt = cnt + 1;
                        var expiry = (typeof val1.expirydate != "undefined") ? val1.expirydate : "";
                        html = '<tr><td><input type="Number" class="form-control controlInput" onkeypress="return event.charCode >= 48 && event.charCode <= 57" id="bchangequantity' + key1 + '" name="bchangequantity' + key1 + '" value="' + val1.quantity + '"></td><td><input type="Number" onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" class="form-control controlInput" id="bprice' + key1 + '" min="1" name="bprice1"  value="' + val1.mrp + '"></td><td><input type="text" class="form-control controlInput" id="bbatch' + key1 + '" name="bbatchname' + key1 + '" maxlength="20"  value="' + val1.batch + '"></td><td><input type="text" class="form-control controlInput" id="expiry_month' + key1 + '" name="expiry_month' + key1 + '" maxlength="20"  value="' + expiry + '"></td><td><input type="hidden" class="form-control controlInput" id="cbatchno' + key1 + '" name="cbatchno' + key1 + '" maxlength="20"  value="' + val1.batchno + '"></td></tr>';
                        $("#vendorupdatebatchprice").append(html);
                        //expiry_month
                    })
                    $("#batch_rowcount").val(cnt);
                }
            });
        }
    });
}


function vendorallorder() {
    var vendorid = sessionStorage.getItem('loginid');
    var _data = {vendorid: vendorid};
    _ajaxEventHandler("vendorall_orders", _data, allordersview, SHOW_LOADER);
}
//first time batch update
function vendorupdateprice() {
    var rowcount = $("#batchcount").val();
    var needval = rowcount * 3;
    var newvalues = [];
    var orderqty = $('#quantity').val();
    var l2omorder_id = $('#l2omorder_id').val();
    var item_code = $('#item_code').val();
    var disamount = $('#disamount').val();
    var item_prescribed = $('#item_prescribed').val();
    var newqty = 0;
    var mrp;
    var error = "";
    for (var i = 1; i <= rowcount; i++) {
        $("input[name='changequantity" + i + "']").each(function () {
            var qty = $("input[id='" + this.id + "']").val();
            mrp = $("#price" + i).val();
            var batch = $("#batchname" + i).val();
            var batchno = $("#bbatchno" + i).val();
            var expirydate = $("#expiry_monthyear" + i).val();
            newqty = parseInt(newqty) + parseInt(qty);
            if (qty == "" || qty == "0" || typeof qty == "undefined") {
                error = "please provide correct quantity.";
                return false;
            } else if (qty == "" || qty == "0" || typeof qty == "undefined") {
                error = "please provide correct quantity.";
                return false;
            } else if ($.trim($("#batchname" + i).val()) == "") {
                error = "please provide batch details.";
                return false;
            }
            if ($.trim($("#expiry_monthyear" + i).val()) == "" && item_prescribed == "1") {
                error = "provide provide expiry date.";
                return false;
            }
            var data = {quantity: qty, mrp: mrp, batch: batch, expirydate: expirydate};
            newvalues.push(data);
        });
    }
    if (error != "") {
        alert(error);
        return false;
    }
    if (newqty == 0 || mrp == 0) {
        //document.getElementById("GENERAL_RESPONSE").innerHTML='<p>please fill all fields in add batch and Don`t fill 0 as quantity or price.</p>';
        //$('#generalModal').modal('show');
        alert("please fill all fields in add batch and Don`t fill 0 as quantity or price.");
        return false;
    }
    else if (orderqty > newqty)
    {
        //document.getElementById("GENERAL_RESPONSE").innerHTML='<p>Given quantity less than order quantity please check.</p>';
        //$('#generalModal').modal('show');

        alert("Given quantity less than order quantity please check");
        return false;
    }
    else if (orderqty < newqty)
    {
        //document.getElementById("GENERAL_RESPONSE").innerHTML='<p>Given quantity exceeds order quantity please check.</p>';
        //$('#generalModal').modal('show');
        alert("Given quantity exceeds order quantity please check");
        return false;
    }

    var _data = {omorder_id: l2omorder_id, item_code: item_code, batchdata: newvalues, disamount: disamount};
    console.log(_data);
    var data = _ajaxEventHandler("vendorupdateprice", _data, hidecbk2, SHOW_LOADER);
}
function hidecbk2(res) {
    $(".loader").hide();
    console.log(res);
    var Obj = JSON.parse(res);
    if (Obj.status == "1") {
        alert(Obj.message);
        $("#myPrice").modal("hide");
        $('.modal-backdrop').fadeOut();
        vieworder(Obj.orderid);
    } else {
        alert(Obj.message);
    }
}

// sencod time bathc update
function vendorbatchupdateprice() {

    var rowcount = $("#batch_rowcount").val();
    var newvalues = [];
    var orderqty = $('#bquantity').val();
    var l2omorder_id = $('#vendor_batch_omorder_id').val();
    var item_code = $('#batch_item_code').val();
    var disamount = $('#batch_disamount').val();
    var newqty = 0;
    var mrp;
    for (var i = 0; i <= rowcount; i++) {
        $("input[name='bchangequantity" + i + "']").each(function () {
            var qty = $("input[id='" + this.id + "']").val();
            mrp = $("#bprice" + i).val();
            var batch = $("#bbatch" + i).val();
            console.log(batch);
            newqty = parseInt(newqty) + parseInt(qty);
            var batchno = $("#cbatchno" + i).val();
            var data = {quantity: qty, mrp: mrp, batch: batch, batchno: batchno};
            //newvalues['batchdata'][i]=[];
            newvalues.push(data);
        });
    }

    if (newqty == 0 || mrp == 0) {
        //document.getElementById("GENERAL_RESPONSE").innerHTML='<p>please fill all fields in add batch and Don`t fill 0 as quantity or price.</p>';
        //$('#generalModal').modal('show');
        alert("please fill all fields in add batch and Don`t fill 0 as quantity or price.");
        return false;
    } else if (orderqty > newqty) {
        //document.getElementById("GENERAL_RESPONSE").innerHTML='<p>Given quantity less than order quantity please check.</p>';
        //$('#generalModal').modal('show');		
        alert("Given quantity less than order quantity please check");
        return false;
    } else if (orderqty < newqty) {
        //document.getElementById("GENERAL_RESPONSE").innerHTML='<p>Given quantity exceeds order quantity please check.</p>';
        //$('#generalModal').modal('show');
        alert("Given quantity exceeds order quantity please check");
        return false;
    }
    var _data = {omorder_id: l2omorder_id, item_code: item_code, batchdata: newvalues, disamount: disamount};
    var data = _ajaxEventHandler("vendorupdateprice", _data, hidecbk1, SHOW_LOADER);
}

function hidecbk1(res) {
    console.log(res);
    $(".loader").hide();
    //console.log(res);
    var Obj = JSON.parse(res);
    if (Obj.status == "1") {
        $('#myPrice').modal('hide');
        $('.modal-backdrop').fadeOut();
        alert(Obj.message);
        vieworder(Obj.orderid);
    } else {
        alert(Obj.message);
    }
}

function changedate(dt) {
    if (typeof dt != 'undefined') {
        return dt.replace('T', ' ').replace(':00.000Z', '');
    } else {
        return '-';
    }
}

function rejectorder(omorder_id) {
    var myarray = [];
    $('input[name="item_reject"]:checked').each(function () {
        console.log(this.value);
        myarray.push(this.value);
    });
    var len = myarray.length;
    if (len) {
        $('#orderReject').modal('show');
        $('#reject_omorder_id').val(omorder_id);
        $('#reject_item_id').val(myarray);
    }
    else {
        alert("Please Select Medicine To Reject ");
    }
}

function user_log(omorder_id) {
    var myarray_log = [];
    $('input[name="item_reject"]:checked').each(function () {
        console.log(this.value);
        myarray_log.push(this.value);

    });
    var len = myarray_log.length;
    if (len) {
        $('#orderLog').modal('show');
        $('#log_omorder_id').val(omorder_id);
        $('#log_item_id').val(myarray_log);
    }
    else {
        alert("Please Select Medicine To Log!");
    }

}

function itemrejectorder(omorder_id, item_code) {
    $('#itemReject').modal('show');
    $('#item_reject_omorder_id').val(omorder_id);
    $('#item_reject_code').val(item_code);
}

function orderrejectsubmit() {

    var omorder_id = $('#reject_omorder_id').val();
    var item_ids = $('#reject_item_id').val();
    var rejectreasons = $('#orderrejectreasons').val();
    var vendorid = sessionStorage.getItem('loginid');
    var vendorname = sessionStorage.getItem('loginname');
    var _data = {omorder_id: omorder_id, item_ids: item_ids, rejectreasons: rejectreasons, vendorid: vendorid, vendorname: vendorname};
    //console.log(_data); return false;
    var data = _ajaxEventHandler("rejectorder", _data, hidecbk, SHOW_LOADER);

}

//function showlogmodal(logdetails,itemcode){
function showlogmodal(orderid, itemcode) {
    var _data = {id: orderid, itemcode: itemcode};
    var data = _ajaxEventHandler("userlog_details", _data, showlogmodalview, SHOW_LOADER);
    console.log(data);
}
function showlogmodalview(data) {
    ordersdetails = JSON.parse(data);
    var html = "No logs.";
    if (ordersdetails.status == "1") {
        var html = '<table style="width:100%;border:1;" class="wrap_data"><thead><tr><th style="padding:3px;">Role</th><th style="padding:3px;">User Id</th><th style="padding:3px;">User Name</th><th style="padding:3px;">Log</th><th style="padding:3px;">Date/Time</th></tr></thead><tbody>';
        $.each(ordersdetails.itemlist, function (bkey, bval) {
            if (bval.item_code == ordersdetails.activetiem) {
                html += '<tr style="border:1px solid;"><td style="border:1px solid;">' + bval.role + '</td>' +
                        '<td style="border:1px solid;">' + bval.actionbyid + '</td>' +
                        '<td style="border:1px solid;">' + bval.actionbyname + '</td>' +
                        '<td style="border:1px solid;">' + bval.log_reason + '</td>' +
                        '<td style="border:1px solid;">' + bval.action_date + '</td>' +
                        '</tr>';
            }
        });
        html += '</tbody></table>';
    }
    $(".loader").hide();
    $("#userLogbody").html(html);
    $("#userLog").modal('show');
}

function orderlogsubmit() {

    var omorder_id = $('#log_omorder_id').val();
    var item_ids = $('#log_item_id').val();
    var logreasons = $('#orderlogreasons').val();
    var role = 'Vendor';
    if ($.trim(logreasons) == '') {
        alert('Kindly fill Log info!');
        //return false;
    } else {
        var vendorid = sessionStorage.getItem('loginid');
        var vendorname = sessionStorage.getItem('loginname');
        var _data = {omorder_id: omorder_id, item_ids: item_ids, rejectreasons: logreasons, vendorid: vendorid, vendorname: vendorname, role: role};
        //console.log(_data); return false;

        var data = _ajaxEventHandler("logorder", _data, logorderhidecbk, SHOW_LOADER);
    }
}

function logorderhidecbk() {
    $(".loader").hide();
    $("#orderlogreasons").val("");
    $("#orderLog").modal('hide');
}

function itemrejectsubmit() {
    var rejectreasons = $('#rejectreasons').val();
    var item_reject_omorder_id = $('#item_reject_omorder_id').val();
    var item_reject_code = $('#item_reject_code').val();
    var vendorid = sessionStorage.getItem('loginid');
    var vendorname = sessionStorage.getItem('loginname');

    var _data = {omorder_id: item_reject_omorder_id, item_code: item_reject_code, rejectreasons: rejectreasons, vendorid: vendorid, vendorname: vendorname};
//console.log(_data);return false;
    var data = _ajaxEventHandler("itemrejectsubmit", _data, hidecbk1, SHOW_LOADER);

}
//select all item 

function allreject() {

    var st = $('input[name="allitem_reject"]:checked').val();
    console.log(st);
    if (st)
        $('input[name="item_reject"]').prop("checked", "checked");
    else
        $('input[name="item_reject"]').prop("checked", false);
}
function trackOrder(orderid) {
    if (orderid == "") {
        alert("Please Select the Correct Order.")
    } else {
        $.ajax({type: "POST",
            url: RestServiceURL + "trackOrder",
            data: JSON.stringify({orderid: orderid}),
            contentType: "application/json",
            success: function (result) {
                var tdata = "<table class='table table-responsive'><tbody><tr><th>Order</th><th>User Name</th><th>User ID</th><th>Role</th><th>Action</th><th>Servicing Facility Name</th><th>Order Status</th><th>Updated On</th><th>Text</th></tr>"
                result = JSON.parse(result);
                var popname = result.itemlist[0].order.patientinfo.popname;
                result = result.itemlist[0].order_log;
                console.log(result);
                $.each(result, function (key, val) {
                    tdata += '<tr><td>' + val.wodid + '</td><td>' + val.actionByName + '</td><td>' + val.actionById + '</td><td>' + val.role + '</td><td>' + val.action + '</td><td>' + popname + '</td><td>' + orderstatus(val.order_status) + '</td><td>' + val.created_date + '</td><td>' + val.reason + '</td></tr>';
                });
                tdata += '</tbody></table>';
                $('#trackresult').html(tdata);
                $('#track').modal('show');
                //$("#mainreplacecontent").html(result);
            }
        });
    }
}

function memodownload(orderid) {
    var _data = {omorder_id: orderid};
    //console.log(_data); return false;
    //window.location=RestServiceURL+'OrderInvoice?orderid='+orderid;
    window.location = RestServiceURL + 'CashMemo?orderid=' + orderid;
}

function shipmentlable(orderid) {
    var _data = {omorder_id: orderid};
    //console.log(_data); return false;
    //window.location=RestServiceURL+'OrderCashMemo?orderid='+orderid;
    window.location = RestServiceURL + 'shipment_lable?orderid=' + orderid;
}

//$('#vendordate').change(function(){
$('body').on('change', '#vendordate', function () {
    var seldate = new Date($("#vendordate").val());

    // $("#vendordate").datepicker({'minDate':'+0d'});
    // $('#vendordate').datepicker('minDate','+3D');
    var today = new Date();
    var bool = (today.toDateString() === seldate.toDateString());
    if (bool) {
        var hour = today.getHours();
        //	console.log(hour);
        if (hour < 10) {
            $("#vendortime").html('<option value="10:00">Slot-1(6 AM to 10 AM)</option><option value="14:00">Slot-2(10 AM to 2 PM)</option><option value="18:00">Slot-3(2 PM to 6 PM)</option> <option value="22:00">Slot-4(6 PM to 10 PM)</option>');
        }
        else if (hour >= 10 && hour < 14) {
            $("#vendortime").html('<option value="14:00">Slot-2(10 AM to 2 PM)</option><option value="18:00">Slot-3(2 PM to 6 PM)</option> <option value="22:00">Slot-4(6 PM to 10 PM)</option>');
        }
        else if (hour >= 14 && hour < 18) {
            $("#vendortime").html('<option value="18:00">Slot-3(2 PM to 6 PM)</option> <option value="22:00">Slot-4(6 PM to 10 PM)</option>');
        }
        else if (hour >= 18 && hour <= 23) {
            $("#vendortime").html('<option value="22:00">Slot-4(6 PM to 10 PM)</option>');
        }
        else {
            $("#vendortime").html('<option value="10:00">Slot-1(6 AM to 10 AM)</option><option value="14:00">Slot-2(10 AM to 2 PM)</option><option value="18:00">Slot-3(2 PM to 6 PM)</option> <option value="22:00">Slot-4(6 PM to 10 PM)</option>');
        }
    }
    else {
        $("#vendortime").html('<option value="10:00">Slot-1(6 AM to 10 AM)</option><option value="14:00">Slot-2(10 AM to 2 PM)</option><option value="18:00">Slot-3(2 PM to 6 PM)</option> <option value="22:00">Slot-4(6 PM to 10 PM)</option>');
    }
});

function exportcsv() {
    // var type = $("#exporttype").val();

    var vendorid = sessionStorage.getItem('loginid');
    //var _data = {vendorid:vendorid};
    //var _data={formdate:formdate,todate:todate,vendorid:vendorid}
    window.location = sessionStorage.getItem('base_url') + "PharmaServices/v1/vendororderexportcsv?&vendorid=" + vendorid;
    // _ajaxEventHandler("orderexportcsv",_data,hidecbk,SHOW_LOADER);

}

function addmore() {
    var next = $("#batchcount").val();
    next = parseInt(next) + 1;
    $("#batchcount").val(next);

    var _data = "";

    $("#vendorupdateprice").append('<tr><td><input type="Number" class="form-control controlInput"  onkeypress="return event.charCode >= 48 && event.charCode <= 57" id="changequantity' + next + '" name="changequantity' + next + '"></td><td><input type="Number" onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46"  class="form-control controlInput"  id="price' + next + '" name="price"></td><td><input type="text" class="form-control controlInput" id="batchname' + next + '" maxlength="20" name="batchname' + next + '"></td><td class="expiry_monthyear"><input type="text" id="expiry_monthyear' + next + '" class="form-control datepicker" placeholder="YYYY-MM"><span class="datepicker"><span class="glyphicon glyphicon-calendar cust_cal"></span></span></td><td><button type="button" class="btn btn-danger" onclick="removelast()">-</button></td><td><input type="hidden" class="form-control controlInput" id="bbatchno' + next + '" name="bbatchno' + next + '" maxlength="20"  value="' + next + '"></td></tr>');
}
function removelast() {
    var next = $("#batchcount").val();
    next = parseInt(next) - 1;
    $("#batchcount").val(next);
    $('#vendorupdateprice tr:last').remove();
}
function l2prescptionupload() {

    var formData = new FormData($("#formsum")[0]);
    var vendorid = sessionStorage.getItem('loginid');
    var vendorname = sessionStorage.getItem('loginname');
    formData.append('omorderid', $('#orderid').val());
    formData.append('loginid', vendorid);
    formData.append('loginname', vendorname);
    //formData.append("userfile", fileInputElement.files[0]);

    $.ajax({
        url: RestServiceURL + 'l2prescptionupload',
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        type: 'POST',
        success: function (data) {
            result = JSON.parse(data);
            //console.log(result['status']);
            if (result.status == 1) {

                alert(result.message)
            }
            else {

                alert("some Thing Wrong  Please try again !")
            }
            //alert(data);
            hidecbk();
        }
    });
}

function open_slot_modal() {
    var itemcode = "";
    $("input[name=item_reject]").each(function () {
        itemcode = $(this).val;
        return false;
        //break;
    });
    if ($.trim(itemcode) == "") {
        alert("Please enter test name");
        return false;
    }
    if ($.trim($("#selecttimeslot").attr("data-pincode")) == "") {
        alert("Please provide proper pincode.");
        return false;
    }
    $("#showavailableslot").modal("show");
    var tommorowDate = $("#selecttimeslot").attr("data-scheduled_date").split(" ");
    console.log(tommorowDate);
    $("#mainorderdate").val(tommorowDate[0])
    fetch_slot();
}

function setgenderinnumber(valu) {
    var valu = $.trim(valu);
    var setgender = "";
    if (valu == "Female" || valu == "F") {
        setgender = "1";
    }
    else if (valu == "Male" || valu == "M") {
        setgender = "2";
    }
    else if (valu == "Other") {
        setgender = "3";
    }
    else if (valu == "Not Stated") {
        setgender = "3";
    }
    else if (valu == "Female") {
        setgender = "1";
    }
    else if (valu == "Male") {
        setgender = "2";
    }
    else {
        setgender = valu;
    }
    return setgender;
}

function fetch_slot() {
    var itemcode = "";
    $("input[name=item_reject]").each(function () {
        itemcode = $(this).val;
        return false;
        //break;
    });
    var _data = {
        from_date: $("#mainorderdate").val(),
        to_date: $("#mainorderdate").val(),
        business_id: "2",
        sub_business_id: "9",
        service_did: itemcode,
        pop_id: $("#selecttimeslot").attr("data-popid"),
        patient_mrn: $("#selecttimeslot").attr("data-mrn"),
        patient_age: $("#selecttimeslot").attr("data-age"),
        patient_gender: setgenderinnumber($("#selecttimeslot").attr("data-gender")),
        preferred_officer: "",
        pin_code: $("#selecttimeslot").attr("data-pincode"),
        order_latitude: $("#selecttimeslot").attr("data-latitude"),
        order_longitude: $("#selecttimeslot").attr("data-longitude")
    }
    var data = _ajaxEventHandler(sessionStorage.getItem('base_url') + "OMS/api/operation.php/v1/fetch_slots", _data, response_fetch_slot, SHOW_LOADER, "no");
}

function datetime24to12(date24) {
    var date24 = date24.split(' ');
    var time = date24[1].slice(0, 8);
    var H = +time.substr(0, 2);
    var h = (H % 12) || 12;
    var ampm = H < 12 ? "AM" : "PM";
    time = h + time.substr(2, 3) + ampm;
    //scheduledate = date24[0] + ' ' + time;
    return time;
}

function response_fetch_slot(response) {
    console.log(response);
    $(".loader").hide();
    //var ordersdetails = JSON.parse(response);
    var senddate = $("#mainorderdate").val();

    if (response.success === "1") {
        var htmlstring = "";
        $.each(response.data[senddate], function (key, val) {
            if (val.is_booked != 1) {
                var from_time = senddate + " " + val.from_time;
                var to_time = senddate + " " + val.to_time;
                htmlstring += "<button class='btn btn-success' style='margin:5px;' onclick='booktheslot(\"" + val.transaction_id + "\",\"" + senddate + "\",\"" + val.to_time + "\")'>" + datetime24to12(from_time) + " - " + datetime24to12(to_time) + "</button>";
            }
        });
        if (htmlstring == "") {
            htmlstring = "<br><label>Slots are not available.</label>";
        }
        $("#slotdiv").html(htmlstring);
    } else {
        console.log(response.message);
        alert(response.message);
    }
}



function booktheslot(transaction_id, selected_date, selected_time) {
    $("#bookedselecttime").attr("data_time", selected_time);
    $("#bookedselecttime").attr("data_date", selected_date);
    $("#bookedselecttime").attr("data_trasactionid", transaction_id);
    $("#showavailableslot").modal("hide");
    $("#showbookedselecttime").html(selected_date + " " + selected_time);
    //"bookedselecttime"
}


function allOrders(ajaxMethod, SuccessFn, withSearch, skip, pagination) {
    console.log(pagination);
    withSearch = withSearch || false;
    ajaxMethod = ajaxMethod || false;
    pagination = pagination || false;
    skip = skip || '1';
    sessionStorage.setItem("ajaxMethod", ajaxMethod);
    sessionStorage.setItem("SuccessFn", SuccessFn);
    sessionStorage.setItem("withSearch", withSearch);
    sessionStorage.setItem("pagination", pagination);
    sessionStorage.setItem("skip", skip);

    var _data = {};
    _data.vendorid = sessionStorage.getItem('loginid');
    _data.pagination = true;
    _data.skip = skip;
    _data.limit = 10;
    //_ajaxEventHandler(ajaxMethod, _data, SuccessFn, SHOW_LOADER);
    _customeDataTable(_data, ajaxMethod, SuccessFn, SHOW_LOADER);
}

function _customeDataTable(_data, ajaxMethod, SuccessFn, showLoader) {
    showLoader = showLoader || 1;
    if (showLoader == '1') {
        $(".loader").show();
    }
    _data.method = ajaxMethod;
    _data.type = "pharmacist";
    var url = sessionStorage.getItem("base_url") + 'OMS/api/medicine_supply.php/v1/getMedOrdersByFilter';
    $("#Custom_body").customeDataTable({
        data: _data,
        orderby: 0,
        actionurl: url,
        actiontype: "POST",
        tableprepare: SuccessFn,
        pagination: _data.pagination,
        perpage: _data.limit,
        search: false,
        customsearch: _data.customsearch,
        skip: _data.skip
    });
    $(".loader").hide();
}

//single order  view 
function vieworder(orderid) {
    var _data = {orderid: orderid};
    fullUrl = sessionStorage.getItem("base_url") + 'OMS/api/medicine_supply.php/v1/getorderdetails';
    var data = _ajaxEventHandler(fullUrl, _data, showorderview, SHOW_LOADER,'no');
    console.log(data);
}

function trackOrder(orderid) {
    if (orderid == "") {
        alert("Please Select the Correct Order.")
    } else {
        var _data = {order_id: orderid};
        fullUrl = sessionStorage.getItem("base_url") + 'OMS/api/operation.php/v1/ordertrack';
        _ajaxEventHandler(fullUrl, _data, trackOrderView, SHOW_LOADER, 'no');
    }
}

