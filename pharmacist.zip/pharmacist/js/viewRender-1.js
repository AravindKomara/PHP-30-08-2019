function renderBanner(patientInfoObj) {

    $("#attendbutton").css("display", "none");
    $("#endcallbutton").css("display", "block");
    var htmlBanner = "";
    /* htmlBanner =  "<article class='patient_details'>"	+
     "<div class='col-md-1 mp'>" 				+
     "<a href='#' class='back_btn'>Back</a>"	+
     "</div>"									+
     "<h2>"					+
     "<span id='pname'>"+patientInfoObj.name+"</span>"					+
     "<small>	|"			+
     "<span id='pgender'>"+patientInfoObj.gender+"</span> | "+patientInfoObj.age+" | MRN-"+patientInfoObj.mrn+" | English <span class='mailid'>"+patientInfoObj.email+" </span> <i class='fa fa-tags' aria-hidden='true'>"+"Tags"+"</i></br>"					+
     "</small></h2></div></article>"; */


    htmlBanner = "<article class='main_content_banner'><div class='col-md-1 col-sm-1 col-xs-12 mp'><div class='form-group'>" + patientInfoObj.name + "</div></div>" + "<div class='col-md-1 col-sm-1 col-xs-12 mp'><div class='form-group'>" + patientInfoObj.mrn + "</div></div>" + "<div class='col-md-1 col-sm-1 col-xs-12 mp'><div class='form-group'>" + patientInfoObj.age + "</div></div>" + "<div class='col-md-1 col-sm-1 col-xs-12 mp'><div class='form-group'>" + patientInfoObj.gender + "</div></div>" + "<div class='col-md-1 col-sm-1 col-xs-12 mp'><div class='form-group'>" + patientInfoObj.email + "</div></div>" + "<div class='col-md-1 col-sm-1 col-xs-12 mp'><div class='form-group'>" + "Tags" + "</div></div></article>";
    $("#patientBannerInfo").html(htmlBanner);
    $(".loader").hide();
}
function clearMenu(action) {
    var htmlBanner = "";
    htmlBanner = "<article class='patient_details'>" +
            "<div class='col-md-1 mp'>" +
            "<a href='#' class='back_btn'>Back</a>" +
            "</div>" +
            "<div class='col-md-4'><h1>Patient Dashboard</h1></div>" +
            "</article>";

    $("#pharma_menu").html(htmlBanner);

}
function renderMenu(action) {
    var htmlBanner = "";
    htmlBanner = "<article class='patient_details'>" +
            "<div class='col-md-1 mp'>" +
            "<a href='#' class='back_btn'>Back</a>" +
            "</div>" +
            "<div class='col-md-4'><h1>Patient Dashboard</h1></div>" +
            "</article>";

    $("#pharma_menu").html(htmlBanner);

}
function renderWidgets(counts) {
    var htmlBannerup = "<div class='container-fluid'><article class='medicine_details'><div class='col-md-9 col-sm-9 col-xs-9'> <h1>Medicine at Home Orders</h1></div><div class='col-md-3 col-sm-3'><a href='#' onclick='exportcsv()'  class='export_csv_btn pull-right'>Export CSV</a></div></article></div>";
    var htmlBanner = "";
    htmlBanner = "<div class='container-fluid custom_pop_rx'><ul class='nav nav-tabs cust_nav'>" +
            "<li role='presentation'>" +
            "<a onclick=allOrders('update_mrp','allordersview',false,1,true); aria-controls='home' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-shopping-cart' aria-hidden='true'></i>" +
            "Update Mrp (<span id='vendor_assigned_count'>0</span>)" +
            "</a>" +
            "</li>" +
            "<li role='presentation'>" +
            "<a onclick=allOrders('requested_to_pickup','allordersview',false,1,true); aria-controls='profile' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-check' aria-hidden='true'></i>" +
            "Request to Pickup (<span id='requested_pickup_count'>0</span>)" +
            "</a>" +
            "</li>" +
            "<li role='presentation'>" +
            "<a onclick=allOrders('rejected','allordersview',false,1,true); aria-controls='profile' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-print' aria-hidden='true'></i>" +
            "Rejected Orders (<span id='rejectedcount'>0</span>)" +
            "</a>" +
            "</li>" +
            "<li role='presentation'>" +
            "<a  aria-controls='profile' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-print' aria-hidden='true'></i>" +
            "Return Orders (<span id=''>0</span>)" +
            "</a>" +
            "</li>" +
            "<li role='presentation' class='active'>" +
            "<a onclick=allOrders('all_orders','allordersview',false,1,true); aria-controls='home' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-shopping-cart' aria-hidden='true'></i>" +
            "All Orders (<span id='allorder_count'>0</span>)" +
            "</a>" +
            "<li role='presentation'>" +
            "<a onclick=allOrders('completed','allordersview',false,1,true); aria-controls='home' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-shopping-cart' aria-hidden='true'></i>" +
            "Completed Orders (<span id='completed_count'>0</span>)" +
            "</a>" +
            "</li>" +
            "</ul></div>";
    $("#pharma_menu").html(htmlBannerup);
    $("#pharma_widgets").html(htmlBanner);

}
function renderCustomSearch() {
    var htmlBanner = "";
    htmlBanner = "<div class='med_home'>" +
            " <div class='col-md-12 col-sm-12 col-xs-12'>" +
            "<div class='col-md-4'>" +
            "<h1>Medicine at Home Orders</h1>" +
            "</div>" +
            "<div class='col-md-6 col-sm-6 col-xs-12 mrn_srch'>" +
            "<form class='form-inline'>" +
            "<form class='form-inline'>" +
            " <select name='job_name' class='form-control new-status'>" +
            " <option value='WO'>MRN</option>" +
            " <option value='Name'>Order ID</option>" +
            "<option value='Name'>Batch No</option>" +
            "</select>" +
            "<a href='#' class='mrn_srch_btn'>Search</a>" +
            "</form>" +
            " </form>" +
            "</div>" +
            "<div class='col-md-2 col-sm-6 col-xs-12'>" +
            "<a href='#' class='export_csv_btn pull-right'>Export CSV</a>" +
            "</div>" +
            "</div>" +
            "</div>" +
            "<div class='container-fluid'>" +
            "<section class='custom_search'>" +
            "<article class='col-md-12 col-sm-12 col-xs-12'>" +
            "<div class='col-md-1 col-sm-1 col-xs-12 mp'>" +
            "<div class='form-group'>" +
            "<label>City :</label>" +
            "<select name='job_name' class='form-control new-status'>" +
            "<option value=''>--Select--</option>" +
            "<option value='WO'>Hyderabad</option>" +
            "<option value='Name'>Delhi</option>" +
            "<option value='Name'>Kolkata</option>" +
            "<option value='Name'>Chennai</option>" +
            "<option value='Name'>Bengaluru</option>" +
            "<option value='Name'>Pune</option>" +
            "<option value='Name'>Mumbai</option>" +
            "</select>" +
            "</div>" +
            "</div>" +
            " <div class='col-md-1 col-sm-6 col-xs-12 mnp'>" +
            "<div class='form-group'>" +
            "<label>Location / Pop :</label>" +
            "<select name='job_name' class='form-control new-status'>" +
            "<option value=''>--Select--</option>" +
            "<option value='WO'>Gchibowli</option>" +
            " <option value='Name'>Madhapur</option>" +
            "<option value='Name'>Ameerpet</option>" +
            "<option value='Name'>Dilsukhnagar</option>" +
            "<option value='Name'>Uppal</option>" +
            "<option value='Name'>Kukatpally</option>" +
            "<option value='Name'>Miyapur</option>" +
            "</select>" +
            "</div>" +
            "</div>" +
            "<div class='col-md-2 col-sm-6 col-xs-12 mp'>" +
            "<div class='form-group'>" +
            " <label>From Date :</label>" +
            "<div class='input-group' id='datepicker'>" +
            "<input type='text' class='form-control datepicker' placeholder='DD/MM/YYYY'>" +
            "<span class='datepicker'>" +
            " <span class='glyphicon glyphicon-calendar cust_cal'></span>" +
            "</span>" +
            "</div>" +
            "</div>" +
            "</div>" +
            " <div class='col-md-2 col-sm-1 col-xs-12 mp'>" +
            "<div class='form-group'>" +
            "<label>To Date :</label>" +
            "<div class='input-group' id='datepicker'>" +
            "<input type='text' class='form-control datepicker' placeholder='DD/MM/YYYY'>" +
            "<span class='datepicker'>" +
            " <span class='glyphicon glyphicon-calendar cust_cal'></span>" +
            " </span>" +
            "</div>" +
            "</div>" +
            "</div>" +
            "<div class='col-md-1 col-sm-1 col-xs-12 mp'>" +
            "<div class='form-group'>" +
            "<label>Order Status :</label>" +
            "<select name='job_name' class='form-control new-status'>" +
            "<option value=''>--Select--</option>" +
            "<option value='WO'>Pending</option>" +
            "<option value='Name'>Completed</option>" +
            " <option value='Name'>Un Assign</option>" +
            "</select>" +
            "</div>" +
            "</div>" +
            " <div class='col-md-2 col-sm-6 col-xs-12'>" +
            " <label>Vendor Pharma Name :</label>" +
            "<select name='job_name' class='form-control new-status'>" +
            " <option value=''>--Select--</option>" +
            "<option value='WO'>Balaji Medical</option>" +
            "<option value='Name'>Rohan Medical</option>" +
            "<option value='Name'>Sri Krishna</option>" +
            "</select>" +
            " </div>" +
            "<div class='col-md-2 col-sm-6 col-xs-12'>" +
            "<label>Delivery Associates :</label>" +
            "<select name='job_name' class='form-control new-status'>" +
            "<option value=''>--Select--</option>" +
            "<option value='WO'>Apollo Pharmacy</option>" +
            "<option value='Name'>Medplus</option>" +
            "<option value='Name'>Hetero</option>" +
            "</select>" +
            "</div>" +
            " <div class='col-md-1 col-sm-6 col-xs-12 text-right'>" +
            " <a href='#' class='med_order_srch'>Search</a>" +
            "</div>" +
            " </article>" +
            " </section>" +
            "</div>"
            ;

    $("#Custom_search").html(htmlBanner);

}
function renderCreateOrder() {
    var htmlBanner = "";
    htmlBanner = "<div class='col-md-12 col-sm-12 col-xs-12 mp'>" +
            "<div class='table-responsive'>" +
            "<table class='table table-fixed table-condensed table-bordered table-striped medicine_home_order_table' id='toggleColumn-datatable'>" +
            "<thead>" +
            "<tr>" +
            "<th>" +
            "Pharmaceutical Name" +
            "</th>" +
            "<th>" +
            " Brand Name" +
            "</th>" +
            "<th>" +
            " Doctor Name" +
            "</th>" +
            "<th>" +
            "Order Qty" +
            "</th>" +
            "<th>" +
            " Discount" +
            " </th>" +
            "<th>" +
            "  MRP" +
            "</th>" +
            "<th>" +
            "Amount" +
            "</th>" +
            "<th>" +
            " Actions" +
            "</th> " +
            "</tr>" +
            " </thead>" +
            "<tbody>" +
            "<tr>" +
            "<td>" +
            " <div class='form-group'>" +
            " <div class='input-group input-group-md'>" +
            "<div class='icon-addon'>" +
            "<input type='text' placeholder='RANITIDINE' class='form-control' id='email'>" +
            "</div>" +
            "<span class='input-group-btn'>" +
            "<button class='btn btn-default' type='button'><i class='fa fa-search' aria-hidden='true'></i></button>" +
            "</span>" +
            "</div>" +
            "</div>" +
            "</td>" +
            "<td>" +
            " <div class='form-group'>" +
            "<div class='input-group input-group-md'>" +
            "<div class='icon-addon'>" +
            "<input type='text' placeholder='ACILOC RD TAB' class='form-control' id='email'>" +
            " </div>" +
            " <span class='input-group-btn'>" +
            "<button class='btn btn-default' type='button'><i class='fa fa-search' aria-hidden='true'></i></button>" +
            "</span>" +
            "</div>" +
            "</div>" +
            "</td>" +
            " <td>" +
            "  Vijaya Lakshmi" +
            "</td>" +
            " <td class='oneliner'> 12 </td>" +
            "<td> 2.51 </td>" +
            " <td>" +
            "2.51" +
            "</td>" +
            " <td>" +
            "  2.26" +
            "</td>" +
            " <td> <a href='#'><i class='fa fa-check cust_check' aria-hidden='true'></i></a><a href='#'><i class='fa fa-times cust_times' aria-hidden='true'></i></a></td>" +
            "</tr> " +
            "</tbody>" +
            "</table>" +
            "</div>" +
            "<div class='col-md-12 col-sm-12 col-xs-12 text-right view_prec'>" +
            " <a href='#' class='back_btn'>View Prescription</a>" +
            "<a href='#' class='back_btn'>Rpeat Order</a>" +
            "</div>" +
            "<div class='col-md-8 col-md-offset-4 pull-right'>" +
            " <nav aria-label='...'>" +
            "<ul class='pagination'>" +
            " <li class='page-item disabled'>" +
            " <a class='page-link' href='#' tabindex='-1'>Previous</a>" +
            "</li>" +
            "<li class='page-item'><a class='page-link' href='#'>Order( 1 - 100 from 123 )</a></li>" +
            "<li class='page-item'>" +
            " <a class='page-link' href='#'>Next</a>" +
            " </li>" +
            "</ul>" +
            "<span class='nps'>" +
            "No of Pages <select name='job_name' class='form-control noofpages'>" +
            " <option value=''>1</option>" +
            "<option value=''>25</option>" +
            "<option value=''>50</option>" +
            " <option value=''>100</option>" +
            "</select>" +
            " </span>" +
            "</nav>" +
            " </div>" +
            "</div>";

    $("#Custom_body").html(htmlBanner);

}
function allordersview(ordersdetails) {
    console.log(sessionStorage.getItem('loginid'));
    //var total_orders=20 ;//ordersdetails.length;
    //alert();
    $(".loader").show();
    ordersdetails = JSON.parse(ordersdetails);
//$('#rxuploadedcount').html(ordersdetails.countn);
//console.log(ordersdetails.countn);
    htmlBanner = '<section class="container-fluid">' +
            '<article class="main_content">' +
            '<div class="tab-content custom_tab_content">' +
            '<div role="tabpanel" class="tab-pane fade in active" id="mainreplacecontent">' +
            '<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
            '<div class="table-responsive">' +
            '<table id="example"  cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">' +
            '<thead>' +
            '<tr>' +
            '<th>MRN</th>' +
            '<th>Customer Name</th>' +
            ' <th>' + 'Order No.' + '</th>' +
            '<th>Location</th>' +
            '<th>Order Created Date </th>' +
            '<th>Preferred Date/Time </th>' +
            '<th>Scheduled Date/Time </th>' +
            ' <th>Vendor Assign Date</th>' +
            '<th>Vendor Name</th>' +
            '<th>Order Status</th>' +
            '<th>Order Details</th>' +
            '<th>Order Track</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';
    $.each(ordersdetails.data, function (key, val) {
        //console.log(val._id);
        var patientname = val.order.patientinfo.name;
        patientname = patientname.replace("null", "");
        htmlBanner += '<tr>' +
                ' <td>' + val.order.patientinfo.mrn + '</td>' +
                '<td>' + patientname + '</td>' +
                '<td>' + val._id + '</td>' +
                '<td>' + val.order.patientinfo.city + '</td>' +
                '<td>' + changedate(val.order.order_status.created_date) + '</td>' +
                ' <td>' + changedate(val.order.patientinfo.expected_delivery_time) + '</td>';

        if (val.OStatus != 17 && val.OStatus != 21) {
            htmlBanner += '<td>' + changedate(val.order.patientinfo.scheduled_date) + '</td>';
        } else {
            htmlBanner += '<td>-</td>';
        }
        htmlBanner += '<td>' + changedate((typeof (val.order.vendorinfo) == "undefined") ? "" : ((typeof val.order.vendorinfo.vendorassign_datetime == "undefined") ? "" : val.order.vendorinfo.vendorassign_datetime)) + '</td>' +
                '<td>' + ((typeof (val.order.vendorinfo) == "undefined") ? "" : ((typeof val.order.vendorinfo.VendorName == "undefined") ? "" : val.order.vendorinfo.VendorName)) + '</td>' +
                '<td>' + orderstatus(val.OStatus) + '</td>' +
                '<td> <a onclick="vieworder(' + val._id + ')" target="_new" class="view">View</a> </td>' +
                '<td><a href="#" onclick="trackOrder(' + val._id + ')" class="track_btn">Deliver Track</a></td>' +
                '</tr>'; //href=order_view.php?id='+val._id.value+' 
    });
    htmlBanner += '</tbody>' +
            '</table>' +
            ' </div>' +
            ' </div>' +
            ' </div>' +
            '</div>' +
            '</div>' +
            ' </div>' +
            '</article>' +
            '</section>' +
            '</div>' +
            '<div class="modal fade in" id="track" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">' +
            '<div class="modal-dialog" style="width:80%;">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>' +
            '<h3 class="modal-title" style="width:300px;" id="myModalLabel">Order Tracking Status</h3>' +
            '</div>' +
            '<div class="modal-body" style="float:left; width:80%; background: #fff;">' +
            '<div class="col-md-12" id="trackresult">' +
            '</div>' +
            '</div>' +
            '<div class="modal-footer">' +
            '<button type="button" class="btn btn-default sa-success" data-dismiss="modal" style="color:#fff;">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>';

    //$("#Custom_body").html(htmlBanner);
    console.log('sdfsfdsfsd');
    console.log($("#vendor_assigned_count").length);
    setTimeout(function(){ 
    $("#vendor_assigned_count").html(ordersdetails.update_mrp);
     $("#requested_pickup_count").html(ordersdetails.requested_pickup);
     $("#rejectedcount").html(ordersdetails.rejected);
     $("#completed_count").html(ordersdetails.completed);
     $("#allorder_count").html(ordersdetails.all_orders);
    }, 1000);

    $(".loader").hide();
    return htmlBanner;
}

function updateTableCount(ordersdetails){
    getwidgetCount();
    $("#vendor_assigned_count").html(ordersdetails.update_mrp);
     $("#requested_pickup_count").html(ordersdetails.requested_pickup);
     $("#rejectedcount").html(ordersdetails.rejected);
     $("#completed_count").html(ordersdetails.completed);
     $("#allorder_count").html(ordersdetails.all_orders);
}

function showorderview(data) {
    if(typeof ordersdetails == 'string'){
    ordersdetails = JSON.parse(data);
    }else{
    ordersdetails = data;    
    }
    ordersdetails = ordersdetails.data;
    lglist = ordersdetails.logisticsvendorlist;
    patientname = ordersdetails.order.patientinfo.name;
    orderstatuscheck = ordersdetails.order.patientinfo.order_status;
    patientname = patientname.replace("null", "");
    htmlBanner = '<section class="container-fluid">' +
            '<article class="p_details">' +
            '<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
            '<h3>Order ID #' + ordersdetails._id + ' | MRN - ' + ordersdetails.order.patientinfo.mrn + '</h3>' +
            ' <section class="complete_order_search">' +
            '<article class="col-md-12 col-sm-12 col-xs-12 mobile_mp">' +
            '<div class="col-md-2 col-sm-1 col-xs-12 mp">' +
            '<div class="form-group">' +
            '<label>Customer Name: </br>' + patientname + ' </label>' +
            '<label>Delivery Address <a href="#"></a></label>' +
            '<small>Address:' + ordersdetails.order.patientinfo.address + '</br>' + ordersdetails.order.patientinfo.landmark + '</small>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-1 col-sm-1 col-xs-12 mnp">' +
            '<label>Pop Name: </br>' + ordersdetails.order.patientinfo.popname + ' </label>' +
            '<label>Mobile No. : </br>' + ordersdetails.order.patientinfo.contact + ' </label>' +
            '<label>Alternate Mobile No. : </br>' + ordersdetails.order.patientinfo.alternetcontactno + ' </label>' +
            '<label>Pin code : </br>' + ordersdetails.order.patientinfo.pincode + ' </label>' +
            '</div>' +
            '<div class="col-md-1 col-sm-1 col-xs-12 mnp">' +
            '<label>Preferred Date/Time :</br> ' + changedate(ordersdetails.order.patientinfo.expected_delivery_time) + ' </label>' +
            '<label>Scheduled Date/Time :</br> ' + changedate(ordersdetails.order.patientinfo.scheduled_date) + ' </label>' +
            '</div>' +
            '<div class="col-md-1 col-sm-1 col-xs-12 mnp">' +
            '<label>Payment Mode </br>' + ordersdetails.order.patientinfo.payment_method + ' </label>' +
            '</div>';
    if (ordersdetails.order.patientinfo.prepaid == 1) {
        htmlBanner += '<div class="col-md-1 col-sm-1 col-xs-12 mnp">' +
                '<label>Prepaid Amount  &#8377;&nbsp; ' + ordersdetails.order.prepayment.amount.toFixed(2) + ' </label>' +
                '</div>';
    }
    if (ordersdetails.OStatus == 21) {
        if (ordersdetails.pop_id == "200043" || ordersdetails.pop_id == "200044" || ordersdetails.pop_id == "200045") {
            htmlBanner += '<div class="col-md-2 col-sm-1 col-xs-12 mnp">' +
                    '<div class="form-group">' +
                    '<label>Schedule Date :</label>' +
                    ' <div class="input-group" >' +
                    '<input type="text" id="vendordate" class="form-control datepicker" placeholder="YYYY-MM-DD">' +
                    '<span class="datepicker">' +
                    '<span class="glyphicon glyphicon-calendar cust_cal"></span>' +
                    ' </span>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '<div class="col-md-2 col-sm-1 col-xs-12 mnp">' +
                    '<div class="form-group">' +
                    '<label>Schedule Time Slot :</label>' +
                    '<select id="vendortime" name="job_name" class="form-control new-status">' +
                    '<option value="">--Select--</option>' +
                    '<option value="10:00">06:00 AM-10:00 AM</option>' +
                    '<option value="14:00">10:00 AM-02:00 pm</option>' +
                    '<option value="18:00">02:00 PM-06:00 pm</option>' +
                    '<option value="22:00">06:00 PM-10:00 pm</option>' +
                    '</select>' +
                    '</div>' +
                    '</div>';
        } else {
            htmlBanner += '<div class="col-md-2 col-sm-1 col-xs-12 mnp">' +
                    '<div class="form-group">' +
                    '<label>Book the Slot :</label>' +
                    '<button name="job_name" onclick="open_slot_modal();"  id="selecttimeslot" data-scheduled_date="' + changedate(ordersdetails.order.patientinfo.scheduled_date) + '" data-mrn="' + ordersdetails.order.patientinfo.mrn + '" data-popid="' + ordersdetails.order.patientinfo.facility_id + '" data-age="' + ordersdetails.order.patientinfo.age + '" data-gender="' + ordersdetails.order.patientinfo.gender + '" data-pincode="' + ordersdetails.order.patientinfo.pincode + '" data-latitude="' + ordersdetails.order.patientinfo.delivery_lat + '" data-longitude="' + ordersdetails.order.patientinfo.delivery_lng + '"  class="btn btn-success">Select slot</button>' +
                    '<hidden data_time="" data_date="" data_trasactionid="" id="bookedselecttime" style="color:#408DAE"></hidden>' +
                    '<label style="color:#408DAE" id="showbookedselecttime"></lable>' +
                    ' </div>' +
                    '</div>';
        }
        htmlBanner += '<!--div class="col-md-2 col-sm-1 col-xs-12 mnp">' +
                '<div class="form-group">' +
                '<label>Schedule Time Slot :</label>' +
                '<select id="vendortime" name="job_name" class="form-control new-status">' +
                ' <option value="">--Select--</option>' +
                '<option value="10:00">06:00 AM-10:00 AM</option>' +
                '<option value="14:00">10:00 AM-02:00 pm</option>' +
                '<option value="18:00">02:00 PM-06:00 pm</option>' +
                '<option value="22:00">06:00 PM-10:00 pm</option>' +
                '</select>' +
                '</div>' +
                '</div-->' +
                '<div class="col-md-2 col-sm-1 col-xs-12 mnp">' +
                '<div class="form-group">' +
                '<label>Logistics Vendor :</label>' +
                '<select name="vendor" id="logisticsvendor" class="form-control new-status">' +
                '<option value="" disabled>Select Logistics Vendor</option> ';
        if (ordersdetails.pop_id == "200043" || ordersdetails.pop_id == "200044" || ordersdetails.pop_id == "200045") {
            htmlBanner += '<option value="Aramex">Aramex</option>';
        } else {
            htmlBanner += '<option value="callhealth">Callhealthpickup</option> ' +
                    '<option value="getbike">GetBike</option>' +
                    '<!--<option value="Vdeliver">Vdeliver</option> -->';
        }
        htmlBanner += '</select>' +
                '</div>' +
                '</div>';
    }
    htmlBanner += '</article>' +
            '</section>' +
            '<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
            '<div class="table-responsive">' +
            '<table class="table  table-condensed table-bordered table-striped medicine_home_order_table" id="toggleColumn-datatable">' +
            ' <thead>' +
            '<tr>';
    //if(ordersdetails.OStatus==21){
    htmlBanner += '<th>Select All <input type="checkbox" name="allitem_reject" value="1" onclick="allreject()"></th>';
    //}
    htmlBanner += '<th>Brand Name</th>' +
            '<th>Pharmaceutical Name</th>' +
            '<th>Type</th>' +
            '<th>Doctor Name</th>' +
            '<th>MRP</th>' +
            '<th>Order Qty</th>' +
            '<th>Gross Amount</th>' +
            '<th>Discount</th>' +
            '<th>Net Amount</th>' +
            '<th>Actions</th>' +
            '<!--<th>Reject</th>-->' +
            '<th>Comments</th>' +
            '<th>Log Info</th>' +
            '<th>Add Log</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';
    var order_total = 0;
    var item_count = 0;
    var order_gross = 0;
    var order_discount = 0;
    var medicine_delivery_charge = (typeof ordersdetails.order.patientinfo.medicine_delivery_charge != 'undefined') ? parseFloat(ordersdetails.order.patientinfo.medicine_delivery_charge) : 0;
    var prepaidamt = (typeof ordersdetails.order.prepayment != 'undefined') ? parseFloat(ordersdetails.order.prepayment.amount) : 0;
    var voucher_amount = (typeof ordersdetails.order.patientinfo.voucher_amount != 'undefined') ? parseFloat(ordersdetails.order.patientinfo.voucher_amount) : 0;
    $.each(ordersdetails.order.orderitem, function (key, val) {
        if (val.item_status != '8') {
            item_count++;
        }
    });
    $.each(ordersdetails.order.orderitem, function (key, val) {

        if (val.item_status != '8') {
            //item_count++;
            order_total = order_total + parseFloat(val.net_amount);
            order_gross += parseFloat(val.gross_amount);
            order_discount += parseFloat(val.discount_amount);
            //if(ordersdetails.OStatus==21){
            htmlBanner += '<tr>' +
                    '<td><input type="checkbox" name="item_reject"  value="' + val.item_code + '"></td>';
            //}
            htmlBanner += '<td>' + val.itemname + '</td>' +
                    '<td>' + val.pharmaname + '</td>';
            if (val.prescribed == "1") {
                htmlBanner += '<td><label name="l2vsetrxotg" id="l2vsetrxotg" data-rxset="true" style="display:block;"><span class="rx">Rx</span></label></td>';
            } else {
                htmlBanner += '<td></td>';
            }
            htmlBanner +=
                    '<td>' + val.doctor + '</td>' +
                    '<td>' + val.item_mrp + '</td>' +
                    '<td class="oneliner">' + val.quantity + ' </td>' +
                    '<td>' + val.gross_amount + '</td>' +
                    '<td> ' + val.discount_amount + '</td>' +
                    '<td>' + val.net_amount + '</td>';
            if (ordersdetails.OStatus == 21) {
                if (typeof (val.batch) == "undefined") {

                    htmlBanner += '<td> <button type="button" onclick=updateprice(' + ordersdetails._id + ',"' + val.item_code + '",' + val.quantity + ',' + val.item_mrp + ',"' + escape(val.itemname) + '",' + val.discount_amount + ',' + val.prescribed + ') class="btn btn-primary" >Edit</button></td>';
                }
                else {
                    htmlBanner += '<td><button type="button" onclick=viewbatchdetails(' + ordersdetails._id + ',"' + val.item_code + '",' + val.discount_amount + ') class="btn btn-primary" >view Details</button></td>';
                }
            }
            else {
                if (typeof (val.batch) == "undefined") {
                    htmlBanner += ' <td>N/A</td>';
                }
                else {
                    htmlBanner += ' <td><div class="dropdown"><button class="dropbtn">Batch details</button><div class="dropdown-content"><table  class="table table-bordered table-condensed table-striped table-responsive"><thead><tr><th>Quantity</th><th>Amount</th><th>batch Name</th><th>Expiry Time</th></tr></thead>  <tbody>';
                    $.each(val.batch, function (bkey, bval) {
                        var expiry = (typeof bval.expirydate != "undefined") ? bval.expirydate : "";
                        htmlBanner += '<tr><td>' + bval.quantity + '</td><td>' + bval.mrp + '</td><td>' + bval.batch + '</td><td>' + expiry + '</td></tr>';
                    });
                    htmlBanner += '  </tbody></table></div></div></td>';
                }
            }
            /*if(ordersdetails.OStatus!=0&&ordersdetails.OStatus!=18&&ordersdetails.OStatus!=9&&ordersdetails.OStatus!=6){
             if(item_count>1){
             htmlBanner+=' <td> <button type="button" onclick=itemrejectorder('+ordersdetails._id+',"'+val.item_code+'") class="btn btn-primary" >Reject</button></td>';
             }
             else{
             htmlBanner+=' <td>N/A</td>';
             }
             }
             else{
             htmlBanner+=' <td>N/A</td>';
             }
             */
            if (val.item_status == 9) {
                htmlBanner += '<td><a href="#" data-toggle="tooltip" title="' + val.item_reject_reason + '">Reason</a></td>';
            } else {
                htmlBanner += '<td>N/A</td>';
            }

            //htmlBanner+='<td><label id="l2vaccept" title="Log details"><a href="#" class="mpt"  onclick="showlogmodal(\''+ordersdetails._id+'\',\''+val.item_code+'\')"><i class="fa fa-info cust_check" aria-hidden="true"></i></a></label></td>';

            /*htmlBanner+='<td><div class="dropdown"><button class="dropbtn"> <i class="fa fa-info cust_check" aria-hidden="true"></i></button><div class="dropdown-content" style="right:10%;"><table class="table table-bordered table-condensed table-striped table-responsive"><thead><tr><th>Role</th><th>Name</th><th>Log Details</th><th>Date/Time</th></tr></thead><tbody>';
             var testdata ="";
             if(typeof ordersdetails.user_log != "undefined"){
             $.each(ordersdetails.user_log,function(bkey,bval){
             if(bval.item_code==val.item_code){
             testdata+='<tr><td>'+bval.role+'</td><td>'+bval.actionbyname+'</td><td>'+bval.log_reason+'</td><td>'+bval.action_date+'</td></tr>';
             }							
             });
             }
             
             if(testdata==""){
             htmlBanner+='<tr><td colspan="4">NA</td></tr>';
             }else{
             htmlBanner+=testdata;
             }
             htmlBanner+='</tbody></table></div></div></td>';*/

            /** changes htmlBanner+= **/
            var box1 = '<td><div class="dropdown"><button class="dropbtn"> <i class="fa fa-info cust_check" aria-hidden="true"></i></button><div class="dropdown-content" style="right:10%;"><table class="table table-bordered table-condensed table-striped table-responsive"><thead><tr><th>Role</th><th>Name</th><th>Log Details</th><th>Date/Time</th></tr></thead><tbody>';
            var testdata = "";
            if (typeof ordersdetails.user_log != "undefined") {
                $.each(ordersdetails.user_log, function (bkey, bval) {
                    if (bval.item_code == val.item_code) {
                        testdata += '<tr><td>' + bval.role + '</td><td>' + bval.actionbyname + '</td><td>' + bval.log_reason + '</td><td>' + bval.action_date + '</td></tr>';
                    }
                });
            }

            if (testdata == "") {
                htmlBanner += '<td colspan="">NA</td>';
            } else {
                htmlBanner += (box1 + testdata + '</tbody></table></div></div></td>');
            }
            /** changes **/

            htmlBanner += '<td> <a href="#" class="mpt" onclick="user_log(\'' + ordersdetails._id + '\',\'' + val.item_code + '\')">Add Log</a></td>';


            htmlBanner += '</tr> ';
        } else if (orderstatuscheck == "8" && (typeof val.cancelbeforeaccept == "undefined")) {
            //for order cancel
            //item_count++;
            order_total = order_total + parseFloat(val.net_amount);
            order_gross += parseFloat(val.gross_amount);
            order_discount += parseFloat(val.discount_amount);
            htmlBanner += '<tr style="background:#FFB4B7;">' +
                    '<td><input type="checkbox" name="item_reject"  value="' + val.item_code + '"></td>';
            htmlBanner += '<td>' + val.itemname + '</td>' +
                    '<td>' + val.pharmaname + '</td>';
            if (val.prescribed == "1") {
                htmlBanner += '<td><label name="l2vsetrxotg" id="l2vsetrxotg" data-rxset="true" style="display:block;"><span class="rx">Rx</span></label></td>';
            } else {
                htmlBanner += '<td></td>';
            }
            htmlBanner +=
                    '<td>' + val.doctor + '</td>' +
                    '<td>' + val.item_mrp + '</td>' +
                    '<td class="oneliner">' + val.quantity + ' </td>' +
                    '<td>' + val.gross_amount + '</td>' +
                    '<td> ' + val.discount_amount + '</td>' +
                    '<td>' + val.net_amount + '</td>' +
                    '<td>N/A</td>' +
                    '<td>N/A</td>' +
                    '<td>N/A</td>' +
                    '<td>N/A</td>';
            htmlBanner += '</tr> ';
        }
    });


    htmlBanner +=
            '</tbody>' +
            '</table>' +
            '</div>';
    if (ordersdetails.OStatus == 21) {
        htmlBanner +=
                '<div class="col-md-1 col-sm-12 col-xs-12 text-right view_prec">' +
                '<a href="#" class="comp_apply_btn  mpt" onclick="assignlogisticsvendor(' + ordersdetails._id + ')">Confirm</a>' +
                '</div>';
    }
    if (ordersdetails.OStatus == 21) {
        htmlBanner += '<div class="col-md-1 col-sm-12 col-xs-12 text-right view_prec">' +
                '<a href="#" class="reject_btn  mpt" onclick="rejectorder(' + ordersdetails._id + ')">Reject</a>' +
                '</div>';
    }
    /*if(ordersdetails.OStatus==21){
     htmlBanner+='<div class="col-md-1 col-sm-12 col-xs-12 text-right view_prec">'+
     '<a href="#" class="log_btn  mpt" onclick="user_log('+ordersdetails._id+')">Log</a>'+
     '</div>';
     }*/

    var wallet_amount = (typeof ordersdetails.order.patientinfo.wallet_amount == "undefined" ? "0" : ordersdetails.order.patientinfo.wallet_amount);
    order_total = order_total - wallet_amount;
    htmlBanner += '<a href="#" class="view_pres_btn" data-toggle="modal" data-target="#myModal">View Prescription</a>';
    if (ordersdetails.OStatus == 21) {
        htmlBanner += '<a class="view_pres_btn"  data-toggle="modal" data-target="#Uploadprescption" style="margin: 0px 7px 0px 5px !important;" > Upload Prescription</a>';
    }

    // if(ordersdetails.OStatus==0 || ordersdetails.OStatus==18 || ordersdetails.OStatus==6){
    var allowed_statusfor_showamount = new Array(0, 18, 1, 2, 3, 4, 5, 6, 106);
    if ($.inArray(ordersdetails.OStatus, allowed_statusfor_showamount) > -1) {
        htmlBanner += '<div class="col-md-2 col-sm-12 col-xs-12 text-right view_prec">' +
                '<label>Gross Amount &nbsp; : &nbsp; &#8377; ' + order_gross.toFixed(2) + '</label>' +
                '<label>Discount &nbsp; : &nbsp; &#8377;&nbsp; ' + order_discount.toFixed(2) + '</label>' +
                '<label>Wallet Amount &nbsp; : &nbsp; &#8377;' + wallet_amount + '</label>' +
                '<label>Shipping Charges &nbsp; : &nbsp; &#8377;' + medicine_delivery_charge.toFixed(2) + '</label>' +
                '<label>Prepaid Amount &nbsp; : &nbsp; &#8377;&nbsp; <span>' + prepaidamt.toFixed(2) + '</span></label>' +
                '<label>Voucher Amount &nbsp; : &nbsp; &#8377;&nbsp; <span>' + voucher_amount.toFixed(2) + '</span></label>' +
                '<label>Net Amount &nbsp; : &nbsp; &#8377;&nbsp; <span>' + (((order_total + medicine_delivery_charge) - prepaidamt) - voucher_amount).toFixed(2) + '</span></label>' +
                '</div>';



    }
    htmlBanner += '<div class="col-md-4 col-sm-6 col-xs-12 text-right">' +
            '<!--a href="#" class="print_invoice_btn" onclick="memodownload(' + ordersdetails._id + ')">Print Invoice</a>  &nbsp;' +
            '<a href="#" class="print_invoice_btn" onclick="cashmemodownload(' + ordersdetails._id + ')">Print Cash Memo</a-->';
    if (ordersdetails.OStatus != 24 && ordersdetails.OStatus != 21) {
        htmlBanner += '<a href="#" class="print_invoice_btn" onclick="memodownload(' + ordersdetails._id + ')">PRINT Cash MEMO</a>  &nbsp;' +
                '<a href="#" class="print_invoice_btn" onclick="shipmentlable(' + ordersdetails._id + ')">SHIPMENT LABEL</a>';
    }
    htmlBanner += '</div>' +
            '<div class="col-md-12 col-sm-12 col-xs-12">' + ((typeof ordersdetails.order.patientinfo.reject_reason == "undefined") ? "" : "<b>Reject Reason : </b>" + ordersdetails.order.patientinfo.reject_reason) + '</div>' +
            '</div>   ' +
            '<!-- Showing update Price  -->' +
            '<div class="modal fade" id="myPrice" role="dialog">' +
            '<div class="modal-dialog" style="width:900px;">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">Update MRP </h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<h5>Quantity: <span id=qty></span></h5>' +
            '<h6>Product Name:<span id=iname></span></h6>' +
            '<table class="table table-striped" id="vendorupdateprice">' +
            ' <thead id="tblHead">' +
            ' <tr>' +
            ' <th>Quantity</th>' +
            '<th>MRP</th>' +
            '<th>Batch</th>' +
            '<th>Expiry Month/Year</th>' +
            ' </tr>' +
            '</thead>' +
            '<tbody>';

    htmlBanner += '<tr><input type="hidden" id="quantity" name="quantity">' +
            '<td><input type="Number" onkeypress="return event.charCode >= 48 && event.charCode <= 57" class="form-control controlInput" id="changequantity1" min="1" name="changequantity1"></td>' +
            '<td><input type="Number" min="1" onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" title="Only Number" step="1" class="form-control controlInput" id="price1" name="price1"></td>' +
            '<td><input type="text" class="form-control controlInput" id="batchname1" name="batchname1" maxlength="20"></td>' +
            '<td class="expiry_monthyear"><input type="text" id="expiry_monthyear1" class="form-control datepicker" placeholder="YYYY-MM">' +
            '<span class="datepicker">' +
            '<span class="glyphicon glyphicon-calendar cust_cal"></span>' +
            '</span></td>' +
            '<td><button class="btn btn-success add-more" type="button" onclick="addmore()">+</button></td></tr>';
    htmlBanner += ' </tbody>' +
            '</table>' +
            '<button type="button" class="btn btn-primary" onclick="vendorupdateprice()">Update</button>' +
            '<input type="hidden" class="form-control controlInput" id="bbatchno1" name="bbatchno1" maxlength="20"  value="1">' +
            '<input type="hidden" id="l2omorder_id" name="l2omorder_id">' +
            '<input type="hidden" id="item_code" name="item_code">' +
            '<input type="hidden" id="disamount" name="disamount">' +
            '<input type="hidden" id="item_prescribed" name="item_prescribed">' +
            '<input type="hidden" id="batchcount" name="batchcount" value="1">' +
            '</div>' +
            '<div class="modal-footer">' +
            ' <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<!-- Showing batch update Price  -->' +
            '<div class="modal fade" id="batchmodel" role="dialog">' +
            '<div class="modal-dialog">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">View Batch Details </h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<h5>Quantity: <span id=qty1></span></h5>' +
            '<h6>Product Name:<span id=iname1></span></h6>' +
            '<input type="hidden" id="bquantity" name="bquantity">' +
            '<input type="hidden" id="vendor_batch_omorder_id" name="vendor_batch_omorder_id">' +
            '<input type="hidden" id="batch_item_code" name="batch_item_code">' +
            '<input type="hidden" id="batch_disamount" name="batch_disamount">' +
            '<input type="hidden" id="batch_rowcount" name="batch_rowcount">' +
            '<table class="table table-striped" id="vendorupdatebatchprice">' +
            ' <thead id="tblHead">' +
            ' <tr>' +
            ' <th>Quantity</th>' +
            '<th>MRP</th>' +
            '<th>Batch</th>' +
            '<th>Expiry Date</th>' +
            ' </tr>' +
            '</thead>' +
            '<tbody>';
    htmlBanner += ' </tbody>' +
            '</table>' +
            '<button type="button" class="btn btn-primary" onclick="vendorbatchupdateprice()">Update</button>' +
            '</div>' +
            '<div class="modal-footer">' +
            ' <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<!-- Showing Item Wise Reject  -->' +
            '<div class="modal fade" id="itemReject" role="dialog">' +
            '<div class="modal-dialog">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">Are  you  sure  You Want to Reject  This Order. </h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<div>' +
            '<select id="rejectreasons" style="width:550px;" required="">' +
            '<option value="Some medicines ordered by you are currently unavailable">Some medicines ordered by you are currently unavailable </option>' +
            '<option value="Medicines ordered by you are currently unavailable">Medicines ordered by you are currently unavailable </option>' +
            '<option value="Prescription shared by you is invalid"> Prescription shared by you is invalid</option>' +
            '</select>' +
            '<input type="hidden" id="item_reject_omorder_id" name="item_reject_omorder_id">' +
            '<input type="hidden" id="item_reject_code" name="item_reject_code">' +
            '</div>' +
            '</div>' +
            '<div class="modal-footer">' +
            ' <button type="button" class="btn btn-default" data-dismiss="modal" onclick="itemrejectsubmit()">Submit</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<!-- Showing Order Wise Log  -->' +
            '<div class="modal fade" id="orderLog" role="dialog">' +
            '<div class="modal-dialog">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">Log the Activity..! </h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<div>' +
            '<label>Log Info &nbsp;&nbsp;&nbsp;</label>' +
            '<input type="text" id="orderlogreasons" name="orderlogreasons" style="border:1px solid !important;width:500px;" required="required">' +
            '<input type="hidden" id="log_omorder_id" name="log_omorder_id">' +
            '<input type="hidden" id="log_item_id" name="log_item_id">' +
            '</div>' +
            '</div>' +
            '<div class="modal-footer">' +
            ' <button type="button" class="btn btn-default" onclick="orderlogsubmit()">Submit</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<!-- Showing Order Wise user Log  -->' +
            '<div class="modal fade" id="userLog" role="dialog">' +
            '<div class="modal-dialog">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">Log Details </h4>' +
            '</div>' +
            '<div class="modal-body" id="userLogbody">' +
            '</div>' +
            '<div class="modal-footer">' +
            '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<!-- Showing Order Wise Reject  -->' +
            '<div class="modal fade" id="orderReject" role="dialog">' +
            '<div class="modal-dialog">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">Are  you  sure  You Want to Reject  This Order. </h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<div>' +
            '<select id="orderrejectreasons" style="width:550px;" required="">' +
            '<option value="Some medicines ordered by you are currently unavailable">Some medicines ordered by you are currently unavailable </option>' +
            '<option value="Medicines ordered by you are currently unavailable">Medicines ordered by you are currently unavailable </option>' +
            '<option value="Prescription shared by you is invalid"> Prescription shared by you is invalid</option>' +
            '</select>' +
            '<input type="hidden" id="reject_omorder_id" name="reject_omorder_id">' +
            '<input type="hidden" id="reject_item_id" name="reject_item_id">' +
            '</div>' +
            '</div>' +
            '<div class="modal-footer">' +
            ' <button type="button" class="btn btn-default" data-dismiss="modal" onclick="orderrejectsubmit()">Submit</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<!-- Showing prescption images  -->' +
            '<div class="modal fade" id="myModal" role="dialog">' +
            '<div class="modal-dialog">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">Prescription </h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<table class="table table-striped" id="tblGrid">' +
            ' <thead id="tblHead">' +
            ' <tr>' +
            '<th>Action</th>' +
            ' </tr>' +
            '</thead>' +
            '<tbody>';
    if (typeof ordersdetails.order.prescription_file != 'undefined' && (ordersdetails.order.prescription_file).length != 0) {
        $.each(ordersdetails.order.prescription_file, function (key, val) {
            $.each(val, function (key, val1) {
                htmlBanner += '<tr>' +
                        '<td><a target="_blank" href="' + val1 + '">Full Image</a></td>' +
                        '</tr>';
            });
        });
    } else {

        htmlBanner += '<tr><td>NO Prescription</td></tr>';
    }
    htmlBanner += ' </tbody>' +
            '</table>' +
            '</div>' +
            '<div class="modal-footer">' +
            ' <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<!-- Showing prescption images uplaoding for l2   -->' +
            '<div class="modal fade" id="Uploadprescption" role="dialog">' +
            '<div class="modal-dialog">' +
            '<!-- Modal content-->' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">Upload Prescription </h4> ' +
            '</div>' +
            '<div class="modal-body">' +
            '<form  id="formsum"  method="post" enctype="multipart/form-data">' +
            '<input type="file" name="pic[]" id ="l2prescptionname" multiple>' +
            '<input type="hidden" name="orderid" value=' + ordersdetails._id + ' id="orderid">' +
            ' <button type="button" class="btn btn-success" data-dismiss="modal" onclick="l2prescptionupload()" >Upload</button>' +
            '</div></form>' +
            '<div class="modal-footer">' +
            ' <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</article>' +
            '</section>';

    $("#Custom_body").html(htmlBanner);
    $(".loader").hide();

    $('#ordertotal').html(order_total);
    var d = new Date(ordersdetails.order.patientinfo.expected_delivery_time);
    //var d=new Date(ordersdetails.order.patientinfo.scheduled_date);
    var date = d.getYear + "-" + d.getMonth + "-" + d.getDate();
    //$('#vendordate').datepicker({minDate: '-0d'});
    $('#vendordate').datepicker('setDate', date);
    $("#vendordate").datepicker('setStartDate', '0d');
}

function trackOrderView(result) {
    $(".loader").hide();
    var tdata = '';
    if (typeof result == 'string') {
        result = JSON.parse(result);
    }
    
    if(result.order_log.length <= 0){
        tdata = '<h4>No Data</h4>';
        $('#trackresult').html(tdata);
        $('#track').modal('show');
        return;
    }
    tdata = "<table class='table table-responsive'><tbody><tr><th>Order</th><th>User Name</th><th>User ID</th><th>Role</th><th>Action</th><th>Servicing Facility Name</th><th>Order Status</th><th>Updated On</th><th>Text</th></tr>"

    //console.log(popname);
    result = result.order_log;
    console.log(result);
    $.each(result, function (key, val) {
        tdata += '<tr><td>' + val.wodid + '</td><td>' + val.actionByName + '</td><td>' + val.actionById + '</td><td>' + val.role + '</td><td>' + val.action + '</td><td>' + val.popname + '</td><td>' + orderstatus(val.order_status) + '</td><td>' + val.created_date + '</td><td>' + val.reason + '</td></tr>';
    });
    tdata += '</tbody></table>';
    $('#trackresult').html(tdata);
    $('#track').modal('show');
    
}

	