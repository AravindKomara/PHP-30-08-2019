var runCallback = "";
function start_polling()
{
	var user_id=sessionStorage.getItem("loginuserid");
	//alert('2');
	//console.log('1');
	var _data = {user_id:user_id};
	
		_ajaxEventHandler("auto_call",_data,cbk_start_polling,NO_SHOW_LOADER);	
	console.log(user_id);
	getwidgetCount();

}
function cbk_start_polling()
{
	//if(runCallback){
	runCallback= window.setTimeout(function(){ 
    start_polling();    
}, 30000000);
	//}	
	//start_polling(user_id);	
}
function endcall(){
	$("#attendbutton").css("display","block");
	$("#endcallbutton").css("display","none");
	runCallback= window.setTimeout(function(){ 
    start_polling();    
}, 30000000);
}
