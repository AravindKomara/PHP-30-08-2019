function allordersview(ordersdetails) {
   // console.log(sessionStorage.getItem('loginid'));
    //var total_orders=20 ;//ordersdetails.length;
    //alert();
    $(".loader").show();
    ordersdetails = JSON.parse(ordersdetails);
    console.log(ordersdetails);
//$('#rxuploadedcount').html(ordersdetails.countn);
//console.log(ordersdetails.countn);
    htmlBanner = '<section class="container-fluid">' + 
	'<article class="main_content">' +
	'<div class="tab-content custom_tab_content">' +
	'<div role="tabpanel" class="tab-pane fade in active" id="mainreplacecontent">' +
	'<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
	'<div class="table-responsive">' +
	'<table id="example"  cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">' +
	'<thead>' +
	'<tr>' +
	'<th>MRN</th>' +
	'<th>Customer Name</th>' +
	' <th>' + 'Order No.' + '</th>' +
	'<th>Location</th>' +
	'<th>Order Created Date </th>' +
	'<th>Preferred Date/Time </th>' +
	'<th>Scheduled Date/Time </th>' +
	' <th>Vendor Assign Date</th>' +
	'<th>Vendor Name</th>' +
	'<th>Order Status</th>' +
	'<th>Order Details</th>' +
	'<th>Order Track</th>' +
	'</tr>' +
	'</thead>' +
	'<tbody>';
    $.each(ordersdetails.data, function (key, val) {
        //console.log(val._id);
        var patientname = val.order.patientinfo.name;
        patientname = patientname.replace("null", "");
        htmlBanner += '<tr>' +
		' <td>' + val.order.patientinfo.mrn + '</td>' +
		'<td>' + patientname + '</td>' +
		'<td>' + val._id + '</td>' +
		'<td>' + val.order.patientinfo.city + '</td>' +
		'<td>' + (val.order.order_status.created_date) + '</td>' +
		' <td>' + (val.order.patientinfo.expected_delivery_time) + '</td>';

        if (val.OStatus != 17 && val.OStatus != 21) {
            htmlBanner += '<td>' + (val.order.patientinfo.scheduled_date) + '</td>';
        } else {
            htmlBanner += '<td>-</td>';
        }
        htmlBanner += '<td>' + ((typeof (val.order.vendorinfo) == "undefined") ? "" : ((typeof val.order.vendorinfo.vendorassign_datetime == "undefined") ? "" : val.order.vendorinfo.vendorassign_datetime)) + '</td>' +
		'<td>' + ((typeof (val.order.vendorinfo) == "undefined") ? "" : ((typeof val.order.vendorinfo.VendorName == "undefined") ? "" : val.order.vendorinfo.VendorName)) + '</td>' +
		'<td>' + ((typeof(val.statusName[0])!="undefined")?val.statusName[0].Nomenclature:"NA") + '</td>' +
		'<td> <a onclick="vieworder(' + val._id + ')" target="_new" class="view">View</a> </td>' +
		'<td><a href="#" onclick="trackOrder(' + val._id + ')" class="track_btn">Deliver Track</a></td>' +
		'</tr>'; //href=order_view.php?id='+val._id.value+' 
    });
    htmlBanner += '</tbody>' +
	'</table>' +
	' </div>' +
	' </div>' +
	' </div>' +
	'</div>' +
	'</div>' +
	' </div>' +
	'</article>' +
	'</section>' +
	'</div>';

    setTimeout(function(){ 
		$("#vendor_assigned_count").html(ordersdetails.tobeconfirmed);
		$("#requested_pickup_count").html(ordersdetails.requested_pickup);
		$("#rejectedcount").html(ordersdetails.rejected);
		$("#completed_count").html(ordersdetails.completed);
		$("#allorder_count").html(ordersdetails.all_orders);
    }, 1000);

    $(".loader").hide();
    return htmlBanner;
}



function trackOrderView(result){
	var modalfooter='<button type="button" class="btn btn-default sa-success" data-dismiss="modal" style="color:#fff;">Close</button>';
	var myModalLabel="Order Tracking Status";
	var trackresult="";
	if(result.status==1){
		var tdata = ''; 
		if(result.data.order_log.length <= 0){
			tdata = '<h4>No Data</h4>';
			$('#trackresult').html(tdata);
			$('#track').modal('show');
		}else{
			tdata="<table class='table table-responsive'><thead><tr>"+
			"<th>Order</th>"+
			"<th>User Name</th>"+
			"<th>User ID</th>"+
			"<th>Role</th>"+
			"<th>Action</th>"+
			"<th>Servicing Facility Name</th>"+
			"<th>Order Status</th>"+
			"<th>Updated On</th>"+
			"<th>Text</th>"+
			"</tr></thead><tbody>";
			$.each(result.data.order_log, function (key, val) {
				tdata +='<tr><td>'+val.wodid+'</td>'+
				'<td>'+val.actionByName+'</td>'+
				'<td>'+val.actionById+'</td>'+
				'<td>'+val.role+'</td>'+
				'<td>'+val.action+'</td>'+
				'<td>'+val.popname+'</td>'+
				'<td>'+orderstatus(val.order_status)+'</td>'+
				'<td>'+val.created_date+'</td>'+
				'<td>'+val.reason+'</td></tr>';
			});
			tdata += '</tbody></table>';
			trackresult = tdata;
		}		
	}else{
		trackresult = result.message;
	}
	//console.log(trackresult);
	$(".loader").hide();
	$("#myModalLabel").html(myModalLabel);
	$("#trackresult").html(trackresult);
	$("#modalfooter").html(modalfooter);
	$("#Modal_for_all").modal('show');
}


function showorderview(resposne){
	var cancel_btn_on_statuses = [1, 2, 3, 4, 5];
	var show_statuses_the_start_btn = [0, 1, 2];
        var allowed_statusfor_showamount = [0,18,1,2,3,4,5,6,106];
    /*if (typeof resposne == 'string') {
        ordersdetails = JSON.parse(resposne);
    } else {
        ordersdetails = resposne;
    }*/
     //console.log(resposne.data);return;
     if(resposne.status==1){		
	   if(typeof resposne.data._id != "undefined"){
		ordersdetails = resposne.data;
		htmlBanner = 
                     '<br><section class="container-fluid">'+
                     '<article class="p_details">'+
                     '<div class="col-md-12 col-sm-12 col-xs-12 mp">'+            
		     '<section class="complete_order_search">'+
		     '<div class="col-xs-12 mp" style="border-bottom:1px solid #7DB0AC; margin-top:-10px; padding:5px;">'+
		     '<h5 style="text-decoration:none; font-size:18px;">'+
		     'Order ID # '+((typeof ordersdetails._id != "undefined")?ordersdetails._id:"")+
		     '| Order DID # '+((typeof ordersdetails.odid != "undefined")?ordersdetails.odid:"")+
		     '| MRN - '+((typeof ordersdetails.order.patientinfo.mrn != "undefined")?ordersdetails.order.patientinfo.mrn:"")+
		     '| Transaction ID - '+((typeof ordersdetails.transaction_code != "undefined")?ordersdetails.transaction_code:"")+
                     '</h5>'+
		     '</div>'+
                     '<article class="col-md-12 col-sm-12 col-xs-12 mobile_mp"><br>'+			
                     '<div class="col-md-2 col-sm-3 col-xs-12 mp">' +
                     '<div class="form-group">' +
                     '<label style="margin-bottom:10px;">Customer Name:<br><span style="color:#6D6D6D;">'+ordersdetails.order.patientinfo.name+'</span></label>'+
                     '<label style="margin-bottom:10px;">Mobile No:<br><span style="color:#6D6D6D;">'+ordersdetails.order.patientinfo.contact+'</span></label>'+
                     '<label style="margin-bottom:10px;">Alternate Mobile No:<br><span style="color:#6D6D6D;">'+(ordersdetails.order.patientinfo.alternetcontactno ? ordersdetails.order.patientinfo.alternetcontactno :"")+'</span></label>' +  
                     '</div>'+
                     '</div>'+
                     '<div class="col-md-4 col-sm-3 col-xs-12 mp">'+
		     '<label style="margin-bottom:10px;">Delivery Address:<br><span style="color:#6D6D6D;">'+ordersdetails.order.patientinfo.address+'</span></label>'+
                     '<label style="margin-bottom:10px;">Pincode:<br><span style="color:#6D6D6D;">'+ordersdetails.order.patientinfo.pincode+'</span></label>'+
                     '</div>'+
		     '<div class="col-md-3 col-sm-3 col-xs-12 mp">'+
		     '<label style="margin-bottom:10px;">Preferred Date/Time:<br><span style="color:#6D6D6D;">'+changedate(ordersdetails.order.patientinfo.expected_delivery_time ? ordersdetails.order.patientinfo.expected_delivery_time : "NaN")+'</span></label>';
            if(ordersdetails.OStatus == 21){
		 htmlBanner+=
                     '<label style="margin-bottom:10px;">Book the Slot :</lable><br>'+
                     '<div class="col-md-6 mp">'+
                     '<button name="job_name" onclick="open_slot_modal();"  id="selecttimeslot" data-scheduled_date="'+changedate(ordersdetails.order.patientinfo.scheduled_date)+'" data-mrn="'+ordersdetails.order.patientinfo.mrn+'" data-popid="'+ordersdetails.order.patientinfo.facility_id+'" data-age="'+ordersdetails.order.patientinfo.age+'" data-gender="'+ordersdetails.order.patientinfo.gender+'" data-pincode="'+ordersdetails.order.patientinfo.pincode+'" data-latitude="'+ordersdetails.order.patientinfo.delivery_lat+'" data-longitude="'+ordersdetails.order.patientinfo.delivery_lng+'"  class="btn btn-success">Select slot</button>'+
                     '<hidden data_starttime="" data_date="" data_trasactionid="" id="bookedselecttime" style="color:#408DAE"></hidden>'+
                     '<hidden data_endtime="" data_date="" data_trasactionid="" id="bookedselecttime" style="color:#408DAE"></hidden>'+
                     '<label style="color:#408DAE" id="showbookedselecttime"></lable>'+
                     '</div>';
	   }else{
                htmlBanner +=
                             '<label style="margin-bottom:10px;">Scheduled Date/Time:</lable><br>'+
			     '<div class="col-md-6 mp">'+
			     '<input type="text" id="vendordate" onchange="settimeslot();" class="form-control datepicker" placeholder="YYYY-MM-DD" style="margin-bottom:5px; font-size:14px; font-weight:100; width:135px;">' +
                             '<span class="datepicker"></span>'+
			     '<select id="vendortime" name="job_name" class="form-control new-status" style="margin-bottom:5px; font-size:14px; font-weight:100; width:135px;">' +
                             '<option id="10amslot" value="14:00:00">10AM-02PM</option>'+
                             '<option id="2pmslot" value="18:00:00">02PM-06PM</option>'+
                             '<option id="6pmslot" value="22:00:00">06PM-10PM</option>'+
                             '</select>'+
			     '</div>';
	    
	
	  }			
            htmlBanner +='</div>';	
            if(ordersdetails.OStatus == 21){
                    htmlBanner += '<div class="col-md-3 col-sm-12 col-xs-12 cancel_order text-left">' +
                    '<label>Logistics Vendor :</label>'+
                    '<select name="vendor" id="logisticsvendor" class="form-control new-status">'+
                    '<option value="callhealth">Callhealthpickup</option>'+
                    '<option value="vendorpickup">VendorPickup</option>'+
                    '</select>'+
                    '</div>';
	    }			
            
			///////// end the box code  ///////////
			
	    htmlBanner +='</article>'+
            '</section>'+
            '<br>'+
            //table statting
            '<div class="col-md-12 col-sm-12 col-xs-12 mp">'+
            '<div class="table-responsive">'+
            '<table class="table table-condensed table-bordered table-striped medicine_home_order_table" id="toggleColumn-datatable">'+
            '<thead>'+
            '<tr>'+
            '<th>Select All <input type="checkbox" name="allitem_reject" value="1" onclick="allreject()"></th>'+
            '<th>Brand Name</th>'+
            '<th>Pharmaceutical Name</th>'+
            '<th>Type</th>'+
            '<th>Doctor Name</th>'+
            '<th>Order Qty</th>'+
            '<th>MRP</th>'+
            '<th>Gross Amount</th>'+
            '<th>Net Amount</th>'+
            '<th>Discount</th>'+
            '<th>Actions</th>'+
            '<th>Comments</th>'+
            '<th>Log Info</th>'+
            '<th>Add Log</th>'+
            '</tr>'+
            '</thead>'+
            '<tbody>';
            var Tgross_amount=0;
            var Tnet_amount=0;
            var Tdiscount_amount=0;
            var medicine_delivery_charge = (typeof ordersdetails.order.patientinfo.medicine_delivery_charge != 'undefined')?parseFloat(ordersdetails.order.patientinfo.medicine_delivery_charge):0;
            var prepaidamt = (typeof ordersdetails.order.prepayment != 'undefined')?parseFloat(ordersdetails.order.prepayment.amount):0;
	    var voucher_amount = (typeof ordersdetails.order.patientinfo.voucher_amount != 'undefined')?parseFloat(ordersdetails.order.patientinfo.voucher_amount):0;
            $.each(ordersdetails.order.orderitem, function (key, val) {
                   Tgross_amount = parseFloat(Tgross_amount) + parseFloat(val.gross_amount);
                   Tnet_amount =   parseFloat(Tnet_amount) + parseFloat(val.net_amount);
                   Tdiscount_amount = parseFloat(Tdiscount_amount) + parseFloat(val.discount_amount);
                   if (val.item_status == "8") {
                            htmlBanner += '<tr style="background:#FFB4B7;">';
                    } else {
                            htmlBanner += '<tr style="">';
                    }
                    htmlBanner +=
                          '<td><input type="checkbox" name="item_reject"  value="' + val.item_code + '"></td>'+
                          '<td>'+(val.manufacturer ? val.manufacturer : "")+'</td>' +
                          '<td>'+(val.itemname ? val.itemname : "")+'</td>';
                    if (val.type == 1) {
                            htmlBanner += '<td>Rent</td>';
                    }else if (val.type == 2) {
                            htmlBanner += '<td>Sale</td>';
                    }else{
                            htmlBanner += '<td>-</td>';
                    }
                    htmlBanner +=
                            '<td>' + (val.doctorname ? val.doctorname : "") + ' </td>' +
                            '<td class="oneliner">' + (val.quantity ? val.quantity : "1") + ' </td>' +
                            '<td>' + val.MRP + '</td>' +
                            '<td>' + val.gross_amount + '</td>' +
                            '<td>' + val.net_amount + '</td>' +
                            '<td>' + val.discount_amount + '</td>' ;
                    //edit and view details tab td
                    if (ordersdetails.OStatus == 21) {
                            if (typeof (val.batch) == "undefined") {
                                htmlBanner+='<td> <button type="button" onclick=updateprice_popup('+ordersdetails._id+',"'+val.item_code+'","'+escape(val.itemname)+'",'+val.quantity+','+val.item_mrp+','+val.discount_amount+','+val.prescribed+') class="btn btn-primary" >Edit</button></td>';
                            }else{
                                htmlBanner+='<td><button type="button" onclick=viewbatchdetails('+ordersdetails._id+',"'+val.item_code+'","'+escape(val.itemname)+'",'+val.quantity+','+val.discount_amount+') class="btn btn-primary" >view Details</button></td>';  
                            }
                    }else if (val.item_status != 9) {
                            if (typeof (val.batch) == "undefined") {
                                  htmlBanner += ' <td>N/A</td>';
                            }else{
                              htmlBanner += ' <td><div class="dropdown"><button class="dropbtn">Batch details</button><div class="dropdown-content"><table  class="table table-bordered table-condensed table-striped table-responsive"><thead><tr><th>Quantity</th><th>Amount</th><th>batch Name</th></tr></thead>  <tbody>';
                              $.each(val.batch, function (bkey, bval) {
                                    htmlBanner += '<tr><td>' + bval.quantity + '</td><td>' + bval.mrp + '</td><td>' + bval.batch + '</td></tr>';
                              });
                                    htmlBanner += '  </tbody></table></div></div></td>';
                            }
                    } else {
                            htmlBanner +='<td>N/A</td>' +
                            '<td>N/A</td>';
                    }

                    //comments td
                    if (val.item_status == 9) {
                            htmlBanner += '<td><a href="#" data-toggle="tooltip" title="' + val.item_reject_reason + '">Reason</a></td>';
                    } else {
                            htmlBanner += '<td>N/A</td>';
                    }

                    //showing log information if log is added
                    if (val.item_status != 9) {
                            var logtable =
                                            '<td>' +
                                            '<div class="dropdown">' +
                                            '<button class="dropbtn"> <i class="fa fa-info cust_check" aria-hidden="true"></i></button>' +
                                            '<div class="dropdown-content" style="right:10%;">' +
                                            '<table class="table table-bordered table-condensed table-striped table-responsive">' +
                                            '<thead>' +
                                            '<tr>' +
                                            '<th>Role</th><th>Name</th><th>Log Details</th><th>Date/Time</th></tr></thead><tbody>';
                            var logdata = "";
                            if (typeof ordersdetails.user_log != "undefined") {
                                    $.each(ordersdetails.user_log, function (bkey, bval) {
                                            if (bval.item_code == val.item_code) {
                                                    logdata += '<tr><td>' + bval.role + '</td><td>' + bval.actionbyname + '</td><td>' + bval.log_reason + '</td><td>' + bval.action_date + '</td></tr>';
                                            }
                                    });
                            }
                            if (logdata == "") {
                                    htmlBanner += '<td colspan="">NA</td>';
                            } else {
                                    htmlBanner += (logtable + logdata + '</tbody></table></div></div></td>');
                            }
                       //add log td
                            htmlBanner += '<td> <a href="#" class="mpt" onclick="addLog_popup(\'' + ordersdetails._id + '\',\'' + val.item_code + '\')">Add Log</a></td>';
                    } else {
                            htmlBanner += 
                                            '<td>N/A</td>' +
                                            '<td>N/A</td>';
                    }

                    '</tr>';

            });
   htmlBanner +=
            '</tbody>' +
            '</table>' +
            '</div>';
	//end of table
   
	//confirm and reject buttons
        if (ordersdetails.OStatus == 21) {
                htmlBanner +=
                '<div class="col-md-1 col-sm-12 col-xs-12 text-right view_prec">' +
                '<a href="#" class="comp_apply_btn  mpt" onclick="assignlogisticsvendor(' + ordersdetails._id + ')">Confirm</a>' +
                '</div>'+
                '<div class="col-md-1 col-sm-12 col-xs-12 text-right view_prec">' +
                '<a href="#" class="reject_btn  mpt" onclick="rejectorder_popup(' + ordersdetails._id + ')">Reject</a>' +
                '</div>';
        }
       
        //view prescription and upload prescrption buttons
        var wallet_amount=(typeof ordersdetails.order.patientinfo.wallet_amount=="undefined" ?"0":ordersdetails.order.patientinfo.wallet_amount);
        Tnet_amount=Tnet_amount-wallet_amount;
        htmlBanner+='<a href="#" class="view_pres_btn" onclick="viewpresmodal('+ordersdetails.order.prescription_file+')">View Prescription</a>';
        if(ordersdetails.OStatus==21){
        htmlBanner+='<a class="view_pres_btn"  onclick="uploadpresmodal('+ordersdetails._id+')"  style="margin: 0px 7px 0px 5px !important;" > Upload Prescription</a>';
        }

	//displaying total amount  
       if(jQuery.inArray(ordersdetails.OStatus, allowed_statusfor_showamount) >= 0) {
             htmlBanner+='<div class="col-md-2 col-sm-12 col-xs-12 text-right view_prec">'+
             '<label>Gross Amount &nbsp; : &nbsp; &#8377; '+Tgross_amount.toFixed(2)+'</label>'+	
            '<label>Discount &nbsp; : &nbsp; &#8377;&nbsp; '+Tdiscount_amount.toFixed(2)+'</label>'+
            '<label>Wallet Amount &nbsp; : &nbsp; &#8377;'+wallet_amount+'</label>'+
            '<label>Shipping Charges &nbsp; : &nbsp; &#8377;'+medicine_delivery_charge.toFixed(2)+'</label>'+
            '<label>Prepaid Amount &nbsp; : &nbsp; &#8377;&nbsp; <span>'+prepaidamt.toFixed(2)+'</span></label>'+
            '<label>Voucher Amount &nbsp; : &nbsp; &#8377;&nbsp; <span>'+voucher_amount.toFixed(2)+'</span></label>'+
            '<label>Net Amount &nbsp; : &nbsp; &#8377;&nbsp; <span>'+(((Tnet_amount + medicine_delivery_charge)-prepaidamt) -voucher_amount).toFixed(2)+'</span></label>'+
            '</div>';
      }
      //print cash memo and shipment label buttons
      htmlBanner+=
              '<div class="col-md-4 col-sm-6 col-xs-12 text-right">'+
	      '<!--a href="#" class="print_invoice_btn" onclick="memodownload('+ordersdetails._id+')">Print Invoice</a>  &nbsp;'+
	      '<a href="#" class="print_invoice_btn" onclick="cashmemodownload('+ordersdetails._id+')">Print Cash Memo</a-->';
	      if(ordersdetails.OStatus!=24 && ordersdetails.OStatus!=21){ 
		   htmlBanner+='<a href="#" class="print_invoice_btn" onclick="memodownload('+ordersdetails._id+')">PRINT Cash MEMO</a>  &nbsp;'+
			       '<a href="#" class="print_invoice_btn" onclick="shipmentlable('+ordersdetails._id+')">SHIPMENT LABEL</a>';
              }		
   }else{
     if(resposne.data.length <= 0) {
          alert(resposne.message);
          $(".loader").hide();
          console.log(resposne);
     }	
   }
   
    $("#Custom_body").html(htmlBanner);
    $(".loader").hide();
    var d = new Date(ordersdetails.order.patientinfo.expected_delivery_time);
    var date = d.getYear + "-" + d.getMonth + "-" + d.getDate();
    $('#vendordate').datepicker('setDate', date);
    $("#vendordate").datepicker('setStartDate', '0d');
	

}
}



