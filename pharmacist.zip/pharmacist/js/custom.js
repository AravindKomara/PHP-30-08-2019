var activeLineitem="";
var global_pharmaorderid="";
function allOrders(ajaxMethod, SuccessFn, withSearch, skip, pagination,type) {
    console.log(pagination);
    withSearch = withSearch || false;
    ajaxMethod = ajaxMethod || false;
    pagination = pagination || false;
    skip = skip || '1';
    sessionStorage.setItem("ajaxMethod", ajaxMethod);
    sessionStorage.setItem("SuccessFn", SuccessFn);
    sessionStorage.setItem("withSearch", withSearch);
    sessionStorage.setItem("pagination", pagination);
    sessionStorage.setItem("skip", skip);
    var _data = {};
  
    if(type=="search" && $.trim($("#searchvalue").val())!=""){
		//alert($("#searchtext").val());
		if($("#searchtext").val()=="orderidser"){
			_data.orderidser = $("#searchvalue").val();
		}else if($("#searchtext").val()=="orderdidser"){
			_data.orderdidser = $("#searchvalue").val();
		}else{
                    _data.mrn = $("#searchvalue").val();
                }
	}
  
    _data.vendorid = sessionStorage.getItem('pharmacist_user_id');
    _data.pagination = true;
    _data.skip = skip;
    _data.limit = 10;
    //_ajaxEventHandler(ajaxMethod, _data, SuccessFn, SHOW_LOADER);
     console.log(_data);
    // $("#search_form")[0].reset();
    _customeDataTable(_data, ajaxMethod, SuccessFn, SHOW_LOADER);
}

function _customeDataTable(_data, ajaxMethod, SuccessFn, showLoader) {
    showLoader = showLoader || 1;
    if (showLoader == '1') {
        $(".loader").show();
    }
    _data.method = ajaxMethod;
    _data.type = "pharmacist";
    var url = sessionStorage.getItem("base_url") + 'OMS/api/medicine_supply.php/v1/getMedOrdersByFilter';
    $("#Custom_body").customeDataTable({
        data: _data,
        orderby: 1,
        actionurl: url,
        actiontype: "POST",
        tableprepare: SuccessFn,
        pagination: _data.pagination,
        perpage: _data.limit,
        search: false,
        customsearch: _data.customsearch,
        skip: _data.skip,
        sortBy:"DESC"
    });
    $(".loader").hide();
}

function trackOrder(orderid) {
    if (orderid == "") {
        alert("Please Select the Correct Order.")
    } else {
        var _data = {order_id: orderid};
        _ajaxEventHandler('ordertrack', _data, trackOrderView, SHOW_LOADER,"POST","operation.php/v1/");
    } 
}

function vieworder(orderid) {
    var _data = {orderid: orderid};
    var data = _ajaxEventHandler("getorderdetails",_data, showorderview, SHOW_LOADER);
    //console.log(data);
}



function vendorupdateprice(){
	var qty=0;
	var newvalues = [];
	var rowcount=$("#batchcount").val();
	//var orderqty=$('#changequantity1').val();
	var orderqty1 = 0;
	//alert(orderqty);return;
    //alert(orderqty);
	var order_id=$('#phorder_id').val();
	var item_code=$('#item_code').val();//price2
	var item_prescribed=$('#item_prescribed').val();
    //alert(item_prescribed);
	var error="";
	//alert($('#quantity_1').val());
	var total_qty=parseInt($('#quantity_1').val());
    //alert(total_qty);
	//var check_qty=0;	
	for(var i=1;i<=rowcount;i++){
		$("input[name='changequantity"+i+"']").each(function(){
			qty = $("input[id='"+this.id+"']").val();
			if(qty=="" || qty=="0" || typeof(qty)=="undefined"){
				//error = "Please provide correct quantity.";
				return false;
			}
			mrp = $("#price"+i).val();
			if(mrp=="" || mrp=="0" || typeof(mrp)=="undefined"){
				error = "Please provide correct MRP.";
				return false;
			}
			
			var batch = $("#batchname"+i).val();
			var expirydate = $("#expiry_monthyear"+i).val();
			orderqty1=parseInt(orderqty1)+parseInt(qty);			
            /*if(orderqty <= 0 || orderqty1 !=orderqty ){
				error = "Please provide correct quantity.";
				return false;
			}*/
            if($.trim($("#batchname"+i).val())==""){
				error = "Please provide the batch details.";
				return false;
			}
			if($.trim($("#expiry_monthyear"+i).val())=="" && item_prescribed=="1"){
				error = "Please provide an expiry date.";
				return false;
			}
                        
			//check_qty = check_qty + parseInt(qty);
			var data = {quantity:qty, mrp:mrp, batch:batch,expirydate:expirydate};			
			newvalues.push(data);
		});
	}
	if(error!=""){
		alert(error); return false;
	}
	if(total_qty!=orderqty1){
		alert("Quantity entered is incorrect.");
		//error = "Quantity entered is incorrect.";
		return false;
	}	
	if(orderqty1 <= 0){
		alert("Quantity cannot be ZERO.");
		return false;
	}
	var _data = {order_id:order_id,item_code:item_code,batchdata:newvalues};
	console.log(_data);
	global_pharmaorderid = order_id;
	_ajaxEventHandler("updateMedicineItem",_data,commonres_forvendormethods,SHOW_LOADER);   
}

//response of vendor 
function commonres_forvendormethods(resposne) {
    $(".loader").hide();
    console.log(resposne);
    if (typeof resposne == 'string') {
        Obj = JSON.parse(resposne);
    } else {
        Obj = resposne;
    }
    if (Obj.status == "1") {
        alert(Obj.message);
        $("#Modal_for_all").modal("hide");
        vieworder(global_pharmaorderid);
    } else {
        alert(Obj.message);
    }
}

function addmore(){
    var next=$("#batchcount").val();
    next = parseInt(next)+1;
    $("#batchcount").val(next);
    $("#vendorupdateprice").append(
		'<tr>'+
		'<td><input type="Number" class="form-control controlInput"  onkeypress="return event.charCode >= 48 && event.charCode <= 57" id="changequantity'+next+'" name="changequantity'+next+'"></td>'+
		'<td><input type="Number" onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46"  class="form-control controlInput"  id="price'+next+'" name="price"></td>'+
		'<td><input type="text" class="form-control controlInput" id="batchname'+next+'" maxlength="20" name="batchname'+next+'"></td>'+
		'<td class="expiry_monthyear"><input type="text" id="expiry_monthyear'+next+'" class="form-control datepicker_monthyear" placeholder="YYYY-MM"><!--span class="datepicker"><span class="glyphicon glyphicon-calendar cust_cal"></span></span--></td>'+
		'<td><button type="button" class="btn btn-danger" onclick="removelast()">-</button></td><td><input type="hidden" class="form-control controlInput" id="bbatchno'+next+'" name="bbatchno'+next+'" maxlength="20"  value="'+next+'"></td>'+
		'</tr>'
	);
}

function removelast(){
	var next=$("#batchcount").val();
	next = parseInt(next)-1;
	$("#batchcount").val(next);
	$('#vendorupdateprice tr:last').remove();
}

function uploadpresmodal(phorder_id,mrn,type){
    var header_data = "";
    var body_data = "";
    var footer_data = "";
    if(type=="1"){
        type="Invoice";
    }else{
        type="Prescription";
    }
    header_data +='<h3 class="modal-title" style="width:300px;" id="myModalLabel">Upload '+type+' </h3>';
    body_data +='<form  id="formsum"  method="post" enctype="multipart/form-data">'+
	'<input type="file" name="pic[]" id ="l2prescptionname" multiple>'+
	'<input type="hidden" name="orderid" value='+phorder_id+' id="pre_orderid">'+
	'<input type="hidden" name="pre_mrn" value='+mrn+' id="pre_mrn">'+    
	'</form>';
   if(type == "Invoice"){
      footer_data+= '<button type="button" class="btn btn-success"  onclick="l2invoiceupload()" >Upload</button>';
   }else{
     footer_data+= '<button type="button" class="btn btn-success"  onclick="l2prescptionupload()" >Upload</button>';  
   }
    
    $("#myModalLabel").html(header_data);
    $("#trackresult").html(body_data);
    $("#modalfooter").html(footer_data);
    $("#Modal_for_all").modal("show");
}

function viewpresmodal(){
	var prescription_file = sessionStorage.getItem("prescription_images");
	//console.log(prescription_file);
    //alert(prescription_file);
    var header_data = "";
    var body_data = "";
    header_data +='<h4 class="modal-title">Prescription </h4>';
	body_data +='<table class="table table-striped" id="tblGrid">'+
	'<thead id="tblHead">'+
	'<tr>'+
	'<th>Action</th>'+
	'</tr>'+
	'</thead>'+
	'<tbody>';
	var prescription_file = JSON.parse(prescription_file);
	if(typeof  prescription_file != 'undefined' && (prescription_file).length!=0){		
		var i = 1;
		$.each(prescription_file,function(key,val){
			console.log(val);
			if(typeof val.fullpath!="undefined"){
				var name=(typeof val.filename!="undefined")?val.filename:"Prescription file "+(i+1);
				body_data += "<tr><td><div class='col-xs-12'><div class='col-xs-12' style='margin:10px;'>"+i+". "+name+ " &nbsp; &nbsp; <a href='"+val.fullpath+"' target='_blank' class='track_btn'> View </a></div></div></td></tr>";
			}
			i = i + 1;
		});
	}else{
		body_data+='<tr><td>Prescription is not available.</td></tr>';	
	}
	body_data+= '</tbody></table>';
	console.log(body_data);
	
	var footer_data='<button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>';
     
	$("#modalfooter").html(footer_data);
    $("#myModalLabel").html(header_data);
    $("#trackresult").html(body_data);
    $("#Modal_for_all").modal("show");
}

//rejecting order
function rejectorder_submit(){	
    var order_id=parseInt($('#reject_omorder_id').val());
	global_pharmaorderid = order_id;
	var item_ids=[];
	$("input:checkbox:checked").map(function(){
		item_ids.push($(this).val());
	});
    //var item_ids=$('#reject_item_id').val();
    //var rejectreasons= $('#orderrejectreasons').val();
	var rejectreasons= $('#orderrejectreasons').val();
	if(rejectreasons==""){
		alert("Please provide a Reason.");
		return;
	}
    var vendorid=sessionStorage.getItem('pharmacist_user_id');
    var vendorname=sessionStorage.getItem('pharmacist_user_name');
	var length=item_ids.length;
	if(length){
		var _data = {
			order_id:order_id,
			item_ids:item_ids,
			rejectreasons:rejectreasons,
			vendorid:vendorid,
			vendorname:vendorname
		};
		_ajaxEventHandler("reject_order",_data,commonres_forvendormethods,SHOW_LOADER);
	}else{
		alert("Please select a Medicine, To Reject");
	}
}



function addLog_popup(phorder_id){ 
	var header_data = "";
	var body_data = "";
	var footer_data="";
	var log_array=[];
	$("input:checkbox:checked").map(function(){
		log_array.push($(this).val());
	});
	var length =log_array.length;
	if(length){
		header_data +=
		'<div class="modal-header">'+
		'<!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->'+
		'<h4 class="modal-title">Log the Activity..! </h4>'+
		'</div>';
		body_data +=
		'<div class="modal-body">'+
		'<div>'+
		'<label>Log Info &nbsp;&nbsp;&nbsp;</label>'+
		'<input type="text" id="orderlogreasons"  name="orderlogreasons" style="border:1px solid !important;width:500px;"  class="form-control" required="required">'+
		'<input type="hidden" value = '+phorder_id+' id="log_omorder_id" name="log_omorder_id">'+
		'<input type="hidden" value = '+log_array+' id="log_item_id" name="log_item_id">'+
		'</div>'+
		'</div>';
         footer_data+='<button type="button" class="btn btn-primary" data-dismiss="modal" onclick="orderlogsubmit()">Add Log</button>';
        
    $("#myModalLabel").html(header_data);
    $("#trackresult").html(body_data);
    $("#modalfooter").html(footer_data);
    $("#Modal_for_all").modal("show");
    }else{
		alert("Please select a Medicine, To Log!");
    }
}

function orderlogsubmit(){
   
	var pharmaorderid=$('#log_omorder_id').val();
    global_pharmaorderid = pharmaorderid;
	var item_ids=$('#log_item_id').val();
	var logreasons=$('#orderlogreasons').val();
	var role='Eqvendor';
	if($.trim(logreasons)==''){
		alert('Kindly fill Log info!');
		return;
	}else{
		var vendorid=sessionStorage.getItem('pharmacist_user_id');
		var vendorname=sessionStorage.getItem('pharmacist_user_name');
		var _data = {
			omorder_id:pharmaorderid,
			item_ids:item_ids,
			rejectreasons:logreasons,
			vendorid:vendorid,
			vendorname:vendorname,
			role:role
		};
		//_ajaxEventHandler("logorder",_data,res_logorder,SHOW_LOADER);
        _ajaxEventHandler("create_log",_data,commonres_forvendormethods,SHOW_LOADER);
	}
}

function res_logorder(response){
	console.log(response);
	var resp = JSON.parse(response);
	alert(resp.msg);
	setTimeout(function(){ location.reload(); }, 1000);
	$(".loader").hide();
	$("#orderlogreasons").val("");
	$("#Modal_for_all").modal("hide");
}
/*
function open_slot_modal(){
	var header_data = "";
	var body_data = "";
	var itemcodes = [];
	$("input:checkbox:checked").map(function(){
		itemcodes.push($(this).val());
	});
	if($.trim(itemcodes)==""){
		alert("Please select  test name");	
		return false; 
	}
	if($.trim($("#selecttimeslot").attr("data-pincode"))==""){
		alert("Please provide proper pincode.");
		return false; 
	}
	var tommorowDate = $("#selecttimeslot").attr("data-scheduled_date").split(" ");

	header_data +='<h4 class="modal-title" id="myModalLabel">Choose the slot</h4><span id="walletbal"></span>';	 
	body_data +='<div>'+
	"<div class='input-group date datepicker' id='orderdatediv'>"+
	"<input id='mainorderdate' type='text' onchange='fetch_slot();' class='form-control' value='' readonly=''>"+				
	"<span class='input-group-addon'>"+
	"<i class='fa fa-calendar' aria-hidden='true'></i>"+
	"</span>"+
	"</div>"+
	"</div>"+
	'<div id="londing_view">'+
	'<div class="loader" style="display:block"></div>'+
	'</div>'+
	'<div id="slotdiv"></div>';

	$("#myModalLabel").html(header_data);
	$("#trackresult").html(body_data);
	$("#Modal_for_all").modal("show");
	$("#mainorderdate").val(tommorowDate[0]);
	fetch_slot(itemcodes);	
}

function fetch_slot(itemcodes){
	console.log(itemcodes);
	var _data = {
		from_date:$("#mainorderdate").val(), 
		to_date:$("#mainorderdate").val(),
		business_id:"2",
		sub_business_id:"9",
		service_did:itemcodes,
		pop_id:$("#selecttimeslot").attr("data-popid"),
		patient_mrn:$("#selecttimeslot").attr("data-mrn"),
		patient_age:$("#selecttimeslot").attr("data-age"),
		patient_gender:"",
		preferred_officer:"",
		pin_code:$("#selecttimeslot").attr("data-pincode"),
		order_latitude:$("#selecttimeslot").attr("data-latitude"),
		order_longitude:$("#selecttimeslot").attr("data-longitude"),
		normal_slots:"Y"
	}
	console.log(_data);
	_ajaxEventHandler('fetch_slots', _data, response_fetch_slot, SHOW_LOADER,"POST","operation.php/v1/");
}

function response_fetch_slot(response){
	console.log(response);
	$(".loader").hide();
	var senddate = $("#mainorderdate").val();
        var htmlstring="";
	if(response.success==="1"){
		$.each(response.data[senddate], function (key, val) {
			if(val.is_booked!=1){
				var from_time=senddate+" "+val.from_time;
				var to_time=senddate+" "+val.to_time;
				htmlstring+="<button class='btn btn-success' style='margin:5px;' onclick='booktheslot(\""+val.transaction_id+"\",\""+senddate+"\",\""+val.from_time+"\",\""+val.to_time+"\")'>"+datetime24to12(from_time)+" - "+datetime24to12(to_time)+"</button>";
			}		   
		});
		if(htmlstring==""){
			htmlstring="<br><label>Slots are not available.</label>";
		}
		$("#slotdiv").html(htmlstring);
	}else{
		console.log(response.message);
		alert(response.message);
	}
}
*/
function datetime24to12(date24){
	var date24 = date24.split(' ');
	var time = date24[1].slice(0, 8);
	var H = +time.substr(0, 2);
	var h = (H % 12) || 12;
	var ampm = H < 12 ? "AM" : "PM";
	time = h + time.substr(2, 3) + ampm;
	return time;
}

function booktheslot(transaction_id,selected_date,from_time,to_time){
	$("#bookedselecttime").attr("data_starttime",from_time);
    $("#bookedselecttime").attr("data_endtime",to_time);
	$("#bookedselecttime").attr("data_date",selected_date);
	$("#bookedselecttime").attr("data_trasactionid",transaction_id);
	$("#showavailableslot").modal("hide");
	$("#showbookedselecttime").html(selected_date+" "+to_time);
	$("#Modal_for_all").modal("hide");
	//"bookedselecttime"
}

var global_orderid = "";
function assignlogisticsvendor(phorder_id){ 
	console.log(activeLineitem);
	var actionById=sessionStorage.getItem('pharmacist_user_id');
	var actionByName=sessionStorage.getItem('pharmacist_user_name');
	var vendor_val=$('#logisticsvendor').val();
	var vendor_date = "";
	var vendor_time="";
	var vendor_date = "2019-08-07";
	var vendor_time="14:10:10";
	var vendor_starttime = "";
	var vendor_endtime = "";
	var slot_transactionid="";
	
	if(vendor_val==''){
		alert("Please select a Logistics Vendor.");
		return false;
	}	
	if(vendor_val=="Aramex"){
	    //vendor_date=$('#vendordate').val();
		//vendor_time=$('#vendortime').val();
	}else{
		//vendor_date=$("#bookedselecttime").attr("data_date");
		vendor_starttime=$("#bookedselecttime").attr("data_starttime");
		vendor_endtime=$("#bookedselecttime").attr("data_endtime");
		slot_transactionid=$("#bookedselecttime").attr("data_trasactionid");
		//vendor_time = vendor_endtime;
	}	
	/*if($.trim(vendor_date)=="" || $.trim(vendor_time)==""){
		alert("Please select the time slot");
		return false;
	}else if($.trim(slot_transactionid)=="" && vendor_val!="delhivery_express"){
		alert("Please select a Time Slot.");
		return false;
	}*/
    global_orderid = phorder_id;
	global_pharmaorderid = phorder_id;
	var _data = {order_id:phorder_id,
        actionById:actionById,
        actionByName:actionByName,
        source:"CCO",
        latitude:21.34539,
        longitude:78.456456,
        status:902,
        //status:0,
        scheduled_date:vendor_date,
        start_time:vendor_starttime,
        end_time:vendor_endtime,
        chiss_transaction_id:slot_transactionid,
        role_id:9
    }; 
   // console.log(_data);return;
   
	_ajaxEventHandler("order/change/status",_data,res_changeorderstatsus,SHOW_LOADER,"POST","operation.php/v1/");	
}

function res_changeorderstatsus(response){
    $(".loader").hide();
	console.log(response);
	var Obj = response;
	if(Obj.status=="1"){
		alert(Obj.message);
		if($("#logisticsvendor").val()=="delhivery_express"){
			var _data = {"order_id":global_orderid,"assignedto":"delhivery_express"};
			//alert(pincodevalue);
			_ajaxEventHandler("createOrder", _data, cbk_delhivery_createOrder, SHOW_LOADER, "POST", External_delivery);
		}else if($("#logisticsvendor").val()=="callhealth"){
			var _data = { "order_ids": [global_orderid] };
			_ajaxEventHandler("ordercreation_chiss",_data,res_ordercreation_chiss,SHOW_LOADER,"POST","operation.php/v1/");
			$("#Modal_for_all").modal("hide");
		} 
	}else{
		alert(Obj.message);
		vieworder(global_pharmaorderid);
	}
}

function res_ordercreation_chiss(response){
    $(".loader").hide();
	var Obj = response;
    console.log(Obj);
	if(Obj.status=="1"){
		if(Obj.present_status[0]=="1"){
			alert("Order has been assigned to a Drug Delivery Officer.");
		}
	}
	vieworder(global_pharmaorderid);
	//allOrders('tobeconfirmed','allordersview',false,1,true);
	/*
	$.each(Obj, function (key, val) {
		if(val.status==1){
			alert(val.message);	
			$("#Modal_for_all").modal("hide");
			allOrders('tobeconfirmed','allordersview',false,1,true);
		}else{
			//alert(val.message);
		}
	});*/
}

function cbk_delhivery_createOrder(response){
    $(".loader").hide();
	console.log(response);
	var Obj = response;
    console.log(Obj);
	if(Obj.status==1){
		//if(Obj.data.packages=="1"){
			alert("Order has been assigned for Delivery. ");
		//}
	}
	vieworder(global_pharmaorderid);
}

//viewbatchdetails
var phitem_code = "";
function viewbatchdetails(phorder_id,item_code,itemname,quantity,disamount){
    var header_data = "";
    var body_data = "";
    var footer_data = "";
    phitem_code = item_code;
    itemname = itemname.replace(/[^a-zA-Z ]/g, "");
    header_data +='<h3 class="modal-title" style="width:300px;" id="myModalLabel">View Batch Details</h3>' ;
    body_data +='<h5>Quantity: <span id=qty1>'+quantity+'</span></h5>'+
	'<h6>Product Name:<span id=itemname1>'+itemname+'</span></h6>'+
	'<input type="hidden" id="bquantity" name="bquantity">'+
	'<input type="hidden" value=' + phorder_id + ' id="vendor_batch_omorder_id" name="vendor_batch_omorder_id">'+
	'<input type="hidden" value=' + item_code + ' id="batch_item_code" name="batch_item_code">'+
	'<input type="hidden" value=' + disamount + ' id="batch_disamount" name="batch_disamount">'+
	'<input type="hidden" id="batch_rowcount" name="batch_rowcount">'+
	'<table class="table table-striped" id="vendorupdatebatchprice">'+
	'</table>';
	    
    footer_data+='<button type="button" class="btn btn-primary" onclick="vendorbatchupdateprice()">Update</button>';
    
    $("#modal_header").html(header_data);
    $("#modal_body").html(body_data);
    $("#modalfooter").html(footer_data);
    $("#Modal_for_all").modal("show");
    
    var _data = {omorder_id:phorder_id,item_code:item_code};
    _ajaxEventHandler("getitemdetails",_data,res_batchmodel,SHOW_LOADER); 
    $("#vendorupdatebatchprice").html('');
}

function res_batchmodel(response){
	$(".loader").hide();
	ordersdetails=JSON.parse(response);
	$.each(ordersdetails.order.orderitem,function(key,val){
		if(val.item_code==phitem_code){
			$('#itemname1').text(val.itemname);
			$('#bquantity').val(val.quantity);
			$('#qty1').html(val.quantity);
			var html="";
			var cnt=0;
			$.each(val.batch,function(key1,val1){
				cnt=cnt+1;
				var expiry =  (typeof val1.expirydate !="undefined")?val1.expirydate:"";
				html='<tr>'+
				'<td><input type="Number" class="form-control controlInput" onkeypress="return event.charCode >= 48 && event.charCode <= 57" id="bchangequantity'+key1+'" name="bchangequantity'+key1+'" value="'+val1.quantity+'"></td>'+
				'<td><input type="Number" onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" class="form-control controlInput" id="bprice'+key1+'" min="1" name="bprice1"  value="'+val1.mrp+'"></td>'+
				'<td><input type="text" class="form-control controlInput" id="bbatch'+key1+'" name="bbatchname'+key1+'" maxlength="20"  value="'+val1.batch+'"></td>'+
				'<td><input type="text" class="form-control controlInput" id="expiry_month'+key1+'" name="expiry_month'+key1+'" maxlength="20"  value="'+expiry+'"></td>'+
				'<td><input type="hidden" class="form-control controlInput" id="cbatchno'+key1+'" name="cbatchno'+key1+'" maxlength="20"  value="'+val1.batchno+'"></td>'+
				'</tr>';
				$("#vendorupdatebatchprice").append(html);
			//expiry_month
			});
			$("#batch_rowcount").val(cnt);
		}
	});	
}


function open_slot_modal(){
    var header_data = "";
    var body_data = "";
    var itemcode="";
	$("input[name=item_reject]").each(function (){			
		itemcode = $(this).val;
		return false; 
		//break;
	});
	if($.trim(itemcode)==""){
		alert("Please enter test name");	
		return false; 
	}
	if($.trim($("#selecttimeslot").attr("data-pincode"))==""){
		alert("Please provide a valid Pincode.");
		return false; 
	}
    //var tommorowDate = $("#selecttimeslot").attr("data-scheduled_date").split(" ");     
    //var tommorowDate = $("#selecttimeslot").attr("data-scheduled_date").split(" ");     
    header_data +=  '<h4 class="modal-title" id="myModalLabel">Choose the slot</h4><span id="walletbal"></span>';	 
    body_data +='<div>'+
	"<div class='input-group date datepicker' id='orderdatediv'>"+
	"<input id='mainorderdate' type='text' onchange='fetch_slot();' class='form-control' value='"+todayDate()+"' readonly=''>"+				
	"<span class='input-group-addon'>"+
	"<i class='fa fa-calendar' aria-hidden='true'></i>"+
	"</span>"+
	"</div>"+
	"</div>"+
	'<div id="londing_view">'+
	'<div class="loader" style="display:block"></div>'+
	'</div>'+
	'<div id="slotdiv"></div>';          
    	
    $("#myModalLabel").html(header_data);
    $("#trackresult").html(body_data);
    $("#Modal_for_all").modal("show");
    //$("#mainorderdate").val();
    fetch_slot(itemcode,todayDate());	
}

function fetch_slot(itemcode,defaultDateSlot=""){
	if(itemcode==""){
		$("input[name=item_reject]").each(function (){			
			itemcode = $(this).val;
			return false; 
			//break;
		});
		if($.trim(itemcode)==""){
			alert("Please enter test name");	
			return false; 
		}
	}
	if(defaultDateSlot==""){
		defaultDateSlot = $("#mainorderdate").val();
	}
	var _data = {
		from_date:defaultDateSlot, 
		to_date:defaultDateSlot,
		business_id:"2",
		sub_business_id:"9",
		service_did:itemcode,
		pop_id:$("#selecttimeslot").attr("data-popid"),
		patient_mrn:$("#selecttimeslot").attr("data-mrn"),
		patient_age:$("#selecttimeslot").attr("data-age"),
		patient_gender:"",
		preferred_officer:"",
                normal_slots:"Y",
		pin_code:$("#selecttimeslot").attr("data-pincode"),
		order_latitude:$("#selecttimeslot").attr("data-latitude"),
		order_longitude:$("#selecttimeslot").attr("data-longitude")
	}
	console.log(_data);
	_ajaxEventHandler('fetch_slots', _data, response_fetch_slot, SHOW_LOADER,"POST","operation.php/v1/");
}

function response_fetch_slot(response){
	console.log(response);
	$(".loader").hide();
	var senddate = $("#mainorderdate").val();
        var htmlstring="";
		if(response.success==="1"){
		$.each(response.data[senddate], function (key, val) {
			if(val.is_booked!=1){
				var from_time=senddate+" "+val.from_time;
				var to_time=senddate+" "+val.to_time;
				htmlstring+="<button class='btn btn-success' style='margin:5px;' onclick='booktheslot(\""+val.transaction_id+"\",\""+senddate+"\",\""+val.from_time+"\",\""+val.to_time+"\")'>"+datetime24to12(from_time)+" - "+datetime24to12(to_time)+"</button>";
			}		   
		});
		if(htmlstring==""){
			htmlstring="<br><label>Slots are unavailable.</label>";
		}
		$("#slotdiv").html(htmlstring);
	}else{
		console.log(response.message);
		alert(response.message);
	}
}

function memodownload(orderid){
	var _data = {omorder_id:orderid};
	window.location=RestServiceURL+'operation.php/v1/invoice?OrderID='+orderid;
}

function shipmentlable(orderid){
	var _data = {omorder_id:orderid};
	//console.log(_data); return false;
	//window.location=RestServiceURL+'OrderCashMemo?orderid='+orderid;
        window.location=RestServiceURL+'operation.php/v1/shipment_lable?OrderID='+orderid;
	
}

function l2prescptionupload() {
    var formData = new FormData($("#formsum")[0]);
    formData.append('order_id',$('#pre_orderid').val());
    formData.append('mrn', $('#pre_mrn').val());
    $.ajax({
        url: RestServiceURL + 'medicine_supply.php/v1/prescription_upload_link',
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        type: 'POST',
        success: function (data) {
			//console.log(data);
            var result = '';
            if (typeof data == 'string') {
                result = JSON.parse(data);
            } else {
                result = data;
            }
            if (result.status == 1) {
                alert('Prescription uploaded.');
                /*$('.hideAllDetails').hide();
                $('.removeActive').removeClass('active');
                $('.veiwOrderDetails').addClass("active");
                $('#veiwOrderDetails').addClass('active in');
				$("#viewOrder").modal("hide");*/
				$("#Modal_for_all").modal("hide");
				vieworder($('#pre_orderid').val());
            }
            else{
                alert("Something went wrong. Please try again!")
            }
        }
    });
}

function l2invoiceupload() {
    var formData = new FormData($("#formsum")[0]);
    formData.append('order_id',$('#pre_orderid').val());
  //  formData.append('mrn', $('#pre_mrn').val());
    formData.append('file_mode', 'INVOICE');
   
    $(".loader").show();	
    $.ajax({
        url: RestServiceURL + 'medicine_supply.php/v1/orders/invoice/upload/blob',
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        type: 'POST',
        success: function (data) {
		//console.log(data);
            var result = '';
            if (typeof data == 'string') {
                result = JSON.parse(data);
            } else {
                result = data;
            }
            console.log(result);
            if (result.status == 1 || result.status == "1") {
                alert('Invoice uploaded.');
		$("#Modal_for_all").modal("hide");
		vieworder($('#pre_orderid').val());
            }
            else{
                alert("Something went wrong. Please try again!")
            }
        }
    });
}

function allreject(){
	if($("input[name='allitem_reject']").prop("checked") == true){
		$.each($("input[name='item_reject']"),function(){
			//alert("checked");
			$(this).prop("checked",true);
		});
	}else{
		$.each($("input[name='item_reject']"),function(){
			//alert("unchecked");
			$(this).prop("checked",false);
		});
	}
}

function itemcheck_selected(thisdata){
	if($(thisdata).prop("checked") == false){
		$("input[name='allitem_reject']").prop("checked",false); 
	}
}

function exportcsv() {
	var pharmacistID= sessionStorage.getItem('pharmacist_user_id');
	window.location = RestServiceURL + "medicine_supply.php/v1/orderexportcsv?&vendorID="+pharmacistID;
}

var scheduledd_date="";
var OStatus="";

function orderstatusChange(eqorderid,scheduled_date,payable_amount,status){
   var vendor_collected_amount = $("#vendor_collected_amount").val();
   // alert(vendor_collected_amount);
   //alert(payable_amount);
   if(vendor_collected_amount == "" ){ 
        alert("please enter collected amount");
        return;       
  }
  if(vendor_collected_amount > payable_amount){ 
        alert("collected amount should not be greaterthan payable amount");
        return;       
  }
   
   if($("#amt_chkbox").prop('checked') == false ){ 
        alert("please click on amount collected box before updating the order status");
        return;       
  }
   if(status == 5){
       _ajaxEventHandler("generateBill",{OrderID:eqorderid},commonres_forvendormethods,SHOW_LOADER,"POST","operation.php/v1/");
  }
 
    global_eqorderid = eqorderid;
    scheduledd_date = scheduled_date;
    OStatus = status;
    var scdate = scheduled_date.split("T"); 
    var endtime = scdate[1].split(".");
    var starttime = endtime[0].split(":");
    if(starttime[0]=="14"){
        starttime[0] = "10:00:00";
    }else if(starttime[0]=="18"){
        starttime[0] = "14:00:00";
    }else if(starttime[0]=="22"){
        starttime[0] = "18:00:00";
    }
    var _data = {
            order_id:eqorderid,
            actionById:sessionStorage.getItem("pharmacist_user_id"),
            actionByName:sessionStorage.getItem("pharmacist_user_name"),
            source:"CCO",
            latitude:21.34539,//presently static
            longitude:78.456456,//presently static
            status:status,
            scheduled_date:scdate[0],
            start_time:starttime[0],
            end_time:endtime[0],
            chiss_transaction_id:456434564576,
            role_id:1
        };
	
    console.log(_data);
   _ajaxEventHandler("order/change/status",_data,res_orderstatusChange,SHOW_LOADER,"POST","operation.php/v1/");	
}

//response of change orderstatus
function res_orderstatusChange(response){
    $(".loader").hide();
    console.log(OStatus);
    if(response.status=="1" || response.status==1){
        if(response.OStatus === 15){
            alert("Order Canclled Successfully");
            $(".close").click();
            $(".order_status_change1").html('') ;
       }else if(OStatus === 3){
            $(".order_status_change").html('<a href="#" class="print_invoice_btn" name = "inprogress" onclick="orderstatusChange(\''+global_eqorderid+'\',\''+scheduledd_date+'\',5)">Delivered</a>');
            $(".cancel_order").html('<a href="#" class="print_invoice_btn" name = "started" onclick="cancelorder_Popup(\'' + global_eqorderid + '\',\''+scheduledd_date+'\',15)">Cancel</a>'); 
       }else if(OStatus === 5){
           $(".order_status_change").html('<a href="#" class="print_invoice_btn" name = "completed" onclick="orderstatusChange(\''+global_eqorderid+'\',\''+scheduledd_date+'\',6)">Complete</a>' +
                                          '<div style="position: absolute; left: -98px; bottom: -85px;">'+
                                          '<input type="text" name="collected_amount" class="form-control" id="vendor_collected_amount" value="" placeholder="Enter collected amount...">'+
                                          '<input type="checkbox" name="" value="1" id = "amt_chkbox" >Amount Collected' +
                                          '</div>');
           $(".cancel_order").html('<a href="#" class="print_invoice_btn" name = "started" onclick="cancelorder_Popup(\'' + global_eqorderid + '\',\''+scheduledd_date+'\',15)">Cancel</a>');                                 
       }else if(OStatus === 6){
           $(".order_status_change").html('') ;
           $(".cancel_order").html('') ;
       }
        alert(response.message);
    }else{
       alert("Failed to update the order status");
    }
}

function orderCancel(eqorderid,scheduled_date,status){
     var scdate = scheduled_date.split("T"); 
     var reason_text = $("#cancel_reason").val();
     if(status == 15 && reason_text === "" ){ 
         alert("please enter the reason and click on yes");
         return false;  
     }
     global_eqorderid = eqorderid;
     var _data = {
            order_id:[parseInt(eqorderid)],
            actionById:sessionStorage.getItem("pharmacist_user_id"),
            actionByName:sessionStorage.getItem("pharmacist_user_name"),
            source:1,
            role:"CCO",
            scheduled_date:scdate[0],
            reasonType:1,
            reason:"cancel",
            reason_text:reason_text,
            comment:"cancel"
     };
	
    console.log(_data);
    _ajaxEventHandler("orderCancel",_data,res_orderCancel,SHOW_LOADER,"POST","operation.php/v1/");	
}
function res_orderCancel(resposne){
    $(".loader").hide();
    console.log(resposne); 
    if (resposne.status == "1" || resposne.status == 1) {
        alert(resposne.msg[0].msg);
        $("#Modal_for_all").modal("hide");
        vieworder(global_eqorderid);
    } else {
        alert(resposne.msg);
    }
}