function allordersview(ordersdetails) {
    // console.log(sessionStorage.getItem('loginid'));
    //var total_orders=20 ;//ordersdetails.length;
    //alert();
    $(".loader").show();
    ordersdetails = JSON.parse(ordersdetails);
    console.log(ordersdetails);
    //$('#rxuploadedcount').html(ordersdetails.countn);
    //console.log(ordersdetails.countn);
    htmlBanner = '<section class="container-fluid">' +
            '<article class="main_content">' +
            '<div class="tab-content custom_tab_content">' +
            '<div role="tabpanel" class="tab-pane fade in active" id="mainreplacecontent">' +
            '<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
            '<div class="table-responsive">' +
            '<table id="example"  cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">' +
            '<thead>' +
            '<tr>' +
            '<th>MRN</th>' +
            '<th>Customer Name</th>' +
            '<th>' + 'Order No.' + '</th>' +
            '<th>' + 'Order DID.' + '</th>' +
            '<th>Location</th>' +
            '<th>Order Created Date </th>' +
            '<th>Preferred Date/Time </th>' +
            '<th>Scheduled Date/Time </th>' +
            '<th>Vendor Assign Date</th>' +
            '<th>Vendor Name</th>' +
            '<th>Order Status</th>' +
            '<th>Order Details</th>' +
            '<th>Order Track</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';
    $countn = 0;
    $.each(ordersdetails.data, function (key, val) {
        //console.log(val._id);
        var patientname = val.order.patientinfo.name;
        patientname = patientname.replace("null", "");
        htmlBanner += '<tr>' +
                '<td>' + val.order.patientinfo.mrn + '</td>' +
                '<td>' + patientname + '</td>' +
                '<td>' + val._id + '</td>' +
                '<td>' + val.odid + '</td>' +
                '<td>' + val.order.patientinfo.city + '</td>' +
                '<td>' + (val.order.order_status.created_date) + '</td>' +
                '<td>' + changedate(val.order.patientinfo.expected_delivery_date) + '</td>';
        var myarray_ststus = [1000, 1001, 21, 24, 17];
        if (jQuery.inArray(val.OStatus, myarray_ststus) == -1) {
            htmlBanner += '<td>' + changedate(val.order.patientinfo.scheduled_date) + '</td>';
        } else {
            htmlBanner += '<td>-</td>';
        }
        htmlBanner += '<td>' + ((typeof (val.order.provider_info) == "undefined") ? "" : ((typeof val.order.provider_info[0].vendor_assigned_date == "undefined") ? "" : val.order.provider_info[0].vendor_assigned_date)) + '</td>' +
                '<td>' + ((typeof (val.order.provider_info) == "undefined") ? "" : ((typeof val.order.provider_info[0].associate_name == "undefined") ? "" : val.order.provider_info[0].associate_name)) + '</td>' +
                '<td>' + ((typeof (val.statusName[0]) != "undefined") ? val.statusName[0].Nomenclature : "NA") + '</td>' +
                '<td> <a onclick="vieworder(' + val._id + ')" target="_new" class="view">View</a> </td>' +
                '<td><a href="#" onclick="trackOrder(' + val._id + ')" class="track_btn">Deliver Track</a></td>' +
                '</tr>'; //href=order_view.php?id='+ val._id.value+' 
        $countn = $countn + 1;
    });
    if ($countn == 0) {
        htmlBanner += '<tr><td colspan="12">Data not found.</td></tr>'
    }
    htmlBanner += '</tbody>' +
            '</table>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</article>' +
            '</section>' +
            '</div>';

    setTimeout(function () {
        $("#vendor_assigned_count").html(ordersdetails.tobeconfirmed);
        $("#requested_pickup_count").html(ordersdetails.requested_pickup);
        $("#rejectedcount").html(ordersdetails.rejected);
        $("#completed_count").html(ordersdetails.completed);
        $("#allorder_count").html(ordersdetails.all_orders);
		$(".loader").hide();
    }, 1000);

    
    return htmlBanner;
}



function trackOrderView(result) {
    var modalfooter = '<button type="button" class="btn btn-default sa-success" data-dismiss="modal" style="color:#fff;">Close</button>';
    var myModalLabel = "Order Tracking Status";
    var trackresult = "";
    if (result.status == 1) {
        var tdata = '';
        if (result.data.order_log.length <= 0) {
            tdata = '<h4>No Data</h4>';
            $('#trackresult').html(tdata);
            $('#track').modal('show');
        } else {
            tdata = "<table class='table table-responsive'><thead><tr>" +
                    "<th>Order</th>" +
                    "<th>User Name</th>" +
                    "<th>User ID</th>" +
                    "<th>Role</th>" +
                    "<th>Action</th>" +
                    "<th>Order Status</th>" +
                    "<th>Updated On</th>" +
                    "<th>Text</th>" +
                    "</tr></thead><tbody>";
            $.each(result.data.order_log, function (key, val) {
                tdata += '<tr><td>' + val.wodid + '</td>' +
                        '<td>' + val.actionByName + '</td>' +
                        '<td>' + val.actionById + '</td>' +
                        '<td>' + val.role + '</td>' +
                        '<td>' + val.action + '</td>' +
                        '<td>' + ((typeof val.status_name != "undefined") ? val.status_name : "") + '</td>' +
                        '<td>' + val.created_date + '</td>' +
                        '<td>' + val.reason + '</td></tr>';
            });
            tdata += '</tbody></table>';
            trackresult = tdata;
        }
    } else {
        trackresult = result.message;
    }
    //console.log(trackresult);
    $(".loader").hide();
    $("#myModalLabel").html(myModalLabel);
    $("#trackresult").html(trackresult);
    $("#modalfooter").html(modalfooter);
    $("#Modal_for_all").modal('show');
}

var global_ordersdetails = null;
function showorderview(resposne) {
    var allowed_statusfor_showamount = [902, 0, 18, 1, 2, 3, 4, 5, 6, 106];
    var show_statuses_the_start_btn = [0, 1, 2];
    //console.log(resposne.data);return;
    sessionStorage.setItem("prescription_images", "");
    if (resposne.status == 1) {
        if (typeof resposne.data._id != "undefined") {
            ordersdetails = resposne.data;
            global_ordersdetails = ordersdetails;
            var paymentInfo = ordersdetails.payment_info;
             var payable_amount = (typeof ordersdetails.payment_info != "undefined") ? ordersdetails.payment_info.payable_amount : 0;
            htmlBanner ='<br><section class="container-fluid">' +
			'<article class="p_details">' +
			'<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
			'<section class="complete_order_search">' +
			'<div class="col-xs-12 mp" style="border-bottom:1px solid #7DB0AC; margin-top:-10px; padding:5px;">' +
			'<h5 style="text-decoration:none; font-size:18px;">' +
			'Order ID # <span style="color:#aaaaaa;">' + ((typeof ordersdetails._id != "undefined") ? ordersdetails._id : "") +
			'</span>, Order DID # <span style="color:#aaaaaa;">' + ((typeof ordersdetails.odid != "undefined") ? ordersdetails.odid : "") +
			'</span>, MRN - <span style="color:#aaaaaa;">' + ((typeof ordersdetails.order.patientinfo.mrn != "undefined") ? ordersdetails.order.patientinfo.mrn : "") +
			'</span>, Transaction ID - <span style="color:#aaaaaa;">' + ((typeof ordersdetails.transaction_code != "undefined") ? ordersdetails.transaction_code : "") +
			'</h5>' +
			'</div>' +
			'<article class="col-md-12 col-sm-12 col-xs-12 mobile_mp"><br>' +
			'<div class="col-md-2 col-sm-3 col-xs-12 mp">' +
			'<div class="form-group">' +
			'<label style="margin-bottom:10px;">Customer Name:<br><span style="color:#6D6D6D;">' + ordersdetails.order.patientinfo.name + '</span></label>' +
			'<label style="margin-bottom:10px;">Mobile No:<br><span style="color:#6D6D6D;">' + ordersdetails.order.patientinfo.contact + '</span></label>' +
			'<label style="margin-bottom:10px;">Alternate Mobile No:<br><span style="color:#6D6D6D;">' + (ordersdetails.order.patientinfo.alternetcontactno ? ordersdetails.order.patientinfo.alternetcontactno : "") + '</span></label>' +
			'</div>' +
			'</div>' +
			'<div class="col-md-4 col-sm-3 col-xs-12 mp">' +
			'<label style="margin-bottom:10px;">Delivery Address:<br><span style="color:#6D6D6D;">' + ordersdetails.order.patientinfo.address + '</span></label>' +
			'<label style="margin-bottom:10px;">Pincode:<br><span style="color:#6D6D6D;">' + ordersdetails.order.patientinfo.pincode + '</span></label>' +
			'</div>' +
			'<div class="col-md-3 col-sm-3 col-xs-12 mp">' +
			'<label style="margin-bottom:10px;">Preferred Date/Time:<br><span style="color:#6D6D6D;">' + changedate(ordersdetails.order.patientinfo.expected_delivery_date ? ordersdetails.order.patientinfo.expected_delivery_date : "NaN") + '</span></label>';
            if (ordersdetails.OStatus == 21){				
				if ($.inArray("13",ordersdetails.component_order) != -1){
					
				}else if ($.inArray("8",ordersdetails.component_order) != -1){
					htmlBanner += '<label style="margin-bottom:10px;">Book the Slot :</lable><br>' +
					'<div class="col-md-6 mp">' +
					'<button name="job_name" onclick="open_slot_modal();"  id="selecttimeslot" data-scheduled_date="' + changedate(ordersdetails.order.patientinfo.scheduled_date) + '" data-mrn="' + ordersdetails.order.patientinfo.mrn + '" data-popid="' + ordersdetails.order.patientinfo.facility_id + '" data-age="' + ordersdetails.order.patientinfo.age + '" data-gender="' + ordersdetails.order.patientinfo.gender + '" data-pincode="' + ordersdetails.order.patientinfo.pincode + '" data-latitude="' + ordersdetails.order.patientinfo.delivery_lat + '" data-longitude="' + ordersdetails.order.patientinfo.delivery_lng + '"  class="btn btn-success">Select slot</button>' +
					'<hidden data_starttime="" data_date="" data_trasactionid="" id="bookedselecttime" style="color:#408DAE"></hidden>' +
					'<hidden data_endtime="" data_date="" data_trasactionid="" id="bookedselecttime" style="color:#408DAE"></hidden>' +
					'<label style="color:#408DAE" id="showbookedselecttime"></lable>' +
					'</div>';
				}

                /*var pan_india_pop_id = ["200043", "200044", "200045"];
                if (((typeof ordersdetails.pop_id) != "undefined") ? (((typeof pan_india_pop_id[ordersdetails.pop_id]) != "undefined") ? true : false) : false) {
                    htmlBanner += '<div class="col-md-2 col-sm-1 col-xs-12 mnp">' +
					'<div class="form-group">' +
					'<label>Schedule Date :</label>' +
					'<div class="input-group" >' +
					'<input type="text" id="vendordate" class="form-control datepicker" placeholder="YYYY-MM-DD">' +
					'<span class="datepicker">' +
					'<span class="glyphicon glyphicon-calendar cust_cal"></span>' +
					' </span>' +
					'</div>' +
					'</div>' +
					'</div>' +
					'<div class="col-md-2 col-sm-1 col-xs-12 mnp">' +
					'<div class="form-group">' +
					'<label>Schedule Time Slot :</label>' +
					'<select id="vendortime" name="job_name" class="form-control new-status">' +
					'<option value="">--Select--</option>' +
					'<option value="10:00">06:00 AM-10:00 AM</option>' +
					'<option value="14:00">10:00 AM-02:00 pm</option>' +
					'<option value="18:00">02:00 PM-06:00 pm</option>' +
					'<option value="22:00">06:00 PM-10:00 pm</option>' +
					'</select>' +
					'</div>' +
					'</div>';
                } else {
                    htmlBanner += '<label style="margin-bottom:10px;">Book the Slot :</lable><br>' +
					'<div class="col-md-6 mp">' +
					'<button name="job_name" onclick="open_slot_modal();"  id="selecttimeslot" data-scheduled_date="' + changedate(ordersdetails.order.patientinfo.scheduled_date) + '" data-mrn="' + ordersdetails.order.patientinfo.mrn + '" data-popid="' + ordersdetails.order.patientinfo.facility_id + '" data-age="' + ordersdetails.order.patientinfo.age + '" data-gender="' + ordersdetails.order.patientinfo.gender + '" data-pincode="' + ordersdetails.order.patientinfo.pincode + '" data-latitude="' + ordersdetails.order.patientinfo.delivery_lat + '" data-longitude="' + ordersdetails.order.patientinfo.delivery_lng + '"  class="btn btn-success">Select slot</button>' +
					'<hidden data_starttime="" data_date="" data_trasactionid="" id="bookedselecttime" style="color:#408DAE"></hidden>' +
					'<hidden data_endtime="" data_date="" data_trasactionid="" id="bookedselecttime" style="color:#408DAE"></hidden>' +
					'<label style="color:#408DAE" id="showbookedselecttime"></lable>' +
					'</div>';
                }*/
            } else {
                htmlBanner +='<label style="margin-bottom:10px;">Scheduled Date/Time:</lable><br>' +
				'<div class="col-md-6 mp">';
				if (ordersdetails.OStatus != 21 && ordersdetails.OStatus != 24) {
					htmlBanner +=((typeof ordersdetails.order.patientinfo.scheduled_date != "undefined") ? changedate(ordersdetails.order.patientinfo.scheduled_date) : "");
				}else{
					htmlBanner +='NA';
				}
				htmlBanner +='</div>';
            }
            htmlBanner += '</div>';
            
            
            if (jQuery.inArray(ordersdetails.OStatus, show_statuses_the_start_btn) >= 0) {
                htmlBanner += '<div class="col-md-3 col-sm-12 col-xs-12 order_status_change text-left">' +
                        '<a href="#" class="print_invoice_btn" name = "started" onclick="orderstatusChange(\'' + ordersdetails._id + '\',\'' + ordersdetails.order.patientinfo.scheduled_date + '\',\'' + payable_amount + '\',3)">Start</a>' +
                        '</div>';
            } else if (ordersdetails.OStatus == 3) {
                htmlBanner += '<div class="col-md-3 col-sm-12 col-xs-12 order_status_change text-left">' +
                        '<a href="#" class="print_invoice_btn" name = "inprogress" onclick="orderstatusChange(\'' + ordersdetails._id + '\',\'' + ordersdetails.order.patientinfo.scheduled_date + '\',\'' + payable_amount + '\',5)">Delivered</a>' +
                        '</div>';
            } else if (ordersdetails.OStatus == 5) {
                htmlBanner += '<div class="col-md-3 col-sm-12 col-xs-12 order_status_change text-left">' +
                        '<a href="#" class="print_invoice_btn" name = "completed" onclick="orderstatusChange(\'' + ordersdetails._id + '\',\'' + ordersdetails.order.patientinfo.scheduled_date + '\',\'' + payable_amount + '\',6)">Complete</a>' +
                        '<div style="position: absolute; left: -98px; bottom: -85px;">'+
                        '<input type="text" name="collected_amount" class="form-control" id="vendor_collected_amount" value="" placeholder="Enter collected amount...">'+
                        '<input type="checkbox" name="" value="1" id = "amt_chkbox" >Amount Collected' +
                        '</div>'+
                        '</div>';
            }else if (ordersdetails.OStatus == 21) {
                htmlBanner += '<div class="col-md-3 col-sm-12 col-xs-12 cancel_order text-left">' +
				'<label>Logistics Vendor :</label>' +
				'<select name="vendor" id="logisticsvendor" class="form-control new-status">' +
				'<!--option value="" disabled>Select Logistics Vendor</option-->';
				if ($.inArray("13",ordersdetails.component_order) != -1){
					htmlBanner += '<option value="delhivery_express">Delhivery Express</option>';
				}else if ($.inArray("8",ordersdetails.component_order) != -1){
					htmlBanner += '<option value="callhealth">Callhealthpickup</option>';
				}
				
                /*if (((typeof ordersdetails.pop_id) != "undefined") ? (((typeof pan_india_pop_id[ordersdetails.pop_id]) != "undefined") ? true : false) : false) {
                    htmlBanner += '<option value="Aramex">Aramex</option>';
                } else {
                    htmlBanner += '<option value="callhealth">Callhealthpickup</option> ' +
                            '<option value="getbike">GetBike</option>' +
                            '<!--<option value="Vdeliver">Vdeliver</option> -->';
                }*/
                htmlBanner += '</select></div>';
            }
            ///////// end the box code  ///////////

            htmlBanner += '</article>' +
			'</section>' +
			'<br>' +
			//table statting
			'<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
			'<div class="table-responsive">' +
			'<table class="table table-condensed table-bordered table-striped medicine_home_order_table" id="toggleColumn-datatable">' +
			'<thead>' +
			'<tr>' +
			'<th>Select All <input type="checkbox" name="allitem_reject" value="1" onclick="allreject()"></th>' +
			'<th>Item Name</th>' +
			'<!--th>Pharmaceutical Name</th-->' +
			'<th>Brand Name</th>' +
			'<th>Type</th>' +
			'<th>Doctor Name</th>' +
			'<th>Order Qty</th>' +
			'<th>MRP</th>' +
			'<th>Gross Amount</th>' +
			'<th>Net Amount</th>' +
			'<th>Discount</th>' +
			'<th>Actions</th>' +
			'<th>Comments</th>' +
			'<th>Log Info</th>' +
			'<th>Add Log</th>' +
			'</tr>' +
			'</thead>' +
			'<tbody>';
            console.log(ordersdetails.order.payment_info);
            var Tgross_amount = (typeof ordersdetails.payment_info.gross_amount != 'undefined') ? parseFloat(ordersdetails.payment_info.gross_amount) : 0;
            var Delivery_amount = 0;
            var Tnet_amount = (typeof ordersdetails.payment_info.net_amount != 'undefined') ? parseFloat(ordersdetails.payment_info.net_amount) : 0;
            var Tdiscount_amount = (typeof ordersdetails.payment_info.discount_amount != 'undefined') ? parseFloat(ordersdetails.payment_info.discount_amount) : 0;
            var prepaidamt = (typeof ordersdetails.payment_info.paid_amount != 'undefined') ? parseFloat(ordersdetails.payment_info.paid_amount) : 0;
            var wallet_amount = (typeof ordersdetails.payment_info.wallet_amount == "undefined" ? "0" : ordersdetails.payment_info.wallet_amount);
            var due_amount = (typeof ordersdetails.payment_info.payable_amount != 'undefined') ? parseFloat(ordersdetails.payment_info.payable_amount) : 0;
			var voucher_amount = (typeof ordersdetails.payment_info.voucher_amount != 'undefined') ? parseFloat(ordersdetails.payment_info.voucher_amount) : 0;
            

            $.each(ordersdetails.order.orderitem, function (key, val) {
                if (val.roleBasedService == 1) {
                    Delivery_amount = parseFloat(val.net_amount);
                    return true;
                }
                //voucher_amount = voucher_amount + (val.voucher_amount ? val.voucher_amount : 0);
                //Tgross_amount = parseFloat(Tgross_amount) + parseFloat(val.gross_amount);
                //Tnet_amount =   parseFloat(Tnet_amount) + parseFloat(val.net_amount);
                // add all the discount here 
                //Tdiscount_amount = parseFloat(Tdiscount_amount) + parseFloat(val.discount_amount);
                Tcoupon_amount = parseFloat(Tdiscount_amount) + parseFloat(val.discount_amount);
                if (val.item_status == "8") {
                    //htmlBanner += '<tr style="background:#FFB4B7;">';
                } else {
                    htmlBanner += '<tr style="">' +
                            '<td><input type="checkbox" name="item_reject" onclick="itemcheck_selected(this)" value="' + val.item_code + '"></td>' +
                            '<td>' + (val.itemname ? val.itemname : "") + '</td>' +
                            '<td>' + (val.manufacturer ? val.manufacturer : "") + '</td>';
                    if (val.prescribed == "1") {
                        htmlBanner += '<td><label name="l2vsetrxotg" id="l2vsetrxotg" data-rxset="true" style="display:block;"><span class="rx">Rx</span></label></td>';
                    } else {
                        htmlBanner += '<td></td>';
                    }
                    htmlBanner +=
                            '<td>' + ((typeof val.doctor!="undefined")?val.doctor:((typeof val.doctorname!="undefined")?val.doctorname:"NA")) + ' </td>' +
                            '<td class="oneliner">' + (val.quantity ? val.quantity : "1") + ' </td>' +
                            '<td>' + val.item_mrp + '</td>' +
                            '<td>' + val.gross_amount + '</td>' +
                            '<td>' + val.net_amount + '</td>' +
                            '<td>' + val.discount_amount + '</td>';
                    //edit and view details tab td
                    if (ordersdetails.OStatus == 21) {
                        //if (typeof (val.batch) == "undefined") {
                        var batchid = ((typeof val.batch != "undefined") && (typeof val.batch.batch != "undefined")) ? JSON.stringify(val.batch.batch) : "";
                        var expiry = ((typeof val.batch != "undefined") && (typeof val.batch.expirydate != "undefined")) ? val.batch.expirydate : "";
                        var batch = (typeof val.batch != "undefined") ? val.batch : "";
						var buttonname="Re-Edit";
                        if (batch == "") {
							buttonname="Edit";
                            batch = [{'quantity': val.quantity, 'mrp': val.item_mrp, 'batch': '', 'expirydate': ''}];
                        }


                        //htmlBanner+='<td><button type="button" onclick=updateprice_popup('+ordersdetails._id+',"'+val.item_code+'","'+escape(val.itemname)+'",'+val.quantity+','+val.item_mrp+','+val.prescribed+',"'+batchid+'","'+expiry+'",'+batch+') class="btn btn-primary" >Edit</button></td>';
						
                        htmlBanner += "<td><button type='button' onclick=updateprice_popup(" + ordersdetails._id + ",'" + val.item_code + "','" + escape(val.itemname) + "'," + val.quantity + "," + val.prescribed + "," + JSON.stringify(batch) + ") class='btn btn-primary' >"+buttonname+"</button></td>";
                        /*}else{
                         htmlBanner+='<td><button type="button" onclick=viewbatchdetails('+ordersdetails._id+',"'+val.item_code+'","'+escape(val.itemname)+'",'+val.quantity+','+val.discount_amount+') class='btn btn-primary' >view Details</button></td>";  
                         }*/
                    } else { //if (val.item_status != 9) {
                        if (typeof (val.batch) == "undefined") {
                            htmlBanner += ' <td>N/A</td>';
                        } else {
                            htmlBanner += ' <td><div class="dropdown"><button class="dropbtn">Batch details</button><div class="dropdown-content"><table  class="table table-bordered table-condensed table-striped table-responsive"><thead><tr><th>Quantity</th><th>Amount</th><th>batch Name</th><th>Expiry</th></tr></thead><tbody>';
                            $.each(val.batch, function (bkey, bval) {
                                htmlBanner += '<tr><td>' + bval.quantity + '</td><td>' + bval.mrp + '</td><td>' + bval.batch + '</td><td>' + bval.expirydate + '</td></tr>';
                            });
                            htmlBanner += '</tbody></table></div></div></td>';
                        }
                    }/* else {
                     htmlBanner +='<td>N/A</td>' +
                     '<td>N/A</td>';
                     }*/
                    //comments td
					
					
                    if (val.item_status == 9) {
						htmlBanner += '<td>NA</td>';
                        htmlBanner += '<td><a href="#" data-toggle="tooltip" title="' + val.item_reject_reason + '">Reason</a></td>';
                    } else {
                        htmlBanner += '<td>N/A</td>';
                    }

                    //showing log information if log is added
                    //if (val.item_status != 9) { 
                        var logtable =
                                '<td>' +
                                '<div class="dropdown">' +
                                '<button class="dropbtn"> <i class="fa fa-info cust_check" aria-hidden="true"></i></button>' +
                                '<div class="dropdown-content" style="right:10%;">' +
                                '<table class="table table-bordered table-condensed table-striped table-responsive">' +
                                '<thead>' +
                                '<tr>' +
                                '<th>Role</th><th>Name</th><th>Log Details</th><th>Date/Time</th></tr></thead><tbody>';
                        var logdata = "";
                        if (typeof ordersdetails.user_log != "undefined") {
                            $.each(ordersdetails.user_log, function (bkey, bval) {
                                if (bval.item_code == val.item_code) {
                                    logdata += '<tr><td>' + bval.role + '</td><td>' + bval.actionbyname + '</td><td>' + bval.log_reason + '</td><td>' + bval.action_date + '</td></tr>';
                                }
                            });
                        }
                        if (logdata == "") {
                            htmlBanner += '<td colspan="">NA</td>';
                        } else {
                            htmlBanner += (logtable + logdata + '</tbody></table></div></div></td>');
                        }
                        //add log td
                        htmlBanner += '<td> <a href="#" class="mpt" onclick="addLog_popup(\'' + ordersdetails._id + '\',\'' + val.item_code + '\')">Add Log</a></td>';
                    /*} else {
                        htmlBanner += '<td>N/A</td><td>N/A</td><!--td>N/A</td-->';
                    }*/
                    '</tr>';
               }
          });
            htmlBanner += '</tbody></table></div>';
            //end of table
			activeLineitem = ordersdetails.order.orderitem;
            //confirm and reject buttons
            if (ordersdetails.OStatus == 21) {
                htmlBanner += '<div class="col-md-1 col-sm-12 col-xs-12 text-right view_prec">' +
                        '<a href="#" class="comp_apply_btn  mpt" onclick="assignlogisticsvendor('+ordersdetails._id+')">Confirm</a>' +
                        '</div>' +
                        '<div class="col-md-1 col-sm-12 col-xs-12 text-right view_prec">' +
                        '<a href="#" class="reject_btn  mpt" onclick="rejectorder_popup(' + ordersdetails._id + ')">Reject</a>' +
                        '</div>'+
                        '<div class="col-md-3 col-sm-12 col-xs-12 text-right view_prec">' +
                       
			'<a href="#" class="reject_btn  mpt"  onclick="call_common_upload_files_modal(1)">Associate Invoice</a>' +
			'</div>';
            }

            //view prescription and upload prescrption buttons
            if (typeof ordersdetails.order.prescription_images != "undefined") {
                sessionStorage.setItem("prescription_images", JSON.stringify(ordersdetails.order.prescription_images));
            }

            //Tnet_amount=Tnet_amount-wallet_amount;
            htmlBanner += '<a href="#" class="view_pres_btn" onclick="viewpresmodal()">View Prescription</a>';
            if (ordersdetails.OStatus == 21) {
                htmlBanner += '<a class="view_pres_btn"  onclick="call_common_upload_files_modal(2)"  style="margin: 0px 7px 0px 5px !important;" > Upload Prescription</a>';
            }

            //displaying total amount  
            if (jQuery.inArray(ordersdetails.OStatus, allowed_statusfor_showamount) >= 0) {
                htmlBanner += '<div class="col-md-2 col-sm-12 col-xs-12 text-right view_prec">' +
                        '<label>Gross Amount &nbsp; : &nbsp; &#8377; ' + paymentInfo.gross_amount + '</label>' +
                        '<label>Discount &nbsp; : &nbsp; &#8377;&nbsp; ' + paymentInfo.discount_amount + '</label>' +
						'<label>Net Amount &nbsp; : &nbsp; &#8377;&nbsp; <span>' + parseFloat(paymentInfo.net_amount) + '</span></label>' +
                        '<label>Wallet Amount &nbsp; : &nbsp; &#8377;' + paymentInfo.wallet_amount + '</label>' +
                        '<label>Shipping Charges &nbsp; : &nbsp; &#8377;' + Delivery_amount + '</label><br>' +
                        '<label>Prepaid Amount &nbsp; : &nbsp; &#8377;&nbsp; <span>' + ((typeof paymentInfo.payment_amount != "undefined") ? paymentInfo.payment_amount : 0) + '</span></label><br>' +						
                        '<label>Voucher Amount &nbsp; : &nbsp; &#8377;&nbsp; <span>' + voucher_amount.toFixed(2) + '</span></label><br>' + 
						'<label>Total Paid Amount &nbsp; : &nbsp; &#8377;&nbsp; <span>' + ((typeof paymentInfo.paid_amount != "undefined") ? paymentInfo.paid_amount : 0) + '</span></label><br>' +						
                        '<label>Due Amount &nbsp; : &nbsp; &#8377;&nbsp; <span>' + parseFloat(paymentInfo.payable_amount) + '</span></label>' +
                        '</div>';
            }
            //print cash memo and shipment label buttons
            htmlBanner +=
                    '<div class="col-md-4 col-sm-6 col-xs-12 text-right">' +
                    '<!--a href="#" class="print_invoice_btn" onclick="memodownload(' + ordersdetails._id + ')">Print Invoice</a>  &nbsp;' +
                    '<a href="#" class="print_invoice_btn" onclick="cashmemodownload(' + ordersdetails._id + ')">Print Cash Memo</a-->';
            //if(ordersdetails.OStatus!=24 && ordersdetails.OStatus!=21){ 
            if (ordersdetails.OStatus != 24) {
                htmlBanner += '<a href="#" class="print_invoice_btn" onclick="memodownload(' + ordersdetails._id + ')">PRINT Cash MEMO</a>  &nbsp;' +
                        '<a href="#" class="print_invoice_btn" onclick="shipmentlable(' + ordersdetails._id + ')">SHIPMENT LABEL</a>';
            }
        } else {
            if (resposne.data.length <= 0) {
                alert(resposne.message);
                $(".loader").hide();
                console.log(resposne);
            }
        }

        $("#Custom_body").html(htmlBanner);
        $(".loader").hide();
        var d = new Date(ordersdetails.order.patientinfo.expected_delivery_date);
        var date = d.getYear + "-" + d.getMonth + "-" + d.getDate();
        $('#vendordate').datepicker('setDate', date);
        $("#vendordate").datepicker('setStartDate', '0d');
    }
}

//Rejection Pop
function rejectorder_popup(phorder_id) {
    var header_data = "";
    var body_data = "";
    var footer_data = "";
    var item_rejectarray = [];
    $("input:checkbox:checked").map(function (){
		if($(this).val()=="1"){
			return false;
		}
        item_rejectarray.push($(this).val());
    });
    var length = item_rejectarray.length;
    if (length) {
        header_data += '<h4 id="myModalLabel" style="margin:0px; display:block; border:0px; color:#fff;">Add the rejection reason</h4>';
        body_data += '<div>' +
                '<select id="orderrejectreasons" class="form-control" required="required">' +
                '<option value="">Please select reason to reject</option>' +
                '<option value="Some medicines ordered by you are currently unavailable">Some medicines ordered by you are currently unavailable </option>' +
                '<option value="Medicines ordered by you are currently unavailable">Medicines ordered by you are currently unavailable </option>' +
                '<option value="Prescription shared by you is invalid"> Prescription shared by you is invalid</option>' +
                '</select>' +
                '<input type="hidden" value = ' + phorder_id + ' id="reject_omorder_id" name="reject_omorder_id">' +
                '<input type="hidden" value = ' + item_rejectarray + ' id="reject_item_id" name="reject_item_id">' +
                '</div>';
        footer_data += '<button type="button" class="btn btn-danger" data-dismiss="modal" onclick="rejectorder_submit()">Reject</button> <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>';

        call_common_model(header_data, body_data, footer_data, "large");
    } else {
        alert("Please Select Medicine To Reject");
    }
}

function updateprice_popup(order_id, item_code, itemname, quantity, type, batchs) {
    var next = 0;
    var header_data = "";
    var body_data = "";
    var footer_data = "";
    itemname = itemname.replace(/[^a-zA-Z ]/g, "");
    header_data += '<h3 class="modal-title" style="width:300px;" id="myModalLabel">Update MRP</h3>';
    body_data +=
            '<h5>Quantity: <span id=qty>' + quantity + '</span></h5>' +
            '<h6>Product Name:<span id=itemname>' + itemname + '</span></h6>' +
            '<table class="table table-striped" id="vendorupdateprice">' +
            '<thead id="tblHead">' +
            '<tr>' +
            '<th>Quantity</th>' +
            '<th>MRP</th>' +
            '<th>Batch</th>' +
            '<th>Expiry Month/Year</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';
    $.each(batchs, function (key, val) {
        next = parseInt(next) + 1;
        body_data += '<tr>' +
                '<td><input type="Number" min="1" max="' + val.quantity + '" value="' + val.quantity + '" onkeypress="return event.charCode >= 48 && event.charCode <= 57" class="form-control controlInput" id="changequantity' + next + '" name="changequantity' + next + '"></td>' +
                '<td><input type="Number" min="1" value=' + val.mrp + ' onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" title="Only Number" step="1" class="form-control controlInput" id="price' + next + '" name="price' + next + '"></td>' +
                '<td><input type="text" class="form-control controlInput" id="batchname' + next + '" name="batchname' + next + '" maxlength="20" value="' + val.batch + '"></td>' +
                '<td class="expiry_monthyear"><input type="text" id="expiry_monthyear' + next + '" class="form-control datepicker_monthyear" placeholder="YYYY-MM" value="' + val.expirydate + '">' +
                '<!--span class="datepicker">' +
                '<span class="glyphicon glyphicon-calendar cust_cal"></span>' +
                '</span--></td>' +
                '<td>';
        if (next == 1) {
            body_data += '<button class="btn btn-success add-more" type="button" onclick="addmore()">+</button>';
        } else {
            body_data += '<button type="button" class="btn btn-danger" onclick="removelast()">-</button>';
        }
        body_data += '</td></tr>';
    });
    body_data += '</tbody>' +
            '</table>';

    footer_data +=
            '<button type="button" class="btn btn-primary" onclick="vendorupdateprice()">Update</button>' +
            '<input type="hidden" class="form-control controlInput" id="bbatchno1" name="bbatchno1" maxlength="20"  value="1">' +
            '<input type="hidden" value=' + order_id + ' id="phorder_id" name="l2omorder_id">' +
            '<input type="hidden" value=' + item_code + ' id="item_code" name="item_code">' +
            '<input type="hidden" value="' + quantity + '" id="quantity_1" name="quantity_1">' +
            '<input type="hidden" value=' + type + ' id="item_prescribed" name="item_prescribed">' +
            '<input type="hidden" id="batchcount" name="batchcount" value="' + next + '">';

    call_common_model(header_data, body_data, footer_data, "large");
    /*$("#myModalLabel").html(header_data);
     $("#trackresult").html(body_data);
     $("#modalfooter").html(footer_data);
     $("#Modal_for_all").modal("show");*/
}


function call_common_upload_files_modal(type) {
    var header_data = "";
    var body_data = "";
    var footer_data = "";
    if(type=="1"){
        type="Invoice";
    }else{
        type="Prescription";
    }
    header_data +='<h3 class="modal-title" style="width:300px;" id="myModalLabel">Upload '+type+' </h3>';
    
    body_data += '<form  id="formsum"  method="post" enctype="multipart/form-data">' ;
    if(type=="Invoice"){
         body_data += '<div class="col-md-3"><input type="file" name="file[]" id ="l2prescptionname" multiple></div>' ;
    }else{
        body_data += '<div class="col-md-3"><input type="file" name="pic[]" id ="l2prescptionname" multiple></div>' ;
    }
    
            
        body_data += '<input type="hidden" name="orderid" value='+global_ordersdetails._id+' id="pre_orderid">' +
            '<input type="hidden" name="pre_mrn" value='+global_ordersdetails.order.patientinfo.mrn+' id="pre_mrn">';
          if(type == "Invoice"){
              body_data += '<div class="col-md-3"><button type="button" class="btn btn-success" onclick="l2invoiceupload()" >Upload</button></div>' ;
          }else{
              body_data += '<div class="col-md-3"><button type="button" class="btn btn-success" onclick="l2prescptionupload()" >Upload</button></div>' ;
          }
            
         body_data +=   '</form>' +
            '</div>' +
            '<div class="clearfix"></div>' +
            '<hr style="margin-bottom: 0px;">' +
            '<div class="">' +
            '<table class="table table-striped" id="tblGrid">' +
            ' <thead id="tblHead">' +
            ' <tr>' +
            '<th>Uploaded '+type+' Documents</th>' +
            ' </tr>' +
            '</thead>' +
            '<tbody>';
    if(type=="Prescription"){
        if (typeof global_ordersdetails.order.prescription_images != 'undefined' && (global_ordersdetails.order.prescription_images).length != 0) {
		var i = 1;
        $.each(global_ordersdetails.order.prescription_images, function (key, val) {
			
            //$.each(val, function (key, val1){
				var name="Prescription - "+i;
				if(typeof val.filename!="undefined"){
					var name=val.filename;
				}				
                body_data += '<tr>' +
				'<td>'+i+'. '+name+' <a target="_blank" href="' + val.fullpath+ '">View</a></td>' +
				'</tr>';
				i = i +1;
            //});
        });
    } else {
      
        body_data += '<tr><td>No Prescription</td></tr>';
    }
    }else{
        if (typeof global_ordersdetails.order.associate_invoice != 'undefined' && (global_ordersdetails.order.associate_invoice).length != 0) {
		var i = 1;
        $.each(global_ordersdetails.order.associate_invoice, function (key, val) {
			
            //$.each(val, function (key, val1){
				var name="Prescription - "+i;
				if(typeof val.filename!="undefined"){
					var name=val.filename;
				}				
                body_data += '<tr>' +
				'<td>'+i+'. '+name+' <a target="_blank" href="' + val.absolute_path+ '">View</a></td>' +
				'</tr>';
				i = i +1;
            //});
        });
    } else {

        body_data += '<tr><td>No Prescription</td></tr>';
    }
    }
    

    body_data += ' </tbody>' +
            '</table>' +
            '</div>' +
            '</div>' ;
    

        footer_data += '<button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>';

       // call_common_model(header_data, body_data, footer_data, "small");
     $("#myModalLabel").html(header_data);
    $("#trackresult").html(body_data);
    $("#modalfooter").html(footer_data);
    $("#Modal_for_all").modal("show");
    
}


