﻿<?php session_start();
if(!isset($_SESSION['ph_user_id'])){
    // redirect them to your desired location
    header('location:index.php');
    exit;
}
include_once("header.php");
include_once("menu.php");
include_once("footer.php");
?>