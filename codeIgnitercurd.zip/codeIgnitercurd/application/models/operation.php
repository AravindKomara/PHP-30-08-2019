<?php

class operation extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
    

    
    public function commonInsert($tableName,$data){
        $res = $this->db->insert($tableName,$data);
        return $res;
        
    }
    
    public function commonGet($where,$tableName,$resultType,$sort_columun,$sort_type){
        if($resultType == "row"){
            $res = $this->db->where($where)->order_by($sort_columun, $sort_type)->limit(9999)->get($tableName)->row(); 
        }else{
            $res = $this->db->where($where)->order_by($sort_columun, $sort_type)->limit(9999)->get($tableName)->result(); 
        }
        return $res; 
       
    }
    
    public function commonUpdate($where,$set,$tableName){
        $res = $this->db->where($where)->update($tableName,$set);
        return $res; 
       
    }
    
    public function commonDelete($where,$tableName){
        $res = $this->db->where($where)->delete($tableName);
        return $res;
        
    }
    
    public function commonJoin($select,$fromTable,$toTable,$localField,$foreignField,$jointype,$where,$sort_columun,$sort_type,$limit){
        $this->db->select($select);
        $this->db->from($fromTable);
        $this->db->join($toTable, $fromTable.$localField = $toTable.$foreignField,$jointype);//left, right, outer, inner, left outer, right outer
        $this->db->where($where);
        $this->db->order_by($sort_columun, $sort_type);
        $this->db->limit($limit);
        
        $query = $this->db->get();
        return $query->result();
 
    }
    public function commonLike($select, $tableName, $column_name, $like_text, $like_type, $sort_columun, $sort_type, $limit){
        $this->db->select($select);
        $this->db->from($tableName);
        //'Select keyword from keywords where keyword like "%' . $keyword . '%" '
        $this->db->like($column_name, $like_text, $like_type);//3rd argument is  wildcard character (%) 'before' ,'after','both'
         
         //WHERE `name` LIKE '%Aravind'
         //WHERE `name` LIKE 'Aravind%'
         //WHERE `name` LIKE '%Aravind%'
        
        
        $this->db->order_by($sort_columun, $sort_type);
        $this->db->limit($limit);
        
        $query = $this->db->get();
        return $query->result();
 
    }
    
    
}
