<?php  
defined('BASEPATH') OR exit('No direct script access allowed');  
class Hook extends CI_Controller {  
public function print_hooks()  
    {  
        echo "Welcome to Hooks";  
    }  
}  
  
?> 