<?php
require_once('tcpdf/config/lang/eng.php');
require_once('tcpdf/tcpdf.php');
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'ISO-8859-1', false);
            $pdf->SetCreator(PDF_CREATOR);
            $pdf->SetAuthor('Callhealth - Drug');
            $pdf->SetTitle('ShimentLable');
            $pdf->setPrintHeader(true);
            $pdf->setPrintFooter(true);
            $pdf->SetMargins(10, 36, 5);
            $pdf->SetAutoPageBreak(true, 45);
            $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
            $pdf->setLanguageArray($l);
            $pdf->AddPage();

            $html =  file_get_contents("pdf.html");

//print_r($html);exit;
$pdf->writeHTML($html, true, 0, true, 0);
$pdf->lastPage();
$pdf->Output('htmlout.pdf', 'D');
?>