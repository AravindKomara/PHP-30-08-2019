
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>CallHealth | AppAdmin</title>
        <link rel="icon" href="<?=base_url('')?>/assets/images/favicon.ico" type="image/gif" sizes="16x16" />
        <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">

        <link href="<?=base_url('')?>/assets/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- slider -->
        <!-- slider -->
        <script src="<?=base_url('')?>/assets/js/jquery-1.11.0.min.js"></script>
        <script src="<?=base_url('')?>/assets/js/bootstrap.min.js"></script>
        <style>
            .login_block {
                background-color: rgb(255, 255, 255);
                margin-top: 120px;
            }
            body{
                font-family:"Open Sans";
                position:relative;
                overflow-x:hidden;
                font-size:14px;
                background:rgba(232,232,238,0.5);
            }
            a{
                color:#0b69af;
            }
            a:hover, a:focus{
                color:#0b69af
            }
            .btn-group-sm > .btn, .btn-sm{font-size:14px;}


            .login-panel-container{
                padding:30px 0px;
            }
            .login-panel{
                width:450px;
                min-height:400px;
                margin-left:auto;
                margin-right:auto;
                display:block;
                border:1px solid #e1e1e1;
                padding:15px;
                padding-bottom: 35px;
                -webkit-box-shadow: 0px 0px 14px -3px rgba(0,0,0,0.75);
                -moz-box-shadow: 0px 0px 14px -3px rgba(0,0,0,0.75);
                box-shadow: 0px 0px 14px -3px rgba(0,0,0,0.75);
            } 
            .login-panel .login-head{
                font-weight: bold;
                font-size: 24px;
                color: #253d98;
            }
            .login-panel .login-head1{
                font-size: 18px;
                margin-top: 65px;
                display: block;
            }
            .login-panel form{
                padding:15px 15px 0px;
            }
            .login-panel form label {
                color:#333;
            }
            .form-control,.input-group-addon{
                border-radius:0px;
            }
            .input-group-addon{
                background:#fff;
            }
            .mt-15{
                margin-top:15px !important;
            }
            .mt-25 {
                margin-top:25px;
            }
            .mt-30{
                margin-top:30px !important;
            }
            .mb-15{
                margin-bottom:15px;
            }
            .ml-5{
                margin-left:5px
            }
            .mr-5{
                margin-right:5px
            }
            .m-5{
                margin: 0px 5px;
            }
            .p-l-15{
                padding-left:15px;
            }
            .p-10{
                padding:10px;
            }
            .no-pad-l-r
            {
                padding-left:0px;
                padding-right:0px;

            }
            .p-15{
                padding:15px;
            }
            .login-panel form a{
                color:#999;
                float:right;
                line-height:35px;
            }
            .login-panel .register-link{
                margin-left:15px;
                color:#999;
                float:left;
            }
            .login-panel .register-link a{
                color: #78ad43;
            }
            .login-panel .login-terms{
                float:right;
                color: #999;
                margin-right:15px;
            }
            .login-panel .login-terms a {
                color: #999;
            }
            .btn-custom{
                border-radius: 0px;
                background-color: #253d98;
                border: none;
                color: #fff;
            }
            .btn-custom:hover,.btn-custom:focus{
                background-color: #78ad43;
                color: #fff;
            }
            .form-control.text-width{
                width:279px;
            }
            .form-control.text-width1{
                width: 208px;
            }
            .btn-custom1{
                border-radius: 0px;
                background-color: #78ad43;
                border: none;
                color: #fff;
            }
            .btn-custom1:hover,.btn-custom1:focus{
                background-color: #253d98;
                color: #fff;
            }
            .btn-custom2, .btn-custom2.inact{
                border-color: #ccc;
                border-radius: 0;
                color: #333;
                margin: 6px 4px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                width: 179px;
            }
            .btn-custom2:hover, .btn-custom2:focus, .btn-custom2.act{
                color: #fff;
                background-color: #7bae4d;
                border-color: #7bae4d;
            }
            .add-btn {
                margin-right:5px;
                margin-top:5px;
                float:right;
                color: #0b69af;
                background-color: #fff;
                border:1px solid #ccc;
            }
            .validation
            {
                color:red;
                display:none;
            }
            .login-panel .form-group{
                display:block;
            }
            .login-panel .alert{
                display: block;
                padding: 10px;
            }
            .login-panel .alert.success {
                border: 1px solid #78ad43;
                color: #78ad43;
            }
            .login-panel .alert.error{
                border: 1px solid #f00;
                color: #f00;
            }
            /* Body Styles */
            label{
                color:#333;
            }
            .form-group {
                margin: 15px 0px;
                display: flex;
            }
            form .form-head{
                color: #6AB942;
                font-weight: 600;

            }
            /************* Login Form Ends Here *****************/
            #wrapper {
                -moz-border-bottom-colors: none;
                -moz-border-left-colors: none;
                -moz-border-right-colors: none;
                -moz-border-top-colors: none;
                border-color: #669bdf #fff;
                border-image: none;
                border-radius: 0;
                border-style: solid;
                border-width: 3px 1px;
                padding-bottom: 30px;
                box-shadow: 0px 0px 40px rgba(0,0,0,.1);
            }
            #wrapper input:not([type="checkbox"]) {
                padding: 10px 5px 10px 10px;
            }
            .fa-user::before {
                content: "";
            }
            .submitButton #submit {
                display: block;
                float: right;
                margin: 0 0 0 30px;
                width: 30% !important;
            }
            .customButton[type="submit"] {
                border: medium none;
                font-size: 14px !important;
            }
            .customButton {
                margin: 20px 0;
                outline: medium none !important;
            }
            .customButton {
                background: #6ab942 none repeat scroll 0 0;
                color: #fff;
                padding: 5px 10px;
                text-transform: uppercase;
            }
            .img-responsive.center-block {
                margin-bottom: 30px;
                margin-top: 30px;
                width: 70%;
            }
            input#input-username,input#input-password{

                border-radius:4px 0px 0px 4px;
                height:38px;	
            }
            .input-group-addon{
                border-radius:0px 4px 4px 0px;		
            }
            .form-control:focus {
                border-color: #6ab942;
                box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(123, 174, 77, 0.6);
                outline: 0 none;
            }
            input { font-size:14px; padding:5px; border:1px solid #CCC; display: block; margin:0px 0; }
            .loginbutton{
                background: #669bdf none repeat scroll 0 0;
                color: #fff;
                padding: 5px 10px;
                text-transform: uppercase;
                display:inline-block;
            }
            a.loginbutton:hover{color:#fff; text-decoration:none;}
            input,textarea,select,.form-group input.form-control, input.form-control, div.form-group  input.form-control,input.form-control,.form-group  select, input.fp-input{
                border-color: #e5e5e5 !important;
                transition: border-color 0.3s ease 0s !important;
                box-shadow:none !important; 
                border-radius:0 !important;
                border-style: solid;
                border-width: 2px !important;	
                color: #999;
                display: block;
                font-size:12px;
                height: 33px;
                width:100%; 
            }
            input:hover,textarea:hover, input:focus,input:active, select:focus,select:active, textarea:focus,textarea:active {
                border-color: #70ba63 !important;
                outline:none;
                box-shadow:none !important; 
            }
            .form-group input.form-control:focus,input.form-control:focus, input.fp-input:focus, input.fp-input:hover,.form-group input:focus,.form-group input.form-control:hover,input.form-control:hover, .form-group input:hover,.form-group  select:focus,.form-group  select:hover, .form-group .form-control textarea:focus, .form-group textarea:focus,.form-group input.form-control:focus + i, .form-group input:focus + i,.form-group input.form-control:focus + i,.form-group input:focus + i,.form-group input.form-control:focus + i ,.form-group input:focus + i{
                border-color: #70ba63 !important;	
            }
        </style>
    </head>
    <body class="login_body">
        <div class="container">
            <div class="main">

            </div>
        </div>
        <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1 login_block" id="wrapper"> 
            <!-- BEGIN LOGIN FORM -->
            <form method="post" class="form-vertical no-padding no-margin" autocomplete="off" id="loginform" action="<?=base_url('admin/appadminAuthentication')?>">
                <div class="col-md-10 col-md-offset-1"> <img alt="Call Health" class="img-responsive center-block" src="<?=base_url('')?>/assets/images/ch-logo.png"> 

                    <font color="green"></font><font color="red"></font>

                    <div class="form-group"> 

                        <div class="input-group">
                            <input type="text" required="" value="" name="officer_id" autocomplete="off" placeholder="Username" class="form-control" id="input-username" aria-required="true">
                            <div class="input-group-addon"><i class="fa fa-user"></i></div>
                        </div>
                        <label class="error" for="input-username" id="input-username-error"></label>
                        <small class="errorText"> </small> </div>

                    <div class="form-group">
                        <div class="input-group">
                            <input type="password" required="" value="" name="password" autocomplete="off" placeholder="Password" class="form-control" id="input-password" aria-required="true">
                            <div class="input-group-addon"><i class="fa fa-key"></i></div>
                        </div>
                        <label class="error" for="input-password" id="input-password-error"></label>
                        <small class="errorText"> </small> </div>
                    <div class="submitButton"> <!-- href="forgotpassword" --> 
                        <!--<a href="#" class="pull-left"><u>I can't access my Account.</u> </a>-->
                        <input type="submit" style="cursor:pointer;" class="loginbutton pull-right" value="Login"></br>
                        <?php if (isset($_SESSION['login_fail_msg']) && $_SESSION['login_fail_msg'] != "") { ?> <span style="color:red"><?php echo $_SESSION['login_fail_msg'];
                        $_SESSION['login_fail_msg'] = ""; ?></span><?php } ?>
                    </div>
                </div>
            </form>

        </div>
    </body>
</html>