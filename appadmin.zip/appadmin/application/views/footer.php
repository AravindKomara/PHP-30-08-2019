<style>
    label {
        vertical-align:middle;
    }
</style>
<!-- Common Modal -->
<div class="modal fade" id="commonModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" id="model_resp">
            <div class="modal-header" id="modal_header" style="background-color:#7bae4d; color:#fff;">
                <button type="button" class="close close_model" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Order Details</h4>
            </div>
            <div class="modal-body" id="modal_body">
                <p>This is a common modal.</p>
            </div>
            <div class="modal-footer" id="modal_footer">
                <button type="button" class="btn btn-default close_model" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!--modal end-->



<script src="https://cdn.socket.io/socket.io-1.2.0.js"></script>
<script type="text/javascript">
	sessionStorage.setItem("appadmin_dashboard_user_id", "<?php echo $sessiondata["userid"]; ?>");
	sessionStorage.setItem("appadmin_dashboard_user_name", "<?php echo $sessiondata['username']; ?>");
	
</script> 
<script>
  //for selecting multiple options from dropdown
    $(document).ready(function() {
         $('.js-example-basic-multiple').select2({
               placeholder: "Select a city"
        });
        
    });
    
    //getinng search dropdown values  
    $("#orderdropwown").on('change', (function (e) {
        e.preventDefault();
        var value = $(this).val();
        //  alert(value);
        $("#orderdropwownvalue").val(value);

    }));

    //common ajax call
    function _ajaxEventHandler(method, payload, functionName) {
        $.ajax({
            url: "<?php echo base_url(); ?>admin/" + method,
            type: "POST",
            data: payload,
            //data: JSON.stringify(payload),
            //contentType: "application/json",
            success: functionName,
            error: function (jqXHR, exception) {
            getErrorMessage(jqXHR, exception);
           }
            
        });
    }
    
    // This function is used to get error message for all ajax calls
    function getErrorMessage(jqXHR, exception) {
        $(".loader").hide();
        var msg = '';
        if (jqXHR.status === 0) {
               msg = 'Not connect.\n Verify Network.';
        } else if (jqXHR.status == 404) {
               msg = 'Requested page not found. [404]';
        } else if (jqXHR.status == 500) {
               msg = 'Internal Server Error [500].';
        } else if (exception === 'parsererror') {
               msg = 'Requested JSON parse failed.';
        } else if (exception === 'timeout') {
               msg = 'Time out error.';
        } else if (exception === 'abort') {
               msg = 'Ajax request aborted.';
        } else {
               msg = 'Uncaught Error.\n' + jqXHR.responseText;
        }
         
        alert(msg);
    }
    
    //common ajax success resposne
    function commonSuccessResponse(response){
        console.log(response);
        if (typeof response == 'string') {
	     response = JSON.parse(response);
	} else {
             response = response;	
	}
        if(response.status == 1 || response.status == "1"){
            if(typeof(response.message)!=="undefined"){
                alert(response.message);
            }else{
                alert(response.msg);
            }
             
             window.location.reload();
        }else{
            if(typeof(response.message)!=="undefined"){
                alert(response.message);
            }else{
                alert(response.msg);
            }
        }
            $('.loading').hide();
            //$("#commonModal").modal("hide");
    }

    function changedate(dt) {
        if (dt === "NaN") {
            return "-";
        } else {
            dt = dt.replace(" ", "T");
            dt = dt.split('T');
            var time = dt[1].slice(0, 8);
            var H = +time.substr(0, 2);
            var h = (H % 12) || 12;
            var ampm = H < 12 ? "AM" : "PM";
            time = h + time.substr(2, 3) + ampm;
            return dt = dt[0] + ' ' + time;
        }
    }

    function convetamount(amount) {
        amount = amount.toString();//converting number to string
        var arr = amount.split('.');//spilting string after dot
        amount = arr[0] + '.00';//if it doesn't have numbers after dot adding two 00's
        if (arr[1]) {
            amount = arr[0] + '.' + arr[1].slice(0, 2);//showing only two digits after the dot
        }
        return amount;
    }

    //for order details
    function orderdetails(OrderID) {
        $('.loading').show();
        _ajaxEventHandler("getorderinformation", {order_id: OrderID}, resposeOf_order_info);
    }

    //response of order_info modal
    function resposeOf_order_info(response) {
       // console.log(response);
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        var wallet_amount = 0;
        var voucher_amount = 0;
        var delivery_charge = 0;
        var total_grossamount = 0;
        var total_netamount = 0;
        var total_discountamount = 0;
        var total_payable_amount = 0;
         if (typeof response == 'string') {
              ordersdetails = JSON.parse(response);
	} else {
              ordersdetails = response;	
	}
       
        //console.log(ordersdetails);
        if (ordersdetails.data.message === "Success") {
            var i = 0;
            header_data +="<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
			"<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
			" <h5 class='modal-title' id='recieptdetails' style='margin:0;line-height: 1.428571;'>" +
			"<b>" + ordersdetails.data.data[0].order.patientinfo.name + "</b>" +
			"|" + ordersdetails.data.data[0].order.patientinfo.gender + "|" +
			"" + ordersdetails.data.data[0].order.patientinfo.age + "|" +
			"MRN:" + ordersdetails.data.data[0].order.patientinfo.mrn + "<br> " +
			"Order#:" + ordersdetails.data.data[0].odid + " |" +
			"Ordered On:" + changedate(ordersdetails.data.data[0].order.patientinfo.scheduled_date ? ordersdetails.data.data[0].order.patientinfo.scheduled_date : "NaN")+"<br><br>";
			
            if(ordersdetails.data.data[0].order.patientinfo.service_type == "3" || ordersdetails.data.data[0].order.patientinfo.service_type == "4"){
                header_data +=  "Laboratory Name:" + ordersdetails.data.data[0].order.provider_info[0].associate_name +"";
            }
            
            header_data += "</h5></div>";
            body_data +="<div class='modal-body' >" +
			"<div class='row'>" +
			"<div class='col-xs-12'>" +
			"<div class='orderdata' >" +
			"<div class='col-md-12' id='JS_main_content_scroll' style='overflow:auto; height:350px;padding:0;'>" +
			"<ul class='nav navbar-nav symptoms' style='width:100%;'>" +
			"<li class='col-xs-12 active'>" +
			"<table class='table table-striped table-bordered table-hover'>" +
			"<thead>" +
			"<tr>" +
			"<th width='30' style='text-align:center;'>#</th>" +
			"<th width='30' style='text-align:center;'>Test Name</th>" +
			"<th width='30' style='text-align:center;'>Doctor</th>" +
			"<th width='30' style='text-align:center;'>Quantity</th>" +
			"<th width='30' style='text-align:center;'>Scheduled Date/Time</th>" +
			"<th width='30' style='text-align:center;'>Gross Amount</th>" +
			"<th width='30' style='text-align:center;'>Net Amount</th>" +
			"</tr>" +
			"</thead>" +
			"<tbody class='doctors-available'>";
            //foreach loop            
            $.each(ordersdetails.data.data[0].order.orderitem, function (key, val){
				//console.log(val.item_status);
                if (val.item_status != "8"){
                    i = i + 1;
                    val.quantity = val.quantity ? val.quantity : 1;
                    val.gross_amount = val.gross_amount ? parseFloat(val.gross_amount) : 0;
                    val.net_amount = val.net_amount ? parseFloat(val.net_amount) : 0;
                    val.discount_amount = val.discount_amount ? parseFloat(val.discount_amount):0;

                    total_grossamount = parseFloat(total_grossamount) + parseFloat(val.gross_amount);
                    total_netamount = parseFloat(total_netamount) + parseFloat(val.net_amount);
                    total_discountamount = parseFloat(total_discountamount) + parseFloat(val.discount_amount);
					
                    body_data += "<tr>" +
					"<td width='30' style='text-align:center;'>" + i + "</td>" +
					"<td width='30'  style='text-align:center;'>" + (val.itemname ? val.itemname : "Na") + "</td>" +
					"<td width='30' style='text-align:center;'>" + (val.doctor ? val.doctor : "Na") + "</td>" +
					"<td width='30' style='text-align:center;'>" + val.quantity + "</td>" +
					"<td width='30' style='text-align:center;'>" + changedate(ordersdetails.data.data[0].order.patientinfo.scheduled_date) + "</td>" +
					"<td width='30' style='text-align:center;'>" + val.gross_amount.toFixed(2) + "</td>" +
					"<td width='30'  style='text-align:center;'>" + val.net_amount.toFixed(2) + "</td>" +
					"</tr>";
                }
            });//end of foreach loop

            //calculating total payable amount
			
            wallet_amount = convetamount(ordersdetails.data.data[0].payment_info.wallet_amount ? ordersdetails.data.data[0].payment_info.wallet_amount : 0);
			//calling method
            voucher_amount = convetamount(ordersdetails.data.data[0].payment_info.voucher_amount ? ordersdetails.data.data[0].payment_info.voucher_amount : 0);
			//calling method
			
            delivery_charge = convetamount(ordersdetails.data.data[0].order.patientinfo.medicine_delivery_charge ? ordersdetails.data.data[0].order.patientinfo.medicine_delivery_charge : 0);//calling method
			
			if(parseFloat(delivery_charge)>0){
				total_payable_amount = (parseFloat(total_netamount) + parseFloat(delivery_charge)) - (parseFloat(wallet_amount) + parseFloat(voucher_amount));
			}else{
				total_payable_amount = parseFloat(total_netamount) - (parseFloat(wallet_amount) + parseFloat(voucher_amount));
			}

            body_data += "<tr>" +
			"<td colspan='6' width='30' style='text-align:right;'>Total GrossAmount:</td>" +
			"<td style='text-align:center;'>" + total_grossamount.toFixed(2) + "</td>" +
			"</tr>" +
			"<tr>" +
			"<td colspan='6' width='30' style='text-align:right;'>Total DiscountAmount:</td>" +
			"<td style='text-align:center;'>" + total_discountamount.toFixed(2) + "</td>" +
			"</tr>" +
			"<tr>" +
			"<td colspan='6' width='30' style='text-align:right;'>Total NetAmount:</td>" +
			"<td style='text-align:center;'>" + total_netamount.toFixed(2) + "</td>" +
			"</tr>" +			
			"<tr>" +
			"<td colspan='6' width='30' style='text-align:right;'>Total WalletAmount:</td>" +
			"<td style='text-align:center;'>" + wallet_amount + "</td>" +
			"</tr>" +
			"<tr>" +
			"<td colspan='6' width='30' style='text-align:right;'>Total VoucherAmount:</td>" +
			"<td style='text-align:center;'>" + voucher_amount + "</td>" +
			"</tr>";
			if(parseFloat(delivery_charge)>0){
				body_data += "<tr><td colspan='6' width='30' style='text-align:right;'>Total DeliveryCharges:</td>" +
				"<td style='text-align:center;'>" + delivery_charge + "</td>" +
				"</tr>";
			}	
			body_data += "<tr>" +
			"<td colspan='6' width='30' style='text-align:right;'>Total PaybleAmount:</td>" +
			"<td style='text-align:center;'>" + total_payable_amount.toFixed(2) + "</td>" +
			"</tr>" +
			"</tbody>" +
			"</table>" +
			"</li>" +
			"</ul>" +
			"</div>" +
			"</div>" +
			"</div>" +
			"</div>" +
			"</div>";
        } else {
            header_data +=
                    "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                    "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                    " <h5 class='modal-title' id='recieptdetails' style='margin:0;line-height: 1.428571;'>" +
                    "<font style='color:red;font-size:25px;'>Order dettails not found</font>"+
            "</h5>" +
                    " </div>";
        }
        footer_data+='<button type="button" class="btn btn-default close_model" data-dismiss="modal">Close</button>';

        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();
    }

    //for tracking order
    function trackorder(OrderID) {
        $('.loading').show();
        _ajaxEventHandler("trackorder", {orderid: OrderID}, resposeOf_workorder_info);
    }

    //response of tracking order modal
    function resposeOf_workorder_info(response) {
        //console.log(response);return;
        if (typeof response == 'string') {
                workordersdetails = JSON.parse(response);
        } else {
                workordersdetails = response;
        }
        console.log(workordersdetails.data.order_log);
        var header_data = "";
        var body_data = "";
        var footer_data = "";

        //if (workordersdetails.order_log !== 'undefined' && workordersdetails.order_log.length > 0) {
        if (workordersdetails.status == 1 && workordersdetails.data.order_log.length > 0) {
            var action = "";

            header_data +=
                    "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                    "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                    "<h3 class='modal-title' style='width:300px;' id='myModalLabel'>Order Tracking Status</h3>" +
                    "<!--<label id='hforhomefacility' style='width: auto;margin-top: -24px;margin-bottom: 0px;height: 21px; margin-right: 34px;' class='pull-right label label-success popup_label'><i>Home Facility</i> : " +(workordersdetails.data.order_log[0].popname  ? workordersdetails.data.order_log[0].popname : "N/A")+ "</label>-->" +
                    " </div>";
            body_data +=
                    "<div class='modal-body' >"+
                    "<div class='row'>"+
                    "<div class='col-xs-12'>"+
                    "<div class='orderdata' >"+
                    "<div class='col-md-12' id='JS_main_content_scroll' style='overflow:auto; height:350px;padding:0;'>"+
                    "<ul class='nav navbar-nav symptoms' style='width:100%;'>"+
                    "<li class='col-xs-12 active'>"+
                    "<table class='table table-striped table-bordered table-hover'>" +
                    "<thead>" +
                    "<tr>" +
                    "<th width='30'  style='text-align:center;'>Order</th>" +
                    "<th width='30'  style='text-align:center;'>User Name</th>" +
                    "<th width='30'  style='text-align:center;'>User Id</th>" +
                    "<th width='30'  style='text-align:center;'>Role</th>" +
                    "<th width='30'  vstyle='text-align:center;'>Action</th>" +
                    "<!--<th width='30'  style='text-align:center;'>Servicing Facility Name</th>-->" +
                    "<th width='30'  style='text-align:center;'>Order Status</th>" +
                    "<th width='30'  style='text-align:center;'>Updated On</th>" +
                    "<th width='30'  style='text-align:center;'>Reason</th>" +
                    "</tr>" +
                    "</thead>" +
                    "<tbody class='doctors-available'>";
            //foreach loop
            $.each(workordersdetails.data.order_log, function (key, val) {
                //  console.log(val.action);
                if (val.action !== null) {
                    action = val.action.charAt(0).toUpperCase() + val.action.slice(1);
                }
                if (action !== "Delivered") {
                    body_data += 
                            "<tr>" +
                            "<td width='30'  style='text-align:center;'>" + val.wodid + "</td>" +
                            "<td width='30' style='text-align:center;'>" +(val.actionByName  ? val.actionByName : "N/A")+ "</td>" +
                            "<td width='30' style='text-align:center;'>" +(val.actionById  ? val.actionById : "N/A")+ "</td>" +
                            "<td width='30' style='text-align:center;'>" +(val.role  ? val.role : "N/A")+ "</td>" +
                            "<td width='30' style='text-align:center;'>" +(val.action  ? val.action : "N/A")+ "</td>" +
                            "<!--<td width='30'  style='text-align:center;'>" +(val.popname  ? val.popname : "N/A")+ "</td>-->" +
                            "<td width='30'  style='text-align:center;'>" + (val.status_name?val.status_name:"") + "</td>" +
                            "<td width='30'  style='text-align:center;'>" + val.created_date + "</td>" +
                            "<td width='30'  style='text-align:center;'>" +(val.reason  ? val.reason : "N/A")+ "</td>" +
                            "</tr>";

                }

            });
            body_data += "</tbody>" +
                    "</table>" +
                    "</div>";

        } else {
            header_data +=
                    "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                    "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                    " <h5 class='modal-title' id='recieptdetails' style='margin:0;line-height: 1.428571;'>" +
                    "<font style='color:red;font-size:25px;'>"+workordersdetails.message+"</font>" +
                    "</h5>" +
                    " </div>";
        }
        
        footer_data+= '<button type="button" class="btn btn-default close_model" data-dismiss="modal">Close</button>';


        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();

    }

    function getOfficers(orderid, schedule_data, workorder_id, roletype) {
      //  $('.loading').show();
        var data = {order_id: orderid, scheduled_date: schedule_data, workorder_id: workorder_id, roletype: roletype};
        _ajaxEventHandler("getOfficers_list", data, fun_getOfficers);
    }

//calling getOfficers model
    function fun_getOfficers(response) {
        //alert(response);
        var Obj = JSON.parse(response);
        var header_data = "<h4 class='modal-title'>Select The Officer</h4>";
        var body_data = "";
        if (Obj.status == "1") {
            var i = 1;
            body_data += "<div style='max-height:300px; overflow:auto;'><table width='100%' style='border-collapse: collapse;' cellpadding='10'>";
            $.each(Obj.data, function (key, val) {
                body_data += "<tr>" +
                        "<td width='30' height='32' align='left'>" + i + ". </td><td>" + val.officer_name + "</td>" +
                        "<td align='right'><button class='btn btn-success' style='height:29px; padding:4px 12px;' onclick='selectOfficer(this);' data_officer_id='" + val.officer_id + "' data_officer_name='" + val.officer_name + "' data_associate_id='" + val.associate_id + "' data_branch_id='" + val.branch_id + "' data_order_id='" + Obj.orderid + "' data_scheduled_date='" + Obj.scheduled_date + "' data_workorder_id='" + Obj.workorder_id + "'>Select</button></td></tr>";
                i = i + 1;
            });
            body_data += "</table></div>";
        } else {
            body_data += "<div>" + Obj.message + "</div>";
        }
        //console.log(Obj.status);
        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $('.loading').hide();
        $("#commonModal").modal("show");
    }
// Get Officer List for allocation

// Force Allocation
    function selectOfficer(obj) {
        var data = {
            order_id: $(obj).attr("data_order_id"),
            scheduled_date: $(obj).attr("data_scheduled_date"),
            associate_id: $(obj).attr("data_associate_id"),
            branch_id: $(obj).attr("data_branch_id"),
            officer_id: $(obj).attr("data_officer_id"),
            officer_name: $(obj).attr("data_officer_name"),
            workorder_id: $(obj).attr("data_workorder_id")
        };
        $('.loading').show();
        _ajaxEventHandler("force_allocation", data, fun_force_allocation);
    }

    function fun_force_allocation(response) {
        console.log(response);
        var Obj = JSON.parse(response);
       //alert(Obj);
        if (Obj.status == "1" || Obj.status == 1) {
            alert(Obj.chiss_updation_order_log[0].message);
            location.reload();
 
        } else {
            alert(Obj[0].message);
            location.reload();
        }
    }

    //assoign order by chiss 
    function allocateby_chissSocket(order_id, url, urlchiss, orderdid, scheduledate) {
        var userid = "<?php echo $sessiondata["userid"]; ?>";
        var orderids = [parseInt(order_id)];
        /*for (i = 0; i < selected.length; i++) {
         var res =selected[i].split(",");
         var oid=res[0];
         order_id=parseInt(oid);
         orderids.push(order_id);
         }*/
        debugger;
        var obj = {"orderid": orderids};
        obj = JSON.stringify(obj);
        console.log(obj);
        $.ajax({
            type: "POST",
            url: url + "orderStructurechiss",
            data: obj,
            success: function (result) {
                debugger;
                console.log(result);
                //console.log(event_type);debugger;
                var transaction_id = (new Date()).getTime();
                socket.emit('message', {receipentId: userid, receipentAppId: 'CHISS', receipentDeviceId: '', messageType: 'orderCreated', payload: {message: result, transaction_id: transaction_id}});
                sessionStorage.setItem('transactionid', transaction_id);
                var loginid = btoa(userid + "_" + transaction_id);
                //debugger;
                //alert(urlchiss+'/reallocate_list/'+loginid);
                window.open(urlchiss + '/reallocate_list/' + loginid, '_blank');
                //$('#orderfreeze').show();
                //$('#checkAvailibility').hide();				
            }
        });
    }



$(function () {
        $(".datepick").datepicker({
            format: 'dd-mm-yyyy',
            orientation: "top",
            autoclose: true,
            //endDate: new Date()

        }).on('changeDate', function (selected) {
            var date = new Date(selected['date']);
            var dd = date.getDate();
            if(dd<10) {
                dd='0'+dd;
            } 
            var month = date.getMonth() + 1;
            if(month<10) {
                month='0'+month;
            } 
            var finaldate = dd + "-" + month + "-" + date.getFullYear();
            //console.log(finaldate);
            $("#fromdatesearch").val(finaldate);
            $(this).prev('input').val(finaldate);
        });
    });



    function generateRecipt_modal(orderid) {
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        
        
        header_data +=
                "<style>.error_clean{font-size: 12px;color: red;margin : 0px;}</style>" +
                "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                "<button type='button' class='close close_model' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                "<h3 class='modal-title' style='width:300px;' id='myModalLabel'>Generate Receipt</h3>" +
                " </div>";
        body_data +=
                "<div class='modal-body' >" +
                "<div class='row'>" +
                "<div class='col-xs-12'>" +
                "<div class='orderdata' >" +
                "<div class='col-md-12' id='JS_main_content_scroll' style='overflow:auto; height:350px;padding:0;'>" +
              
                "<ul class='nav navbar-nav symptoms' style='width:100%;'>" +
                "<li class='col-xs-12 active'>" +
                "<table class='table table-striped table-bordered table-hover'>" +
                "<thead>" +
                "<tr>" +
                "<th width='30'  style='text-align:center;'>PaymentMode</th>" +
                "<th width='30'  style='text-align:center;'>Amount</th>" +
                "<th width='30'  style='text-align:center;'>Payment RefNo</th>" +
                "<th width='30'  style='text-align:center;'>Reason</th>" +
                "</tr>" +
                "</thead>" +
                "<tbody class='doctors-available'>" +
                "<tr>" +
                "<td width='90'  style='text-align:center;'>" +
                '<input type="hidden" id="recipt_modal_select_value" value="cash" name="item_code">' +
                '<input type="hidden" id="recipt_modal_order_id" name="item_code" value="'+orderid+'">' +
                '<select size="1" name="search_type" id="recipt_modal_select" onchange="selectpaymentmodeype()"   class="submitrecipt btn dropdown-toggle select_search_value form-control pull-left" aria-controls="example"  style="background-color: #7BAE4D; color: #FFFFFF;height:33px;">' +
                '<option value="cash">Cash</option>' +
                '<option value="creditcard">Credit Card</option>' +
                '<option value="debitcard">Debit Card</option>' +
                '<option value="paytm">Paytm</option>' +
                '<option value="ezeitapp">EZEit App</option>' +
                '</select>' +
                '<p class="recipt_modal_select_error error_clean"></p>' +
                "</td>" +
                "<td width='30'  style='text-align:center;'>" +
                "<input type='text' id='recipt_entered_amount'placeholder = 'Enter Amount...' name='item_code' class='submitrecipt'>" +
                "</td>" +
                "<td width='30'  style='text-align:center;'>" +
                '<input type="text" id="recipt_payment_refno" placeholder = "Enter Payment RefNo..." name="item_code" class="submitrecipt">' +
                '<p class="recipt_transcaction_code_error error_clean"></p>' +
                "</td>" + 
                "<td width='30'  style='text-align:center;'>" +
                "<input type='text' id='recipt_entered_reason' name='item_code' placeholder = 'Enter Reason...' class='submitrecipt'>" +
                "</td>" +
                "</tr>" +
                "</tbody>" +
                "</table>" +
              
                "</div>";

      footer_data +=
                '<div class="row">' +
                '<div class="col-md-3" ></div>' +
                '<div class="col-md-1" ></div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-primary"  Style="width:85px;" onclick="submit_generate_recipt()">Submit</button>' +
                '</div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-danger"  Style="width:85px;" data-dismiss="modal">Cancel</button>' +
                '</div>' +
                '</div>' +
                '</div>';

        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();

    }

    function selectpaymentmodeype() {
        var value = $('#recipt_modal_select option:selected').val();
        //  alert(value);
        $("#recipt_modal_select_value").val(value);
    } 

    function submit_generate_recipt() {
        var payment_mode = $("#recipt_modal_select_value").val();
        var entered_amount = $("#recipt_entered_amount").val();
        var payment_refno = $("#recipt_payment_refno").val();
        var reason = $("#recipt_entered_reason").val();
        
        if(entered_amount === "" ){
            alert("Please enter amount");
            return false;
        }
        if(payment_mode !== "cash" && payment_refno === "" ){
            alert("Please enter payment refno");
            return false;
        }
        
        if(reason === "" ){
            alert("Please enter reason");
            return false;
        }
        
        var _data = {
                order_id: $("#recipt_modal_order_id").val(),
                paymentmode: payment_mode,
                referencenumber: payment_refno,
                reason:reason,
                reciptamount: parseFloat(entered_amount),
                actionById:sessionStorage.getItem('appadmin_dashboard_user_id'),
                actionByName:sessionStorage.getItem('appadmin_dashboard_user_name'),

                
          };
         console.log(_data);
         _ajaxEventHandler("generateReciptSubmit", _data, commonSuccessResponse);
        
       

    }

    $("#changeorderstatus_button").click(function (e) {
        e.preventDefault();
        var orderIDs = [];
        $("input:checkbox:checked").map(function () {
            orderIDs.push($(this).val());
        });
        //alert(orderIDs);
        console.log(orderIDs);
       // return;
       changeScheduledDate_modal(orderIDs);
      //  $('.loading').show();
       
    });
    
    function changeScheduledDate_modal(orderIDs) {
        if(orderIDs == ""){
            alert("please select atleast one order");return;
        }
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        var receiptData = "";
     
        
        header_data +=
                "<style>.error_clean{font-size: 12px;color: red;margin : 0px;}</style>" +
                "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                "<button type='button' class='close close_model' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                "<h3 class='modal-title' style='width:300px;' id='myModalLabel'>Change Scheduled Dates</h3>" +
                " </div>";
        body_data +=
                "<div class='modal-body' >" +
                "<div class='row'>" +
                "<div class='col-xs-12'>" +
                "<div class='orderdata' >" +
                "<div class='col-md-12' id='JS_main_content_scroll' style='overflow:auto; height:350px;padding:0;'>" +
               '<input type="hidden" id="change_scheduled_date_orderids" name="item_code" value="'+orderIDs+'">' +
               '<span style="color:#337ab7;font-size: 130%;">We are updating scheduled date for orders : '+orderIDs+' </span><br><br><br>'+
                "<ul class='nav navbar-nav symptoms' style='width:100%;'>" +
                "<li class='col-xs-12 active'>" +
                "<table class='table table-striped table-bordered table-hover'>" +
                "<thead>" +
                "<tr>" +
                "<th width='30'  style='text-align:center;'>New ScheduledDate</th>" +
                 "<th width='30'  style='text-align:center;'>Time</th>" +
                "<th width='30'  style='text-align:center;'>Reason</th>" +
                "</tr>" +
                "</thead>" +
                "<tbody class='doctors-available'>" +
                "<tr>" +
                "<td width='30'  style='text-align:center;'>" + 
                "<input type='date'  id='new_scheduled_date' name='item_code' class='submitrecipt' style='width: 185px;height: 36px;'>" +
                "</td>" +
                "<td width='30'  style='text-align:center;'>" +
                "<input type='time' id='new_scheduled_time' name='item_code' placeholder : 'ex:14:00:000' class='submitrecipt' style='width: 185px;height: 36px;'>" +
                "</td>" +
                "<td width='30'  style='text-align:center;'>" +
                "<input type='text' id='reason_for_new_scheduled_date' name='item_code' class='submitrecipt' style='width: 185px;height: 36px;'>" +
                "</td>" +
                
                "</tr>" +
                "</tbody>" +
                "</table>" +
              
                "</div>";

      footer_data +=
                '<div class="row">' +
                '<div class="col-md-3" ></div>' +
                '<div class="col-md-1" ></div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-primary"  Style="width:85px;" onclick="changeScheduledDate_submit()">Submit</button>' +
                '</div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-danger"  Style="width:85px;" data-dismiss="modal">Cancel</button>' +
                '</div>' +
                '</div>' +
                '</div>';

        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();

    }
    
    function changeScheduledDate_submit(){
        var orderIDs = $("#change_scheduled_date_orderids").val();
        var new_scheduled_date = $("#new_scheduled_date").val();
        var new_scheduled_time = $("#new_scheduled_time").val();
        var reason = $("#reason_for_new_scheduled_date").val();
        var ordreids = orderIDs.split(',').map(Number);
        if(new_scheduled_date === "" || new_scheduled_time == ""  ){
            alert("Please enter schedule date and time ");
            return false;
        }
    
        var _data = {
                order_ids: ordreids,
                new_scheduled_date:new_scheduled_date,
                new_scheduled_time:new_scheduled_time,
                reason: reason,
                actionById:sessionStorage.getItem('appadmin_dashboard_user_id'),
                actionByName:sessionStorage.getItem('appadmin_dashboard_user_name'),

                
          };
         //console.log(_data); return;
         _ajaxEventHandler("changeScheduledDatesubmit", _data, commonSuccessResponse);
    }
    
    function changeOrderStatus_modal(orderid) {
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        
        
        header_data +=
                "<style>.error_clean{font-size: 12px;color: red;margin : 0px;}</style>" +
                "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                "<button type='button' class='close close_model' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                "<h3 class='modal-title' style='width:300px;' id='myModalLabel'>Change Order Status</h3>" +
                " </div>";
        
        body_data +=
                "<div class='modal-body' >" +
                "<div class='row'>" +
                "<div class='col-xs-12'>" +
                "<div class='orderdata' >" +
                "<div class='col-md-12' id='JS_main_content_scroll' style='overflow:auto; height:350px;padding:0;'>" +       
                "<ul class='nav navbar-nav symptoms' style='width:100%;'>" +
                "<li class='col-xs-12 active'>" +
                "<table class='table table-striped table-bordered table-hover'>" +
                "<thead>" +
                "<tr>" +
                "<th width='30'  style='text-align:center;'>Action</th>" +
                "<th width='30'  style='text-align:center;'>Reason</th>" +
                "</tr>" +
                "</thead>" +
                "<tbody class='doctors-available'>" +
                "<tr>" +
                "<td width='30'  style='text-align:center;'>" +
                '<input type="hidden" id="COS_modal_select_value" value="6" name="item_code">' +
                '<input type="hidden" id="COS_modal_order_id" name="item_code" value="'+orderid+'">' +
                '<select size="1" name="search_type" id="COS_modal_select" onchange="selectstatustype()"   class="submitrecipt btn dropdown-toggle select_search_value form-control pull-left" aria-controls="example"  style="background-color: #7BAE4D; color: #FFFFFF;height:33px;">' +
                '<option value="6">Completed</option>' +
                '<option value="8">Cancelled</option>' +
                '</select>' +
                '<p class="recipt_modal_select_error error_clean"></p>' +
                "</td>" +
                "<td width='30'  style='text-align:center;'>" +
                "<input type='text' id='COS_entered_reason' name='item_code' placeholder = '' class='submitrecipt' style='width: 285px;height: 36px;'>" +
                "</td>" +
                "</tr>" +
                "</tbody>" +
                "</table>" +           
                "</div>";
  

      footer_data +=
                '<div class="row">' +
                '<div class="col-md-3" ></div>' +
                '<div class="col-md-1" ></div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-primary"  Style="width:85px;" onclick="channgeOrderStatus_submit()">Submit</button>' +
                '</div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-danger"  Style="width:85px;" data-dismiss="modal">Cancel</button>' +
                '</div>' +
                '</div>' +
                '</div>';

        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();

    }
    
    function selectstatustype() {
        var value = $('#COS_modal_select option:selected').val();
        //alert(value);
        $("#COS_modal_select_value").val(value);
    }
    
     function channgeOrderStatus_submit() {
        var changedOStatus = $("#COS_modal_select_value").val();
        var reason = $("#COS_entered_reason").val();
        var comment = "";
        if(reason === "" ){
            alert("Please enter reason");
            return false;
        }
        if(changedOStatus === "6" ){
            comment = "Manual Completion";
        }else{
            comment = "Manual Cancel";
        }
        
        var _data = {
                order_ids: [$("#COS_modal_order_id").val()],
                status: changedOStatus,
                reason:reason,
                comment:comment,
                role:sessionStorage.getItem('role_type'),
                actionById:sessionStorage.getItem('appadmin_dashboard_user_id'),
                actionByName:sessionStorage.getItem('appadmin_dashboard_user_name'),

                
          };
         console.log(_data);
         if(changedOStatus === "6" ){
            _ajaxEventHandler("channgeOrderStatusSubmit", _data, commonSuccessResponse);
        }else{
            _ajaxEventHandler("channgeOrderStatusSubmit", _data,cancelOrderResponse);
        }
         
        
       

    }
    
    function cancelOrderResponse(response){
        console.log(response);
        if (typeof response == 'string') {
	     response = JSON.parse(response);
	} else {
             response = response;	
	}
        if(response.status == 1 || response.status == "1"){
            alert(response.msg[0].chiss_response[0].message);
            window.location.reload();
        }else{
              alert(response.msg[0].chiss_response[0].message);
            
        }
            $('.loading').hide();
            //$("#commonModal").modal("hide");
    }
    
     //for print document
    function printReportsModal(OrderID, ServicetypeID, ServicesubtypeID, MRN, BusinessName) {
        $('.loading').show();
        _ajaxEventHandler("printReportsValidation", {orderid: OrderID, servicetypeid: ServicetypeID, servicesubtypeid: ServicesubtypeID, mrn: MRN, businessname: BusinessName}, resposeOf_print_document);
    }

    //response of  printdocument popup   
    function resposeOf_print_document(response) {
        console.log(response);
        documentdetails = JSON.parse(response);
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        if (documentdetails.status === "1") {
            header_data +=
                    "<div class='modal-header' style='background-color:#7bae4d; color:#fff;'>" +
                    "<button type='button' class='close' data-dismiss='modal'>&times;</button>" +
                    "<h4 class='modal-title'>Print Reports</h4>" +
                    "</div>";

            body_data +=
                    "<div class='modal-body'>" +
                    "<input type='hidden' name='order_id' id='order_id' value=''>" +
                    "<input type='hidden' name='mrn' id='mrn' value=''>" +
                    "<div class='container-fluid'>" +
                    "<div class='row'>" +
                    "<b><h4>" + documentdetails.businessname + "</h4></b>" +
                    "</div>";
            if (documentdetails.servicetypeid === "1") {
                body_data += "<div class='row'>" +
                        "<div class='col-md-4'>" +
                        "<span>Note Print</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>admin/print_CommonPrescriptionDocument/" + documentdetails.orderid + "/" + documentdetails.businessname + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>";
                
            } else if (documentdetails.servicetypeid === "2") {
                if (documentdetails.servicecubtypeid === "Via Consultation") {
                    body_data += "<div class='row'>" +
                            "<div class='col-md-4'>" +
                            "<span>Print Prescription</span>" +
                            "</div>" +
                            "<div class='col-md-4'>" +
                            "<a class='btn btn-default active'  href='<?php echo base_url(); ?>admin/print_CommonPrescriptionDocument/" + documentdetails.orderid + "/" + documentdetails.businessname + "''>" +
                            "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                            "</a>" +
                            "</div>" +
                            "</div>";
                }
                body_data += "<div class='row' style='margin-top:10px;'>" +
                        "<div class='col-md-4'>" +
                        "<span>Drug Request</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>admin/print_CommonInvoiceDocument/" + documentdetails.orderid + "/" + documentdetails.businessname + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>";
            } else if (documentdetails.servicetypeid === "5") {
                body_data += "<div class='row'>" +
                        "<div class='col-md-4'>" +
                        "<span>Note Print</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>admin/print_CommonPrescriptionDocument/" + documentdetails.orderid + "/" + documentdetails.businessname + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>" +
                        "<div class='row' style='margin-top:10px;'>" +
                        "<div class='col-md-4'>" +
                        "<span>Home Care Bill</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>admin/print_CommonInvoiceDocument/" + documentdetails.orderid + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>";
            } else if (documentdetails.servicetypeid === "30") {
                body_data += "<div class='row'>" +
                        "<div class='col-md-4'>" +
                        "<span>Note Print</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active'  href='<?php echo base_url(); ?>admin/print_CommonPrescriptionDocument/" + documentdetails.orderid + "/" + documentdetails.businessname + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>" +
                        "<div class='row' style='margin-top:10px;'>" +
                        "<div class='col-md-4'>";
                if (documentdetails.servicecubtypeid === "103" || documentdetails.servicecubtypeid === "201") {
                    body_data += "<span> Print Invoice</span>";
                } else {
                    body_data += "<span>Home Care Bill</span>";
                }
                body_data += "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>admin/print_CommonInvoiceDocument/" + documentdetails.orderid + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>";
            } else if (documentdetails.servicetypeid === "4") {
                body_data += "<div class='row'>" +
                        "<div class='col-md-4'>" +
                        "<span> Print Prescription</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>admin/print_CommonPrescriptionDocument/" + documentdetails.orderid + "/" + documentdetails.businessname + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>" +
                        "<div class='row' style='margin-top:10px;'>" +
                        "<div class='col-md-4'>" +
                        "<span> Print Invoice</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>admin/print_CommonInvoiceDocument/" + documentdetails.orderid + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>";


            } else {
                body_data += "<div class='row'>" +
                        "<div class='col-md-4'>" +
                        "<span> Print Prescription</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>admin/print_CommonPrescriptionDocument/" + documentdetails.orderid + "/" + documentdetails.businessname + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>" +
                        "<div class='row' style='margin-top:10px;'>" +
                        "<div class='col-md-4'>" +
                        "<span> Print Invoice</span>" +
                        "</div>" +
                        "<div class='col-md-4'>" +
                        "<a class='btn btn-default active' href='<?php echo base_url(); ?>admin/print_CommonInvoiceDocument/" + documentdetails.orderid + "'>" +
                        "<span class='glyphicon glyphicon-print glyphicon'></span>" +
                        "</a>" +
                        "</div>" +
                        "</div>";
            }

            "</div>" +
                    "</div>";

        } else {
            header_data +=
                    "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                    "<button type='button' class='close' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                    " <h5 class='modal-title' id='recieptdetails' style='margin:0;line-height: 1.428571;'>" +
                    "<font style='color:red;font-size:25px;'>Document  details not found</font>+"
            "</h5>" +
                    " </div>";
        }

        footer_data+= '<button type="button" class="btn btn-default close_model" data-dismiss="modal">Close</button>';
        
        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();
    }
    
    $("#changelatlongpincode_button").click(function (e) {
        e.preventDefault();
        var orderIDs = [];
        $("input:checkbox:checked").map(function () {
            orderIDs.push($(this).val());
        });
        //alert(orderIDs);
        console.log(orderIDs);
       // return;
       changeLatLongPincode_modal(orderIDs);
      //  $('.loading').show();
       
    });
   
   
   function changeLatLongPincode_modal(orderIDs) {
        if(orderIDs == ""){
            alert("please select atleast one order");return;
        }
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        var receiptData = "";
     
        
        header_data +=
                "<style>.error_clean{font-size: 12px;color: red;margin : 0px;}</style>" +
                "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                "<button type='button' class='close close_model' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                "<h3 class='modal-title' style='width:300px;' id='myModalLabel'>Change Lat,Long,Pincode</h3>" +
                " </div>";
        body_data +=
                "<div class='modal-body' >" +
                "<div class='row'>" +
                "<div class='col-xs-12'>" +
                "<div class='orderdata' >" +
                "<div class='col-md-12' id='JS_main_content_scroll' style='overflow:auto; height:350px;padding:0;'>" +
               '<input type="hidden" id="change_latlongpincode_orderids" name="item_code" value="'+orderIDs+'">' +
               '<span style="color:#337ab7;font-size: 130%;">We are updating lat,long,pincode for orders : '+orderIDs+' </span><br><br><br>'+
                "<ul class='nav navbar-nav symptoms' style='width:100%;'>" +
                "<li class='col-xs-12 active'>" +
                "<table class='table table-striped table-bordered table-hover'>" +
                "<thead>" +
                "<tr>" +
                "<th width='30'  style='text-align:center;'>Latitude</th>" +
                "<th width='30'  style='text-align:center;'>Longtitude</th>" +
                "<th width='30'  style='text-align:center;'>Pincode</th>" +
                "<th width='30'  style='text-align:center;'>Reason</th>" +
                "</tr>" +
                "</thead>" +
                "<tbody class='doctors-available'>" +
                "<tr>" +
                "<td width='30'  style='text-align:center;'>" +
                "<input type='text' id='new_latitude'  name='item_code' class='submitrecipt' style='width: 150px;height: 36px;'>" +
                "</td>" +
                "<td width='30'  style='text-align:center;'>" +
                "<input type='text' id='new_longtitude'  name='item_code' class='submitrecipt' style='width: 150px;height: 36px;'>" +
                "</td>" +
                "<td width='30'  style='text-align:center;'>" +
                "<input type='text' id='new_pincode' name='item_code' class='submitrecipt' style='width: 150px;height: 36px;'>" +
                "</td>" +
                "<td width='30'  style='text-align:center;'>" +
                "<input type='text' id='reason_for_changeLP' name='item_code' class='submitrecipt' style='width: 150px;height: 36px;'>" +
                "</td>" +
                "</tr>" +
                "</tbody>" +
                "</table>" +
              
                "</div>";

      footer_data +=
                '<div class="row">' +
                '<div class="col-md-3" ></div>' +
                '<div class="col-md-1" ></div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-primary"  Style="width:85px;" onclick="changeLatLongPincode_submit()">Submit</button>' +
                '</div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-danger"  Style="width:85px;" data-dismiss="modal">Cancel</button>' +
                '</div>' +
                '</div>' +
                '</div>';

        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();

    }
    
     function changeLatLongPincode_submit(){
        var orderIDs = $("#change_latlongpincode_orderids").val();
        var latitude = $("#new_latitude").val();
        var longtitude = $("#new_longtitude").val();
        var pincode = $("#new_pincode").val();
        var reason = $("#reason_for_changeLP").val();
        var ordreids = orderIDs.split(',').map(Number);
        if(latitude === ""  || longtitude === ""  || pincode === ""){
            alert("Please enter all the fields");
            return false;
        }
        var _data = {
                order_ids: ordreids,
                lat:latitude,
                long: longtitude,
                pincode: pincode,
                reason: reason,
                actionById:sessionStorage.getItem('appadmin_dashboard_user_id'),
                actionByName:sessionStorage.getItem('appadmin_dashboard_user_name'),

                
          };
         console.log(_data);
         _ajaxEventHandler("changeLatLongPincodesubmit", _data, commonSuccessResponse);
    }
    
    function viewLatLongPincode_modal(orderId,latitude,longitude,pincode) {
   
        var header_data = "";
        var body_data = "";
        var footer_data = "";
        var receiptData = "";
     
        
        header_data +=
                "<style>.error_clean{font-size: 12px;color: red;margin : 0px;}</style>" +
                "<div class='modal-header' style ='background-color:#7bae4d;color:#fff; border-bottom:none;'>" +
                "<button type='button' class='close close_model' style='cursor:hand;' data-dismiss='modal'>&times;</button>" +
                "<h3 class='modal-title' style='width:300px;' id='myModalLabel'>View Lat,Long,Pincode</h3>" +
                " </div>";
        body_data +=
                "<div class='modal-body' >" +
                "<div class='row'>" +
                "<div class='col-xs-12'>" +
                "<div class='orderdata' >" +
                "<div class='col-md-12' id='JS_main_content_scroll' style='overflow:auto; height:350px;padding:0;'>" +
               '<input type="hidden" id="change_latlongpincode_orderids" name="item_code" value="'+orderId+'">' +
               '<span style="color:#337ab7;font-size: 130%;">Latitude,Longitude and Pincode of Order : '+orderId+' Is Shown Below: </span><br><br><br>'+
                "<ul class='nav navbar-nav symptoms' style='width:100%;'>" +
                "<li class='col-xs-12 active'>" +
                "<table class='table table-striped table-bordered table-hover'>" +
                "<thead>" +
                "<tr>" +
                "<th width='30'  style='text-align:center;'>Latitude</th>" +
                "<th width='30'  style='text-align:center;'>Longtitude</th>" +
                "<th width='30'  style='text-align:center;'>Pincode</th>" +
                "</tr>" +
                "</thead>" +
                "<tbody class='doctors-available'>" +
                "<tr>" +
                "<td width='30'  style='text-align:center;'>" +
                "<input type='text' id='new_latitude'  name='item_code' value = "+latitude+" class='submitrecipt' style='width: 150px;height: 36px;' readonly>" +
                "</td>" +
                "<td width='30'  style='text-align:center;'>" +
                "<input type='text' id='new_longtitude'  name='item_code' value = "+longitude+" class='submitrecipt' style='width: 150px;height: 36px;' readonly>" +
                "</td>" +
                "<td width='30'  style='text-align:center;'>" +
                "<input type='text' id='new_pincode' name='item_code' value = "+pincode+" class='submitrecipt' style='width: 150px;height: 36px;' readonly>" +
                "</td>" +
                "</tr>" +
                "</tbody>" +
                "</table>" +
              
                "</div>";

      footer_data +=
                '<div class="row">' +
                '<div class="col-md-3" ></div>' +
                '<div class="col-md-1" ></div>' +
                '<div class="col-md-2" >' +
                '<button type="button" class="btn btn-danger"  Style="width:85px;" data-dismiss="modal">Close</button>' +
                '</div>' +
                '</div>' +
                '</div>';

        $("#modal_header").html(header_data);
        $("#modal_body").html(body_data);
        $("#modal_footer").html(footer_data);
        $("#commonModal").modal("show");
        $('.loading').hide();

    }
    
    function selectAll(){
    var selected=$('input[name="allorders_select"]:checked').val();
    if(selected){
        $('input[name="order_select"]').prop("checked", "checked");
    }else{
        $('input[name="order_select"]').prop("checked", false);
    }	
}

function uniqueselectAll(){
    var selected=$('input[name="order_select"]:checked').val();
    if(selected){
        $('input[name="allorders_select"]').prop("checked", false);
    }else{
       
    }	
}
    
</script>
</div>
</div>
</body>
</html>