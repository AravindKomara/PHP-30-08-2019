<style>
.pn-ProductNav {
    /* Make this scrollable when needed */
    overflow-x: auto;
    /* We don't want vertical scrolling */
    overflow-y: hidden;
    /* Make an auto-hiding scroller for the 3 people using a IE */
    -ms-overflow-style: -ms-autohiding-scrollbar;
    /* For WebKit implementations, provide inertia scrolling */
    -webkit-overflow-scrolling: touch;
    /* We don't want internal inline elements to wrap */
    white-space: nowrap;
    /* Remove the default scrollbar for WebKit implementations */
    &::-webkit-scrollbar {
        display: none;
    }
}
</style>
<div class="col-md-12">
   <div class="container-fluid push-bot">
      <div class="row">
        <div class="col-md-12">		
            <nav class="navbar navbar-default pn-ProductNav"> 
	       <div class="navbar-header">
		   <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
		     <span class="sr-only">Toggle navigation</span>
		     <span class="icon-bar"></span>
		     <span class="icon-bar"></span>
		     <span class="icon-bar"></span>
		 </button>     
	       </div>  
	        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <ul>
                      <li>
                          <button  class="<?php if($menu=="createreceipt"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>admin/createreceipt'">Create Receipt</button>								
		      </li>
                        
		      <li>
                          <button  class="<?php if($menu=="changeorderstatus"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>admin/changeorderstatus'">Change Order Status</button>
		      </li>
		
		      <li>
                          <button  class="<?php if($menu=="assignorder"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>admin/assignorder'">Assign An Order</button>
                      </li>
		
		      <li>
                          <button  class="<?php if($menu=="changescheduleddate"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>admin/changescheduleddate'">Change Scheduled Date</button>				
		      </li>
                       <li>
                          <button  class="<?php if($menu=="reports"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>admin/reports'">Reports</button>				
		      </li>
                      
                      <li>
                          <button  class="<?php if($menu=="changelatilongpincode"){echo "activemenu";}else{echo "inactivemenu";}?>" onclick="location.href='<?=base_url()?>admin/changelatilongpincode'">Change Lati/Long/Pincode</button>				
		      </li>
                        
		    
                          
		  </ul>
	     </div>  
        </nav>
   </div>	
</div>
</div>