<?php

include(APPPATH . 'controllers/ConfigAdmin.php');

class Admin extends ConfigAdmin {

    public function __construct() {
        parent::__construct();
        $this->load->library('pdf');
    }

    public function index() {
        $this->load->view('login');
    }
    
    public function appadminAuthentication(){
       $requestData = array(
            "officer_id" => $this->input->post('officer_id'),
            "password" =>  $this->input->post('password'));
        $url = serverhostpath . 'OMS/api/app_support_route.php/v1/login/appsupport';
        $header = array('Content-Type: application/json');
        $requestData = json_encode($requestData);
       // echo $url;print_r($requestData);exit;
        $data = $this->common_curl_call($url, $requestData, $header, "POST");
        $data = json_decode($data);
      // print_r($data);exit;
        if($data->status == 1 || $data->status == "1"){
            $officerdata = array(
                    'userid' => $data->data->user_id,
                    'username' => $data->data->name);
            $this->session->set_userdata('userinfo', $officerdata);
            $this->createreceipt();
        }else{
           $_SESSION['login_fail_msg']="Invalid User";
	   $this->index();
        }

    }
    
    public function logout() {
        $this->session->sess_destroy();
        $this->index();
    }


    public function citySearch(){
        $userinfo = $this->session->userdata('userinfo');
        $pagename = $this->input->post('pagename');
        $fromdatesearch = $this->input->post('fromdatesearch');
        $cityList = $this->input->post('cities');
        $this->updatesession($userinfo);
        $parameter = array(
                    "pagename" => $pagename,
                    "startDate" => date('Y-m-d', strtotime($this->input->post('fromDate'))),
                    "endDate" => date('Y-m-d', strtotime($this->input->post('toDate'))),
                    "cities" => $cityList
                );
        
        $data['from_dt'] = $this->input->post('fromDate');
        $data['to_dt'] = $this->input->post('toDate');
        if(!empty($fromdatesearch)){
           $parameter['startDate'] = date('Y-m-d', strtotime($this->input->post('fromdatesearch')));
           $data['from_dt'] =$this->input->post('fromdatesearch');
        }
       if(!empty($cityList)){       
           $data['cityList'] = $cityList;
        }else{
           $data['cityList'] = $this->getallcities();
        }
        $data["ordersList"] = $this->filterData($parameter);
       // print_r( $data["ordersList"]);exit;
        $data['menu'] = $pagename;
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();
        $data['search_txt'] = "";
        $data['search_type'] = 1;
        $menuData['menuList'] = $this->menuVisiblityValidation($userinfo);
       // print_r($data['popList']);exit;
        $this->load->view('header', $data);
        $this->load->view('menu', $menuData);
        $this->load->view($pagename);
        $this->load->view("footer");
 
     }

     public function trackorder() {
        if ($this->input->is_ajax_request()) {
            $orderid = $this->input->post('orderid');
            $parameter["status"] = "1";
            $parameter['order_id'] = $orderid;
            $url = serverhostpath . "OMS/api/operation.php/v1/ordertrack";
            $header = array('Content-Type: application/json');
            $param = json_encode($parameter);
            $data = $this->common_curl_call($url, $param, $header, "post");
            echo $data;
        } else {
            $data = array("status" => "0", "message" => "Order tracking details are not avaliable");
            echo json_encode($data);
        }
    }

    public function getorderinformation() {
        $data = array("status" => "0", "data" => array());
        $userinfo = $this->session->userdata('userinfo');
        
            $orderid = $this->input->post("order_id");
            $data["status"] = "1";
            $data["data"] = $this->filterData(array("order_id" => $orderid));
           // print_r($data);exit;
            echo json_encode($data);
        
    }
    
    

    public function createreceipt() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "createreceipt");
        $userinfo = $this->session->userdata('userinfo');
       if (!empty($userinfo['userid'])) {
       if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            if(empty($this->input->post('fromdate')) && empty($this->input->post('todate'))){
                $fromdate = date('Y-m-d', strtotime(date('Y-m-d')));
                $todate = date('Y-m-d', strtotime(date('Y-m-d')));
            }else{
                $fromdate =  date('Y-m-d', strtotime($this->input->post('fromdate')));
                $todate =  date('Y-m-d', strtotime($this->input->post('todate')));
            }
            
            $parameter["startDate"] = $fromdate;
            $parameter["endDate"] = $todate;
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            //print_r($parameter);exit;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] =$fromdate;
            $data['to_dt'] = $todate;
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            
        }
  
       
        $data['menu'] = "createreceipt";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();
        $data['cityList'] = $this->getallcities();
        $this->load->view('header', $data);
        $this->load->view('menu');
        $this->load->view('createreceipt');
        $this->load->view("footer");
    }else{
       $this->index(); 
    }
    }
    
    public function changeorderstatus() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "changeorderstatus");
        $userinfo = $this->session->userdata('userinfo');
        if (!empty($userinfo['userid'])) {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            //print_r($parameter);exit;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        //print_r($parameter);exit;
        $data['menu'] = "changeorderstatus";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();
        $data['cityList'] = $this->getallcities();
        $this->load->view('header', $data);
        $this->load->view('menu');
        $this->load->view('changeorderstatus');
        $this->load->view("footer");
    }else{
       $this->index(); 
    }
  }
    
    public function assignorder() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "assignorder");
        $userinfo = $this->session->userdata('userinfo');
        if (!empty($userinfo['userid'])) {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            //print_r($parameter);exit;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        //print_r($parameter);exit;
        $data['menu'] = "assignorder";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();

        $data['cityList'] = $this->getallcities();
        $this->load->view('header', $data);
        $this->load->view('menu');
        $this->load->view('assignorder');
        $this->load->view("footer");
    }else{
       $this->index(); 
    }
    }
    
    public function changescheduleddate() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "changescheduleddate");
        $userinfo = $this->session->userdata('userinfo');
        if (!empty($userinfo['userid'])) {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            //print_r($parameter);exit;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        //print_r($parameter);exit;
        $data['menu'] = "changescheduleddate";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();

        $data['cityList'] = $this->getallcities();
        $this->load->view('header', $data);
        $this->load->view('menu');
        $this->load->view('changescheduleddate');
        $this->load->view("footer");
    }else{
       $this->index(); 
    }
    }
    
    public function reports() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "reports");
        $userinfo = $this->session->userdata('userinfo');
        if (!empty($userinfo['userid'])) {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            //print_r($parameter);exit;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        //print_r($parameter);exit;
        $data['menu'] = "reports";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();

        $data['cityList'] = $this->getallcities();
        $this->load->view('header', $data);
        $this->load->view('menu');
        $this->load->view('reports');
        $this->load->view("footer");
    }else{
       $this->index(); 
    }
    }
    
    public function changelatilongpincode() {
        date_default_timezone_set("Asia/Kolkata");
        $parameter = array("pagename" => "changelatilongpincode");
        $userinfo = $this->session->userdata('userinfo');
        if (!empty($userinfo['userid'])) {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $search_type = $this->input->post('searchdropdown');
            $search_text = $this->input->post('searchtext');
            $parameter["startDate"] = date('Y-m-d', strtotime($this->input->post('fromdate')));
            $parameter["endDate"] = date('Y-m-d', strtotime($this->input->post('todate')));
            $parameter["search_txt"] = $search_text;
            $parameter["search_type"] = $search_type;
            //print_r($parameter);exit;
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = $search_text;
            $data['search_type'] = $search_type;
            $data['from_dt'] = $this->input->post('fromdate');
            $data['to_dt'] = $this->input->post('todate');
        } else {
            $data["ordersList"] = $this->filterData($parameter);
            $data['search_txt'] = "";
            $data['search_type'] = 1;
            $data['from_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
            $data['to_dt'] = date('d-m-Y', strtotime(date('Y-m-d')));
        }
        //print_r($parameter);exit;
        $data['menu'] = "changelatilongpincode";
        $data['sessiondata'] = $this->session->userdata('userinfo');
        $data['business_name'] = $this->business_name();

        $data['cityList'] = $this->getallcities();
        $this->load->view('header', $data);
        $this->load->view('menu');
        $this->load->view('changelatilongpincode');
        $this->load->view("footer");
    }else{
       $this->index(); 
    }
    }
    
    public function generateReciptSubmit() {
        $requestData = array(
            "order_id" => (int)$this->input->post('order_id'),
            "paymentmode" =>  $this->input->post('paymentmode'),
            "referencenumber" => $this->input->post('referencenumber'),
            "reason" => $this->input->post('reason'),
            "receiptamount" => (int) $this->input->post('reciptamount'),
            "actionById" => $this->input->post('actionById'),
            "actionByName" => $this->input->post('actionByName')
            
        );
        $url = serveruatv3path . 'OMS/api/operation.php/v1/generateReceipt';
        $header = array('Content-Type: application/json');
        $requestData = json_encode($requestData);
        //echo $url;print_r($requestData);exit;
        $data = $this->common_curl_call($url, $requestData, $header, "POST");
        echo $data;
    }
    
    public function changeScheduledDatesubmit() {
        $orderIds=array_map(function ($v) {return (int)$v;},$this->input->post('order_ids'));
        $scheduled_date =  date("Y-m-d",strtotime($this->input->post('new_scheduled_date')))." ". date("G:i:s", strtotime($this->input->post('new_scheduled_time')));
        $requestData = array(
            "order_ids" =>$orderIds,
            "new_scheduled_date" =>$scheduled_date ,
            "reason" => $this->input->post('reason'),
            "actionById" => $this->input->post('actionById'),
            "actionByName" => $this->input->post('actionByName')
            
        );
        $url = serverhostpath . 'OMS/api/operation.php/v1/schedule/date/update';
        $header = array('Content-Type: application/json');
        $requestData = json_encode($requestData);
       // echo $url;print_r($requestData);exit;
        $data = $this->common_curl_call($url, $requestData, $header, "POST");
        echo $data;
    }
    
    public function channgeOrderStatusSubmit() {
        $url="";
        $ostatus = $this->input->post('status');
        $requestData = array(
            "order_ids" => $this->input->post('order_ids'),
            "status" =>  $this->input->post('status'),
            "reason" => $this->input->post('reason'),
            "comment" => $this->input->post('comment'),
            "role" => $this->input->post('role'),
            "actionById" => $this->input->post('actionById'),
            "actionByName" => $this->input->post('actionByName')
            
        );
        if($ostatus == "6"){
            $url = serverhostpath . 'OMS/api/operation.php/v1/orders/complete/manually';
        }else{
            $url = serverhostpath . 'OMS/api/operation.php/v1/orders/cancel/manually';
        }
        
        $header = array('Content-Type: application/json');
        $requestData = json_encode($requestData);
        //echo $url;print_r($requestData);exit;
        $data = $this->common_curl_call($url, $requestData, $header, "POST");
        echo $data;
    }
    
    public function getOfficers_list() {
        $order_id = $this->input->post('order_id');
        $scheduled_date = $this->input->post('scheduled_date');
        $workorder_id = $this->input->post('workorder_id');
        // $associate_id = $this->input->post('associate_id');
        // $branch_id = $this->input->post('branch_id');
        $roleType = $this->input->post('roletype');
        $filter = array(
            "scheduled_date" => $scheduled_date,
            "order_id" => $order_id,
            "roleType" => $roleType
        );

        $url = serverhostpath . "OMS/api/operation.php/v1/fetch_officers";
        $param = json_encode($filter);
        $header = array('Content-Type: application/json');
        $data = $this->common_curl_call($url, $param, $header, "post");
        //print_r($order_id);exit;
        $data = json_decode($data);
        $data->orderid = $order_id;
        //print_r($data->orderid);exit;
        $data->orderid = $order_id;
        $data->scheduled_date = $scheduled_date;
        $data->workorder_id = $workorder_id;  
        echo json_encode($data);exit;
    }
    
     public function printReportsValidation() {
        if ($this->input->is_ajax_request()) {
            $orderid = $this->input->post('orderid');
            $servicetypeid = $this->input->post('servicetypeid');
            $servicesubtypeid = $this->input->post('servicesubtypeid');
            $mrn = $this->input->post('mrn');
            $businessname = $this->input->post('businessname');
            $data["status"] = "1";
            $data['orderid'] = $orderid;
            $data['servicetypeid'] = $servicetypeid;
            $data['servicecubtypeid'] = $servicesubtypeid;
            $data['mrn'] = $mrn;
            $data['businessname'] = $businessname;
            echo json_encode($data);
        } else {
            $data = array("status" => "0", "message" => "no documents");
            echo json_encode($data);
        }
    }
    
     //for invoice,homecare, drug bill print
    public function print_CommonInvoiceDocument() {
        $order_id = $this->uri->segment('3');
        $url = serverhostpath . "OMS/api/operation.php/v1/invoice?OrderID=$order_id";
        $data = $this->common_curl_call($url, "", "", "get"); //get method curl call
        //for downloading PDF file
        header('Cache-Control: public');
        header('Content-type: application/pdf');
        header('Content-Disposition: attachment; filename="invoice_' . $order_id . '.pdf"');
        header('Content-Length: ' . strlen($data));
        echo $data;
    }

    //for prescription,care@home, assement order bill
    public function print_CommonPrescriptionDocument() {
        $order_id = $this->uri->segment('3');
        $url = serverhostpath . "OMS/api/operation.php/v1/prescriptionprint?OrderID=$order_id";
        $data = $this->common_curl_call($url, "", "", "get"); //get method curl call 
        header('Cache-Control: public');
        header('Content-type: application/pdf');
        header('Content-Disposition: attachment; filename="Prescription_' . $order_id . '.pdf"');
        header('Content-Length: ' . strlen($data));
        echo $data;

    }
 
    public function changeLatLongPincodesubmit() {
        $orderIds=array_map(function ($v) {return (int)$v;},$this->input->post('order_ids'));
        $requestData = array(
            "order_ids" =>$orderIds,
            "lat" =>  $this->input->post('lat'),
            "long" =>  $this->input->post('long'),
            "pincode" =>  $this->input->post('pincode'),
            "reason" => $this->input->post('reason'),
            "actionById" => $this->input->post('actionById'),
            "actionByName" => $this->input->post('actionByName')
            
        );
        $url = serverhostpath . 'OMS/api/operation.php/v1/update/la/lo/pincode';
        $header = array('Content-Type: application/json');
        $requestData = json_encode($requestData);
        //echo $url;print_r($requestData);exit;
        $data = $this->common_curl_call($url, $requestData, $header, "POST");
        echo $data;
    }

    
     
     
     
    
}
