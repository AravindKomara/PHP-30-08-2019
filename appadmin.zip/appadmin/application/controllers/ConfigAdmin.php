<?php

class ConfigAdmin extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function filterData($parameter) {
        //print_r($parameter);exit;
        $userinfo = $this->session->userdata('userinfo');
        $filterorderstatus = $this->mappingOrderStatuses();
       // print_r($filterorderstatus);exit;
        
            $filter = array("dateFilter" => "scheduled_date");
            date_default_timezone_set("Asia/Kolkata");
            $url = serverhostpath . "OMS/api/operation.php/v1/orders";
            if (isset($parameter["order_id"]) && $parameter["order_id"] != "") {
                $filter = array("order_id" => $parameter["order_id"]);
            } else {
                if (!isset($parameter['startDate'])) {
                    $filter['startDate'] = date("Y-m-d");
                    $filter['endDate'] = date("Y-m-d");
                } else {
                    $filter['startDate'] = $parameter["startDate"];
                    $filter['endDate'] = $parameter["endDate"];
                }
	
                if (isset($userinfo["popId"]) && $userinfo["popId"] != "0") {
                    $filter["facilityId"] = array($userinfo["popId"]);
                }

                if (isset($parameter["search_txt"])) {
                    if ($parameter["search_type"] == 1 && trim($parameter["search_txt"]) != "") {
                        $filter = array('order_did' => $parameter["search_txt"]);
                    } elseif ($parameter["search_type"] == 2 && trim($parameter["search_txt"]) != "") {
                        $filter = array('workorder_did' => $parameter["search_txt"]);
                    } elseif ($parameter["search_type"] == 4 && trim($parameter["search_txt"]) != "") {
                        $filter = array('officerId' => array($parameter["search_txt"]));
                    } elseif ($parameter["search_type"] == 5 && trim($parameter["search_txt"]) != "") {
                        $filter = array('mrn' => $parameter["search_txt"]);
                    }
                }
                
                //for getting cities
                 if (isset($parameter["cities"])) {
                     $filter["city"] = $parameter["cities"];
                 }

                if ($parameter["pagename"] == "createreceipt") {
                    $filter["orderStatus"] = $filterorderstatus[$parameter["pagename"]]['filterstatues'];
                   // print_r($filter["orderStatus"]);exit;
                } else if ($parameter["pagename"] == "changeorderstatus") {
                    $filter["orderStatus"] = $filterorderstatus[$parameter["pagename"]]['filterstatues'];
                } else if ($parameter["pagename"] == "assignorder") {
                    $filter["orderStatus"] = $filterorderstatus[$parameter["pagename"]]['filterstatues'];
                } else if ($parameter["pagename"] == "changescheduleddate") {
                    $filter["orderStatus"] = $filterorderstatus[$parameter["pagename"]]['filterstatues'];
                } else if ($parameter["pagename"] == "reports") {
                } 
                else if ($parameter["pagename"] == "changelatilongpincode") {
                }
            }

            
            $filter['sortBy'] = "desc";
            $param = json_encode($filter);
            //echo $url;print_r($param);exit;		
            $header = array('Content-Type: application/json');
            $data = $this->common_curl_call($url, $param, $header, "post");
            //print_r($data);exit;
            return json_decode($data);
        
    }

    public function validate_the_request($roletype, $parameters) {
        if ($roletype == "superadmin") {
            $url = securl . "/api/validateSessionKey";
            $header = array('x-session-key:' . $parameters);
            $resultpckg = $this->common_curl_call($url, "", $header, "post");
            $resultpckg = json_decode($resultpckg);
            $set = 0;
            if ($resultpckg->status == "1") {
                if (isset($resultpckg->officer->accessRoles)) {
                    foreach ($resultpckg->officer->accessRoles as $role) {
                        if ($role == 'escalation_dashboard_viewer') {
                            $set = 1;
                        }
                    }
                }
            }
            if ($set == 1) {
                $data = array(
                    'session_id' => $resultpckg->sessionKey,
                    'userid' => $resultpckg->officer->officerId,
                    'username' => ($resultpckg->officer->fname . " " . $resultpckg->officer->lname),
                    'parent_userid' => $resultpckg->officer->officerId,
                    'parent_username' => ($resultpckg->officer->fname . " " . $resultpckg->officer->lname),
                    'email' => $resultpckg->officer->email,
                    'type' => $roletype,
                    'admin_type' => "superadmin",
                    'popId' => "0"
                );
                $this->session->set_userdata('userinfo', $data);
                return "1";
            } else {
                return "0";
            }
        } else if ($roletype == "associate_admin") {
            $url = serverhostpath . "aravind/OMS/api/rtct.php/v1/gettokendata";
            $param = json_encode(array("token" => $parameters));
            $header = array('Content-Type: application/json');
            $resultpckg = $this->common_curl_call($url, $param, $header, "post");
            //print_r($resultpckg); exit;
            $resultpckg = json_decode($resultpckg);
            if ($resultpckg->status == "1") {
                if (isset($resultpckg->branch_id)) {
                    $data = array(
                        'session_id' => $resultpckg->session,
                        'userid' => $resultpckg->branch_id,
                        'username' => $resultpckg->branch_name,
                        'parent_userid' => $resultpckg->associate_id,
                        'parent_username' => $resultpckg->associate_name,
                        'type' => "branch_admin",
                        'admin_type' => "associate_admin",
                        'popId' => "0"
                    );
                } else {
                    $data = array(
                        'session_id' => $resultpckg->session,
                        'userid' => "",
                        'username' => $resultpckg->branch_name,
                        'parent_userid' => $resultpckg->associate_id,
                        'parent_username' => $resultpckg->associate_name,
                        'type' => $roletype,
                        'admin_type' => "associate_admin",
                        'popId' => "0"
                    );
                }

                $this->session->set_userdata('userinfo', $data);
                return "1";
            } else {
                return "0";
            }
        }
    }

    //common curl call
    public function common_curl_call($url, $param, $header, $method) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        if ($param != "") {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
        }
        if ($method == "post") {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        } else {
            curl_setopt($ch, CURLOPT_HTTPHEADER, array());
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $resultcurl = curl_exec($ch);
        curl_close($ch);
        return $resultcurl;
    }

    

    public function business_name() {
        $business_name = array(
            "1" => "Doctor Consultation",
            "2" => "Medicines",
            "3" => "Diagnostics",
            "4" => "Facilitation",
            "5" => "Care at Home",
            "6" => "Nursing",
            "7" => "Physiotherapy",
            "8" => "Bedside Attendant",
            "9" => "Speciality",
            "10" => "Doctor",
            "11" => "Equipment Rental",
            "12" => "Emotional Wellbeing",
            "13" => "Second Opinion",
            "14" => "Wellness",
            "15" => "Family Doctor",
            "16" => "Extended Services(blood bank)",
            "100" => "Package"
        );
        return $business_name;
    }
    
    public function mappingOrderStatuses() {
        $mappingorderstatuses = [
            "createreceipt" => [
                "filterstatues" => [5,6,7,102,101],            
            ],
            "assignorder" => [
                "filterstatues" => [1,2,3,4,5,7,26],            
            ],
            "changeorderstatus" => [
                "filterstatues" => [0,1,2,3,4,5,7,9,25,26,102,101],            
            ],
            "changescheduleddate" => [
                "filterstatues" => [0,1,2,3,4,5,7,9,25,26,102,101],            
            ]
                            
        ];
        
        return $mappingorderstatuses;
    }
    
   

    public function getallpop() {
        $url = serverhostpath . 'OrderManagementRestServices/index.php/v1/getPOPList';
        $header = array('Content-Type: application/json');
        $reqparmt = json_encode(array('facility_id' => "-1"));
        $resultpckg = $this->common_curl_call($url, $reqparmt, $header, "post");
        $resultpckg = json_decode($resultpckg);
        //print_r($resultpckg->itemlist);exit;
        if (!empty($resultpckg)) {
            return $resultpckg->itemlist;
        } else {
            return "";
        }
    }
    
    //getting all cities list
    public function getallcities() {
        $url = serverhostpath . 'OMS/api/operation.php/v1/unique';
        $header = array('Content-Type: application/json');
        $reqparmt = json_encode(array('searchBy' => "city"));
        $resultpckg = $this->common_curl_call($url, $reqparmt, $header, "post");
        $resultpckg = json_decode($resultpckg);
       // print_r($resultpckg);exit;
        if (!empty($resultpckg)) {
            return $resultpckg;
        } else {
            return "";
        }
    }

    public function updatesession($sessiondata) {
        //print_r($sessiondata['admin_type']);exit;
        if ($sessiondata['admin_type'] == "superadmin") {
            $sessiondata['type'] = $sessiondata['admin_type'];
        } else if ($sessiondata['admin_type'] == "associate_admin") {
            $sessiondata['type'] = $sessiondata['admin_type'];
        }
        $this->session->set_userdata('userinfo', $sessiondata);  //updating session information
    }

    public function resetthesession() {
        $userinfo = $this->session->userdata('userinfo');
        $userinfo['popId'] = $this->input->post("popid");
        $this->session->set_userdata('userinfo', $userinfo);
    }

    

}

?>