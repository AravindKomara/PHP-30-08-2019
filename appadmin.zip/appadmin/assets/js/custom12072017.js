$(document).ready(function () {
	$('.loading').hide();
	
	$('input#receipt_id').change(function(){
		 if($(this).is(':checked')) {
			coll_amt = parseInt($(this).attr("data-collectamt"));
			total_sel_amount = parseInt($.trim($('#total_sel_amount').text()));
			$('#total_sel_amount').text(total_sel_amount+coll_amt);
		} else {
			coll_amt = parseInt($(this).attr("data-collectamt"));
			total_sel_amount = parseInt($.trim($('#total_sel_amount').text()));
			$('#total_sel_amount').text(total_sel_amount-coll_amt);			
		}
		if(parseInt($.trim($('#total_sel_amount').text())) > 0){
			$('#payment_sub').removeAttr('disabled');
		}
		else if(parseInt($.trim($('#total_sel_amount').text())) == 0){
			$('#payment_sub').attr('disabled', 'disabled');
		}
	});
});

	
 $(function(){        
    $(".datepick").datepicker({
            format: 'dd-mm-yyyy',
			 orientation: "top",
             autoclose: true,
             //endDate: new Date()
             
    }).on('changeDate', function(selected){ 
		var date = new Date(selected['date']);
		var month =date.getMonth()+1;
		var finaldate = date.getDate()+"-"+month+"-"+date.getFullYear();
		console.log(finaldate);
        $(this).prev('input').val(finaldate);
   });  
});

function getuserlist(){
	$('#assigndoc').html('Assign To MHO');
	if($( "#poplist" ).hasClass( "active" )){$( "#poplist" ).removeClass( "active" );}
	$( "#userlist" ).addClass( "active" );
	$('.loading').show();
	$.ajax({
			type: "POST",
			url: "getUserLists",
			data: {},
			success: function (result) {
			$('.loading').hide();					
			$('#family').html(result);
			}
	});
}

function getpoplist(){
	$('#assigndoc').html('Assign To POP');
	if($( "#userlist" ).hasClass( "active" )){$( "#userlist" ).removeClass( "active" );}
	$( "#poplist" ).addClass( "active" );
	$('.loading').show();
	$.ajax({
			type: "POST",
			url: "getPOPLists",
			data: {},
			success: function (result) {
			$('.loading').hide();					
			$('#family').html(result);
			}
	});
}

function getpatient(AssignedUserId,mhoname,cre_amt,skill_id){
	$("#AssignedUserId").val(AssignedUserId);	
	$("#mhoname").val(mhoname);	
	$("#cre_amt").val(cre_amt);
	$("#skill_id").val(skill_id); 
	$('.patientlist').removeClass("active");
	$("#"+AssignedUserId).addClass("active");
}
function getpatientpop(AssignedUserId,popname){
	$("#AssignedUserId").val(AssignedUserId);	
	$("#popname").val(popname);	
	$('.patientlist').removeClass("active");
	$("#"+AssignedUserId).addClass("active");
}


function checkavailability(){
	var checkboxes = document.getElementsByName('patient_list');
	var selected = new Array;
	for (var i=0; i<checkboxes.length; i++) {
		if (checkboxes[i].checked) {
			selected.push(checkboxes[i].value);
		}
	}
	
	if(selected.length > 0){				
		if ($('#mhoname').length)
		{
			var AssignedUserId=$("#AssignedUserId").attr("value");
			var mhoname=$("#mhoname").attr("value");
			var cre_amt=$("#cre_amt").attr("value");
			var skill_id=$("#skill_id").attr("value");
			
			if($("#AssignedUserId").val() != ""){
				$('.loading').show();
				
				$.ajax({
					type: "POST",
					url: "checkavailability",
					data: {selected:selected, AssignedUserId:AssignedUserId},
					success: function (result) {
						$('.loading').hide();						
						$('#apoordersdetails').html(result);
						$('#apoordersdetails').modal('show');						
						console.log(result);						
					}
				});
				
			}
			else{
				alert("Please select mho to assign");
			}
		}
	}
	else{
		alert("Please check atleast one workorder");
		return false;
	}
}

function assigndoc(){
	var checkboxes = document.getElementsByName('patient_list');
	var selected = new Array;
	for (var i=0; i<checkboxes.length; i++) {
		if (checkboxes[i].checked) {
			selected.push(checkboxes[i].value);
		}
	}
	
	if(selected.length > 0){				
		if ($('#mhoname').length)
		{
			var AssignedUserId=$("#AssignedUserId").attr("value");
			var mhoname=$("#mhoname").attr("value");
			var cre_amt=$("#cre_amt").attr("value");
			var skill_id=$("#skill_id").attr("value");
			
			if($("#AssignedUserId").val() != ""){
				$('.loading').show();				
				
				$.ajax({
					type: "POST",
					url: "assignWOtoMHO",
					data: {selected:selected, AssignedUserId:AssignedUserId, mhoname:mhoname,cre_amt:cre_amt,skill_id:skill_id},
					success: function (result) {						
						console.log(result);
						$('.loading').hide();	
						if(result == "success"){
							alert('Work order assigned successfully');
							console.log(result);
							location.reload(true);
						}else{
							alert(result);
							console.log(result);
						}
					}
				});
			}
			else{
				alert("Please select mho to assign");
			}
		}
		else if ($('#popname').length)
		{
			var popname=$("#popname").attr("value");
			if($("#AssignedUserId").val() != ""){
				var popname=$("#popname").attr("value");
				var AssignedUserId=$("#AssignedUserId").attr("value");
				$('.loading').show();
				$.ajax({
					type: "POST",
					url: "assignWOtoPOP",
					data: {selected:selected,AssignedUserId:AssignedUserId,popname:popname},
					success: function (result) {
						$('.loading').hide();
						location.reload(true);
					}
				});
			}
			else{
				alert("Please select pop to assign");
			}
		}
	}
	else{
		alert("Please check atleast one workorder");
		return false;
	}
}

function unassigndoc(){	
	var checkboxes = document.getElementsByName('patient_list');
	var selected = new Array;
	for (var i=0; i<checkboxes.length; i++) {
		if (checkboxes[i].checked) {
			selected.push(checkboxes[i].value);
		}
	}
	if(selected.length > 0){
		$('#unassignorder').modal('show');
	}else{
		alert("Please check atleast one workorder");
		return false;
	}
	
}

function reassigndoc(){
	var checkboxes = document.getElementsByName('patient_list');
	var selected = new Array;
	for (var i=0; i<checkboxes.length; i++) {
		if (checkboxes[i].checked) {
			selected.push(checkboxes[i].value);
		}
	}
	if(selected.length > 0){				
		if ($('#mhoname').length)
		{ 
			var AssignedUserId=$("#AssignedUserId").attr("value");
			var mhoname=$("#mhoname").attr("value");
			var remarksname=$("#remarksname").val();
			if(remarksname=="Select"){
				alert("Please select a Reason for Unassign");
				return false;
			}
			var remarksTestarea=$("#remarksTestarea").val();
			//if($("#AssignedUserId").val() != ""){
				$('.loading').show();
				$.ajax({
					type: "POST",
					url: "reassignWOtoMHO",
					data: {selected:selected, AssignedUserId:AssignedUserId, mhoname:mhoname,remarksname:remarksname,remarksTestarea:remarksTestarea},
					success: function (result) {						
						$('.loading').hide();
						console.log(result);
						alert('Work order Unassigned successfully.');
						location.reload(true); 
					}
				});
			//}
			//else{
			//	alert("Please select mho to assign");
			//}
		}
	}
	else{
		alert("Please check atleast one workorder");
		return false;
	}
}

function workorderdetails(OrderID,mrn,workorderid){
	$('.loading').show();
	$.ajax({
		type:"POST",
		url: "getWorkOrderDetails",
		data: {OrderID:OrderID,mrn:mrn,workorderid:workorderid},
		success : function(result){
			$('.loading').hide();
			$('#workorderdetails').html(result);
			$('#workorderdetails').modal('show');					
		}
	});
}

function orderdetails(OrderID,PatientId){			
	$('.loading').show();			
	$.ajax({
		type:"POST",
		url: "getOrderDetailsDiagHome",
		data: {OrderID:OrderID},
		success : function(result){
			$('.loading').hide();
			$('#orderdetails').html(result);
			$('#orderdetails').modal('show');					
		}
	});
}

function orderdetailsfacil(OrderID,PatientId){			
	$('.loading').show();			
	$.ajax({
		type:"POST",
		url: "getOrderDetailsDiagHomefacil",
		data: {OrderID:OrderID},
		success : function(result){
			$('.loading').hide();
			$('#orderdetails').html(result);
			$('#orderdetails').modal('show');					
		}
	});
}



function loadorderbypatient(order_id,PatientId,mrn){
	$('.loading').show();
	$.ajax({
		type:"POST",
		url: "getOrderDetailsPatient",
		data: {order_id:order_id,PatientId:PatientId,mrn:mrn},
		success : function(result){
			$('.loading').hide();
			$('#orderbypatientid').html(result);
			$('#orderbypatientid').modal('show');					
		}
	});
}

function loadaddressbypatient(order_id,PatientId,mrn){
	$('.loading').show();
	$.ajax({
		type:"POST",
		url: "getPatientAddressDetails",
		data: {order_id:order_id,PatientId:PatientId,mrn:mrn},
		success : function(result){
			$('.loading').hide();
			$('#addressbypatientid').html(result);
			$('#addressbypatientid').modal('show');					
		}
	});
}
function instruct(instruction)
{
	$('#trackresult').html("Instructions to be followed: "+instruction);
    $('#track').modal('show');
    $('#myModalLabel').html('Instruction');
}

function printdoc(order_id,mrn,service_type,service_type_id,servicecubtypeid,service_subtype){
	$('.loading').show();
	$.ajax({
		type:"POST",
		url: "printdoc",
		data: {order_id:order_id,mrn:mrn,service_type:service_type,service_type_id:service_type_id,servicecubtypeid:servicecubtypeid,service_subtype:service_subtype},
		success : function(result){
			$('.loading').hide();
			$('#printdoc').html(result);
			$('#printdoc').modal('show');					
		}
	});
}

function paymentcollected(rid, pc, wid, mrn, order_id, collamt){
	$('.loading').show();
	$.ajax({
			type: "POST",
			url: "../paymentcollected",
			data: {rid:rid, pc:pc, wid:wid, mrn:mrn, order_id:order_id, collamt:collamt},
			success: function (result) {				
				location.reload(true);
				$('.loading').hide();
			}
	});
}

function paymentreceivebypop(ser_type, order_id, woorder_id){
	var checkboxes = document.getElementsByName('receipt_id');
	var selected = new Array;
	for (var i=0; i<checkboxes.length; i++) {
		if (checkboxes[i].checked) {
			selected.push(checkboxes[i].value);
		}
	}
	console.log(selected);
	if(selected.length > 0){
		$('.loading').show();
		$.ajax({
			type: "POST",
			url: "paymentToPOP",
			data: {selected:selected},
			success: function (result) {
				$('.loading').hide();
				alert('Payment received');
				location.reload(true);
			}
		});
	}
	else{
		alert("Please check atleast one workorder");
		return false;
	}
}

function trackorder(order_id,order_date,mrn){
	//alert(mrn);
	if(mrn=="" || order_id==""){
		alert("Please Select the Correct Order");
	}else {
		$('.loading').show();
		$.ajax({type: "POST", url: "trackOrder", data:{mrn:mrn,order_id:order_id,order_date:order_date},
			success: function(result){
				console.log(result);
				$('#trackresult').html(result);
				$('#track').modal('show');
				//$("#mainreplacecontent").html(result);
			}
		});
	}
	$('.loading').hide();
}

