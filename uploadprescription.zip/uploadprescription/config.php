<?php 
$serverhostpath = "http://172.26.7.111/OMS/api/";
$max_file_uploads = 5 ;
?>


