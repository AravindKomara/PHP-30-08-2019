<?php 
require('../config/db.php');
//var_dump(IMAGE_EXTNS);
$ext = strtolower(pathinfo($_FILES["prescri_image"]["name"][0], PATHINFO_EXTENSION));
    if(empty($_FILES["prescri_image"]["name"][0])){
        $errMessage .= '<li>Please upload the  Prescription image</li>';
    } elseif (!in_array($ext, IMAGE_EXTNS)) {
        $errMessage .= '<li>Please upload Prescription image in "jpg|jpeg|gif|png|bmp|pdf" format only.</li>';
    }else if($_FILES["prescri_image"]['error'][0]){
		
		 $errMessage .= '<li>Please upload Prescription image Less than 2 MB size only.</li>';
	}
	
	
    if (!empty($errMessage)) {
        echo  "<h1 style='color:red'>".$errMessage ."</h1>"; exit;
    }

	$getvars = getStaticvariables();
    //$target_dir = "/var/www/html/medpharmacy/prescription/";
    $target_dir = $_SERVER['DOCUMENT_ROOT']."/medpharmacy/prescription/";
    $target_url = $getvars['serverurl']."/medpharmacy/prescription/";
	
	$length=count($_FILES["prescri_image"]["name"]);
	$pre_name=array();
	for ($i = 0; $i < $length; $i++) {
	  

	$target_file = $target_dir . basename($_FILES["prescri_image"]["name"][$i]);

	$pre_name[]=$target_url.$_FILES["prescri_image"]["name"][$i];
	$uploadOk = 1;
	$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
	// Check if image file is a actual image or fake image

	//echo target_file;

		$imgaresult=move_uploaded_file($_FILES["prescri_image"]["tmp_name"][$i], $target_file);
	}	
	$db = getDBmasters();
	$collection = $db->orders;	
	$where = array("_id"=>(int)$_POST['omorderid']);
	$filter=array('$push'=>array('order.prescription_file'=>$pre_name),'$set'=>array('order.patientinfo.prescription_later'=>'0','order.patientinfo.last_prescription_uploaded_byid'=>'Customer','order.patientinfo.last_prescription_uploaded_byname'=>'Customer','order.patientinfo.last_prescription_uploaded_Date'=>date("Y-m-d")."T".date("H:i:s").".000Z"));	
	
	$cursor=$collection->update($where,$filter);
	//print_r($cursor);
	if($imgaresult&&isset($cursor)){
		$cursor2 = $collection->find($where);
		foreach ($cursor2 as $document) {
		$orderlog = array("created_date"=>date("Y-m-d H:i:s"),"role"=>'-',"order_status"=>$document['OStatus'],"action"=>"Uploaded Prescription","actionById"=>"-","actionByName"=>"Customer",'description'=>"",'reason'=>$pre_name,"wid"=>$document['wid'],"wodid"=>$document['wodid'],'comment'=>"");
		$collection1 = $db->orderlog;
		$test=$collection1->update(
         array('_id' => (int)$_POST['omorderid']),
        array('$push' => array('order_log' =>$orderlog))
       );
		}
		
		
		echo "Prescription file has been uploaded.";
		
		
	}
	else
	{
		 echo  "<h1 style='color:red'>Someting went wrong! Please Try Again after sometime! </h1>"; exit;
	}
	?>