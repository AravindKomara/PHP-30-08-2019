<?php 
require('config.php');
$token = $_GET['token'];
$order = $_GET['orderid'];
//$orderid = urldecode(base64_decode(strrev(base64_decode($token))));
$orderid = $order;
?>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="./resources/css/bootstrap.css" rel="style/sheet">
<style>
    .img-responsive { width:16%; backgroun-size:100% 100%; height: 30px;box-shadow: 0 4px 4px rgba(216,216,216,.6);}
    /*.body-content { width:24%; height: 46% ; padding:16px 25px; border:solid 1px #ccc; margin:120px 535px; background:#eee;}*/
    .body-content { width:100%; max-width:300px; padding:10;}
    .btn-primary { background:#323a8b; color:#fff; padding:5px 12px; font-size:14px; border-radius:none; border:none; cursor:pointer; margin:15px 0;}
    .btn-primary:hover { background:#ses; color:#fff;}

    .ses-mes { font-size:16px; color:#ses; margin:auto; display:block; text-align:center; margin-bottom:15px;}
    .error-mes { font-size:16px; color:red; margin:auto; display:block; text-align:center; margin-bottom:15px;}
    .commonHeader{
        clear: both;
        box-shadow: 0px 2px 2px rgba(216,216,216,.7);
        z-index: 999;
        width: 100%;
        background-color: #fff;
        padding:9px 0px 10px 30px;
    }
    .bottom-footer{
        position:absolute;
        bottom:0;
        width:100%;
        height:70px;
        display: block;
        background: #000;
        padding: 5px 7px;
        font-size: 14px;
        color: #fff;
        z-index:500;
    }
    .text-center {
        text-align: center!important;
    }


</style>
<body onload="getOrderDetails()">
    <div class="commonHeader">
        <a href="#" class="pull-left">
            <img src="http://dev.callhealthshop.com/chdrugs/images/ch-shop-logo.png" style="width:180px;" alt="logo" name="logo">
        </a>
    </div>
    <div>
       
        <br><br>
        <div style="text-align:center">
        <span id="prescription_error">
        <div class="form-group" style="text-align:center;">
            <h3 style="padding-bottom:10px" id="uploadPresHeading"> Upload Prescription For -  </h3>
            <p class="ses-ses"></p>
            <p id="error_msg" style="color:red;font-size:15px;"></p>
        </div>
        <br><br>

        <form id="prescription_upload_form" method="post" enctype="multipart/form-data">
        <div align="center" style="background-color:#eeeeee; border-radius:3px 3px;">                    
            <div class="body-content"> 
                <lable style="text-align:center;">Please choose the file</lable>
                <input class="form-control" type="file" name="prescri_image[]" id="prescri_image" onchange="fileValidation(this);" multiple>
                <input type="hidden" name = "omorderid" value="<?php echo $orderid; ?>" id= "orderId"/>
               
                <input type="hidden" name = "mrn" value="<?php echo $mrn; ?>" id= "orderId"/>
                <input type="hidden" name = "orderstatus" value="" id= "orderStatus"/>
            </div>
        </div>
        <div align="center">
            <div style="text-align:center"> 
                <button class="form-control btn btn-primary" name="submit" type="button" value="submit"  id="prescription_submit" onclick="l2prescptionupload();">Submit</button>
                <input class="form-control btn btn-primary" type="reset" value="reset" name="submit"  class="btn btn-primary">
            </div>        
        </div>
    </form>
        </div>
        </span>
    
    <div class="bottom-footer text-center">
        <p> � CallHealth Services Pvt. Ltd., All Rights Reserved. 
            <span><img  alt="" src="assets/images/call_icon.png"> (+91) 91 33 55 77 99</span>
        </p>
    </div>
</div>
</body>
</html>
<script language="JavaScript" type="text/javascript" src="./resources/jquery/jquery.min.js"></script>
<script language="JavaScript" type="text/javascript" src="./resources/jquery/bootstrap.min.js"></script>
<script>
     sessionStorage.setItem("maxFileUploads", <?=$max_file_uploads?>);
    function getOrderDetails() {
        var requiredStatuses = [21,24,1000,1001];
        
        var _data = { order_id:'<?php echo $orderid; ?>',
                      OStatus:requiredStatuses};
       
        var paylaod = JSON.stringify(_data);
       console.log(paylaod);

    $.ajax({
        url: '<?= $serverhostpath ?>operation.php/v1/orders',
        data: paylaod,
        type: 'POST',
        success: function (data) {
          console.log(data);
            var result = '';
            if (typeof data == 'string') {
                result = JSON.parse(data);
            } else {
                result = data;
            }
            if (result.status == 1) {
                //alert(result.data[0].order.patientinfo.prescription_link_sent_dt);
              if(typeof(result.data[0].order.patientinfo.prescription_link_sent_dt)!="undefined"){
                  var temp = addMinutes(result.data[0].order.patientinfo.prescription_link_sent_dt);
                  if(temp == 1){
                       $("#prescription_error").html('<span style="color:red;font-size:35px;">Prescription has expired</span>');
                  }else{
                  $('#uploadPresHeading').html('Upload Prescription For:'+result.data[0].odid+', MRN: '+result.data[0].order.patientinfo.mrn);
                if (jQuery.inArray(result.data[0].OStatus, requiredStatuses) >= 0) {
                    $("#prescription_submit").prop('disabled',false);
                }else{
                   // $("#error_msg").html('Prescription has expired');
                    $("#prescription_submit").prop('disabled',true);
                }
                  }
              }else{
                  $("#prescription_error").html('<span style="color:red;font-size:35px;">Prescription date is not there</span>');
              }
                
                sessionStorage.setItem("patientMRN", result.data[0].order.patientinfo.mrn);
                sessionStorage.setItem("odid",  result.data[0].odid);
                sessionStorage.setItem("OStatus",  result.data[0].OStatus);
                
            }else{
                $("#prescription_error").html('<span style="color:red;font-size:35px;">Order details are not found</span>');
                $("#prescription_submit").prop('disabled',true);
            }
       }
    });
  }
  
  
  function l2prescptionupload() {
        var formData = new FormData($("#prescription_upload_form")[0]);
            formData.append('order_id',$("#orderId").val());
            formData.append('mrn', sessionStorage.getItem("patientMRN"));
        console.log(formData);
        $.ajax({
           url: '<?= $serverhostpath ?>medicine_supply.php/v1/prescription_upload_link',
           data: formData,
           cache: false,
           contentType: false,
           processData: false,
           type: 'POST',
           success: function (data) {
               console.log(data);
               var result = '';
               if (typeof data == 'string') {
                   result = JSON.parse(data);
               } else {
                   result = data;
               }
           if (result.status == 1) {
                alert('Prescription uploaded.');
                window.location.reload();
           } else {
                alert("some Thing Wrong  Please try again !")
            }
        }
    });
 }
 
 
    var imageArray = [];
    function fileValidation(uploadedfile) {
        var ext = $('#prescri_image').val().split('.').pop().toLowerCase();
        if ($.inArray(ext, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
            alert('invalid extension!');
            $(uploadedfile).val(''); //for clearing
            return false;
        } 
        var fp = $("#prescri_image");
               var lg = fp[0].files.length; // get length
               if(lg !=  sessionStorage.getItem("maxFileUploads")){
                   alert("only"+sessionStorage.getItem("maxFileUploads")+" files are allowed");
                   $('#prescri_image').val('');
                   return;
               }
               var items = fp[0].files;
               var fileSize = 0;
               if (lg > 0) {
               for (var i = 0; i < lg; i++) {
                   fileSize = fileSize+items[i].size; // get file size
               }
               if(fileSize > 2097152) {
                    alert('File size must be less than 2 MB');
                    $('#prescri_image').val('');
               }
           }
   
       for(var i=0; i<=uploadedfile.files.length;i++){         
           imageArray.push(uploadedfile.files[i]);//pushing all images into an array
       }
       imageArray = imageArray.filter(function( element ) {  return element !== undefined; });//removing undefind elements from array           
       //console.log(imageArray);
    }
    
    
    function addMinutes(time){
        var date1 = new Date(time);
        var date2  = new Date (date1); 
        date2.setMinutes (date1.getMinutes() + 30);
        var curent = new Date();
      //alert(curent);
       if(curent > date2){
           return 1;
          
       }else{
          return 0;
       }
  }
    

</script>