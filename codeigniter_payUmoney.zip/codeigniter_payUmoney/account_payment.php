

<!-- CONTENT AREA -->
<div class="content-area">

    <!-- PAGE --> <?php
    if ($this->session->flashdata('update_pass_fail')) {
        ?>
        <div class="alert alert-danger text-center" style="z-index:1055;margin:auto;position:absolute;top:5px;right:500px;"> 
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?php echo $this->session->flashdata('update_pass_fail') ?>
        </div>
    <?php } ?>
  
    <section class="page-section no-padding slider">

    </section>
    <!-- /PAGE -->


    <section class="page-section">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade active in" id="tab-2" style="">
                    <div class="">
                        <div class="col-md-12 col-sm-6 col-md-offset-">									
                            <div class="row">
                                <div class="message-box">
                                    <div class="message-box-inner">
                                        <h2>Make Payment</h2>
                                    </div>
                                </div>

                                <div class='col-md-6 col-md-offset-3'>
                                    <!-- Pay U Money Submitting Form --->
                        <form id="payment_form" method="post" action="<?= base_url('payment') ?>">
                            <div class="col-xs-12 text-center">
                                <div class="form-group">
                                    <h3>You are <?=$udetails->type?> Membership User.... </h3><br>
                                    <h3>Pay <?= $udetails->tr_total_amount ?> to activate your membership... </h3><br>
                                    <p style="font-size:15px;">Click <a href="javascript:;" id="" data-price="<?= $udetails->tr_total_amount ?>"><b><span class="label label-danger label-mini">below</span></b></a> and pay <b style="font-size: 20px;"> Rs <?= $udetails->tr_total_amount ?> /- </b> to activate your account</p>

                                </div>
                            </div>

                            <?php
                            $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 10);//generating txnID for transaction
                            ?>
                            <input type="hidden" name="mem_id" value="<?= $udetails->member_id ?>">
                            <input type="hidden" name="type" value="AccountPayment">
                            
                 <!-- Pay U Money Mandatory Fields --->                        
                            <input type="hidden" name="key" value="B9vV3QMo">
                            <input type="hidden" name="txnid" value="<?= $txnid ?>">
                            <input type="hidden" name="amount"   value="<?= $udetails->tr_total_amount ?>">
                            <input type="hidden" name="firstname" value="<?= $udetails->tru_pre_name ?>">
                            <input type="hidden" name="email" value="<?= $udetails->tru_pre_email ?>">
                            <input type="hidden" name="phone" value="<?= $udetails->tru_pre_mobile1 ?>">
                            <input type="hidden" name="productinfo" value="Member Payment">
                            <input type="hidden" name="surl" value="<?= base_url('Payments/success/online?txnid=' . $txnid) ?>">
                            <input type="hidden" name="furl" value="<?= base_url('Payments/failure') ?>">
               <!-- End Pay U Money Mandatory Fields --->        
                             


                            <div class="col-xs-12 text-center">
                                <div class="form-group">
                               
                                    <button type="submit" class="btn btn-success">Pay via Pay U Money</button>
                                    <span id="otp_msg_resp"></span>
                                </div>
                            </div>

                        </form>
              <!-- End of Pay U Money Submitting Form --->
                                </div>

                            </div>	
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- /PAGE -->              
</div>
<!-- /CONTENT AREA -->












