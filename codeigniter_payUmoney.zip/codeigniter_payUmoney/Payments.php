<?php

header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');

class Payments extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Ngos_model');
        $this->load->model('Sms_model');
        $this->load->model('States_districts');
        $this->load->model('Mail_model');
        $this->load->model('admin/Admin_model');
    }

    public function payment() {

        $this->load->view('payment/PayUMoney_form');
    }

    public function account_payment() {
        $data['udetails'] = $this->Admin_model->get_all_details_ofuser($_SESSION['memberid']);
        $this->load->view('templates/header');
        $this->load->view('payment/account_payment', $data);
        $this->load->view('templates/footer');
    }

    public function success() {
        $data = array();
        if ($this->input->post('type') == 'AccountPayment') {
            $data = array("member_id" => $this->input->post('mem_id'),
                "name" => $this->input->post('firstname'),
                "email" => $this->input->post('email'),
                "mobile" => $this->input->post('phone'),
                "payment_for" => $this->input->post('productinfo'),
                "service_provider" => 'payu_paisa',
                "amount" => $this->input->post('amount'),
                "txnID" => $this->input->post('txnid'),
                "date" => date('d-m-Y'));
        } else {
            $data = array("member_id" => $_SESSION['mem_id'],
                "name" => $_POST["firstname"],
                "email" => $_SESSION['email'],
                "mobile" => $_SESSION['mobile'],
                "payment_for" => $_POST['productinfo'],
                "service_provider" => 'payu_paisa',
                "amount" => $_POST["amount"],
                "txnID" => $_POST["txnid"],
                "date" => date('d-m-Y'));
        }


        $memberstatus = $this->Ngos_model->update_member_status(); //updating member status
        $this->db->insert('payments', $data); //inserting in payments table  
        $this->session->sess_destroy(); //destroying all the sessions

        $this->load->view('templates/header');
        $this->load->view('payment/success');
        $this->load->view('templates/footer');
    }

    public function failure() {
        $txnid = $_POST["txnid"];
        $this->load->view('templates/header');
        $this->load->view('payment/failure');
        $this->load->view('templates/footer');
    }

}
