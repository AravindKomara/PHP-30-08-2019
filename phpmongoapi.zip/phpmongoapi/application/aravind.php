<?php

require 'api/vendor/autoload.php';
include 'db.php';
ini_set('memory_limit', '-1');
date_default_timezone_set("Asia/Calcutta");
$app = new Slim\App([

    'settings' => [
        'displayErrorDetails' => true,
        'debug'               => true,
        'whoops.editor'       => 'sublime',
    ]

]);
$app->post('/register', 'user_registration');
$app->run();

function user_registration($request, $response) {

    $userdata = json_decode($request->getBody());
    $db = getDBmasters();
    $collection = $db->user_test;

    $document = array("username" => $userdata->username,
        "email" => $userdata->email,
        "password" => $userdata->password);

    // print_r($document);


    $response = $collection->insert($document);
    echo "Document inserted successfully";
}

?>