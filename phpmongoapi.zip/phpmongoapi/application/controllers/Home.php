<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        $this->load->view('register');
    }
    
     //common curl API call
    private function common_curl_call($url, $param, $header, $method) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);//here we have to give our url
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        if ($param != "") {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $param);//checking parameters empty or not empty
        }
        if ($method == "post") {
            curl_setopt($ch, CURLOPT_POST, true);//if method is post
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);//here setting header
        $resultcurl = curl_exec($ch);//from API call , result is getting and storing in this variable
      //  print_r($resultcurl);
        curl_close($ch);//closing curl
        return $resultcurl;//returning the data
    }

    public function user_registration() {
        $data = array(
            "username" => $this->input->post('username'),
            "email" => $this->input->post('useremail'),
            "password" => $this->input->post('userpassword'));
       $reqparmt = json_encode($data);//converting data to json format and passing as parameter to API curl call
       //change path according to your localhost
       $url ='http://localhost/dboperations/api/operation.php/v1/userRegistration';//creating URL for API call(open this path)
       $header = array('Content-Type: application/json');//this is necessary to passs
       $method = "post";//method type
       $response = $this->common_curl_call($url,$reqparmt,$header,$method);//calling curl function by passing all required parameters
       $response = json_decode($response);//after getting data from curl call we have to convert json to php array
       print_r($response);exit;
       
    }

   

}

?>