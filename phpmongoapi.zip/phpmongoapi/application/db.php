<?php

function getDBmasters() 
{	
	$m = new MongoClient("mongodb://172.26.7.111:27017");	
	$db = $m->masters;
	return $db;
}
?>