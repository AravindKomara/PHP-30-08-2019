<?php
ini_set("log_errors", 1);
date_default_timezone_set("Asia/Calcutta");

ini_set("error_log", __DIR__ . "/logs/php-error_" . date('Y-m-d') . ".log");
include 'functions.php';
include 'dbo.php';
include 'utility.php';
include 'logapp.php';
include 'Oms.php';
create_access_log();

ini_set('memory_limit', '-1');

class Order extends Oms
{
    public function __construct()
    {
        parent::__construct();
    }

    public function insertTransaction($order_set, $transaction_code, $payload)
    {
        unset($payload['business']);
        //echo "1";exit;
        $transaction = $payload;
        $utility = new Utility;
        $transaction['transaction_code'] = $transaction_code;
        $transaction['created_date'] = $utility->getCurrenttime();
        $order_info = array();
        $order_array = array();
        $workorder_array = array();
        $log_array = array();
        $app_array = array();

        $app_ids = array();
        $order_ids = array();

        //print_r($order_set);exit;

        foreach ($order_set as $order) {
            //echo "1";exit;
            /* if($order['type']==1)
            {
            //    print_r($payload);
            $order_data=$this->createAppointment($order,$transaction_code);
            //print_r($order_data);exit;
            $app_ids[] = $order_data[appointmentId];//Fetch appointmentId s
            array_push($app_array,$order_data);
            $orderdetail=$orderdetail=array(
            "mrn"=>$order_data['mrn'],
            "scheduled_date"=>$order_data['servicedate'],
            "gross_amount"=>$order_data['payment_info']['gross_amount'],
            "discount_amount"=>$order_data['payment_info']['discount_amount'],
            "net_amount"=>$order_data['payment_info']['net_amount'],
            "voucher_amount"=>$order_data['payment_info']['voucher_amount'],
            "coupon_amount"=>$order_data['payment_info']['coupon_amount'],
            "appointmentId"=>$order_data['appointmentId'],
            "coupon_amount"=>$order_data['payment_info']['coupon_amount'],
            "service_subtype_id"=>$order_data['serviceSubTypeId'],
            "service_type"=>$order_data['serviceTypeId'],

            );
            } */
            //else
            //{
            //ADDED FOR INITIAL STATUS FETCH
            $mode_of_service = isset($order['mode_of_service']) ? $order['mode_of_service'] : "";

            $creation_type = isset($order['business']->creation_type) ?
            $order['business']->creation_type : "";

            $payment_code = $order['business']->payment_code;
            $is_package = $order['business']->is_package;

			if ($order['type'] == 1) //CONSULT NOW
            {
				if($order['business']->is_consultation == 1 and $order['business']->slot_transaction_id == "")
				{
					$consultNow = 1;
				}
			}
			
            if ($order['type'] == 2) //or $order['type']==11 => MAY BE ADDED LATER
            {
                $prescription_later = isset($order['business']->prescription_later) ?
                $order['business']->prescription_later : 0;

                //$vendorset = isset($order['business']->associate_id)? 1:0;

                //CHECK IF VENDOR DETAIL IS MENTIONED
                $vendorset = 0;
                if (isset($order['business']->associate_id) and $order['business']->associate_id != "") {
                    $vendorset = 1;
                }
            }

            $ostatus = $this->getInitialStatus((int) $order['type'], $mode_of_service, $creation_type, $payment_code, $is_package, $prescription_later, $vendorset);			
            $order['orderStatus'] = $ostatus;
			
            //echo json_encode($order);
            //print_r($order);
            //exit;

            //echo json_encode($order);exit;
            $data_order = $this->createOrder($order, $transaction_code);
            $order_data = $data_order['order'];
            //print_r($order_data);exit;
			if((int)$ostatus==1001 && (int)$order['type']==2){
				$data_order['order']['order']['patientinfo']['prescription_later']="1";
			}
            $order_ids[] = $order_data[_id]; //Fetch order_id s
            array_push($order_array, $data_order['order']);
            array_push($workorder_array, $data_order['workorder']);
            array_push($log_array, $data_order['log']);
			
			
            $patient_info = $order_data['order']['patientinfo'];
            $orderdetail = array(
                "mrn" => $patient_info['mrn'],
                "scheduled_date" => $patient_info['servicedate'],
                "gross_amount" => $patient_info['gross_amount'],
                "discount_amount" => $patient_info['discount_amount'],
                "net_amount" => $patient_info['net_amount'],
                "voucher_amount" => $patient_info['voucher_amount'],
                "coupon_amount" => $patient_info['coupon_amount'],
                "order_id" => $patient_info['order_id'],
                "workorder_id" => $order_data['wid'], //ADDED 27/03/19
                "coupon_amount" => $patient_info['coupon_amount'],
                "service_subtype_id" => $patient_info['service_subtype_id'],
                "service_type" => $patient_info['service_type'],
                "order_did" => $order_data['odid'],
                "ihs_batch_id" => $patient_info['ihs_batch_id'], //ADDED 27/02/19

            );

            //}
            array_push($order_info, $orderdetail);
        }
        $transaction['order_info'] = $order_info;

        //print_r($order_array);exit;
        $dbo = new Dbo;
        $insert_set = array();
        if (!empty($app_array)) {
            //$insert_response=$dbo->insertMany('masters','appointments',$app_array);
            $insert_set['appointments'] = $app_array;
        }
        if (!empty($order_array)) {
            //$insert_response=$dbo->insertMany('masters','orders',$order_array);
            $insert_set['order'] = $order_array;
        }
        if (!empty($workorder_array)) {
            $insert_set['workorders'] = $workorder_array;
            //$insert_response=$dbo->insertMany('masters','workorders',$workorder_array);
        }
        if (!empty($log_array)) {
            $insert_set['orderlog'] = $log_array;
            //$insert_response=$dbo->insertMany('masters','orderlog',$log_array);
        }
        //print_r($workorder_array);exit;

        $insert_set['transaction'] = $transaction;
        $insert_set['order_info'] = $order_info;
		$wallet_statusDurg = array();
		if(isset($insert_set["transaction"]["deduct_the_wallet"]) && $insert_set["transaction"]["deduct_the_wallet"]==1){
			$MedicineSupplies = new MedicineSupplies;
			$deduct_wallet_amount = (float)$insert_set["transaction"][payment_info]->wallet_amount;			
			$wallet_statusDurg = $MedicineSupplies->walletTransaction("Medicine",$transaction_code,"debit",$deduct_wallet_amount,$insert_set["transaction"]["mrn"],"");
		}
        $response = array("transaction" => $transaction_code, "status" => "1", "message" => "transaction created Successfully");
        return array("set" => $insert_set, "response" => $response, "orders" => $order_ids,
            "appointments" => $app_ids, "wallet_statusDurg"=>$wallet_statusDurg);

    }

    public function getInitialStatus($type, $mode, $creation_type, $payment_code, $is_package, $prescription_later, $vendorset,$consultNow)
    {
        if ((int) $is_package == 1 and $payment_code == 0) {
            $status = "17";
        } else if ((int) $is_package == 1) {
            $status = "6";
        } else {
            $status = "0";
			if ($type == 1 and $consultNow == 1) {
                $status = "2";
            }
            if ($type == 3) {
                $status = "0";
            }
            if ($type == 4) {
                $status = "25";
            }
            if ($type == 2) {
                //$status="17";
                if ($prescription_later != 1) {
                    if ($vendorset == 1) {
                        $status = "21";
                    } else {
                        $status = "1000";
                    }
                } else {
                    $status = "1001";
                }
            } else if ($type == 30) {
                $status = "0";
            } else if ($type == 11) {
                $status = "21";
            } else if ($type == 13) {
                $status = "6";
                if ($creation_type == "1") {
                    $status = "17";
                }
            } else if ($type == 14) {
                $status = "6";
                if ($creation_type == "1") {
                    $status = "17";
                }

            }

            //FOR IHS ORDERS
            if ($creation_type == "3") {
                $status = "6";
            }
        }

        return $status;
    }

    public function createAppointment($order, $transaction_code)
    {
        //print_r($order);exit;
        $econ = new econsultation;

        $order_obj = $econ->createAppointment($order, $transaction_code);
        return $order_obj;
    }

    public function createOrder($payload, $transaction_code)
    {

        //
        //print_r($payload);
        //exit;
        try {
            //required order creation parameters same for all business..

            $source = isset($payload['additionaldata']['channel']) ? $payload['additionaldata']['channel'] : "1";

            $orderId = $this->utility->getNextSequence("ORDERID");
            $orderDidSeq = $this->utility->getNextSequence("OID");
            $userid = isset($payload[additionaldata]['createdById']) ? $payload[additionaldata]['createdById'] : "";
            $username = isset($payload[additionaldata]['createdByName']) ? $payload[additionaldata]['createdByName'] : "";
            $mode_of_service = isset($payload['mode_of_service']) ? $payload['mode_of_service'] : "";

            $creation_type = isset($payload['business']->creation_type) ? $payload['business']->creation_type : "";

            $payment_code = $payload['business']->payment_code;
            $is_package = $payload['business']->is_package;

            //ADDED FOR INITIAL STATUS FETCH
			if ($payload['type'] == 1) //CONSULT NOW
            {
				if($payload['business']->is_consultation == 1 and $payload['business']->slot_transaction_id == "")
				{
					$consultNow = 1;
				}
			}
            if ($payload['type'] == 2) //or $payload['type']==11 => MAY BE ADDED LATER
            {
				//print_r($payload['business']); exit;
                $prescription_later = isset($payload['business']->prescription_later) ?
                $payload['business']->prescription_later : 0;
                $vendorset = isset($payload['business']->associate_id) ? 1 : 0;
            }

            $date = date('dmy');
            $payment_info = $payload['payment_info'];
            //required order creation parameters end

            $orderStatus = isset($payload['orderStatus']) ? (int) $payload['orderStatus'] : "";
            if ($orderStatus == "") {

                if ($payload['type'] == "") {
                    $payload['type'] = $payload['patientinfo']->service_type;
                }
                $business_type = $payload['type'];

                $orderStatus = $this->getInitialStatus($business_type, $mode_of_service, $creation_type, $payment_code, $is_package, $prescription_later, $vendorset, $consultNow);
            }

            $patientinfo_obj = $this->patientinfo((object) $payload['patientinfo']
                , $orderStatus, $orderId);

            $orderstatus_obj = $this->orderstatus($orderStatus, $source, $orderId);

            //business logic
            $businessId = (int) $patientinfo_obj['service_type'];
            $business_obj = $this->business((object) $payload['business'], $orderStatus, $businessId);
            $business_data = (array) $payload['business'];
            $order_status = (array) $payload['order_status'];
            $subBusinessId = (int) $patientinfo_obj['service_subtype_id'];

            $addition_attribute = 0;
            if ($businessId == 6 || $businessId == 7 || $businessId == 8) {
				$careitem=(array)$payload['orderitem'][0];
				$subBusinessId=$careitem['service_subtype_id'];
				$patientinfo_obj['service_subtype_id']=(string)$subBusinessId;
                if (isset($business_obj['is_continuous'])) {
                    $addition_attribute = 1;

                } else if (isset($business_obj['is_assessment'])) {

                    $addition_attribute = 2;

                } else {
                    $addition_attribute = 3;

                }
            }
            if ($businessId == 1 and (int) $business_obj['is_assessment'] == 1) {
                $addition_attribute = 2; //ECon Assessment
            }
			
			//RETURN ORDER
			if(($businessId == 2 or $businessId == 11) and (int)$payload['business']->is_return_order == 1)
			{
				$addition_attribute = 4; // Drug/Equipment Return
			}

            $prefix = $this->utility->getPrefix($subBusinessId, $mode_of_service, $businessId, $addition_attribute);
            $businessPrefix = $this->utility->getBusinessPrefix($businessId, $addition_attribute);

            $is_parent = isset($business_data[is_parent]) ? $business_data[is_parent] : 1;
            if ($is_parent != 0 or $payload['patientinfo']['package_parent_id'] != null) {
                $orderDid = $businessPrefix . "-" . $prefix . "-" . $date . "-" . $orderDidSeq;
            } else {

                $orderDid = $order_status[order_did] . "-" . $business_data[session_no];

            }

            $orderstatus_obj['order_did'] = $orderDid;
            $patientinfo_obj['order_did'] = $orderDid;
            //print_r($business_obj);exit;

            //Package Orders
            if ((int) $business_data['is_package'] == 1) {
                $package = new Package;
                $associate = $payload['associate'];
                $order_obj = $package->createOrder($associate, $patientinfo_obj, $orderstatus_obj, $payload, $business_obj, $transaction_code);
            }

            //If not package order
            else {
                //eConsulatation starts
                if ($businessId == 1 ) 
				{
                    if ( (int) $business_data['is_assessment'] == 1) 
					{
						$associate = $payload['associate'];
						$econsulation = new Econsultation;

						$order_obj = $econsulation->createAssessmentOrder($associate, $patientinfo_obj, $orderstatus_obj, $payload, $business_obj);
               
				   }

				  else 
					{
						$associate = $payload['associate'];
						$econsulation = new Econsultation;

						//echo "1";exit;
						$order_obj = $econsulation->createConsulationOrder($associate, $patientinfo_obj, $orderstatus_obj, $payload, $business_obj);
					}
                }

              
	if ($businessId == 1 and (int) $business_data['is_assessment_consultation'] == 1 ) {
                    $associate = $payload['associate'];
                    $econsulation = new Econsultation;

                    //echo "1";exit;
                    $order_obj = $econsulation->createAssessmentConsulationOrder($associate, $patientinfo_obj, $orderstatus_obj, $payload, $business_obj);
                }
                //eConsulation ends

                //Drug order
                if ($businessId == 2) {
                    //$associate = $payload['associate'];
                    $medicineobj = new Medicine;
                    $order_obj = $medicineobj->createOrder($patientinfo_obj, $orderstatus_obj, $payload, $business_obj);

                    //VENDOR INFO NEEDS TO BE PUSHED TO PROVIDER INFO
                    $vendorinfo = $order_obj[vendorinfo];
                    unset($order_obj[vendorinfo]);
                }
                //End drug order

                //pathology
                if ($businessId == 3) {

                    $associate = $payload['associate'];
                    $pathology = new pathology;
                    $order_obj = $pathology->createOrder($associate, $patientinfo_obj, $orderstatus_obj, $payload, $business_obj);
                    $report_required = $business_data['report_required'];
                }

                //pathology ends
                //imaging starts
                if ($businessId == 4) {

                    $associate = $payload['associate'];
                    $imagingOrder = new Imaging;
                    $order_obj = $imagingOrder->createOrder($associate, $patientinfo_obj, $orderstatus_obj, $payload, $business_obj);
                    $report_required = 0;
                }

                //imaging ends
                //care at home 77
                if ($businessId == 6 || $businessId == 7 || $businessId == 8) {

                    $careOrder = new Care;
                    $associate = $payload['associate'];
                    if (isset($business_obj['is_continuous'])) {
                        $business_obj['is_continuous'] = 1;
                        if (!isset($business_obj['is_parent'])) {
                            $business_obj['is_parent'] = 1;

                        }
                        $order_obj = $careOrder->order($subBusinessId, $patientinfo_obj, $orderstatus_obj, $payload, $business_obj, $transaction_code);

                    } else if (isset($business_obj['is_assessment'])) {

                        $order_obj = $careOrder->createAssessmentOrder($subBusinessId, $associate, $patientinfo_obj, $orderstatus_obj, $payload, $business_obj);

                    } else {

                        $business_obj['is_transaction'] = 1;
                        if (!isset($business_obj['is_parent'])) {
                            $business_obj['is_parent'] = 1;

                        }
                        $order_obj = $careOrder->order($subBusinessId, $patientinfo_obj, $orderstatus_obj, $payload, $business_obj, $transaction_code);
                    }

                }
                //care at home end
                //

                //Added  on 25-02-2019
                //MedEquip order
                if ($businessId == 11) {
                    //$associate = $payload['associate'];

                    $medeqobj = new Mediequipment;
                    $order_obj = $medeqobj->createOrder($patientinfo_obj, $orderstatus_obj, $payload, $business_obj);

                    //VENDOR INFO NEEDS TO BE PUSHED TO PROVIDER INFO
                    $vendorinfo = $order_obj[vendorinfo];
                    unset($order_obj[vendorinfo]);
                }
                //End MedEquip order

                //ewellness
                if ($businessId == 13) {

                    $wellnessOrder = new Wellness;
                    $order_obj = $wellnessOrder->createOrder($subBusinessId, $patientinfo_obj, $orderstatus_obj, $payload, $creation_type, $business_obj);
                }
                if ($businessId == 14) {

                    $wellnessOrder = new Wellness;
                    $order_obj = $wellnessOrder->createOrder($subBusinessId, $patientinfo_obj, $orderstatus_obj, $payload, $creation_type, $business_obj);
                }
                //ewellness ends
                //Assessment order
                //Assessment order Ends

                /*  if ($businessId == 30) {
            $associate = $payload['associate'];
            $careOrder = new Care;
            $order_obj = $careOrder->createAssessmentOrder($subBusinessId, $associate, $patientinfo_obj, $orderstatus_obj, $payload);
            } */
            }
            //business logic End

            $component_data = $this->utility->service_component_map($businessId, $mode_of_service, $report_required,(int)$business_data['is_assessment']);
            //print_r($component_data);exit;
            ///

            //ADDED 27/03/2019
            $role_comp_map = array();

			$sample_submission_flag = 1;
            //PUSHING THE COMPONENT_NOs INTO EACH ORDERITEM
            for ($k = 0; $k < count($order_obj[orderitem]); $k++) {
                //ADDED BECAUSE CAREPLAN ORDERITEM IS IN ARRAY FORMAT
                $order_obj[orderitem][$k] = (object) $order_obj[orderitem][$k];

                $order_obj[orderitem][$k]->component_no = $component_data[components][$k];

                /* $role_comp_map[$component_data[components][$k]] =
                array('role'=>$order_obj[orderitem][$k]->role
                ,'skill'=>$order_obj[orderitem][$k]->skill
                ,'roleBasedService'=>$order_obj[orderitem][$k]->roleBasedService
                ); */

                //FOR MEDICINE ORDER ROLE BASED SERVICE IS DDO AND ALL OTHER IS VENDOR COMP
                if ((int) $businessId == 2) {
                    if ($order_obj[orderitem][$k]->roleBasedService) {
                        //$order_obj[orderitem][$k]->component_no = "13"; //"8";
                        if(in_array('8',$component_data[components])) //DDO
						{
							$order_obj[orderitem][$k]->component_no = "8";
						}
						else
						{
							$order_obj[orderitem][$k]->component_no = "13";
						}
                    } else {
                        $order_obj[orderitem][$k]->component_no = "9";
                    }
                }
                //DIAGNOSTICS
                else if ((int) $businessId == 3) {
                    if ($order_obj[orderitem][$k]->roleBasedService && $order_obj[orderitem][$k]->role == 8) {
                        $order_obj[orderitem][$k]->component_no = "1";
                    } else if ($order_obj[orderitem][$k]->roleBasedService && $order_obj[orderitem][$k]->role == 25) {
                        $order_obj[orderitem][$k]->component_no = "3"; //ADMIN SAMPLE COLLECTION
                    } else if ($order_obj[orderitem][$k]->roleBasedService && $order_obj[orderitem][$k]->role == 13) {
                        //$order_obj[orderitem][$k]->component_no = "13"; //"8"; //RDO
                        if(in_array('8',$component_data[components])) //RDO
						{
							$order_obj[orderitem][$k]->component_no = "8";
						}
						else
						{
							$order_obj[orderitem][$k]->component_no = "13";
						}
                    } else if (!$order_obj[orderitem][$k]->roleBasedService or $order_obj[orderitem][$k]->roleBasedService == 0) {
                        $order_obj[orderitem][$k]->component_no = "7"; //CENTER(TEST COMPONENT)
                    }
                }

                //FACILITATION
                else if ((int) $businessId == 4) {
                    if ($order_obj[orderitem][$k]->roleBasedService && $order_obj[orderitem][$k]->role == 13) {
                        //$order_obj[orderitem][$k]->component_no = "13"; //"8"; //RDO
                        if(in_array('8',$component_data[components])) //RDO
						{
							$order_obj[orderitem][$k]->component_no = "8";
						}
						else
						{
							$order_obj[orderitem][$k]->component_no = "13";
						}
                    } else if ($order_obj[orderitem][$k]->roleBasedService && $order_obj[orderitem][$k]->role == 26) {
                        $order_obj[orderitem][$k]->component_no = "3"; //ADMIN RADIOLOGY
                    } else if (!$order_obj[orderitem][$k]->roleBasedService or $order_obj[orderitem][$k]->roleBasedService == 0) {
                        $order_obj[orderitem][$k]->component_no = "7"; //CENTER(TEST COMPONENT)
                    }
                }

                $role_comp_map[$order_obj[orderitem][$k]->component_no] =
                array('role' => $order_obj[orderitem][$k]->role
                    , 'skill' => $order_obj[orderitem][$k]->skill
                    , 'roleBasedService' => $order_obj[orderitem][$k]->roleBasedService,
                );
				
				if($order_obj[orderitem][$k]->require_sample_submission === 0)
				{
					$sample_submission_flag = 0;
				}
            }
			

            $comps_present = array();
            //GET THE COMPONENTS ALREADY PRESENT IN THE PROVIDER INFO AND PUSH CORRESPONDING ROLE AND SKILL
            for ($i = 0; $i < count($order_obj[provider_info]); $i++) {
                $order_obj[provider_info][$i][role] =
                    $role_comp_map[(int) $order_obj[provider_info][$i][component_no]][role];
                $order_obj[provider_info][$i][skill] =
                    $role_comp_map[(int) $order_obj[provider_info][$i][component_no]][skill];

                //IN CASE OF EQUIPMENT ADD VENDOR INFO TO COMPONENT(VENDOR) ALREADY PRESENT AS DETAILS DONT COME FROM MDM TO BE ALREADY IN ORDERITEM
                if ($businessId == 11 or $businessId == 2) {
                    foreach ($vendorinfo as $key => $value) {
                        $order_obj[provider_info][$i][$key] = $value;
                    }
                    //$order_obj[provider_info][$i][vendor_assigned_date] = $order_obj[order_status][created_date];
                }

                $comps_present[] = $order_obj[provider_info][$i][component_no];
            }

            //INSERT NEW ARRAY VALUE FOR THE COMPONENTS NOT PRESENT
            $j = count($order_obj[provider_info]);
            foreach ($component_data[components] as $comp) {
                if (!in_array($comp, $comps_present)) {
                    $order_obj[provider_info][$j][component_no] = $comp;
                    $order_obj[provider_info][$j][role] = $role_comp_map[$comp][role];
                    $order_obj[provider_info][$j][skill] = $role_comp_map[$comp][skill];
                    $j++;
                }
            }

            //print_r($order_obj);exit;
            ///

            $version = $this->config->getconfig('version', '');

            $order_structure = array();

            $order_structure['version'] = (int)$version;
			if(isset($payload['additionaldata']['code'])) 
			{
				$order_structure['code'] = $payload['additionaldata']['code'];
			}
            $order_structure['_id'] = $orderId;
            $order_structure['order'] = $order_obj;
            $order_structure['createdById'] = $userid;
            $order_structure['createdByName'] = $username;
            $order_structure['mode_of_service'] = $mode_of_service;
            //$order_structure['pop_id'] = $patientinfo_obj['facility_id'];
            $order_structure['channel'] = $source;
            $order_structure['active_component'] = (string) $component_data['active_comp'];
			if($sample_submission_flag === 0)
			{
				//FOR SAMPLE_SUBMISSION_FLAG
				$component_data['components'] = ["1"];
			}
            $order_structure['component_order'] = $component_data['components'];
            $order_structure['transaction_code'] = $transaction_code;
            $order_structure['OStatus'] = (int) $orderStatus;
            $order_structure['creation_type'] = $creation_type;
            $order_structure['WOStatus'] = (int) $orderStatus;
            $order_structure['report_required'] = (int) $report_required;
            $order_structure['odid'] = $orderDid;
            $order_structure['wodid'] = $orderstatus_obj['workorder_did'];
            $order_structure['wid'] = $orderstatus_obj['workorder_id'];
            $order_structure['billing'] = array("payment_status" => "1", "billing_status" => "1");
            $order_structure['advance_receipt'] = $payload['advance_receipt']; //NEW ADDITION
            $order_structure['payment_info'] = $payment_info;
            $order_structure['workorderinfo'] = array(array('wostatus' => $orderStatus, 'wodid' => $orderstatus_obj['workorder_did'], 'wid' => $orderstatus_obj['workorder_id'], "scheduled_date" => $patientinfo_obj['servicedate'], "created_date" => $orderstatus_obj['order_date']));
            
			//PREVIOUS
			/* $order_structure['order']['business']->reschedule_block = 0;
            $order_structure['order']['business']->cancel_block = 0;
            if ((int) $creation_type == 2 ) //  for IHS or drug:comp9
            {
                $order_structure['order']['business']->reschedule_block = 1;
                $order_structure['order']['business']->cancel_block = 1;
            } */
			
			$order_structure['order']['business'] = (array)$order_structure['order']['business'];
			
			$order_structure['order']['business']['reschedule_block'] = 0;
            $order_structure['order']['business']['cancel_block'] = 0;
            if ((int) $creation_type == 2 ) //  for IHS or drug:comp9
            {
                $order_structure['order']['business']['reschedule_block'] = 1;
                $order_structure['order']['business']['cancel_block'] = 1;
            }
			
			if ($order_structure['order']['business']['is_assessment']==1 and $order_structure['order']['patientinfo']['service_type']== "1") //  for ECON-ASSESSMENT ORDERS
            {
                $order_structure['order']['business']['reschedule_block'] = 1;
                $order_structure['order']['business']['cancel_block'] = 1;
            }
			
			if(isset($order_structure['order']['business']['referenceOrderId']) and $order_structure['order']['business']['is_consultation']==1 and 
			$order_structure['order']['patientinfo']['consultationType']!="2" ) //FOR CONSULTATION WITH referenceOrderId / ENC ID
			{
				$order_structure['order']['business']['reschedule_block'] = 1;
                $order_structure['order']['business']['cancel_block'] = 1;
			}
			
			if(isset($order_structure['order']['business']['eventId']) and 
						isset($order_structure['order']['business']['package_parent_id']))
			{
				$order_structure['order']['business']['cancel_block'] = 1;
			}

			//ASSIGN TO DOCTOR DIRECTLY IF CONSULT NOW
			if($consultNow == 1)
			{
				$order_structure['assaigned_to'] = $order_structure['order']['business']['doctorId'];
				$order_structure['assignedbypop'] = "1";
				$order_structure['assigned_to'] = $order_structure['order']['business']['doctorId'];
			}		

            $order_obj = $order_structure;
            /*  $this->dbo = new Dbo;
            $insert_response = $this->dbo->insert('masters', 'orders', $order_structure);

            if ($insert_response['ok'] == 1) {

            $order_id = $order_structure['_id'];
            $current_w_id = $order_structure['wid'];
            $current_w_did = $order_structure['wodid'];
            $facility_id = $patientinfo_obj['facility_id'];
            $pop_name = $patientinfo_obj['popname'];
            $orderitem = $order_structure['order']['orderitem'];
            $scheduled_date = $patientinfo_obj['scheduled_date'];
            $this->createworkorder($order_id,$current_w_id,$current_w_did,$scheduled_date,$orderitem,$orderStatus,"creation");

            //exit;
            $this->logcreation($source, $orderStatus, "order creation", $userid, $username, "Order Created as draft", $current_w_id, $current_w_did, $order_id, "Order Creation", "", $order_structure, $facility_id, $pop_name);
            } */

            // print_r($order_structure);
            // exit;

            $order_id = $order_structure['_id'];
            $current_w_id = $order_structure['wid'];
            $current_w_did = $order_structure['wodid'];
            $facility_id = $patientinfo_obj['facility_id'];
            $pop_name = $patientinfo_obj['popname'];
            $orderitem = $order_structure['order']['orderitem'];
            $scheduled_date = $patientinfo_obj['scheduled_date'];
            $workorder_obj = $this->createworkorder($order_id, $current_w_id, $current_w_did, $scheduled_date, $orderitem, $orderStatus, "creation",(string) $component_data['active_comp']);
			/* if($payment_info['payable_amount']==0 and ($order_structure['order']['business']['is_parent']==1))
			{
						$financeobj = new Finance;
                        $financeobj->generateBill((object) array("OrderID" => $order_id));
			} */
            //exit;
            $log_obj = $this->logcreation($order_structure, $comment);

            // print_r($order_obj);exit;
            //print_r($workorder_obj);
            //print_r($log_obj);exit;
            $order_data = array("order" => $order_obj, "workorder" => $workorder_obj, "log" => $log_obj);
            return $order_data;
        } catch (Exception $e) {
            print_r($e);exit;
        }
        //exit;
    }

    public function business($business, $orderStatus, $businessId)
    {
        //print_r($business);exit;
        $business_obj = array();
        if (isset($business->package_parent_id)) {
            $business_obj["package_parent_id"] = $business->package_parent_id;
        }

        if ((int) $business->allocate_self == 1) {
            $business_obj["self_alloc_flag"] = 1;
            $business_obj["officerAssociateId"] = $business->officerAssociateId;
            $business_obj["officerBranchId"] = $business->officerBranchId;
            $business_obj["createdById"] = $business->createdById;
            $business_obj["createdByName"] = $business->createdByName;
        }

        //FOR SUBORDERS OF PACKAGES
        if (isset($business->eventId)) {
            $business_obj["eventId"] = $business->eventId;
        }


        if ($business->is_package == 1) {
            $business_obj["wellness_speciality_code"] = $business->wellness_speciality_code;
            $business_obj["primaryCoachCode"] = $business->primaryCoach;
            $business_obj["is_package"] = $business->is_package;

            //WILL BE ONLY SET FOR PARENT ORDERS
            if (isset($business->is_parent)) {
                $business_obj["is_parent"] = $business->is_parent;
            }
        }

        if ($businessId == 1) {
            if (isset($business->is_assessment)) {
                $business_obj["is_assessment"] = $business->is_assessment;
            }
            if (isset($business->is_consultation) and (int) $business->is_assessment != 1) {
                $business_obj["is_consultation"] = $business->is_consultation;
            }
            if (isset($business->doctorId)) {
                $business_obj["doctorId"] = $business->doctorId;
            }
            if (isset($business->doctorName)) {
                $business_obj["doctorName"] = $business->doctorName;
            }
            if (isset($business->consultationType)) {
                $business_obj["consultationType"] = $business->consultationType;
            }
            if (isset($business->consultationMode)) {
                $business_obj["consultationMode"] = $business->consultationMode;
            }
            if (isset($business->internal)) {
                $business_obj["internal"] = $business->internal;
            }
            if (isset($business->mer)) {
                $business_obj["mer"] = $business->mer;
            }
            if (isset($business->duration)) {
                $business_obj["duration"] = $business->duration;
            }
			if (isset($business->specialityId)) {
            $business_obj["specialityId"] = $business->specialityId;
			}
			if (isset($business->specialityName)) {
                $business_obj["specialityName"] = $business->specialityName;
            }
			
			if (isset($business->referenceOrderId)) {
                $business_obj["referenceOrderId"] = $business->referenceOrderId;
            }
			if (isset($business->encid)) {
                $business_obj["encid"] = $business->encid;
            }
        }

        if ($businessId == 6 || $businessId == 7 || $businessId == 8) {
            if (isset($business->is_assessment)) {
                $business_obj["is_assessment"] = $business->is_assessment;
            }
            if (isset($business->is_continuous)) {
                $business_obj["is_continuous"] = $business->is_continuous;
            }
            if (isset($business->is_parent)) {
                $business_obj["is_parent"] = $business->is_parent;
            }
            if (isset($business->parent_id)) {
                $business_obj["parent_id"] = $business->parent_id;
            }
            if (isset($business->repeats)) {
                $business_obj["repeats"] = $business->repeats;
            }
            /* if (isset($business->repeats)) {
            $business_obj["repeats"] = $business->repeats;
            } */
            if (isset($business->sessionsPerDay)) {
                $business_obj["sessionsPerDay"] = $business->sessionsPerDay;
            }
            if (isset($business->frequency)) {
                $business_obj["frequency"] = $business->frequency;
            }
            if (isset($business->session_no)) {
                $business_obj["session_no"] = $business->session_no;
            } else {
                $business_obj["session_no"] = 1;
            }
            if (isset($business->assessment_id)) {
                $business_obj["assessment_id"] = $business->assessment_id;
            }
        }
		
		//RETURN ORDERS POSSIBLE IN MEDICINE AND EQUIPMENT ORDERS [ADD businessId == 11 FOR EQUIPMENT]
		if($businessId == 2 and (int)$business->is_return_order == 1)
		{
			$business_obj["is_return_order"] = $business->is_return_order;
			$business_obj["reference_order_id"] = $business->reference_order_id;
			$business_obj["return_order_items"] = $business->return_order_items;
		}

        //print_r( $business_obj);exit;
        return ($business_obj);

    }

    public function orderstatus($orderStatus, $source, $orderId)
    {
        $yr = date('y');
        $seqwodid = $this->utility->getNextSequence("WORKORDERID");
        $receipts_tracker_id = $this->utility->getNextSequence("receipts_tracker_id");
        $document_tracker_id = $this->utility->getNextSequence("document_tracker_id");
        $workorder_id = $this->utility->getNextSequence("WOID");
        $orderstatus_obj = array(
            "order_id" => $orderId,
            "receipts_tracker_id" => $receipts_tracker_id,
            "document_tracker_id" => $document_tracker_id,
            "order_status" => (string) $orderStatus,
            "created_date" => date("Y-m-d H:i:s"),
            "order_date" => $this->utility->getCurrenttime(),
            "last_updated_on" => date("Y-m-d") . "T" . date("H:i:s") . ".000Z",
            "last_updated_by" => $source,
            "workorder_id" => $workorder_id,
            "workorder_did" => "WO-000-" . $yr . "-" . $seqwodid);
        return $orderstatus_obj;

    }
    public function patientinfo($data, $orderStatus, $orderId)
    {
        //print_r($data);exit;
        //$facilityid = $data->facility_id;
        //$home_facility_id = $data->home_facility_id;

        //$pop = $this->utility->getFacilityName($facilityid);
        //$homepop = $this->utility->getFacilityName($home_facility_id);
        $date = $data->scheduled_date;
        $date = substr(date("c", strtotime($date)), 0, 19) . ".000Z";

        $patientinfo = array(
            "order_id" => (int) $orderId,
            "appointmentId" => $data->appointmentId,
            "source_of_referral" => $data->source_of_referral,
            "referred_officerid" => $data->referral_id,
            "referedby" => $data->referral_id,
            "order_status" => (string) $orderStatus,
            "mrn" => (string) $data->mrn,
			"parent_mrn" => (string) $data->parent_mrn,
            "patient_id" => (string) $data->patient_id,
            "name" => $data->name,
            "firstName" => $data->firstName,
            "lastName" => $data->lastName,
            "profilePhotoUrl" => $data->profilePhotoUrl,
            "age" => (string) $data->age,
            "gender" => $data->gender,
            "contact" => $data->contact,
            "email" => $data->email,
			"tags"=>$data->tags,
            "salutation" => $data->salutation,
            "address_id" => $data->address_id,
            "state" => $data->state,
            "city" => $data->city,
            "district" => $data->district,
            "landmark" => $data->landmark,
            "address" => $data->address,
            "pincode" => (string) $data->pincode,
            //"facility_did" => $pop['did'],
            //"facility_id" => (string) $facilityid,
            //"popname" => $pop['name'],
            //"home_facility_id" => $home_facility_id,
            //"home_popname" => $homepop['name'],
            "delivery_lat" => $data->delivery_lat,
            "delivery_lng" => $data->delivery_lng,
            "wallet_amount" => (int) $data->wallet_amount,
            "scheduled_date" => $date,
            "servicedate" => $this->dbo->date(strtotime($date)),
            "gross_amount" => (double) $data->gross_amount,
            "discount_amount" => (double) $data->discount_amount,
            "net_amount" => (double) $data->net_amount,
            "coupon_amount" => (double) $data->coupon_amount,
            "voucher_amount" => (double) $data->voucher_amount,
            "surge_amount" => (double) $data->surge_amount,
            "coupon" => $data->coupon,
            "service_subtype_id" => $data->service_subtype_id,
            "service_type" => $data->service_type,
            "slot_transaction_id" => $data->slot_transaction_id,
            "callNumber" => $data->callNumber,
            "lead_id" => $data->lead_id);

        if (isset($data->referral_mrn)) {
            $patientinfo["referred_mrn"] = $data->referral_mrn; //ADDED 24/04/19
        }
		
		if (isset($data->prescription_later)) {
            $patientinfo["prescription_later"] = $data->prescription_later; //ADDED 24/04/19
        }

        if (isset($data->gender_pref)) {
            $patientinfo["gender_pref"] = $data->gender_pref; //ADDED 24/04/19
        }

        if (isset($data->closedby)) {
            $patientinfo["closedby"] = $data->closedby; //ADDED 24/04/19
        }

        if (isset($data->final_delivery_date)) {
            $patientinfo["final_delivery_date"] = $data->final_delivery_date; //ADDED 06/05/19
        }

        if (isset($data->expected_delivery_date)) {
            $patientinfo["expected_delivery_date"] = $date; //ADDED 13/05/19
        }

        if (isset($data->package_parent_id)) {
            $patientinfo["package_parent_id"] = $data->package_parent_id; //ADDED 17/05/19
        }
		
		if(isset($data->end_date))
		{
			$end_date = $data->end_date;
			$end_date = substr(date("c", strtotime($end_date)), 0, 19) . ".000Z";
			$patientinfo["end_date"] = $end_date; //ADDED 06/06/19
		}
		
		if(isset($data->primaryCoach))
		{
			$patientinfo["primaryCoach"] = $data->primaryCoach; //ADDED 06/06/19
		}
		
		if(isset($data->wellness_speciality_code))
		{
			$patientinfo["wellness_speciality_code"] = $data->wellness_speciality_code; //ADDED 06/06/19
		}
		
		if(isset($data->prescription_later))
		{
			$patientinfo["prescription_later"] = (string)$data->prescription_later; //ADDED 14/06/19
		}

        //ONLY IN CASE OF IHS/COPRORATE ORDERS
        if (isset($data->corporate_id)) {
            $patientinfo["corporateid"] = $data->corporate_id; //ADDED 27/02/19
        }

        if (isset($data->corporate_name)) {
            $patientinfo["corporatename"] = $data->corporate_name; //ADDED 27/02/19
        }

        if (isset($data->corporate_nodeid)) {
            $patientinfo["corporate_nodeid"] = $data->corporate_nodeid; //ADDED 27/02/19
        }

        if (isset($data->ihs_batch_id)) {
            $patientinfo["ihs_batch_id"] = $data->ihs_batch_id; //ADDED 27/02/19
        }
		
		if(isset($data->application_no))
		{
		 $patientinfo["application_no"]=$data->application_no;//ADDED 30/05/19
		}
	
        //print_r($patientinfo);exit;
        return $patientinfo;
    }

    public function logcreation($orderreq, $comment = "")
    {
        $businessid = $orderreq['order']['patientinfo']['service_type'];
        $mosid = $orderreq['mode_of_service'];
        $component_no = $orderreq['active_component'];
        $statusno = $orderreq['OStatus'];

        $logarr = array();
        /* if($orderreq['channel'] == 1)
        {
        //DRAFT IN CASE OF CCO CREATION
        $logarr[] = array(
        "created_date" => $orderreq['order']['order_status']['created_date'],
        "role" => CHANNEL[(int)$orderreq['channel']],
        "order_status" => "17", //DRAFT ORDER
        "action" => "Order Created",
        "actionById" => $orderreq['createdById'],
        "actionByName" => $orderreq['createdByName'],
        'description' => "Order Created as draft",
        'wid' => $orderreq['wid'],
        'wodid' => $orderreq['wodid'],
        'reason' => "Draft Order creation",
        'comment' => $comment
        );
        } */

        $logarr[] = array(
            "created_date" => $orderreq['order']['order_status']['created_date'],
            "role" => CHANNEL[(int) $orderreq['channel']],
            "order_status" => (string) $orderreq['OStatus'],
            "action" => "Order Confirmed",
			"component_no" => $component_no,
            "status_name" => $this->utility->getStatusName($businessid, $mosid, $component_no, $statusno),
            "actionById" => $orderreq['createdById'],
            "actionByName" => $orderreq['createdByName'],
            'description' => "Order Confirmed",
            'wid' => $orderreq['wid'],
            'wodid' => $orderreq['wodid'],
            'reason' => "Order Confirmation",
            'comment' => $comment,
			 "createdDate" => $this->utility->getCurrenttime()
        );

        //print_r($order_structure);
        $orderreq["order_log"] = $logarr;

        return $orderreq;
        //$insert_response=$this->dbo->insert('masters','orderlog',$orderreq);

    }

    public function createworkorder($orderid, $workorder_id, $workorder_did, $scheduled_date, $orderitem, $status, $reason,$active_component)
    {
        $version = $this->config->getconfig("version", "");
        $current_time = substr(date("c", strtotime(date('Y-m-d H:i:s'))), 0, 19) . ".000Z";
        //$this->workorderpush($orderid,$workorder_id,$workorder_did,"0",$scheduled_date);
        $workdocument = array(
            "_id" => $workorder_id,
            "version" => $version,
            "wodid" => $workorder_did,
            "orderinfo" => array(
				"component_no"=>$active_component,
                "order_id" => (int) $orderid,
                "created_time" => $current_time,
                "modified_time" => $current_time,
                "order_status" => 0,
                "assignedto" => "0",
                "start_time" => "",
                "reached_time" => "",
                "delivery_time" => "",
                "completed_time" => "",
                "final_status" => 0,
                "cancel_time" => "",
                "reschedule_time" => "",
                "reason" => "",
                "orderitem" => $orderitem,
                "scheduled_date" => $scheduled_date,
            ),
        );

        return $workdocument;
        //$this->dbo=new Dbo;
        //$insert_response=$this->dbo->insert('masters','workorders',$workdocument);
    }
/*     function workorderpush($order_id,$workorder_id,$workorder_did,$status,$scheduled_date)
{
$db = getDBmasters();
$collection = $db->orders;
$collection->update(
array('_id' => (int)$order_id),
array('$push' => array('workorderinfo' => array('wid'=>$workorder_id,'wodid'=>$workorder_did,'wostatus'=>$status,"scheduled_date"=>$scheduled_date)))
);
} */

}
