<?php

include 'constant.php';

class Config
{

    public $globalvars;

    public function getconfig($key, $url)
    {
      // echo GLOBALVARS;exit;
	
        $this->globalvars= json_decode(GLOBALVARS,true);
	 
	   //echo $key.$url;exit;
        //$getvars = getStaticvariables();
        return $this->globalvars[$key] . $url;
    }

    public function category_map_drug()
    {
        return array(
            "1" => array("oms_category" => "1", "manufacturer_split" => 0), //General_medicine
            "2" => array("oms_category" => "1", "manufacturer_split" => 0), //General_medicine
            "3" => array("oms_category" => "1", "manufacturer_split" => 0), //General_medicine
            "4" => array("oms_category" => "1", "manufacturer_split" => 0), //General_medicine
            "5" => array("oms_category" => "1", "manufacturer_split" => 0), //General_medicine
            "6" => array("oms_category" => "1", "manufacturer_split" => 0), //General_medicine
            "7" => array("oms_category" => "1", "manufacturer_split" => 0), //General_medicine
            "10" => array("oms_category" => "1", "manufacturer_split" => 0), //General_medicine
            "11" => array("oms_category" => "2", "manufacturer_split" => 1), //Supplement
            "12" => array("oms_category" => "3", "manufacturer_split" => 1), //Ayurveda
            "13" => array("oms_category" => "4", "manufacturer_split" => 1), //Homeopathy
        );
    }
	
	//added by Pandu
	
	
		/* public function status_search_categories($status)
		{
			if((int)$status==1) //SCHEDULED ORDER
			{
				return array('$nin'=>array(17,8,6,11));
			}
			
			else if((int)$status==2)//COMPLETED ORDER
			{
				return array('$nin'=>array(6));
			}
			
			else if((int)$status==3)//Cancelled ORDERS
			{
				return array('$nin'=>array(8));
			}
			
			else if((int)$status==0)//PENDING ORDERS
			{
				return 17;
			}
		} */
		
		
		public function status_search_categories($status)
		{
			if((int)$status==1) //SCHEDULED ORDER
			{
				return array('$nin'=>array(17,8,6,11,505));
			}
			
			else if((int)$status==2)//COMPLETED ORDER
			{
				return array('$in'=>array(6,505));
			}
			
			else if((int)$status==3)//ALL ORDERS
			{
				return array('$nin'=>array(17,11));
			}
			
			else if((int)$status==4)//CANCELLED ORDERS
			{
				return array('$in'=>array(8,11));
			}
			
			else if((int)$status==0)//PENDING ORDERS
			{
				return 17;
			}
		}
  

	//end
	
	
    public function role_to_component($business, $role, $mode_of_service)
    {

        if ($business == "3") {

            $map_array["29"] = "7";
            $map_array["12"] = "1";
            $map_array["17"] = "8";
        } else if ($business == "4") {

            $map_array["29"] = "7";
        }

        return $map_array[$role];

    }

    /* $map_array =  array(
    "30"=>"7"
    ,"17"=>"8"
    );

    if($mode_of_service==1)
    {
    $map_array["12"]="1";
    }
    else if($mode_of_service==2)
    {
    $map_array["29"]="4";
    }

    return $map_array[$role]; */

    public function component_with_associate($service_type, $mode_of_service, $additional_parameter)
    {

        if ($service_type == 3) {
            if ($mode_of_service == 1) {
                $component = array(1, 7);
            } else {
                $component = array(5, 7);
            }

            if ($additional_parameter['report'] == 1) {
                array_push($component, 8);
            }

            $provider_component = array("component" => $component, "associate_component" => 7);

        } else if ($service_type == 4) {
            $component = array(3);
            if ($additional_parameter['report'] == 1) {
                array_push($component, 8);
            }
            $provider_component = array("component" => $component, "associate_component" => 7);
        }

        return $provider_component;
    }

    public function search_by_status($main_status, $payload)
    {

        if (isset($payload->type) == "created_date") {
            $date = "order.order_status.created_date";
        } else if (isset($payload->type) == "scheduled_date") {
            $date = "order.patientinfo.scheduled_date";
        }
        //print_r($date);exit;

        switch ($main_status) {
            //all orders
            case 0:
                $tmp = array(
                    "OStatus" => array(
                        '$in' => array(0, 1,505, 2, 3, 4,102,101,106,103,801, 5, 6, 7, 9, 10, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27,101,102,8,1000,1001,902,301),
                    ),
                );
                break;
            //scheduled orders
            case 1:
                $tmp = array(
                    "OStatus" => array(
                        '$in' => array(0, 7, 9, 10, 16, 17, 21, 24,1000,301),
                    ),
                );
                break;
            //past orders
            case 2:
                $tmp = array(
                    "OStatus" => array(
                        '$in' => array(6, 12, 22, 23),
                    ), 
                );
                break;
            //active orders
            case 3:
                $tmp = array(
                    "OStatus" => array(
                        '$in' => array(1, 2, 3, 4,505, 5, 13, 14, 15,16, 18, 19, 20,102,101,106,103,801,25,26,27,301,902),
                    ),
                );
                break;
            //cancelled orders
            case 4:
                $tmp = array(
                    "OStatus" => array(
                        '$in' => array(8),
                    ),
                );
				break;
            case 5:
                $tmp = array(
                    "OStatus" => array(
                        '$in' => array(16),
                    ),
                );
                break;
            case 6:
                $tmp = array(
                    "OStatus" => array(
                        '$in' => array(15),
                    ),
                );
                break;
                //pending orders for officer app
			case 7: 
            $tmp = array(
                "OStatus" => array(
                    '$in' => array(1, 2, 3, 4,505, 5, 13, 14, 15,16, 18, 19, 20,102,101,106,103,801),
                ),
            );
            break;
                // past orders for officer app
			case 8:
            $tmp = array(
                "OStatus" => array(
                    '$in' => array(6, 12, 22, 23,8),
                ), 
            );
            break;
		/*	case 9:
            $tmp = array(
                "OStatus" => array(
                    '$in' => array(15),
                ),
            );
            break;*/
                /*case 5:
        return array(
        "order.patientinfo.scheduled_date" => array(
        '$gte' =>$payload->from_date,
        '$lte' => $payload->to_date
        ),
        array($status => array(6))
        );
        break;  */
        }
        if (isset($date)) {
			$datedata=array();
			if(isset($payload->from_date) and $payload->from_date!=null)
			{
				$datedata['$gte']= $payload->from_date;
			}
			if(isset($payload->to_date) and $payload->to_date!=null)
			{
				$datedata['$lte']= $payload->to_date;
			}
			if(!empty($datedata))
			{
            $tmp[$date] = $datedata;
			}
        }
        return $tmp;

    }

    public function search_by_wo_status($main_status,$payload)
    {

        if (isset($payload->dateFilter) == "created_date") 
        {
            $date = "orderinfo.created_time";
        } 
        else if(isset($payload->dateFilter) == "scheduled_date") 
        {
            $date = "orderinfo.scheduled_date";
        }
        //print_r($date);exit;

        switch($main_status) 
        {
            //all orders
            case 1:
                $tmp = array(
                    "orderinfo.final_status" => array(
                        '$in' => array("6","106",6,106))
                    );
                break;
        }
        if (isset($date)) 
        {
			$datedata=array();
			if(isset($payload->fromDate) and $payload->fromDate!=null)
			{
				$datedata['$gte']= $payload->fromDate;
			}
			if(isset($payload->toDate) and $payload->toDate!=null)
			{
				$datedata['$lte']= $payload->toDate;
			}
			if(!empty($datedata))
			{
                $tmp[$date] = $datedata;
			}
        }
        return $tmp;

    }

    public function workorder_type_component_mapping($main_status)
    {
        //print_r($main_status);exit;
        switch((int)$main_status) 
        {
            //all orders
            case 1:
                $tmp = array(
                    "orderinfo.component_no" => array('$in' => array("1")
                    )
                );
                break;

            case 2:
                $tmp = array(
                    "orderinfo.component_no" => array('$in' => array("2")
                    )
                );
                break;
            
            case 3:
                $tmp = array(
                    "orderinfo.component_no" => array('$in' => array("3")
                    )
                );
                break;
            
            case 4:
                $tmp = array(
                    "orderinfo.component_no" => array('$in' => array("7")
                    )
                );
                break;
            
            case 5:
                $tmp = array(
                    "orderinfo.component_no" => array('$in' => array("8")
                    )
                );
                break;

            default:
                $tmp = array(
                    "orderinfo.component_no" => array('$in' => array("1","2","3","7","8")
                    )
                );
            break;

            
        }
        //print_r($tmp);exit;
        return $tmp;
    }

    public function search_by_status_appointment($main_status, $payload)
    {
        if(isset($payload->type) and $payload->type == "created_date")
        {
            //$date = "createdDate"; //WHEN USING appointments COLLECTION
			$date = "order.order_status.created_date";
        }
        else if(isset($payload->type) and $payload->type == "scheduled_date")
        {
            //$date = "scheduledTime"; //WHEN USING appointments COLLECTION
			$date = "order.patientinfo.scheduled_date";
        }

        switch ($main_status) {
            case 0:
                $tmp = array("status" => array(
                    '$in' => array(17, 0, 1, 2, 3, 4, 5, 6, 7),
                ),
                );
                break;
            case 1:
                $tmp = array(
                    "status" => array(
                        '$in' => array(0, 1, 2, 3, 4, 5, 6, 7),
                    ),
                );
                break;
            case 2:
                $tmp = array(
                    "status" => array(
                        '$in' => array(0, 1, 2),
                    ),
                );
                break;
            case 3:
                $tmp = array(
                    "status" => array(
                        '$in' => array(8),
                    ),
                );
                break;
            case 4:
                $tmp = array(
                    "status" => array(
                        '$in' => array(6),
                    ),
                );
                break;
            case 5:
                $tmp = array(
                    "OStatus" => array(
                        '$in' => array(8),
                    ),
                );
                break;
            //gcm completed
            case 6:
                $tmp = array(
                    "OStatus" => array(
                        '$in' => array(6),
                    ),
                );
                break;

            //gcm scheduled/rescheduled
            case 7:
                $tmp = array(
                    "OStatus" => array(
                        '$in' => array(0, 1, 7),
                    ),
                );
                break;

        }
        if (isset($date)) {
            $tmp[$date] = array(
                '$gte' => $payload->from_date,
                '$lte' => $payload->to_date,
            );
        }
        return $tmp;
    }

    public function ezetab()
    {
        $mode = EZEETAB_MODE; // sandbox || live
        $ezetap_sandbox = array(
            'appkey' => EZEETAB_APPKEY,
            'url' => EZEETAB_URL,
            'keytime' => array("00" => "30", "1" => "3", "2" => "30", "3" => "30", "4" => "30", "5" => "30", "30" => "30", "12" => "30", "13" => "30", "14" => "30"), //minute;  00: for transactional order
        );

        $ezetap_live = array(
            'appkey' => EZEETAB_APPKEY,
            'url' => EZEETAB_URL,
            'keytime' => array("00" => "30", "1" => "3", "2" => "30", "3" => "30", "4" => "30", "5" => "30", "30" => "30", "12" => "30", "13" => "30", "14" => "30"), //minute;  00: for transactional order
        );

        if ($mode == 'sandbox') {
            return $ezetap_sandbox;
        } else {
            return $ezetap_live;
        }
    }

    public function validate_omsapi_key()
    {
        if (getallheaders()['X-Api-Key'] != OMS_API_KEY) {
            $res = array("status" => "0", "code" => "403", "message" => "Un-authorized access, Invalid API Key");
            header("HTTP/1.1 401 Unauthorized");
            header('Content-Type: application/json');
            echo json_encode($res);
            die();
        }
    }
	//for invoice
	public function business_to_ahelp_map($businessId,$mode_of_service=null){
        if($businessId == 1){
            $component = 5;
        }
        else if($businessId==2)
        {
            $component =9;
        }
        else if($businessId==3 || $businessId==4)
        {
            $component = 7;
        }
        else
        {
            $component = 2;
        }

        return $component;
    }

}
