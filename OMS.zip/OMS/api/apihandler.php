<?php
class Apihandler
{
	function apirequest($request,$file)
	{
		$utility = new Utility;
		$uri = $request->getUri();
		$requestIP = $request->getServerParam('REMOTE_ADDR');
		$json_request = $request->getBody();
		$payload =  $utility->json_validate($json_request);
	//	$payload=json_decode($body); 
		$logobj=new Logapp;
		
		$ticket=rand(0,999999999999);
		
		//json_validate($body);
		
		$logobj->create_log($requestIP,$uri,$file,"API",200,"request",(string)$json_request,(string)$ticket);

		$payload->ticket=$ticket;

		return $payload;
	}
	
	function apiresponse($response,$file,$data,$ticket)
	{
		$logobj=new Logapp;
		$logobj->create_log("response","response",$file,"API",200,"response",(string)"",(string)$ticket);
		//print_r($data);
		return $response->withJson($data, 200);
	}
	
	
	function errorresponse($response,$file,$data,$ticket)
	{
		$logobj=new Logapp;
		$logobj->create_log("response","response",$file,"API",400,"response",(string)"",(string)$ticket);
		//print_r($data);
		return $response->withJson($data, 200);
	}
	function apiGetRequest($request){
                $requestIP = $request->getServerParam('REMOTE_ADDR');
                $payload = $request->getQueryParams();
                $payload = (object)$payload;
                $uri = $request->getUri();
                $file = getname();
                $logobj=new Logapp;
		$ticket=rand(0,999999999999);
		$logobj->create_log($requestIP,$uri,$file,"API",200,"request",json_encode($payload),(string)$ticket);
                
		$payload->ticket=$ticket;
                return $payload;
        }
	function create_log($file,$startTime, $payload, $response){
		//$LogStartTime = microtime(TRUE);
		$timeTaken = number_format(microtime(TRUE) - $startTime, 4);
		$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		$log = date('Y-m-d H:i:s').' '.$_SERVER['REMOTE_ADDR'].' '.$actual_link.' '.$timeTaken.' '. json_encode($payload).' '. json_encode($response) .' '.$_SERVER['HTTP_USER_AGENT']. PHP_EOL;
		$myfile = file_put_contents( __DIR__ . '/../logs/'.$file.'-'.date('Y-m-d').'.log', $log , FILE_APPEND | LOCK_EX);
	}
	
}



?>
