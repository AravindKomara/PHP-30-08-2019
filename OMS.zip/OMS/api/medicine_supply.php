<?php
require 'vendor/autoload.php';
require '../order.php';
require 'apihandler.php'; 
require_once '../action/MedicineSupplies.php';

ini_set('memory_limit', '-1');
date_default_timezone_set("Asia/Calcutta");
$app = new Slim\App();
//provided to CP
$app->post('/v1/customerSearch', 'customerSearch');
$app->post('/v1/wallet_transaction_history', 'wallet_transaction_history');
$app->post('/v1/checkpricefrommdm', 'checkpricefrommdm');
$app->post('/v1/getsource_of_referral', 'getsource_of_referral');
$app->post('/v1/getwalletamt', 'getwalletamt');
$app->post('/v1/search_item', 'search_item');
$app->post('/v1/getMedOrdersByFilter', 'getMedOrdersByFilter');
$app->post('/v1/getPrescriptionFromGcm', 'getPrescriptionFromGcm');
$app->post('/v1/getPrescriptionCP', 'getPrescriptionCP');
$app->post('/v1/getCorporate', 'getCorporateInfo');

//$app->post('/v1/deduct_wallet', 'deduct_wallet');
//$app->post('/v1/updatewalletamtinmdm', 'updatewalletamtinmdm');
//$app->post('/v1/creditwalletamtinmdm', 'creditwalletamtinmdm');
$app->post('/v1/gettransactionkeyforwallet', 'gettransactionkeyforwallet');
$app->post('/v1/coupenlist_all', 'coupenlist_all');
$app->post('/v1/coupenlist_orderwise', 'coupenlist_orderwise');
$app->post('/v1/common_coupendetails', 'common_coupendetails');
$app->post('/v1/AuthenticationPharmacist', 'vendorAuthenticationPharmacist');
$app->post('/v1/AuthenticationMediVendor', 'vendorAuthenticationMediVendor');
$app->post('/v1/vendor_list', 'vendor_list');
$app->post('/v1/GetVendorDetails', 'GetVendorDetails');
//Cart
$app->post('/v1/addItemsToCart', 'addItems_ToCart');
$app->post('/v1/getItemsFormCart', 'getItems_FormCart');
$app->post('/v1/deleteItemsFormCart', 'deleteItems_FromCart');
$app->post('/v1/create_log', 'logorder');
$app->post('/v1/log_details', 'userlog_details');

$app->post('/v1/editEquipmentOrder', 'editEquipmentOrder'); 
$app->post('/v1/updateEquipmentItem', 'updateEquipmentItem');
$app->post('/v1/updateOrder', 'updateOrder');
$app->post('/v1/updateMedicineItem', 'updateMedicineItem');
$app->post('/v1/updateRejectedOrder', 'updateRejectedOrder');

$app->post('/v1/get_customer_type','get_customer_type');

//for GCM API address fetch/update
$app->post('/v1/getAddress','getAddress');
$app->post('/v1/modifyAddress','modifyAddress');

//for prescription_upload_l2screen
$app->post('/v1/prescription_upload_l2screen','prescription_upload_l2screen');
$app->post('/v1/prescription_upload_link','prescription_upload_link');
$app->post('/v1/prescription_withorder','prescription_withorder');

//form OMS
$app->post('/v1/getorderdetails','getorderdetails');
$app->post('/v1/reject_order','reject_order');
$app->post('/v1/prescription/details','getPrescriptionByMrn');

$app->post('/v1/add_update_vendor_inOMS','add_update_vendor_inOMS');

$app->post('/v1/orders/lineitem/cancel','item_cancel_L2');
$app->post('/v1/orders/accept/vendor','order_accept_by_vendor');
$app->post('/v1/reminder_request','reminder_request');
$app->post('/v1/orders/invoice/upload/blob', 'upload_invoice_to_blob');
$app->post('/v1/deletePrescription','deletePrescription');
$app->get('/v1/orderexportcsv','orderexportcsv');



$app->run();
 
//code is shared with cp needs to be merged inline with order

function getname()
{
    return "medicine_supply";
}

function customerSearch($request, $response){
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $gcmobj = new Gcm;
    if(isset($payload->records_per_page) and isset($payload->pagenumber)) {
        $apiresponse = $gcmobj->customer_search(
			$payload->searchType,
			$payload->searchText,
			$payload->ticket,
            $payload->records_per_page,
            $payload->pagenumber
        );
    }else{
		$apiresponse = $gcmobj->customer_search($payload->searchText, $payload->ticket);
    }
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
	return $response;
}

//MDM APIS START
function wallet_transaction_history($request,$response)
{
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	// print_r(json_encode($payload));exit;
	$obj = new Mdm;
	$apiresponse = $obj->fetch_wallet_transaction_history($payload);         
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;       
}


function checkpricefrommdm($request, $response)
{
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	// print_r(json_encode($payload));exit;
	$obj = new Mdm;
	$apiresponse = $obj->checkPriceFromMDM($payload);         
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
}

//GET requests
function getsource_of_referral($request, $response){
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	$obj = new Mdm;
	$apiresponse = $obj->getSource_of_Referral();
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;	
}

function getwalletamt($request, $response)
{
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	$obj = new Mdm;
	$apiresponse = $obj->getWalletAmount($payload);         
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
	
}

function search_item($request, $response) 
{
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	//print_r($payload);exit;
	$obj = new MedicineSupplies;
	$apiresponse = $obj->DrugListLoad($payload);
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	//print_r(json_encode($apiresponse));
	return $response;
}

//MDM APIS END

//OrdersByFilter API
function getMedOrdersByFilter($request, $response) 
{
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	//print_r($payload);exit;
	$obj = new MedicineSupplies;
	$apiresponse = $obj->getmedordersbyfilter($payload);
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	//print_r(json_encode($apiresponse));
	return $response;
}

///22-02-2019
/*function updatewalletamtinmdm($request, $response)
{
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	// print_r(json_encode($payload));exit;
	$obj = new Mdm;
	$apiresponse = $obj->updatewalletamtinmdm($payload);         
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
}*/

/*function creditwalletamtinmdm($request, $response)
{
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	// print_r(json_encode($payload));exit;
	$obj = new Mdm;
	$apiresponse = $obj->creditwalletamtinmdm($payload);         
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
}*/

function gettransactionkeyforwallet($request, $response)
{
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	// print_r(json_encode($payload));exit;
	$obj = new Mdm;
	$apiresponse = $obj->gettransactionkeyforwallet($payload);         
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
}

function coupenlist_orderwise($request, $response)
{
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	// print_r(json_encode($payload));exit;
	$obj = new Mdm;
	$apiresponse = $obj->coupenlist_orderwise($payload);         
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
}

function common_coupendetails($request, $response)
{
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	//print_r(json_encode($payload));exit;
	$obj = new Mdm;
	$apiresponse = $obj->common_coupendetails($payload);         
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
}

function coupenlist_all($request, $response)
{
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	// print_r(json_encode($payload));exit;
	$obj = new MedicineSupplies;
	$apiresponse = $obj->coupenlist_all($payload);         
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
}


///

///CORPORATE GET REQUEST API
function get_customer_type($request, $response){
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	$obj = new Ihs;  
	$apiresponse = $obj->getCorporateInfo($payload);         
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
}
///


///////////////////////// From  OWN DB //////////////////////////

function getorderdetails($request, $response)
{
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	//print_r($payload);exit;
	$obj = new MedicineSupplies;
	$apiresponse = $obj->getOrderDetails($payload);
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	//print_r(json_encode($apiresponse));
	return $response;
}

function vendorAuthenticationPharmacist($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request,getname());
    $obj = new MedicineSupplies;
    $apiresponse = $obj->vendorAuthenticationPharmacist($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response,getname(), $apiresponse, $payload->ticket);
    return $response;
}

function vendorAuthenticationMediVendor($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request,getname());
    $obj = new MedicineSupplies;
    $apiresponse = $obj->vendorAuthenticationMediVendor($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response,getname(), $apiresponse, $payload->ticket);
    return $response;
}

function vendor_list($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request,getname());
    $obj = new MedicineSupplies;
    $apiresponse = $obj->Vendorlist($payload, $payload->ticket);
    //print_r($apiresponse);exit;
    $response = $apiobj->apiresponse($response,getname(), $apiresponse, $payload->ticket);
    return $response;
}

function GetVendorDetails($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request,getname());
    $obj = new MedicineSupplies;
    $apiresponse = $obj->VendorDetails($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response,getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getPrescriptionFromGcm($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, "cancel");
    $obj = new Gcm;
    $apiresponse = $obj->getPrescriptionFromGcm($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, "cancel", $apiresponse, $payload->ticket);
    return $response;
}

function getPrescriptionCP($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, "cancel");
    $obj = new Choice;
    $apiresponse = $obj->getPrescriptionCP($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, "cancel", $apiresponse, $payload->ticket);
    return $response;
   
}

function getCorporateInfo($request, $response) 
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, "cancel");
    $obj = new Ihs;
    $apiresponse = $obj->getCorporateInfo($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, "cancel", $apiresponse, $payload->ticket);
    return $response; 
}

function getAddress($request, $response)   
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Gcm;
    $apiresponse = $obj->getAddress($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response; 
}

function modifyAddress($request, $response) 
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, "cancel");
    $obj = new Gcm;
    $apiresponse = $obj->modifyAddress($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, "cancel", $apiresponse, $payload->ticket);
    return $response; 
}

function addItems_ToCart($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request,getname());
    $obj = new MedicineSupplies;
    $apiresponse = $obj->add_items_to_cart($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, "cancel", $apiresponse, $payload->ticket);
    return $response; 
}

function getItems_FormCart($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request,getname());
    $obj = new MedicineSupplies;
    $apiresponse = $obj->get_allitems_from_cart($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, "cancel", $apiresponse, $payload->ticket);
    return $response; 
}

function deleteItems_FromCart($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request,getname());
    $obj = new MedicineSupplies;
    $apiresponse = $obj->delete_items_from_cart($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, "cancel", $apiresponse, $payload->ticket);
    return $response; 
}

function prescription_upload_l2screen($request,$response){
    $apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request, getname());	
	$uploadedFiles = $request->getUploadedFiles();
	$mrn = $request->getParam('mrn');	
	$obj = new MedicineSupplies;
	$apiresponse = $obj->prescription_upload_l2screen($mrn,$uploadedFiles);         
    $response = $apiobj->apiresponse($response, "prescription_upload_l2screen", $apiresponse, $payload->ticket);	
	return $response;  
}

function logorder($request, $response)   
{
    $apiobj = new Apihandler; 
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new MedicineSupplies;
    $apiresponse = $obj->logorder($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;   
}

function userlog_details($request, $response)    
{
    $apiobj = new Apihandler; 
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new MedicineSupplies;
    $apiresponse = $obj->userlog_details($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;   
}

function editEquipmentOrder($request, $response){
    $apiobj = new Apihandler; 
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new MedicineSupplies;
    $apiresponse = $obj->editEquipmentOrder($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;   
}

function updateEquipmentItem($request, $response){
    $apiobj = new Apihandler; 
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new MedicineSupplies;
    $apiresponse = $obj->updateEquipmentItem($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;   
}

function updateOrder($request, $response)    
{
    $apiobj = new Apihandler; 
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new MedicineSupplies;
    $apiresponse = $obj->updateOrder($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;   
}

function updateMedicineItem($request, $response)    
{
    $apiobj = new Apihandler; 
    $payload = $apiobj->apirequest($request, getname());
    $obj = new MedicineSupplies;
    $apiresponse = $obj->updateMedicineItem($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;   
}

function updateRejectedOrder($request, $response)    
{
    $apiobj = new Apihandler; 
    $payload = $apiobj->apirequest($request, getname());
    $obj = new MedicineSupplies;
    $apiresponse = $obj->updateRejectedOrder($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;   
}

function reject_order($request, $response)    
{
    $apiobj = new Apihandler; 
    $payload = $apiobj->apirequest($request, getname());
    $obj = new MedicineSupplies;
    $apiresponse = $obj->rejectOrder($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;   
}

function prescription_upload_link($request,$response){
	
    $apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request, getname());	
	$uploadedFiles = $request->getUploadedFiles();
	$order_id = $request->getParam('order_id');
	
	$uploadedFrom = ($request->getParam('uploadedFrom')!=null)?$request->getParam('uploadedFrom'):"Prescription Link";	
	$obj = new MedicineSupplies;
	$apiresponse = $obj->prescription_upload_link($uploadedFiles,$order_id,$uploadedFrom);         
    $response = $apiobj->apiresponse($response, "prescription_upload_link", $apiresponse, $payload->ticket);	
	return $response;  
}

function prescription_withorder($request,$response){
    $apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request, getname());	
	$uploadedFiles = $request->getUploadedFiles();
	$order_id = $request->getParam('order_id');	
	$obj = new MedicineSupplies;
	$apiresponse = $obj->bytearray_prescription_withorder($payload,$payload->ticket);         
    $response = $apiobj->apiresponse($response, "prescription_upload_orderId", $apiresponse, $payload->ticket);	
	return $response;  
}

function getPrescriptionByMrn($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, "cancel");
    $obj = new MedicineSupplies;
    $apiresponse = $obj->getPrescriptionByMrn($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, "cancel", $apiresponse, $payload->ticket);
    return $response;
}

function add_update_vendor_inOMS($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new MedicineSupplies;
    $apiresponse = $obj->add_update_vendor_inOMS($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function item_cancel_L2($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new MedicineSupplies; 
    $apiresponse = $obj->item_cancel_L2($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function order_accept_by_vendor($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new MedicineSupplies; 
    $apiresponse = $obj->order_accept_by_vendor($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function reminder_request($request, $response){
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new MedicineSupplies; 
    $apiresponse = $obj->reminderRequest($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function upload_invoice_to_blob($request, $response){
    $apiobj = new Apihandler;
    $payload = $request->getParsedBody();
    $obj = new MedicineSupplies; 
    $apiresponse = $obj->upload_invoice_to_blob($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function deletePrescription($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, "cancel");
    $obj = new MedicineSupplies;
    $apiresponse = $obj->deletePrescription($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, "cancel", $apiresponse, $payload->ticket);
    return $response;
}

function orderexportcsv($request, $response){
    $payload = $request->getQueryParams(); 
    $medobj = new MedicineSupplies; 
    print_r($medobj->orderExportCSV($payload["vendorID"]));
}

