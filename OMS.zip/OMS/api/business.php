<?php
include 'business/care.php';
include 'business/imaging.php'; 
include 'business/medicine.php';
include 'business/wellness.php'; 
include 'business/pathology.php'; 
include 'business/econsultation.php'; 

?>