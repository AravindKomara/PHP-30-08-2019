<?php
require 'vendor/autoload.php';

require '../order.php';
include 'logapp.php';

ini_set('memory_limit', '-1');
date_default_timezone_set("Asia/Calcutta");
$app = new Slim\App();
//provided to doctorsapp
$app->post('/v1/createLog','createLog');


$app->run();

public function createLog($request,$response)
{
	$payload = json_decode($request->getBody());

	$ip = $payload->ip;
	$path = $payload->path;
	$file = $payload->file;
	$process = $payload->process;
	$type = $payload->type;
	$stage = $payload->stage;
	$message = $payload->message;
	$ticket = $payload->ticket;

	$log_obj = new logapp;
	$response = $log_obj->create_log($ip,$path,$file,$process,$type,$stage,$message,$ticket);
}


?>