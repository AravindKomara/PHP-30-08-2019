<?php
require 'vendor/autoload.php';
require '../order.php';
require 'apihandler.php';
require_once '../action/Rtct.php';

$app = new Slim\App();
$app->post('/v3/rtct/orders', 'get_orders');
$app->post('/v3/rtct/orders/event/set', 'set_event');
$app->post('/v3/rtct/orders/counts', 'get_orders_counts');
$app->post('/v3/rtct/orders/counts/by/status', 'get_orders_counts_by_status');
$app->post('/v3/rtct/orders/mark/pinned', 'mark_pinnable');
$app->post('/v3/rtct/orders/flow', 'get_order_flow');
$app->post('/v3/rtct/orders/single/detail', 'get_single_order_detail');
$app->run();

function getname()
{
    return "rtct";
}

function get_orders($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Rtct;
    $apiresponse = $obj->get_orders($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function get_orders_counts($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Rtct;
    $apiresponse = $obj->get_orders_counts($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function set_event($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Rtct;
    $apiresponse = $obj->set_event($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function mark_pinnable($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Rtct;
    $apiresponse = $obj->mark_pinnable($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
} 

function get_order_flow($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Rtct;
    $apiresponse = $obj->get_order_flow($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function get_single_order_detail($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Rtct;
    $apiresponse = $obj->get_single_order_detail($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function get_orders_counts_by_status($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Rtct;
    $apiresponse = $obj->get_orders_counts_by_status($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}
