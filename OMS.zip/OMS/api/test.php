<?php
require 'vendor/autoload.php';

require '../order.php'; 
require 'apihandler.php'; 
ini_set('memory_limit', '-1');
date_default_timezone_set("Asia/Calcutta");
$app = new Slim\App();
//provided to doctorsapp
$app->post('/v1/lineiteminfo','lineiteminfo');
$app->post('/v1/child','child');
$app->post('/v1/customerinfo','customerinfo');
$app->post('/v1/associateinfo','associateinfo');

 

$app->run();
	
	function child($request, $response)
	{
		$apiobj=new Apihandler;
		 $payload = $apiobj->apirequest($request,"test");
		 
		 $care=new finance;
		 $result=$care->getRefunds($payload->order);
		 $newResponse = $apiobj->apiresponse($response,"test",$result, $payload->ticket);
	   return $newResponse;
	}
	
	
	//code is shared with cp needs to be merged inline with order

	function lineiteminfo($request, $response)
	{
        $mdm=new Mdm;
		 
		
		 //var_dump($request);
		 $apiobj=new Apihandler;
		 $payload = $apiobj->apirequest($request,"test");
		
		 
		// json_decode($request->getBody());
		
		$order_item_payload = array('data'=>array(
												array("business"=>'3','itemcodes'=>
														array("TS1500DGHDPAE0012","TS02DRHALAS0202")
													 )
													 /* ,
												array("business"=>'9','itemcodes'=>
														array("TS1501ECNSRB00006")
													 )	 */	   
										   )
		);
		$apiresponse=$mdm->get_line_item_info($order_item_payload);
		//print_r($apiresponse);exit;
	    $newResponse = $apiobj->apiresponse($response,"test",$apiresponse, $payload->ticket);
	   return $newResponse;
	  //  print_r($data);	 
	}
	
	function customerinfo($request, $response)
	{
        $gcm=new Gcm;
		$payload = json_decode($request->getBody());

	 	$data=$gcm->get_mrn_address_info(explode(',',$payload->mrnIds),explode(',',$payload->addressIds));
		  
	    print_r($data);	
	}
      
	  function associateinfo($request, $response)
	{
        $associate=new Associate;
		$payload = json_decode($request->getBody());

	 	$data=$associate->get_associate_info($payload);
		  
	    print_r($data);	
	}
        
        
	

 ?>