<?php

require 'vendor/autoload.php';
require '../order.php';
require 'apihandler.php';

ini_set('memory_limit', '-1');
date_default_timezone_set("Asia/Calcutta");
$app = new Slim\App();
//provided to CP
$app->get('/v1/invoice', 'invoice');
$app->get('/v1/prescriptionprint', 'prescriptionprint');
$app->get('/v1/sampleCollectionMemo', 'sampleCollectionMemo');
$app->post('/v1/invoice', 'invoicePost');
$app->get('/v1/shipmentlabel', 'shipmentlabel');
$app->post('/v1/orders', 'getorders');
$app->post('/v1/orderallocation', 'orderallocation');
$app->post('/v1/orderunallocation', 'orderunallocation');
$app->post('/v1/ordercreation_chiss', 'ordercreation_chiss');
$app->post('/v1/order_reschedule_chiss', 'order_reschedule_chiss');
$app->post('/v1/fetch_officers', 'fetch_officers');
$app->post('/v1/ordertrack', 'ordertrack');
$app->post('/v1/fetch_slots', 'fetch_slots');
$app->post('/v1/fetch_appointment', 'fetch_appointment_chiss');
$app->post('/v1/appointmentcreation_chiss', 'appointmentcreation_chiss');
$app->post('/v1/appointmentreschedule_chiss', 'appointmentreschedule_chiss');
$app->post('/v1/orderreject_chiss', 'orderreject_chiss');
$app->post('/v1/ordercancel_chiss', 'ordercancel_chiss');
$app->get('/v1/unAssignedOrdersChiss', 'unAssignedOrdersChiss'); //GET REQUEST
$app->post('/v1/order/change/status', 'change_order_status');
$app->post('/v1/order/change/status/forlineitem', 'change_order_status_forlineitem');
$app->post('/v1/order/allocation/doctor', 'doctor_allocation');
$app->post('/v1/order/lineitem/crud', 'lineitem_crud');
$app->post('/v1/order/lineitem/crud/multi', 'lineitem_crud_multi'); // remove after use
$app->post('/v1/returnOfficerCharge', 'returnOfficerCharge');
$app->post('/v1/appointment/change/status', 'change_appointment_status');
$app->post('/v1/order/processing/sample_submission', 'processing_at_delivery_officer');
$app->post('/v1/orders/get_cart', 'getCart');
$app->post('/v1/orders/payments/link/send', 'send_payment_link');
$app->post('/v1/orders/payments/pg/ezetap/callback', 'ezetap_push_notification');
$app->post('/v1/orders/notification/eventdata', 'get_notification_event_data');
$app->post('/v1/orders/notification/send/prescription-upload-link', 'send_prescription_upload_link');
$app->post('/v1/orders/notification/feedback/capture', 'capture_feedback');
$app->post('/v1/orders/complete/manually', 'complete_order_manually');
$app->post('/v1/orders/cancel/manually', 'cancel_order_manually');
$app->post('/v1/getOrderWithBillingDetails', 'getOrderWithBillingDetails');
$app->post('/v1/received_themoney_from_officer', 'received_themoney_from_officer');
$app->post('/v1/fetchOrders', 'fetchOrders');
$app->post('/v1/fetchAppointments', 'fetchAppointments');
$app->post('/v1/orderCancel', 'order_cancel');
$app->post('/v1/orderaction_chiss', 'orderaction_chiss');
$app->post('/v1/cancelItem', 'cancelItem');
$app->post('/v1/generateReceiptInfo', 'generateReceiptInfo');
$app->post('/v1/generateReceipt', 'generateReceipt');
$app->post('/v1/generateBill', 'generateBill');
$app->post('/v1/updateReceiptPaymentStatus', 'updateReceiptPaymentStatus');
$app->post('/v1/updateSampleInfo', 'updateSampleInfo');
$app->post('/v1/addOrderItem', 'addOrderItem');
$app->post('/v1/generateDocumentInfo', 'generateDocumentInfo');
$app->post('/v1/getPrescriptioninfo', 'getPrescriptioninfo');
$app->post('/v1/fetch_associate_isp_data', 'fetch_associate_isp_data');
$app->post('/v1/getSampleTypeforBarcode', 'getSampleTypeforBarcode');
$app->post('/v1/getReceiptinfoByMhoID', 'getReceiptinfoByMhoID');
$app->post('/v1/insertProcessCompletedTime', 'insertProcessCompletedTime');
$app->post('/v1/UpdateBarcode', 'UpdateBarcode');
$app->post('/v1/getBillingInfo', 'getBillingInfo');
$app->post('/v1/getDebriefRecord', 'getDebriefRecordByAppointmentID');
$app->post('/v1/order_history', 'orderHistory');
$app->post('/v1/ItemCodeCountByCity', 'getItemCodeCountByCity');
$app->post('/v1/generateTicket', 'generateTicket');
$app->post('/v1/allocate_order', 'allocate_order');
$app->post('/v1/getOrderCount', 'getOrderCountByState');
$app->post('/v1/customerclassification', 'customerClassification');
$app->post('/v1/Appointments', 'getAppointmentsDetails');
$app->post('/v1/updateReceipts', 'updateReceiptsforMho');
$app->post('/v1/cashReceiptsByOfficerID', 'getCashReceiptsByMhoID');
$app->post('/v1/coupon_count', 'couponUsageCount');
$app->post('/v1/order/change/itemStatusUpdate', 'change_order_item_status');
$app->get('/v1/updateAhelpIntdbFromOms', 'update_ahelp_intdb_from_oms');
$app->get('/v1/updatePhelpIntdbFromOms', 'update_phelp_intdb_from_oms');
$app->post('/v1/order_pods_update', 'order_pods_update');
$app->post('/v1/OrderStatusInfoByMrn', 'getAllOrderStatusInfoByMrn');
$app->post('/v1/getOrderCountByMOS', 'getOrderCountByMOS');
$app->post('/v1/BillInfo', 'getBillDetails');
$app->get('/v1/receipt_details', 'receipt_details');
$app->post('/v1/followup_eligiblity_check', 'getFollowUpInfo');
$app->post('/v1/send_careplan_gcm', 'gcmCareplan');
$app->post('/v1/customer_invoice', 'customer_invoice');
$app->post('/v1/refund_info', 'refund_info');
$app->post('/v1/update/refund/info', 'update_refund_info');
$app->post('/v1/cp_order', 'cp_order');
$app->post('/v1/unique', 'getUniqueStates');
$app->post('/v1/order/refund', 'refundedOrders');
$app->post('/v1/cp/change/order/status', 'cp_changeorder');
$app->post('/v1/receipts/cash', 'getCashReceipts');
$app->post('/v1/wellnesscreation_chiss', 'wellnesscreation_chiss');
$app->post('/v1/customerUpdate', 'customerUpdate');
$app->post('/v1/prescription/remove', 'removePrescriptions');
$app->post('/v1/penalty/details', 'getDetails');
$app->post('/v1/penalty/payable', 'getAllPendingPaidDetails');
$app->post('/v1/payment/denial', 'paymentDenial');
$app->post('/v1/schedule/date/update', 'updateScheduleDate');
$app->post('/v1/addCriteriaInfo', 'addCriteriaInfo');
$app->post('/v1/getDependentOrders', 'getDependentOrders');
$app->post('/v1/getCampaignMrns', 'getCampaignMrns');
$app->post('/v1/order/search','orderSearch'); 
$app->get('/v1/getThirdPartyReceipts', 'getThirdPartyReceipts');
$app->get('/v1/applicationNo/{application_no}','applicationNoDetails');
$app->post('/v1/update/la/lo/pincode','changeLatLongPincode'); 

//$app->post('/v1/create/refund','refundCreation'); 
$app->post('/v1/refund/generate_waiver','generate_refund_waiver');
//METAL GRADING
//$app->post('/v1/customerclassification','customerclassification');

//added by pandu 26-4-2019
$app->post('/v1/getPenaltiesAndPendingPayments', 'getPenaltiesAndPendingPayments');
$app->post('/v1/payPenaltiesAndPendingPayments', 'payPenaltiesAndPendingPayments');
$app->post('/v1/receiptsPendingToCH', 'receiptsPendingToCH');
$app->post('/v1/phelpCashSubmission', 'phelpCashSubmission');

$app->post('/v1/addmedicinevendor', 'addmedicinevendor');
$app->get('/v1/shipment_lable', 'shipment_lable');

//MDM API
$app->get('/v1/requestForCallbackMdm', 'requestForCallbackMdm'); //GET REQUEST

//end

$app->run();

//code is shared with cp needs to be merged inline with order

function getname()
{
    return "operation";
}

function order_cancel($request, $response)
{

    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, "cancel");
    $obj = new Orderinfo;
    $apiresponse = $obj->order_cancel($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, "cancel", $apiresponse, $payload->ticket);
    return $response;

}

function invoice($request, $response)
{
    $payload = $request->getQueryParams();
    $finance = new Finance;
    print_r($finance->invoice($payload["OrderID"]));
}

function prescriptionprint($request, $response)
{
    $payload = $request->getQueryParams();
    $finance = new Finance;
    print_r($finance->prescriptionprint($payload["OrderID"]));
}

function sampleCollectionMemo($request, $response)
{
    $payload = $request->getQueryParams();
    $pathology = new Pathology;
    print_r($pathology->sampleCollectionMemo($payload["OrderID"]));
}

function invoicePost($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, "cancel");
    $finance = new Finance;
    //$apiresponse = $obj->order_cancel($payload, $payload->ticket);
    $apiresponse = $finance->invoice($payload->order_id, $payload->downloadtype = "");
    $response = $apiobj->apiresponse($response, "cancel", $apiresponse, $payload->ticket);
    return $response;
}

function shipmentlabel($request, $response)
{
    $payload = $request->getQueryParams();
    //print_r($payload);exit;
    $finance = new Finance;
    print_r($finance->shipmentlabel($payload["OrderID"]));
}

function orderunallocation($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->unAllocateOrders($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function appointmentcreation_chiss($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->chiss_appointment_creation($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;

    /* $payload = json_decode($request->getBody());
$obj = new Orderinfo;
$response = $obj->chiss_appointment_creation($payload);
print_r($response);
exit; */
}
function getorders($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->getordersbyfilter($payload);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function orderallocation($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->manual_allocation($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function ordertrack($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->order_track($payload, $ticket);

    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);

    return $response;
}

function ordercreation_chiss($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->chiss_order_creation($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function wellnesscreation_chiss($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->chiss_wellness_creation($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getOrderCountByMOS($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Econsultation;
    $apiresponse = $obj->getOrderCountByMOS($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function order_reschedule_chiss($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->chiss_api_reschedule($payload, $payload->ticket);

    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;

}

function fetch_slots($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->get_available_slots($payload, $payload->ticket);

    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function fetch_appointment_chiss($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Chiss;
    $apiresponse = $obj->fetch_appointment($payload, $payload->ticket);

    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;

}

function fetch_officers($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->get_available_officers($payload, $payload->ticket);

    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;

}

function appointmentreschedule_chiss($request, $response)
{

    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->chiss_appointment_reschedule($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;

}

//Handles accept,start,completed statuses
function orderaction_chiss($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->chiss_order_action($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function orderreject_chiss($request, $response)
{

    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->chiss_order_rejection($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;

}

function ordercancel_chiss($request, $response)
{

    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->chiss_order_cancel($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;

}

function unAssignedOrdersChiss($request, $response)
{
    //$payload = $request->getQueryParams();
    $apiobj = new Apihandler;
    $payload = $apiobj->apiGetRequest($request);
    $obj = new Orderinfo;
    //print_r($pathology->sampleCollectionMemo($payload["OrderID"]));
    $apiresponse = $obj->unAssignedOrdersChiss($payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function change_order_status($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/OrderWorkFlow.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new OrderWorkFlow;
    $apiresponse = $obj->change_order_status($payload, $payload->ticket);
    $apiobj->create_log('orderworkflow', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function change_order_status_forlineitem($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/OrderWorkFlow.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new OrderWorkFlow;
    $apiresponse = $obj->change_order_status_forlineitem($payload, $payload->ticket);
    $apiobj->create_log('orderworkflow', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function doctor_allocation($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/OrderWorkFlow.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new OrderWorkFlow;
    $apiresponse = $obj->doctor_allocation($payload, $payload->ticket);
    $apiobj->create_log('orderworkflow', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function change_appointment_status($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/AppointmentWorkFlow.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new AppointmentWorkFlow;
    $apiresponse = $obj->change_appointment_status($payload, $payload->ticket);
    $apiobj->create_log('appointmentworkflow', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function get_notification_event_data($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/Notification.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Notification;
    $apiresponse = $obj->get_notification_event_data($payload, $payload->ticket);
    $apiobj->create_log('notification', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function send_prescription_upload_link($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/Notification.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Notification;
    $apiresponse = $obj->send_prescription_upload_link($payload, $payload->ticket);
    $apiobj->create_log('notification', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function capture_feedback($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/Notification.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Notification;
    $apiresponse = $obj->capture_feedback($payload, $payload->ticket);
    $apiobj->create_log('notification', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getCart($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->getCart($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function processing_at_delivery_officer($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/OrderWorkFlow.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new OrderWorkFlow;
    $apiresponse = $obj->processing_at_delivery_officer($payload, $payload->ticket);
    $apiobj->create_log('orderworkflow', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function send_payment_link($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/Payments.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Payments;
    $apiresponse = $obj->send_payment_link($payload, $payload->ticket);
    $apiobj->create_log('payment', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function ezetap_push_notification($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/Payments.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Payments;
    $apiresponse = $obj->ezetap_push_notification($payload, $payload->ticket);
    $apiobj->create_log('payment', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getOrderWithBillingDetails($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->getOrderWithBillingDetails($payload);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function received_themoney_from_officer($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->received_themoney_from_officer($payload);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}
function fetchOrders($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->getMyOrders($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getAppointmentsDetails($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Econsultation;
    $apiresponse = $obj->getAppointmentsDetails($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function customerclassification($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Gcm;
    $apiresponse = $obj->customerClassification($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function customerUpdate($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Gcm;
    $apiresponse = $obj->customerUpdate($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function fetchAppointments($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->getMyAppointments($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function updateReceiptsforMho($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Finance;
    $apiresponse = $obj->updateReceiptsforMho($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getCashReceiptsByMhoID($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Finance;
    $apiresponse = $obj->getCashReceiptsByMhoID($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function couponUsageCount($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->couponUsageCount($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getAllOrderStatusInfoByMrn($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->getAllOrderStatusInfoByMrn($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function cp_changeorder($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->change_order_cp($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

//added by Pandu 22.1.2019

function cancelItem($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderupdation;
    $apiresponse = $obj->cancelItem($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

//CAN FIND THE FUNCTION    IN finance.php and API call below
/* function generateReceiptInfo($request,$response)
{
$apiobj=new Apihandler;
$payload = $apiobj->apirequest($request,getname());
//print_r($payload);exit;
$obj = new Orderupdation;
$apiresponse = $obj->generateReceiptInfo($payload, $payload->ticket);
$response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
return $response;
} */

///FINANCE.PHP APIS
function generateReceiptInfo($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Finance;
    //$apiresponse = $obj->generateReceiptInfo($payload, $payload->ticket);
    $apiresponse = $obj->generateReceipt($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

//NEW FUNCTION FOR RECEIPT GENERATION
function generateReceipt($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Finance;
    $apiresponse = $obj->generateReceipt($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function generateBill($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Finance;
    $apiresponse = $obj->generateBill($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

///

function updateReceiptPaymentStatus($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderupdation;
    $apiresponse = $obj->updateReceiptPaymentStatus($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function updateSampleInfo($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderupdation;
    $apiresponse = $obj->updateSampleInfo($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function addOrderItem($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderupdation;
    $apiresponse = $obj->addOrderItem($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function generateDocumentInfo($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderupdation;
    $apiresponse = $obj->generateDocumentInfo($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getPrescriptioninfo($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderupdation;
    $apiresponse = $obj->getPrescriptioninfo($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}
/// added by prakhar..............

function getSampleTypeforBarcode($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->getSampleTypeforBarcode($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function generateTicket($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new SugarCRM;
    $apiresponse = $obj->raise_ticket($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function orderHistory($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->orderHistory($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;

}

function getReceiptinfoByMhoID($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Finance;
    $apiresponse = $obj->getReceiptinfoByMhoID($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;

}

function insertProcessCompletedTime($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderupdation;
    $apiresponse = $obj->insertProcessCompletedTime($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;

}

function UpdateBarcode($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderupdation;
    $apiresponse = $obj->UpdateBarcode($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getBillingInfo($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Finance;
    $apiresponse = $obj->getBillingInfo($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;

}

function getDebriefRecordByAppointmentID($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->getDebriefRecordByAppointmentID($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getItemCodeCountByCity($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->getItemCodeCountByCity($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getOrderCountByState($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->getOrderCountByState($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function allocate_order($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderupdation;
    $apiresponse = $obj->allocate_order($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function receipt_details($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apiGetRequest($request, getname());
    $obj = new Finance;
    $apiresponse = $obj->receiptDetails($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function gcmCareplan($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Gcm;
    $apiresponse = $obj->send_care_plan($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function refund_info($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Finance;
    $apiresponse = $obj->getRefundInfo($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function update_refund_info($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Finance;
    $apiresponse = $obj->updateRefundInfo($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getCashReceipts($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Finance;
    $apiresponse = $obj->getCashReceipts($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

// added by prasanna......

function change_order_item_status($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Associate;
    $apiresponse = $obj->change_order_item_status($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function update_ahelp_intdb_from_oms($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apiGetRequest($request, getname());
    $obj = new Associate;
    $apiresponse = $obj->update_ahelp_intdb_from_oms($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function update_phelp_intdb_from_oms($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apiGetRequest($request, getname());
    $obj = new Associate;
    $apiresponse = $obj->update_phelp_intdb_from_oms($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function order_pods_update($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Associate;
    $apiresponse = $obj->order_pods_update($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function fetch_associate_isp_data($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Chiss;
    $apiresponse = $obj->fetch_associate_isp_data($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getBillDetails($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Finance;
    $apiresponse = $obj->getBillDetails($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getUniqueStates($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->getUniqueStates($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function orderSearch($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->orderSearchByWO($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function refundedOrders($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->refundedOrders($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getFollowUpInfo($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Econsultation;
    $apiresponse = $obj->getFollowUpInfo($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}
//added by prakhar
function customer_invoice($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    require_once '../action/Notification.php';
    //print_r($payload);exit;
    $obj = new Notification;
    $apiresponse = $obj->customerInvoice($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}
//added by pandu 26-4-2019

function getPenaltiesAndPendingPayments($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Finance;
    $apiresponse = $obj->getPenaltiesAndPendingPayments($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function payPenaltiesAndPendingPayments($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Finance;
    $apiresponse = $obj->payPenaltiesAndPendingPayments($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function receiptsPendingToCH($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Finance;
    $apiresponse = $obj->receiptsPendingToCH($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function phelpCashSubmission($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Finance;
    $apiresponse = $obj->phelpCashSubmission($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

// end of code pandu 26-4-2019
function lineitem_crud($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/LineItems.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new LineItems;
    $apiresponse = $obj->crud($payload, $payload->ticket);
    $apiobj->create_log('lineitems', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function lineitem_crud_multi($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/LineItemsMulti.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new LineItemsMulti;
    $apiresponse = $obj->crud($payload, $payload->ticket);
    $apiobj->create_log('lineitems', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function returnOfficerCharge($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/LineItemsMulti.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new LineItemsMulti;

    //ADDITIONAL DETAILS TO PAYLOAD
    $payload->isDROChargesApplied = true;
    $payload->update_in_order = false;
    $payload->action = 5;

    $apiresponse = $obj->crud($payload, $payload->ticket);
    $apiobj->create_log('lineitems', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function removePrescriptions($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, "cancel");
    $obj = new Orderinfo;
    $apiresponse = $obj->removePrescriptions($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, "cancel", $apiresponse, $payload->ticket);
    return $response;
}

function getDetails($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, "cancel");
    $obj = new Orderinfo;
    $apiresponse = $obj->getPenaltyRefundDetails($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, "cancel", $apiresponse, $payload->ticket);
    return $response;
}

function getAllPendingPaidDetails($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->getAllPendingPaidDetails($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function paymentDenial($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->paymentDenial($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function addmedicinevendor($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->addMedicineVendor($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

/* function customerclassification($request, $response)
{
$apiobj = new Apihandler;
$payload = $apiobj->apirequest($request, getname());
$obj = new Orderinfo;
$apiresponse = $obj->customerclassification($payload, $payload->ticket);
$response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
return $response;
}
 */
function shipment_lable($request, $response)
{
    $payload = $request->getQueryParams();
    //print_r($payload);exit;
    $finance = new Finance;
    print_r($finance->shipmentLable($payload["OrderID"]));
}

function requestForCallbackMdm($request, $response)
{
    //$payload = $request->getQueryParams();
    $apiobj = new Apihandler;
    $payload = $apiobj->apiGetRequest($request);
    $obj = new Mdm;
    $apiresponse = $obj->requestForCallbackMdm($payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function updateScheduleDate($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $apiresponse = $obj->updateScheduleDate($payload, $ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function addCriteriaInfo($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->addCriteriaInfo($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getDependentOrders($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->getDependentOrders($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getCampaignMrns($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->getCampaignMrns($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function getThirdPartyReceipts($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apiGetRequest($request, getname());
    $obj = new Finance;
    $apiresponse = $obj->getThirdPartyReceipts($payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function complete_order_manually($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/OrderWorkFlow.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new OrderWorkFlow;
    $apiresponse = $obj->complete_order_manually($payload, $payload->ticket);
    $apiobj->create_log('orderworkflow', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function cancel_order_manually($request, $response)
{
    $LogStartTime = microtime(true);
    require_once '../action/OrderWorkFlow.php';
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Orderinfo;
    $payload->is_manual = 1;
    $payload->source = 2; // CCO
    $payload->order_id = $payload->order_ids;
    $payload->categoryId = 1;
    $payload->subCategoryId = 1;
    $apiresponse = $obj->order_cancel($payload, $payload->ticket);
    $apiobj->create_log('orderworkflow', $LogStartTime, $payload, $apiresponse);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function applicationNoDetails($request, $response)
{
    $payload1 = $request->getAttribute('application_no');
    //print_r($payload);exit;
    //$payload = $request->getQueryParams(); 
	$apiobj = new Apihandler;
	$payload = $apiobj->apiGetRequest($request);
	$obj = new Orderinfo;
    $apiresponse = $obj->applicationNoDetails($payload1);
	$response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function changeLatLongPincode($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Orderinfo;
    $apiresponse = $obj->changeLatLongPincode($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function generate_refund_waiver($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new Finance;
    $apiresponse = $obj->generate_refund_waiver($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}
