<?php

require 'vendor/autoload.php';
require '../order.php';
require 'apihandler.php';

ini_set('memory_limit', '-1');
date_default_timezone_set("Asia/Calcutta");
$app = new Slim\App();

//Common Track
$app->get('/v1/trackOrder', 'trackOrder');

//DelhiveryExpress
$app->get('/v1/delhivery/pincodeVerification','pincodeVerification');
$app->get('/v1/delhivery/multiplePincodeVerification','multiplePincodeVerification');
$app->post('/v1/delhivery/createWarehouse', 'createWarehouse');
$app->post('/v1/delhivery/updateWarehouse', 'updateWarehouse');
$app->get('/v1/delhivery/bulkWayBills', 'bulkWayBills');
$app->get('/v1/delhivery/delhiverysingleWayBill', 'singleWayBill');
$app->post('/v1/delhivery/createOrder', 'createOrder');
$app->post('/v1/delhivery/updateOrder', 'updateOrder');
$app->post('/v1/delhivery/cancelOrder', 'cancelOrder');
$app->get('/v1/delhivery/trackOrder', 'trackOrder');
$app->get('/v1/delhivery/shippingChargesInvoice', 'shippingChargesInvoice');
$app->get('/v1/delhivery/createPackageSlip', 'createPackageSlip');
$app->post('/v1/delhivery/createPickupReq', 'createPickupReq');
$app->post('/v1/delhivery/updateDelStatusDetails','updateDelStatusDetails');
//End DelhiveryExpress



$app->run();

//code is shared with cp needs to be merged inline with order
function getname() {
    return "external_delivery";
}

function message_in_response(){
	$message=array(
		"Deliv_01"=>"",
		"Deliv_02"=>"",
		"Deliv_03"=>"",
		"Deliv_04"=>""
	);
}

//ADDED 17/06/2019
function pincodeVerification($request, $response) {
    $apiobj = new Apihandler;
    $payload = $apiobj->apiGetRequest($request);
    $delhiveryExpressLibrary = new DelhiveryExpressLibrary;
    $apiResponse = $delhiveryExpressLibrary->getPincode($payload, $payload->ticket,$multiplincode=false);
    $response = $apiobj->apiresponse($response, getname(), $apiResponse, $payload->ticket);
    return $response;
}

function multiplePincodeVerification($request, $response) {
    $apiobj = new Apihandler;
    $payload = $apiobj->apiGetRequest($request);
    $delhiveryExpressLibrary = new DelhiveryExpressLibrary;
    $apiResponse = $delhiveryExpressLibrary->getPincode($payload, $payload->ticket,$multiplincode=true);
    $response = $apiobj->apiresponse($response, getname(), $apiResponse, $payload->ticket);
    return $response;
}

function createWarehouse($request, $response) {
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request);
    $delhiveryExpressLibrary = new DelhiveryExpressLibrary;
    $apiResponse = $delhiveryExpressLibrary->createWarehouse($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiResponse, $payload->ticket);
    return $response;
}

function updateWarehouse($request, $response) {
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request);
    $delhiveryExpressLibrary = new DelhiveryExpressLibrary;
    $apiResponse = $delhiveryExpressLibrary->updateWarehouse($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiResponse, $payload->ticket);
    return $response;
}

function bulkWayBills($request, $response) {
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request);
    $delhiveryExpressLibrary = new DelhiveryExpressLibrary;
    $apiResponse = $delhiveryExpressLibrary->bulkWayBills($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiResponse, $payload->ticket);
    return $response;
}

function singleWayBill($request, $response) {
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request);
    $delhiveryExpressLibrary = new DelhiveryExpressLibrary;
    $apiResponse = $delhiveryExpressLibrary->singleWayBill($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiResponse, $payload->ticket);
    return $response;
}

function createOrder($request, $response) {
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request);
    $delhiveryExpressLibrary = new DelhiveryExpressLibrary;
    $apiResponse = $delhiveryExpressLibrary->createOrder($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiResponse, $payload->ticket);
    return $response;
}

function updateOrder($request, $response) {
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request);
    $delhiveryExpressLibrary = new DelhiveryExpressLibrary;
    $apiResponse = $delhiveryExpressLibrary->updateOrder($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiResponse, $payload->ticket);
    return $response;
}

function cancelOrder($request, $response) {
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request);
    $delhiveryExpressLibrary = new DelhiveryExpressLibrary;
    $apiResponse = $delhiveryExpressLibrary->cancelOrder($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiResponse, $payload->ticket);
    return $response;
}

function trackOrder($request, $response) {
    $apiobj = new Apihandler;
    $payload = $apiobj->apiGetRequest($request);
    $delhiveryExpressLibrary = new DelhiveryExpressLibrary;
    $apiResponse = $delhiveryExpressLibrary->trackOrder($payload, $payload->ticket);
    if(isset($payload->uiType) && $payload->uiType != 'r'){
        return $apiResponse;
    }
    $response = $apiobj->apiresponse($response, getname(), $apiResponse, $payload->ticket);
    return $response;
}

function shippingChargesInvoice($request, $response) {
    $apiobj = new Apihandler;
    $payload = $apiobj->apiGetRequest($request);
    $delhiveryExpressLibrary = new DelhiveryExpressLibrary;
    $apiResponse = $delhiveryExpressLibrary->shippingChargesInvoice($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiResponse, $payload->ticket);
    return $response;
}

function createPackageSlip($request, $response) {
    $apiobj = new Apihandler;
    $payload = $apiobj->apiGetRequest($request);
    $delhiveryExpressLibrary = new DelhiveryExpressLibrary;
    $apiResponse = $delhiveryExpressLibrary->createPackageSlip($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiResponse, $payload->ticket);
    return $response;
}

function createPickupReq($request, $response) {
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request);
    $delhiveryExpressLibrary = new DelhiveryExpressLibrary;
    $apiResponse = $delhiveryExpressLibrary->createPickupReq($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiResponse, $payload->ticket);
    return $response;
}

function updateDelStatusDetails($request, $response) {
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request);
    $delhiveryExpressLibrary = new DelhiveryExpressLibrary;
    $apiResponse = $delhiveryExpressLibrary->updateDelStatusDetails($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiResponse, $payload->ticket);
    return $response;
}


