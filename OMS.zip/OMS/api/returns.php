<?php
require 'vendor/autoload.php';
require '../order.php';
require 'apihandler.php';
require_once '../action/Returns.php';

ini_set('memory_limit', '-1');
date_default_timezone_set("Asia/Calcutta");
$app = new Slim\App();
$app->post('/v3/order/returns/quantity/status', 'get_return_quantity_status');
$app->get('/v3/order/returns/penalty', 'get_return_penalty');
$app->post('/v3/order/returns/uploder', 'uploder');
$app->get('/v3/order/returns/test', 'test');
$app->run();

function getname()
{
    return "returns";
}

function get_return_quantity_status($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Returns;
    $apiresponse = $obj->get_return_quantity_status($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function get_return_penalty($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $request->getQueryParams();
    $obj = new Returns;
    $apiresponse = $obj->get_return_penalty($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function uploder($request, $response)
{
    $apiobj = new Apihandler;
    $obj = new Returns;
    $payload = $request->getParsedBody();
    $apiresponse = $obj->uploder($payload);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

function test($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $request->getQueryParams();
    $obj = new Returns;
    $apiresponse = $obj->test($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}
