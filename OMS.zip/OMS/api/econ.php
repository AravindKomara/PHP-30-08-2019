<?php
require 'vendor/autoload.php';

require '../order.php'; 
ini_set('memory_limit', '-1');
date_default_timezone_set("Asia/Calcutta");
$app = new Slim\App();
//provided to doctorsapp
$app->post('/v1/getAllAppointmentDetails','getAllAppointmentDetails');
$app->post('/v1/createEconsultationOrder','createEconsultationOrder');
$app->post('/v1/debriefToGcm','debriefToGcm');
$app->post('/v1/updateDoctor','updateDoctor');


$app->run();
	
	
	
	
	//code is shared with cp needs to be merged inline with order

	function getAllAppointmentDetails($request, $response)
	{
            $payload = json_decode($request->getBody()); 
	    print_r($payload);	
	}
        
        
	function createEconsultationOrder($request, $response)
	{       
                $json_request=$request->getBody();
                $utility = new Utility;
                $payload = $utility->json_validate($json_request);
		
                if($payload->appointmentId==''){
                    echo 'appointmentId is missing';
                    exit;
                }
                
                if(!is_string($payload->appointmentId)){
                    echo 'please give appointmentId as type string';
                    exit;
                }

                $econsorder = new Econsultation;
		$econ_payload=$econsorder->createOrderStructure($payload->appointmentId);
                
                $order=new Order;
                $order_data = $order->createOrder($econ_payload,$econ_payload['transaction_code']);
                print_r($order_data);
	}
	
	
	function debriefToGcm($request,$response)
	{
		$payload = json_decode($request->getBody());
		
		$userId = $payload->userId;
		$userType = $payload->userType;
		$orderIds = $payload->orderIds;
		
		if($orderIds==null or empty($orderIds) or !is_array($orderIds))
		{
			$response = json_encode(array("status"=>0,"message"=>"OrderIds required in array format and each should be an integer"));
			return $response;
		}
		
		$econ = new Econsultation;
		$output = $econ->debriefToGcm($orderIds,$userId,$userType);
		
		return json_encode($output);
		
		//VALIDATE $output AND THUS STRUCTURE RESPONSE
	}
	
	
	function updateDoctor($request,$response)
	{
		/* $apiobj = new Apihandler;
		$payload = $apiobj->apirequest($request, getname());
		
		
		$econ = new Econsultation;
		$apiresponse = $econ->updateDoctor($payload, $payload->ticket);
		$response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
		return $response; */
		
		$payload = json_decode($request->getBody());
		//print_r($payload);exit;
		$econ = new Econsultation;
		$output = $econ->updateDoctor($payload);
		
		return json_encode($output);
	}
	
	
 

 ?>