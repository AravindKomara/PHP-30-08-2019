<?php

require 'vendor/autoload.php';
require '../order.php';
require 'apihandler.php';

ini_set('memory_limit', '-1');
date_default_timezone_set("Asia/Calcutta");
$app = new Slim\App();

$app->post('/v1/login/appsupport', 'loginAppSupportUser');

$app->run();

function getname()
{
    return "app_support_route"; 
}

function loginAppSupportUser($request, $response)
{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    //print_r($payload);exit;
    $obj = new AppSupport;
    $apiresponse = $obj->loginAppSupportUser($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}

?>