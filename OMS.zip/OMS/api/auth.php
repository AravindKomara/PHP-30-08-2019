<?php
require 'vendor/autoload.php';
require '../order.php';
require 'apihandler.php';
ini_set('memory_limit', '-1');
date_default_timezone_set("Asia/Calcutta");
$app = new Slim\App();
$app->post('/v1/helptokencreation','helptokencreation');
$app->post('/v1/gettokendata','gettokendata');
$app->run();

 function getname()
{
  return "auth";
}


function helptokencreation($request, $response) {
	
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	$assocobj = new Associate;	
	$apiresponse = $assocobj->helptokencreation($payload,$payload->ticket);
    $response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
}

function gettokendata($request, $response) {
	
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	$assocobj = new Associate;	
	$apiresponse = $assocobj->gettokendata($payload,$payload->ticket);
    $response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
}


?>