<?php

require 'vendor/autoload.php';
require '../order.php';
require 'apihandler.php'; 
//include 'order.php';
 
ini_set('memory_limit', '-1');
date_default_timezone_set("Asia/Calcutta");
$app = new Slim\App();
//provided to CP
$app->post('/v1/createOrder', 'createOrder');
$app->post('/v1/createPackageChildOrders', 'createPackageChildOrders');
$app->post('/v1/autoOrder', 'autoOrder');
$app->post('/v1/createTransaction', 'createTransaction');
$app->post('/v1/createTransaction_ihs', 'createTransaction_ihs');
$app->post('/v1/getPackageOrder', 'getPackageOrder');
$app->post('/v1/getBookedPackages', 'getBookedPackages');
$app->post('/v1/getBookedPackagesname', 'getBookedPackagesname');
$app->post('/v1/getBookedPackagesforMrn', 'getBookedPackagesforMrn');
$app->post('/v1/getPackageCount', 'getPackageCount');
$app->post('/v1/getBookedPackagesForCoach', 'getBookedPackagesForCoach');
$app->post('/v1/create_packegebydraftorder', 'create_packegebydraftorder');
$app->post('/v1/finalReport', 'finalReport');
$app->post('/v1/async_transaction_call', 'asyncCall');
$app->get('/v1/order/cancel/wellness', 'cancel_wellness_order');

//$app->post('/v1/update_order','update_order');
//$app->get('/v1/invoice','invoice');


$app->run();

//code is shared with cp needs to be merged inline with order
function getname()
{
  return "order";
}


//ADDED 17/06/2019
function createPackageChildOrders($request,$response)
{
	$payload = json_decode($request->getBody());
	
	$package = new Package;
	$response = $package->createPackageChildOrders($payload);
	$response = json_encode($response);
	
	return $response;
	
}


//ADDED ON 27/03/2019
function autoOrder($request,$response)
{
	//TO GENERATE ORDERS UNDER PACKAGE
	$payload = json_decode($request->getBody());
	
	$package = new Package;
	
	$pkgCode = $payload->packageCode;
	$startDate = $payload->startDate;
	$package_parent_id = $payload->package_parent_id;
	$orderPayload = $payload->orderPayload;
	$transaction_code = $payload->transactionCode;
	
	$response = $package->autoOrder($pkgCode,$startDate,$package_parent_id,$orderPayload,		
										$transaction_code);
	$response = json_encode($response);
	
	return $response;
}



function getPackageOrder($request, $response) {

    $payload = json_decode($request->getBody());
	 if($payload->mrn==''){
                    echo 'mrn is missing';
                    exit;
                }
	 $mrn=$payload->mrn;
	$filter=array("order.patientinfo.mrn"=>(string)$mrn,"order.patientinfo.package_parent_id"=>array('$exists'=>true));
	$dbo=new Dbo;
	$packageorder=$dbo->find('masters','orders',$filter,array(),array());
	//print_r($packageorder);
	echo json_encode(array("result"=>"success","orders"=>$packageorder));


}




function getBookedPackagesForCoach($request, $response) 
{ 
   $apiobj=new Apihandler;
    $payload = $apiobj->apirequest($request,getname());
	//print_r($payload);exit;
    $package = new Package;
    $apiresponse= $package->getBookedPackagesForCoach($payload);
    $response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
		

}
function getBookedPackagesforMrn($request, $response) 
{ 
   $apiobj=new Apihandler;
    $payload = $apiobj->apirequest($request,getname());
	//print_r($payload);exit;
    $package = new Package;
    $apiresponse= $package->getBookedPackagesforMrn($payload);
    $response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
		

}

function finalReport($request, $response) 
{ 

   $apiobj=new Apihandler;
    $payload = $apiobj->apirequest($request,getname());
	//print_r($payload);exit;
    $associateObj = new Associate;
    $apiresponse= $associateObj->finalReport($payload);
    $response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
		

}

function getPackageCount($request,$response)

{
    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, getname());
    $obj = new Package;
    $apiresponse = $obj->getPackageCount($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, getname(), $apiresponse, $payload->ticket);
    return $response;
}



function getBookedPackages($request, $response) {

    $apiobj=new Apihandler;
    $payload = $apiobj->apirequest($request,getname());
	//print_r($payload);exit;
    $package = new Package;
    $apiresponse= $package->getBookedPackages($payload);
    $response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
}


function getBookedPackagesname($request, $response) {

    $apiobj=new Apihandler;
    $payload = $apiobj->apirequest($request,getname());
	//print_r($payload);exit;
    $package = new Package;
    $apiresponse= $package->getBookedPackagesname($payload);
    $response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
}

function createOrder($request, $response) {
    $apiobj=new Apihandler;
    $payload = $apiobj->apirequest($request,getname());

    $payload = json_decode($request->getBody(),true); 
    $order = new Order;
    $order_data= $order->createOrder((array)$payload);
	$apiresponse=array("status"=>1,"response"=>"order created","orderId"=>$order_data['_id'],"orderDId"=>$order_data['odid']);
    $response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
}

function createTransaction($request, $response) {
    //$requestIP = $request->getServerParam('REMOTE_ADDR');
	
	//LOGGING
	$logobj=new Logapp;
	$logobj->create_log("","",getname(),"Execution",200,"createTransaction_start",$request,(string)$ticket);


	try
	{
		//Create Instances
		$utility = new Utility;
		$gcm = new Gcm;
		$associate = new Associate;
		$mdm = new Mdm;
	
		$apiobj=new Apihandler;
	    $payload =(array) $apiobj->apirequest($request,getname());
		//$payload = (array) $utility->json_validate($json_request);
		//$payload = (array) json_decode($json_request);
		//print_r($payload); exit;
		
		//Validation of TRANSACTION PAYLOAD
		$utilresponse = $utility->verify_transaction($payload);

		if ($utilresponse['status'] == 0) {
			echo json_encode($utilresponse);
			exit;
		}
		
		//IF ORDERS IS NOT EMPTY
		if(!empty($payload[orders]) and $payload[orders] != null)
		{
			$source = isset($payload['channel']) ? $payload['channel'] : "";

			$transaction_id = $utility->getNextSequence("TRANSACTION");
			$date = date('dmy');
			$transaction_code = $source . "-" . $date . "-" . $transaction_id;

			//GATHERING DATA FROM THIRD-PARTY APIS	
			$orders = $payload[orders];
			$item_data = [];
			$order_set = array();
			
			$ord_num = 0;
			foreach($orders as $each_order)
			{
				$mrns_required[] = $each_order->mrn;
				$address_ids_required[] = $each_order->address_id;
				
				//DOCTOR ORDER IS A CONSULTATION ORDER(10 == 1)
				if((int)$service_type==10)
				{
					$payload[orders][$ord_num]->service_type = "1";
					$each_order->service_type = "1";
				}
				
				$service_type = $each_order->service_type;
				$is_package=isset($each_order->is_package)?1:0;
				$order_item = $each_order->order_item;
				
				
				//Associate IN CASE OF BELOW SERVICE_TYPE ORDERS AND NON-INTERNAL CONSULTATION ORDERS
				if (in_array((int)$service_type, array(3, 4, 1, 6, 7, 8, 14)) == true and 
					(int)$each_order->internal == 0 and (int)$each_order->is_assessment != 1 and 
					(int)$each_order->is_transaction != 1 and (int)$each_order->is_package != 1)
				{
									 $associates[] = (object) array("associate_id"=>$each_order->associate_id,
									  "branch_id"=>$each_order->associate_branch_id
									  ,"creation_type"=>$each_order->creation_type);
				}
		    	
				
				$item_codes = array();
				$external_codes = array();
				foreach($order_item as $item)
				{
					if((int)$item->roleBasedService == 0)
					{
						/* if((string)$service_type=="1" and $each_order->internal == 0 
								and (int)$each_order->is_assessment!=1)
						{
							$external_codes[] = $item->item_code;
						}
						else
						{ */
							$item_codes[] = $item->item_code;
						//}
					}	
				}
				
				//ADDED FOR UNIQUE ITEM CODES
				$external_codes = array_values(array_unique($external_codes));
				$item_codes = array_values(array_unique($item_codes));
				
				//Service type:1 and is_consultation requires internal or external doctor specification
				if((string)$service_type=="1")
				{
					if(!empty($item_codes))
					{
						
						$item_data[] = array("business"=>(string)$service_type,
								 "itemcodes"=>$item_codes,
								 "externalCodes" => $external_codes
								);
					}					
				}
				
				else
				{
					if(!empty($item_codes))
					{
						if($is_package==1)
						{
							$item_data[] = array("business"=>"100",
										 "itemcodes"=>$item_codes
										);
						}
						else
						{
						$item_data[] = array("business"=>(string)$service_type,
										 "itemcodes"=>$item_codes
										);
						}				
					}					
				}
				
				$ord_num++;
			}
			
			
			//print_r($item_data);exit;
			//print_r($mrns_required);print_r($address_ids_required);exit;
			//print_r($associates);exit;
			
			$patient_info = $gcm->get_mrn_address_info($mrns_required,$address_ids_required);
			
			//IN CASE OF orders that don't require associate details
			if(!empty($associates))
			{
				$associate_info = $associate->get_associate_info($associates);
				if(isset($associate_info['status']))
				{
					return $associate_info;
				}
			}
			else
			{
				$associate_info =array();
			}
			
			//IN CASE OF all roleBasedService items in a order need not call MDM
			if($item_data!=null and !empty($item_data))
			{
				$item_payload = array("data"=>$item_data);
				$item_info = $mdm->get_line_item_info($item_payload);
			}
			
			//print_r($patient_info);exit;
			//print_r($associate_info);exit;
			//print_r($item_info);exit;
			
			foreach($orders as $each_order)
			{
				//Making Patientinfo
				$patient_info_level = array_merge($patient_info[mrn][$each_order->mrn], 
										  $patient_info[address_id][$each_order->address_id]);
				
				//Making Orderinfo
				$associate_index = $each_order->associate_id."_".$each_order->associate_branch_id;
				$associate_details = $associate_info[$associate_index];
				$order_temp = $each_order;
				
				foreach($associate_details as $key=>$value)
				{
					$order_temp->$key = $value;
				}
				 
				//Adding Iteminfo
				$item_temp = $order_temp->order_item;
				$servicetype = $order_temp->service_type;
				$i = 0;
				$prescription_required=0;
				foreach($item_temp as $item_level_temp)
				{
					//THIS CHANGE IS REVERTED
					/* if((int)$servicetype!=3 and (int)$servicetype!=4)
					{
						unset($item_temp[$i]->reportto);
						unset($item_temp[$i]->invoiceto);
						unset($item_temp[$i]->corporateinvoiceemail);
						unset($item_temp[$i]->corporatereportemail);
					} */
					
					
					//FOR MEDICINE BUSINESS ITEM_MRP IS ALSO ADDED
					if((int)$servicetype == 2 and $item_temp[$i]->roleBasedService == 0)
					{
						$item_temp[$i]->item_mrp = $item_temp[$i]->MRP;
						$item_temp[$i]->old_item_mrp = $item_temp[$i]->MRP;
						$item_temp[$i]->old_gross_amount = $item_temp[$i]->gross_amount;
						$item_temp[$i]->old_discount_amount = $item_temp[$i]->discount_amount;
						$item_temp[$i]->old_net_amount = $item_temp[$i]->net_amount;
						$item_temp[$i]->old_quantity = $item_temp[$i]->quantity;
						
						if(isset($item_temp[$i]->doctor_name) and $item_temp[$i]->doctor_name!="")
						{
							$item_temp[$i]->doctorname = $item_temp[$i]->doctor_name;
						}
					}
					
					else if( ( (int)$servicetype == 3 or (int)$servicetype == 4 ) and $item_temp[$i]->roleBasedService == 0)
					{
						$tatPayload = array(
											"pincode" => $patient_info[address_id][$each_order->address_id][pincode],
											"serviceCode" => $item_temp[$i]->item_code
										);
						$mdm = new Mdm;
						$tatResp = $mdm->getTatHours($tatPayload,$ticket);
					    //print_r($tatResp);exit;
						
						if(isset($tatResp[data][0][hours]) and $tatResp[data][0][hours]!="")
						{
							$minHrs = (int)$tatResp[data][0][hours];
							$maxHrs = (int)$tatResp[data][0][hours]+ (int)$tatResp[data][0][toHours];
							
							$item_temp[$i]->tatHours = $maxHrs;
						}
						else
						{
							$minHrs = 12;
							$maxHrs = 24;
							$item_temp[$i]->tatHours = 24;
						}

						//$from = substr(date("c", strtotime($each_order->scheduled_date)), 0, 19) . ".000Z";
						$from = substr(date("c", strtotime(date('Y-m-d H:i:s',strtotime('+'.$minHrs.'hour',strtotime($each_order->scheduled_date))))), 0, 19) . ".000Z";
						
						$to = substr(date("c", strtotime(date('Y-m-d H:i:s',strtotime('+'.$maxHrs.'hour',strtotime($each_order->scheduled_date))))), 0, 19) . ".000Z";
						
						$item_temp[$i]->reportdeliverydatefrom = $from;
						$item_temp[$i]->reportdeliverydateto = $to;			
						//print_R($item_temp);exit;						
					}
					
					//PUSH ALL DETAILS FETCHED FROM MDM TO ITEM
					foreach($item_info[$item_level_temp->item_code] as $key=>$value)
					{
						//$item_temp[$i]->item_name = $item_info[$item_level_temp->item_code][item_name];
						$item_temp[$i]->$key = $value;
					}	
						
					//PREVIOUS LOGIC FOR TAT HOURS
					/* foreach($item_info[$item_level_temp->item_code] as $key=>$value)
					{
						//$item_temp[$i]->item_name = $item_info[$item_level_temp->item_code][item_name];
						$item_temp[$i]->$key = $value;	
						
						//GET tatHours in diagnostic orders
						if($key == 'tatHours' and (int)$servicetype==3)
						{
							$tatHours = $value;
							$from = substr(date("c", strtotime($each_order->scheduled_date)), 0, 19) . ".000Z";
							
							$to = substr(date("c", strtotime(date('Y-m-d H:i:s',strtotime('+'.$tatHours.'hour',strtotime($each_order->scheduled_date))))), 0, 19) . ".000Z";
							
							$item_temp[$i]->reportdeliverydatefrom = $from;
							$item_temp[$i]->reportdeliverydateto = $to;
							
							// if((int)$servicetype==2 and $key == 'prescription_required' and $value)
							//{
							//	$doctor_prescribed = 1;
							//} 
						}
					}
					//IF NO TATHOURS IS PRESENT DEFAULT IS 24HRS  
					if(!array_key_exists("tatHours", $item_info[$item_level_temp->item_code]) and (int)$servicetype==3)
					{
						$to = substr(date("c", strtotime(date('Y-m-d H:i:s',strtotime('+'.'24hour',strtotime($each_order->scheduled_date))))), 0, 19) . ".000Z";
					} */
					
					
					//FOR MEDICINES
					if((int)$servicetype == 2 and isset($item_level_temp->doctor_encounter_id) and $item_level_temp->doctor_encounter_id != "")
					{
						$encId = $item_level_temp->doctor_encounter_id;
					}
					
					if((int)$servicetype == 2 and isset($item_level_temp->prescription_required) and $item_level_temp->prescription_required)
					{
						$prescription_required = $item_level_temp->prescription_required;
					}
					
					if((int)$servicetype == 2 and $item_level_temp->prescription_required!=null and (int)$item_level_temp->prescription_required==1)
					{
						$prescription_required = (int)$item_level_temp->prescription_required;
					}
					
					//FOR Econsultation
					if((int)$servicetype == 1 and isset($item_level_temp->specialityName))
					{
						$specialityName = $item_level_temp->specialityName;
					}
					
					$item_temp[$i]->item_status = "0";
					
					$i++;
				}
				$order_temp->order_item = $item_temp;
				//print_r($order_temp);exit;
				
				//report delivery date to in diagnostic orders
				if((int)$servicetype == 3)
				{
					$order_temp->final_delivery_date = $to;
				}
				
				//specialityName in econ orders
				if((int)$servicetype == 1 and isset($specialityName))
				{
					$order_temp->specialityName = $specialityName;
				}
				
				
				//RETURN ORDER
				if((int)$order_temp->is_return_order == 1 and (int)$servicetype == 2)
				{
					$medObj = new Medicine;
					$returnResp = $medObj->returnOrderChanges((int)$order_temp->reference_order_id,$order_temp->return_order_items);
					
					if($returnResp['response'] == 0)
					{
						return json_encode($returnResp);
					}
					
					//GET VENDOR DETAILS FROM REF ORDER
					$order_temp->associate_id = $returnResp['associate'];
					$order_temp->associate_branch_id = $returnResp['branch'];
				}
				
				
				//FOR PRESCRIPTION UPLOAD
				if((int)$servicetype == 2)
				{
					$prescription_images = array();
					if($prescription_required == 1){
						if(isset($order_temp->prescription_images) && is_array($order_temp->prescription_images)){
							foreach($order_temp->prescription_images as $presc){
								array_push($prescription_images,(array)$presc);
							}
						}else{
							$order_temp->prescription_later = "1";
						}
					}
					
					
					//when an encounterId is given against a medicine order doctorApp will have the prescription stored
					if(isset($encId) and $encId!="")
					{
						$prescriPayload = array("encounterId"=>(string)$encId);
						$prescription_resp = $gcm->prescriptionFromDoctor($prescriPayload, $ticket);
						if(!isset($prescription_resp['status']))
						{
							array_push($prescription_images,$prescription_resp);
						}
						else
						{
							$order_temp->prescription_later = "1";
						}							
					}
					
					//prescription_required for medicine orders if atleast one item needs prescription
					else if($prescription_required == 1)
					{
						if(isset($order_temp->prescription_image) and !empty($order_temp->prescription_image) and is_array($order_temp->prescription_image))
						{
							$prescription_image = $order_temp->prescription_image;
							$mrn = $order_temp->mrn;

							//CALL TO UPLOAD PRESCRIPTION
							$medsupply = new MedicineSupplies;
							$prescription_resp = $medsupply->upload_bytearray_prescription($prescription_image,$mrn);
							//print_r($prescription_resp);exit;
							if($prescription_resp['status']==1)
							{
								foreach($prescription_resp['message'] as $prescription)
								{
									if($prescription['status']==1)
									{
										array_push($prescription_images,$prescription['data']);
									}
								}
							}
						}
						else
						{
							$order_temp->prescription_later = "1";
						}
					}
					
					//PUSH PRESCRIPTION_IMAGES
					$order_temp->prescription_images = $prescription_images;
					if($prescription_required==1){
						if(count($prescription_images)>0){
							$order_temp->prescription_later = "0";
						}else{
							$order_temp->prescription_later = "1";
						}
					}else{
						$order_temp->prescription_later = "0";
					}
					
				}
				
				
				$business_info_level = $order_temp;
				//print_r($business_info_level);exit;
				
				
				//Making Additional Info
				$additionaldata = array(
					"parent_mrn" => $payload['mrn'],
					//"source_id" => $payload['source_id'],
					"channel" => $payload['channel'],
					//"created_date" => $payload['created_date'],
					"source_of_referral" => $payload['source_of_referral'],
					"referral_id" => $payload['referral_id'],
					"referral_mrn" => $payload['referral_mrn'],
					"createdById" => $payload['created_by_id'],
					"createdByName" => $payload['created_by_name']
				);
				if(isset($payload['code']) and $payload['code']!="")
				{
					$additionaldata['code'] = (string)$payload['code'];
				}
				
				//Making Payment Info
				$payment_info = $payload['payment_info'];
			
				//print_r($payment_info);//exit;
				//print_r($additionaldata);//exit;
				//print_r((object)$patient_info_level);exit;
				//print_r($business_info_level);exit;
				
				
				//CREATE ORDER STRUCTURE FOR EACH ORDER AND PUSH INTO AN ARRAY
				$order = create_order_structure($business_info_level, (object)$patient_info_level, $additionaldata, $payment_info);
				
				array_push($order_set, $order);
				
			}
			//print_r($order_set);exit;
			
			
			//Create Instances
			$order = new Order;
			$dbo = new Dbo;
			$econ = new Econsultation;
			
			//INSERTING THE TRANSACTIONS IN DB AND CREATING ORDERS(in below function)
			//print_r($order_set);exit;
			$appresponse = $order->insertTransaction($order_set, $transaction_code, $payload);

			//TO BE SENT FOR ORDER CREATION USING INSERT TRANSACTION
			
			
			//print_r($appresponse[set]);exit;
			/* if($appresponse[set][appointments] != null)
			{
				$app_array = $appresponse[set][appointments];
			} */
			
			if($appresponse[set][order] != null)
			{
				$order_array = $appresponse[set][order];
			}
			
			if($appresponse[set][workorders] != null)
			{
				$workorder_array = $appresponse[set][workorders];
			}
			
			if($appresponse[set][orderlog] != null)
			{
			$orderlog_array = $appresponse[set][orderlog];
			}
			
			if($appresponse[set][transaction] != null)
			{
				$transaction_array = $appresponse[set][transaction];
				$order_info_array[] = (array)$appresponse[set][order_info];
			}
			
			if($appresponse[response] != null and isset($appresponse[response][transaction]))
			{
				//$response_array[] = $appresponse[response];
				$tr_codes[] = $appresponse[response][transaction];
			}
			
			//GET ORDERIDS,APPOINTMENTIDS TO PASS TO CHISS
			if(!empty($appresponse[orders]) and $appresponse[orders]!=null)
			{
				$order_ids[] = $appresponse[orders];
			}
			if(!empty($appresponse[appointments]) and $appresponse[appointments]!=null)
			{
				$appointment_ids[] = $appresponse[appointments];
			}
			
			
			$asyncPayload = array(); //FOR ASYNC API CALLS	
			
			//INSERTING ALL THE ORDER,APPOINTMENTS,WORKORDERS,ORDERLOGS AND THE TRANSACTION

			/* if(isset($app_array) and !empty($app_array))
			{
				//$app_array = call_user_func_array('array_merge', $app_array);
				//echo json_encode($app_array);exit;
				$insert_response = $dbo->insertMany('masters','appointments',$app_array);
			} */

			if(isset($order_array) and !empty($order_array))
			{
				$codFlag = 0; //IF TRANSACTION HAS A COD ORDER
				$medorders = array();
				$welorders = array();
				$welordersCompleted = array();
				
				//$order_array = call_user_func_array('array_merge', $order_array);
				//echo json_encode($order_array);exit;
				
				//SINCE EMPTY BUSINESS FIELD IS A OBJECT AND NON EMPTY IS A ARRAY(THIS NEEDS TO BE CHECKED IN EACH BUSINESS FILE)
				$k = 0;
				foreach($order_array as $ord)
				{
					$order_array[$k][order][business] = (array)$order_array[$k][order][business];
					$k++;
				}
				
				$k = 0;
				foreach($order_array as $ord)
				{
					//IF SELF ALLOC FLAG IS SET ALLOCATE USING MANUAL_ALLOC AND NOT THROUGH CHISS
					if($ord[order][business][self_alloc_flag] == 1)
					{
						$ass_id = $ord[order][business][officerAssociateId];
						$br_id = $ord[order][business][officerBranchId];
						$off_id = $ord[order][business][createdById];
						$off_name = $ord[order][business][createdByName];
						
						//echo $ass_id." ".$br_id." ".$off_id." ".$off_name;exit;
						unset($order_array[$k][order][business][officerAssociateId]);
						unset($order_array[$k][order][business][officerBranchId]);
						unset($order_array[$k][order][business][createdById]);
						unset($order_array[$k][order][business][createdByName]);
						
						$man_alloc_payload['orders'][] = (object)
												array(
													   "order_id" => $ord[_id],
													   "workorder_id" => $ord[wid],
													   "associate_id" => $ass_id,
													   "branch_id" => $br_id,
													   "officer_id" => $off_id,
													   "officer_name" => $off_name,
													   "officer_contact_number" => "",
													   "date_Changed" => false,
													   "scheduled_date" => ""
													 );

						//SELF ALLOCATION FOR CHILD ORDERS							 
						if($ord[order][business][is_continuous] == 1 or $ord[order][business][is_transaction] == 1)
						{
							if(!empty($ord[order][childOrderIds]) and 
													is_array($ord[order][childOrderIds]))
							{
								$childOrders = $ord[order][childOrderIds];
							

								//GET CHILD ORDERS FOR SELF ALLOC
								$childFilter = array("_id"=>array('$in'=>$childOrders));
								$childProject = array("wid"=>1);
								//print_r($childFilter);print_R($childProject);exit;
								$childCursor = $dbo->find('masters','orders',$childFilter,$childProject,array());
								foreach($childCursor as $child)
								{
									$man_alloc_payload['orders'][] = (object)
														array(
															   "order_id" => $child[_id],
															   "workorder_id" => $child[wid],
															   "associate_id" => $ass_id,
															   "branch_id" => $br_id,
															   "officer_id" => $off_id,
															   "officer_name" => $off_name,
															   "officer_contact_number" => "",
															   "date_Changed" => false,
															   "scheduled_date" => ""
															 );
								}
							
							}
							
						}
						
						
						$medorders[] = $ord[_id];// TO AVOID CHISS ALLOCATION NOT MEDICINE ORDERS						 
					}
					
					
					else if(in_array((int)$ord[order][patientinfo][service_type], [6,7,8]))
					{
						if($ord[order][business][is_continuous] == 1 or $ord[order][business][is_transaction] == 1)
						{
							if(!empty($ord[order][childOrderIds]) and 
													is_array($ord[order][childOrderIds]))
							{
								$childOrderIds[] = $ord[order][childOrderIds];
							}	
						}
					}
					
					//STOP MEDICINE AND EQUIPMENT ORDERS TO CHISS BY REMOVING IT FROM ARRAY OF ORDERIDS BEING SENT TO CHISS
					else if(in_array((int)$ord[order][patientinfo][service_type], [2,11]))
					{
						$medorders[] = $ord[_id];
					}
					
					//SEND WELLNESS PACKAGE ORDERS TO CHISS WELLNESS APIS
					else if((int)$ord[order][patientinfo][service_type] == 14 and (int)$ord[order][patientinfo][is_package]==1)
					{
						$welorders[] = $ord[_id];
						if($ord[OStatus] == 6)
						{
							$welordersCompleted[] = $ord[_id];
						}
					}
					
					//FACILITATION IHS ORDERS SEND TO UPDATE ASSOCIATE INFO
					if( (int)$ord[order][patientinfo][service_type] == 4 and $ord[order][patientinfo][application_no]!="" and isset($ord[order][patientinfo][application_no]) )
					{
						$ImagIhsOrders = array();
						$ImagIhsOrders[orderID] = $ord[_id];
						foreach($ord[order][provider_info] as $provider)
						{
							if((int)$provider[component_no] == 7)
							{
								$ImagIhsOrders[associateCode] = $provider[associate_id];
								$ImagIhsOrders[associateName] = $provider[associate_name];
								$ImagIhsOrders[associateAddress] = $provider[associate_address];
							}	
						}
						$asyncPayload[] = array("option"=>7,"payload"=>$ImagIhsOrders);
					}

					
					
					//FOR SMS_EMAIL_TRIGGER
					//order_id,status,component_id,mode_of_service,business_id,flag,corporate_id
					$id = $ord[_id];
					$status = $ord[OStatus];
					$component_id = $ord[active_component];
					$mode_of_service = $ord[mode_of_service];
					$odid = $ord[odid];
					$business_id = $ord[order][patientinfo][service_type];
					$businessName = $utility->getbusinessName($business_id);
					//print_r($businessName);exit;
					$corporate_id = $ord[order][patientinfo][corporateid];
					$business = $ord[order][business];
					$payment_code = $ord[payment_info][payment_code];
					
					if((int)$payment_code == 0)
					{
						$codFlag = 1;
					}
					
					//GET THE CORRESPONDING FLAG
					if( in_array($business_id, ["6","7","8"]) )
					{
						//ASSESSMENT
						if($business[is_assessment] == 1)
						{
							if((int)$payment_code == 0 or (int)$payment_code == 100)
							{
								$flag = 8;
							}
							else
							{
								$flag = 9;
							}
						}
						
						//CONTINUOUS
						else if($business[is_continuous] == 1)
						{
							if((int)$payment_code == 0 or (int)$payment_code == 100)
							{
								$flag = 16;
							}
							else
							{
								$flag = 17;
							}
						}
						
						//TRANSACTION
						else
						{
							if((int)$payment_code == 0 or (int)$payment_code == 100)
							{
								$flag = 12;
							}
							else
							{
								$flag = 13;
							}
						}
					}
					
					else
					{
						if((int)$payment_code == 0 or (int)$payment_code == 100)
						{
							$flag = 5;
						}
						else
						{
							$flag = 6;
						}
					}
					
					
					//CALL SMS EMAIL TRIGGER
					//$omsobj = new Oms;

				$smsEmailPayload = array(
					"_id" => $id,
					"status" => $status,
					"component_id" => $component_id,
					"mode_of_service" => $mode_of_service,
					"odid" => $odid,
					"flag" => $flag,
					"business_id" => $service_type,
					"businessName" => $businessName,
					"corporate_id" => $corporate_id,
					"business" => $business,
					"payment_code" => $payment_code 
				);

				$asyncPayload[] = array("option"=>4,"payload"=>$smsEmailPayload);
				
				//$trigger_response = $omsobj->trigger_email_sms_event($id, $status, $component_id, $mode_of_service, $business_id, $flag, $corporate_id);
				
				
				//RETURN ORDER TICKET GENERATION
				if($ord[order][business][is_return_order] == 1)
				{
					// foreach($ord[order][business][return_order_items] as $rtItem)
					// {
					// }
				
					$ticketPayload = array(
											"order_id" => $ord[order][business][reference_order_id],
											"category" => $ord[order][business][return_order_items][0]->reason_category_id,
											"sub_category" => $ord[order][business][return_order_items][0]->reason_category_id,
											"sub_category_description" => $ord[order][business][return_order_items][0]->Comment
										);

					$sugarCrm = new SugarCRM;
					$ticketResp = $sugarCrm->raise_ticket((object)$ticketPayload);	
					
					//$sub_url = 'OMS/api/operation.php/v1/generateTicket';
					//$url = $config->getconfig("serverurl",$sub_url);
					//$ticketResp = $utility->my_curl($url, 'POST', json_encode($ticketPayload), 'json', null, 10);
					
					$order_array[$k][order][patientinfo][ticket_id] = $ticketResp["Ticket"][0]["ticket_id"];
				}
				
				$k++;

				}
				
				$insert_response = $dbo->insertMany('masters','orders',$order_array);
	
				foreach($order_array as $ord)
				{				
					if((int)$status == 1001)
					{
						$prescriptionlinkPayload = array("order_id"=> $ord['_id'], "component_id"=>9);
						//$asyncPayload[] = array("option"=>7,"payload"=>$prescriptionlinkPayload);
						$suburl = 'OMS/api/operation.php/v1/orders/notification/send/prescription-upload-link';
						
						
						$config = new Config;
						$url = $config->getConfig('serverurl',$suburl);
						
						$prescriptionlinkPayload = json_encode($prescriptionlinkPayload);
						//echo $url." ".$prescriptionlinkPayload;exit;
						
						$prescriptionLinkResponse = $utility->my_curl($url,'POST',$prescriptionlinkPayload,'json',null,10);
						//print_r($prescriptionlinkResponse);exit;
					}
				}
				//print_r($man_alloc_payload['orders']);exit;
				
				if(!empty($man_alloc_payload['orders']) and $man_alloc_payload != null)
				{
					$man_alloc_payload["allocated_by"] = 5;
					$man_alloc_payload["assigning_officer_id"] = $off_id;
					$man_alloc_payload["assigning_officer_name"] = $off_name;
					
						
					$ordinfo_obj = new Orderinfo;
					$man_alloc_resp = $ordinfo_obj->manual_allocation((object)$man_alloc_payload,$ticket);
					
					/* $sub_url = 'pandu/OMS/api/operation.php/v1/orderallocation';//MAIN BRANCH URL MUST BE CHANGED
					$url = $config->getconfig("serverurl",$sub_url);
					$man_alloc_payload = json_encode($man_alloc_payload);
					$man_alloc_resp = $utility->async_curl($url,$man_alloc_payload); */
				}
				
			}
			
			
			//print_r($childOrderIds);exit;
			if(isset($workorder_array) and !empty($workorder_array))
			{
				//$workorder_array = call_user_func_array('array_merge', $workorder_array);
				//echo json_encode($workorder_array);exit;
				$insert_response = $dbo->insertMany('masters','workorders',$workorder_array);
			}
			if(isset($orderlog_array) and !empty($orderlog_array))
			{
				//$orderlog_array = call_user_func_array('array_merge', $orderlog_array);
				//echo json_encode($orderlog_array);exit;
				$insert_response = $dbo->insertMany('masters','orderlog',$orderlog_array);
			}
			if(isset($transaction_array) and !empty($transaction_array))
			{
				$transaction_array = array($transaction_array);
				$insert_response=$dbo->insertMany('masters','transaction',$transaction_array);
			}
			
			if(isset($tr_codes) and !empty($tr_codes))
			{
				$response_array = array("transaction"=>$tr_codes,"status"=>"1","message"=>"Transactions created Successfully","order_info"=>$order_info_array);
				
				//PAYMENT LINK API PAYLOAD FOR COD ORDERS
				if($codFlag == 1)
				{
					$payLinkPayload = array("id" => $tr_codes[0],
								"type" => "1",
								"link_expiry_minute" => "15",
								"channel"=> CHANNEL[(int)$source] != null ? CHANNEL[(int)$source] : "CP"
								);
					$asyncPayload[] = array("option"=>6,"payload"=>$payLinkPayload);			
				}
			}
				
			
			//print_r($response_array);exit;
			//ADDED CHISS ORDER CREATION CALL , GCM DEBRIEF API , CUSTOMER UPDATE GCM , SMS EMAIL TRIGGER CALL IN ASYNC MANNER
			if(isset($order_ids) and $order_ids!=null and !empty($order_ids))
			{
				$order_ids = call_user_func_array('array_merge', $order_ids);
				$childOrderIds = call_user_func_array('array_merge', $childOrderIds);
				//print_r($order_ids);//exit;
				//print_r($childOrderIds);exit;
				
				if(isset($childOrderIds))
				{
					$order_ids = array_merge($order_ids,$childOrderIds);
				}
				
				//MEDICINE AND EQUIPMENT ORDERS NOT SEND TO CHISS
				$chiss_orders = array_values(array_diff($order_ids, $medorders));
				$chiss_orders = array_values(array_diff($chiss_orders, $welorders));
				
				//INSTANCES
				$config = new Config;
				$utility = new Utility; 
				
				//option 1 => chiss order creation Call
				//ADD CALL TO CHISS FOR ORDER CREATION API
				if(!empty($chiss_orders))
				{
					$chisspayload = array("order_ids"=>$chiss_orders);
					$asyncPayload[] = array("option"=>1,"payload"=>$chisspayload);
				}
				
				/* $payload = json_encode($payload);
				$sub_url = 'OMS/api/operation.php/v1/ordercreation_chiss';//MAIN BRANCH URL MUST BE CHANGED
				$url = $config->getconfig("serverurl",$sub_url);
				//echo $url." ".$payload;exit;
				$chissresponse = $utility->my_curl($url, 'POST', $payload, 'json', null, 1); 
				//DIRECT FUNCTION CALL REMOVED FOR NOW
				//$obj = new Orderinfo;
				//$chiss_ord_resp = $obj->chiss_order_creation((object)$payload,$ticket);
				//$response_array['chiss_order_response'] = $chiss_ord_resp;*/ 

				
				//option 2 => gcm Debrief Call
				//ADD CALL TO GCM DEBRIEF updateOrderId API
				$debriefpayload = array("orderIds"=>$order_ids);
				
				$asyncPayload[] = array("option"=>2,"payload"=>$debriefpayload);
				
				/* $payload = json_encode($payload);
				$sub_url = 'OMS/api/econ.php/v1/debriefToGcm';//MAIN BRANCH URL MUST BE CHANGED
				$url = $config->getconfig("serverurl",$sub_url);
				$gcmresponse = $utility->my_curl($url, 'POST', $payload, 'json', null, 1); 
				//$name=$payload[orders][service_type];
				//print_r($name);exit;
				//echo $utility->getbusinessName($name);*/
				//print_r($businessName);exit;
				
				
				
				//option 3 => customerUpdate	
				$customerpayload = array(
					"mrn"=>$payload[mrn],
					"lastService"=>$businessName,
					"lastServiceOrderId"=>(string)$id,
					"sourceType"=>"OMS",
					"isSendSms"=>0,
					"isSendEmail"=>0
				);

				$asyncPayload[] = array("option"=>3,"payload"=>$customerpayload);
				
				
				//option 5=>wellness order allocation chiss
				if(!empty($welordersCompleted) and $welordersCompleted!="")
				{
					foreach($welordersCompleted as $word)
					{
						$welPayload = array("order_id"=>(int)$word);
						$asyncPayload[] = array("option"=>5,"payload"=>$welPayload);
					}	
				}

				//STRUCTURE ASYNC CALL
				//$callingPayload = json_encode($asyncPayload); //COMMENTED

				$sub_url = 'OMS/api/order.php/v1/async_transaction_call';
				$url = $config->getconfig("serverurl",$sub_url);
				
				//FOR ALL ASYNC CALLS
				//$utility->async_curl($url, $callingPayload); //COMMENTED
				
				
				//TEMPERORY SOLN. FOR ASYNCCALL
				//$logobj->create_log("","",getname(),"Execution",200,"createTransaction_asyncRequest",json_encode($asyncPayload),(string)$ticket);
				
				$async_response = asyncCall($asyncPayload);
				
				//$logobj->create_log("","",getname(),"Execution",200,"createTransaction_asyncResponse",json_encode($async_response),(string)$ticket);
				//print_r($async_response);exit;
				
			}
		}
		
		//PENALTIES AND PENDING PAYMENTS
		if(!empty($payload["pending_payments"]) and $payload["pending_payments"] != null)
		{
			//print_r($payload);exit;
			$pendingReq = $payload["pending_payments"];
			$pendingReq->mrn = $payload["mrn"];
			$pendingReq->payment_service = $payload["payment_info"]->payment_service;
			$pendingReq->payment_reference_id = $payload["payment_info"]->payment_reference_id;
			$pendingReq->payment_code = $payload["payment_info"]->payment_mode;
			
			$finance = new Finance;
			$fResult = $finance->payPenaltiesAndPendingPayments($pendingReq); 
			//print_r($fResult);exit;
			
			if($fResult['response'] == 1)
			{
				$response_array["status"] = "1";
				$response_array["message"] = "Transactions created Successfully";
				
				if(empty($response_array["transaction"]))
				{
					$response_array["transaction"] = $fResult['transaction'];
				}
				else
				{
					$response_array["transaction"] = array_merge($response_array["transaction"] , $fResult['transaction']);
				}
			}
			else
			{
				$response_array["status"] = "0";
				$response_array["message"] = "Penalties and pendingPayments payment failed";
			}
			
			unset($fResult['transaction']);
			
			$response_array['penaltiesAndPendingPayments'] = $fResult;
		}	
		
	}

	catch(Exception $e)
	{
		echo 'Message: ' .$e->getMessage();
		$logobj->create_log("","",getname(),"Execution",300,"Error_createTransaction",$e->getMessage(),(string)$ticket);
		exit;
	}
	
	
	$logobj->create_log("","",getname(),"Execution",200,"createTransaction_end",json_encode($response_array),(string)$ticket);
	
	$response = $apiobj->apiresponse($response,getname(),$response_array, $payload->ticket);
	return $response;

}//end of function

function asyncCall($payload)
{
	//$apiobj = new Apihandler; //COMMENTED
    //$payload = $apiobj->apirequest($request, getname()); //COMMENTED

	//print_r($payload);exit;
	
	$config = new Config;
	$utility = new Utility;
	$logobj=new Logapp;
	
	$logobj->create_log("","",getname(),"Execution",200,"asyncCall_start",json_encode($payload),(string)$ticket);

	$response = array();
	foreach($payload as $pay)
	{
		if($pay[option]==1)
		{
			
			try
			{
				$callingPayload = json_encode($pay[payload]);
				//echo $callingPayload;exit;

				$sub_url = 'OMS/api/operation.php/v1/ordercreation_chiss';
				$url = $config->getconfig("serverurl",$sub_url);
				//echo $url." ".$callingPayload;exit;
				
				//FOR ALL ASYNC CALLS
				$utility->async_curl($url, $callingPayload);
				
				//$ordinfo = new Orderinfo;
				//$chiss_resp = $ordinfo->chiss_order_creation((object)$pay[payload],$ticket);
				//print_r($chiss_resp);exit;
				//$response['chiss_response'] =  $chiss_resp;
			}
			catch(Exception $e)
			{
				$Error = array("ChissOrderCreationError"=>$e->getMessage());
				$logobj->create_log("","",getname(),"Execution",200,"asyncCall_Error",json_encode($Error),(string)$ticket);
			}
		}

		else if($pay[option]==2)
		{
			$userId = "";
			$userType = 1;
			
			//print_r($pay->payload->orderIds);exit;
			try
			{
				$callingPayload = array(
										"userId"=>$userId,
										"userType"=>$userType,
										"orderIds"=>$pay[payload][orderIds]
										);
				$callingPayload = json_encode($callingPayload);
				//echo $callingPayload;exit;

				$sub_url = 'OMS/api/econ.php/v1/debriefToGcm';
				$url = $config->getconfig("serverurl",$sub_url);
				//echo $url." ".$callingPayload;exit;
				
				//FOR ALL ASYNC CALLS
				$utility->async_curl($url, $callingPayload);

				//$gcm_info = new Econsultation;
				//$gcm_resp = $gcm_info->debriefToGcm($pay[payload][orderIds],$userId,$userType);
				//$response['gcm_debrief_resp'] =  $gcm_resp;
			}
			catch(Exception $e)
			{
				$Error = array("DebriefToGcmError"=>$e->getMessage());
				$logobj->create_log("","",getname(),"Execution",200,"asyncCall_Error",json_encode($Error),(string)$ticket);
			}
		}

		else if($pay[option]==3)
		{
			$gcm_call = new Gcm;
			try
			{
				$callingPayload = json_encode($pay[payload]);
				//echo $callingPayload;exit;

				$sub_url = 'OMS/api/operation.php/v1/customerUpdate';
				$url = $config->getconfig("serverurl",$sub_url);
				//echo $url." ".$callingPayload;exit;
				
				//FOR ALL ASYNC CALLS
				$utility->async_curl($url, $callingPayload);
				
			
				//$gcm_resp = $gcm_call->customerUpdate((object)$pay[payload],$ticket);
				//$response['gcm_customerUpdate_resp'] =  $gcm_resp;
			}
			catch(Exception $e)
			{
				$Error = array("CustomerUpdateError"=>$e->getMessage());
				$logobj->create_log("","",getname(),"Execution",200,"asyncCall_Error",json_encode($Error),(string)$ticket);
			}
		}

		else if($pay[option]==4)
		{
			$payload = $pay[payload];

			$order_id = $payload[_id];
			$status = $payload[status];
			$flag = $payload[flag];
			$component_id = $payload[component_id];  
			$mode_of_service = $payload[mode_of_service]; 
			$business_id = $payload[business_id]; 
			$corporate_id = $payload[corporate_id]; 
		
			try
			{				
				$sms_email_trigger = new Oms; 
				$sms_email_trigger_resp = $sms_email_trigger->trigger_email_sms_event($order_id,$status,$component_id,
					$mode_of_service,$business_id,$flag,$corporate_id);
				$response['sms_email_resp'][] =  $sms_email_trigger_resp;
			}
			catch(Exception $e)
			{
				$Error = array("SMSEmailError"=>$e->getMessage());
				$logobj->create_log("","",getname(),"Execution",200,"asyncCall_Error",json_encode($Error),(string)$ticket);
			}
			//print_r($sms_email_trigger_resp);exit;
		}

		else if($pay[option]==5)
		{
			try
			{
				$callingPayload = json_encode($pay[payload]);
				//echo $callingPayload;exit;

				$sub_url = 'OMS/api/operation.php/v1/wellnesscreation_chiss';
				$url = $config->getconfig("serverurl",$sub_url);
				//echo $url." ".$callingPayload;exit;
				
				//FOR ALL ASYNC CALLS
				$utility->async_curl($url, $callingPayload);
				
				//$ordinfo = new Orderinfo;
				//$chiss_resp = $ordinfo->chiss_wellness_creation((object)$pay[payload],$ticket);
				//print_r($chiss_resp);exit;
				//$response['chiss_wellness_response'][] =  $chiss_resp;
			}
			catch(Exception $e)
			{
				$Error = array("ChissWellnessError"=>$e->getMessage());
				$logobj->create_log("","",getname(),"Execution",200,"asyncCall_Error",json_encode($Error),(string)$ticket);
			}
			
		}

		else if($pay[option]==6)
		{
			try
			{				
				$payment = new Payments; 
				$payLink_resp = $payment->send_payment_link((object)$pay[payload], $ticket);
				$response['paymentLink_resp'] =  $payLink_resp;
			}
			catch(Exception $e)
			{
				$Error = array("paymentLinkError"=>$e->getMessage());
				$logobj->create_log("","",getname(),"Execution",200,"asyncCall_Error",json_encode($Error),(string)$ticket);
			}
			//print_r($payLink_resp);exit;
		}

		else if($pay[option]==7)
		{
			try
			{				
				$ihs = new Ihs; 
				$res = $ihs->updateOrderByAssociate((object)$pay[payload], $ticket);
				//$response['ihsAssociateUpdate_resp'] =  $res;
			}
			catch(Exception $e)
			{
				$Error = array("ihsAssociateUpdateError"=>$e->getMessage());
				$logobj->create_log("","",getname(),"Execution",200,"asyncCall_Error",json_encode($Error),(string)$ticket);
			}
		}	

	}
	
	$logobj->create_log("","",getname(),"Execution",200,"asyncCall_end",json_encode($response),(string)$ticket);

	//return json_encode($response); //COMMENTED
	return $response; 
	
}//end of function


//MAIN ASYNC API
/* function asyncCall($request,$response)
{
	$apiobj = new Apihandler; //COMMENTED
    $payload = $apiobj->apirequest($request, getname()); //COMMENTED

	//print_r($payload);exit;
	
	$config = new Config;
	$utility = new Utility;
	$logobj=new Logapp;
	
	$logobj->create_log("","",getname(),"Execution",200,"asyncCall_start",json_encode($payload),(string)$ticket);

	$response = array();
	foreach($payload as $pay)
	{
		if($pay->option==1)
		{
			$ordinfo = new Orderinfo;
			
			try
			{				
				$chiss_resp = $ordinfo->chiss_order_creation($pay->payload,$ticket);
				//print_r($chiss_resp);exit;
				$response['chiss_response'] =  $chiss_resp;
			}
			catch(Exception $e)
			{
				$Error = array("ChissOrderCreationError"=>$e->getMessage());
				$logobj->create_log("","",getname(),"Execution",200,"asyncCall_Error",json_encode($Error),(string)$ticket);
			}
		}

		else if($pay->option==2)
		{
			$userId = "";
			$userType = 1;
			$gcm_info = new Econsultation;
			//print_r($pay->payload->orderIds);exit;
			try
			{				
				$gcm_resp = $gcm_info->debriefToGcm($pay->payload->orderIds,$userId,$userType);
				$response['gcm_debrief_resp'] =  $gcm_resp;
			}
			catch(Exception $e)
			{
				$Error = array("DebriefToGcmError"=>$e->getMessage());
				$logobj->create_log("","",getname(),"Execution",200,"asyncCall_Error",json_encode($Error),(string)$ticket);
			}
		}

		else if($pay->option==3)
		{
			$gcm_call = new Gcm;
			try
			{				
				$gcm_resp = $gcm_call->customerUpdate($pay->payload,$ticket);
				$response['gcm_customerUpdate_resp'] =  $gcm_resp;
			}
			catch(Exception $e)
			{
				$Error = array("CustomerUpdateError"=>$e->getMessage());
				$logobj->create_log("","",getname(),"Execution",200,"asyncCall_Error",json_encode($Error),(string)$ticket);
			}
		}

		 else if($pay->option==4)
		{
			$payload = $pay->payload;

			$order_id = $payload->_id;
			$status = $payload->status;
			$flag = $payload->flag;
			$component_id = $payload->component_id;  
			$mode_of_service = $payload->mode_of_service; 
			$business_id = $payload->business_id; 
			$corporate_id = $payload->corporate_id; 
		
			try
			{				
				$sms_email_trigger = new Oms; 
				$sms_email_trigger_resp = $sms_email_trigger->trigger_email_sms_event($order_id,$status,$component_id,
					$mode_of_service,$business_id,$flag,$corporate_id);
				$response['sms_email_resp'] =  $sms_email_trigger_resp;
			}
			catch(Exception $e)
			{
				$Error = array("SMSEmailError"=>$e->getMessage());
				$logobj->create_log("","",getname(),"Execution",200,"asyncCall_Error",json_encode($Error),(string)$ticket);
			}
			//print_r($sms_email_trigger_resp);exit;
		}

		else if($pay->option==5)
		{
			$order = (int)$pay->payload->order_id;
			$ordinfo = new Orderinfo;
			try
			{				
				$chiss_resp = $ordinfo->chiss_wellness_creation($pay->payload,$ticket);
				//print_r($chiss_resp);exit;
				$response['chiss_wellness_response'] =  $chiss_resp;
			}
			catch(Exception $e)
			{
				$Error = array("ChissWellnessError"=>$e->getMessage());
				$logobj->create_log("","",getname(),"Execution",200,"asyncCall_Error",json_encode($Error),(string)$ticket);
			}
			
			//ONLY IN CASE OF POSITIVE RESPONSE
			if((int)$chiss_resp[status] == 2)
			{
				//INSERT HEALTH_COACH AND SECONDARY_COACH IN PARENT WELLNESS ORDER				
				$filt = array("order.patientinfo.package_parent_id"=>$order);
				$proj = array("order.business"=>1);
				
				$cur = $dbo->findOne('masters','orders',$filt,$proj);

				$health_coach = $cur[order][business][health_coach];
				$secondary_coach = $cur[order][business][secondary_coach];
				
				$filt = array("_id"=>$order);
				$set = array("order.business.health_coach"=>$health_coach,
							 "order.business.secondary_coach"=>$secondary_coach
							);
				
				try
				{				
					$upd_cur = $dbo->update('masters','orders',$filt,$set,array(),array());
				}
				catch(Exception $e)
				{
					$Error = array("WellnessUpdationError"=>$e->getMessage());
					$logobj->create_log("","",getname(),"Execution",200,"asyncCall_Error",json_encode($Error),(string)$ticket);
				}
					
			}
		}

		else if($pay->option==6)
		{
			$payload = $pay->payload;
			try
			{				
				$pay = new Payments; 
				$payLink_resp = $pay->send_payment_link($payload, $ticket);
				$response['paymentLink_resp'] =  $payLink_resp;
			}
			catch(Exception $e)
			{
				$Error = array("paymentLinkError"=>$e->getMessage());
				$logobj->create_log("","",getname(),"Execution",200,"asyncCall_Error",json_encode($Error),(string)$ticket);
			}
			//print_r($payLink_resp);exit;
		}	

	}
	
	$logobj->create_log("","",getname(),"Execution",200,"asyncCall_end",json_encode($response),(string)$ticket);

	return json_encode($response); //COMMENTED
	
}//end of function */


function create_order_structure($business, $patients_data, $additionaldata, $payment_info) {
    //print_r($patients_data);exit;
    $utility = new Utility;
    $additionaldata['scheduled_date'] = $business->scheduled_date;
	
	///
	//$additionaldata['start_time'] = $business->start_time;
    //$additionaldata['end_time'] = $business->end_time;
	///
    $additionaldata['service_type'] = $business->service_type;
    //$additionaldata['service_subtype_id'] = $business->service_subtype;
	
	//FOR SELF ALLOC
	$business->createdById = $additionaldata[createdById];
	$business->createdByName = $additionaldata[createdByName];
	
	//FOR PACKAGE ORDERS
	if((int)$business->is_package == 1)
	{
		$additionaldata['end_date'] = $business->end_date;
		$additionaldata['primaryCoach'] = $business->primaryCoach;
		$additionaldata['wellness_speciality_code'] = $business->wellness_speciality_code;
	}
	
	//COMES IN CASE OF EQUIPMENT OR MEDICINE 
	if(isset($business->closedby))
	{
		$additionaldata['closedby'] = $business->closedby;
	}

	//For Diagnostic orders
	if((int)$business->service_type == 3)
	{
		$additionaldata['final_delivery_date'] = $business->final_delivery_date;
	}
	
	//For Medicine orders new field
	if((int)$business->service_type == 2 or (int)$business->service_type == 11)
	{
		$additionaldata['expected_delivery_date'] = $business->scheduled_date;
	}
	
	if(in_array($business->creation_type,[2,3]))
	{
		if(isset($business->ihs_batch_id))
		{
			$additionaldata['ihs_batch_id'] = $business->ihs_batch_id;
		}		
		
		if(isset($business->corporate_id))
		{
			$additionaldata['corporate_id'] =  $business->corporate_id;
		}
		
		if(isset($business->corporate_name))
		{
			$additionaldata['corporate_name'] = $business->corporate_name;
		}

		if(isset($business->corporate_nodeid))
		{			
			$additionaldata['corporate_nodeid'] = $business->corporate_nodeid;
		}
		
		if(isset($business->application_no))
		{			
			$additionaldata['application_no'] = $business->application_no;
		}
	}
	
	//SLOT_TRANSACTION ID
	$additionaldata['slot_transaction_id'] = $business->slot_transaction_id;
	
	
	if( !isset($business->report_required) or $business->report_required == 0)
	{
	   $additionaldata['report_required'] = 0;
    }
	else
	{
	   $additionaldata['report_required'] = 1;
	}
	
	//print_r($additionaldata);exit;
	$order_item = $business->order_item;
	
	
	//print_r($patients_data);exit;
	//print_r($business);exit;
    $gross_amount = $business->gross_amount;
	$net_amount = $business->net_amount;
	$wallet_amount = $business->wallet_amount;
	$coupon_amount = $business->coupon_amount;
	$voucher_amount = $business->voucher_amount;	
	//$markup_amount = $business->markup_amount;	
	$cli_amount = $business->cli;	
	$corporate_amount = $business->corporate_amount;
	
	if((int)$business->service_type == 11)
	{	
		$base_amount = $business->base_amount;
	}	
		
	
	//PAYMENT_AMOUNT
	if ((int) $payment_info->payment_amount > 0 and (int)$business->payment_code != 0) {
        //$payment_amount = $net_amount - ($wallet_amount + $coupon_amount + $voucher_amount);
		$payment_amount = $net_amount - ($wallet_amount +  $voucher_amount) - $corporate_amount;
    } else {
        $payment_amount = 0;
    }
	
	//PAYABLE_AMOUNT
	if((int)$business->payment_code == 0)
	{$payable_amount = $net_amount - ($wallet_amount +  $voucher_amount+$payment_amount) - $corporate_amount;
	}
	else
	{
		$payable_amount = 0;
	}

    $payment_info = array(
        "gross_amount" => $gross_amount,
        "discount_amount" => ($gross_amount-$net_amount),//$business->discount_amount,
        "net_amount" => $net_amount,
        "wallet_amount" => $wallet_amount,
        "voucher_amount" => $voucher_amount,
        "coupon_amount" => $coupon_amount,
		//"markup_amount"=>$markup_amount,
		"cli"=>$cli_amount,
        "surge_amount" => $business->surge_amount,//$payment_info->surge_amount,
        "payment_code" => $business->payment_code,//$payment_info->payment_code,
        "coupon" => $payment_info->coupon,
        "payment_mode" => $payment_info->payment_mode,//Can get from payment_code
        "payment_amount" => $payment_amount,
		"paid_amount" => $payment_amount,
		"payable_amount" => $payable_amount,  //payable by normal customer
		"corporate_payable_amount" => $corporate_amount,  //payable by corporate customer
        "payment_service" => $payment_info->payment_service,
        "payment_reference_id" => $payment_info->payment_reference_id,
        "voucher_assoc_code" => $payment_info->voucher_assoc_code,
        "voucher_assoc_name" => $payment_info->voucher_assoc_name,
        "voucher_code" => $payment_info->voucher_code
    );

	if(isset($payment_info->base_amount))
	{
		$payment_info['base_amount'] = $payment_info->base_amount;
	}		
	
	//ADVANCE PAYMENTS OBJECT
	if((int)$business->payment_code != 0)
	{
		//echo "123";exit;
		$receiptidseq = $utility->getNextSequence("receipt_id");
		
		$yr = date('y');
		$receiptid = "R-000-" . $yr . "-" . $receiptidseq;
		
		$receiptDate = $utility->getCurrentdatetimesimple();
		
		$advanceReceipt = array(
							"receipt_id" => $receiptid,
							"associate_id" => $business->associate_id,
							"associate_branch_id" => $business->associate_branch_id,
							"receipt_amount" => $payment_amount,
							"payment_mode" => $business->payment_code,//NAMES TO BE ADDED
							"payment_ref_no" => $payment_info[payment_reference_id],
							"payment_collected" => 1,
							"receipt_date" => $receiptDate,
							"receipt_status" => 1, //NEED TO CHECK IN CASE OF '100'
							"processed" => "NP",
							"submitted_to" => "", //NEED TO CHECK
							"payment_submited" => 1,
							"payment_submitted" => 1
							);
		
		if((int)$business->payment_code == 100)//IN CASE OF CASH COLLECTION BY CAREPLAN CCR
		{
			$advanceReceipt["mho_id"] = $additionaldata[createdById];
			$advanceReceipt["mho_name"] = $additionaldata[createdByName];
			$advanceReceipt["payment_submited"] = 0;
			$advanceReceipt["payment_submitted"] = 0;
			$advanceReceipt["payment_collected"] = 0;
			
		}
		$advanceReceipt = array($advanceReceipt);
	}
	else
	{
		$advanceReceipt = array();
	}
	
	if($voucher_amount > 0)
	{
		$receiptidseq = $utility->getNextSequence("receipt_id");
		
		$yr = date('y');
		$receiptid = "R-000-" . $yr . "-" . $receiptidseq;
		
		$receiptDate = $utility->getCurrentdatetimesimple();
		
		$voucherReceipt = array(
							"receipt_id" => $receiptid,
							"type" => 3,
							"associate_id" => $business->associate_id,
							"associate_branch_id" => $business->associate_branch_id,
							"receipt_amount" => $voucher_amount,
							"payment_mode" => "9",//NAMES TO BE ADDED
							//"payment_ref_no" => $payment_info->payment_reference_id,
							"voucher_code" => $payment_info['voucher_code'],
							"voucher_assoc_code" => $payment_info['voucher_assoc_code'],
							"payment_collected" => 1,
							"receipt_date" => $receiptDate,
							"receipt_status" => 1, //NEED TO CHECK IN CASE OF '100'
							"processed" => "NP",
							"submitted_to" => "", //NEED TO CHECK
							"payment_submited" => 1,
							"payment_submitted" => 1
							);
							
		$advanceReceipt[] = $voucherReceipt;					
	}		
	

    $patientinfo = array_merge((array) $patients_data, (array) $additionaldata, $payment_info);
    $services_with_associate = array(3, 4, 1, 6, 7, 8, 14);

    if (in_array((int) $patientinfo['service_type'], $services_with_associate)) {

        $associate = array(
            "associate_name" => $business->associate_name,
            "associate_id" => $business->associate_id,
            "associate_address" => $business->associate_address,
            "associate_location" => $business->associate_location,
            "associate_popid" => $business->associate_popid,
            "associate_popname" => $business->associate_popname,
            "associate_branch_id" => $business->associate_branch_id,
            "associate_lat" => $business->associate_latitude,
            "associate_long" => $business->associate_longitude,
            "contact_number" => $business->associate_contact_number,
            "email" => $business->associate_email_id,
            "officer_id" => $business->associate_officer_id,
            "website_url" => $business->associate_website_url,
            "license_number" => $business->associate_license_number,
            "associate_gst_number" => $business->associate_gst_number,
            "skill" => $business->associate_skill,
			"role" => $business->associate_role
			//,"mode_of_service" => $business->mode_of_service
			//,"slot_transaction_id"=> $business->slot_transaction_id
        );

       /*  if ($business->service_type == 1) {
            //constrcuting appointment array
            $appiontment_data = array(
				"status"=>"1",
                "patientId" => $patients_data->patient_id,
                "mrn" =>(string) $patients_data->mrn,
				"age" => $patients_data->age,
				"gender" => $patients_data->gender,
                "conferenceType" => $business->conferenceType,
                "consultationType" => $business->consultationType,
				"isinternal" => $business->isinternal,
                "speciality" => $business->speciality,
                "doctorId" => $business->doctorId,
                "serviceSubTypeId" => $business->service_subtype,
                "serviceTypeId" => $business->service_type,
                "reason" => $business->reason,
				"item_code"=>$order_item[0]->item_code,
                "scheduledTime" => $business->scheduled_date,
				"servicedate"=>new MongoDate(strtotime($business->scheduled_date)),
				"slot_transaction_id"=> $business->slot_transaction_id,//ADDED on 25/02/19
                "duration" => $business->duration,
                "endDateTime" => date('Y-m-d H:i:s', strtotime('+' . $business->duration . ' minutes', strtotime($business->scheduled_date))),
                "createdById" => $additionaldata['createdById'],
                "createdByName" => $additionaldata['createdByName'],
                "createdDate" => date("Y-m-d H:i:s"),
                "facilityId" => $patients_data->facility_id,
                "mode_of_service" => $business->mode_of_service,
                "customerFirstName" => $patients_data->salutation,
                "customerLastName" => $patients_data->name,
                "invoiceto" => '',
                "reportto" => '',
                "corporateinvoiceemail" => '',
                "corporatereportemail" => ''
            );

            //merging array to create appointment data
            $appiontment = array("type" => $business->service_type, "appointment_info" => $appiontment_data, "associate_info" => $associate, "payment_info" => $payment_info);
			
			
            return $appiontment;
        }
    
	
	
	 */
	
	} else {
        $associate = array();
    }

	 //unset((array)$business['order_item']); 
	$business->is_parent=1;
	
    $order = array("source" => $additionaldata['channel'], "type" => $business->service_type, "patientinfo" => $patientinfo, "orderitem" => $order_item, "associate" => $associate, "mode_of_service" => $business->mode_of_service,"advance_receipt"=>$advanceReceipt,"payment_info" => $payment_info,"business"=>$business,"additionaldata"=>$additionaldata);
    return $order;
}


function create_order_structure_drug($business, $patients_data, $additionaldata, $payment_info,$set_order){
	$utility = new Utility;
    $additionaldata['scheduled_date'] = $business->scheduled_date;
    $additionaldata['service_type'] = $business->service_type;
    $additionaldata['service_subtype_id'] = $business->service_subtype;
	$net_amount = (float) $business->net_amount;
    $gross_amount = (float) $business->gross_amount;
    $wallet_amount = (float) $business->wallet_amount;
    $coupon_amount = (float) $business->coupon_amount;
    $voucher_amount = (float) $business->voucher_amount;
    if ((float) $payment_info->payment_amount > 0) {
        $payment_amount = $net_amount - ($wallet_amount + $coupon_amount + $voucher_amount);
    } else {
        $payment_amount = 0;
    }
	$findratio = (float)$set_order["gross"] / (float) $gross_amount;
	$set_net_amount = (float) $set_order["net"];
	$set_wallet_amount = (float) $business->wallet_amount  * $findratio;
	$set_coupon_amount = (float) $business->coupon_amount  * $findratio;
	$set_voucher_amount = (float) $business->voucher_amount  * $findratio;
	if ((float) $payment_info->payment_amount > 0) {
		$set_payment_amount = $set_net_amount - ($set_wallet_amount + $set_coupon_amount + $set_voucher_amount);
	} else {
		$set_payment_amount = 0;
	}
	$payment_info = array(
		"gross_amount" => $set_order["gross"],
		"discount_amount" => $set_order["discount"],
		"net_amount" => $set_order["net"],
		"wallet_amount" => $wallet_amount * $findratio,
		"voucher_amount" => $voucher_amount * $findratio,
		"coupon_amount" => $coupon_amount * $findratio,
		"payment_code" => $payment_info->payment_code,
		"payment_mode" => $payment_info->payment_mode,
		"payment_amount" => $set_payment_amount,
		"payment_service" => $payment_info->payment_service,
		"payment_reference_id" => $payment_info->payment_reference_id,
		"voucher_assoc_code" => $payment_info->voucher_assoc_code,
		"voucher_assoc_name" => $payment_info->voucher_assoc_name,
		"voucher_code" => $payment_info->voucher_code
	);
	$patientinfo=array();
	$patientinfo = array_merge((array) $patients_data, (array) $additionaldata, $payment_info);
	$order = array("additionaldata"=>$additionaldata,"source" => $additionaldata['source'], "type" => $business->service_type, "patientinfo" => $patientinfo, "orderitem" => $set_order[itemdetails], "mode_of_service" => $business->mode_of_service, "payment_info" => $payment_info);
    return $order;
}

function create_packegebydraftorder($request,$response){
    $jdcode = json_decode($request->getBody());
    $order_id = $jdcode->order_id;
    $draftCall= new Wellness;
    $draftOrder= $draftCall->create_packegebydraftorder($order_id);
    print_r($draftOrder);
}

function cancel_wellness_order($request, $response) 
{ 
	$apiobj=new Apihandler;
	$payload = $apiobj->apirequest($request,getname());
	//print_r($payload);exit;
	$package = new Package;
	$apiresponse= $package->cancel_wellness_order($payload);
	$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
	return $response;
}


function createTransaction_ihs($request, $response) {
   
	
	//LOGGING
	$logobj=new Logapp;
	$logobj->create_log("","",getname(),"Execution",200,"createTransaction_start",$request,(string)$ticket);

	try
	{
		//Create Instances
		$utility = new Utility;
		$gcm = new Gcm;
		$associate = new Associate;
		$mdm = new Mdm;
	
		$apiobj=new Apihandler;
	    $payload =(array) $apiobj->apirequest($request,getname());
		
		
		//Validation COMMENTED
		$utilresponse = $utility->verify_transaction($payload);

		if ($utilresponse['status'] == 0) {
			echo json_encode($utilresponse);
			exit;
		}
		$source = isset($payload['channel']) ? $payload['channel'] : "";

		
		//GATHERING DATA FROM THIRD-PARTY APIS	
		$orders = $payload[orders];
		$item_data = [];
		
		//Insertion Buffers used at last
		$app_array = array();
		$order_array = array();
		$workorder_array = array();
		$orderlog_array = array();
		$transaction_array = array();
		
		
		$ord_num = 0;
		foreach($orders as $each_order)
		{
			$mrns_required[] = $each_order->mrn;
			$address_ids_required[] = $each_order->address_id;
			
			$service_type = $each_order->service_type;
			$order_item = $each_order->order_item;
			
			
			//Associate IN CASE OF BELOW SERVICE_TYPE ORDERS AND NON-INTERNAL CONSULTATION ORDERS
			if (in_array((int)$service_type, array(3, 4, 1, 6, 7, 8, 14)) == true and 
				(int)$each_order->internal == 0)
			{
			                     $associates[] = (object) array("associate_id"=>$each_order->associate_id,
								  "branch_id"=>$each_order->associate_branch_id
								  ,"creation_type"=>$each_order->creation_type);
			}
			
			//DOCTOR ORDER IS A CONSULTATION ORDER(10 == 1)
			if((int)$service_type==10)
			{
				$payload[orders][$ord_num]->service_type = "1";
			}
			
			$item_codes = array();
			$external_codes = array();
			foreach($order_item as $item)
			{
				if((int)$item->roleBasedService == 0)
				{
					if((string)$service_type=="1" and (int)$each_order->internal == 0 and 
						(int)$each_order->is_assessment!=1) 
					{
						$external_codes[] = $item->item_code;
					}
					else
					{
						$item_codes[] = $item->item_code;
					}
				}	
			}
			
			//ADDED FOR UNIQUE ITEM CODES
			$external_codes = array_values(array_unique($external_codes));
			$item_codes = array_values(array_unique($item_codes));
			
			//Service type:1 and is_consultation requires internal or external doctor specification
			if((string)$service_type=="1")
			{
				/* if((!empty($item_codes) or !empty($external_codes)) 
											and (int)$each_order->is_assessment!=1)
				{
					$item_data[] = array("business"=>"10",//FOR MDM IN CASE OF CONSULTATION
								 "itemcodes"=>$item_codes,
								 "externalCodes"=>$external_codes
								);
				}
				
				else */
				
				if(!empty($item_codes))
				{  
					$item_data[] = array("business"=>(string)$service_type,
								 "itemcodes"=>$item_codes,
								 "externalCodes" => $external_codes
								);
				}					
			}
			
			else
			{
				if(!empty($item_codes))
				{
					$item_data[] = array("business"=>(string)$service_type,
									 "itemcodes"=>$item_codes
									);
				}					
			}
			
			$ord_num++;
		}
		
		
		$mrns_required = call_user_func_array('array_merge', $mrns_required);
		$address_ids_required = call_user_func_array('array_merge', $address_ids_required);
		
		//print_r($mrns_required);print_r($address_ids_required);exit;
		//print_r($associates);exit;
		//print_r($item_data);exit;
		
		
		//THIRD PARTY API CALLS
		$patient_info = $gcm->get_mrn_address_info($mrns_required,$address_ids_required);
		
		//IN CASE OF orders that don't require associate details
		if(!empty($associates))
		{
			$associate_info = $associate->get_associate_info($associates);
			if(isset($associate_info['status']))
			{
				return $associate_info;
			}
		}
		else
		{
			$associate_info =array();
		}
		
		//IN CASE OF all roleBasedService items in a order need not call MDM
		if($item_data!=null and !empty($item_data))
		{
			$item_payload = array("data"=>$item_data);
			//print_r($item_payload);exit;
			$item_info = $mdm->get_line_item_info($item_payload);
		}
	
	    //print_r($patient_info);exit;
		//print_r($associate_info);exit;
		//print_r($item_info);exit;
		
		foreach($orders as $each_order)
		{
			$order_set = array();
			$transaction_id = $utility->getNextSequence("TRANSACTION");
			$date = date('dmy');
			$transaction_code = $source . "-" . $date . "-" . $transaction_id;
			
			//Making Orderinfo
			$associate_index = $each_order->associate_id."_".$each_order->associate_branch_id;
			$associate_details = $associate_info[$associate_index];
			$order_temp = $each_order;
			
			foreach($associate_details as $key=>$value)
			{
				$order_temp->$key = $value;
			}
			 
			//Adding Iteminfo
			$item_temp = $order_temp->order_item;
			$servicetype = $order_temp->service_type;
			$i = 0;
			foreach($item_temp as $item_level_temp)
			{
				//THIS CHANGE IS REVERTED 
				/* if((int)$servicetype!=3 and (int)$servicetype!=4)
				{
					unset($item_temp[$i]->reportto);
					unset($item_temp[$i]->invoiceto);
					unset($item_temp[$i]->corporateinvoiceemail);
					unset($item_temp[$i]->corporatereportemail);
				} */
				
				//FOR MEDICINE BUSINESS ITEM_MRP IS ALSO ADDED
				if((int)$servicetype == 2 and $item_temp[$i]->roleBasedService == 0)
				{
					$item_temp[$i]->item_mrp = $item_temp[$i]->MRP;
					$item_temp[$i]->old_item_mrp = $item_temp[$i]->MRP;
					$item_temp[$i]->old_gross_amount = $item_temp[$i]->gross_amount;
					$item_temp[$i]->old_discount_amount = $item_temp[$i]->discount_amount;
					$item_temp[$i]->old_net_amount = $item_temp[$i]->net_amount;
					$item_temp[$i]->old_quantity = $item_temp[$i]->quantity;
				}
				
				foreach($item_info[$item_level_temp->item_code] as $key=>$value)
				{
					//$item_temp[$i]->item_name = $item_info[$item_level_temp->item_code][item_name];
					$item_temp[$i]->$key = $value;
					
					//GET tatHours in diagnostic orders
					if($key == 'tatHours' and (int)$servicetype==3)
					{
						$tatHours = $value;
						$from = substr(date("c", strtotime($each_order->scheduled_date)), 0, 19) . ".000Z";
						
						$to = substr(date("c", strtotime(date('Y-m-d H:i:s',strtotime('+'.$tatHours.'hour',strtotime($each_order->scheduled_date))))), 0, 19) . ".000Z";
						
						$item_temp[$i]->reportdeliverydatefrom = $from;
						$item_temp[$i]->reportdeliverydateto = $to;

					}
				}
				
				//IF NO TATHOURS IS PRESENT DEFAULT IS 24HRS  
				if(!array_key_exists("tatHours", $item_info[$item_level_temp->item_code]) and (int)$servicetype==3)
				{
					$to = substr(date("c", strtotime(date('Y-m-d H:i:s',strtotime('+'.'24hour',strtotime($each_order->scheduled_date))))), 0, 19) . ".000Z";
				}
				
				$item_temp[$i]->item_status = "0";
				
				$i++;
			}
			$order_temp->order_item = $item_temp;
			
			//report delivery date to in diagnostic orders
			if((int)$servicetype == 3)
			{
				$order_temp->final_delivery_date = $to;
			}
			
			$business_info_level = $order_temp;
			//print_r($business_info_level);exit;
			
			
			//Previously mrn,address_id are arrays in payload, we want specific mrn,add_id to which the order is for so we unset it and add it in iteration on mrn array
			$transaction_mrns = $business_info_level->mrn;
			$transaction_address_ids = $business_info_level->address_id;
			unset($business_info_level->mrn);
			unset($business_info_level->address_id);
			
			
			//Making Additional Info
			$additionaldata = array(
				//"source_id" => $payload['source_id'],
				"channel" => $payload['channel'],
				//"created_date" => $payload['created_date'],
				"source_of_referral" => $payload['source_of_referral'],
				"referral_id" => $payload['referral_id'],
				"referral_mrn" => $payload['referral_mrn'],
				"createdById" => $payload['created_by_id'],
				"createdByName" => $payload['created_by_name']
			);
			
			//Making Payment Info
			$payment_info = $payload['payment_info'];
		
			
			//EACH ORDER FOR EACH MRN,ADDRESS_ID PAIR	
			for($j=0;$j<count($transaction_mrns);$j++)
			{
				//Making Patientinfo
				$patient_info_level = array_merge($patient_info[mrn][$transaction_mrns[$j]], 
									$patient_info[address_id][$transaction_address_ids[$j]]);
				
				//Set business specific mrn,address_id (unset previously)
				$business_info_level->mrn = $each_order->mrn[$j];
				$business_info_level->address_id = $each_order->address_id[$j];
				
				//print_r((object)$patient_info_level);exit;	
				
				$order = create_order_structure($business_info_level, (object)$patient_info_level, $additionaldata, $payment_info);
					
				array_push($order_set, $order);
			}
			
			//print_r($order_set);exit;
			
			//INSERTING THE TRANSACTIONS IN DB AND CREATING ORDERS(in below function)
			$order = new Order;
			$dbo = new Dbo;
			
			//print_r($order_set);exit;
			$appresponse = $order->insertTransaction($order_set, $transaction_code, $payload);
			
			//print_r($appresponse[set]);exit;
			
			
			if($appresponse[set][order] != null)
			{
				$order_array[] = $appresponse[set][order];
			}
			
			if($appresponse[set][workorders] != null)
			{
				$workorder_array[] = $appresponse[set][workorders];
			}
			
			if($appresponse[set][orderlog] != null)
			{
			$orderlog_array[] = $appresponse[set][orderlog];
			}
			
			if($appresponse[set][transaction] != null)
			{
				$transaction_array[] = $appresponse[set][transaction];
				$order_info_array[] = $appresponse[set][order_info];
			}
			
			if($appresponse[response] != null and isset($appresponse[response][transaction]))
			{
				$tr_codes[] = $appresponse[response][transaction];
			}	
			//print_r($order_array);exit;
			//TO BE SENT FOR ORDER CREATION USING INSERT TRANSACTION
		}
		
		
		if(isset($order_array) and !empty($order_array))
		{
			$order_array = call_user_func_array('array_merge', $order_array);
			//echo json_encode($order_array);exit;
			foreach($order_array as $ord)
			{
				$o_id = $ord['_id'];
				$w_id = $ord['wid'];
				$component_id = $ord['active_component'];
				
				$wflow = new OrderWorkFlow;
				$intdbResp = $wflow->send_associate($o_id, $w_id, 6, $component_id, 1, 1);
			}
			
			$insert_response = $dbo->insertMany('masters','orders',$order_array);
		}
		if(isset($workorder_array) and !empty($workorder_array))
		{
			$workorder_array = call_user_func_array('array_merge', $workorder_array);
			//echo json_encode($workorder_array);exit;
			$insert_response = $dbo->insertMany('masters','workorders',$workorder_array);
		}
		if(isset($orderlog_array) and !empty($orderlog_array))
		{
			$orderlog_array = call_user_func_array('array_merge', $orderlog_array);
			//echo json_encode($orderlog_array);exit;
			$insert_response = $dbo->insertMany('masters','orderlog',$orderlog_array);
		}
		if(isset($transaction_array) and !empty($transaction_array))
		{
			$insert_response=$dbo->insertMany('masters','transaction',$transaction_array);
		}
		
		//echo json_encode($response_array);
		if(isset($tr_codes) and !empty($tr_codes))
		{
			$response_array = array("transaction"=>$tr_codes,"status"=>"1","message"=>"Transactions created Successfully","order_info"=>$order_info_array);
		}
	}
	
	catch(Exception $e)
	{
		echo 'Message: ' .$e->getMessage();
		$logobj->create_log("","",getname(),"Execution",300,"Error_createTransaction",$e->getMessage(),(string)$ticket);
		exit;
	}
	
	
	$logobj->create_log("","",getname(),"Execution",200,"createTransaction_end",json_encode($response_array),(string)$ticket);
	
	$response = $apiobj->apiresponse($response,getname(),$response_array, $payload->ticket);
	return $response;
}	



/* function update_order($request,$responce)
{
    $payload = json_decode($request->getBody());

    //$associate_id_branch_id = $payload->associate_id_branch_id;

    $order_id = $payload->order_id;
    /*$db = getDBmasters();
    $collection = $db->orders;//
    $dbo_obj= new Dbo;

    $associate_details = get_associate_info($payload->associate_id_branch_id);

    $filter=array("order_id"=>(int)$order_id);
    $update=array('$set'=>array("order.provider_info"=>$associate_details))

    $dbo_obj->findAndModify("masters","orders",$filter,$update);

} */


?>
