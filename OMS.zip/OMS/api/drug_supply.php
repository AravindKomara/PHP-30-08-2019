<?php
require 'vendor/autoload.php';
require '../order.php'; 
require 'apihandler.php';
	
ini_set('memory_limit', '-1');
date_default_timezone_set("Asia/Calcutta");
$app = new Slim\App();

$app->post('/v1/create_careplan','create_careplan');
$app->post('/v1/update_careplan','update_careplan');
$app->post('/v1/fetch_careplan','fetch_careplan');
$app->run();
	
	
	function getname()
	{
		return "careathome";
	}
	
	//code is shared with cp needs to be merged inline with order

	/*function create_careplan($request, $response)
	{
           $apiobj=new Apihandler;
			$payload = $apiobj->apirequest($request,getname()); 
			$careobj = new Care;
			$apiresponse = $careobj->create_careplan($payload,$payload->ticket);
			$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
			return $response;	 
	}
        
    function update_careplan($request, $response)
	{
            $apiobj=new Apihandler;
			$payload = $apiobj->apirequest($request,getname()); 
			$careobj = new Care;
			$apiresponse = $careobj->care_plan_update($payload,$payload->ticket);
			$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
			return $response;	 
	}
     
	function fetch_careplan($request, $response)
	{
            $apiobj=new Apihandler;
			$payload = $apiobj->apirequest($request,getname()); 
			$careobj = new Care;
			$apiresponse = $careobj->fetch_careplan($payload,$payload->ticket);
			$response = $apiobj->apiresponse($response,getname(),$apiresponse, $payload->ticket);
			return $response;	 
	}*/
 

 ?>