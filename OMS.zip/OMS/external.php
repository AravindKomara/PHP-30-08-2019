<?php
include 'libraries/mdm.php';
include 'libraries/gcm.php';
include 'libraries/associate.php';
include 'libraries/chiss.php';

/*



include 'libraries/smsemail.php';
//include 'libraries/corporate.php';
 */

?>
