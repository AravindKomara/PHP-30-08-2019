<?php
class Utility
{

    public function assigning_role($role)
    {
        if ($role == 1) {
            $role_name = "SUPER ADMIN";
        } else if ($role == 2) {
            $role_name = "PHELP ADMIN";
        } else if ($role == 4) {
            $role_name = "CHISS";
        }
        return $role_name;
    }

    public function service_component_map($servicetype, $mode_of_service, $report_required = 0, $is_assessment = 0)
    {
        $component = array();
        if ($servicetype == 1 or $servicetype == '1') //Econsultation
        {
            if ($is_assessment == 1) {
                $component[] = '2';
            } else {
                if ($mode_of_service == 2) {
                    $component[] = '3';
                } else if ($mode_of_service == 1) {
                    $component[] = '2';
                } else {
                    $component[] = '5';
                }
            }
        }

        if ($servicetype == 10 or $servicetype == '10') //Econsultation
        {
            if ($mode_of_service == 2 or $mode_of_service == '2') {
                $component[] = '4';
            } else if ($mode_of_service == 1 or $mode_of_service == '1') {
                $component[] = '2';
            } else {
                $component[] = '5';
            }

        } elseif ($servicetype == 2 or $servicetype == '2') //Drugs
        {
            //$component[] = '10';
            $component[] = '9';
			//$component[] = '8';
			
			if($mode_of_service == 2)
			{
				$component[] = '15';
			}
			else
			{
				// for thirdparty inetration
				$component[] = '13';
			}

            //DIFFERENT CASE IN MEDICINE ACTIVE COMPONENT IS 9
            //$map = array("active_comp" => $component[1], "components" => $component);
            //return $map;

        } elseif ($servicetype == 3 or $servicetype == '3') //Diagnostic
        {
            if ($mode_of_service == 2 or $mode_of_service == '2') {
                $component[] = '3';
            } else {
                $component[] = '1';
            }
            $component[] = '7';
            if ($report_required == 1 or $report_required == '1') {
                //$component[] = '8';
				// for thirdparty inetration
				$component[] = '13';
            }
        } elseif ($servicetype == 4 or $servicetype == '4') //Facilitation
        {
            $component[] = '3';
            //$component[] = '7';
            if ($report_required == 1 or $report_required == '1') {
                //$component[] = '8';
				// for thirdparty inetration
				$component[] = '13';
            }
        } elseif ($servicetype == 6 or $servicetype == '6' or $servicetype == 7 or $servicetype == '7' or $servicetype == 8 or $servicetype == '8') //C@H
        {
            $component[] = '2';
        } elseif ($servicetype == 11 or $servicetype == '11') //Equipment
        {
            //$component[] = '10';
            $component[] = '9';
            $component[] = '8';
			// for thirdparty inetration
            //$component[] = '13';

            //DIFFERENT CASE IN EQUIPMENT ACTIVE COMPONENT IS 9
            //$map = array("active_comp" => $component[1], "components" => $component);
            //return $map;

        } elseif ($servicetype == 13 or $servicetype == '13' or $servicetype == 14 or $servicetype == '14') //EWellness
        {
            $component[] = '2';
        }

        $map = array("active_comp" => $component[0], "components" => $component);
        return $map;

    }

    public function convert_date($date)
    {
        /*TO CONVERT FROM OMS Date to CHISS Date
        eg: 2018-01-01T12:00:00.000Z to 2018-01-01 12:00:00 */
        $modified_date = substr($date, 0, 10) . " " . substr($date, 11, 8);
        //echo $modified_date;exit;
        return $modified_date;
    }

    public function modify_date($date)
    {
        /*TO CONVERT FROM CHISS Date to OMS Date
        eg: 2018-01-01 12:00:00 to 2018-01-01T12:00:00.000Z */
        //$new_date = $date . 'T00:00:00.000Z';

        $date = str_replace(" ", "T", $date);
        $new_date = $date . '.000Z';

        return $new_date;
    }

    public function validateDate_Ymd($date, $format = 'Y-m-d')
    {
        $d = DateTime::createFromFormat($format, $date);
        return $d && $d->format($format) == $date;
    }

    public function validateDate_His($date, $format = 'H:i:s')
    {
        $d = DateTime::createFromFormat($format, $date);
        return $d && $d->format($format) == $date;
    }

    public function validateDate($date, $format = 'Y-m-d H:i:s')
    {
        $d = DateTime::createFromFormat($format, $date);
        return $d && $d->format($format) == $date;
    }

    public function json_validate($string)
    {
        // decode the JSON data
        $result = json_decode($string);

        // switch and check possible JSON errors
        switch (json_last_error()) {
            case JSON_ERROR_NONE:
                $error = ''; // JSON is valid // No error has occurred
                break;
            case JSON_ERROR_DEPTH:
                $error = 'The maximum stack depth has been exceeded.';
                break;
            case JSON_ERROR_STATE_MISMATCH:
                $error = 'Invalid or malformed JSON.';
                break;
            case JSON_ERROR_CTRL_CHAR:
                $error = 'Control character error, possibly incorrectly encoded.';
                break;
            case JSON_ERROR_SYNTAX:
                $error = 'Syntax error, malformed JSON.';
                break;
            // PHP >= 5.3.3
            case JSON_ERROR_UTF8:
                $error = 'Malformed UTF-8 characters, possibly incorrectly encoded.';
                break;
            // PHP >= 5.5.0
            case JSON_ERROR_RECURSION:
                $error = 'One or more recursive references in the value to be encoded.';
                break;
            // PHP >= 5.5.0
            case JSON_ERROR_INF_OR_NAN:
                $error = 'One or more NAN or INF values in the value to be encoded.';
                break;
            case JSON_ERROR_UNSUPPORTED_TYPE:
                $error = 'A value of a type that cannot be encoded was given.';
                break;
            default:
                $error = 'Unknown JSON error occured.';
                break;
        }

        if ($error !== '') {
            $response = array("status" => 0, "message" => $error);
            echo json_encode($response);
            exit;
        } else {
            return $result;
        }
    }

    public function log_message($message, $type)
    {
        if (sizeof($message) != 0) {
            $response = array('status' => 0, 'message' => $message);

        } else {
            $response = array('status' => 1, 'message' => 'Transaction Payload Verified');
        }
        // print_r($response);
        return $response;
    }

    public function verify_transaction($payload)
    {
        $error_message = array();

        $info_data = array("mrn" => "string", "channel" => "integer",
            "source_of_referral" => "string",
            "referral_id" => "string", "created_by_id" => "string");

        //Mrn Validation
        if (!ctype_digit($payload["mrn"])) {
            array_push($error_message, "mrn should be numeric field");
        }

        //Remaining Fields
        foreach ($info_data as $key => $value) {
            if (array_key_exists($key, $payload)) {
                if (strcmp(gettype($payload[$key]), $value) == 0) {
                    //echo $info_data[$key].'  '.$value;

                    if (strlen(trim($payload[$key])) == 0 and
                        strcmp($key, "created_by_id") == 0) {
                        array_push($error_message, $key . " field has value missing");
                    }
                } else {
                    array_push($error_message, $key . " field is invalid");
                }
            } else {
                array_push($error_message, $key . " field is missing");
            }
        }

        //NEED ATLEAST ONE OF ORDERS OR PENDING_PAYMENTS ARRAY FILLED
        if ((empty($payload['orders']) or !isset($payload['orders'])) and (empty($payload['pending_payments']) or !isset($payload['pending_payments']))) {
            array_push($error_message, "Atleast one of orders or pending_payments array need to be filled.");
            return $this->log_message($error_message, 'error');
        }

        //Business Data Validation
        $business_data = $payload['orders'];
        $i = 1;

        $transaction_payable_amount = 0.00;
        $transaction_gross_amount = 0.00;
        $transaction_discount_amount = 0.00;
        $transaction_net_amount = 0.00;
        $transaction_voucher_amount = 0.00;
        $transaction_wallet_amount = 0.00;
        $transaction_coupon_amount = 0.00;
        //$transaction_markup_amount = 0.00;
        $transaction_cli_amount = 0.00;
        $transaction_surge_amount = 0.00;
        $transaction_base_amount = 0.00;
        $transaction_corporate_amount = 0.00;

        foreach ($business_data as $business) {
            $total_business_gross_amount = 0.00;
            $total_business_discount_amount = 0.00;
            $total_business_net_amount = 0.00;
            $total_business_voucher_amount = 0.00;
            $total_business_wallet_amount = 0.00;
            $total_business_coupon_amount = 0.00;
            //$total_business_markup_amount = 0.00;
            $total_business_cli_amount = 0.00;
            $total_business_base_amount = 0.00;
            $total_business_corporate_amount = 0.00;

            $service_type = $business->service_type;
            //print_r($business);

            ///
            //IHS ORDER CREATION CORRECTION
            if ($business->creation_type == 3) {
                if (!is_array($business->mrn)) {
                    array_push($error_message, 'mrn in business ' . $i . ' is invalid, need a array');
                }
                if (!is_array($business->address_id)) {
                    array_push($error_message, 'address_id in business ' . $i . ' is invalid, need a array');
                }
            } else if (in_array($business->creation_type, [1, 2])) {
                if (!is_numeric($business->mrn)) {
                    array_push($error_message, 'mrn in business ' . $i . ' is invalid, need a numeric string');
                }
                if (!is_numeric($business->address_id)) {
                    array_push($error_message, 'address_id in business ' . $i . ' is invalid, need a numeric string');
                }
            }

            ///

            //Edit below array for valid fields and types

            if ($service_type == 2) {

                $business_info_data = array("mrn" => "string",
                    "address_id" => "string",
                    "service_type" => "string",
                    //"service_subtype"=>"string",
                    "creation_type" => "integer",
                    "scheduled_date" => "string",
                    "payment_code" => "string",
                    //"wallet_amount"=>"double",
                    //"voucher_amount"=>"double",
                    //"coupon_amount"=>"double",
                    "mode_of_service" => "integer");

            } else {
                $business_info_data = array("mrn" => "string",
                    "address_id" => "string",
                    "service_type" => "string",
                    //"service_subtype"=>"string",
                    "scheduled_date" => "string",
                    "payment_code" => "string",
                    ///
                    //"start_time"=>"string",
                    //"end_time"=>"string",
                    ///
                    "creation_type" => "integer",
                    //"surge_amount"=>"double", //INT OR DOUBLE
                    //"wallet_amount"=>"double",
                    //"voucher_amount"=>"double",
                    //"coupon_amount"=>"double",
                    //"associate_name"=>"string",
                    //"associate_lat"=>"string",
                    //"associate_long"=>"string",
                    //"associate_address"=> "string",
                    //"associate_Location"=> "string",
                    //"associate_popname"=> "string",
                    //"associate_popid"=> "string",
                    //"associate_contact_number"=>"string",
                    //"associate_email" => "string",
                    //"associate_officer_id" => "string",
                    //"associate_website_url" => "string",
                    //"associate_license_number" => "string",
                    //"associate_gst_number" => "string",
                    "mode_of_service" => "integer",
                    // "report_required"=>"integer"
                );

                if ((!in_array((int) $service_type, [1, 10]) or (int) $business->internal == 0) and
                    (int) $business->is_assessment != 1 and (int) $business->is_transaction != 1 and (int) $business->is_package != 1) {
                    $business_info_data["associate_id"] = "string";
                    $business_info_data["associate_branch_id"] = "string";
                }

                if (in_array((int) $service_type, [1, 10]) and (!isset($business->is_assessment) or (int) $business->is_assessment != 1)) {
                    //Only in case of non-assessment
                    $business_info_data["internal"] = "integer";
                    $business_info_data["mer"] = "integer";
                    $business_info_data["duration"] = "string";
                    $business_info_data["consultationType"] = "string";
                    $business_info_data["doctorName"] = "string";
                    $business_info_data["doctorId"] = "string";
                    $business_info_data["specialityId"] = "string";
                }

                if ($service_type == 14 and (int) $business->is_package == 1) {
                    $business_info_data["primaryCoach"] = "string";
                    $business_info_data["end_date"] = "string";
                    $business_info_data["wellness_speciality_code"] = "string";
                }

                if ((int) $business->is_continous == 1 or
                    (int) $business->is_transaction == 1) {
                    $business_info_data["repeats"] = "integer";
                    $business_info_data["sessionsPerDay"] = "integer";
                    $business_info_data["frequency"] = "integer";
                }

            }

            //echo $this->validateDate($business->{scheduled_date});
            //echo $business->scheduled_date;

            foreach ($business_info_data as $key => $type) {
                if (property_exists($business, $key)) {
                    if (!isset($business->{$key})) {
                        array_push($error_message, $key . ' for business ' . $i . ' field is missing');
                    } else if (gettype($business->{$key}) != $type and $key != 'mrn' and $key != 'address_id') {
                        array_push($error_message, $key . ' for business ' . $i . ' field is Invalid');
                    } else {
                        if ( //strcmp($key,"mrn")==0 or
                            //strcmp($key,"address_id")==0 or
                            strcmp($key, "service_type") == 0
                            or strcmp($key, "service_subtype") == 0
                            or strcmp($key, "associate_contact_number") == 0
                            or strcmp($key, "payment_code") == 0
                            or strcmp($key, "internal") == 0 //THIS IS TEMPERORY FIX
                        ) {
                            if (!is_numeric($business->{$key})) {
                                array_push($error_message, $key . ' in business ' . $i . ' must be a numeric field');
                            }
                        } elseif (strcmp($key, "associate_id") == 0
                            or strcmp($key, "primaryCoach") == 0
                            or strcmp($key, "doctorId") == 0) {
                            if (!ctype_alnum($business->{$key})) {
                                array_push($error_message, $key . ' in business ' . $i . ' must be a alpha-numeric field');
                            }
                        } elseif (strcmp($key, "associate_name") == 0
                            or strcmp($key, "consultationType") == 0
                            or strcmp($key, "doctorName") == 0) {
                            if (strlen($business->{$key}) == 0) {
                                //echo $key;
                                array_push($error_message, $key . ' in business ' . $i . ' is empty');
                            }
                        }

                    }

                    if (strcmp($key, "scheduled_date") == 0
                        or strcmp($key, "end_date") == 0) {
                        //echo $this->validateDate($business->{$key}));exit;
                        if ($this->validateDate($business->{$key}) == false) {
                            array_push($error_message, $key . ' for business ' . $i . ' is Invalid');
                        }

                        //Past Date NORMAL orders wont be accepted
                        $now = date("Y-m-d H:i:s");
                        if ($business->{$key} < $now and
                            $business->creation_type == 1 and $payload[dateIgnore] != 1) {
                            array_push($error_message, $key . ' for business ' . $i . ' is Past Date');
                        }

                    }

                    //Will be added if required
                    /*
                if (strcmp($key,"scheduled_date") == 0)
                {
                //echo $this->validateDate_Ymd($business->{$key}));exit;
                if($this->validateDate_Ymd($business->{$key}) == false)
                {
                array_push($error_message, $key.' for business '.$i.' is Invalid');
                }
                }

                if (strcmp($key,"start_time") == 0 or
                strcmp($key,"end_time") == 0)
                {
                //echo $this->validateDate_His($business->{$key}));exit;
                if($this->validateDate_His($business->{$key}) == false)
                {
                array_push($error_message, $key.' for business '.$i.' is Invalid');
                }
                }

                 */
                } else {
                    array_push($error_message, $key . ' field does not exist for business' . $i);
                }

            }

            //surge amount can be int or double
            if (!in_array(gettype($business->surge_amount), ["double", "integer"])) {
                array_push($error_message, 'surge_amount for business ' . $i . ' is Invalid');
            }

            //LINE ITEM LEVEL VALIDATION-----

            //print_r($business);exit;
            $order_data = $business->order_item;
            //print_r($order_data);exit;

            $j = 1;

            //NOT NEEDED FOR NOW
            /* if ($service_type == 2)
            {
            //Edit below array for valid fields and types in Drugs Orders context
            $order_info_data = array(//"role"=>"integer",
            "item_code"=>"string",
            //"itemname"=>"string",
            //"discount_amount"=>"double",// not required
            //"gross_amount"=>"double",//INT OR DOUBLE
            //"net_amount"=>"double",//INT OR DOUBLE
            "roleBasedService"=>"integer"
            );
            }*/

            //else
            //{
            //Edit below array for valid fields and types
            $order_info_data = array(
                //"role"=>"integer",
                "item_code" => "string",
                //"itemname"=>"string",
                //"voucher_amount"=>"double",//INT OR DOUBLE
                //"discount_amount"=>"double",// not required
                //"gross_amount"=>"double",//INT OR DOUBLE
                //"net_amount"=>"double",//INT OR DOUBLE
                //"wallet_amount"=>"double",//INT OR DOUBLE
                //"coupon_amount"=>"double",//INT OR DOUBLE
                "invoiceto" => "string",
                "reportto" => "string",
                "corporateinvoiceemail" => "string",
                "corporatereportemail" => "string",
                "roleBasedService" => "integer",
                "cartDiscountApplied" => "boolean",
                "discountApplied" => "boolean",
                "cartCouponApplied" => "boolean",
                "orderDiscountApplied" => "boolean",
            );
            //}

            if (in_array((int) $business->service_type, [1, 10]) and
                !isset($business->is_assessment)) {
                //    $order_info_data["isInternal"] = "boolean";
            }

            //print_r($order_data);
            foreach ($order_data as $order) {
                //print_r($order);exit;

                foreach ($order_info_data as $key => $type) {

                    if (property_exists($order, $key)) {
                        if (!isset($order->{$key})) {
                            array_push($error_message, $key . ' for order item ' . $j . ' in business ' . $i . ' field is missing');
                        } else if (gettype($order->{$key}) != $type) {
                            array_push($error_message, $key . ' for order item ' . $j . ' in business ' . $i . ' field is Invalid');
                        } else if (strcmp($key, "component_no") == 0 or strcmp($key, "item_name") == 0 or strcmp($key, "item_code") == 0) {
                            if (strlen($order->{$key}) == 0) {
                                array_push($error_message, $key . " for order item " . $j . " in business " . $i . " field has empty value");
                            }
                        } else if (strcmp($key, "category") == 0 or strcmp($key, "quantity") == 0 or strcmp($key, "prescribed") == 0 or
                            strcmp($key, "item_status") == 0 or strcmp($key, "quantity") == 0) {
                            if (!ctype_digit($order->{$key})) {
                                array_push($error_message, $key . " for order item " . $j . " in business " . $i . " field should be a numeric value");
                            }
                        } else if (strcmp($key, "packsize") == 0 or strcmp($key, ",manufacturer_id") == 0 or strcmp($key, "manufacturer") == 0 or
                            strcmp($key, "type") == 0) {
                            if (strlen($order->{$key}) == 0) {
                                array_push($error_message, $key . " for order item " . $j . " in business " . $i . " field has empty value");
                            }
                        }

                        /*  if (strcmp($key,"scheduled_date") == 0)
                    {
                    //echo $this->validateDate($business->{$key}));exit;
                    if($this->validateDate($order->{$key}) == false)
                    {
                    array_push($error_message, $key.' for order item '.$j.' in business '.$i.' is Invalid');
                    }
                    } */

                    } else {
                        array_push($error_message, $key . ' field does not exist for order ' . $j . ' in business ' . $i);
                    }
                }

                ///
                //NEWLY ADDED
                if (isset($order->roleBasedService) and
                    (int) $order->roleBasedService == 1 and
                    gettype($order->isWaiver) != "boolean") {
                    array_push($error_message, 'isWaiver for order item ' . $j . ' in business ' . $i . ' field is Invalid or Missing');
                }

                if (isset($order->roleBasedService) and
                    (int) $order->roleBasedService == 0 and
                    (int) $business->service_type == 2 and
                    gettype($order->isReturnable) != "boolean") {
                    array_push($error_message, 'isReturnable for order item ' . $j . ' in business ' . $i . ' field is Invalid or Missing. Mandatory for Medicine business');
                }

                ///

                //print_r($order);
                //echo $j." ";
                //echo $order->wallet_amount."\n";exit;

                //Amounts can be int or double also add any new amounts
                $amount_array = array("lineItemDiscountAmount", "cartDiscountApportionedAmount", "orderApportionedDiscountAmount", "gross_amount", "net_amount", "voucher_amount", "wallet_amount", "coupon_amount", "MRP", "cli");

                foreach ($amount_array as $amount) {
                    if (!in_array(gettype($order->{$amount})
                        , ["double", "integer"])) {
                        array_push($error_message, $amount . ' for order item ' . $j . ' in business ' . $i . ' field is Invalid or Missing');
                    }
                }

                if (
                    in_array(gettype($order->gross_amount), ["double", "integer"])
                    and
                    in_array(gettype($order->net_amount), ["double", "integer"])
                ) {
                    //echo $j."Hi there \n";
                    //print_r($order);exit;
                    $order_gross = $order->gross_amount;
                    //$order_discount = $order->discount_amount;
                    $order_net = $order->net_amount;
                    $order_voucher = $order->voucher_amount;
                    $order_wallet = $order->wallet_amount;
                    $order_coupon = $order->coupon_amount;
                    //$order_markup = $order->markup_amount;
                    $order_cli = $order->cli; //_amount;
                    $order_base = $order->total_baseprice;
					
					//Corporate Item
					if($order->invoiceto == "2")
					{
						$order_corporate_amount = $order->net_amount - 
														($order->wallet_amount +  $order->voucher_amount);
					}

                    $total_business_gross_amount += $order_gross;
                    //$total_business_discount_amount += $order_discount;
                    $total_business_net_amount += $order_net;
                    $total_business_voucher_amount += $order_voucher;
                    $total_business_wallet_amount += $order_wallet;
                    $total_business_coupon_amount += $order_coupon;
                    //$total_business_markup_amount += $order_markup;
                    $total_business_cli_amount += $order_cli;
                    $total_business_base_amount += $order_base;
					$total_business_corporate_amount += $order_corporate_amount;

                    if ($order_gross < $order_net) {
                        array_push($error_message, 'Order item ' . $j . ' in business ' . $i . ' amount validation failed');
                    }

                    //CALCULATE DISCOUNT AMOUNT
                    $payload['orders'][($i - 1)]->order_item[($j - 1)]->discount_amount =
                        $order_gross - $order_net;
                }
                $j++;
            }
            //$business[$i]['gross_amount'] = $total_business_gross_amount;
            //$business[$i]['discount_amount'] = $total_business_discount_amount;
            //$business[$i]['net_amount'] = $total_business_net_amount;

            //ADDING AMOUNTS IN BUSINESS LEVEL
            $payload['orders'][($i - 1)]->gross_amount =
                $total_business_gross_amount;
            //$payload['orders'][($i-1)]->discount_amount =
            //                      $total_business_discount_amount;
            $payload['orders'][($i - 1)]->net_amount =
                $total_business_net_amount;
            $payload['orders'][($i - 1)]->voucher_amount =
                $total_business_voucher_amount;
            $payload['orders'][($i - 1)]->wallet_amount =
                $total_business_wallet_amount;
            $payload['orders'][($i - 1)]->coupon_amount =
                $total_business_coupon_amount;
            //$payload['orders'][($i-1)]->markup_amount =
            //                        $total_business_markup_amount;

            $payload['orders'][($i - 1)]->cli =
                $total_business_cli_amount;
            $payload['orders'][($i - 1)]->base_amount =
                $total_business_base_amount;
			$payload['orders'][($i-1)]->corporate_amount = 
				$total_business_corporate_amount;
			

            if ($business->payment_code != 0 or $business->payment_code != '0') {
                $transaction_payable_amount += $total_business_net_amount -
                    ($total_business_wallet_amount
                    //+$total_business_coupon_amount
                     + $total_business_voucher_amount);

            }

            $transaction_gross_amount += $total_business_gross_amount;
            //$transaction_discount_amount += $total_business_discount_amount;
            $transaction_net_amount += $total_business_net_amount;
            $transaction_voucher_amount += $total_business_voucher_amount;
            $transaction_wallet_amount += $total_business_wallet_amount;
            $transaction_coupon_amount += $total_business_coupon_amount;
            //$transaction_markup_amount += $total_business_markup_amount;
            $transaction_cli_amount += $total_business_cli_amount;
            $transaction_base_amount += $total_business_base_amount;
            $transaction_surge_amount += $business->surge_amount;

            $i++;
        }

        //echo $transaction_gross_amount;exit;

        //IF pending_payments IS MENTIONED AND NOT EMPTY
        if (!empty($payload["pending_payments"]) and $payload["pending_payments"] != null) {
            $pending_payments = $payload["pending_payments"];
            $penaltyPayment = 0.0;
            $pendingPayment = 0.0;

            $penalties = $pending_payments->penalties;
            foreach ($penalties as $eachpenalty) {
                $penaltyPayment += $eachpenalty->amount;
            }

            $pendingPayments = $pending_payments->pendingPayments;
            foreach ($pendingPayments as $eachpending) {
                $pendingPayment += $eachpending->payable_amount;
            }
        }

        //Payment data Validation
        $payment_data = $payload['payment_info'];
        //print_r($payment_data);

        //Edit below array for valid fields and types
        $payment_info_data = array( //"payment_code"=> "string",
            "payment_mode" => "integer",
            //"payment_amount" => "double", //INT OR DOUBLE
            "payment_service" => "string",
            "payment_reference_id" => "string",
            //"wallet_amount" => "double", //INT OR DOUBLE
            "coupon" => "string",
            //"coupon_amount" => "double", //INT OR DOUBLE
            "voucher_assoc_code" => "string",
            //"voucher_assoc_name" => "string",
            "voucher_code" => "string",
            //"voucher_amount" => "double" //INT OR DOUBLE
        );
        //print_r($order_data);
        foreach ($payment_info_data as $key => $type) {
            if (property_exists($payment_data, $key)) {
                if (!isset($payment_data->{$key})) {
                    array_push($error_message, $key . ' for payment_info field is missing');
                } else if (gettype($payment_data->{$key}) != $type) {
                    array_push($error_message, $key . ' for payment_info field is Invalid');
                }

                if (strcmp($key, "scheduled_date") == 0) {
                    //echo $this->validateDate($business->{$key}));exit;
                    if ($this->validateDate($payment_data->{$key}) == false) {
                        array_push($error_message, $key . ' for payment_info field is Invalid');
                    }
                }
            } else {
                array_push($error_message, $key . ' field does not exist for payment_info');
            }
        }

        //PAYMENT AMOUNT CAN BE INT OR DOUBLE
        $payment_info_amounts = array("payment_amount", "wallet_amount",
            "coupon_amount", "voucher_amount");

        foreach ($payment_info_amounts as $amount) {
            if (!in_array(gettype($payment_data->{$amount}), ["double", "integer"])) {
                array_push($error_message, $amount . ' for payment_info field is Invalid need integer or double value');
            }
        }
        //$payment_data->coupon_amount = $transaction_coupon_amount;
        //$payment_data->voucher_amount = $transaction_voucher_amount;
        //$payment_data->wallet_amount = $transaction_wallet_amount;

        if ($transaction_payable_amount + $penaltyPayment + $pendingPayment != 0) //payment_data->payment_code
        {
            $expected_payment_amount = $transaction_payable_amount +
                $penaltyPayment + $pendingPayment;

            //Previous
            //$expected_payment_amount = $transaction_net_amount-(
            //$transaction_voucher_amount+$transaction_wallet_amount
            //                           +$transaction_coupon_amount);

            $payment_amount = $payment_data->payment_amount;

            //echo $expected_payment_amount." ".$payment_amount;exit;
            //$payload['payment_info']->payment_service = "";
            //$payload['payment_info']->payment_reference = "";

            if (round($expected_payment_amount) != round($payment_amount)) {
                array_push($error_message, "Payment amount validation failed. It should be " . $expected_payment_amount);
            }
        }

        $payment_wallet_amount = $payment_data->wallet_amount;
        $payment_voucher_amount = $payment_data->voucher_amount;
        $payment_coupon_amount = $payment_data->coupon_amount;

        //Added validation for wallet_amount and voucher_amount
        if (round($transaction_wallet_amount) != round($payment_wallet_amount)) {
            array_push($error_message, "Wallet amount validation failed in paymentinfo. It should be " . $transaction_wallet_amount);
        }

        if (round($transaction_voucher_amount) != round($payment_voucher_amount)) {
            array_push($error_message, "Voucher amount validation failed in paymentinfo. It should be " . $transaction_voucher_amount);
        }
        //echo $payment_coupon_amount;exit;
        if (round($transaction_coupon_amount) != round($payment_coupon_amount)) {
            array_push($error_message, "Coupon amount validation failed in paymentinfo. It should be " . $transaction_coupon_amount);
        }

        if (strlen($payment_data->payment_service) == 0) {
            array_push($error_message, 'Payment service field is empty');
        } else if (strlen($payment_data->payment_reference_id) == 0
            and !in_array((int) $payment_data->payment_mode, [0, 100])) {
            array_push($error_message, 'Payment reference id field is empty');
        }

        //echo json_encode($payment_data);
        //print_r($payload);
        return $this->log_message($error_message, 'error');

        //Function ends
    }

    public function getFacilityName($facilityid)
    {

        $dbo = new Dbo;
        $filter = array("popinfo.FACILITY_ID" => (string) $facilityid, "popinfo.ACTIVE_INACTIVE_E" => "1");
        $project = array();
        $sort = array();
        $result = $dbo->find("masters", "poplist", $filter, $project, $sort);

        if ($result == "") {
            $facility = "";
        } else {
            $facility = array("name" => ($result[0]['popinfo']['FACILITY_NAME']), "did" => $result[0]['popinfo']['FACILITY_DID']);

        }
        return $facility;

    }

    public function getNextSequence($name)
    {
        $dbo = new Dbo;
        $filter = array('_id' => $name);
        $update = array('$inc' => array("sequence" => 1));

        $result = $dbo->findAndModify("masters", "counters", $filter, $update);

        return $result['sequence'];
    }
    public function logger()
    {

        // the default date format is "Y-m-d H:i:s"
        $dateFormat = "Y n j, g:i a";
        // the default output format is "[%datetime%] %channel%.%level_name%: %message% %context% %extra%\n"
        $output = "%datetime% > %level_name% > %message% %context% %extra%\n";
        // finally, create a formatter
        $securityLogger = new Monolog\Logger('security');
        $formatter = new Monolog\Formatter\LineFormatter($output, $dateFormat);
        // Create a handler
        $stream = new Monolog\Handler\StreamHandler('my_app.log', Monolog\Logger::DEBUG);
        $stream->setFormatter($formatter);
        // bind it to a logger object
        $securityLogger->pushHandler($stream);
        $securityLogger->addWarning('Foo', array('username' => 'Seldaek'));

    }
    public function jsonLogger()
    {

        $log = new \Monolog\Logger('my_log');
        $stream_handler = new \Monolog\Handler\StreamHandler('my_log_file.log');
        $stream_handler->setFormatter(new \Monolog\Formatter\JsonFormatter());
        print_r($stream_handler);exit;
        $log->pushHandler($stream_handler);

        $log->addError('foo');

        /* $user_info = ['ip' => '192.168.1.0', 'OS' => 'Window'];

    $file ='info-'.date('Y-m-d') . '.log';
    $dateFormat = "Y n j, g:i a";
    // finally, create a formatter
    $formatter = new Monolog\Formatter\JsonFormatter($dateFormat);

    // Create a handler

    $stream = new Monolog\Handler\StreamHandler($file, Monolog\Logger::INFO);

    $stream->setFormatter($formatter);

    // bind it to a logger object
    $securityLogger = new Monolog\Logger('View Info');
    $securityLogger->pushHandler($stream);
    $securityLogger->addInfo('info', $user_info);
    var_dump($securityLogger);  */
    }
    public function curl_call_urlencode_notimeout($url, $data)
    {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/x-www-form-urlencoded"));
        $result = curl_exec($ch);
        curl_close($ch);
        $resultcurl = json_decode($result);

        if (curl_errno($ch)) {
            curl_setopt($ch, CURLOPT_VERBOSE, true);
            curl_setopt($ch, CURLOPT_STDERR, $fp);
            throw new Exception(curl_error($ch));
        }
        curl_close($ch);
        return $resultcurl;
    }

    public function curl_call_urlencode_notimeout_vivek($url, $data, $header = "", $method = "")
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        if ($method = "post" && $data != "") {curl_setopt($ch, CURLOPT_POST, true);}
        //curl_setopt($ch, CURLOPT_CONNECTTIMEOUT ,curltimeout);
        //curl_setopt($ch, CURLOPT_TIMEOUT, curltimeout);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        $result = curl_exec($ch);
        /*if(curl_errno($ch)){
        $fname="orm-error-log";
        curl_setopt($ch, CURLOPT_VERBOSE, true);
        $fp = fopen("/var/www/html/ORMErrorLog/$fname.txt", 'a+');
        fwrite($fp, "\n");
        curl_setopt($ch, CURLOPT_STDERR, $fp);
        $logdata=json_encode(array("createddate"=>date("Y-m-d H:i:s"),"error"=>curl_error($ch)."#".$url));
        fwrite($fp, $logdata);
        fwrite($fp, ",");
        fclose($fp);
        throw new Exception(curl_error($ch));
        }*/
        curl_close($ch);
        return $result;

    }

    public function emailLogger()
    {
        //echo FROMMAIL;
        $to = "pallav.ghose@callhealth.com";
        $from = "response@callhealth.co.in";
        $subject = "error";
        $mailHandler = new Monolog\Handler\NativeMailerHandler($to, $subject, $from, Monolog\Logger::ERROR, true, 70);

        $logHandler = new Monolog\Handler\StreamHandler('synchro.log', Monolog\Logger::DEBUG);
        $logger = new Monolog\Logger('mail Info');
        $logger->pushHandler($logHandler);
        $logger->pushHandler($mailHandler);
        $logger->addWarning('Foo', array('username' => 'Seldaek'));
        print_r($mailHandler);
    }

    public function getBusinessPrefix($businessId, $addition_attribute = null)
    {
        if ($businessId == 1 || $businessId == 10) {$prefix = 'EC';}
        if ($businessId == 2) {$prefix = 'DR';}
        if ($businessId == 3) {$prefix = 'DG';}
        if ($businessId == 4) {$prefix = 'IM';}
        if ($businessId == 5) {$prefix = 'CH';}
        if ($businessId == 6) {$prefix = 'NC';}
        if ($businessId == 7) {$prefix = 'PY';}
        if ($businessId == 8) {$prefix = 'TA';}
        if ($businessId == 11) {$prefix = 'EQ';}
        if ($businessId == 13) {$prefix = 'EW';}
        if ($businessId == 14) {$prefix = 'EW';}
        if ($businessId == 30) {$prefix = 'AS';}
		
		//RETURN ORDER
		if($addition_attribute == 4)
		{
			$prefix = 'RT-'.$prefix;
		}
		
        return $prefix;
    }

    public function getprefix($subBusinessId, $type, $businessId, $addition_attribute)
    {
        //echo $businessId; exit;
        if ($type == 1) {$mode = "AH";} else if ($type == 2) {$mode = "AC";} else if ($type == 3) {$mode = "AP";}

        if ($businessId == 1) {
            $prefix = $mode;
            if ($addition_attribute == 2) {
                $prefix = "AS"; //Assessment Order
            }
        } else if ($businessId == 3) {$prefix = $mode;} else if ($businessId == 4) {$prefix = $mode;} else if ($businessId == 11) {$prefix = "AH";} //Equipment Rentals/Sale //added else to if

        //for drug
        else if ($businessId == 2) {
            $prefix = $mode;
            /* if ($subBusinessId == 9) {$prefix = "DI";}
        if ($subBusinessId == 10) {$prefix = "EC";} */
        }
        //end for drug
        //imaging

        //Care at home
        else if ($businessId == 6 || $businessId == 7 || $businessId == 8) {

            if ($businessId == 6 || $businessId == 8) {
                if ($subBusinessId == 101) {
                    $prefix = 'BC';
                } else if ($subBusinessId == 102) {
                    $prefix = 'BNC';
                } else if ($subBusinessId == 103) {
                    $prefix = 'AC';
                } else if ($subBusinessId == 104) {
                    $prefix = 'SC';
                } else if ($subBusinessId == 105) {
                    $prefix = 'BTC';
                } else if ($subBusinessId == 106) {
                    $prefix = 'OT';
                } else if ($subBusinessId == 107) {
                    $prefix = 'ST';
                } else if ($subBusinessId == 108) {
                    $prefix = 'SA';
                } else {
                    $prefix = 'BNC';
                }
            }
            if ($businessId == 7) {
                $prefix = $mode;
            }

            if ($addition_attribute == 1) {
                $prefix = $prefix . "-C";
            }

            if ($addition_attribute == 2) {
                //$prefix = $prefix . "-AS";
                $prefix = "AS";
            }

            if ($addition_attribute == 3) {
                $prefix = $prefix . "-T";
            }

        }
        //Care at home prefix ends
        else {
            $prefix = $mode;
        }
        //print_r($addition_attribute);exit;
        return $prefix;
    }

    public function getCurrenttime()
    {date_default_timezone_set('Asia/Kolkata');
        $dbo = new Dbo;
        $date = $dbo->date(strtotime(date("Y-m-d") . "T" . date("H:i:s") . ".000Z"));
        //$date = new MongoDate(strtotime(date("Y-m-d") . "T" . date("H:i:s") . ".000Z"));
        return $date;
    }

    public function getCurrentDate()
    {
        $date = date("Y-m-d");
        return $date;
    }

    public function getCurrentdatetimesimple()
    {
        $date = date("Y-m-d") . "T" . date("H:i:s") . ".000Z";
        return $date;
    }
    public function getCurrentdatetime()
    {
        $date = date("Y-m-d H:i:s");
        return $date;
    }
    public function getbusinessName($businessId)
    {
        $businessName = "";
        if ($businessId == 1) {$businessName = "Doctor Consultation";} else if ($businessId == 2) {$businessName = "Medicines";} else if ($businessId == 3) {$businessName = "Diagnostics";} else if ($businessId == 4) {$businessName = "Radiology";} else if ($businessId == 5) {$businessName = "Care";} else if ($businessId == 6) {$businessName = "Nursing";} else if ($businessId == 7) {$businessName = "Physiotherapy";} else if ($businessId == 8) {$businessName = "Trained Attendants";} else if ($businessId == 11) {$businessName = "Equipment Rentals";} else if ($businessId == 14) {$businessName = "MyWellness";}  else { $businessName = "";}
        return $businessName;
    }

    public function getbusinessDef($businessId, $mode_of_service)
    {
        $businessName = "";
        if ($businessId == 1) {$businessName = "Doctor Consultation";} else if ($businessId == 2) {$businessName = "Medicines";} else if ($businessId == 3) {$businessName = "Diagnostics";} else if ($businessId == 4) {$businessName = "Radiology";} else if ($businessId == 5) {$businessName = "Care";} else if ($businessId == 6) {$businessName = "Nursing";} else if ($businessId == 7) {$businessName = "Physiotherapy";} else if ($businessId == 8) {$businessName = "Trained Attendants";} else if ($businessId == 11) {$businessName = "Equipment Rentals";} else if ($businessId == 14) {$businessName = "MyWellness";} else if ($businessId == 30) {$businessName = "Assessment Order";} else { $businessName = "";}
        $MosName = "";
        if ($mode_of_service == 3) {
            $MosName = "@Online";
        } else if ($mode_of_service == 2) {
            $MosName = "@Center";
        } else {
            $MosName = "@Home";
        }

        return $businessName . $MosName;
    }

    public function getsubbusinessName($subbusinessId)
    {
        if ($subbusinessId == 1) {$subbusinessName = "eConsultation";} else if ($subbusinessId == 2) {$subbusinessName = "Drugs@Home";} else if ($subbusinessId == 3) {$subbusinessName = "Diagnostic@home";} else if ($subbusinessId == 4) {$subbusinessName = "Facilitation";} else if ($subbusinessId == 5) {$subbusinessName = "Care@Home";} else if ($subbusinessId == 6) {$subbusinessName = "General";} else if ($subbusinessId == 7) {$subbusinessName = "Speciality";} else if ($subbusinessId == 8) {$subbusinessName = "Trained Attendants";} else if ($subbusinessId == 9) {$subbusinessName = "Direct";} else if ($subbusinessId == 10) {$subbusinessName = "Via Consultation ";} else if ($subbusinessId == 11) {$subbusinessName = "Refill";} else if ($subbusinessId == 12) {$subbusinessName = "Return";} else if ($subbusinessId == 13) {$subbusinessName = "Direct Lab";} else if ($subbusinessId == 14) {$subbusinessName = "Via Consultation Lab";} else if ($subbusinessId == 15) {$subbusinessName = "Doctor Visit";} else if ($subbusinessId == 16) {$subbusinessName = "Diagnostic";} else if ($subbusinessId == 17) {$subbusinessName = "Hospital Visit";} else if ($subbusinessId == 18) {$subbusinessName = "Single";} else if ($subbusinessId == 19) {$subbusinessName = "Long Term";} else if ($subbusinessId == 20) {$subbusinessName = "Episodic Care";} else if ($subbusinessId == 21) {$subbusinessName = "Pre-Checkin";} else if ($subbusinessId == 22) {$subbusinessName = "Completion";} else if ($subbusinessId == 23) {$subbusinessName = "Transport Arrangement";} else if ($subbusinessId == 24) {$subbusinessName = "Transport Execution";} else if ($subbusinessId == 25) {$subbusinessName = "Miscellaneous";} else if ($subbusinessId == 26) {$subbusinessName = "Miscellaneous Services";} else if ($subbusinessId == 27) {$subbusinessName = "Direct Radiology";} else if ($subbusinessId == 28) {$subbusinessName = "HomeCare/FamilyCare Services";} else if ($subbusinessId == 29) {$subbusinessName = "Package Subscription";} else if ($subbusinessId == 30) {$subbusinessName = "Assessment Order";} else if ($subbusinessId == 31) {$subbusinessName = "Review Consultation";} else if ($subbusinessId == 100) {$subbusinessName = "Nursing Care";} else if ($subbusinessId == 101) {$subbusinessName = "Basic Care";} else if ($subbusinessId == 102) {$subbusinessName = "Basic Nursing Care";} else if ($subbusinessId == 103) {$subbusinessName = "Advanced Care";} else if ($subbusinessId == 104) {$subbusinessName = "Specialized Care";} else if ($subbusinessId == 105) {$subbusinessName = "Intensive Care";} else if ($subbusinessId == 200) {$subbusinessName = "Physiotherapy";} else if ($subbusinessId == 201) {$subbusinessName = "Physiotherapy Care";} else if ($subbusinessId == 300) {$subbusinessName = "Family Care";} else if ($subbusinessId == 301) {$subbusinessName = "Family Care Consultation";} else { $subbusinessName = "";}
        return $subbusinessName;
    }

    public function common_curl($url, $postdata, $setmethod, $header)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_POST, $setmethod);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        $resultpckg = curl_exec($ch);
        curl_close($ch);
        return $resultpckg;
    }

    public function my_curl($url, $method = "GET", $fields, $contentType = null, $headers = array(), $timeout = 30)
    {
        try {
            if (!empty($fields) && $contentType != 'json') {
                //$fields = $this->my_urlencode($fields);
            }

            // if json input
            switch ($contentType) {
                case 'json':$header = array("Content-Type:application/json");
                    break;
                case 'form-data':$header = array("Content-Type:text/plain");
                    break;
                case 'x-www-form':$header = array("Content-Type: application/x-www-form-urlencoded");
                    break;
                case 'form-data-multipart':$header = array("Content-Type:multipart/form-data");
                    break;
            }
            
            if(count($headers) > 0){
            $header = array_merge($header,$headers);
            }

            //print_r($header);exit;

            if ($method == 'GET' || $method == 'get') {
                if (!empty($fields)) {
                    $fields_string = http_build_query($fields);
                    $url = $url . $fields_string;
                    //print_r($method);exit;
                }
            }

            //open connection
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //Return data instead printing directly in Browser

            if ($method == 'POST' || $method == 'post') {
                //url-ify the data for the POST
                //$fields_string = http_build_query($fields);
                //print_r($fields);exit;
                curl_setopt($ch, CURLOPT_POST, count($fields));
                curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
            }
            // add header fields
            if (!empty($header)) {
                //print_r($header); 
                curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            }

            //UNCOMMENTED, PREVIOUSLY COMMENTED
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); //Timeout after 30 seconds
            curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);

            //execute curl
            $result = curl_exec($ch);

            if (!empty($result)) {
                $resultcurl = json_decode($result, true);
            } else {
                curl_close($ch);
                //print curl_error($ch);
                //echo "\n";
                //echo "Empty Result";
                return $result;
            }

            if (curl_errno($ch)) {
                curl_setopt($ch, CURLOPT_VERBOSE, true);
                curl_setopt($ch, CURLOPT_STDERR, $fp);
                throw new Exception(curl_error($ch));
            }
            curl_close($ch);
            //print_r($resultcurl);exit;

        } catch (Exception $e) {
            //echo "1";
            print_r($e->getmessage());
        }
        return $resultcurl;
    }

    //change the gender character to number
    public function genderStringtoNumber($valu)
    {
        $valu = strtolower(trim($valu));
        $setgender = "";
        if ($valu == "female" || $valu == "f") {$setgender = "1";} else if ($valu == "male" || $valu == "m") {$setgender = "2";} else if ($valu == "other" || $valu == "o") {$setgender = "3";} else { $setgender = $valu;}
        return $setgender;
    }

    // Usage:=> Method: must be POST, $param:Must be JSON encoded
    public function async_curl($url, $param)
    {
        $param = str_replace('\'', "", $param);
        $param = str_replace('\"', "", $param);
        //echo "-----------".$param;
        // post method for json data
        $check_ssl = false;
        $cmd = "curl --header 'Content-Type: application/json; charset=utf-8'  --max-time 9000 --request POST --data '" . $param . "' '" . $url . "'";

        //echo $cmd;
        if (!$check_ssl) {
            $cmd .= " --insecure"; // this can speed things up, though it's not secure
        }
        $cmd .= " > /dev/null 2>&1 &"; //just dismiss the response
        exec($cmd, $output, $exit);
        return $exit == 0;
    }

    // Usage:=> Method: must be GET, $param:Must be JSON encoded
    public function async_get_curl($url, $param)
    {
        // GET method
        $check_ssl = false;
        if (!empty($param)) {
            $param = json_decode($param, true);
            $url = $url . "?" . http_build_query($param, '', "&");
        }
        $cmd = "curl --request GET '" . $url . "'";
        if (!$check_ssl) {
            $cmd .= " --insecure"; // this can speed things up, though it's not secure
        }
        $cmd .= " > /dev/null 2>&1 &"; //just dismiss the response
        exec($cmd, $output, $exit);
        return $exit == 0;
    }
    //Class Ends

    //getStatusName
    public function getStatusName($businessid, $mosid, $component_no, $statusno)
    {
        $filter = array(
            "Bid" => (string) $businessid,
            "MOSid" => (float) $mosid,
            "Workflow" => (string) $component_no,
            "status" => (float) $statusno,
        );
        $project = array("Nomenclature" => 1);

        $dbo = new Dbo;
        $result = $dbo->findOne("masters", "workflow_status", $filter, $project);
        if (count($result) > 0 && isset($result[Nomenclature])) {
            return $result[Nomenclature];
        } else {
            return "";
        }
    }

    public function blob_upload_block($container, $filepath, $content)
    {
        require_once 'libraries/AzureUploder.php';
        $azure_uploder = new AzureUploder();
        return $azure_uploder->create_blob($container, $filepath, $content);
    }

    public function blob_delete_block($container, $filepath)
    {
        require_once 'libraries/AzureUploder.php';
        $azure_uploder = new AzureUploder();
        return $azure_uploder->delete_blob($container, $filepath);
    }

    public function blob_create_container($container)
    {
        require_once 'libraries/AzureUploder.php';
        $azure_uploder = new AzureUploder();
        return $azure_uploder->create_container($container);
    }

}
