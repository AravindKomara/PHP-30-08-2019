<?php
// specify environment
defined('ENV_MODE') or define('ENV_MODE', 'DEV'); // DEV || UAT || PRE_PROD || PROD

// specify logger fesibility
defined('ENABLE_DEBUG') or define('ENABLE_DEBUG', 1); // 1 || 0
defined('ENABLE_ACCESS_LOG') or define('ENABLE_ACCESS_LOG', 1); // 1 || 0
defined('TRACE_ID') or define('TRACE_ID', mt_rand(10000000,99999999));
defined('START_TM') or define('START_TM', microtime(true));

// specify mongodb serverpath
defined('DB_PATH') or define('DB_PATH', 'mongodb://172.26.7.111:27017'); 
//defined('DB_PATH') OR define('DB_PATH', 'mongodb://172.26.7.176:27017');
defined('DB_USERNAME') OR define('DB_USERNAME', '');
defined('DB_PASSWORD') OR define('DB_PASSWORD', '');

 
// specify server base URL 
defined('SERVER_PATH') or define('SERVER_PATH', 'http://172.26.7.111');
//defined('SERVER_PATH') OR define('SERVER_PATH', 'http://172.26.7.176');

// specify logger URL
defined('LOGGER_PATH') or define('LOGGER_PATH', 'http://172.26.7.111/logger/');
defined('OMS_API_KEY') or define('OMS_API_KEY', 'AFTD-GDTGG-KLDG-GT546-GKJBIBF');

// specify INTDB Server Connection
defined('INTDB_DSN') or define('INTDB_DSN', 'INTDB');
defined('INTDB_USERNAME') or define('INTDB_USERNAME', 'ordmgnt');
defined('INTDB_PASSWORD') or define('INTDB_PASSWORD', 'CallHealth@1234');

defined('REDIS_SOCKET_TYPE') or define('REDIS_SOCKET_TYPE', 'tls'); //// unix || tcp || tls
defined('REDIS_HOST') or define('REDIS_HOST', 'ccuatredis.redis.cache.windows.net');
defined('REDIS_PORT') or define('REDIS_PORT', 6380);
defined('REDIS_PWD') or define('REDIS_PWD', "3QsJWpSseDIiBeFhwcjIk6dLKdgjdbdezFJhbq+WNXU=");

// payment gateway ezeetab
defined('EZEETAB_MODE') or define('EZEETAB_MODE', 'sandbox'); // sandbox || live
defined('EZEETAB_APPKEY') or define('EZEETAB_APPKEY', '3c394538-df2d-4ed0-b119-5718385c6c5f'); 
defined('EZEETAB_URL') or define('EZEETAB_URL', 'https://demo.ezetap.com/api/2.0/pay/remote/initiate');

define('AZURE_ACCOUNT_NAME', 'ormuatblobonperm');
define('AZURE_ACCOUNT_KEY', 'jHQ6GfstIuRLVzPF7wnXSEOZ3anqQWdYAiOrIVNjQsekrEMu6xpIDCUrAZdeV0ychGuc96XLAzCjKOkVBkiJFg==');
define('AZURE_BASE_PATH', 'https://'.AZURE_ACCOUNT_NAME.'.blob.core.windows.net/');
//https://ormuatblobonperm.blob.core.windows.net/container/pathOfTheFile


defined('GLOBALVARS') or define('GLOBALVARS', 
   json_encode( array(
        "rtct_path" => "http://cpdev.callhealth.com:3000/",
        "cpservicepath" => "http://gcmuatv3.callhealth.com:8080/",
        "mdmpath" => "http://gcmuatv3.callhealth.com:8080/mdm_v3/services/",
        "smsemaileventpath" => "http://cpuat.callhealth.com:8094/domain/Publish",
        "cpserviceCorppath" => "http://cpuat.callhealth.com:8081/",
        "SEClink" => "https://qaaccount.callhealth.com/",
        "serverurl" => "http://172.26.7.111/",
        //send sms
        "SendSms" => "https://uatsms.callhealth.com/domain/SendSms",
		//send email
		"SendEmail"=>"https://uatemail.callhealth.com/domain/SendEmail",
        "chissurl" => "https://chissapouatv3.callhealth.com/",
        "rootpath" => "/var/www/html/",
        "logpath" => "/var/www/html/OMS/logs/", 
        "associateurl" => "https://aiuat.callhealth.com/consumables/webservices/api/getDefaultDOVendor",
        "smsemail" => "http://cpuat.callhealth.com:8091/domain/",
        "INTDB" => "QACHINTDB",
        "LOGISTIC_VENDOR" => "LG00000000000022",
        "CPchoice_url" => "https://choicev3.callhealth.com/rest/",
        //"logpath" => "/logs/oms",
        "ihspath" => 'http://cpuat.callhealth.com:8081/corporate/',
        "ihspathhdfc" => 'https://ihsuat.callhealth.com/corporate/',
		"ihsmediassist" => 'https://ihsmediassistuatv3.callhealth.com/corporate/',
		"hdfc_corporate_id" => '674',
        "chisskey" => '51ABGH-E14F-4422-95211-12241ERT',
        "chissapikey" => "91ADEF-F14F-4422-95211-1224THE",
        "chisspath" => 'https://chissapouatv3.callhealth.com/',
        "choiceurl" => 'https://choice.callhealth.com/',
        "associtepath" => 'https://elk-e-uat.callhealth.com/',
        "doctorurl" => 'https://doctoruatv3.callhealth.com',
        //"domainurl" => 'https://omsuat.callhealth.com/',
        "domainurl" => 'http://172.26.7.111/',
        "version" => "3.0",
    ))
);

const IMAGE_EXTNS= array('jpg','jpeg','png','bmp','gif','pdf');

const CHANNEL= array(
	1 => "CP",
	2 => "CCO",
	3 => "Android App",
	4 => "Corporate Portal",
	5 => "IOS App",
	6 => "L2 Pharma",
	7 => "Officer App"
);

const ModeOfService= array(
	1 => "At Home",
	2 => "At Center",
	3 => "At Platform"
);

const PAYMENTMODE_ENUM = array(
	0 => "Cash",
	1 => "payU",
	2 => "ICICI",
	3 => "Mobikwik",
	4 => "ccavenue",
	5 => "ITZCASH",
	6 => "paytm",
	7 => "AIRTEL",
	8 => "PaytmQR",
	9 => "Voucher",
	100 => "Ezetab",
);


// added by prasanna for Delhivery Express
define('DELHIVERYTESTURL','https://staging-express.delhivery.com/');
define('AUTHORIZATION','0e68f30afbbd96b12cc2f7b4880eb2e5ae6a8727');
define('CLIENTNAME','CALLHEALTH SURFACE');