<?php
require_once "../constant.php";

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$ciphertext = $_POST['token'];
$order_id = urldecode(base64_decode(strrev(base64_decode($ciphertext))));
$rating = $_POST['experience'];
$name = $_POST['name'];
$email = $_POST['email'];
$feedback = $_POST['comments'];

// send to oms using crul request
$postData = [
    "order_id" => $order_id,
    "rating" => $rating,
    "name" => $name,
    "email" => $email,
    "feedback" => $feedback,
];
$param = json_encode($postData);
$url = SERVER_PATH. '/OMS/api/operation.php/v1/orders/notification/feedback/capture';
$cmd = "curl --header 'Content-Type: application/json' --request POST --data '" . $param . "' '" . $url . "'";
$cmd .= " --insecure"; // this can speed things up, though it's not secure
//$cmd .= " > /dev/null 2>&1 &"; //just dismiss the response
//echo $cmd;
exec($cmd, $output, $exit);
//var_dump($output);
$output = json_decode($output[0], true);
if($output['success'] == 1){
    echo json_encode(["result" => "success"]);
}






/*
var_dump($_POST);
rray (size=5)
'token' => string 'd2t6TnlNVE4=' (length=12)
'experience' => string '4' (length=1)
'comments' => string 'dfgd' (length=4)
'name' => string 'df' (length=2)
'email' => string 'cfgh@fg.gh' (length=10)
/
/*
Tested working with PHP5.4 and above (including PHP 7 )

 */

/*
require_once './vendor/autoload.php';
use FormGuide\Handlx\FormHandler;
$pp = new FormHandler();
$validator = $pp->getValidator();
$validator->fields(['name','email'])->areRequired()->maxLength(50);
$validator->field('email')->isEmail();
$validator->field('comments')->maxLength(6000);
$pp->sendEmailTo('someone@gmail.com'); // ← Your email here
echo $pp->process($_POST);
 */
