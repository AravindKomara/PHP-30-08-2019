<?php

class Care extends Oms
{
	public function __construct() 
    {
        parent::__construct();
	} 
	
    public function create_careplan($payload, $ticket)
    {
        //print_r($payload);exit;
        $filter = array("assessment_order_id"=> (string)$payload->assessment_order_id);
        
        $payload->assessment_order_id = (string)$payload->assessment_order_id;
        $result = $this->dbo->find("masters","treatmentplan",$filter,array(),array());
        //print_r($result);exit;

        //payload for saving care plan for gcm
        $gcm_payload = array
        (
            "service"=> "officer/saveCarePlanTemplate",
            "requestType"=> "post",
            "parentOrderId"=> $payload->assessment_order_id,
            "childOrderId"=> $payload->assessment_order_id,
            "serviceId"=> "",
            "mrn"=>isset($payload->mrn) ? $payload->mrn : "",
            "serviceId"=> $payload->assessment_order_id,
            "careplanId"=> $result[0]['_id']->{'$id'},
            "careplan" =>json_encode((object)$payload),
            "patientId"=>"", 
            "addedBy"=> "",
            "addedByName"=> "",
            "role"=> "officer", 
            "executionType"=> "2"
        );

        //echo json_encode($gcm_payload);exit;

        $suburl = 'services/officer/saveCarePlanTemplate';
        $url = $this->config->getConfig("doctorurl",$suburl);

        //FOR ASYNC CALL GCM
        $this->utility->async_curl($url, $gcm_payload);
       
        //echo json_encode($result);exit;

        //if($result['nModified']!=1)
        if($result==null) 
        {
            $payload->is_master = 1;
            $payload->{"date"} = $this->dbo->date(strtotime($payload->{"date"})); 
            //new MongoDate(strtotime($payload->{"date"}));
            $payload->created_date = $this->utility->getCurrenttime();
            $insert_data = $this->dbo->insert("masters", "treatmentplan", $payload);
            return array("status" => "1", "treatmentplanid" => $insert_data[id], "message" => "careplan created successfully");
        }  
        else
        {   
            $update = $payload;

            $update->last_updated_on=date('Y-m-d H:i:s');
            $updt=$this->dbo->update("masters","treatmentplan",$filter,$update,array(),array());
            return array("status" => "1", "treatmentplanid" => $result[0]['_id']->{'$id'}, "message" => "careplan modified");
        }  
    } 
	
	
	
	public function get_careplan_master($payload, $ticket)
    {
        //print_r($payload);exit;
        $filter = array("assessment_order_id"=> (string)$payload->assessment_order_id,"is_master"=>1);
        
        $payload->assessment_order_id = (string)$payload->assessment_order_id;
        $result = $this->dbo->find("masters","treatmentplan",$filter,array(),array());
       
        if($result==null) 
        {
            
            return array("status" => "1",  "message" => "master careplan doesnot exist");
        }  
        else
        {   
            
            
            return array("status" => "1", "treatmentplan" => $result, "message" => "careplan found");
        }  
    }
	
	
	
	
	
    public function createAssessmentOrder($subBusinessId, $associate, $patientinfo_obj, $orderstatus_obj, $payload,$business_obj)
    {
     //   print_r($payload);exit;
	    $associate = $payload['associate'];
        $associate['component_no'] = "2";
        $associate_info = array();
        array_push($associate_info, $associate);
        $items = $payload['orderitem'];
        $order = array("patientinfo" => $patientinfo_obj, "order_status" => $orderstatus_obj, "orderitem" => $items, "provider_info" => $associate_info,"business" => $business_obj);
        return ($order);
    }
    public function order($subBusinessId, $patientinfo_obj, $orderstatus_obj, $payload, $business_obj, $transaction_code)
    {
        //logic for all care at home
        $orderobj = new Order;

        /*
         */
       // print_r($payload['orderitem']);exit;
        //care at home logic ends
        //print_r($payload);exit;
        //Continous care logic

        $isTransactionCare = isset($business_obj['is_transaction']) ? (int) $business_obj['is_transaction'] : 0;
		$repeats=(int) $business_obj[repeats];
        $sessionsPerDay=(int) $business_obj[sessionsPerDay];
		$duration=24/$sessionsPerDay;
        
        $frequency = (int) $business_obj['frequency'];
        $sessions = $repeats*$sessionsPerDay;
		
		$finance=new Finance;
		$items = $payload['orderitem'];
		
		// print_r($items );exit;
         $iteminfo_obj = array();
			
            foreach ($items as $item) {
				$item=(object)$item;
				
                $item_obj = array(
                    //"type" => $item->type,
					"category_id" => $item->category_id, 
					"subcategory_id" => $item->subcategory_id,
                    "itemname" => $item->itemname,
                    "item_code" => $item->item_code,
                    "sessions" => $sessions,
                    "gross_amount" => $finance->twoDigitAfterPoint($item->gross_amount),
                    "discount_amount" => $finance->twoDigitAfterPoint($item->discount_amount),
                    "net_amount" => $finance->twoDigitAfterPoint($item->net_amount),
                    "chsessions" => $business_obj[session_no],
                    "item_status" => "0",
                    "instruction" => $item->instruction,
                    "invoiceto" => $item->invoiceto,
                    "reportto" => $item->reportto,
                    "corporateinvoiceemail" => $item->corporateinvoiceemail,
                    "corporatereportemail" => $item->corporatereportemail,
					"role" => $item->role,
					"skill" => $item->skill,
					"roleCode" => $item->skill,
					"roleBasedService" => $item->roleBasedService,
					"wallet_amount" => $item->wallet_amount,
					"voucher_amount" => $item->voucher_amount,
					"cli" => $item->cli,
					"MRP" => $item->MRP,
					"is_cashless" => $item->is_cashless,
					"coupon_amount" => $item->coupon_amount,
					"invoiceto" => $item->invoiceto,
					"reportto" => $item->reportto,
					"payment_code" => $item->payment_code,
					"corporateinvoiceemail" => $item->corporateinvoiceemail,
					"roleCode" => $item->roleCode,
					"cartDiscountApplied" => $item->cartDiscountApplied,
					"discountApplied" => $item->discountApplied,
					"corporatereportemail" => $item->corporatereportemail,
					"cartCouponApplied" => $item->cartCouponApplied,
					"orderDiscountApplied" => $item->orderDiscountApplied,
					"cartDiscountApportionedAmount" => $item->cartDiscountApportionedAmount,
					"orderApportionedDiscountAmount" => $item->orderApportionedDiscountAmount,
					"lineItemDiscountAmount" => $item->lineItemDiscountAmount
					
		
                );
                array_push($iteminfo_obj, $item_obj);
            }
		
		//print_r($iteminfo_obj);exit;
		 
		
		
		//echo $isTransactionCare;exit;
        if ($isTransactionCare != 1) {
            //patientinfo
            //$patientinfo_obj['istransactioncare']="1";
             $business_obj['is_continuous'] = 1;
            //print_r($business_obj);
            //patientinfo

            //item info
            
            //item info end
        }
        //Continous care logic end
        //transaction care logic
        else {

            $business_obj['is_transaction'] = 1;
            //patientinfo
            $patientinfo_obj['istransactioncare'] = "1";
            //patientinfo
			
            //item info
          /*   $items = $payload['orderitem'];
			print_r($items);exit;
            $iteminfo_obj = array();
            foreach ($items as $item) {
                $item_obj = array(
                    "type" => $item->type,
                    "itemname" => $item->itemname,
                    "item_code" => $item->item_code,
                    "sessions" => $business_obj['sessions'],
                    "gross_amount" => (int) $item->gross_amount,
                    "discount_amount" => (int) $item->discount_amount,
                    "net_amount" => (int) $item->net_amount,
                    "chsessions" => $business_obj[session_no],
                    "instruction" => $item->instruction,
                    "invoiceto" => $item->invoiceto,
                    "reportto" => $item->reportto,
                    "corporateinvoiceemail" => $item->corporateinvoiceemail,
                    "corporatereportemail" => $item->corporatereportemail,
                );
                array_push($iteminfo_obj, $item_obj);
            } */
            //item info end

        }
        //transaction care logic end
		 $associate = $payload['associate'];
        $associate['component_no'] = "2";
        $associate_info = array();
        array_push($associate_info, $associate);
		
        $order = array("patientinfo" => $patientinfo_obj, "order_status" => $orderstatus_obj, "orderitem" => $iteminfo_obj,"provider_info" => $associate_info, "business" => $business_obj); 
       // print_r($order);exit;
       
      
	//	echo "4";

	  if ($business_obj[is_parent] == 1) {
			
            $order[business]["parent_id"] = 0;
            $order_array = array();
            $workorder_array = array();
            $log_array = array();
			
			
			
			
			//echo $repeats.$frequency. $sessions.$sessionsPerDay.$duration;exit;
		    	
    
            $scheduled_date = $this->utility->convert_date($patientinfo_obj['scheduled_date']);
			
			/*
				frequency:
				
				1: daily
				2: alternate
				3: every 3 days
				4: weekly
				5: fortnightly
				6: monthly
			
			
			
			*/
			
			$child_order_info=array();
			
			if($sessions>1)
			{
              //for repeat
			  $sessno=1;
			       if ($frequency == 1) {
                        $day= 1;
                    } else if ($frequency == 2) {
                        $day= 2;
                    } else if ($frequency == 3) {
                        $day= 3;
                    }else if ($frequency == 4) {
                        $day= 7;
                    }else if ($frequency == 5) {
                       $day= 15;
                    }else if ($frequency == 6) {
                       $day= 30;
                    } else {
                        $day=1;
                    }
					
					
					
			  for ($repeat = 0; $repeat < $repeats; $repeat++) {

                   
					
					

				
				
				//$scheduled_date
				$durationadd=0;
				for($session_d=0;$session_d<$sessionsPerDay;$session_d++){
					$childorder = $order;
					if($sessno==1)
					{
						$sessno++;
						continue;
					}
			
				$durationadd=$duration*$session_d;
				$nsession=$repeat*$day;
				$next_date = date('Y-m-d H:i:s', strtotime($scheduled_date . ' +' . $nsession . ' day'));
				$next_time = date('Y-m-d H:i:s', strtotime($next_date . ' +' . $durationadd . ' hours'));
			//	echo $sessno."Date: ".$next_time." .... repeat: ".$repeat."..... Day:".$day."  ------ ";
                $childorder[patientinfo][scheduled_date] = $next_time;
                $childorder[business][session_no] = $sessno;
                $childorder[business][is_parent] = 0;
                $childorder[business][parent_id] = $childorder[patientinfo][order_id];
                $childorder[patientinfo][wallet_amount] = 0;
                $childorder[patientinfo][gross_amount] = 0;
                $childorder[patientinfo][discount_amount] = 0;
                $childorder[patientinfo][net_amount] = 0;
                $childorder[patientinfo][coupon_amount] = 0;
                $childorder[patientinfo][voucher_amount] = 0;
                $childorder[patientinfo][surge_amount] = 0;
                $childorder[orderitem][0][wallet_amount] = 0;
                $childorder[orderitem][0][gross_amount] = 0;
                $childorder[orderitem][0][discount_amount] = 0;
                $childorder[orderitem][0][net_amount] = 0;
                $childorder[orderitem][0][coupon_amount] = 0;
                $childorder[orderitem][0][voucher_amount] = 0;
                //echo json_encode($childorder);exit;
                //$payload->order=$childorder;
					
                //$payload->order_status=$childorder[order_status];
                $childorder[type] = $payload[type];
                $childorder[mode_of_service] = $payload[mode_of_service];
                $childorder[additionaldata] = $payload[additionaldata];

                //$childorder[] here make payment_info object and put allvalues as 0
                //    $childorder[source]=$payload[source];
                $childorder['payment_info']['gross_amount'] = 0; 
                $childorder['payment_info']['discount_amount'] = 0;
                $childorder['payment_info']['net_amount'] = 0;
                $childorder['payment_info']['voucher_amount'] = 0;
                $childorder['payment_info']['coupon_amount'] = 0;
                $childorder['payment_info']['wallet_amount'] = 0;
                $childorder['payment_info']['payment_mode'] = 0;
                $childorder['payment_info']['payment_service'] = 0;
                $childorder['payment_info']['payment_reference_id'] = "";
                $childorder['payment_info']['payable_amount'] = 0;
                $childorder['payment_info']['paid_amount'] = 0;
                $childorder['payment_info']['payment_amount'] = 0;
                $childorder['advance_receipt'] = array();


                //print_r($childorder);echo $next_date;exit;
				
			//	echo "2"; 

			//echo json_encode($childorder); 	exit;
                $data_order = $orderobj->createOrder($childorder, $transaction_code);
				
				 //echo "3";  print_r($data_order); 	
                //print_r($childorder);echo $next_date;exit;

                //$order_data = $data_order['order'];
               
				 
			   array_push($order_array, $data_order['order']);
               

			   array_push($workorder_array, $data_order['workorder']);
                array_push($log_array, $data_order['log']);
				//$child_order_info_data=array("session_no"=>$sessno,"order");
				//print_r($data_order);exit;
				array_push($child_order_info,$data_order['order'][order][patientinfo][order_id]);
              
					$sessno++;

				}//end of Sessions per day

			 //end of frequency
		   }
            //end of repeat 
			
			
			//print_r($order_array);
			//exit;
			
            $insert_response = $this->dbo->insertMany('masters', 'orders', $order_array);
            $insert_response = $this->dbo->insertMany('masters', 'workorders', $workorder_array);
            $insert_response = $this->dbo->insertMany('masters', 'orderlog', $log_array);
			
			}
     //  echo "1";
		$order['childOrderIds']=$child_order_info;
	   }
		
		//print_r($order);
			
		
        return $order;
    }

    public function fetch_careplan($payload, $ticket)
    {

        $filter = array("_id" => (int)$payload->order_id);

        $result = $this->dbo->findOne("masters","orders",$filter,array());
        //echo json_encode($result);exit;

        $result["assessment_id"] = $result[order][business][assessment_id];

        $current_date = date("Y-m-d");

        $filter1 = array("assessment_order_id" => (string) $result["assessment_id"], "date" => $current_date, "is_master" => 0);
        $filter2 = array("assessment_order_id" => (string) $result["assessment_id"], "is_master" => 1);

        $result1 = $this->dbo->findOne("masters", "treatmentplan", $filter1, array());
        //    echo json_encode($filter1);exit;

        if (empty($result1)) {
            //echo "123";exit;
            $result2 = $this->dbo->findOne("masters", "treatmentplan", $filter2, array());
            print_r($result2);
            unset($result2['_id']);
            $result2['is_master'] = 0;
            $result2['date'] = $this->utility->getCurrentDate();
            //print_r($result2);
            $insert = $this->dbo->insert("masters", "treatmentplan", $result2);
            $result2['treatmentplanid'] = $result2['_id']->{'$id'};
            $data = $result2;
        } else {
            $result1['treatmentplanid'] = $result1['_id']->{'$id'};
            $data = $result1;
            //echo json_encode($result1);
        }
        $response = array(
            "treatmentplanid" => $data['treatmentplanid']
            , "status" => 1,
            "message" => "Careplan fetched successfully",
            "careplan" => $data,
        );
        return $response;

    }

   public function care_plan_update($payload, $ticket)
    {
        //$current_time = date('Y-m-d H:i:s');
        //$current_time = str_replace(' ','T', $current_time).'.000Z';

        $current_time = $this->utility->getCurrenttime();

        //First fetch the data and find which index in instance array of category array has required instance id
        $search_filter = array("_id" => $this->dbo->id($payload->treatmentplanid)); //PREVIOUS FILTER
       // $search_filter = array("assessment_id" => (string)$payload->assessment_id);
        $search_project = array("category" => 1, "_id" => 0, "assessment_id" => 1);
        $search_cursor = $this->dbo->findOne('masters', 'treatmentplan',$search_filter, $search_project, array());

        $category = $search_cursor['category'];

       //print_r($search_cursor);exit;
        //MAP THE INSTANCE ID TO THE INDEXES IN INSTANCE REQUIRED TO UPDATE
        $inst_id_index_map = array();
        foreach ($category as $each_category) {
            $instance = $each_category['instance'];
            $i = 0;
            foreach ($instance as $each_inst) {
                $inst_id_index_map[$each_inst['instanceId']] = $i;
                $i++;
            }
        }
        
        //Updation filter and set arrays
        //OLD FILTER
		//$filter = array(
        //    "_id" =>new MongoId($payload->treatmentplanid) //ADD (int) as this field should be int not string
        //    , "category.catId" =>  $payload->category_id
        //    , "category.actId" =>  $payload->activity_id,
        //  );
		
		
		$filter = array(
				"_id" => $this->dbo->id($payload->treatmentplanid) //ADD (int) as this field should be int not string
			   ,"category"=> array('$elemMatch'=>
								array(
										"catId" =>  $payload->category_id
									   ,"actId" =>  $payload->activity_id
									)
							)   
				);
        //assessment_id hardcoded field
        //echo json_encode($filter);exit;
        $set = array();
		$activity_parameter = $payload->activity_parameter;
		$activity_parameterValue = $payload->activity_parameterValue;
		if(!empty($activity_parameter)){
			
		
              
		  if ( count($activity_parameter) != count($activity_parameterValue)) {
                $response = array("status" => 0, "message" => "The count of parameter and parameterValue should be same.Please check and correct");
                return $response;
            }
         $set['category.$.' . 'capturedOn'] = $current_time;
			  for ($i = 0; $i < count($activity_parameter); $i++) {
                $set['category.$.' . $activity_parameter[$i]] = $activity_parameterValue[$i];
            }
		}

        if ((int) $payload->is_instance == 1) {

            if ((int) $payload->instance_id <= 0) {
                $response = json_encode(array("status" => 0, "message" => "Invalid instanceId"));
                return $response;
            }

            $index = $inst_id_index_map[$payload->instance_id];
           // print_r($inst_id_index_map);

            //echo $index;


            //(int)$payload->instance_id - 1;

            $instance_parameter = $payload->instance_parameter;
            $instance_parameterValue = $payload->instance_parameterValue;

            
            if (count($instance_parameter) != count($instance_parameterValue) or count($activity_parameter) != count($activity_parameterValue)) {
                $response = array("status" => 0, "message" => "The count of parameter and parameterValue should be same.Please check and correct");
                return $response;
            }

          

            for ($i = 0; $i < count($instance_parameter); $i++) {
                $set['category.$.instance.' . $index . '.' . $instance_parameter[$i]] = $instance_parameterValue[$i];
            }

          

            $set['category.$.instance.' . $index . '.capturedOn'] = $current_time;

        }
		
		//echo json_encode($set).json_encode($filter);exit;
		//echo json_encode(array(array($filter),array('$set'=>$set)));exit;

        if (!empty($set)) 
        {
			try{
            $response = $this->dbo->update('masters', 'treatmentplan', $filter, $set, array(), array());
			}
			catch(Exception $e)
			{
				$response["nModified"]=0;
			}
           // print_r($response);exit;
            if ((int) $response["nModified"] != 0) 
            {
                $response = array("status" => 1, "message" => "Updated " . $response["nModified"] . " records Successfully!");
            }
            else
            {
                 $response = array("status" => 0, "message" => "Unable to update please check the update parameters and treatmentplanid");
            }
        } 
        else 
        {
            $response = array("status" => 0, "message" => "Unable to update");
        }

        return $response;
    }
	
	function checkIsChild($child,$parent)
	{
		if($child==$parent)
		{
			return 0;
		}
		else
		{
			$filter = array("_id"=>(int)$child,
			      "order.business.parent_id" => (int) $parent);
				  
		    $count=$this->dbo->countitem("masters", "orders", $filter);
			
			if($count>0)
				return 1;
			else
				return 0;
		}
	}
	function check_child_session($payload)
	{
		$orderid=$payload->orderId;
		 $filterpatient = array("order.business.parent_id" => (int) $orderid);
		 $project=array(
		 "active"=>
              array(
                 '$cond'=> array('if'=>array( '$eq'=> ['$OStatus', 8] ), "then"=> "inactive", 'else'=> "active" 
               ))
		 
		 );
		 $pipeline=array(
		 array('$match'=>$filterpatient),
		  array('$project'=>$project),
		  array('$group'=>array('_id'=>'$active','count'=>array('$sum'=>1)))
		  
		 );
		 $result = $this->dbo->aggregate("masters", "orders", $pipeline);
		 return $result;
	}
	
}
