<?php

class Econsultation extends Oms
{

    public function __construct()
    {
        parent::__construct();
    }

    public function createAppointment($order, $transaction_code)
    {
        $appointment = $order['appointment_info'];
        $appointment["appointmentId"] = (string) $this->utility->getNextSequence("appointmentid");
        $appointment['mode_of_service'] = $appointment['mode_of_service'];
        $appointment['associate_info'] = $order['associate_info'];
        $appointment['transaction_code'] = $transaction_code;
 
        //print_r($order);exit;
        $order['payment_info'][payment_code] = $order['appointment_info'][payment_code];
        $appointment['payment_info'] = $order['payment_info'];

        //print_r($appointment);exit;
        //$insert_response=$this->dbo->insert('masters','appointments',$appointment);
        //print_r($insert_response);exit;
        return ($appointment);
    }
   public function getOrderCountByMOS($payload,$ticket)
    {
    	$filter = array(
    				'$match'=>array(
    						"order.patientinfo.mrn"=>array('$in'=>$payload->mrn),
							"order.patientinfo.is_consultation"=>array('$in'=>array(1,"1")),
    						"order.patientinfo.conferenceType"=>array('$exists'=>true),
    						"order.patientinfo.conferenceType"=>array('$nin'=>array("",null))
    				)
    	);

    	$group = array(
    		'$group'=>array(
    			"_id"=>'$order.patientinfo.conferenceType',
    			'count'=>array('$sum'=>1) 
    		)
    	);

    	$sort = array(
    		'$sort'=>array('count'=>-1)
    	);

    	$pipeline = array($filter,$group,$sort);
    	//echo json_encode($pipeline);exit;   

    	$result = $this->dbo->aggregate("masters","orders",$pipeline);
    	//echo json_encode($result);

    	if(empty($result))
    	{
    		$response = array("status"=>0,"message"=>"Operation Failed","data"=>$result);
    		return $response;
    	}
    	else
    	{
    		$response = array("status"=>1,"message"=>"Operation Success","data"=>$result);
    		return $response; 
    	}
    }//end of function

    public function createOrderStructure($appointmentId)
    {

        $db = "masters";
        $filter_data = array("appointmentId" => array('$eq' => (string) $appointmentId));
        $project = array();
        $appointment_data = $this->dbo->findOne($db, "appointments", $filter_data, $project);
        $transaction_code = $appointment_data['transaction_code'];
        $mrn = $appointment_data['mrn'];
        $filter_data = array("transaction_code" => array('$eq' => (string) $transaction_code));
        $project = array('patient.' . $mrn => 1, 'source_id' => 1, 'source' => 1, 'source_of_referral' => 1, 'referral_id' => 1, 'referral_mrn' => 1);
        $transaction_data = $this->dbo->findOne($db, "transaction", $filter_data, $project);

        $patient_info = $transaction_data['patient'][$mrn]; //patitent info from transcation collection
        $patitentdata = array(
            "mrn" => $patient_info['mrn'],
            "patient_id" => $patient_info['patient_id'],
            "appointmentId" => $appointment_data['appointmentId'],
            "salutation" => $patient_info['salutation'],
            "name" => $patient_info['name'],
            "address_id" => $patient_info['address_id'],
            "age" => $patient_info['age'],
            "gender" => $patient_info['gender'],
            "contact" => $patient_info['contact'],
            "alternatecontactno" => $patient_info['alternatecontactno'],
            "email" => $patient_info['email'],
            "landmark" => $patient_info['landmark'],
            "pincode" => $patient_info['pincode'],
            "address" => $patient_info['address'],
            "city" => $patient_info['city'],
            "state" => $patient_info['state'],
            "district" => $patient_info['district'],
            "facility_id" => $patient_info['facility_id'],
            "popname" => $patient_info['popname'],
            "home_facility_id" => $patient_info['home_facility_id'],
            "home_popname" => $patient_info['home_popname'],
            "delivery_lat" => $patient_info['delivery_lat'],
            "delivery_lng" => $patient_info['delivery_lng'],
        );

        //   print_r($appointment_data); exit;

        $payment_data = $appointment_data['payment_info']; //payment info from appointments colection
        $payment_info = array(
            "gross_amount" => $payment_data['gross_amount'],
            "discount_amount" => $payment_data['discount_amount'],
            "net_amount" => $payment_data['net_amount'],
            "wallet_amount" => $payment_data['wallet_amount'],
            "voucher_amount" => $payment_data['voucher_amount'],
            "coupon_amount" => $payment_data['coupon_amount'],
            "payment_code" => $payment_data['payment_code'],
            "payment_mode" => $payment_data['payment_mode'],
            "payment_amount" => $payment_data['payment_amount'],
            "payment_service" => $payment_data['payment_service'],
            "payment_reference_id" => $payment_data['payment_reference_id'],
            "voucher_assoc_code" => $payment_data['voucher_assoc_code'],
            "voucher_assoc_name" => $payment_data['voucher_assoc_name'],
            "voucher_code" => $payment_data['voucher_code'],
        );

        //additional data from both the collections
        $additionaldata = array("source_id" => $transaction_data['source_id'],
            "source" => $transaction_data['source'],
            "created_date" => $appointment_data['createdDate'],
            "source_of_referral" => $transaction_data['source_of_referral'],
            "referral_id" => $transaction_data['referral_id'],
            "referral_mrn" => $transaction_data['referral_mrn'],
            "createdById" => $appointment_data['createdById'],
            "createdByName" => $appointment_data['createdByName'],
            "scheduled_date" => $appointment_data['scheduledTime'],
            "service_type" => $appointment_data['serviceTypeId'],
            "service_subtype_id" => $appointment_data['serviceSubTypeId'],
        );

        $patientinfo = array_merge($patitentdata, $additionaldata, $payment_info); //merging arrays to create patient array

        $assoicate_info = $appointment_data['associate_info']; //assicate data from appointments collection
        $assoicatedata = array(
            "associate_name" => $assoicate_info['associate_name'],
            "associate_id" => $assoicate_info['associate_id'],
            "associate_address" => $assoicate_info['associate_address'],
            "associate_Location" => $assoicate_info['associate_Location'],
            "associate_popid" => $assoicate_info['associate_popid'],
            "associate_popname" => $assoicate_info['associate_popname'],
            "associate_branch_id" => $assoicate_info['associate_branch_id'],
            "associate_lat" => $assoicate_info['associate_lat'],
            "associate_long" => $assoicate_info['associate_long'],
            "contact_number" => $assoicate_info['contact_number'],
            "email" => $assoicate_info['email'],
            "officer_id" => $assoicate_info['officer_id'],
            "website_url" => $assoicate_info['website_url'],
            "license_number" => $assoicate_info['license_number'],
            "associate_gst_number" => $assoicate_info['associate_gst_number'],
            "skill" => $assoicate_info['skill'],
        );

        //creating order_item array structure
        $order_item = array(
            array("component_no" => 5,
                "item_code" => $assoicate_info['associate_id'],
                "itemname" => $appointment_data['speciality'],
                "gross_amount" => $payment_data['gross_amount'],
                "discount_amount" => $payment_data['discount_amount'],
                "net_amount" => $payment_data['net_amount'],
                "item_status" => "0",
                "invoiceto" => '',
                "reportto" => '',
                "corporateinvoiceemail" => '',
                "corporatereportemail" => '',
                "item_status" => "0",
                "quantity" => "1",
            ),
        );

        //final array structure
        $totaldata = array("source" => $transaction_data['source'],
            "patientinfo" => $patientinfo,
            'orderitem' => $order_item,
            "associate" => $assoicatedata,
            "mode_of_service" => $appointment_data['mode_of_service'],
            "payment_info" => $payment_info,
            "transaction_code" => (string) $transaction_code);

        return $totaldata;
    }
	
	
	public function createAssessmentOrder($associate, $patientinfo_obj, $orderstatus_obj, $payload,$business_obj)
    {
       // print_r($patientinfo_obj);exit;
        $associate['component_no'] = "2";
		$patientinfo_obj['is_assessment']=1;	
        $associate_info = array();
        array_push($associate_info, $associate);
        $items = $payload['orderitem'];
        $order = array("patientinfo" => $patientinfo_obj, "order_status" => $orderstatus_obj, "orderitem" => $items, "provider_info" => $associate_info,"business" => $business_obj);
        return ($order);
        //exit;
    }
	
	
    public function createConsulationOrder($associate, $patientinfo_obj, $orderstatus_obj, $payload,$business_obj)
    {
       
	   //if()
	 // print_r($payload);exit;
	   
	      /*   "conferenceType": "1",
            "consultationType": "New Consultation",
            "doctorId": "101506",  
            "reason": "", */
			$business=(array)$payload['business'];
			 $items = (array)$payload['orderitem'];
			 
		/* if($payload[mode_of_service]=="3")
        {
			$patientinfo_obj['conferenceType']="1";
		}
		if($payload[mode_of_service]=="4")
        {
			$patientinfo_obj['conferenceType']="2";
		} */

		$patientinfo_obj['conferenceType']= $business['consultationMode'];	
		$patientinfo_obj['is_consultation']=1;
		$patientinfo_obj['specialityId']=$business['specialityId'];	
		
		//IF A NON NUMERIC VALUE IS BEING SENT
		if(!is_numeric($business['consultationType']))
		{
			if(strtolower($business['consultationType']) == "followup")
			{
				$patientinfo_obj['consultationType'] = "2";
			}
			
			else if(strtolower($business['consultationType']) == "assessmentconsultation")
			{
				$patientinfo_obj['consultationType'] = "3";
			}
			else if(strtolower($business['consultationType']) == "assessment")
			{
				$patientinfo_obj['consultationType'] = "3";
			}
			else
			{
				//BY DEFAULT NEW CONSULTATION
				$patientinfo_obj['consultationType'] = "1";
			}
		}
		else
		{
			$patientinfo_obj['consultationType']=$business['consultationType'];
		}
		
		//$patientinfo_obj['consultationType']=$business['consultationType']; //ADDED ABOVE
		$patientinfo_obj['internal']=$business['internal'];
		$patientinfo_obj['mer']=(int)$business['mer'];
		$patientinfo_obj['duration']=(int)$business['duration'];
		$patientinfo_obj['reason']=$business['reason'];
		$patientinfo_obj['doctorName']=$business['doctorName'];
		$patientinfo_obj["doctorId"]= $business['doctorId']; //$items[0]->item_code;//PREVIOUS
	//	$patientinfo_obj["doctorId"]=$items[0][item_code];
		$patientinfo_obj["service_type"]="1";	
		$items[0]->caregiverid= $business['doctorId']; //$items[0]->item_code;	
		$items[0]->role="10";	
        $associate['component_no'] = "5";
        $associate_info = array();
        array_push($associate_info, $associate);
       
        $order = array("patientinfo" => $patientinfo_obj, "order_status" => $orderstatus_obj, "orderitem" => $items, "provider_info" => $associate_info,"business" => $business_obj);

        //for showing alert in doctor app
        //event type is hardcoded for now. This will change based on events(reschedule,cancel) for consultation order
        $this->alertForDoctorApp($order,1);

        return ($order);
        //exit;
    } 
	
	
	public function createAssessmentConsulationOrder($associate, $patientinfo_obj, $orderstatus_obj, $payload,$business_obj)
    {
       
	  
			$business=(array)$payload['business'];
			 $items = (array)$payload['orderitem'];
			 
		

		$patientinfo_obj['conferenceType']= $business['consultationMode'];	
		$patientinfo_obj['is_consultation']=1;
		$patientinfo_obj['specialityId']=$business['specialityId'];	
		
		//IF A NON NUMERIC VALUE IS BEING SENT
		if(!is_numeric($business['consultationType']))
		{
			if(strtolower($business['consultationType']) == "followup")
			{
				$patientinfo_obj['consultationType'] = "2";
			}
			else
			{
				//BY DEFAULT NEW CONSULTATION
				$patientinfo_obj['consultationType'] = "1";
			}
		}
		else
		{
			$patientinfo_obj['consultationType']=$business['consultationType'];
		}
		
		//$patientinfo_obj['consultationType']=$business['consultationType']; //ADDED ABOVE
		$patientinfo_obj['internal']=$business['internal'];
		$patientinfo_obj['mer']=(int)$business['mer'];
		$patientinfo_obj['duration']=(int)$business['duration'];
		$patientinfo_obj['reason']=$business['reason'];
		$patientinfo_obj['doctorName']=$business['doctorName'];
		$patientinfo_obj["doctorId"]= $business['doctorId']; //$items[0]->item_code;//PREVIOUS
	//	$patientinfo_obj["doctorId"]=$items[0][item_code];
		$patientinfo_obj["service_type"]="1";	
		$items[0]->caregiverid= $business['doctorId']; //$items[0]->item_code;	
		$items[0]->role="10";	
        $associate['component_no'] = "5";
        $associate_info = array();
        array_push($associate_info, $associate);
       
	   //$items
	   
	   
	   
        $order = array("patientinfo" => $patientinfo_obj, "order_status" => $orderstatus_obj, "orderitem" => $items, "provider_info" => $associate_info,"business" => $business_obj);

        //for showing alert in doctor app
        //event type is hardcoded for now. This will change based on events(reschedule,cancel) for consultation order
        $this->alertForDoctorApp($order,1);
      
        //create Assessment ORDER
		$assesssmentOrder=$order;
		
		
		
		//$assesssmentOrder[]
		
		
		
		//end creation of assessment order.

	  //  echo "1";exit;
          print_r($assesssmentOrder);exit;
		
		return ($order);
        //exit;
    }



	public function getAppointmentsDetails($payload) 
    {
		$result = array();
		
		//CHECK FOR Mandatory fields
		$flag = 0;
		$mandatory_fields = array('doctorId','mrn','orderId');
		foreach($mandatory_fields as $field)
		{
			if(isset($payload->{$field}) and $payload->{$field}!=null )
			{
				$flag = 1;
				//NEED IN ARRAY FORMAT
				if(!is_array($payload->{$field}) or empty($payload->{$field}))
				{
					$response = array("status"=>0,"message"=>'Need '.$field .' in Array format',"data"=>$result);
					return $response;
				}						
			}
		}	
		
		if($flag != 1)
		{
			$response = array("status"=>0,"message"=>'Atleast one of doctorId,mrn,orderId is mandatory',"data"=>$result);
			return $response;
		}
		
		
		$match = array(); 
		
		//HARD CODED FILTER
		$match["order.patientinfo.is_consultation"] = 1;
		
		//DOCTORID
    	if( !empty($payload->doctorId) and is_array($payload->doctorId) 
													and $payload->doctorId!=null )
    	{
			$match["order.patientinfo.doctorId"] = array('$in'=>$payload->doctorId);
			
		}	
		
		//ORDERID
		if(!empty($payload->orderId) and is_array($payload->orderId) 
													and $payload->orderId!=null)
		{
			$match["_id"] = array('$in'=>$payload->orderId);
		}

		//MRN
		if(!empty($payload->mrn) and is_array($payload->mrn) 
													and $payload->mrn!=null)
		{
			$match['order.patientinfo.mrn'] = array('$in'=>$payload->mrn);
		}		
		
		//STATUS
		if(isset($payload->status))
		{
			$status = $this->config->status_search_categories($payload->status);
			$match["OStatus"] = $status;
		}
		
		
		$sort = array("order.patientinfo.scheduled_date"=>-1);
		//FROM_DATE AND TO_DATE AND DATETYPE
		if(isset($payload->from_date) and isset($payload->to_date))
		{
			if(!($this->utility->validateDate_Ymd($payload->from_date) and $this->utility->validateDate_Ymd($payload->to_date)))
			{
				$response = array("status"=>0,"message"=>"Please provide from_date and to_date in yyyy-mm-dd format","data"=>$result);
				return $response;
			}
			if(!isset($payload->dateFilterType) or 
						!in_array($payload->dateFilterType,['created_date','scheduled_date']))
			{
				$response = array("status"=>0,"message"=>"Please provide a valid dateType(created_date or scheduled_date)","data"=>$result);
				return $response;
			}
			
			if($payload->dateFilterType == "created_date")
			{
				//$date = "createdDate"; //WHEN USING appointments COLLECTION
				$date = "order.order_status.created_date";
			}
			else if($payload->dateFilterType == "scheduled_date")
			{
				//$date = "scheduledTime"; //WHEN USING appointments COLLECTION
				$date = "order.patientinfo.scheduled_date";
			}
			
			$match[$date] = array(
									'$gte' =>$payload->from_date,
									'$lte' =>$payload->to_date
								 );
			
			$sort = array($date=>-1);	
		}
		
		
		//CUSTOMERNAME
		if(isset($payload->customerName))
		{
			$name = $payload->customerName;
			$match['order.patientinfo.name'] = array('$regex'=>"$name",
												'$options'=>"i");
			
			//new MongoRegex("/$name/i")
		}
		
		//CONSULTATIONTYPE
		if(isset($payload->consultationType))
		{
			if(in_array(strtolower($payload->consultationType),['new','review','followup']))
			{
				$conType = $payload->consultationType;
				$match['order.patientinfo.consultationType'] = 
												array('$regex'=>"^$conType$",
													'$options'=>"i");
					//new MongoRegex("^$conType$i")
			}
			else
			{
				$response = array("status"=>0,"message"=>"Please provide a valid consultationType","data"=>$result);
				return $response;
			}
		}
		
		$status_project = array('$cond'=> array( 
									"if"=> array( '$eq'=> [ '$OStatus', 17 ] ), 
									"then"=> 0, //PENDING
									"else"=> array(
										'$cond'=> array(
											"if"=> array( '$in'=> ['$OStatus',[6,505]]), 
											"then"=> 2, //COMPLETED
											"else"=> array(
												'$cond'=> array(
													"if"=> array( '$in'=> ['$OStatus',[8,11]]), 
													"then"=> 4,//CANCELLED
													"else"=> 1  //SCHEDULED
												)
											)	
										)
									)
								)        
							);
		
		$project = array
		(
			'appointmentId' =>'$_id',
			'order_id' => '$_id',
			'parent_mrn' => '$order.patientinfo.parent_mrn',
			'mrn' =>'$order.patientinfo.mrn',
			'conferenceType' =>'$order.patientinfo.conferenceType',
			'consultationType' => '$order.patientinfo.consultationType',
			'doctorId' =>'$order.patientinfo.doctorId',  
			'reason' =>'$order.patientinfo.reason',
			'scheduledTime' =>'$order.patientinfo.scheduled_date',
			//'scheduledTime' => array('$dateToString'=> array( 'format'=>"%Y-%m-%d %H:%M:%S",
			//									'date'=> '$order.patientinfo.servicedate') ),
			'endDateTime' =>'',
			'duration' =>'$order.patientinfo.duration',
			'status' => $status_project, //$OStatus,
			'createdBy' =>'$order.patientinfo.actionById',
			'createdDate' =>'$order.order_status.created_date',         
			'engagementLevel' =>'$mode_of_service',
			'corporateid' =>'$order.patientinfo.corporateid',
			'corporatename' =>'$order.patientinfo.corporatename',
			'mer' => '$order.patientinfo.mer'
		);

		//$pipeline = array(array('$match'=>$match),array('$unwind'=>'$order.orderitem'),array('$sort'=>$sort),array('$project'=>$project));
		
		$pipeline = array(array('$match'=>$match),array('$sort'=>$sort),array('$project'=>$project));
		
		if(isset($payload->pageNo) and isset($payload->perPage) and $payload->perPage!=null
			and $payload->pageNo != null)
		{
			$pageNo = (int)$payload->pageNo;
			$limit = (int)$payload->perPage;
			
			$totalSkip = $limit * ($pageNo - 1);
			
			$pipeline[] = array('$skip'=>$totalSkip);
			$pipeline[] = array('$limit'=>$limit);
		}
		
		//echo json_encode($pipeline);exit; 
		
		//TRY QUERYING
		try
		{
			$result = $this->dbo->aggregate("masters","orders",$pipeline);
			$count = $this->dbo->countitem("masters","orders",$match);
		}
		catch(Exception $e)
		{
			$response = array("status"=>0,"message"=>"Query error: ".$e->getMessage());
			return $response;
		}
		
		
		
		if(!empty($result) and $result!=null)
		{
			$response = array("status"=>1,"message"=>"Success","countn"=>$count,"data"=>$result);
			return $response;   
		}
		else
		{
			$response = array("status"=>0,"message"=>"Empty or Null Response","data"=>$result);
			return $response;
		}
	

		
    }//end of function 


	
    public function getFollowUpInfo($payload,$ticket)
    {
        $mrn = $payload->mrn;
        $doctorId = $payload->doctorId;
        $scheduled_date = $payload->date;
 
        if(empty($payload->mrn))
        {
            $response = array("response"=>0,"message"=>"Please provide MRN value");
            return $response;
        }

        if(empty($payload->doctorId))
        {
            $response = array("response"=>0,"message"=>"Please provide doctorId value");
            return $response;
        }

        if(empty($payload->date))
        {
            $response = array("response"=>0,"message"=>"Please provide date value");
            return $response;
        } 

        $date = date('Y-m-d', strtotime(date('Y-m-d H:i:s',strtotime($scheduled_date)).' -7 days'));
        $scheduled_date = date('Y-m-d', strtotime(date('Y-m-d H:i:s',strtotime($scheduled_date)).' +1 days'));
        //echo $date;exit;

        $filter = array("order.patientinfo.mrn"=>$payload->mrn,
                        "order.patientinfo.doctorId" => $payload->doctorId,
                        "order.patientinfo.scheduled_date" =>array('$gte'=>$date,'$lt'=>$scheduled_date),
                        "order.patientinfo.consultationType" => array('$in'=>array("1","2"))
                       );

        $group = array( 
            '$group'=>array(
                "_id"=>'$order.patientinfo.consultationType',
                'count'=>array('$sum'=>1)
            )
        );


        $pipeline = array(array('$match'=>$filter),$group);
       //echo json_encode($pipeline);//exit;

        $result = $this->dbo->aggregate("masters","orders",$pipeline);
        //echo json_encode($result);exit;
    
       // print_r($result);exit;
		//exit;
        $checknew=0;
        $checkfollowp=0;
        foreach($result as $items)
        {
            if($items['_id'] == "1")
                $checknew=$items['count'];
            if($items['_id'] == "2")
                $checkfollowp=$items['count'];
        }
  
    //  echo $checknew.$checkfollowp;
        if($checknew>0)
        {
            if($checkfollowp>=1)
            {
                $response = array("response"=>1,"message"=> "Not Eligible for follow up","followUp"=>0);
                return $response; 
            }
            else
            {
                $response = array("response"=>1,"message" => "Eligible for FollowUp","followUp"=>1);
                return $response;
            }
        }
        else
        {
            $response = array("response"=>1,"message"=>"Not Eligible for FollowUp","followUp"=>0);
            return $response;
        }
    }
	
	public function updateDoctor($payload, $ticket)
	{
		$mandatoryFields = [orderId,doctorId,doctorName];
		
		foreach($mandatoryFields as $field)
		{
			if(!isset($payload->{$field}) or $payload->{$field}=="")
			{
				$response = array("response"=>0,"message"=>$field." is required");
				return $response;
			}
		}	
		
		
		$response = array("response"=>1,"message"=>"Success");
		
		$orderId = $payload->orderId;
		$doctorId = $payload->doctorId;
		$doctorName = $payload->doctorName;
		
		$dateChanged = $payload->dateChanged;
		
		//$trId = $payload->slotTransactionId
		//slotTransactionId for chiss -> YET TO BE ADDED
		
		if($dateChanged == true)
		{
			if(!isset($payload->scheduledDate) or $payload->scheduledDate=="")
			{
				$response = array("response"=>0,"message"=>"scheduledDate is required when dateChanged");
				return $response;
			}
			
			if($this->utility->validateDate($payload->scheduledDate) == false)
			{
				$response = array("response"=>0,"message"=>"scheduledDate is required in YYYY-MM-DD h:m:s format");
				return $response;
			}
			
			$scheduledDate = $payload->scheduledDate;
		}
		
		$filter = array("_id"=>(int)$orderId);
		$set = array(
					"assaigned_to" => $doctorId,
					"order.patientinfo.doctorId"=>$doctorId,
					"order.patientinfo.doctorName"=>$doctorName,
					 'order.order_status.assignedto' => $doctorId,
                    'order.order_status.mhoname' => $doctorName,
					"order.business.doctorId"=>$doctorId,
					"order.business.doctorName"=>$doctorName
					);
		
		//If dateChanged == true
		if($dateChanged == true)
		{
			$set["order.patientinfo.scheduled_date"] = $scheduledDate;
			$set["order.patientinfo.servicedate"] = $scheduledDate;	
		}
		
		//TRY QUERYING
		try
		{	
			$updateCursor = $this->dbo->update('masters','orders',$filter,$set,array(),array());
		}
		catch(Exception $e)
		{
			$response = array("response"=>0,"message"=>"QueryError: ".$e->getMessage());
			return $response;	
		}
		
		if($updateCursor['nModified'] > 0)
		{
			$response["message"] = "Updated ".$updateCursor['nModified']." records.";
			return $response;
		}
		
		return $response;
	}
	
	
	public function debriefToGcm($orderIds,$userId,$userType)
	{
		$match = array('_id'=>array('$in'=>$orderIds),
						'order.orderitem.referenceOrderId'=>array('$exists'=>true,'$ne'=>null));
						
		$unwind = '$order.orderitem';
		
		$project = array(
							'_id'=>0,	
							'businessId'=>'$order.patientinfo.service_type',
							'appointmentId'=>'$order.orderitem.referenceOrderId',
							'orderId'=>'$_id',
							'orderDId'=>'$odid',
							'mrn'=>'$order.patientinfo.mrn',
							'serviceId'=>'$order.orderitem.item_code'
						);
		
		$pipeline = array(array('$unwind'=>$unwind),array('$match'=>$match),array('$project'=>$project));

		//echo json_encode($pipeline);exit;
		
		
		//TRY QUERYING
		try
		{
			$cursor = $this->dbo->aggregate("masters","orders",$pipeline);
		}
		catch(Exception $e)
		{
			$response = array("status"=>0,"message"=>"Query error: ".$e->getMessage());
			return $response;
		}
		//print_r($cursor);exit;
		
		
		//IF EMPTY CURSOR
		if($cursor==null or !is_array($cursor) or empty($cursor))
		{
			$response = array("status"=>0,"message"=>"No Data Found for this orderIds");
			return $response;
		}
		
		
		//STRUCTURE GCM PAYLOAD AND URL
		$gcm_payload = array("userId"=>$userId,"userType"=>$userType,"data"=>$cursor);
		
		$sub_url = 'services/clinics/updateOrderId'; //OLD URL
        $url = $this->config->getConfig("doctorurl", $sub_url); //URL to hit
		
		//$url = 'http://gcmuatv3.callhealth.com:8096/services/clinics/updateOrderId';
		$gcm_payload = json_encode($gcm_payload);
		
		
		//CALL GCM API
		$startTime = microtime(true);
		//echo $url." ".$gcm_payload;exit;
		
		$responseData = $this->utility->my_curl($url, 'POST', $gcm_payload, 'json', null, 10);			
		//print_r($responseData);exit;
		
		$this->log->logThirdPartyCall("GCM", $url, $startTime, json_decode($gcm_payload), $responseData);
		
		return $responseData;
		
		//HANDLE $responseData FOR NOW NOT REQUIRED
		
	}

	public function alertForDoctorApp($order,$eventType)
	{
		$gcm_payload = array();
		$gcm_payload["eventType"] = $eventType;
		//print_r($order[patientinfo]); exit;
		$alert_payload = array
		(
			"appointmentId" => $order[patientinfo][order_id], 
			//"patientId"=> $payload->patientId,
			"mrn" => $order[patientinfo][mrn],
			"conferenceType"=> $order[patientinfo][conferenceType],
			"consultationType"=> $order[patientinfo][consultationType],
			//"speciality"=> $payload->speciality,
			"doctorId"=> $order[patientinfo][doctorId],
			"doctorName"=> $order[patientinfo][doctorName],
			//"serviceSubTypeId"=> $payload->serviceSubTypeId,
			"serviceTypeId"=>1,
			"reason"=> "",
			"scheduledTime"=> $order[patientinfo][scheduled_date],
			//"endDateTime"=> $payload->endDateTime,
			"duration"=> "",
			"status"=> (int)$order[order_status][order_status],
			"createdBy"=> "",
			"createdDate"=> $order[order_status][created_date],
			//"facilityId"=> $payload->facilityId,
			//"profileId"=> $payload->profileId
		   	"customerFirstName"=>$order[patientinfo][firstName],
		   	"customerLastName"=> $order[patientinfo][lastName]
		);
		$gcm_payload['data'] = $alert_payload;
		$gcm_payload = json_encode($gcm_payload);
		//echo $gcm_payload;exit;

		$sub_url = '/services/clinics/publishClinicsEvents'; //OLD URL
        $url = $this->config->getConfig("doctorurl", $sub_url); //URL to hit
        //echo $url.$gcm_payload;exit;

        $this->utility->async_curl($url, $gcm_payload); 
	}	
}
