<?php

class Imaging
{ 

    public function createOrder($associate, $patientinfo_obj, $orderstatus_obj, $payload, $business_obj)
    {
        //print_r($payload);

        $associate['component_no'] = "7";
        $associate_info = array();
        array_push($associate_info, $associate);

        $report_required = isset($payload['patientinfo']['report_required']) ? $payload['patientinfo']['report_required'] : "";
        $patientinfo_obj['report_required'] = $report_required;
        $items = $payload['orderitem'];
        //print_r($payload); exit;
		
		if(empty($business_obj))
		{
			$business_obj=(object)$business_obj;
		}
        $order = array("patientinfo" => $patientinfo_obj, "order_status" => $orderstatus_obj, "orderitem" => $items, "provider_info" => $associate_info,"business"=>$business_obj);
        return ($order);
        //exit;
    }

}
