<?php

class Wellness
{
    public function createOrder($subBusinessId, $patientinfo_obj, $orderstatus_obj, $payload, $creation_type,$business)
    {

        $package_parent_id = $patientinfo_obj['order_id'];

        //item info
        $items = $payload['orderitem'];

        $iteminfo_obj = array();
        foreach ($items as $item) {
			$item = (object)$item;
            $item_obj = array(
                "type" => $item->type,
                "itemname" => $item->itemname,
                "item_code" => $item->item_code,
                "item_status" => "0",
                "gross_amount" => (int) $item->gross_amount,
                "discount_amount" => (int) $item->discount_amount,
                "net_amount" => (int) $item->net_amount,
                "invoiceto" => $item->invoiceto,
                "item_status" => "17",
				"role" => $item->role,
				"skill" => $item->skill,
                "reportto" => $item->reportto,
                "corporateinvoiceemail" => $item->corporateinvoiceemail,
                "corporatereportemail" => $item->corporatereportemail,
            );
            array_push($iteminfo_obj, $item_obj);
        }
        //item info end

        if ($creation_type != "1") {
            //echo "1";exit;
            //create auto orders
            $packagecode = $item_obj['item_code'];

            //print_r($events);
            //exit;

            $order_number = $this->autoOrder($patientinfo_obj, $orderstatus_obj, $packagecode, $package_parent_id);

            //create auto orders ends
        }
        $order = array("patientinfo" => $patientinfo_obj, "order_status" => $orderstatus_obj, "orderitem" => $iteminfo_obj, "business" => $business);

        return $order;
    }

    //function auto_orders

    public function addDayswithdate($date, $days)
    {
        $date = strtotime("+" . $days . " days", strtotime($date));
        return date("Y-m-d H:i:s", $date);
    }

    public function autoOrder($patientinfo_obj, $orderstatus_obj, $packagecode, $package_parent_id)
    {
        //print_r($events->data);exit;
        $ordercreation = new Order;
        $urlwellness = $this->config->getconfig('CPchoice_url', "getPackageEvents?packageId=" . $packagecode);
        $events = $this->utility->curl_call_urlencode_notimeout($urlwellness, null);
        //$events=$this->utility->curl_call_urlencode_notimeout_vivek($urlwellness,"",array( "Content-Type: application/x-www-form-urlencoded"),"get");
        $patientinfo_obj['package_parent_id'] = $package_parent_id;
        $patientinfo_obj['packagecode'] = $packagecode;
        $scdate = $patientinfo_obj['scheduled_date'];
        $schdate = str_replace(".000Z", "", str_replace("T", " ", $scdate));
        //print_r($events);
        foreach ($events->data as $resultwellnessitems) {

            $itemcode = $resultwellnessitems->serviceDid;
            $itemname = $resultwellnessitems->name;
            $type = $resultwellnessitems->script;

            //    $date = strtotime($resultwellnessitems->when_event." day");
            //$orderdate=date("d-M-Y h:i:s",$date);
            $orddate = $this->addDayswithdate($schdate, $resultwellnessitems->when_event);
            //echo $date."   ".$resultwellnessitems->when_event." ";
            //continue;
            $businessid = $resultwellnessitems->businessId;
            $speciality = $resultwellnessitems->specialityIds;

            //create Diagnostic Order
            //print_r($resultwellnessitems);
            if ($businessid == 1) {

                if ($speciality != "" && $speciality != null) {

                    $speciality = $resultwellnessitems->specialityIds;

                    $req_data = array(
                        "schedule_date" => $orddate,
                        "speciality_ts_code" => $resultwellnessitems->specialityIds,
                        "api_key" => $this->config->getconfig('chisskey', ""),
                    );

                    $url = $this->config->getconfig('chisspath', "api/fetch_doc_specific_slot_ts_code");
                    //echo $url;
                    $data = json_encode($req_data);

                    $buffer = $this->utility->my_curl($url, 'POST', $data, 'json', null, 10);

                    $doc_info = $buffer['data'];
                    $start_date = str_replace("T00:00", "T" . $doc_info['from_time'], $doc_info['schedule_date']);
                    $end_date = str_replace("T00:00", "T" . $doc_info['to_time'], $doc_info['schedule_date']);

                    $specialityname = $itemname;
                    $doctor_name = $doc_info['doctor_name'];
                    $assigneduserid = $doc_info['doctor_id'];
                    $appointment = array(
                        "patientId" => (string) $patientinfo_obj['patient_id'],
                        "doctormobile" => "",
                        "mrn" => (string) $patientinfo_obj['mrn'],
                        "customerFirstName" => (string) $patientinfo_obj['name'],
                        "amount" => "0",
                        "specialityid" => $resultwellnessitems->specialityIds,
                        "speciality_name" => $specialityname,
                        "speciality" => $specialityname,
                        "doctorName" => $doctor_name,
                        "scheduled_datetime" => $start_date,
                        "scheduledTime" => $start_date,
                        "caregiver_id" => $assigneduserid,
                        "grossamount" => "0",
                        "discountamount" => "0",
                        "netamount" => "0",
                        "status" => "1",
                        "doctorId" => $assigneduserid,
                        "coupon" => "",
                        "package_parent_id" => $patientinfo_obj['package_parent_id'],
                        "patientname" => $patientinfo_obj['name'],
                        "patientaddress" => $patientinfo_obj['address'],
                        "zipcode" => $patientinfo_obj['pincode'],
                        "contactno" => $patientinfo_obj['contact'],
                        "customerEmail" => $patientinfo_obj['email'],
                        "itemcodeecon" => $resultwellnessitems->serviceDid,
                        "facilityId" => $patientinfo_obj['facility_id'],
                        "conferenceType" => "2",
                        "serviceTypeId" => "1",
                        "reason" => "Package Appointment",
                        "profileId" => "",
                        "serviceSubTypeId" => "6",
                        "endtime" => $end_date,
                        "conslutationType" => "New Consultation",
                        "transactionId" => $doc_info['transaction_id'],
                    );

                    //int_r($appointment);
                    $data = array();
                    $data['appointment_info'] = $appointment;
                    $order_data = $ordercreation->createAppointment($data, "");

                } else {

                    $patientinfo_obj['scheduled_date'] = $orddate;
                    $patientinfo_obj['service_type'] = "30";
                    $patientinfo_obj['service_subtype_id'] = "6";
                    $iteminfo_obj = array();
                    $item_obj = array(
                        "type" => $type,
                        "itemname" => $itemname,
                        "item_code" => $itemcode,
                        "gross_amount" => 0,
                        "discount_amount" => 0,
                        "item_status" => "0",
                        "net_amount" => 0,
                        "invoiceto" => $patientinfo_obj["invoiceto"],
                        "reportto" => $patientinfo_obj["reportto"],
                        "corporateinvoiceemail" => $patientinfo_obj["corporateinvoiceemail"],
                        "corporatereportemail" => $patientinfo_obj["corporatereportemail"],
                    );
                    array_push($iteminfo_obj, $item_obj);

                    $order = array("patientinfo" => $patientinfo_obj, "order_status" => $orderstatus_obj, "orderitem" => $iteminfo_obj, "business" => $business);

                    $order_data = $ordercreation->createOrder($order, "");

                    //print_r($order);
                    /* echo json_encode($order);
                exit; */
                }
            } else if ($businessid == 3) {
                $patientinfo_obj['scheduled_date'] = $orddate;
                $patientinfo_obj['service_type'] = (string) $businessid;
                $patientinfo_obj['service_subtype_id'] = "13";
                $iteminfo_obj = array();
                $item_obj = array(
                    "type" => $type,
                    "itemname" => $itemname,
                    "item_code" => $itemcode,
                    "gross_amount" => 0,
                    "discount_amount" => 0,
                    "item_status" => "0",
                    "net_amount" => 0,
                    "invoiceto" => $patientinfo_obj["invoiceto"],
                    "reportto" => $patientinfo_obj["reportto"],
                    "corporateinvoiceemail" => $patientinfo_obj["corporateinvoiceemail"],
                    "corporatereportemail" => $patientinfo_obj["corporatereportemail"],
                );
                array_push($iteminfo_obj, $item_obj);

                $order = array("patientinfo" => $patientinfo_obj, "order_status" => $orderstatus_obj, "orderitem" => $iteminfo_obj, "business" => $business);
                //print_r($order);

                $order_data = $ordercreation->createOrder($order, "");

            } else {

                $patientinfo_obj['scheduled_date'] = $orddate;
                $patientinfo_obj['service_type'] = (string) 30;
                $patientinfo_obj['service_subtype_id'] = "6";
                $iteminfo_obj = array();
                $item_obj = array(
                    "type" => $type,
                    "itemname" => $itemname,
                    "item_code" => $itemcode,
                    "gross_amount" => 0,
                    "discount_amount" => 0,
                    "item_status" => "0",
                    "net_amount" => 0,
                    "invoiceto" => $patientinfo_obj["invoiceto"],
                    "reportto" => $patientinfo_obj["reportto"],
                    "corporateinvoiceemail" => $patientinfo_obj["corporateinvoiceemail"],
                    "corporatereportemail" => $patientinfo_obj["corporatereportemail"],
                );
                array_push($iteminfo_obj, $item_obj);

                $order = array("patientinfo" => $patientinfo_obj, "order_status" => $orderstatus_obj, "orderitem" => $iteminfo_obj, "business" => $business);

                $order_data = $ordercreation->createOrder($order, "");

            }
        }
    }

}
