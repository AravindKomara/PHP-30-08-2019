<?php

ini_set('memory_limit', '-1');

class Package extends Oms
{
	public function __construct()
    {
        parent::__construct();
	} 
	 
   public function getBookedPackagesForCoach($payload,$ticket){


	 
	 //Validation
	 if(trim($payload->doctor_id)=='')
	 {
		$logmessage[] = 'doctor_id is missing/invalid'; 
		//exit;
	 }
	 if((string)$payload->type == "1")
     {
		$coach = "health_coach"; 
	 }	
     else if((string)$payload->type == "2")
     {
		$coach = "secondary_coach"; 
	 }	
     
	 else
	 {
		$logmessage[] = 'Invalid Type of doctor/coach(type)';
        //exit; 
	 }
	 
	 if($logmessage != null)
	 {
		 $output = json_encode(array("status"=>0,"message"=>$logmessage));
		 return $output; 
	 }
	
	//Working on data
	$doctor_id = $payload->doctor_id;
	
	
	$filter=array("order.business.".$coach=>(string)$doctor_id,
	              "order.business.is_parent"=>1,"order.business.is_package"=>"1");
	//echo json_encode($filter);exit;
	
	if((!empty($payload->mrn) and $payload->mrn != null) and (!empty($payload->name) and 												$payload->name != null))
	{
		$mrn = $payload->mrn;
		$name = $payload->name;
		
		//$filter['$or'][] = array("order.patientinfo.mrn"=>$mrn,"order.patientinfo.name"=>$name);
		$filter['$or'][] = array("order.patientinfo.mrn"=>$mrn,"order.patientinfo.name"=> array('$regex' => $name,'$options' => "i"));
	}
	
	else if(!empty($payload->mrn) and $payload->mrn != null)
	{
		$mrn = $payload->mrn;
		$filter['order.patientinfo.mrn'] = $mrn;
	}
	
	else if(!empty($payload->name) and $payload->name != null)
	{
		$name = $payload->name;
		$filter['order.patientinfo.name'] = array('$regex' => $name,'$options' => "i");
	}
	
	$project = array("order.patientinfo"=>1,"order.orderitem"=>1);		
	$projectlineitem = array(
	"scheduledTime"=>'$order.patientinfo.scheduled_date',
				"orderId"=>'$_id',
                                "status"=>'$OStatus',
                                "consultationType"=>"New"
	);			  
	$limit = $payload->limit;
    $skip = $payload->skip;	
	
	 $dbo=new Dbo;
	$customer_orders = array();
	$lookup = array(
						'from'=>'orders',
				  		'let'=>array
			  			   (
			  			   		'doctor_id'=>'$order.patientinfo.doctorId',
			  			   		'package_parent_id'=>'$_id'
			               ),
		  			   'pipeline'=>array(array
		  			   						(
		  			   							'$match'=>array
		  			   									      ('$expr'=>array
		  			   									      				('$and'=>array(
		  			   									      					array('$eq'=>array('$order.patientinfo.doctorId',
		  			   									      						$doctor_id)),
		  			   									      					array('$eq'=>array('$order.patientinfo.package_parent_id','$$package_parent_id'))
		  			   									      					)
		  			   									      				)
		  			   									      	)),
		  			   						array('$project'=>$projectlineitem)
		  			   						),
		  			   'as'=>'lineitem_data'
		  			);		  
	$pipeline = array(array('$match'=>$filter),array('$project'=>$project),array('$lookup'=>$lookup));
	
	if($payload->pagination == true)
	{
		if(isset($payload->limit) and isset($payload->skip))
		{
			$limit = (int)$payload->limit;
			$skip = (int)$payload->skip;
			$totalSkip = $limit * ($skip - 1);
			
			array_push($pipeline, array('$skip'=>$totalSkip));
			array_push($pipeline, array('$limit'=>$limit));
		}
	}

	//echo json_encode($pipeline);exit;
	$package_data= $dbo->aggregate("masters","orders",$pipeline);
	//print_r($package_data);exit;
	foreach( $package_data as $result)
	{
		$customer_data = array(
	                       "mrn"=>$result["order"]["patientinfo"]["mrn"],
	                       "name"=>$result["order"]["patientinfo"]["name"],
	                       "age"=>$result["order"]["patientinfo"]["age"],
	                       "gender"=>$result["order"]["patientinfo"]["gender"]
						);
	//print_r($customer_data);exit;

				$package_data = array(
	                      "package_parent_id"=>$result['_id'],
						  "package_expiry_date"=>$result["order"]["patientinfo"]["end_date"],
						  "package_item_code"=>$result["order"]["orderitem"][0]["item_code"],
						  "package_item_name"=>$result["order"]["orderitem"][0]["itemname"]
	                    );
		
		
	    $customer_orders[] = array(
							   "customer_data"=>$customer_data,
							   "package_data"=>$package_data,
							   "lineitem_data"=>$result[lineitem_data]
							);
	}
	 
	$packagecount=$dbo->countitem('masters','orders',$filter);
		
		
		
	$output = array("status"=>"1",
	                       "doctor_id"=>$doctor_id,
						   "coach"=>$coach,    
	                       "count"=>$packagecount,
	                       "customer_orders"=>$customer_orders
						   
				    );
	//exit;
	//echo $output;exit;
    return $output;
	
}
	
	public function getBookedPackagesforMrn($payload,$ticket)
	{
		
		$this->log->create_log("","","package","Execution",200,"getBookedPackages_start",json_encode($payload),(string)$ticket);    
		if($payload->mrn=='')
		{
			$response = array("status"=>"0","message"=>"Mrn is empty");
			return $response;
		}
				
		$mrn = $payload->mrn;
		$date = $this->utility->getCurrentdatetimesimple();
		 
		$filter=array("order.patientinfo.mrn"=>(string)$mrn,"order.business.is_package"=>array('$exists'=>true,'$eq'=>"1")
						,"order.patientinfo.end_date"=>array('$gte'=>$date)	);
		
		$project = array("order.patientinfo"=>1,"order.orderitem"=>1);		
		$projectlineitem = array(
					"scheduledTime"=>'$order.patientinfo.scheduled_date',
					"orderId"=>'$_id',
					"status"=>'$OStatus',
					"consultationType"=>"New"
					);			  
		$limit = $payload->limit;
		$skip = $payload->skip;	
		
		$dbo=new Dbo;
		$customer_orders = array();
		$lookup = array(
							'from'=>'orders',
							'let'=>array
							   (
									'package_parent_id'=>'$_id'
							   ),
						   'pipeline'=>array(array
												(
													'$match'=>array
																  ('$expr'=>array
																				('$and'=>array(
																					array('$ne'=>array('$order.patientinfo.doctorId',
																						null)),
																					array('$eq'=>array('$order.patientinfo.package_parent_id','$$package_parent_id'))
																					)
																				)
																	)),
												array('$project'=>$projectlineitem)
												),
						   'as'=>'lineitem_data'
						);		  
		$pipeline = array(array('$match'=>$filter),array('$project'=>$project),array('$lookup'=>$lookup));

		//echo json_encode($pipeline);exit;
		$this->log->create_log("","","package","Execution",200,"getBookedPackages_Query",json_encode($pipeline),(string)$ticket);
		try
		{			
			$package_data= $dbo->aggregate("masters","orders",$pipeline);
		}
		catch(Exception $e)
		{
			$output = array("status"=>"0",
							"message"=>"Query Error: ". $e->getMessage());
			$this->log->create_log("","","package","Execution",300,"getBookedPackages_Error",json_encode($output),(string)$ticket);				
			return $response;
		}
		
		//print_r($package_data);exit;
		foreach( $package_data as $result)
		{
			$customer_data = array(
							   "mrn"=>$result["order"]["patientinfo"]["mrn"],
							   "name"=>$result["order"]["patientinfo"]["name"],
							   "age"=>$result["order"]["patientinfo"]["age"],
							   "gender"=>$result["order"]["patientinfo"]["gender"]
							);
		//print_r($customer_data);exit;

					$package_data = array(
							  "package_parent_id"=>$result['_id'],
							  "package_expiry_date"=>$result["order"]["patientinfo"]["end_date"],
							  "package_item_code"=>$result["order"]["orderitem"][0]["item_code"],
							  "package_item_name"=>$result["order"]["orderitem"][0]["itemname"]
							);
			
			
			$customer_orders[] = array(
								   "customer_data"=>$customer_data,
								   "package_data"=>$package_data,
								   "lineitem_data"=>$result[lineitem_data]
								);
		}
		
		$packagecount=$dbo->countitem('masters','orders',$filter);
			
			
		if($packagecount > 0)
		{			
			$output = array("status"=>"1",
							"message"=>"success",  
							"count"=>$packagecount,
							"customer_orders"=>$customer_orders
						);
		}
		else
		{
			$output = array("status"=>"0",
							"message"=>"No Data Found");
		}
		$this->log->create_log("","","package","Execution",200,"getBookedPackages_end",json_encode($output),(string)$ticket);	
		return $output;	
	}
	
	
	
	
	
	public function getBookedPackages($payload,$ticket)
	{
		    
		if($payload->mrn=='')
		{
			$response = array("status"=>"0","message"=>"Mrn is empty");
			return $response;
		}
				
		$mrn = $payload->mrn;
		$date = $this->utility->getCurrentdatetimesimple();
		 
		$filter=array("order.patientinfo.mrn"=>(string)$mrn,"order.business.is_package"=>array('$exists'=>true,'$eq'=>"1")
		,
		
		//"order.patientinfo.scheduled_date"=>array('$lte'=>$date),
		
		"order.patientinfo.end_date"=>array('$gte'=>$date)
		
		
		);
		
		$project = array(
		"_id"=>1,
		//"did"=>1,
		"odid"=>1,
		"wodid"=>1,
		"wid"=>1,
		"OStatus"=>1,
		"WOStatus"=>1,
		"assaigned_to"=>1,
		"mode_of_service"=>1,
		"order.patientinfo.mrn"=>1,
		"order.patientinfo.age"=>1,
		"order.patientinfo.gender"=>1,
		"order.patientinfo.city"=>1,
		"order.patientinfo.address"=>1,
		"active_component"=>1,
		"component_order"=>1,
		"order.patientinfo.pincode"=>1,
		"order.patientinfo.contact"=>1,
		"order.patientinfo.email"=>1,
		"order.patientinfo.name"=>1,
		"order.patientinfo.service_type"=>1,
		"order.patientinfo.delivery_lat"=>1,
		"order.patientinfo.delivery_lng"=>1,
		"order.patientinfo.scheduled_date"=>1,
		"order.patientinfo.gross_amount"=>1,
		"order.patientinfo.discount_amount"=>1,
		"order.patientinfo.net_amount"=>1,
		"order.patientinfo.doctorId"=>1,
		"order.patientinfo.doctorName"=>1,
		"payment_info"=>1,
		"order.order_status.created_date"=>1,
		"order.provider_info"=>1,
		"order.business"=>1,
		"order.orderitem"=>1,
		"order.patientinfo.final_delivery_date"=>1,
		"order.patientinfo.order_status"=>1,
		"order.patientinfo.corporatename"=>1,
		"transaction_code"=>1,
		"createdById"=>1,
		"channel"=>1,
		"createdByName"=>1,
		"data"=>1
	);
		
	$projectchild = array(
		"_id"=>1,
		//"did"=>1,
		"odid"=>1,			
		"OStatus"=>1,
		"assaigned_to"=>1,
		"mode_of_service"=>1,
		"order.patientinfo.mrn"=>1,
		"order.patientinfo.age"=>1,
		"order.patientinfo.gender"=>1,
		"order.patientinfo.city"=>1,
		"order.patientinfo.address"=>1,
		"active_component"=>1,
		"component_order"=>1,
		"order.patientinfo.pincode"=>1,
		"order.patientinfo.contact"=>1,
		"order.patientinfo.email"=>1,
		"order.patientinfo.name"=>1,
		"order.patientinfo.service_type"=>1,
		"order.patientinfo.delivery_lat"=>1,
		"order.patientinfo.delivery_lng"=>1,
		"order.patientinfo.scheduled_date"=>1,
		"order.patientinfo.gross_amount"=>1,
		"order.patientinfo.discount_amount"=>1,
		"order.patientinfo.net_amount"=>1,
		"order.patientinfo.doctorId"=>1,
		"order.patientinfo.doctorName"=>1,
		"payment_info"=>1,
		"order.order_status.created_date"=>1,
		"order.provider_info"=>1,
		"order.business"=>1,
		"order.orderitem"=>1,
		"order.patientinfo.final_delivery_date"=>1,
		"order.patientinfo.order_status"=>1,
		"order.patientinfo.corporatename"=>1,
		"transaction_code"=>1,
		"createdById"=>1,
		"channel"=>1,
		"createdByName"=>1,
		"suborders._id"=>1,
		"suborders.odid"=>1,
		"suborders.OStatus"=>1,
		"suborders.assaigned_to"=>1,
		"suborders.mode_of_service"=>1,
		"suborders.order.patientinfo.mrn"=>1,
		"suborders.order.patientinfo.age"=>1,
		"suborders.order.patientinfo.gender"=>1,
		"suborders.order.patientinfo.city"=>1,
		"suborders.order.patientinfo.address"=>1,
		"suborders.active_component"=>1,
		"suborders.component_order"=>1,
		"suborders.order.patientinfo.pincode"=>1,
		"suborders.order.patientinfo.contact"=>1,
		"suborders.order.patientinfo.email"=>1,
		"suborders.order.patientinfo.name"=>1,
		"suborders.order.patientinfo.service_type"=>1,
		"suborders.order.patientinfo.specialityId"=>1,
		"suborders.order.patientinfo.delivery_lat"=>1,
		"suborders.order.patientinfo.delivery_lng"=>1,
		"suborders.order.patientinfo.scheduled_date"=>1,
		"suborders.order.patientinfo.gross_amount"=>1,
		"suborders.order.patientinfo.discount_amount"=>1,
		"suborders.order.patientinfo.net_amount"=>1,
		"suborders.order.patientinfo.doctorId"=>1,
		"suborders.order.patientinfo.doctorName"=>1,
		"suborders.order.order_status.created_date"=>1,
		"suborders.order.provider_info"=>1,
		"suborders.order.business"=>1,
		"suborders.order.orderitem"=>1,
		"suborders.order.patientinfo.final_delivery_date"=>1,
		"suborders.order.patientinfo.order_status"=>1,
		"suborders.order.patientinfo.corporatename"=>1,
		"suborders.transaction_code"=>1,
		"suborders.createdById"=>1,
		"suborders.channel"=>1,
		"suborders.createdByName"=>1,
	);	
		$lookup = array(
					"from"=> "orders", 
					"localField"=> "_id", 
					"foreignField"=> "order.patientinfo.package_parent_id", 
					"as"=>"suborders" 
				);
		
		$dbo=new Dbo;
		$pipeline=array(
		array('$match'=>$filter),
		array('$project'=>$project),
		array('$lookup'=>$lookup),
		array('$project'=>$projectchild)
		);
		
		//echo json_encode($pipeline);exit;
		$packageorder=$dbo->aggregate('masters','orders',$pipeline);
		
		//print_r($packageorder);
		//$i=0;
		// foreach($packageorder as $indpackage)
		// {

			// $filter=array("order.patientinfo.package_parent_id"=>(int)$indpackage['_id']);
			// $packagesuborders=$dbo->find('masters','orders',$filter,array(),array("order.patientinfo.scheduled_date"=>1));
			


			// $packageorder[$i]['suborders']=$packagesuborders;
			


			// $i++;
		// }

	//	print_r($packageorder);exit;
		$response = array("response"=>"1","message"=>"success","orders"=>$packageorder);
		return $response;
	}
	

	public function getBookedPackagesname($payload,$ticket)
	{
		if($payload->mrn=='')
		{
			$response = array("status"=>0,"message"=>"Mrn is empty");
			return $response;
		}
				
		$mrn = $payload->mrn;
		$date = $this->utility->getCurrentdatetimesimple();
		 
		$filter= array("order.patientinfo.mrn"=>(string)$mrn,"order.business.is_package"=>array('$exists'=>true,'$eq'=>"1")
							, "order.patientinfo.end_date"=>array('$gte'=>$date));
							
		$project= array("order.orderitem.itemname"=>1);

		$cursor = $this->dbo->find('masters','orders',$filter,$project,array("order.patientinfo.servicedate"=>1));

		$response = array("status"=>0,"message"=>"No Packages found for MRN");

		if(!empty($cursor))
		{
			$response['packages'] = array();
			foreach($cursor as $record)
			{
				$response['packages'][] = $record['order']['orderitem'][0]['itemname']; 
			}
			
			if(!empty($response['packages']))
			{
				$response["status"] = 1;
				$response["message"]= "Packages found";
			}
		}
		return $response;
	}
	
	
	public function getPackageCount($payload,$ticket)
	{
		
		   
	
			$dbo = new Dbo;
			if(isset($payload->doctorId)){
					if(trim($payload->doctorId) == '')
					{
						echo json_encode( array('response'=>0,'message'=>'doctor_id is missing') );
						exit;
					}
					$doctor_id = $payload->doctorId;
					
					$filter1 = array("order.business.health_coach"=>(string)$doctor_id, 
							  "order.business.is_package"=>array('$in'=>array("1",1)),
							   "order.business.is_parent"=>array('$in'=>array("1",1)));
							 
					$filter2 = array("order.business.secondary_coach"=>(string)$doctor_id,
							   "order.business.is_package"=>array('$in'=>array("1",1)),
							   "order.business.is_parent"=>array('$in'=>array("1",1)));
							 
					
					$health_coach_count=$dbo->countitem('masters','orders',$filter1);
					$secondary_coach_count=$dbo->countitem('masters','orders',$filter2);	
					
					$output = array("status"=>1,"data"=>array("health_coach_count"=>$health_coach_count,
									"secondary_coach_count"=>$secondary_coach_count));
									
							
			}
			else if(isset($payload->mrn)){
					if(trim($payload->mrn) == '')
					{
						echo json_encode( array('response'=>0,'message'=>'mrn is missing') );
						exit;
					}
					$mrn = $payload->mrn;
					
					$filter1 = array("order.patientinfo.mrn"=>(string)$mrn, 
							  "order.business.is_package"=>array('$in'=>array("1",1)),
							   "order.business.is_parent"=>array('$in'=>array("1",1)));
							 
					
							 
					
					$package_count=$dbo->countitem('masters','orders',$filter1);
					
					
					$output = array("status"=>1,"data"=>array("package_count"=>$package_count));
									
							
			}
			else
			{
				$output = array("status"=>0,"message"=>"doctorId or mrn should be present.");
			}
			
			return $output;
	}
	
	
	
	
	
	public function createOrder($associate, $patientinfo_obj, $orderstatus_obj, $payload,$business_obj,$transaction_code)
    {
		//print_r($patientinfo_obj);exit;
        //$associate['component_no'] = "7"; //NO COMPONENT YET
		
		//SPECIFICS FOR PARENT ORDER
		$patientinfo_obj['is_package']=1;
		$patientinfo_obj['is_parent']=1;
		$patientinfo_obj['package_parent_id'] = null;
		$package_parent_id = $patientinfo_obj['order_id'];
		
        $associate_info = array();
        array_push($associate_info, $associate);
        $items = $payload['orderitem'];
        $order = array("patientinfo" => $patientinfo_obj, "order_status" => $orderstatus_obj, "orderitem" => $items, "provider_info" => $associate_info,"business"=>$business_obj);
		
		if((int)$payload['business']->is_package == 1 and 
						(int)$orderstatus_obj[order_status] ==  6)
		{
			$packagecode = $items[0]->item_code;
			$startDate = $this->utility->convert_date($patientinfo_obj[scheduled_date]);
			
			//AUTO ORDER
			unset($payload['business']);
			unset($payload['payment_info']);
			unset($payload['advance_receipt']);
		//	$payload[patientinfo][landmark]=$param=str_replace("\\'", "",$payload[patientinfo][landmark]);
		  //  $payload[patientinfo][address]=$param=str_replace("\\'", "",$payload[patientinfo][address]);
			$autoPayload = array("packageCode"=>$packagecode
							,"startDate"=>$startDate
							,"package_parent_id"=>$package_parent_id
							,"orderPayload"=>$payload
							,"transactionCode"=>$transaction_code
							);
			
			$url = $this->config->getConfig("serverurl","OMS/api/order.php/v1/autoOrder");
			$autoPayload = json_encode($autoPayload);
			//echo $url." ".
			
			//echo $autoPayload;exit;
			
			$buffer = $this->utility->async_curl($url,$autoPayload);
			//print_r($buffer);exit;
			
			sleep(2); //AS THE CHILD ORDERS NEED TO BE CREATED BEFORE ALLOCATION THROUGH CHISS
		}							
		
        return ($order);
        //exit;
    }
	
	public function autoOrder($pkgCode,$startDate,$package_parent_id,$orderPayload,$transaction_code)
	{
		$logPayload = array("packageCode"=>$pkgCode
							,"startDate"=>$startDate
							,"package_parent_id"=>$package_parent_id
							,"orderPayload"=>$orderPayload
							,"transactionCode"=>$transaction_code);
		
		$this->log->create_log("","","package","Execution",200,"autoOrder_start",json_encode($logPayload),(string)$ticket);
		
		try
		{
			//CPEvents API PAYLOAD
			//$url = $this->config->getConfig(,);
			$payload = array(
							"code"=>$pkgCode,
							"start_date"=> $startDate,
							"lat"=> (string)$orderPayload->patientinfo->delivery_lat,
							"lon"=> (string)$orderPayload->patientinfo->delivery_lng,
							"zipcode"=>$orderPayload->patientinfo->pincode,
							);
							
			//CALL CPEvents
			$url = $this->config->getConfig("CPchoice_url","getEventsOrders");
			$payload = json_encode($payload);
			//echo $url." ".$payload;exit;
			
			$this->log->create_log("","","package","Execution",200,"cpevents_start",$payload,(string)$ticket);
			
			$buffer = $this->utility->my_curl($url,'POST',$payload,'json',null,10);
			//print_r($buffer);exit;
			
			$this->log->create_log("","","package","Execution",200,"cpevents_response",json_encode($buffer),(string)$ticket);
			
			//NEGATIVE RESPONSE
			if((int)$buffer["status"] != 1)
			{
				$response = array(
								"status"=>"0",
								"message"=>"CPEvents API response is invalid or empty"
								);
				
				$this->log->create_log("","","package","Execution",200,"autoOrder_issue",json_encode($response),(string)$ticket);
				
				return $response;
				
			}
			
			//POSITIVE RESPONSE
			$pkgOrders = $buffer["subOrders"];
			
			$orders = array();
			
			//Type casting orderPayload to match the order_set argument of insertTransaction which is called further 
			$orderPayload = (array)$orderPayload;
			$orderPayload['patientinfo'] = (array)$orderPayload['patientinfo'];
			$orderPayload['associate'] = (array)$orderPayload['associate'];
			$orderPayload['payment_info'] = (array)$orderPayload['payment_info'];
			$orderPayload['additionaldata'] = (array)$orderPayload['additionaldata'];
			
		
			$tempOrder = $orderPayload;
			
			//not required for normal orders which are in parent package order
			unset($tempOrder['business']->is_package);
			unset($tempOrder['business']->end_date);
			//unset($tempOrder['business']->primaryCoach);
			unset($tempOrder['orderStatus']);
			
			//print_r($tempOrder);exit;
			
			
			//GET ITEM DETAILS
			$ord_num = 0; //ITERATOR
			foreach($pkgOrders as $order)
			{
				$items = $order['items'];
				$service_type = $order['service_type'];
				
				//DOCTOR ORDER IS A CONSULTATION ORDER(10 == 1)
					if((int)$service_type==10)
					{
						$pkgOrders[$ord_num]['service_type'] = "1";
					}
					
					$item_codes = array();
					$external_codes = array();
					$item_num = 0;
					foreach($items as $item)
					{
						if((int)$item['roleBasedService'] != 1)
						{
							$pkgOrders[$ord_num]['items'][$item_num]['roleBasedService'] = 0;
							if((string)$service_type=="1" and $order['internal'] == 0 
									and (int)$order['is_assessment']!=1)
							{
								$external_codes[] = $item[item_code];
							}
							else
							{
								$item_codes[] = $item[item_code];
							}
						}
						
						//NO AMOUNTS IN CHILD ORDERS
						$pkgOrders[$ord_num]['items'][$item_num][net_amount] = 0;
						$pkgOrders[$ord_num]['items'][$item_num][gross_amount] = 0;
						$item_num++;	
					}
					
					//ADDED FOR UNIQUE ITEM CODES
					$external_codes = array_values(array_unique($external_codes));
					$item_codes = array_values(array_unique($item_codes));
					
					//Service type:1 and is_consultation requires internal or external doctor specification
					if((string)$service_type=="1")
					{
						if((!empty($item_codes) or !empty($external_codes)) 
													and (int)$order['is_assessment']!=1)
						{
							$item_data[] = array("business"=>"1",//FOR MDM IN CASE OF CONSULTATION
										 "itemcodes"=>$item_codes,
										 "externalCodes"=>$external_codes
										);
						}
						
						else if(!empty($item_codes))
						{
							$item_data[] = array("business"=>(string)$service_type,
										 "itemcodes"=>$item_codes
										);
						}					
					}
					
					else
					{
						if(!empty($item_codes))
						{
							$item_data[] = array("business"=>(string)$service_type,
											 "itemcodes"=>$item_codes
											);
						}					
					}
					
					$ord_num++;
			}
			
			//IN CASE OF all roleBasedService items in a order need not call MDM
			if($item_data!=null and !empty($item_data))
			{
				//FETCH ITEM DETAILS FROM MDM		
				$mdm = new Mdm;
				
				$item_payload = array("data"=>$item_data);
				//print_r($item_payload);exit;
				
				$item_info = $mdm->get_line_item_info($item_payload);	
				//print_r($item_info);exit;
			}	
			
			//PUSH TO RESPECTIVE LINE ITEM
			for($i=0;$i<count($pkgOrders);$i++)
			{
				for($j=0;$j<count($pkgOrders[$i]['items']);$j++)
				{
					if($pkgOrders[$i]['items'][$j]['roleBasedService']==0)
					{
						$lineitem = $item_info[$pkgOrders[$i]['items'][$j]['item_code']];
						
						if($lineitem!=null and !empty($lineitem))
						{	
							foreach($lineitem as $key=>$value)
							{
								$pkgOrders[$i]['items'][$j][$key] = $value;
							}
						}
					}
				}
			}
			
			
			foreach($pkgOrders as $order)
			{

				$services_with_associate = array(3, 4, 1, 6, 7, 8, 14);

				//SAME AHELP AS OF PARENT ORDER
				if (in_array((int) $order['service_type'], $services_with_associate)) 
				{

					$associate = $orderPayload['associate'];
				}
				else
				{
					$associate = array();
				}
				
				
				//MAKE ORDERS
				$tempOrder['type'] = (string)$order['service_type'];
				$tempOrder['mode_of_service'] = $order['mode_of_service']; //YET TO CONFIRM
				
				$tempOrder['patientinfo']['scheduled_date'] = $order['date'];
				$tempOrder['patientinfo']['service_type'] = (string)$order['service_type'];
				$tempOrder['patientinfo']['gross_amount'] = 0;
				$tempOrder['patientinfo']['discount_amount'] = 0;
				$tempOrder['patientinfo']['net_amount'] = 0;
				$tempOrder['patientinfo']['wallet_amount'] = 0;
				$tempOrder['patientinfo']['voucher_amount'] = 0;
				$tempOrder['patientinfo']['coupon_amount'] = 0;
				//$tempOrder['patientinfo']['MRP'] = 0;
				$tempOrder['patientinfo']['cli'] = 0; 
				$tempOrder['patientinfo']['surge_amount'] = 0;
				$tempOrder['patientinfo']['payment_code'] = 1;
				$tempOrder['patientinfo']['coupon'] = ""; 
				$tempOrder['patientinfo']['payment_mode'] = 1;
				$tempOrder['patientinfo']['payment_amount'] = 0;
				$tempOrder['patientinfo']['payment_service'] = "";
				$tempOrder['patientinfo']['payment_reference_id'] = "";
				$tempOrder['patientinfo']['voucher_assoc_code'] = "";
				$tempOrder['patientinfo']['voucher_assoc_name'] = "";
				$tempOrder['patientinfo']['voucher_code'] = "";
				$tempOrder['patientinfo']["package_parent_id"] = $package_parent_id;
				
				$tempOrder['orderitem'] = $order['items'];
				
				$tempOrder['associate'] = $associate;
				
				$tempOrder['advance_receipt'] = array(); //EMPTY FOR CHILD ORDERS
				
				$tempOrder['payment_info']['gross_amount'] = 0;
				$tempOrder['payment_info']['discount_amount'] = 0;
				$tempOrder['payment_info']['net_amount'] = 0;
				$tempOrder['payment_info']['wallet_amount'] = 0;
				$tempOrder['payment_info']['voucher_amount'] = 0;
				$tempOrder['payment_info']['coupon_amount'] = 0;
				//$tempOrder['payment_info']['MRP'] = 0;
				$tempOrder['payment_info']['cli'] = 0; 
				$tempOrder['payment_info']['surge_amount'] = 0;
				$tempOrder['payment_info']['payment_code'] = 1;
				$tempOrder['payment_info']['coupon'] = ""; 
				$tempOrder['payment_info']['payment_mode'] = 1;
				$tempOrder['payment_info']['payment_amount'] = 0;
				$tempOrder['payment_info']['payment_service'] = "";
				$tempOrder['payment_info']['payment_reference_id'] = "";
				$tempOrder['payment_info']['voucher_assoc_code'] = "";
				$tempOrder['payment_info']['voucher_assoc_name'] = "";
				$tempOrder['payment_info']['voucher_code'] = "";
				
				$buff_obj = array();
				
				$buff_obj['service_type'] = (string)$order['service_type'];
				if((int)$order['service_type'] == 1)
				{
					$buff_obj['specialityId'] = $order['specialityId'];
					$buff_obj['consultationMode'] = "2";//$order['consultationMode'];
					$buff_obj['consultationType'] = "new";//$order['consultationType'];
					$buff_obj['is_consultation'] = 1;
				}					
				$buff_obj['creation_type'] = 1;
				$buff_obj['surge_amount'] = 0;
				$buff_obj['scheduled_date'] = $order['date'];
				$buff_obj['mode_of_service'] = $order['mode_of_service'];//YET TO CONFIRM
				$buff_obj['payment_code'] = 0;	
				$buff_obj['order_item'] = $order['items'];
				$buff_obj['gross_amount'] = 0;
				$buff_obj['net_amount'] = 0;
				$buff_obj['voucher_amount'] = 0;
				$buff_obj['wallet_amount'] = 0;
				$buff_obj['coupon_amount'] = 0;
				$buff_obj['cli'] = 0;
				$buff_obj['is_parent'] = 0;
				//$buff_obj['is_package'] = 1;
				$buff_obj['eventId'] = $order['eventId'];
				$buff_obj['package_parent_id'] = $package_parent_id;
				
				$tempOrder['business'] = (object)$buff_obj;
				
				
				
				$tempOrder['additionaldata']['scheduled_date'] = $order['date'];
				$tempOrder['additionaldata']['service_type'] = $order['service_type'];
				//$tempOrder['additionaldata']['eventId'] = $order['eventId'];
				
				
				array_push($orders,$tempOrder);
			}
			
			//print_r($orders);exit;
			
			//CALL INSERT TRANSACTION FUNCTION
			
			$obj = new Order;
			$insertResponse = $obj->insertTransaction($orders,$transaction_code);
			
			//INSERTION LOGIC LIKE IN api/order.php createTransaction()
			//print_r($insertResponse);exit;
			
			
			/* if($insertResponse[set][appointments] != null)
			{
				$app_array = $insertResponse[set][appointments];
			} */
			
			if($insertResponse[set][order] != null)
			{
				$order_array = $insertResponse[set][order];
			}
			
			if($insertResponse[set][workorders] != null)
			{
				$workorder_array = $insertResponse[set][workorders];
			}
			
			if($insertResponse[set][orderlog] != null)
			{
			$orderlog_array = $insertResponse[set][orderlog];
			}
			
			
			//GET CHILDS ORDERS' ORDERIDS,APPOINTMENTIDS TO PASS TO CHISS
			if(!empty($insertResponse[orders]) and $insertResponse[orders]!=null)
			{
				$order_ids[] = $insertResponse[orders];
			}
			
			/* if(!empty($insertResponse[appointments]) and $insertResponse[appointments]!=null)
			{
				$appointment_ids[] = $insertResponse[appointments];
			} */
			
			//INSERTING ALL THE ORDER,APPOINTMENTS,WORKORDERS,ORDERLOGS FOR CHILD ORDERS

			/* if(isset($app_array) and !empty($app_array))
			{
				//$app_array = call_user_func_array('array_merge', $app_array);
				//echo json_encode($app_array);exit;
				$insert_response = $this->dbo->insertMany('masters','appointments',$app_array);
			} */
			
			if(isset($order_array) and !empty($order_array))
			{
				//$order_array = call_user_func_array('array_merge', $order_array);
				//echo json_encode($order_array);exit;
				$insert_response = $this->dbo->insertMany('masters','orders',$order_array);
			}
			if(isset($workorder_array) and !empty($workorder_array))
			{
				//$workorder_array = call_user_func_array('array_merge', $workorder_array);
				//echo json_encode($workorder_array);exit;
				$insert_response = $this->dbo->insertMany('masters','workorders',$workorder_array);
			}
			if(isset($orderlog_array) and !empty($orderlog_array))
			{
				//$orderlog_array = call_user_func_array('array_merge', $orderlog_array);
				//echo json_encode($orderlog_array);exit;
				$insert_response = $this->dbo->insertMany('masters','orderlog',$orderlog_array);
			}
			
			
			//STRUCTURING RESPONSE
			if((empty($order_ids) or $order_ids==null) and 
								(empty($appointment_ids) or $appointment_ids==null))
			{
				$autoResponse = array("status"=>"0","message"=>"Child orders creation failed");
				
				$this->log->create_log("","","package","Execution",200,"autoOrder_issue",json_encode($autoResponse),(string)$ticket);
				
				return $autoResponse;
				
			}
			
			//INTO A 1-D ARRAY
			$order_ids = call_user_func_array('array_merge', $order_ids);
			$appointment_ids = call_user_func_array('array_merge', $appointment_ids);
			
			$autoResponse = array("status"=>"1","message"=>"Child orders created","orderIds"=>$order_ids);
			//,"appointmentIds"=> $appointment_ids);
			
			$this->log->create_log("","","package","Execution",200,"autoOrder_issue",json_encode($autoResponse),(string)$ticket);
			
			return $autoResponse;
		}
		
		catch(Exception $e)
		{
			$response = array("status"=>"0","message"=>"Error: ".$e->getMessage());
			
			$this->log->create_log("","","package","Execution",300,"autoOrder_error",json_encode($autoResponse),(string)$ticket);
			
			return $autoResponse;
		}			
	}
	
	
	function createPackageChildOrders($payload,$ticket)
	{
		$this->log->create_log("","","package","Execution",200,"createPackageChildOrders_start",json_encode($payload),(string)$ticket);
		
		try
		{
			$order_id = (int)$payload->order_id;
			
			
			//CREATE AUTO ORDERS
			$filter = array("_id" => $order_id);
			$project = array("order"=>1,"active_component"=>1,"wid"=>1,"wodid"=>1);
			
			$cursor = $this->dbo->findOne('masters','orders',$filter,$project);
			//print_r($cursor['order']['autoOrder']);exit;
			
			if(empty($cursor) or $cursor == null)
			{
				$response = array("status"=>"0","message"=>"Parent Order Not Found");
				$this->log->create_log("","","package","Execution",200,"createPackageChildOrders_end",json_encode($response),(string)$ticket);
				return $response;
			}
			
			$autoPayload = $cursor['order']['autoOrder'];
			
			$pkgCode = $autoPayload['packageCode'];
			$startDate  = $autoPayload['startDate'];
			$package_parent_id = $autoPayload['package_parent_id'];
			$orderPayload = $autoPayload['orderPayload'];
			$transactionCode = $autoPayload['transactionCode'];
			
			try
			{
				$response['autoOrder'] = $this->autoOrder($pkgCode,$startDate,$package_parent_id,$orderPayload,$transaction_code);
			}
			catch(Exception $e)
			{
				$response = array("status"=>"0","message"=>"autoOrder Error: ".$e->getMessage());
			
				$this->log->create_log("","","package","Execution",300,"createPackageChildOrders_error",json_encode($response),(string)$ticket);
				
				return $response;
			}
			
			if($response['autoOrder']['status'] == '1')
			{
				//CHANGE THE ORDER STATUS, WO STATUS TO 6 AS PAYMENT FOR PACKAGE IS DONE
				///
				$ordinfo = new Orderinfo;
				
				$ordinfo->changestatus("6", $order_id, "Transaction Completed" , "Wellness Package Payment Done", "");
				
				$order_details = array();
				foreach($cursor['order']['provider_info'] as $provider)
				{
					if($cursor['active_component'] == $provider['component_no'])
					{
						$order_details['associate_id'] = $provider['associate_id'];
						$order_details['associate_branch_id'] = $provider['associate_branch_id'];
						$order_details['component_no'] = $provider['component_no'];
						$order_details['role'] = $provider['role'];
						$order_details['skill'] = $provider['skill'];
					}
				}	
				$order_details['reason'] = "Transaction Completed";
				$current_w_id = $cursor['wid'];
				$current_w_did = $cursor['wodid'];
				$userid = $cursor['order']['patientinfo']['mrn'];
				$username = $cursor['order']['patientinfo']['name'];
				
				$ordinfo->changeWoStatus("6", $order_id, $order_details, $current_w_id,"", "");
				
				$ordinfo->createlog($role, "6", "Transaction Completed", $userid, $username, "Wellness Package Payment Done", $current_w_id, $current_w_did, $order_id, "","","","", $extraFields = array(),false,"");
				///
				
				$this->log->create_log("","","package","Execution",200,"createPackageChildOrders_end",json_encode($response),(string)$ticket);
				
				$response['changestatus'] =  "Order Status Updated";
				
				//CHILD ORDER ALLOCATIONS THROUGH CHISS
				try
				{
					$welorder = array("order_id"=>(int)$order_id);
					//FUNCTION CALL
					$ordinfo = new Orderinfo;
					$chiss_resp = $ordinfo->chiss_wellness_creation((object)$welorder,$ticket);
					$response['chiss_wellness_response'] =  $chiss_resp;
				}
				catch(Exception $e)
				{
					$response = array("ChissWellnessError"=>$e->getMessage());
					$logobj->create_log("","",getname(),"Execution",300,"createPackageChildOrders_Error",json_encode($response),(string)$ticket);
					
					return $response;
				}
			}
			else
			{
				$response['changestatus'] =  "Status not updated";
				$response['chiss_wellness_response'] = array();
			}	
				
			return $response;
		}
		catch(Exception $e)
		{
			$response = array("status"=>"0","message"=>"Error: ".$e->getMessage());
			
			$this->log->create_log("","","package","Execution",300,"createPackageChildOrders_error",json_encode($response),(string)$ticket);
			
			return $response;
		}			
	}
	
	public function cancel_wellness_order($payload,$ticket)
	{
		
		$orderinfo = new Orderinfo;

		$endTime = time() + (330 * 60) - 900; //(7*60) is the offset to merge system time with server time
		//print_r($endTime);exit;
		$mongoDate  = $this->dbo->date($endTime); // new MongoDate($endTime); //This is the time which we are getting after subtracting 15mins.
        //print_r($mongoDate->toDateTime()->format("Y-m-d H:i:s"));exit;
		$filter = array(
			"order.order_status.order_date" => array(
				'$lte'=> $mongoDate,//->toDateTime()->format("Y-m-d H:i:s")
			),
			"OStatus"=>17,
			"order.patientinfo.service_type"=>"14",	
		);
		//echo json_encode($filter);exit;

		$resultOrder = $this->dbo->find("masters","orders",$filter,array(),array(),array());
		//echo json_encode($resultOrder);exit;

		if(empty($resultOrder))
		{
			$response = array("status"=>0,"message"=>"No order is eligible for cancellation");
			return $response;
		}
		//print_r($resultOrder);exit;
		$orderIds = array();

		foreach($resultOrder as $order)
		{
			$orderIds[] = $order['_id'];
			$response = $orderinfo->changestatus("8",$order['_id'],"wellness cancellation","wellness order cancellation after 15mins",
			"" , "" , $order['orderitem']);
		}

/*
		$cancel_api_payload = (object)array(
			"order_id" => $orderIds,
			"source"=>2,
			"categoryId"=>"1",
			"subCategoryId" => "3",
			"reason" => "package order auto cancellation after 15mins."
		);

		//print_r($cancel_api_payload);exit;
		$orderinfo = new Orderinfo;
		$response = $orderinfo->order_cancel($cancel_api_payload);*/
		$this->log->create_log("","","package","Execution",300,"cancel_wellness_order",json_encode($orderIds)."cancelled",(string)$ticket);
		return $response;

	}
	
	
	
	}
	
	
	?>