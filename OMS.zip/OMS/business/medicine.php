<?php

class Medicine extends Oms
{
	public function __construct()
    {
        parent::__construct();
    }
    public function createOrder($patientinfo_obj, $orderstatus_obj, $payload, $business_obj)
    {
		$associate['component_no']="9";
		$associate_info=array();
		array_push($associate_info,$associate);
		
		$business=$payload['business'];
		$items = $payload['orderitem'];
		
		if(isset($payload['business']->prescription_images))
		{
			$prescription_images = $payload['business']->prescription_images;
		}
		else
		{
			$prescription_images = array();
		}
		
		if(isset($business->associate_id) and $business->associate_id != null)
		{
			$vendorid = $business->associate_id;
			$vendorinfo = $this->getVendorDetails($vendorid);
			$vendorinfo[vendor_assigned_date] = date("Y-m-d H:i:s");
		}
		else
		{
			//IF NO VENDOR MENTIONED
			$vendorinfo[associate_id] = "";
			$vendorinfo[associate_name] = "";
			$vendorinfo[associate_address] = "";
			$vendorinfo[associate_branch_id] = "";
			$vendorinfo[associate_branch_name] = "";
		}
		
		
		if(!empty($business_obj) and $business_obj!= "")
		{
			$business_field = $business_obj;
		}
		else
		{
			$business_field = array();
		}
		
        $order = array("patientinfo" => $patientinfo_obj, "order_status" => $orderstatus_obj, "orderitem" => $items, "vendorinfo"=>$vendorinfo, "provider_info" => $associate_info, "prescription_images" => $prescription_images,"business"=>$business_field);
        return ($order);
        //exit;
    }
	
	
	public function getVendorDetails($vendorid)
	{
		$dbo = new Dbo;
		
		$filter = array("_id"=>$vendorid);
		$project = array("userinfo"=>1);
		
		$vendorcursor = $dbo->findOne('masters','medicine_vendors',$filter,$project);
		
		//print_r($vendorcursor);exit;
		$vendorinfo = array();
		
		$vendorinfo[associate_id] = $vendorcursor[userinfo][USER_ID];
		$vendorinfo[associate_name] = $vendorcursor[userinfo][USER_NAME];
		$vendorinfo[associate_address] = $vendorcursor[userinfo][ADDRESS];
		$vendorinfo[associate_branch_id] = $vendorcursor[userinfo][USER_Branch_ID];
		$vendorinfo[associate_branch_name] = $vendorcursor[userinfo][USER_Branch_NAME];
		//$vendorinfo[vendorassign_datetime] = ;
		
		return $vendorinfo;
	}
	
	public function returnOrderChanges($reference_order_id, $return_order_items)
	{
		//$dbo = new Dbo;
		
		$filter = array("_id"=>$reference_order_id);
		$cursor = $this->dbo->findOne("masters","orders",$filter,array());
		//print_R($cursor);exit;
		if(empty($cursor) or $cursor == "")
		{
			$response = array("response"=>0,"message"=>"Cannot Return the order, reference order not found");
			return $response;
		}
		
		
		//GET PROVIDER/VENDOR DETAILS FROM REFERENCE ORDER
		$associate = "";
		$branch = "";
		$providerInfo = $cursor['order']['provider_info'];
		foreach($providerInfo as $provider)
		{
			if($provider[component_no] == "9")
			{
				$associate = $provider[associate_id];
				$branch = $provider[associate_branch_id];
			}
		}
		
		$orderitem = $cursor['order']['orderitem'];
		
		foreach($return_order_items as $item)
		{
			$returnItem = $item->item_code;
			$returnQuantity = (int)$item->quantity;
			
			//CORRECT LOGIC IF QUANTITY IS INTEGER IN DB(ORDERS)
			//$set = array("order.orderitem.returnQuantity"=>$returnQuantity);
			//$updOptions = array('$inc'=>array("order.orderitem.quantity"=>-1*$returnQuantity));
			//$this->dbo->update("masters","orders",$filter,$set,array(),array(),$updOptions);
			
			for($i=0;$i<count($orderitem);$i++)
			{
				if($orderitem[$i]['item_code'] == $returnItem)
				{
					$orderitem[$i]['quantity'] = (int)$orderitem[$i]['quantity'] - $returnQuantity;
					$orderitem[$i]['returnQuantity'] = $returnQuantity;
				}
			}
		}
		
		//$cursor['order']['orderitem'] = $orderitem;
		//print_R($cursor);exit;
		
		$set = array("order.orderitem"=>$orderitem);
		$updCursor = $this->dbo->update('masters','orders',$filter,$set,array(),array());
		
		if($updCursor['nModified'] == 0)
		{
			$response = array("response"=>0,"message"=>"Cannot Return the order, Try again");
		}
		else
		{
			$response = array("response"=>1,"message"=>"Reference order updated","associate"=>$associate,"branch"=>$branch);
		}
		return $response;
	}

	
	
}
