<?php 

class Mediequipment extends Oms {
	
	public function __construct()
    {
        parent::__construct();
    }
	
	public function createOrder($patientinfo_obj,$orderstatus_obj,$payload){ 
		//print_r($payload);exit;
		
		$associate['component_no']="9";
		$associate_info=array();
		array_push($associate_info,$associate);
		
		$business=$payload['business'];
		$items = $payload['orderitem'];
		
		$vendorid = $business->associate_id;
		$vendorinfo = $this->getVendorDetails($vendorid);
		//print_r($vendorinfo);exit;
		
		$order=array("patientinfo"=>$patientinfo_obj,"order_status"=>$orderstatus_obj,"orderitem"=>$items,"vendorinfo"=>$vendorinfo,"provider_info"=>$associate_info,"prescription_file"=>array());
		return ($order);
		//exit;
	}
	
	public function getVendorDetails($vendorid)
	{
		$dbo = new Dbo;
		
		$filter = array("_id"=>$vendorid);
		$project = array("userinfo"=>1);
		
		$vendorcursor = $dbo->findOne('masters','mequipment_vendors',$filter,$project);
		
		//print_r($vendorcursor);exit;
		$vendorinfo = array();
		
		$vendorinfo[associate_id] = $vendorcursor[userinfo][USER_ID];
		$vendorinfo[associate_name] = $vendorcursor[userinfo][USER_NAME];
		$vendorinfo[associate_address] = $vendorcursor[userinfo][ADDRESS];
		$vendorinfo[associate_branch_id] = $vendorcursor[userinfo][USER_Branch_ID];
		$vendorinfo[associate_branch_name] = $vendorcursor[userinfo][USER_Branch_NAME];
		//$vendorinfo[vendorassign_datetime] = ;
		
		return $vendorinfo;
	}
}

?>