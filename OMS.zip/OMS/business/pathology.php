<?php
require_once './../libraries/mypdf.php';

class Pathology extends Oms 
{ 

    public function createOrder($associate, $patientinfo_obj, $orderstatus_obj, $payload, $business_obj)
    {
        //print_r($payload);
        $associate['component_no'] = "7";
        $associate_info = array();
        array_push($associate_info, $associate);
        $items = $payload['orderitem'];
		if(empty($business_obj))
		{
			$business_obj=(object)$business_obj;
		}
        $order = array("patientinfo" => $patientinfo_obj, "ordertype" => "lab", "order_status" => $orderstatus_obj, "orderitem" => $items, "provider_info" => $associate_info,"business"=>$business_obj);
        return ($order);
        //exit;
    }
	
	
        public function sampletypearray(){
            $sampletypearray = array(
                "26"=>"Urethral Discharge",
                "27"=>"Wound Swab",
                "28"=>"Swab",
                "29"=>"Body fluid",
                "30"=>"Serum/Plasma/Whole Blood",
                "31"=>"Blood",
                "32"=>"Blood, Urine",
                "33"=>"Blood, Urine, Stool",
                "18"=>"Peritoneal fluid",
                "19"=>"Pleural Fluid",
                "20"=>"Pus",
                "21"=>"Semen",
                "22"=>"Serum/Plasma-Fluoride",
                "23"=>"Skin Scrapings",
                "24"=>"Skin Tissue",
                "25"=>"Synovial Fluid",
                "10"=>"Serum, Plasma & Urine",
                "11"=>"Stool",
                "12"=>"Ascitic Fluid",
                "13"=>"Ear swab",
                "14"=>"Hair",
                "15"=>"Lancet prick-Blood Drop",
                "16"=>"Nail / nail scraping",
                "17"=>"Pericardial Fluid",
                "2"=>"Urine",
                "3"=>"Whole Blood",
                "4"=>"Citrated plasma",
                "5"=>"Plasma",
                "6"=>"Sputum",
                "7"=>"Saliva",
                "8"=>"Serum & Urine",
                "9"=>"Serum & Plasma",
                "1"=>"Serum"
                
            );
            return $sampletypearray;
        } 
	public function sampleCollectionMemo($orderid, $action = "Download"){
		date_default_timezone_set('Asia/Kolkata');
		$mdmobj = new Mdm;
		$payload['method'] = "fetchservice/entity";
		$payload['type'] =  "post";
		$payload['entity'] = "sampleType";
		$payload['colNames'] = "sampleID";
		
        if (isset($orderid) && $orderid != ""){
            $project = array(
                "_id" => 1,
                "order.patientinfo.age"=>1,
                "order.patientinfo.mrn"=>1,
                "order.patientinfo.gender"=>1,
                "order.patientinfo.name" => 1,
                "order.patientinfo.barcode.barcode"=>1,
                "order.patientinfo.barcode.sampleType"=>1,
                "order.patientinfo.totalSamplesSubmitted"=>1,
                "assaigned_to"=>1,
                "order.patientinfo.sample_submitted_by_phelp_date"=>1,
                "order.order_status.mhoname" => 1,
                "order.provider_info" => 1,
                "odid" => 1,
                "order.orderitem" => 1
            );
            $filter = array("_id" => (int) $orderid);
            $gender="";
            $noofSamples=0;
            $orderdetails = $this->dbo->findOne('masters', 'orders', $filter, $project);
			//print_r($orderdetails);exit;
			
			if(!isset($orderdetails[order])){
			   return "Wrong order id";
			}
			
			if($orderdetails[order][patientinfo][gender]=="1"){
			   $gender="Female";
			}else{
			   $gender="Male";
			}
			$ahealp_associate_name = "NA";			
			if(isset($orderdetails[order][provider_info][0])){
				foreach($orderdetails[order][provider_info] as $each_associate){
					if($each_associate[component_no]=="7"){
						$ahealp_associate_name=trim($each_associate[associate_name]);
					}
				}
			}
			
			
			if(isset($orderdetails[order][patientinfo][barcode][sampleType])){
				foreach($orderdetails[order][patientinfo][barcode][sampleType] as $sampletype){
					if($sampletype !="0"){
					   $noofSamples++;
					}
				}			  
			}
			$Deposited="Na";
			if(isset($orderdetails[order][patientinfo][sample_submitted_by_phelp_date])){
                            
                                    
				if(isset($orderdetails[order][patientinfo][sample_submitted_by_phelp_date]->sec)){
					$Deposited = date('Y-m-d H:i:s', $orderdetails[order][patientinfo][sample_submitted_by_phelp_date]->sec -19800);
				}else if($orderdetails[order][patientinfo][sample_submitted_by_phelp_date]==""){
					$Deposited = str_replace(".000Z","",$orderdetails[order][patientinfo][sample_submitted_by_phelp_date]);
				}
			}
			
			$pdf = new MYPDF_forSampleCollection(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'ISO-8859-1', false);
			$pdf->SetCreator(PDF_CREATOR);
			$pdf->SetAuthor('Callhealth');
			$pdf->SetTitle('SampleCollection Memo');
			$pdf->setPrintHeader(true);
			$pdf->setPrintFooter(true);
			$pdf->SetMargins(5, 36, 5);
			$pdf->SetAutoPageBreak(true, 45);
			$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
			$pdf->setLanguageArray($l);
			$pdf->AddPage();
			
			$customer_name = ucfirst(trim($orderdetails[order][patientinfo][name]));
                
            $html = '<table style="width:100%">
				<tr>
				  <td><span style="text-align:center; font-weight:bold; text-decoration:""; font-size:40px;">TEST REQUEST FORM</span></td>
				  <br>
			   </tr>
			   <br><br><br>
			   <tr>
				  <td style="width:45%">
					 <table width="70%" cellpadding="0" border="0">
						<tr>
						   <td><br><span><b>Name</b>   :    '.$customer_name.'</span><br></td>
						</tr>
                                                <tr>
						   <td><br><span ><b>MRN</b>   :   '.trim($orderdetails[order][patientinfo][mrn]).'</span><br></td>
						</tr>
						<tr>
						   <td><br><span ><b>Gender</b>   :  '.$gender.'</span><br></td>
						</tr>
						<tr>
						   <td><br><span ><b>No.of Samples</b>   :   '.$noofSamples.'</span><br></td>
						</tr>
						<tr>
						   <td><br><span ><b>MHO Name</b>   :   '.trim($orderdetails[order][order_status][mhoname]).'</span><br></td>
						</tr>
						<tr>
						   <td><br><span ><b>Deposited By</b>   : '.trim($orderdetails[assaigned_to]).'</span><br></td>
						</tr>
						<tr>
						   <td><br><span ><b>Laboratory Name</b>   :  '.trim($ahealp_associate_name).'</span><br></td>
						</tr>
					 </table>
				  </td>
				  <td style="width:85%">
					 <table  cellpadding="0" border="0">
						<tr>
						   <td><br><span><b>Age</b>  :  '.$orderdetails[order][patientinfo][age].'Y</span><br></td>
						</tr>
						<tr>
						   <td><br><span><b>DO No  :</b>  '.$orderdetails[odid].'</span><br></td>
						</tr>
						<tr>
						   <td><br><span><b>Barcode</b>   :  '.$orderdetails[order][patientinfo][barcode][barcode][0].'</span><br></td>
						</tr>
						<tr>
						   <td><br><span><b>Deposited Date</b>  :  '.$Deposited.'</span><br></td>
						</tr>
					 </table>
				  </td>
			   </tr>
			   <tr>
				  <td align="center"style="width:100%">
					 <table width="100%" border="1" cellspacing="0" cellpadding="0" class="conten_tabler">
						<tr>
						   <th height="20" style="font-weight: bold;">Test Name</th>
						   <th height="20" style="font-weight: bold;">Sample Type</th>
						</tr>';
						//print_r($orderdetails[order][orderitem]); exit;
						foreach ($orderdetails[order][orderitem] as $item) {
							if($item[item_status] != "8" && $item['component_no'] == "7"){
							//if($item[item_status] != "8"){
								$samplevalue = isset($item[sampleType])?$item[sampleType]:"";
								$payload['colValues'] = (string)trim($samplevalue);
								$samplename=" ";
								if($samplevalue!=""){									
									$result = $mdmobj->fetchservice($payload);
									if($result["status"]==1 && isset($result["data"][0])){
										$samplename =(string) isset($result["data"][0]["name"])?trim($result["data"][0]["name"]):" ";
									}
								}else{
									$samplename = " "; //[data][0][name]
								}
							    $html = $html .'<tr>
								<td height="20" align="center">'.$item[itemname].'</td>
								<td height="20">'.$samplename.'</td>
								</tr>';
							}
						}					
						$html = $html .'  </table>
				  </td>
			   </tr>
			   <tr><td colspan="2" style="font-weight:bold;">*All tests are mandatory unless stated otherwise.</td></tr>
			</table>';
			// print_r($html);exit;
			$pdf->writeHTML($html, true, 0, true, 0);
			$invnum = 'SampleCollection_memo_' . $orderid . '.pdf';
			$pdf->Output($invnum, 'D');            
        }
    }
}
