<?php

if (!function_exists('async_curl_post_json')) {
    /**
     * Used to make async curl post request Only
     * @params url, $param:Must be JSON encoded
     * @return true | false
     */
    // Usage:=> Method: must be POST, $param:Must be JSON encoded
    function async_curl_post_json($url, $param)
    {
        // post method for json data
        $check_ssl = false;
        $cmd = "curl --header 'Content-Type: application/json' --request POST --data '" . $param . "' '" . $url . "'";
        if (!$check_ssl) {
            $cmd .= " --insecure"; // this can speed things up, though it's not secure
        }
        $cmd .= " > /dev/null 2>&1 &"; //just dismiss the response
        exec($cmd, $output, $exit);
        return $exit == 0;
    }
}

if (!function_exists('create_access_log')) {
/**
 * Create access log and store in log database
 *
 * Returns null
 *
 * @return null
 */
    function create_access_log()
    {
        if (!ENABLE_ACCESS_LOG) {
            return 0;
        }

        $url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER["REQUEST_URI"];
        $req = $_REQUEST;
        if (empty($_REQUEST)) {
            $req = json_decode(file_get_contents('php://input'), true);
        }
        $log = array(
            "ip" => $_SERVER['REMOTE_ADDR'],
            "env" => ENV_MODE,
            "method" => $_SERVER['REQUEST_METHOD'],
            "response_code" => http_response_code(),
            "dt" => date('Y-m-d H:i:s'),
            "url" => $url,
            "request" => json_encode($req),
            "user_agent" => $_SERVER['HTTP_USER_AGENT'],
        );
        //echo json_encode($log); die;
        async_curl_post_json(LOGGER_PATH . 'api/v3/log/access-log', json_encode($log));
    }
}

if (!function_exists('create_debug_log')) {
    /**
     * Create debug log and store in log database
     *
     * Usases => create_debug_log(2345678, 45678, 'Step 1: inner loop', $data = Obj/Arr/ )
     *
     * @return null
     */
    function create_debug_log($order_id, $breakpoint, $data, $filename = null)
    {
        if (!ENABLE_DEBUG) {
            return 0;
        }

        //START_TM contain start time
        if (!empty($filename)) {
            $filename = basename($filename);
        }
        $log = array(
            "trace_id" => TRACE_ID,
            "order_id" => $order_id,
            "env" => ENV_MODE,
            "breakpoint" => (String) $breakpoint,
            "data" => json_encode($data),
            "dt" => date('Y-m-d H:i:s'),
            "elapsed_time" => number_format(microtime(true) - START_TM, 4),
            "filename" => $filename,
        );
        //echo json_encode($log); die;
        async_curl_post_json(LOGGER_PATH . 'api/v3/log/debug-log', json_encode($log));
    }
}
