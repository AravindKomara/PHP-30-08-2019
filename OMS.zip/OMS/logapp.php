<?php
class Logapp
{

    /**
     *
     * 1. DEBUG (100): Detailed debug information.
     *
     * 2. INFO (200): Interesting events. Examples: User logs in, SQL logs.
     *
     * 3. NOTICE (250): Normal but significant events.
     *
     * 4. WARNING (300): Exceptional occurrences that are not errors. Examples: Use of deprecated APIs, poor use of an API, undesirable things that are not necessarily wrong.
     *
     * 5. ERROR (400): Runtime errors that do not require immediate action but should typically be logged and monitored.
     *
     * 6. CRITICAL (500): Critical conditions. Example: Application component unavailable, unexpected exception.
     *
     * 7. ALERT (550): Action must be taken immediately. Example: Entire website down, database unavailable, etc. This should trigger the SMS alerts and wake you up.
     *
     * 8. EMERGENCY (600): Emergency: system is unusable.
     *
     *
     */

    public function create_log($ip, $path, $file, $process, $type, $stage, $message, $ticket)
    {
		// add to debugger
        create_debug_log(0, $stage, $message);
		
        $user_info = ['ip' => $ip, 'path' => $path, 'message' => $message, "ticket" => $ticket];
        //$dir = '/var/www/html/OMS/logs/';
        //$dir = '../logs/';
		$config=new Config;
        $dir = $config->getconfig("logpath","");
        $severity = "";
        if ($type > 300) {$severity = "-error-";}
        $file = $dir . $file . '-' . $severity . date('Y-m-d') . '.log';
		//echo $dir;exit; 
        $dateFormat = "Y n j, g:i a";
        // finally, create a formatter
        $formatter = new Monolog\Formatter\JsonFormatter($dateFormat);

        /* $output = "%datetime% > %level_name% > %message% %context% %extra%\n";
        $formatter = new Monolog\Formatter\LineFormatter($output, $dateFormat);  */

        // Create a handler

        $stream = new Monolog\Handler\StreamHandler($file, Monolog\Logger::INFO);

        $stream->setFormatter($formatter);

        // bind it to a logger object
        $dataLogger = new Monolog\Logger($process);
        $dataLogger->pushHandler($stream);
        switch ($type) {
            case 100:
                $dataLogger->addDebug($stage, $user_info);
                break;
            case 200:
                $dataLogger->addInfo($stage, $user_info);
                break;
            case 250:
                $dataLogger->addNotice($stage, $user_info);
                break;
            case 300:
                $dataLogger->addWarning($stage, $user_info);
                break;
            case 400:
                $dataLogger->addError($stage, $user_info);
                break;
            case 500:
                $dataLogger->addCritical($stage, $user_info);
                break;
            case 550:
                $dataLogger->addAlert($stage, $user_info);
                break;
            case 600:
                $dataLogger->addEmergency($stage, $user_info);
                break;
            default:

        }

    }

    public function logThirdPartyCall($ThirdPartyName, $url, $startTime, $payload, $response, $requestType = 'SERIAL', $method = "POST")
    {
        $timeTaken = number_format(microtime(true) - $startTime, 4);
        $log = date('Y-m-d H:i:s') . ' ' . $ThirdPartyName . ' ' . $url . ' ' . $timeTaken . ' ' . json_encode($payload) . ' ' . json_encode($response) . PHP_EOL;
        $postArr = array(
            "env" => defined('ENV_MODE') ? ENV_MODE : 'CUSTOM',
            "party" => $ThirdPartyName,
            "requestType" => $requestType, //SERIAL, ASYNC
            "method" => $method,
            "logged_on" => date('Y-m-d H:i:s'),
            "endpoint" => $url,
            "elapsed_time" => $timeTaken,
            "input_payload" => json_encode($payload),
            "output_response" => json_encode($response),
        );
        async_curl_post_json(LOGGER_PATH . 'api/v3/log/third-party-api-call', json_encode($postArr));
    }


}
