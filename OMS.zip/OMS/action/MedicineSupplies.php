<?php 
/* include '../dbo.php';
include '../utility.php'; */
ini_set('memory_limit', '-1');
//require_once "OrderWorkFlow.php";

class MedicineSupplies extends Oms
{

    public function __construct()
    {
        parent::__construct();
    }

    public function getname()
    {
        return "MedicineSupplies";
    }

    public function DrugListLoad($payload)
    {
        $mdm = new Mdm;
        $brandname = $payload->brandname;
        $filtercolumn = $payload->filtercolumn;
        $listid = isset($payload->listid) ? $payload->listid : "";
        if ($payload->entitytype == "medicine") {
            $entitytype = "medicineUI";
        } else {
            $entitytype = "equipmentRentalsUI";
        }
        $req_data = array(
            "method" => "fetchservice/entity",
            "type" => "post",
            "entity" => $entitytype,
            "search" => "true",
            "source" => "CCO",
            "colNames" => $filtercolumn,
            "colValues" => $brandname,
        );
        $result = $mdm->fetchservice($req_data);
        if (trim($listid) != "") {
            $result["listid"] = $listid;
        }
        return $result;
    }

    public function getAllCounts($payload)
    {
        //$dbo = new Dbo;
        //$utility = new Utility;

        $field_array['l2pharma'] = ['all_orders', 'rx_pending', 'prescription_upload',
            'assignvendororders', 'tobeassigned', 'rejected', 'rx_not_upload','return'
        ];
        $field_array['equipment'] = ['all_orders', 'assignvendororders', 'tobeassigned', 'rejected'];

        $field_array['pharmacist'] = ['all_orders', 'requested_pickup', 'tobeconfirmed', 'completed', 'rejected','return'];

        $field_array['eqvendor'] = ['all_orders', 'requested_pickup', 'tobeconfirmed', 'completed', 'rejected'];

        $filt_array = array();

        foreach ($field_array[$payload->type] as $method) {
            $filter = array();

            //print_r($payload);exit;
            $date_required = "1";

            $searchdatetype = "order.order_status.created_date"; //BY DEFAULT
            if ($payload->dateType == "scheduled_date") {
                $searchdatetype = "order.patientinfo.scheduled_date";
            }

            //V3 ORDERS ONLY
            $filter['transaction_code'] = array('$exists' => true);

            if ($payload->type == 'l2pharma' or $payload->type == 'pharmacist') {
                //By default only for Drug orders
                $filter["order.patientinfo.service_type"] = '2';
            } else if ($payload->type == 'equipment' or $payload->type == 'eqvendor') {
                //By default only for Drug orders
                $filter["order.patientinfo.service_type"] = '11';
            }

            if ($payload->type == 'l2pharma' or $payload->type == 'equipment') {
                if (isset($payload->vendorid) and trim($payload->vendorid) != "") {
                    $filter['order.provider_info.associate_id'] = (string) trim($payload->vendorid);
                }

                if (isset($payload->orderidser) && $payload->orderidser != '') {
                    $filter["_id"] = (int) $payload->orderidser;
                } else {

                    if (isset($payload->city) && $payload->city != '') {
                        $filter["order.patientinfo.city"] = $payload->city;
                    }

                    //Validating date_required
                    if ($date_required == "1" || count($filter) < 1) {
                        //$searchdatetype = "order.order_status.created_date";

                        $necessary_project[$searchdatetype] = 1;

                        if ($payload->method != 'rx_not_upload' and $method != 'rx_not_upload') {
                            if (isset($payload->formdate) && isset($payload->todate) && $payload->formdate != "" && $payload->todate != "") {
                                $end_date = date('Y-m-d', strtotime('+1 days', strtotime($payload->todate)));
                                $filter[$searchdatetype] = array('$gte' => $payload->formdate, '$lt' => $end_date);

                            }
                        }

                        //date filter for rx_not_upload
                        else {
                            $filter["order.order_status.created_date"] = array('$lte' => date('Y-m-d h:m:s', strtotime('-48 hours')));
                        }
                    }

                }
            } else if ($payload->type == 'pharmacist' or $payload->type == 'eqvendor') {
                //Vendor logic
                $filter['order.provider_info.associate_id'] = $payload->vendorid;
            }
			
			//Return order
			if ($payload->type == 'l2pharma' or $payload->type == 'pharmacist') 
			{
				if (isset($method) and ($method == 'return'))
				{
					$filter['order.business.is_return_order'] = 1;
				}	
			}	

            //PRESCRIPTION CASE ONLY IN THE CASE OF L2PHARMA
            if ($payload->type == 'l2pharma') {
                //Getting prescription_later value for filter
                if (isset($method) and ($method == 'rx_not_upload' or $method == 'rx_pending')) {

                    $filter['order.patientinfo.prescription_later'] = "1";
                } else if (isset($method) and $method == 'prescription_upload') {
                    $filter['order.patientinfo.prescription_later'] = "0";
                }
            }

            //Getting OStatus value for filter

            //IN CASE OF EQUIPMENT,L2PHARMA
            if ($method == 'assignvendororders' or $method == 'tobeconfirmed') {
                $filter['OStatus'] = 21;
            } else if ($method == 'tobeassigned') {
                $filter['OStatus'] = 1000;
            }

            //IN CASE OF EQUIPMENT,L2PHARMA,EQVENDOR,PHARMACIST
            else if ($method == 'rejected') {
                $filter['OStatus'] = 24;
            }

            //IN CASE OF L2PHARMA ONLY
            else if (in_array($method, ['rx_not_upload', 'rx_pending', 'prescription_upload'])) {
                $filter['OStatus'] = 1001;
            }

            //else if($method == 'prescription_upload')
            //{
            //    $filter['OStatus'] = 1001;
            //}

            //IN CASE OF EQVENDOR,PHARMACIST
            else if ($method == 'completed') {
                $filter['OStatus'] = 6;
            } else if ($method == 'requested_pickup') {
                $filter['OStatus'] = array('$in' => array(18, 0));
            }

            $filt_array[$method] = $filter;
        }
        //echo json_encode($filt_array);exit;

        foreach ($filt_array as $key => $value) {
            $total[$key] = $this->dbo->countitem('masters', 'orders', $value);
        }
        return $total;
    }

    public function getmedordersbyfilter($payload)
    {
        //print_r($payload);exit;
        $project = array(
            "_id" => 1,
            "transaction_code" => 1,
            "channel" => 1,
            "did" => 1,
            "odid" => 1,
            "wodid" => 1,
            "OStatus" => 1,
            "order.patientinfo.mrn" => 1,
            "order.patientinfo.age" => 1,
            "order.patientinfo.gender" => 1,
            "order.patientinfo.city" => 1,
            "order.patientinfo.expected_delivery_time" => 1,
            "order.patientinfo.prepaid" => 1,
            "order.patientinfo.address" => 1,
            "order.patientinfo.pincode" => 1,
            "order.patientinfo.contact" => 1,
            "order.patientinfo.name" => 1,
            "order.patientinfo.service_type" => 1,
            "order.patientinfo.role_id" => 1,
            "order.patientinfo.skill_id" => 1,
            "order.patientinfo.delivery_lat" => 1,
            "order.patientinfo.delivery_lng" => 1,
            "order.patientinfo.scheduled_date" => 1,
            "order.patientinfo.gross_amount" => 1,
            "order.patientinfo.discount_amount" => 1,
            "order.patientinfo.net_amount" => 1,
            "order.patientinfo.wallet_amount" => 1,
            "order.patientinfo.voucher_amount" => 1,
            "order.patientinfo.coupon_amount" => 1,
            "order.patientinfo.surge_amount" => 1,
            "order.patientinfo.payment_amount" => 1,
            "order.order_status.created_date" => 1,
            "order.order_status.mhoname" => 1,
            "order.order_status.receipts_tracker_id" => 1,
            "order.provider_info" => 1,
            "payment_info" => 1,
            "order.orderitem" => 1,
            "order.prescription_file" => 1,
            "billing.billing_did" => 1,
            "order.ordertype" => 1,
            "order.ordertyp" => 1,
            "order.patientinfo.patient_id" => 1,
            "order.patientinfo.gender_pref" => 1,
            "order.patientinfo.istransactioncare" => 1,
            "order.patientinfo.landmark" => 1,
            "order.patientinfo.corporatename" => 1,
            "order.patientinfo.expected_delivery_date" => 1,
            "order.vendorinfo" => 1,
        );

        $utilityobj = new Utility;
        //$dbo_obj = new Dbo;
        $date_required = "0";
        $error_message = array();
        $necessary_project = array();
        $sort1 = array();
        $sort = "_id";
        $responce = array("status" => 0, "message" => "Data not found", "data" => array());

        if (!isset($payload->method) or $payload->method == null) {
            $responce["message"] = "Invalid Method";
            return $responce;
        }

        //Validate TYPE and corresponding filter actions
        //for 'l2pharma','pharmacist','equipment','eqvendor'
        if (isset($payload->type) and in_array($payload->type, ['l2pharma', 'pharmacist', 'equipment', 'eqvendor'])) {
            //print_r($payload);exit;
            $date_required = "1";

            $searchdatetype = "order.order_status.created_date"; //BY DEFAULT
            if ($payload->dateType == "scheduled_date") {
                $searchdatetype = "order.patientinfo.scheduled_date";
            }

            $sort = $searchdatetype; //SORT BY DATE TYPE

            if ($payload->type == 'l2pharma' or $payload->type == 'pharmacist') {
                //By default only for Drug orders
                $filter["order.patientinfo.service_type"] = '2';
            } else if ($payload->type == 'equipment' or $payload->type == 'eqvendor') {
                //By default only for Equipment orders
                $filter["order.patientinfo.service_type"] = '11';
            }

            //NOT REQUIRED FOR NOW
            //date search doesn't required for meqvendor
            //if (isset($payload->type) && $payload->type == "eqvendor")
            //{
            //    $date_required = "0";
            //}
            //else
            //{
            //    $date_required = "1";
            //}
            //date search end

            if (isset($payload->orderidser) && $payload->orderidser != '') {
                $filter["_id"] = (int) $payload->orderidser;
            }

            if (isset($payload->orderdidser) && $payload->orderdidser != '') {
                $filter["odid"] = $payload->orderdidser;
            }

            if (isset($payload->mrn) && $payload->mrn != '') {
                $filter["order.patientinfo.mrn"] = (string) $payload->mrn;
            }

            if ($payload->type == 'l2pharma' or $payload->type == 'equipment') {
                if (isset($payload->vendorid) and trim($payload->vendorid) != "") {
                    $filter['order.provider_info.associate_id'] = (string) trim($payload->vendorid);
                }
                //else{
                if (isset($payload->city) && $payload->city != '') {
                    $filter["order.patientinfo.city"] = $payload->city;
                }
                //Previously present but not required if needed uncomment
                //if (isset($payload->status) && $payload->status != '') {
                //    $filter["order.order_status.order_status"] = $payload->status;
                //}

                //Validating date_required
                if ($date_required == "1" || count($filter) < 1) {
                    //$searchdatetype = "order.order_status.created_date";

                    $necessary_project[$searchdatetype] = 1;
                    //$sort = $searchdatetype;

                    if (isset($payload->formdate) && isset($payload->todate) && $payload->formdate != "" && $payload->todate != "") {
                        $end_date = date('Y-m-d', strtotime('+1 days', strtotime($payload->todate)));
                        $filter[$searchdatetype] = array('$gte' => $payload->formdate, '$lt' => $end_date);

                        if ($utilityobj->validateDate_Ymd($payload->formdate) == false || $utilityobj->validateDate_Ymd($payload->todate) == false) {
                            $responce["message"] = "formdate and todate format is invalid. please provide date in yyyy-mm-dd format.";

                            return $responce;
                        }
                    } else if ($payload->method != 'rx_not_upload') //date not needed in this case
                    {
                        $responce["message"] = "Please provide start date and end date.";
                        return $responce;
                    }
                }

                //date filter for rx_not_upload
                if (isset($payload->method) && $payload->method == 'rx_not_upload') {
                    $filter["order.order_status.created_date"] = array('$lte' => date('Y-m-d h:m:s', strtotime('-48 hours')));
                }
                //}
            } else if ($payload->type == 'pharmacist' or $payload->type == 'eqvendor') {
                if (!isset($payload->vendorid) or $payload->vendorid == null or
                    trim($payload->vendorid) == "") {
                    $responce["message"] = "Please provide vendorid";
                    return $responce;
                }
                //Vendor logic
                $filter['order.provider_info.associate_id'] = $payload->vendorid;
                /*if(isset($payload->orderidser) && $payload->orderidser != ''){
            $filter["_id"] = (int)$payload->orderidser;

            }else if (isset($payload->orderdidser) && $payload->orderdidser != ''){
            $filter["odid"] = $payload->orderdidser;
            }*/
            }
			
			//return order
			if (isset($payload->method) && $payload->method == 'return') 
			{
				$filter['order.business.is_return_order'] = 1;
				$necessary_project['order.business'] = 1;
			}
			
            //To get all tab counts
            $allcounts = $this->getAllCounts($payload);
            //print_r($allcounts);exit;
        } else {
            $responce["message"] = "Invalid Type(only l2pharma,pharmacist,equipment,eqvendor)";
            return $responce;
        }
        //END of Validate type and corresponding filter actions

        //PRESCRIPTION CASE ONLY IN THE CASE OF L2PHARMA
        if ($payload->type == 'l2pharma') {
            //Getting prescription_later value for filter
            if (isset($payload->method) and ($payload->method == 'rx_not_upload' or $payload->method == 'rx_pending')) {

                $filter['order.patientinfo.prescription_later'] = "1";
            } else if (isset($payload->method) and $payload->method == 'prescription_upload') {
                $filter['order.patientinfo.prescription_later'] = "0";
            }
        }

        //Getting OStatus value for filter

        //IN CASE OF EQUIPMENT,L2PHARMA
        if ($payload->method == 'assignvendororders' or $payload->method == 'tobeconfirmed') {
            $filter['OStatus'] = 21;
        } else if ($payload->method == 'tobeassigned') {
            $filter['OStatus'] = 1000;
        }

        //IN CASE OF EQUIPMENT,L2PHARMA,EQVENDOR,PHARMACIST
        else if ($payload->method == 'rejected') {
            $filter['OStatus'] = 24;
        }

        //IN CASE OF L2PHARMA ONLY
        else if (in_array($payload->method, ['rx_not_upload', 'rx_pending'])) {
            $filter['OStatus'] = 1001;
        } else if ($payload->method == 'prescription_upload') {
            $filter['OStatus'] = 1001;
        }

        //IN CASE OF EQVENDOR,PHARMACIST
        else if ($payload->method == 'completed') {
            $filter['OStatus'] = 6;
        } else if ($payload->method == 'requested_pickup') {
            $filter['OStatus'] = array('$in' => array(18, 0));
        }

        // set the necessary projection
        $project = array_merge($project, $necessary_project);

        //$group = array("_id"=>"totalrecords"=>array('$sum'=>1));

        //LOOKUP
        /* $lookup = array(
        "from"=> "workflow_status",
        "localField"=> "OStatus",
        "foreignField"=> "status",
        "as"=>"statusDetails"
        ); */

        $lookup = array(
            'from' => 'workflow_status',
            'let' => array
            (
                'mode_of_service' => '$mode_of_service',
                'service_type' => '$order.patientinfo.service_type',
                'order_status' => '$OStatus',
                'component' => '$active_component',
            ),
            'pipeline' => array(array
                (
                    '$match' => array
                    ('$expr' => array
                        ('$and' => array(
                            array('$eq' => array('$status', '$$order_status')),
                            array('$eq' => array('$Bid', '$$service_type')),
                            array('$eq' => array('$MOSid', '$$mode_of_service')),
                            array('$eq' => array('$Workflow', '$$component')),
                        ),
                        ),
                    )),
                array('$project' => array("Nomenclature" => 1, '_id' => 0)),
            ),
            'as' => 'statusName',
        );
        $project['statusName'] = 1; //PROJECT statusName

        //PREVIOUS QUERY LOGIC
        /*
        $unwind = array('$unwind'=>'$statusDetails');

        $addFields = array(
        "isBusinessEq"=> array('$eq'=> array( '$order.patientinfo.service_type', '$statusDetails.Bid' ) ),
        "isMosEq"=> array('$eq'=> array( '$mode_of_service', '$statusDetails.MOSid' ) ),
        "isComponentEq"=> array('$eq'=> array( '$active_component', '$statusDetails.Workflow' ) )
        );

        //STATUS NAME PROJECTION
        $status_project = array('$cond'=> array(
        "if"=> array( '$eq'=> [ '$isBusinessEq', true ] ),
        "then"=> array(
        '$cond'=> array(
        "if"=> array( '$eq'=> ['$isMosEq',true]),
        "then"=> array(
        '$cond'=> array(
        "if"=> array( '$eq'=> ['$isComponentEq', true]),
        "then"=> '$statusDetails.Nomenclature',//Name
        "else"=> "No name"  //NoName
        )
        ),
        "else"=>"No name"//NoName
        )
        ),
        "else"=> "No name"  //NoName
        )
        );
        $project['statusName'] = $status_project;
         */

        //V3 ORDERS ONLY
        $filter['transaction_code'] = array('$exists' => true);

        // Setting of pipeline for aggregate
        //$pipeline = array(array('$lookup'=>$lookup),$unwind,array('$addFields' => $addFields),array('$match' => $filter),array('$project' => $project));

        // dynamic sort
        if (isset($payload->sortBy)) {
            if (strtoupper(trim($payload->sortBy)) == "ASCE") {
                $sort = array($sort => 1);
            }
            else if (strtoupper(trim($payload->sortBy)) == "DESC") {
                $sort = array($sort => -1);
            }
			else
			{
				//BY DEFAULT IN DESCENDING ORDER
				 $sort = array($sort => -1);
			}
        } else {
            //BY DEFAULT IN DESCENDING ORDER
            $sort = array($sort => -1);
        }

        $pipeline = array(array('$match' => $filter), array('$sort' => $sort), array('$lookup' => $lookup)
            , array('$project' => $project));

        //echo json_encode($pipeline);exit;

        if ($payload->pagination == true) {
            if (isset($payload->limit) and isset($payload->skip)) {
                $limit = (int) $payload->limit;
                $skip = (int) $payload->skip;
                $totalSkip = $limit * ($skip - 1);

                array_push($pipeline, array('$skip' => $totalSkip));
                array_push($pipeline, array('$limit' => $limit));
            }
        }

        /* // dynamic sort
        if (isset($payload->sortBy))
        {
        if (trim($payload->sortBy) == "ASCE") {
        array_push($pipeline, array('$sort' => array($sort => 1)));
        }
        if (trim($payload->sortBy) == "DESC") {
        array_push($pipeline, array('$sort' => array($sort => -1)));
        }
        }
        else
        {
        //BY DEFAULT IN DESCENDING ORDER
        array_push($pipeline, array('$sort' => array($sort => -1)));
        } */

        // end the setting of pipeline for aggregate
        //echo json_encode($pipeline);exit;
        //print_r($pipeline); exit;

        //call the aggregate function

        //Query to get count for current tab
        //$counter = array(array('$match'=>$filter),array('$count'=>"total_records"));//NOT REQ

        //TRY QUERYING
        try
        {
            //$count = $dbo_obj->aggregate('masters', 'orders', $counter);
            $orderdetails = $this->dbo->aggregate('masters', 'orders', $pipeline);
        }

        //CATCH EXCEPTIONS
         catch (Exception $e) {
            $message = $e->getMessage();
            $response = array("status" => 0, "query_error_msg" => $message);
            return $response;
        }

        //print_r($orderdetails);exit;

        if (count($orderdetails) > 0) {
            $responce["status"] = 1;
            //$responce["totalrecords"]= $count[0][total_records];
            $responce["message"] = "Success";
        }
        $responce["data"] = $orderdetails;
        if (isset($payload->menu)) {
            $responce["menu_name"] = $payload->menu;
        }
        //$responce["countn"] = count($orderdetails);//COMMENTED FOR NOW
        $responce["totalcount"] = $allcounts[$payload->method];

        foreach ($allcounts as $key => $val) {
            $responce[$key] = $val;
        }
        //print_r($responce);exit;

        return $responce;
    }

    public function getOrderDetails($payload)
    {
        $orderid = isset($payload->orderid) ? $payload->orderid : "";
        $response = array("status" => 0, "countn" => 0, "message" => "please provide the correct order id.", "data" => array());
        if (trim($orderid) != "") {
            //$dbo_obj = new Dbo;
            $filter = array("_id" => (int) $orderid);
            $data = $this->dbo->findOne("masters", "orders", $filter, array());
            if (count($data) > 0) {
                $response["countn"] = count($data);
                $response["data"] = $data;
                $response["message"] = "success";
                $response["status"] = 1;
            } else {
                $response["message"] = "data is not found";
            }
        }
        return $response;
    }

    ///22-02-19 MDM Call in this to be moved to mdm.php
    public function coupenlist_all($orderreq, $ticket)
    {
        //$utility = new Utility;
        $config = new Config;

        $url = $config->getconfig('cpservicepath', 'mdm/services/domain/ApplicableMedicineCoupons');
        $req_data = json_encode($orderreq->orderlevel[0]);
        $headersetcurl = array('Content-Type: application/json');
        $result = json_decode($this->utility->common_curl($url, $req_data, 1, $headersetcurl));

        $i = 1;

        $couponarray = array();
        if (isset($result->status) && $result->status == "fail") {} else {
            foreach ($result as $odata) {
                $couponarray[$odata->name] = array("name" => $odata->name, "description" => (isset($odata->description) ? $odata->description : ''), "code" => array());
                /*$str.="<tr><td>".$odata->name."</td><td>".(isset($odata->description)?$odata->description:'')."</td><td><button data-id='".$odata->name."' class='btn btn-success' data-code='' onclick='copycoupon(".$i.");' id='couponlistbtn".$i."'>Apply</button></td></tr>";
            $i=$i+1;*/
            }
        }
        foreach ($orderreq->itemlevel as $line) {
            $url = $config->getconfig('cpservicepath', 'mdm/services/domain/ApplicableMedicineCoupons');

            $req_data = json_encode($line);
            $headersetcurl = array('Content-Type: application/json');
            $result1 = json_decode($this->utility->common_curl($url, $req_data, 1, $headersetcurl));

            if (isset($result1->status) && $result1->status == "fail") {} else {
                foreach ($result1 as $odata1) {
                    if (isset($couponarray[$odata1->name])) {
                        array_push($couponarray[$odata1->name]['code'], $line->code);
                    } else {
                        $couponarray[$odata1->name] = array("name" => $odata1->name, "description" => (isset($odata1->description) ? $odata1->description : ''), "code" => array($line->code));
                    }
                    /*                $str.="<tr><td>".$odata->name."</td><td>".(isset($odata->description)?$odata->description:'')."</td><td><button data-id='".$odata->name."' class='btn btn-success' data-code='".$line->code."' onclick='copycoupon(".$i.");' id='couponlistbtn".$i."'>Apply</button></td></tr>";
                $i=$i+1;*/
                }
            }

        }
        return $couponarray;
    }

    public function vendorAuthenticationPharmacist($payload, $ticket)
    {
        $username = isset($payload->email) ? trim($payload->email) : "";
        $password = isset($payload->password) ? trim($payload->password) : "";
        $response = array("status" => 0, "message" => "Invalid User or Password", "data" => array());
        $project = array(
            "userinfo.EMAIL" => 1,
            "userinfo.PASSWORD" => 1,
            "userinfo.ACTIVE_INACTIVE_E" => 1,
            "userinfo.GROUP_ID" => 1,
            "userinfo.USER_ID" => 1,
            "userinfo.USER_NAME" => 1,
        );
        if ($username != "" && $password != "") {
            $filterpatient = array(
                "userinfo.EMAIL" => $username,
                "userinfo.PASSWORD" => md5($password),
                "userinfo.ACTIVE_INACTIVE_E" => "1",
            );

            //$dbo_obj = new Dbo;
            $cursor = $this->dbo->findOne("masters", "medicine_vendors", $filterpatient, $project);
            if (count($cursor) > 0) {
                $response["status"] = 1;
                $response["message"] = "Pharmacist Authenticated Successfully";
                $response["data"] = $cursor;
            }
        } else {
            $response["message"] = "Please provide username and password";
        }
        return $response;
    }

    public function vendorAuthenticationMediVendor($payload, $ticket)
    {
        $username = isset($payload->email) ? trim($payload->email) : "";
        $password = isset($payload->password) ? trim($payload->password) : "";
        $response = array("status" => 0, "message" => "Invalid User or Password", "data" => array());
        $project = array(
            "userinfo.EMAIL" => 1,
            "userinfo.PASSWORD" => 1,
            "userinfo.ACTIVE_INACTIVE_E" => 1,
            "userinfo.GROUP_ID" => 1,
            "userinfo.USER_ID" => 1,
            "userinfo.USER_NAME" => 1,
        );
        if ($username != "" && $password != "") {
            $filterpatient = array(
                "userinfo.EMAIL" => $username,
                "userinfo.PASSWORD" => md5($password),
                "userinfo.ACTIVE_INACTIVE_E" => "1",
            );
            //$dbo_obj = new Dbo;
            $cursor = $this->dbo->findOne("masters", "mequipment_vendors", $filterpatient, $project);
            if (count($cursor) > 0) {
                $response["status"] = 1;
                $response["message"] = "Vendor Authenticated Successfull";
                $response["data"] = $cursor;
            }
        } else {
            $response["message"] = "Please provide username and password";
        }
        return $response;
    }

    public function Vendorlist($payload, $ticket)
    {
        $type = $payload->systemType;
        /*Possible systemType:
        1. l2pharma(medicine)
        2. equipment(equipment)*/
        $response = array("status" => 0, "message" => "No data found", "data" => array(), "count" => 0);
        $filter = array("userinfo.ACTIVE_INACTIVE_E" => "1");
        $project = array(
            "_id" => 0,
            "userinfo.USER_ID" => 1,
            "userinfo.USER_NAME" => 1,
            "userinfo.ADDRESS" => 1,
            "userinfo.MOBILE" => 1,
        );
        if ($type == 'l2pharma') {
            $cursor = $this->dbo->find('masters', 'medicine_vendors', $filter, $project);
        } else if ($type == 'equipment') {
            $cursor = $this->dbo->find('masters', 'mequipment_vendors', $filter, $project);
        } else {
            $response["message"] = "Invalid system_type";
            return $response;
        }
        if (count($cursor) > 0 && $cursor != "") {
            $response["status"] = 1;
            $response["message"] = "Success";
            $response["count"] = count($cursor);
            $response["data"] = $cursor;
        }
        return $response;
    }

    public function VendorDetails($payload, $ticket)
    {
        $type = $payload->systemType;
        $vendorid = $payload->vendorId;
        //Possible system_type:
        //1. l2pharma(medicine)
        //2. equipment(equipment)
        $response = array("status" => 0, "message" => "No data found", "data" => array());
        if ($vendorid == null or trim($vendorid) == "") {
            $response["message"] = "Invalid or Missing vendorId";
            return $response;
        }
        $filter = array("_id" => $vendorid);
        $project = array(
            "_id" => 0,
            "userinfo.USER_ID" => 1,
            "userinfo.USER_NAME" => 1,
            "userinfo.ADDRESS" => 1,
            "userinfo.MOBILE" => 1,
        );
        if ($type == 'l2pharma') {
            $cursor = $this->dbo->findOne('masters', 'medicine_vendors', $filter, $project);
        } else if ($type == 'equipment') {
            $cursor = $this->dbo->findOne('masters', 'mequipment_vendors', $filter, $project);
        } else {
            $response["message"] = "Invalid system_type";
            return $response;
        }
        if (count($cursor) > 0 && $cursor != "") {
            $response["status"] = 1;
            $response["message"] = "Success";
            $response["data"] = $cursor;
        }
        return $response;
    }

    public function add_items_to_cart($payload, $ticket)
    {
        //LOGGING
        $response = array("status" => 0, "message" => "Items has not added into Cart.");
        $CurrentDateTime = array(
            "year" => date('Y'),
            "month" => date('m'),
            "dayOfMonth" => date('d'),
            "hourOfDay" => date('H'),
            "minute" => date('i'),
            "second" => date('s'),
        );
        $carts = array();
        foreach ($payload->orders as $data) {
            $cart_id = $this->utility->getNextSequence("CART_ID");
            $carts[] = array(
                "_id" => $cart_id,
                "id" => $cart_id,
                "type" => 1,
                "mobile" => 0,
                "mrn" => $data->mrn,
                "addedBy" => $payload->parentMrn,
                "businessId" => $data->businessId,
                "serviceId" => $data->serviceId,
                "status" => 1,
                "CreatedDate" => $CurrentDateTime,
                "ModifiedDate" => $CurrentDateTime,
                "addressId" => isset($data->addressId) ? $data->addressId : 0,
                "session" => isset($data->session) ? $data->session : 0,
            );
        }
        $result = $this->dbo->insertMany("masters", "draft_orders", $carts);
        if ($result[ok] == 1) {
            $response["status"] = 1;
            $response["message"] = "Successfully items are added to cart";
        }
        //print_r($this->dbo->remove("masters","draft_orders",array("mrn"=>$payload->parentMrn)));
        return $response;
    }

    public function get_allitems_from_cart($payload, $ticket)
    {
        $mrn = $payload->mrn;
        $businessId = $payload->businessId;
        $response = array("status" => 0, "message" => "No data found", "data" => array());
        if ($mrn == null or trim($mrn) == "") {
            $response["message"] = "Invalid or Missing MRN";
            return $response;
        }
        $filter = array("mrn" => $mrn);
        if ($businessId == null or trim($businessId) == "") {
            $filter = array("mrn" => $mrn, "businessId" => $businessId);
        }
        $cursor = $this->dbo->find('masters', 'draft_orders', $filter, array());
        $custome_data = array();
        if (count($cursor) > 0 && $cursor != "") {
            foreach ($cursor as $val) {
                $payload = (object) array(
                    "brandname" => $val[serviceId],
                    "filtercolumn" => "code",
                    "entitytype" => "equipmentRentalsUI",
                );
                $result = $this->DrugListLoad($payload);
                if (isset($result["data"][0]["name"])) {
                    $val["name"] = $result["data"][0]["name"];
                    $custome_data[] = $val;
                }
                //print_r($custome_data); exit;
            }
            $response["status"] = 1;
            $response["message"] = "Success";
            $response["data"] = $custome_data;
            //$response["data"] = $cursor;
        }
        return $response;
    }

    public function delete_items_from_cart($payload, $ticket)
    {
        $mrn = $payload->mrn;
        $businessId = $payload->businessId;
        $response = array("status" => 0, "message" => "items is not deleted from cart.");
        if ($mrn == null or trim($mrn) == "") {
            $response["message"] = "Invalid or Missing MRN";
            return $response;
        }
        $filter = array("mrn" => $mrn);
        if ($businessId == null or trim($businessId) == "") {
            $filter = array("mrn" => $mrn, "businessId" => $businessId);
        }
        $cursor = $this->dbo->remove("masters", "draft_orders", $filter);
        //print_r($cursor[n]); exit;
        if ($cursor[ok] == 1 && $cursor[n] > 0) {
            $response["status"] = 1;
            $response["message"] = "Successfully items are deleted from cart.";
        } else if ($cursor[ok] == 1) {
            $response["message"] = "Item is not available in a cart.";
        }
        return $response;
    }

    public function bytearray_prescription_withorder($payload, $ticket)
    {
        $orderid = isset($payload->orderid) ? $payload->orderid : "";
        $response = array("status" => 0, "message" => "Failed! presscription is not uploaded.");
        if (trim($orderid) != "") {
            $filter = array("_id" => (int) $orderid);
            $data = $this->dbo->findOne("masters", "orders", $filter, array());
            if (isset($data[_id])) {
                $filesdata = array();
                $mrn = $data[order][patientinfo][mrn];

                $result = $this->upload_bytearray_prescription($payload->prescription_image, $mrn, "Officer APP");
                if ($result["status"] == 1) {
                    foreach ($result["message"] as $result1) {
                        $filesdata[] = $result1["data"];
                    }
                    if (count($filesdata) > 0) {
                        $push = array("order.prescription_images" => array('$each' => $filesdata));
                        $cursor = $this->dbo->update("masters", "orders", $filter, array(), $push, array());
                        if ($cursor[nModified] == 1) {
                            $response = array("status" => 1, "message" => "Successfully! presscription is uploaded.");
                        }
                    }
                } else {
                    $response["message"] = "Order id is not exists.";
                }
            } else {
                $response["message"] = "Please provide the correct order id.";
            }
        }
        return $response;
    }

    public function upload_bytearray_prescription($prescription_image, $mrn, $uploaded_from = "web")
    {
        $imagename = array();
        $responce = array('status' => 0, 'message' => array());
        foreach ($prescription_image as $prescription_image) {
            $prec = explode(';', $prescription_image);
            if ((!isset($prec[0])) || (!isset($prec[1]))) {
                continue;
            }
            $exten = explode('/', $prec[0]);
            $ext = $exten[1];
            if (!isset($exten[1])) {
                continue;
            }
            $data = base64_decode(str_replace('base64,', '', $prec[1]));
            $image = $mrn . "_" . time() . "_" . rand(100, 100000) . "." . $ext;
            $newname = $image;
            $sub_url = "medpharmacy/prescription/" . $mrn . "/" . $image;
            $display_path = $this->config->getconfig('serverurl', "medpharmacy/prescription/" . $folder);
            $display_url = $this->config->getconfig('serverurl', $sub_url);
            if (!file_exists('./../../medpharmacy/prescription/' . $mrn)) {
                mkdir('./../../medpharmacy/prescription/' . $mrn, 0777, true);
            }
            $data = file_put_contents('./../../medpharmacy/prescription/' . $mrn . '/' . $image, $data);
            $imagename[] = array(
                "status" => 1,
                "message" => "Prescription uploaded.",
                "data" => array(
                    "filename" => $newname,
                    "filepath" => $display_path,
                    "fullpath" => $display_url,
                    "uploaded_from" => $uploaded_from,
                    "prescription_id" => "",
                ),
            );
            $getvars['serverurl'] . "medpharmacy/prescription/" . $mrn . "/" . $image;
        }
        if (count($imagename) > 0) {
            $responce["status"] = 1;
            $responce["message"] = $imagename;
        }
        return $responce;
    }

    public function prescription_upload_link($uploadedFiles, $orderid, $uploadedFrom)
    {
        $prescriptionfile = array();
        $response = array("status" => 0, "message" => "Failed! presscription is not uploaded.");
        $filter = array("_id" => (int) $orderid);
        $orderDetails = $this->dbo->findOne('masters', 'orders', $filter, array());

        if (!empty($orderDetails)) {
            $mrn = $orderDetails[order][patientinfo][mrn];
            if (!in_array($orderDetails[OStatus], array(1000, 1001, 21))) {
                $response["message"] = "Prescription Link has expired.";
                return $response;
            }
            $responsePrescrip = $this->prescription_upload_l2screen($mrn, $uploadedFiles, $uploadedFrom);
            //print_r($responsePrescrip);exit;
            if ($responsePrescrip['status'] == 1) {
                foreach ($responsePrescrip['data'] as $prescriptions) {
                    if ($prescriptions[status] == 1) {
                        $prescriptionfile[] = $prescriptions[data];
                    }

                    if (count($prescriptionfile) > 0) {
                        $push = array("order.prescription_images" => array('$each' => $prescriptionfile));
                        $set = array("order.patientinfo.prescription_later" => "0");
                        $cursor = $this->dbo->update("masters", "orders", $filter, $set, $push, array());
                        if ($cursor[nModified] == 1) {
                            $response = array("status" => 1, "message" => "Successfully! presscription is uploaded.");
                        }
                    }
                }
            }
        }
        return $response;
    }

    public function prescription_upload_l2screen($mrn, $uploadedFiles, $uploaded_from = "L2")
    {
        $response = array();
        $uploadOk = 0;
        if (trim($mrn) == "") {
            $output = array("status" => 0, "message" => 'Provide a valid mrn');
            return $output;
        }
        $i = 0;
        foreach ($_FILES as $key => $value) {
            //return $value;
            $ext = strtolower(pathinfo($value["name"][$i], PATHINFO_EXTENSION));
            //print_r($ext); exit;
            if (empty($value)) {
                $response[] = array("status" => 0, "message" => 'Please upload the  Prescription image', "file" => $value["name"][$i]);
                continue;
                //return $response;
            } elseif (!in_array($ext, IMAGE_EXTNS)) {
                $response[] = array("status" => 0, "message" => 'Please upload Prescription image in "jpg|jpeg|gif|png|bmp|pdf" format only.', "file" => $value["name"][$i]);
                continue;
                //return $response;
            } else if (($value['size'][$i] > 2000000) || ($value['error'][$i] == 1)) {
                $response = array("status" => 0, "message" => 'Please upload Prescription image Less than 2 MB size only.', "file" => $value["name"][$i]);
                continue;
                //return $response;
            }
            $sub_url = "medpharmacy/prescription/";
            $target_dir = $this->config->getconfig('rootpath', $sub_url);
            $newname = rand(1000, 10000) . basename($value["name"][$i]);
            $newname = str_replace(' ', '', $newname);
            //MAKE FOLDER WITH MRN
            $folder = $mrn . '/';
            $target_dir = $target_dir . $folder;
            //CREATE DIRECTORY FOR MRN IF NOT EXISTS
            if (!is_dir($target_dir)) {
                $val = mkdir($target_dir);
            }
            $target_file = $target_dir . $newname;

            //TRY UPLOADING FILE
            try {
                $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
                $imgaresult = move_uploaded_file($value["tmp_name"][$i], $target_file);
                //MAKE DISPLAY URL IF UPLOADED
                $sub_url = "medpharmacy/prescription/" . $folder . $newname;
                $display_path = $this->config->getconfig('serverurl', "medpharmacy/prescription/" . $folder);
                $display_url = $this->config->getconfig('serverurl', $sub_url);
                $response[] = array(
                    "status" => 1,
                    "message" => "Prescription uploaded.",
                    "data" => array(
                        "filename" => $newname,
                        "filepath" => $display_path,
                        "fullpath" => $display_url,
                        "uploaded_from" => $uploaded_from,
                        "prescription_id" => "",
                    ),
                );
                $uploadOk = 1;
                continue;
            } catch (Exception $e) {
                $response[] = array("status" => 0, "message" => "Upload Failed: " . $e->getMessage(), "filename" => $value["name"][$i]);
                continue;
            }
            $i = $i + 1;
        }
        $output = array('status' => $uploadOk, 'message' => $response, 'data' => $response);
        return $output;
    }

    /*function prescription_upload_l2screen($mrn,$uploadedFiles){
    $response = array();
    $uploadOk = 1;

    if(trim($mrn)=="")
    {
    $output = array("status" => 0, "message" => 'Provide a valid mrn');
    return $output;
    }
    //print_r($uploadedFiles['name']->name:protected); exit;
    //print_r($_FILES['name']['tmp_name']); exit;
    //+';filename='.['name']->name
    $payloadforCP=array(
    "uploadType"=>"prescription",
    "mrn"=>"221233",
    //"file"=>'@'.$_FILES['name']['tmp_name']
    "file"=>'@'.$_FILES['name']['tmp_name'].$_FILES['name']['name'].";filename=".$_FILES['name']['name']
    );

    //print_r($payloadforCP); exit;
    // initialise the curl request
    $request = curl_init();
    curl_setopt($request, CURLOPT_URL, "https://choicev3.callhealth.com/rest/omsUpload");
    // send a file
    curl_setopt($ch, CURLOPT_HTTPHEADER,"Content-Type:multipart/form-data");
    curl_setopt($request, CURLOPT_POST, true);
    curl_setopt(
    $request,
    CURLOPT_POSTFIELDS,
    $payloadforCP
    );
    curl_setopt($request,CURLOPT_INFILESIZE ,$_FILES['name']['size']);
    curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
    echo curl_exec($request);

    // close the session
    curl_close($request);
    exit;
    //print_r($payloadforCP); exit;
    $CPcall = new Choice();
    print_r($CPcall->uploadPrescriptionCP($payloadforCP)); exit;

    print_r($uploadedFiles); exit;

    foreach($uploadedFiles as $file){
    $payloadforCP=array(
    "uploadType"=>"prescription",
    "mrn"=>"221233",
    "file"=>$file
    );
    //print_r($payloadforCP); exit;
    $CPcall = new Choice();
    print_r($CPcall->uploadPrescriptionCP($payloadforCP)); exit;
    }

    foreach ($_FILES as $key => $value){
    $ext = strtolower(pathinfo($value["name"], PATHINFO_EXTENSION));

    if (empty($value)){
    $uploadOk = 0;
    $response[] = array("status" => 0, "message" => 'Please upload the  Prescription image', "file" => "");
    continue;
    //return $response;
    }elseif (!in_array($ext, IMAGE_EXTNS)){
    $uploadOk = 0;
    $response[] = array("status" => 0, "message" => 'Please upload Prescription image in "jpg|jpeg|gif|png|bmp|pdf" format only.', "file" => "");
    continue;
    //return $response;
    }
    else if (($value['size'] > 2000000) || ($value['error'] == 1))
    {
    $uploadOk = 0;

    $response = array("status" => 0, "message" => 'Please upload Prescription image Less than 2 MB size only.', "file" => "");
    continue;
    //return $response;
    }

    $payloadforCP=array(
    "uploadType"=>"prescription",
    "mrn"=>"221233",
    "file"=>$value,
    );
    //print_r($payloadforCP); exit;
    $CPcall = new Choice();
    print_r($CPcall->uploadPrescriptionCP($payloadforCP)); exit;

    /*
    $sub_url = "medpharmacy/prescription/";
    $target_dir = $this->config->getconfig('rootpath', $sub_url);
    $newname = rand(1000, 10000) . basename($value["name"]);

    //MAKE FOLDER WITH MRN
    $folder = $mrn.'/';
    $target_dir = $target_dir . $folder;

    //CREATE DIRECTORY FOR MRN IF NOT EXISTS
    if(!is_dir($target_dir)){
    $val = mkdir($target_dir);
    }
    $target_file = $target_dir . $newname;

    //TRY UPLOADING FILE
    try{
    $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
    $imgaresult = move_uploaded_file($value["tmp_name"], $target_file);

    //MAKE DISPLAY URL IF UPLOADED
    $sub_url = "medpharmacy/prescription/" . $folder . $newname;
    $display_url = $this->config->getconfig('serverurl', $sub_url);

    $response[] = array("status" => 1, "message" => "Prescription uploaded.", "file" => $display_url);
    continue;
    }catch(Exception $e){
    $uploadOk = 0;
    $response[] = array("status" => 0, "message" => "Upload Failed: ".$e->getMessage(), "file" => "");
    continue;
    }*/
    /*}
    $output = array('status' => $uploadOk,'message' => $response);
    return $output;
    }*/

    public function logorder($payload, $ticket)
    {
        $omsorder_id = $payload->omorder_id;
        $itemid_id = $payload->item_ids;
        $log_reason = $payload->rejectreasons;
        $actionbyid = $payload->vendorid;
        $actionbyname = $payload->vendorname;
        $role = $payload->role; // vendor / l2pharma*/
        //exit;
        //$db = getDBmasters();
        //$collection = $db->orders;

        $arraylog = array(
            "item_code" => $itemid_id,
            "log_reason" => $log_reason,
            "role" => $role,
            "actionbyid" => $actionbyid,
            "actionbyname" => $actionbyname,
            "action_date" => date("Y-m-d H:i:s"),
        );

        //print_r($arraylog);exit;
        //Single item log also implemented
        $filter = array("_id" => (int) $omsorder_id, 'order.orderitem.item_code' => (string) $itemid_id);
        $set = array();
        $set = array('order.orderitem.$.user_log' => $log_reason);

        $push = array("user_log" => $arraylog);
        $response = array("status" => "0", "message" => "Failed");
        $cursor = $this->dbo->update("masters", "orders", $filter, $set, $push, array());

        if ($cursor['nModified'] == 1) {
            $response = array("status" => "1", "message" => "Log is generated successfully");
            return $response;
        } else {
            $response = array("status" => "0", "message" => "Log generation Failed");
            return $response;
        }
    }

    public function userlog_details($payload, $ticket)
    {
        /*$postdata = \Slim\Slim::getInstance()->request();
        $reqparmt = json_decode($postdata->getBody(),false);*/
        //var_dump($reqparmt);
        /*$db = getDBmasters();
        $collection = $db->orders;*/
        $filter = array("_id" => (int) $payload->id, "user_log.item_code" => $payload->itemcode);
        $response = array();
        $cursor = $this->dbo->find("masters", "orders", $filter, array(), array());
        //var_dump($cursor);
        //print_r($cursor);exit;
        if (count($cursor) > 0) {
            foreach ($cursor as $document) {
                $result = $document['user_log'];
            }
            $response["status"] = "1";
            $response["activetiem"] = $payload->itemcode;
            $response["itemlist"] = $result;
        } else {
            $response["status"] = "0";
            $response["itemlist"] = "";
        }
        echo json_encode($response);
    }

    private function addLogForMDM($mrn, $orderid, $payloadData, $responseData, $actionType, $addFields)
    {
        $apidata = array();
        $apidata['mrn'] = $mrn;
        $apidata['order_id'] = (int) $orderid;
        $apidata['api'] = $actionType;
        $apidata['actiondate'] = date("Y-m-d h:i:s");
        $apidata['requestdata'] = $payloadData;
        $apidata['result'] = $responseData;
        $this->dbo->insert("masters", "mdm_log", $apidata);
        //$inserted_id = $collection23->insert($apidata);
    }

    public function walletTransaction($business, $orderid, $transactionType, $amount, $mrn, $ticket)
    {
        $response = array("status" => "0", "message" => "Failed", "description" => "Unable to " . $transactionType . " wallet.");
        $Mdm = new Mdm;
        $transactionkey = $Mdm->gettransactionkeyforwallet($mrn, $ticket);
        if ($transactionkey[status] == 1 && $transactionkey[data][value] != "") {
            $payload->mrn = $mrn;
            $payload->transactionkey = $transactionkey[data][value];
            $payload->amount = $amount;
            $payload->orderid = $orderid;
            $payload->description = "";
            $payload->source = "L2 Pharma";
            if ($transactionType == "debit") {
                $payload->transactionType = $transactionType;
                $result = $Mdm->updatewalletamtinmdm($payload, $ticket);
            } else if ($transactionType == "credit") {
                $payload->transactionType = $transactionType;
                $result = $Mdm->creditwalletamtinmdm($payload, $ticket);
            }

            $payload->business = $business;
            $this->addLogForMDM($mrn, $orderid, $payload, $result, "Wallet " . $transactionType, array());
            //$resul = json_encode($result);

            if ($result['status'] == 1 && strtolower($result['data']['status']) == "success") {
                $response["status"] = "1";
                $response["message"] = "Success";
                $response["Amounts"] = $amount;
                $response["description"] = $transactionType;
            }
            return $response;
        } else {
            return $response;
        }
    }

    private function arrangeDurgPayloadAsPerMDM($orderDetails, $itemmrp, $item_code, $usewallet = "false")
    {
        $i = 0;
        $orderItems = isset($orderDetails[order][orderitem]) ? $orderDetails[order][orderitem] : array();
        $mrn = $orderDetails[order][patientinfo][mrn];
        $coupon = $orderDetails[payment_info][coupon];
        $source = CHANNEL[(int) $orderDetails[channel]];
        $wallet_amount = (float) $orderDetails[payment_info][wallet_amount];
        $zipcode = $orderDetails[order][patientinfo][pincode];
        $engage_at = $orderDetails[mode_of_service];
        //$orderDateMongo = $orderDetails[order][order_status][order_date]->sec;
        $orderDateMongo = $this->dbo->mongoDateToSec($orderDetails[order][order_status][order_date]);
        $orderDateObj = new DateTime("@$orderDateMongo");
        //$orderDate = $orderDateObj->format('Y-M-d H:i:s');
        $orderDate = $orderDateObj->format('d-M-Y H:i:s');
        $ForMDMlineItem = array();
        foreach ($orderItems as $newlineitem) {
            if ($newlineitem['roleBasedService'] == 1) {
                continue;
            }
            if ($newlineitem['item_status'] != "8") {
                $ForMDMlineItem[$i] = array(
                    "business" => "2",
                    "code" => (string) $newlineitem['item_code'],
                    "mrn" => (string) $mrn,
                    "zipcode" => (string) $zipcode,
                    "engage_at" => (string) $engage_at,
                    "orderDate" => (string) $orderDate,
                    "source" => (string) $source,
                    "sessions" => (string) $newlineitem['quantity'],
                );
                if ($newlineitem['item_code'] == $item_code) {
                    $ForMDMlineItem[$i]["updatedPrice"] = (string) $itemmrp;
                    $ForMDMlineItem[$i]["isUpdatePrice"] = "true";
                } else {
                    $ForMDMlineItem[$i]["updatedPrice"] = (string) $newlineitem['item_mrp'];
                    $ForMDMlineItem[$i]["isUpdatePrice"] = "false";
                }
                $i = $i + 1;
            }
        }

        $MdmPayload = array(
            "method" => "domain/Order",
            "type" => "POST",
            "addReportDeliveryCharges" => "yes",
            "orderNumber" => (int) $orderDetails[_id],
            "vendorName" => $orderDetails[order][provider_info][0]['associate_name'],
            "orderDate" => (string) $orderDate,
            "source" => $source,
            "coupon" => $coupon,
            "useWallet" => $usewallet,
            "LineItems" => $ForMDMlineItem,
            //"doctorReferral"=>(($doctorReferral == "1") ? "yes" : "no"))
        );
        return $MdmPayload;
    }

    //as per mdm respose (MDM repoce,current order items,change price for item){
    private function rearrangeDurgOrderAsPerMDM($res, $orderItems, $item_code = "", $batchdata = array(),$wallet_calculation="true")
    {
        $T_OMSNetAmount = 0;
        if (isset($res['data']['lineItemList'])) {
            foreach ($res['data']['lineItemList'] as $mdmlineitem) {
                $currentItemCode = $mdmlineitem['code'];
                $itemKey = array_search($currentItemCode, array_column($orderItems, 'item_code'));
                $orderItems[$itemKey]['gross_amount'] = $mdmlineitem['grossAmount'];
                $orderItems[$itemKey]['item_mrp'] = $mdmlineitem['unitPrice'];
                $orderItems[$itemKey]['MRP'] = $mdmlineitem['MRP'];
                $orderItems[$itemKey]['net_amount'] = $mdmlineitem['OMSNetAmount'];
                $T_OMSNetAmount = $T_OMSNetAmount + (float) $mdmlineitem['OMSNetAmount'];
				if($wallet_calculation!="false"){
					$orderItems[$itemKey]['item_wallet'] = $mdmlineitem['apportionedWalletAmount'];
					$orderItems[$itemKey]['wallet_amount'] = $mdmlineitem['apportionedWalletAmount'];
				}
                $orderItems[$itemKey]['discountApplied'] = ($mdmlineitem['discountApplied'] != "") ? true : false;
                $orderItems[$itemKey]['cartCouponApplied'] = ($mdmlineitem['cartCouponApplied'] != "") ? true : false;
                $orderItems[$itemKey]['orderDiscountApplied'] = ($mdmlineitem['orderDiscountApplied'] != "") ? true : false;
                $orderItems[$itemKey]['cartDiscountApportionedAmount'] = (float) $mdmlineitem['cartDiscountApportionedAmount'];
                $orderItems[$itemKey]['orderApportionedDiscountAmount'] = (float) $mdmlineitem['orderApportionedDiscountAmount'];
                $orderItems[$itemKey]['lineItemDiscountAmount'] = (float) $mdmlineitem['discountAmount'];
                $orderItems[$itemKey]['coupon'] = (float) $mdmlineitem['apportionedCouponAmount'];
                //$orderItems[$itemKey]['discount_amount'] =$mdmlineitem['grossAmount'];
                $discount_amount = (float) $mdmlineitem['grossAmount'] - (float) $mdmlineitem['OMSNetAmount'];
                $orderItems[$itemKey]['discount_amount'] = $discount_amount;

                if ($item_code != "" && $mdmlineitem['code'] == $item_code) {
                    $orderItems[$itemKey]['price_update_flag'] = '1';
                    $orderItems[$itemKey]['batch'] = (array) $batchdata;
                    $orderItems[$itemKey]['batch_log'][] = (array) $batchdata;
                }
            }
        }

        if (isset($res['data']['medicineDeliveryChargesList'])) {
            foreach ($res['data']['medicineDeliveryChargesList'] as $mdmlineitem_del) {
                $currentItemCode = $mdmlineitem_del['code'];
                $itemKey = array_search($currentItemCode, array_column($orderItems, 'item_code'));
                $orderItems[$itemKey]['gross_amount'] = $mdmlineitem_del['grossAmount'];
                $orderItems[$itemKey]['item_mrp'] = $mdmlineitem_del['unitPrice'];
                $orderItems[$itemKey]['MRP'] = $mdmlineitem_del['MRP'];
                $orderItems[$itemKey]['net_amount'] = $mdmlineitem_del['OMSNetAmount'];
                $T_OMSNetAmount = $T_OMSNetAmount + (float) $mdmlineitem_del['OMSNetAmount'];
                $orderItems[$itemKey]['discount_amount'] = (float) $mdmlineitem_del['discountAmount'];
                $orderItems[$itemKey]['isWaiver'] = ($mdmlineitem_del['isWaiver'] != "") ? true : false;
                $orderItems[$itemKey]['margin'] = (isset($mdmlineitem_del['margin'])) ? $mdmlineitem_del['margin'] : "";
                $discount_amount = (float) $mdmlineitem_del['grossAmount'] - (float) $mdmlineitem_del['OMSNetAmount'];
                $orderItems[$itemKey]['discount_amount'] = $discount_amount;
            }
        }

        $updateOrderArray['payment_info.gross_amount'] = (float) $res['data']['grossAmount'];
        $updateOrderArray['payment_info.net_amount'] = (float) $T_OMSNetAmount;
        $updateOrderArray['payment_info.discount_amount'] = ((float) $res['data']['grossAmount'] - $T_OMSNetAmount);
        $updateOrderArray['payment_info.coupon_amount'] = (float) $res['data']['couponAmount'];
        if ($res['data']['useWallet'] == true) {
            $updateOrderArray['payment_info.wallet_has_to_deduct'] = (float) $res['data']['walletAmount'];
        }
        $updateOrderArray['payment_info.payable_amount'] = $T_OMSNetAmount;
        //$updateOrderArray['payment_info.wallet_amount'] = (float) $res['data']['netAmount'];
        $updateOrderArray['order.orderitem'] = $orderItems;
        return $updateOrderArray;
    }

    public function editEquipmentOrder($payload, $ticket)
    {
        $utility = new Utility;
        $response = array("status" => 0, "message" => "No data found", "data" => array());
        if (isset($payload->order_id) && trim($payload->order_id) != "" && count($payload->orders) == 1) {
            $utilresponse = $this->utility->verify_transaction((array) $payload);
            if ($utilresponse['status'] == 0) {
                echo json_encode($utilresponse);
                exit;
            }
            $filter = array("_id" => (int) $payload->order_id);
            $orderDetails = $this->dbo->findOne('masters', 'orders', $filter, array(), array());
            $actionById = isset($payload->created_by_id) ? $payload->created_by_id : "";
            $actionByName = isset($payload->created_by_name) ? $payload->created_by_name : "";
            $paymentDetails = $payload->payment_info;
            if (!empty($orderDetails)) {
                $patientInfo = $orderDetails['order']['patientinfo'];
                $transactionCode = $orderDetails['transaction_code'];
                $paidamount = $orderDetails['payment_info']['paid_amount'];
                $transactionFilter = array("transaction_code" => $transactionCode);
                $transactionDetails = $this->dbo->findOne('masters', 'transaction', $transactionFilter, array(), array());
                if (!$transactionDetails) {
                    return false;
                }

                $orderitem = $orderDetails[order][orderitem];
                //print_r($orderitem);
                $transPaymentInfo = $transactionDetails['payment_info'];
                $transOrderInfo = $transactionDetails['order_info'];

                //$orderitem=$orderDetails[order][orderitem];
                //$previouswalletamt=isset($orderDetails[order][patientinfo][wallet_amount])?(float)$orderDetails[order][patientinfo][wallet_amount]:0;
                $orderitemcodes = array_column($orderitem, 'item_code');
                $t_gross_amount = $t_net_amount = $t_discount_amount = $t_base_amount = 0;
                $payloaditemcodes = array();

                foreach ($payload->orders[0]->order_item as $item) {

                    $payloaditemcodes[] = $item->item_code;
                    if (in_array($item->item_code, $orderitemcodes)) {
                        //performed the union opeartion to update the existing value and remaain value willbe in same array
                        $key = array_search($item->item_code, $orderitemcodes);
                        $iteminarray = (array) $item;
                        $iteminarray[item_status] = "0";
                        $orderitem[$key] = array_merge($orderitem[$key], $iteminarray);
                        $t_gross_amount = $t_gross_amount + (float) $iteminarray[gross_amount];
                        $t_net_amount = $t_net_amount + (float) $iteminarray[net_amount];
                        $t_base_amount = $t_base_amount + (float) $iteminarray[total_baseprice];
                    } else {

                        $iteminarray = (array) $item;
                        // added the now line item in order
                        $iteminarray[role] = "";
                        $iteminarray[skill] = "";
                        $iteminarray[item_status] = "0";
                        $iteminarray[component_no] = "9";
                        //"discount_amount":""   // number,
                        //"itemname":"",
                        $orderitem[] = $iteminarray;
                        $t_gross_amount = $t_gross_amount + (float) $iteminarray[gross_amount];
                        $t_net_amount = $t_net_amount + (float) $iteminarray[net_amount];
                        //$t_base_amount = $t_base_amount + (float)$iteminarray[total_baseprice];
                    }
                }

                $t_discount_amount = $t_gross_amount - $t_net_amount;

                //IF ITEM_CODE IS NOT PRESENT IN PRESENT PAYLOAD IT IS CANCELLED
                $cancelledItems = array_diff($orderitemcodes, $payloaditemcodes);

                foreach ($cancelledItems as $key => $item) {
                    $orderitem[$key]["item_status"] = "8";
                    $orderitem[$key]["item_cancel_reason"] = "cancel from l2 screen on edit the order";
                    $orderitem[$key]["item_cancel_date"] = (date("Y-m-d") . "T" . date("H:i:s") . ".000Z");
                    $orderitem[$key]["item_wallet"] = 0;
                    $orderitem[$key]["wallet_amount"] = 0;
                    $orderitem[$key]["cancelbeforeaccept"] = "1";
                }

                /*$i=0;
                // for cancle the existing item which are removed the by l2 after conversion to customer
                foreach($orderitem as $itemscheck){
                if(!in_array($itemscheck[item_code],$payloaditemcodes)){
                $orderitem[$i]["item_status"]="8";
                $orderitem[$i]["item_cancel_reason"]="cancel from l2 screen on edit the order";
                $orderitem[$i]["item_cancel_date"]=(date("Y-m-d")."T".date("H:i:s").".000Z");
                //$orderitem[$i]["item_wallet"]=0;
                //$orderitem[$i]["cancelbeforeaccept"]="1";
                }
                $i = $i + 1;
                }*/

                //update the order
                $update = array(
                    //AMOUNTS UPDATION
                    "order.patientinfo.gross_amount" => $t_gross_amount,
                    "order.patientinfo.net_amount" => $t_net_amount,
                    "order.patientinfo.discount_amount" => $t_discount_amount,
                    "order.patientinfo.base_amount" => $t_base_amount,
                    "order.patientinfo.payable_amount" => $t_net_amount,
                    "payment_info.gross_amount" => $t_gross_amount,
                    "payment_info.net_amount" => $t_net_amount,
                    "payment_info.base_amount" => $t_base_amount,
                    "payment_info.discount_amount" => $t_discount_amount,
                    "payment_info.payable_amount" => $t_net_amount,
                    "order.order_status.last_updated_on" => date("Y-m-d") . "T" . date("H:i:s") . ".000Z",
                    "order.orderitem" => $orderitem,
                );

                //check the address
                if ($payload->orders[0]->address_id != $orderDetails[order][patientinfo][mrn]) {
                    $gcm = new Gcm;
                    $patient_address = $gcm->get_mrn_address_info(array($orderDetails[order][patientinfo][mrn]), array($payload->orders[0]->address_id));
                    $addresDetails = $patient_address[address_id][$payload->orders[0]->address_id];
                    $update['order.patientinfo.address_id'] = $addresDetails[address_id];
                    $update['order.patientinfo.state'] = $addresDetails[state];
                    $update['order.patientinfo.city'] = $addresDetails[city];
                    $update['order.patientinfo.district'] = $addresDetails[district];
                    $update['order.patientinfo.landmark'] = $addresDetails[landmark];
                    $update['order.patientinfo.address'] = $addresDetails[address];
                    $update['order.patientinfo.pincode'] = $addresDetails[pincode];
                    $update['order.patientinfo.delivery_lat'] = $addresDetails[delivery_lat];
                    $update['order.patientinfo.delivery_lng'] = $addresDetails[delivery_lng];
                }

                //check the vendor
                if ($payload->orders[0]->associate_id != $orderDetails[order][provider_info][0][associate_id]) {
                    $medeq = new Mediequipment;
                    $vendorinfo = $medeq->getVendorDetails($payload->orders[0]->associate_id);
                    foreach ($vendorinfo as $key => $value) {
                        //$update['order.provider_info.$.' . $key] = $value;
                        $update['order.provider_info.0.' . $key] = $value;
                    }
                    if (!isset($orderDetails[order][provider_info][0][log])) {
                        $update['order.provider_info.0.log'] = array($orderDetails[order][provider_info][0]);
                    } else {
                        $countval = count($orderDetails[order][provider_info][0][log]);
                        $update['order.provider_info.0.log.' . $countval . ''] = array($orderDetails[order][provider_info][0]);
                    }
                    $update['order.provider_info.0.vendor_assigned_date'] = date("Y-m-d H:i:s");
                }

                //print_r($update); exit;
                //return "hello";
                $set = $update;
                $options = array("multiple" => true);

                $orderupdate = $this->dbo->update('masters', 'orders', $filter, $set, array(), $options);
                if ($orderupdate['nModified'] == 1) {
                    // call change order status api
                    $owf = new OrderWorkFlow;
                    $pload = [
                        "actionById" => $actionById,
                        "actionByName" => $actionByName,
                        "order_id" => $payload->order_id,
                        "status" => 21,
                        "reasonType" => 1,
                        "reason" => "Assigned Vendor",
                        "source" => "L2",
                    ];

                    $tt = $owf->change_order_status((object) $pload, $ticket);
                    //$response1 = array("status" => "1", "message" => "Successfully Updated", "data" =>array("order_id"=>$eachorder->order_id));

                    $gross_amount = ($transOrderInfo->gross_amount - $patientInfo->gross_amount) + $t_gross_amount;
                    $discount_amount = ($transOrderInfo->discount_amount - $patientInfo->discount_amount) + ($t_discount_amount);
                    $net_amount = ($transOrderInfo->net_amount - $patientInfo->net_amount) + $t_net_amount;
                    $voucher_amount = ($transOrderInfo->voucher_amount - $patientInfo->voucher_amount) + $paymentDetails->voucher_amount;
                    $coupon_amount = ($transOrderInfo->coupon_amount - $patientInfo->coupon_amount) + $paymentDetails->coupon_amount;
                    $wallet_amount = ($transOrderInfo->wallet_amount - $patientInfo->wallet_amount) + $paymentDetails->wallet_amount;
                    $payment_amount = ($transPaymentInfo->payment_amount - $patientInfo->payable_amount) + $paymentDetails->payment_amount;

                    $transactionArray = array(
                        'payment_info.voucher_amount' => $voucher_amount,
                        'payment_info.wallet_amount' => $wallet_amount,
                        'payment_info.coupon_amount' => $coupon_amount,
                        'payment_info.payment_amount' => $payment_amount,
                        'order_info.0.gross_amount' => $gross_amount,
                        'order_info.0.discount_amount' => $discount_amount,
                        'order_info.0.net_amount' => $net_amount,
                        'order_info.0.voucher_amount' => $voucher_amount,
                        'order_info.0.wallet_amount' => $wallet_amount,
                        'order_info.0.coupon_amount' => $coupon_amount,
                    );
                    $transactionUpdate = $this->dbo->update('masters', 'transaction', $transactionFilter, $transactionArray, array(), $options);
                    $response = array("status" => 1, "message" => "Updated Successfully", "assignment" => $tt);

                    //$response = array("status"=>1,"message"=>"Successfully order updated.","data"=>array());
                } else {
                    $response["message"] = "Please try again.";
                }
            } else {
                $response["message"] = "In-correct order id.";
            }
        } else {
            $response["message"] = "Please provide the order id.";
        }
        return $response;
    }

    public function updateEquipmentItem($payload, $ticket)
    {
        $utility = new Utility;
        $response = array("status" => 0, "message" => "No data found", "data" => array());
        if (isset($payload->order_id) && trim($payload->order_id) != "") {
            if (!isset($payload->item_code) && trim($payload->item_code) == "") {
                $response["message"] = "Please choose the item.";
                return $response;
            }
            $filter = array("_id" => (int) $payload->order_id);
            $orderDetails = $this->dbo->findOne('masters', 'orders', $filter, array(), array());
            if (!empty($orderDetails)) {
                $MRP = (float) $payload->MRP;
                $item_selling_p = (float) $payload->item_selling_p;
                $item_base_p = (float) $payload->item_base_p;
                $gross_amount = (float) $payload->gross_amount;
                $net_amount = (float) $payload->net_amount;
                $total_baseprice = (float) $payload->total_baseprice;
                $type = $payload->type;
                $quantity = $payload->quantity;

                $t_gross_amount = $t_net_amount = $t_discount_amount = 0;
                $update = array();
                // order item updatetion
                $i = 0;
                foreach ($orderDetails[order][orderitem] as $item) {
                    if ($item[item_status] == "0") {
                        if ($item[item_code] == $payload->item_code) {
                            $update["order.orderitem." . $i . ".MRP"] = $MRP;
                            $update["order.orderitem." . $i . ".item_selling_p"] = $item_selling_p;
                            $update["order.orderitem." . $i . ".item_base_p"] = $item_base_p;
                            $update["order.orderitem." . $i . ".gross_amount"] = $gross_amount;
                            $update["order.orderitem." . $i . ".net_amount"] = $net_amount;
                            $update["order.orderitem." . $i . ".total_baseprice"] = $total_baseprice;
                            $update["order.orderitem." . $i . ".quantity"] = $quantity;

                            $t_gross_amount = $t_gross_amount + $gross_amount;
                            $t_net_amount = $t_net_amount + $net_amount;
                        } else {
                            $t_gross_amount = $t_gross_amount + $item[gross_amount];
                            $t_net_amount = $t_net_amount + $item[net_amount];
                        }
                    }
                    $i = $i + 1;
                }
                if (count($update) > 1) {
                    $t_discount_amount = $t_gross_amount - $t_net_amount;
                    $update["order.patientinfo.gross_amount"] = $t_gross_amount;
                    $update["order.patientinfo.net_amount"] = $t_net_amount;
                    $update["order.patientinfo.discount_amount"] = $t_discount_amount;
                    $update["payment_info.gross_amount"] = $t_gross_amount;
                    $update["payment_info.net_amount"] = $t_net_amount;
                    $update["payment_info.discount_amount"] = $t_discount_amount;
		    $update["payment_info.payable_amount"] = $t_net_amount;
	
                    $set = $update;
                    $options = array("multiple" => true);
                    $orderupdate = $this->dbo->update('masters', 'orders', $filter, $set, array(), $options);
                    if ($orderupdate['nModified'] == 1) {
                        $response = array("status" => 1, "message" => "Successfully item got updated.", "data" => (array) $payload);
                    } else {
                        $response["message"] = "Please try again.";
                    }
                } else {
                    $response["message"] = "Please provide the correct item details.";
                }
            } else {
                $response["message"] = "In-correct order id.";
            }
        } else {
            $response["message"] = "Please provide the order id.";
        }
        return $response;
    }

    public function makeitemarray($items)
    {
        $item = array();
        $item["item_id"] = $items->item_code;
        $item["item_code"] = $items->item_code;
        $item["itemname"] = $items->brandname;
        $item["doctor"] = $items->doctorname;
        $item["quantity"] = $items->quantity;
        $item["item_mrp"] = $items->item_mrp;
        $item["gross_amount"] = $items->gross_amount;
        $item["discount_amount"] = $items->discount_amount;
        $item["net_amount"] = $items->net_amount;
        // set previous price as old price
        $item["old_item_mrp"] = $items->item_mrp;
        $item["old_gross_amount"] = $items->gross_amount;
        $item["old_discount_amount"] = $items->discount_amount;
        $item["old_net_amount"] = $items->net_amount;
        $item["price_update_flag"] = "0";
        $item["item_wallet"] = $items->item_wallet;
        $item["wallet_amount"] = $items->item_wallet;
        $item["pharmaname"] = $items->pharmaname;
        $item["prescribed"] = $items->prescribed;
        $item["item_status"] = "0";
        $item["category"] = isset($items->category) ? $items->category : "";
        $item["priceperunit"] = isset($items->priceperunit) ? $items->priceperunit : "NA";
        $item["packsize"] = isset($items->packsize) ? $items->packsize : "NA";
        $item["manufacturer_id"] = isset($items->manufacturer_id) ? $items->manufacturer_id : "";
        $item["manufacturer"] = isset($items->manufacturer) ? $items->manufacturer : "";
        $item["coupon"] = "";
        if (trim($orderreq->couponitem) != "") {
            $item["coupon"] = isset($items->coupon) ? $items->coupon : "";
        }
        if ($items->prescribed == "1") {
            $typ = 'Prescription';
        } else {
            $typ = 'OTC';
        }
        $item["type"] = isset($typ) ? $typ : "";
        return $item;
    }

    public function updateOrder($payload, $ticket)
    {

        $utility = new Utility;
        $mdm = new Mdm;
        $gcm = new Gcm;
        //UNCOMMENT ONCE DONE
        /* $utilresponse = $utility->verify_transaction($payload);

        if ($utilresponse['status'] == 0) {
        echo json_encode($utilresponse);
        exit;
        } */

        $source = isset($payload->channel) ? $payload->channel : "";
        $orders = $payload->orders;
        $paymentDetails = $payload->payment_info;

        $actionById = isset($payload->created_by_id) ? $payload->created_by_id : "";
        $actionByName = isset($payload->created_by_name) ? $payload->created_by_name : "";

        $item_data = [];
        $order_set = array();
        foreach ($orders as $eachorder) {
            $mrns_required[] = $eachorder->mrn;
            $address_ids_required[] = $eachorder->address_id;
            $address_mrn_info = $gcm->get_mrn_address_info($mrns_required, $address_ids_required);
            $address_info = $address_mrn_info['address_id'][$eachorder->address_id];
            $filter = array("_id" => (int) $eachorder->order_id);
            $orderDetails = $this->dbo->findOne('masters', 'orders', $filter, array(), array());
            if (!$orderDetails) {
                return false;
            }
            $patientInfo = $orderDetails['order']['patientinfo'];
            $transactionCode = $orderDetails['transaction_code'];
            $paidamount = $orderDetails['payment_info']['paid_amount'];
            $transactionFilter = array("transaction_code" => $transactionCode);
            $transactionDetails = $this->dbo->findOne('masters', 'transaction', $transactionFilter, array(), array());
            if (!$transactionDetails) {
                return false;
            }

            $orderitem = $orderDetails[order][orderitem];
            //print_r($orderitem);
            $transPaymentInfo = $transactionDetails['payment_info'];
            $transOrderInfo = $transactionDetails['order_info'];
            //GET PREVIOUS VENDORID AND CHECK IF THE PRESENT VENDOR IS DIFFERENT
            foreach ($orderDetails[order][provider_info] as $provider) {
                if ($provider[order][provider_info][component_no] == "9") {
                    $previousAssociateId = $provider[order][provider_info][associate_id];
                }
            }
            $orderitemcodes = array_column($orderitem, 'item_code');
            $payloaditemcodes = array();
            $orderitemcodeslength = count($orderitemcodes);
            $netAmount = 0;
            foreach ($eachorder->order_item as $item) {
                $payloaditemcodes[] = $item->item_code;
                if (in_array($item->item_code, $orderitemcodes)) {
                    $key = array_search($item->item_code, $orderitemcodes);
                    $orderItems[$key]['old_item_mrp'] = $orderItems[$key]['item_mrp'];
                    $orderItems[$key]['old_gross_amount'] = $orderItems[$key]['gross_amount'];
                    $orderItems[$key]['old_net_amount'] = $orderItems[$key]['net_amount'];
                    $orderitem[$key]["quantity"] = $item->quantity;
                    $orderitem[$key]["item_mrp"] = $item->item_mrp;
                    $orderitem[$key]["gross_amount"] = $item->gross_amount;
                    $orderitem[$key]["discount_amount"] = $item->discount_amount;
                    $orderitem[$key]["net_amount"] = $item->net_amount;
                    $orderitem[$key]["item_status"] = "0";
                    $orderitem[$key]["item_wallet"] = $item->item_wallet;
                    $orderitem[$key]["wallet_amount"] = $item->item_wallet;
                    $netAmount = $netAmount + $item->net_amount;
                } else {
                    $orderitem[$orderitemcodeslength] = $this->makeitemarray($item);
                    $orderitemcodeslength++;
                }
            }

            //IF ITEM_CODE IS NOT PRESENT IN PRESENT PAYLOAD IT IS CANCELLED
            $cancelledItems = array_diff($orderitemcodes, $payloaditemcodes);
            foreach ($cancelledItems as $key => $item) {
                $orderitem[$key]["item_status"] = "8";
                $orderitem[$key]["item_cancel_reason"] = "cancel from l2 screen on edit the order";
                $orderitem[$key]["item_cancel_date"] = (date("Y-m-d") . "T" . date("H:i:s") . ".000Z");
                $orderitem[$key]["item_wallet"] = 0;
                $orderitem[$key]["wallet_amount"] = 0;
                $orderitem[$key]["cancelbeforeaccept"] = "1"; 
            }

            $payable_amount = (float) $paymentDetails->payment_amount - $paidamount;
            if ($payable_amount < 0) {
                $payable_amount = 0;
            }
            $update = array(
                //"order.patientinfo.scheduled_date" => isset($eachorder->scheduled_date) ? $eachorder->scheduled_date : "",
                "order.patientinfo.prescription_later" => (string) $eachorder->prescription_later,
                //AMOUNTS UPDATION
                "payment_info.gross_amount" => $paymentDetails->gross_amount,
                "payment_info.net_amount" => $netAmount,
                "payment_info.discount_amount" => $paymentDetails->gross_amount - $netAmount,
                "payment_info.coupon_amount" => $paymentDetails->coupon_amount,
                "payment_info.payable_amount" => $paymentDetails->payment_amount,
                "payment_info.coupon" => isset($paymentDetails->coupon) ? $paymentDetails->coupon : "",
                "order.order_status.last_updated_on" => date("Y-m-d") . "T" . date("H:i:s") . ".000Z",
                "order.orderitem" => $orderitem,
            );

            //check the address
            if ($payload->orders[0]->address_id != $orderDetails[order][patientinfo][mrn]) {
                $gcm = new Gcm;
                $patient_address = $gcm->get_mrn_address_info(array($orderDetails[order][patientinfo][mrn]), array($payload->orders[0]->address_id));
                $addresDetails = $patient_address[address_id][$payload->orders[0]->address_id];
                $update['order.patientinfo.address_id'] = $addresDetails[address_id];
                $update['order.patientinfo.state'] = $addresDetails[state];
                $update['order.patientinfo.city'] = $addresDetails[city];
                $update['order.patientinfo.district'] = $addresDetails[district];
                $update['order.patientinfo.landmark'] = $addresDetails[landmark];
                $update['order.patientinfo.address'] = $addresDetails[address];
                $update['order.patientinfo.pincode'] = $addresDetails[pincode];
                $update['order.patientinfo.delivery_lat'] = $addresDetails[delivery_lat];
                $update['order.patientinfo.delivery_lng'] = $addresDetails[delivery_lng];
            }

            //check the vendor
            if ($payload->orders[0]->associate_id != $orderDetails[order][provider_info][0][associate_id]) {
                $medeq = new Medicine;
                $vendorinfo = $medeq->getVendorDetails($payload->orders[0]->associate_id);
                foreach ($vendorinfo as $key => $value) {
                    //$update['order.provider_info.$.' . $key] = $value;
                    $update['order.provider_info.0.' . $key] = $value;
                }
                if (!isset($orderDetails[order][provider_info][0][log])) {
                    $update['order.provider_info.0.log'] = array($orderDetails[order][provider_info][0]);
                } else {
                    $countval = count($orderDetails[order][provider_info][0][log]);
                    $update['order.provider_info.0.log.' . $countval . ''] = array($orderDetails[order][provider_info][0]);
                }
                $update['order.provider_info.0.vendor_assigned_date'] = date("Y-m-d H:i:s");
            }

            $prescriptionfile = isset($eachorder->prescription_images) ? $eachorder->prescription_images : "";
            $prescriptionarray = array();
            if ($prescriptionfile !== "") {
                /*$prescriptionexp = explode(",", $prescriptionfile);
                for ($i = 0; $i < count($prescriptionexp); $i++) {
                $prescriptionarray[$i][] = $prescriptionexp[$i];
                }*/

                $update['order.prescription_images'] = (array) $eachorder->prescription_images;
            }

            if (count($prescriptionarray) > $prescriptionfilelength) {
                $update["order.patientinfo.last_prescription_uploaded_byid"] = isset($eachorder->associate_id) ? $eachorder->associate_id : "";
                $update["order.patientinfo.last_prescription_uploaded_byname"] = isset($eachorder->loginname) ? $eachorder->loginname : "";
                $update["order.patientinfo.last_prescription_uploaded_Date"] = date("Y-m-d") . "T" . date("H:i:s") . ".000Z";
            }
            if ((count($prescriptionarray) == 1) && $eachorder->encounterid != "") {
                $update["order.patientinfo.last_prescription_uploaded_byid"] = "Doctor";
                $update["order.patientinfo.last_prescription_uploaded_byname"] = "Doctor";
                $update["order.patientinfo.last_prescription_uploaded_Date"] = date("Y-m-d") . "T" . date("H:i:s") . ".000Z";
            }
            $update["order.order_status.last_updated_on"] = date("Y-m-d") . "T" . date("H:i:s") . ".000Z";

            $set = $update;
            //print_r($set); exit;
            $options = array("multiple" => true);
            $orderupdate = $this->dbo->update('masters', 'orders', $filter, $set, array(), $options);
            //print_r($orderupdate); exit;
            if ($orderupdate[nModified] == 1) {
                // call change order status api

                $owf = new OrderWorkFlow;
                $pload = [
                    "actionById" => $actionById,
                    "actionByName" => $actionByName,
                    "order_id" => $eachorder->order_id,
                    "status" => 21,
                    "reasonType" => 1,
                    "reason" => "Assigned Vendor",
                    "source" => "L2",
                ];

                $tt = $owf->change_order_status((object) $pload, $ticket);
                //$response1 = array("status" => "1", "message" => "Successfully Updated", "data" =>array("order_id"=>$eachorder->order_id));

                $gross_amount = ($transOrderInfo->gross_amount - $patientInfo->gross_amount) + $paymentDetails->gross_amount;
                $discount_amount = ($transOrderInfo->discount_amount - $patientInfo->discount_amount) + ($paymentDetails->gross_amount - $paymentDetails->net_amount);
                $net_amount = ($transOrderInfo->net_amount - $patientInfo->net_amount) + $paymentDetails->payment_amount;
                //$voucher_amount = ($transOrderInfo->voucher_amount - $patientInfo->voucher_amount) + $paymentDetails->voucher_amount;
                $coupon_amount = ($transOrderInfo->coupon_amount - $patientInfo->coupon_amount) + $paymentDetails->coupon_amount;
                $wallet_amount = ($transOrderInfo->wallet_amount - $patientInfo->wallet_amount) + $paymentDetails->wallet_amount;
                $payment_amount = ($transPaymentInfo->payment_amount - $patientInfo->payable_amount) + $paymentDetails->payment_amount;

                $transactionArray = array(
                    //'payment_info.voucher_amount' => $voucher_amount,
                    'payment_info.wallet_amount' => $wallet_amount,
                    'payment_info.coupon_amount' => $coupon_amount,
                    'payment_info.payment_amount' => $payment_amount,
                    'order_info.0.gross_amount' => $gross_amount,
                    'order_info.0.discount_amount' => $discount_amount,
                    'order_info.0.net_amount' => $net_amount,
                    //'order_info.0.voucher_amount' => $voucher_amount,
                    'order_info.0.wallet_amount' => $wallet_amount,
                    'order_info.0.coupon_amount' => $coupon_amount,
                );
                $transactionUpdate = $this->dbo->update('masters', 'transaction', $transactionFilter, $transactionArray, array(), $options);
                $response = array("status" => "1", "message" => "Updated Successfully", "assignment" => $tt);
            }
        }
        return $response;
    }

    public function updateMedicineItem($payload, $ticket)
    {
        $obj = new Mdm;
        $omsorder_id = $payload->order_id;
        $item_code = $payload->item_code;
        $batchdata = $payload->batchdata;
        $response = array("status" => 0, "message" => "Operation Failed", "data" => "");
        $grossamount = 0;
        $itemmrp = 0;
        $qty = 0;
        $updateOrderArray = array();

        foreach ($batchdata as $bdat) {
            $grossamount = $grossamount + ((float) $bdat->mrp * (int) $bdat->quantity);
            $qty = $qty + $bdat->quantity;
        }
        $itemmrp = $grossamount / $qty;
        $orderfilter = array("_id" => (int) $omsorder_id);
        $orderDetails = $this->dbo->findOne('masters', 'orders', $orderfilter, array(), array());
        if (!$orderDetails) {
            $response["message"] = "Order is not found.";
            $response["data"] = array("response" => $orderDetails);
            return $response;
        }
        $payment_info = isset($orderDetails[payment_info]) ? $orderDetails[payment_info] : array();
        $patientInfo = isset($orderDetails[order][patientinfo]) ? $orderDetails[order][patientinfo] : array();
        $orderStatus = isset($orderDetails[order][order_status]) ? $orderDetails[order][order_status] : array();
        $orderItems = isset($orderDetails[order][orderitem]) ? $orderDetails[order][orderitem] : array();
        $providerInfo = isset($orderDetails[order][provider_info]) ? $orderDetails[order][provider_info] : array();
        $mrn = $patientInfo[mrn];
        $wallet_amount = (float) $payment_info[wallet_amount];
        $voucher_amount = (float) $payment_info[voucher_amount];
        //$walletstatus = (float) $payment_info[walletstatus]; // if previously wallet applied
        
		$walletstatus = $order_wallet_status = (float) isset($orderDetails[order][business][walletstatus]) ? $orderDetails[order][business][walletstatus] : 0;

        $MdmPayload = array();
        $itemKey = array_search($item_code, array_column($orderItems, 'code'));
        if ($orderItems[$itemKey]['item_mrp'] == $itemmrp) {
            $orderItems[$itemKey]['batch'] = (array) $batchdata;
            $orderItems[$itemKey]['batch_log'][] = (array) $batchdata;
            $updateOrderArray['order.orderitem'] = $orderItems;
            $options = array("multiple" => true);
            $orderupdate = $this->dbo->update('masters', 'orders', $orderfilter, $updateOrderArray, array(), $options);
            if ($orderupdate[nModified] == 1) {
                $response["status"] = 1;
                $response["data"] = array("order_id" => $omsorder_id, "itemcode" => $item_code, "batchdata" => (array) $batchdata);
                $response["message"] = "Successfully batch and expirty time is updated.";
            } else {
                $response["message"] = "Order is not found.";
                $response["data"] = array("response" => $orderupdate);
            }
        } else {
            /*if ($wallet_amount > 0 && $order_wallet_status == 0) {
                //return the wallet to customer
                $wallet_response = $this->walletTransaction("Medicine", $omsorder_id, "credit", $wallet_amount, $mrn, $ticket);
                if ($wallet_response["status"] == "1") {
                    $wallet_amount = 0;
                    $walletstatus = 1;
                }
            }*/
            $MdmPayload = $this->arrangeDurgPayloadAsPerMDM($orderDetails, $itemmrp, $item_code);
            //print_r($MdmPayload);exit;
            $res = $obj->checkPriceFromMDM($MdmPayload);
            //print_r($res);exit;
            // Add log for MDM Price Update asynchronous
            $addLogForMDM = $this->addLogForMDM($mrn, $omsorder_id, $MdmPayload, $res, "Price Updation - Order API", array());
            if ($res['status'] == 1 || $res['status'] == '1') {
                $prepaid_amount = 0;
                //set the array update structure according to
                $updateOrderArray = $this->rearrangeDurgOrderAsPerMDM($res, $orderItems, $item_code, $batchdata);
                //check the prepayment amount is there.
                if (isset($orderDetails[advance_receipt]) && count($orderDetails[advance_receipt]) > 0) {
                    foreach ($orderDetails[advance_receipt] as $receipts) {
                        if ($receipts["payment_mode"] == "voucher") {
                            continue;
                        }
                        $prepaid_amount = $prepaid_amount + (float) $receipts["receipt_amount"];
                    }
                }
				$walletamount = $wallet_amount;
                //update the wallet amount                
                if ($wallet_amount > 0 && (float)$res['data']['walletAmount'] < 0.1) {
					$walletamount=(float)$res['data']['walletAmount'];
					$updateOrderArray['payment_info.wallet_amount'] = $walletamount;
					$updateOrderArray['order.business.walletstatus'] = 1;
                    $updateOrderArray['order.business.orderModified'] = 1;
                }
                //correcte the payable amount
                $updateOrderArray['payment_info.payable_amount'] = $updateOrderArray['payment_info.payable_amount'] - ($walletamount + $prepaid_amount + $voucher_amount);
                // update the order amounts
                $options = array("multiple" => true);
                $orderupdate = $this->dbo->update('masters', 'orders', $orderfilter, $updateOrderArray, array(), $options);

                if ($orderupdate[nModified] == 1) {
					if ($wallet_amount > 0 && $order_wallet_status == 0) {
						//return the wallet to customer
						$updateOrderarr=array();
						$wallet_response = $this->walletTransaction("Medicine", $omsorder_id, "credit", $wallet_amount, $mrn, $ticket);
						$status = (int)$wallet_response["status"];
						if($status != 1) {
							$payable_amount = $payable_amount - (round($wallet_amount,2));
							if((float)$payable_amount<0){
								$payable_amount = 0;
							}					
							$updateOrderarr['payment_info.payable_amount'] = $payable_amount;
							$updateOrderarr['order.business.orderModified'] = 0;
							$updateOrderarr['payment_info.wallet_amount'] = 0;
							$updateOrderarr['order.business.walletstatus'] = 0;
							$updateOrderarr['order.business.wallet_final_deduct_status'] = 0;
							$orderupdate_for_wallet = $this->dbo->update('masters', 'orders', $orderfilter, $updateOrderarr, array(), ["multiple" => true]);
						}
					}
					
                    $transactionCode = $orderDetails['transaction_code'];
                    $transactionFilter = array("transaction_code" => $transactionCode);
                    $transactionDetails = $this->dbo->findOne('masters', 'transaction', $transactionFilter, array(), array());

                    $transOrderInfo = $transactionDetails['order_info'];
                    $transPaymentInfo = $transactionDetails['payment_info'];
                    $gross_amount = ($transOrderInfo->gross_amount - $patientInfo->gross_amount) + $res['data']['grossAmount'];
                    $discount_amount = ($transOrderInfo->discount_amount - $patientInfo->discount_amount) + ($res['data']['grossAmount'] - $res['data']['netAmount']);
                    $net_amount = ($transOrderInfo->net_amount - $patientInfo->net_amount) + $res['data']['netAmount'];
                    //$voucher_amount = ($transOrderInfo->voucher_amount - $patientInfo->voucher_amount) + $res['data']['voucherAmount'];
                    $coupon_amount = ($transOrderInfo->coupon_amount - $patientInfo->coupon_amount) + $res['data']['couponAmount'];
                    $wallet_amount = ($transOrderInfo->wallet_amount - $patientInfo->wallet_amount) + $res['data']['walletAmount'];
                    $payment_amount = ($transPaymentInfo->payment_amount - $patientInfo->payable_amount) + $res['data']['netAmount'];
                    $paymentGross = ($transPaymentInfo->gross_amount - $patientInfo->gross_amount) + $res['data']['grossAmount'];
                    $transactionArray = array(
                        'payment_info.gross_amount' => $paymentGross,
                        //'payment_info.voucher_amount' => $voucher_amount,
                        'payment_info.wallet_amount' => $wallet_amount,
                        'payment_info.coupon_amount' => $coupon_amount,
                        'payment_info.payment_amount' => $payment_amount,
                        'order_info.0.gross_amount' => $gross_amount,
                        'order_info.0.discount_amount' => $discount_amount,
                        'order_info.0.net_amount' => $net_amount,
                        //'order_info.0.voucher_amount' => $voucher_amount,
                        'order_info.0.wallet_amount' => $wallet_amount,
                        'order_info.0.coupon_amount' => $coupon_amount,
                    );
                    //print_r($transactionArray); exit;
                    $transactionUpdate = $this->dbo->update('masters', 'transaction', $transactionFilter, $transactionArray, array(), $options);

                    $response["status"] = 1;
                    $response["data"] = array("order_id" => $omsorder_id, "updatedInfo" => (array) $updateOrderArray);
                    $response["message"] = "Successfully Price updated.";
                } else {
                    $response["message"] = "Operation Faild please try again.";
                    $response["data"] = array("response" => $orderupdate);
                }
            } else {
                $response["message"] = "Operation Faild please try again.";
                $response["data"] = array("response" => $res);
            }
        }

        return $response;
        //echo json_encode($response);
    }

    public function rejectOrder($payload, $ticket)
    {
        $order_id = $payload->order_id;
        $itemIDs = (array) $payload->item_ids;
        $reject_reason = $payload->rejectreasons;
        $vendorID = $payload->vendorid;
        $vendor_name = $payload->vendorname;

        $Mdm = new Mdm;
        $response = array("status" => 0, "message" => "", "data" => array());
        $set = array();
        $filter = array("_id" => (int) $order_id,"OStatus"=>array('$ne'=>24));
        $cursor = $this->dbo->findOne("masters", "orders", $filter, array());

        if (count($cursor) > 0) {
            $order_wallet_amount = (float) isset($cursor[payment_info][wallet_amount]) ? $cursor[payment_info][wallet_amount] : 0;
            $order_wallet_status = (float) isset($cursor[order][business][walletstatus]) ? $cursor[order][business][walletstatus] : 0;
            $mrn = isset($cursor[order][patientinfo][mrn]) ? $cursor[order][patientinfo][mrn] : "";
            //Return the wallet amount
            if ($order_wallet_amount > 0 && $order_wallet_status == 0) {
                $wallet_response = $this->walletTransaction("Medicine", $order_id, "credit", $order_wallet_amount, $mrn, $ticket);
                //print_r($wallet_response); exit;
                if ($wallet_response["status"] == "1") {
                    $wallet_amount = 0;
                    $walletstatus = 1;
                    $set['payment_info.wallet_amount'] = $wallet_amount;
                    $set['order.business.walletstatus'] = $walletstatus;
                    $set['order.business.orderModified'] = 1;
                } else {
                    return array("status" => "0", "message" => "Failed", "description" => "Unable to credit wallet.");
                }

                //Get the transaction key
                /*$transactionkey = $Mdm->gettransactionkeyforwallet($mrn,$ticket);
            if($transactionkey[status]==1 && $transactionkey[data][value]!=""){
            $payload->mrn = $mrn;
            $payload->transactionkey = $transactionkey[data][value];
            $payload->amount = $order_wallet_amount;
            $result = $Mdm->creditwalletamtinmdm($payload,$ticket);
            if($wallet_response["status"]=="1"){
            $wallet_amount = 0;
            $walletstatus = 1;
            }
            /*if($result[status]==1 && strtolower($result[status][status])!="fail"){
            $set['order.patientinfo.wallet_amount']=0;
            //mdm log
            $data =array();
            $data['key']=$transactionkey;
            $data['mrn']=$mrn;
            $data['amount']=$order_wallet_amount;
            $apidata['order_id']=(int)$omsorder_id;
            $apidata['api']="Addwallet";
            $apidata['actiondate']=date("Y-m-d h:i:s");
            $apidata['requestdata']=$data;
            $apidata['result']=$result;
            $inserted_id = $collection23->insert($apidata);
            }else{

            }
            }else{
            return array("status"=>"0","message"=>"Failed","description"=>"Unable to credit wallet.");
            }*/
            }
            $i = 0;
            foreach ($cursor[order][orderitem] as $item) {
                if (in_array($item[item_code], $itemIDs)) {
                    $set['order.orderitem.' . $i . '.item_status'] = "9";
                    $set['order.orderitem.' . $i . '.item_reject_reason'] = $reject_reason;
                    $set['order.orderitem.' . $i . '.item_reject_date'] = date("Y-m-d") . "T" . date("H:i:s") . ".000Z";
                    $set['order.orderitem.' . $i . '.rejectioncount'] = ((int) isset($item['rejectioncount']) ? $item['rejectioncount'] : 0) + 1;
                }
                $i = $i + 1;
            }

            //$set['OStatus']=24;
            //$set['WOStatus']=24;
            //call to change status api by hemant
            $orderUpdate = $this->dbo->update('masters', 'orders', $filter, $set, array(), array());
            //print_r($orderUpdate); exit;
            if ($orderUpdate[nModified] == 1) {
                // call change order status api

                $owf = new OrderWorkFlow;
                $pload = ["actionById" => $vendorID, "actionByName" => $vendor_name, "order_id" => $order_id, "status" => 24, "reasonType" => 1, "reason" => $reject_reason];
                $tt = $owf->change_order_status((object) $pload, $ticket);
                $response = array("status" => "1", "message" => "Successfully Updated", "data" => array("order_id" => $order_id));
            } else {
                $response["message"] = "Item has not been rejected successfully. Please try again.";
            }
        } else {
            $response["message"] = "No data found for the request. Please check the parameters and try again";
        }
        return $response;
    }

    public function getPrescriptionByMrn($payload, $ticket)
    {
        $mrn = $payload->mrn;
        //$date = $payload->date;
        $currDate = $this->utility->getCurrentDate();
        //print_r($currDate);exit;
        $pastDate = date('Y-m-d', strtotime(date('Y-m-d', strtotime($currDate)) . ' -90 days'));

        $filter = array(
            "order.patientinfo.mrn" => (string) $mrn,
            "order.order_status.created_date" => array('$gte' => $pastDate, '$lte' => $currDate),
            '$or' => array(array("order.prescription_file" => array('$exists' => true)), array("order.prescription_images" => array('$exists' => true))),
        );
        //echo json_encode($filter);exit;
        $presData = $this->dbo->find("masters", "orders", $filter, array(), array("_id" => -1));

        $prescriptions = [];
        if (empty($presData)) {
            $response = array("status" => 0, "message" => "No prescription details found for past 3 months");
            return $response;
        } else { //echo "111";exit;
            foreach ($presData as $key => $order) {
                //print_r($order["order"]["prescription_images"]);exit;
                if (!empty($order["order"]["prescription_images"])) {
                    $prescriptions = array_merge($prescriptions, $order["order"]["prescription_images"]);
                    //print_r($total_prescriptions);exit;
                }
                if (!empty($order["order"]["prescription_file"])) {
                    foreach ($order["order"]["prescription_file"] as $tt) {
                        $prescriptions = array_merge($prescriptions, [['fullpath' => $tt[0]]]);
                    }
                    //print_r($total_prescriptions);exit;
                }
                //$final_prescription = array_merge($total_prescriptions1,$total_prescriptions2);
            }
            if (empty($prescriptions)) {
                $response = array("status" => 0, "message" => "No prescriptions found for this mrn. Please check the mrn and try again.","data" => []);
                return $response;
            } else {
                $response = array("status" => 1, "message" => "Prescriptions details found", "data" => $prescriptions);
                return $response;
            }
        }
    }

    public function add_update_vendor_inOMS($payload, $ticket)
    {
        try {
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "add_update_vendor_inOMS_start", json_encode($payload), (string) $ticket);

            $source_type = isset($payload->source_type) ? $payload->source_type : "";
            $api_key = isset($payload->api_key) ? $payload->api_key : "";
            $response = array("status" => "0", "message" => "Please check the request parameter.");

            $collection = 'medicine_vendors';
            if (isset($payload->isEquipmentVendor) and $payload->isEquipmentVendor == true) {
                $collection = 'mequipment_vendors';
            }
            if ($source_type == 'Associate Portal' && $api_key == 'zxcvbn-456873-asdfgh-065432') {
                $vendor_id = $payload->vendor_id;
                $vendor_name = $payload->vendor_name;
                $vendor_email = $payload->vendor_email;
                $vendor_address = $payload->vendor_address;
                $vendor_pincode = $payload->vendor_pincode;
                $vendor_statename = $payload->vendor_statename;
                $vendor_lat = isset($payload->vendor_lat) ? $payload->vendor_lat : "";
                $vendor_long = isset($payload->vendor_long) ? $payload->vendor_long : "";
                $vendor_mobile = isset($payload->vendor_mobile) ? $payload->vendor_mobile : "";
                $vendor_license = isset($payload->vendor_license) ? $payload->vendor_license : "";
                $vendor_gstno = isset($payload->vendor_gstno) ? $payload->vendor_gstno : "";
                $vendor_branch_id = isset($payload->vendor_branch_id) ? $payload->vendor_branch_id : "";
                $vendor_branch_Name = isset($payload->vendor_branch_Name) ? $payload->vendor_branch_Name : "";
                $serviceing_medicine_categories = isset($payload->serviceing_medicine_categories) ? $payload->serviceing_medicine_categories : "";

                $devide_vendor_id = explode("0", $vendor_id);
                $vendor_type = $devide_vendor_id[0];
                $sessionid = "";

                $sub_url = 'mdm/services/crud/PinCode/' . $vendor_pincode; //UPDATE CONFIG FILE TO UPDATE SUB_URL to""
                $url = $this->config->getConfig("cpservicepath", $sub_url);
                $headersetcurl = array("Content-Type: application/x-www-form-urlencoded", "Authorization:" . $sessionid);
                $fact_result = $this->utility->common_curl($url, array(), 0, $headersetcurl);
                $fact_result = json_decode($fact_result);
                $vendor_facility_id = $fact_result->facilityID;

                $filter = array("_id" => $vendor_id);
                $project = array();
                $vdetails = $this->dbo->find('masters', $collection, $filter, $project, array());
                //print_r($vdetails);exit;
                if (count($vdetails) > 0 and $vdetails != null) {
                    $set = array();
                    if (trim($vendor_name) != "") {$set["userinfo.USER_NAME"] = $vendor_name;}
                    if (trim($vendor_branch_id) != "") {$set["userinfo.USER_Branch_ID"] = $vendor_branch_id;}
                    if (trim($vendor_branch_Name) != "") {$set["userinfo.USER_Branch_NAME"] = $vendor_branch_Name;}
                    if (is_array($serviceing_medicine_categories) && count($serviceing_medicine_categories) > 0) {
                        $set["userinfo.serviceing_medicine_categories"] = $serviceing_medicine_categories;
                    }
                    if (trim($vendor_email) != "") {$set["userinfo.EMAIL"] = $vendor_email;}
                    if (trim($vendor_address) != "") {$set["userinfo.ADDRESS"] = $vendor_address;}
                    if (trim($vendor_lat) != "") {$set["userinfo.LAT"] = $vendor_lat;}
                    if (trim($vendor_long) != "") {$set["userinfo.LONG"] = $vendor_long;}
                    if (trim($vendor_mobile) != "") {$set["userinfo.MOBILE"] = $vendor_mobile;}
                    if (trim($vendor_license) != "") {$set["userinfo.License_No"] = $vendor_license;}
                    if (trim($vendor_gstno) != "") {$set["userinfo.GST_No"] = $vendor_gstno;}

                    $result = $this->dbo->update("masters", $collection, $filter, $set, array(), array("multiple" => true));
                    if ($result[nModified] > 0) {
                        $response['status'] = '1';
                        $response['message'] = 'Vendor Updated Successfully';
                    } else if ($result[ok] == 1) {
                        $response['status'] = '1';
                        $response['message'] = 'Vendor details unchanged.';
                    }
                } else {
                    $insertdata = array(
                        '_id' => $vendor_id,
                        'userinfo' => array(
                            'USER_ID' => $vendor_id,
                            'USER_NAME' => $vendor_name,
                            'USER_Branch_ID' => $vendor_branch_id,
                            'USER_Branch_NAME' => $vendor_branch_Name,
                            'EMAIL' => $vendor_email,
                            'PASSWORD' => '2ac9cb7dc02b3c0083eb70898e549b63',
                            'ACTIVE_INACTIVE_E' => '1',
                            'FACILITY_ID' => "" . $vendor_facility_id,
                            'vendor_type' => $vendor_type,
                            'GROUP_NAME' => 'Vendor',
                            'GROUP_ID' => '10001',
                            "ADDRESS" => $vendor_address,
                            "LAT" => $vendor_lat,
                            "LONG" => $vendor_long,
                            "MOBILE" => $vendor_mobile,
                            "License_No" => $vendor_license,
                            "GST_No" => $vendor_gstno,
                            'STATE' => array(array('statename' => $vendor_statename)),
                        ),
                        'service_pop' => array(array('FACILITY_NAME' => '', 'FACILITY_NAME' => '')),
                    );

                    $inserted_id = $this->dbo->insert("masters", $collection, $insertdata);
                    if ($inserted_id[ok] == "1" || $inserted_id[ok] == 1) {
                        $response['status'] = '1';
                        $response['message'] = 'Vendor Added Successfully';
                    }
                }
            } else {
                $response['message'] = "API Key or Source Type not Matched!";
            }
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "add_update_vendor_inOMS_end", $response, (string) $ticket);
        } catch (Exception $e) {
            $response = array("status" => "0", "errorMessage" => $e->getMessage());
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "add_update_vendor_inOMS_Error", $response, (string) $ticket);
        }
        return $response;
    }

    public function item_cancel_L2($payload, $ticket)
    {
        $order_id = $payload->order_id;
        $item_code = $payload->item_code;
        $cancel_reason = $payload->cancel_reason;
        $actionById = $payload->actionById;
        $actionByName = $payload->actionByName;

        if (empty($order_id) || empty($item_code) || empty($cancel_reason) || empty($actionById) || empty($actionByName)) {
            return array("status" => 0, "code" => "10200", "message" => "Invalid input, required fields are missing(order_id,item_code,cancel_reason,actionById,actionByName)");
        }
        $filter = array(_id => (int) $order_id);
        $order = $this->dbo->findOne("masters", "orders", $filter, array());
        if (empty($order)) {
            return array("status" => 0, "code" => "10300", "message" => "Invalid Order id");
        }

        if (!isset($order['order']['orderitem']) && count($order['order']['orderitem']) < 1) {
            return array("status" => 0, "code" => "10300", "message" => "Thser is no item availble for cancel.");
        }

        $payment_info = isset($order['payment_info']) ? $order['payment_info'] : [];
        $patientInfo = isset($order['order']['patientinfo']) ? $order['order']['patientinfo'] : array();
        $orderStatus = isset($order['order']['order_status']) ? $order['order']['order_status'] : array();
        $orderItems = isset($order['order']['orderitem']) ? $order['order']['orderitem'] : array();
        $providerInfo = isset($order['order']['provider_info']) ? $order['order']['provider_info'] : array();
        $mrn = $patientInfo['mrn'];
        $wallet_amount = (float) $payment_info['wallet_amount'];
        $voucher_amount = (float) $payment_info['voucher_amount'];

        $MdmPayload = array();
        $itemKey = array_search($item_code, array_column($order['order']['orderitem'], 'item_code'));
        //$item_mrp = $orderItems[$itemKey]['item_mrp'];
        $item_status = $order['order']['orderitem'][$itemKey]['item_status'];
        if ($item_status == 8) {
            return array("status" => 0, "code" => "10500", "message" => "orderitem is already cancelled");
        }

        $order['order']['orderitem'][$itemKey]["item_status"] = "8";
        $order['order']['orderitem'][$itemKey]["item_cancel_on"] = "Vendor Rejection";
        $order['order']['orderitem'][$itemKey]["item_cancel_reason"] = $cancel_reason;
        $order['order']['orderitem'][$itemKey]["item_cancel_byID"] = $actionById;
        $order['order']['orderitem'][$itemKey]["item_cancel_byName"] = $actionByName;
        $order['order']['orderitem'][$itemKey]["item_cancel_datetime"] = date('Y-m-d H:i:s');
        $orderItems = $order['order']['orderitem'];
        //print_r($orderItems); exit;
        /*$cancelItem = $orderItems[$itemKey];
        $cancelItem["item_status"] = "8";
        $cancelItem["item_cancel_reason"] = $cancel_reason;
        $cancelItem["item_cancel_datetime"] = date('Y-m-d H:i:s');*/

        if ($wallet_amount > 0) {
            //return the wallet to customer
            $wallet_response = $this->walletTransaction("Medicine", $order_id, "credit", $wallet_amount, $mrn, $ticket);
            if ($wallet_response["status"] == "1") {
                $wallet_amount = 0;
            }
        }

        $MdmPayload = $this->arrangeDurgPayloadAsPerMDM($order, "", "");

        if (!isset($MdmPayload[LineItems]) || count($MdmPayload[LineItems]) < 1) {
            return array("status" => 0, "code" => "10501", "message" => "Item cancel is not possible, please do the order cancel");
        }

        $mdm = new mdm;
        $res = $mdm->checkPriceFromMDM($MdmPayload); // send to MDM for price calculation

        // Add log for MDM Price Update asynchronous
        $this->addLogForMDM($mrn, $order_id, $MdmPayload, $res, "Price Updation - Order API", array());

        if ($res['status'] == 1) {
            $prepaid_amount = 0;
            //set the array update structure according to
            $updateOrderArray = $this->rearrangeDurgOrderAsPerMDM($res, $orderItems, $item_code, $batchdata = []); // need to work here rearrangeDurgOrderAsPerMDM()
            //check the prepayment amount is there.
            if (isset($order['advance_receipt']) && count($order['advance_receipt']) > 0) {
                foreach ($order['advance_receipt'] as $receipts) {
                    /*if ($receipts["payment_mode"] == "voucher") {
                    continue;
                    }*/
                    $prepaid_amount = $prepaid_amount + (float) $receipts["receipt_amount"];
                }
            }

            //add cancel item into `orderitem` array Bcoz it was skiped while creating MDMPayload
            //array_push($updateOrderArray['order.orderitem'], $cancelItem);
            $updateOrderArray['payment_info.wallet_amount'] = $wallet_amount;
            $updateOrderArray['payment_info.payable_amount'] = $updateOrderArray['payment_info.payable_amount'] - ($wallet_amount + $prepaid_amount);
            //return  $updateOrderArray;
            $orderupdate = $this->dbo->update('masters', 'orders', $filter, $updateOrderArray, array(), ["multiple" => true]);
            //$orderupdate[nModified] = 1;

            if ($orderupdate[nModified] == 1) {

                // update transaction
                $transactionFilter = array("transaction_code" => $order['transaction_code']);
                $txnDtl = $this->dbo->findOne('masters', 'transaction', $transactionFilter, [], []);
                $transOrderInfo = $txnDtl['order_info'];

                // get current order order_info item
                $itemKey = array_search($order_id, array_column($transOrderInfo, 'order_id'));
                $transOrderInfo[$itemKey]['gross_amount'] = $updateOrderArray['payment_info.gross_amount'];
                $transOrderInfo[$itemKey]['discount_amount'] = $updateOrderArray['payment_info.discount_amount'];
                $transOrderInfo[$itemKey]['net_amount'] = $updateOrderArray['payment_info.net_amount'];
                $transOrderInfo[$itemKey]['voucher_amount'] = $updateOrderArray['payment_info.voucher_amount'];
                $transOrderInfo[$itemKey]['wallet_amount'] = $updateOrderArray['payment_info.wallet_amount'];
                $transOrderInfo[$itemKey]['coupon_amount'] = $updateOrderArray['payment_info.coupon_amount'];
                $transOrderInfo[$itemKey]['payable_amount'] = $updateOrderArray['payment_info.payable_amount'];

                foreach ($transOrderInfo as $item) {
                    $paymentGross += floatval($item['gross_amount']);
                    $net_amount += floatval($item['net_amount']);
                    $discount_amount += floatval($item['discount_amount']);
                    //$voucher_amount += floatval($item['voucher_amount']);
                    $wallet_amount += floatval($item['wallet_amount']);
                    $coupon_amount += floatval($item['coupon_amount']);
                    $payment_amount += floatval($item['payment_amount']);
                    $payable_amount += floatval($item['payable_amount']);
                }

                $transactionArray = array(
                    'payment_info.gross_amount' => round($paymentGross, 2),
                    'payment_info.net_amount' => round($net_amount, 2),
                    'payment_info.discount_amount' => round($discount_amount, 2),
                    //'payment_info.voucher_amount' => round($voucher_amount, 2),
                    'payment_info.wallet_amount' => round($wallet_amount, 2),
                    'payment_info.coupon_amount' => round($coupon_amount, 2),
                    'payment_info.payment_amount' => round($payment_amount, 2),
                    'payment_info.payable_amount' => round($payable_amount, 2),
                );
                $transactionArray['order_info'] = $transOrderInfo;
                //return $transactionArray;
                $transactionUpdate = $this->dbo->update('masters', 'transaction', $transactionFilter, $transactionArray, [], []);
                return array("status" => 1, "code" => "10100", "message" => "Lineitem cancelled successfully");
            } else {
                return array("status" => 0, "code" => "10400", "message" => "Operation Failed, please try again.");
            }
        } else {
            return array("status" => 0, "code" => "10400", "message" => "Operation Failed, please try again.");
        }
    }

    public function order_accept_by_vendor($payload, $ticket)
    {
        $order_id = $payload->order_id;
        $actionById = $payload->actionById;
        $actionByName = $payload->actionByName;

        if (empty($order_id) || empty($actionById) || empty($actionByName)) {
            return array("status" => 0, "code" => "10200", "message" => "Invalid input, required fields are missing(order_id,actionById,actionByName)");
        }
        $filter = array(_id => (int) $order_id);
        $order = $this->dbo->findOne("masters", "orders", $filter, array());
        if (empty($order)) {
            return array("status" => 0, "code" => "10300", "message" => "Invalid Order id");
        }

        $payment_info = isset($order['payment_info']) ? $order['payment_info'] : [];
        $patientInfo = isset($order['order']['patientinfo']) ? $order['order']['patientinfo'] : array();
        $orderStatus = isset($order['order']['order_status']) ? $order['order']['order_status'] : array();
        $orderItems = isset($order['order']['orderitem']) ? $order['order']['orderitem'] : array();
        $providerInfo = isset($order['order']['provider_info']) ? $order['order']['provider_info'] : array();
        $mrn = $patientInfo['mrn'];
        $wallet_amount = (float) $payment_info['wallet_amount'];
        $walletstatus = (float) $order['order']['business']['walletstatus'];
        $wallet_final_deduct_status = (float) isset($order['order']['business']['walletstatus'])?$order['order']['business']['walletstatus']:0;
        //$voucher_amount = (float) $payment_info['voucher_amount'];

        if ($order['order']['business']['orderModified'] == 1) {

            // callMadRules and wallet amount
            $MdmPayload = array();
            //$item_mrp = $orderItems[$itemKey]['item_mrp'];
            $MdmPayload = $this->arrangeDurgPayloadAsPerMDM($order, "", "");
            if (($walletstatus && floatval($wallet_amount) == 0) || ($walletstatus == 0 && floatval($wallet_amount) > 0)) {
                $MdmPayload['useWallet'] = "true";
            }else{
				$MdmPayload['useWallet'] = "false";
			}

            // Add log for MDM Price Update asynchronous
            $mdm = new mdm;
            $res = $mdm->checkPriceFromMDM($MdmPayload); // send to MDM for price calculation

            // Add log for MDM Price Update asynchronous
            $this->addLogForMDM($mrn, $order_id, $MdmPayload, $res, "Price Updation - Order API", array());

            if ($res['status'] != 1) {
                return array("status" => 0, "code" => "10400", "message" => "Operation Failed from MDM, please try again.");
            }

            $wallet_amount = 0;
            if(isset($res['data']['walletAmount']) && (float)$res['data']['walletAmount']>0 && $MdmPayload['useWallet'] == "true"){
                $wallet_amount = (float)$res['data']['walletAmount'];
                $wallet_final_deduct_status = 1;
            }
			
            //foreach ($res['WalletUsageList'] as $item) {
                /*if ((float)$res['data']['walletAmount'] > 0) {
                    $wallet_response = $this->walletTransaction("Medicine", $order_id, "debit",(float)$res['data']['walletAmount'],$order['order']['patientinfo']['mrn'], $ticket);
                   
					$status = (int)$wallet_response["status"];
                    if($status == 1) {
						$wallet_amount = (float)$res['data']['walletAmount'];
                    }
                }*/
            //}
			//print_r((float)$res['data']);exit;
            $prepaid_amount = 0;
            $updateOrderArray = $this->rearrangeDurgOrderAsPerMDM($res, $orderItems, $item_code, $batchdata = [],$MdmPayload['useWallet']);

            //check the prepayment amount
            if (isset($order['advance_receipt']) && count($order['advance_receipt']) > 0) {
                foreach ($order['advance_receipt'] as $receipts) {
                    if ($receipts["type"] != 2) {
                        $prepaid_amount = $prepaid_amount + (float) $receipts["receipt_amount"];
                    }

                }
            }

            $updateOrderArray['order.business.wallet_final_deduct_status'] = $wallet_final_deduct_status;
            $updateOrderArray['payment_info.wallet_amount'] = $wallet_amount;
            $updateOrderArray['payment_info.payable_amount'] = round($updateOrderArray['payment_info.payable_amount'],2) - (round($wallet_amount,2) + round($prepaid_amount,2));
			$payable_amount = $updateOrderArray['payment_info.payable_amount'];
			if((float)$updateOrderArray['payment_info.payable_amount']<0){
				$updateOrderArray['payment_info.payable_amount'] = 0;
			}
			
            //return $updateOrderArray;

            $orderupdate = $this->dbo->update('masters', 'orders', $filter, $updateOrderArray, array(), ["multiple" => true]);
            $orderupdate[nModified] = 1;

            if ($orderupdate[nModified] == 1) {
				//wallet deduction code
				if ((float)$res['data']['walletAmount'] > 0){
					$updateOrderarr=array();
                    $wallet_response = $this->walletTransaction("Medicine", $order_id, "debit",(float)$res['data']['walletAmount'],$order['order']['patientinfo']['mrn'], $ticket);
					$status = (int)$wallet_response["status"];
                    if($status != 1) {
						$payable_amount = $payable_amount + (round($wallet_amount,2));
						if((float)$payable_amount<0){
							$payable_amount = 0;
						}					
						$updateOrderarr['payment_info.payable_amount'] = $payable_amount;
						$updateOrderarr['payment_info.wallet_amount'] = 0;
						$updateOrderarr['order.business.wallet_final_deduct_status'] = 0;
						$orderupdate_for_wallet = $this->dbo->update('masters', 'orders', $filter, $updateOrderarr, array(), ["multiple" => true]);
                    }
                }
				////
				//MDM CALL	
				/* $wallet_amount = 0;
			
				//foreach ($res['WalletUsageList'] as $item) {
					if ((float)$res['data']['walletAmount'] > 0) {
						$wallet_response = $this->walletTransaction("Medicine", $order_id, "debit",(float)$res['data']['walletAmount'],$order['order']['patientinfo']['mrn'], $ticket);
						//print_r($wallet_response);exit;
						//if ($wallet_response["status"] == "1") {
						//	$wallet_amount += $item['walletAmount'];
						// }
						$status = (int)$wallet_response["status"];
						if($status == 1) {
							$wallet_amount = (float)$res['data']['walletAmount'];
						}
					}
				//}
				//print_r((float)$res['data']);exit; */
				////

                // update transaction
                $transactionFilter = array("transaction_code" => $order['transaction_code']);
                $txnDtl = $this->dbo->findOne('masters', 'transaction', $transactionFilter, [], []);
                $transOrderInfo = $txnDtl['order_info'];

                // get current order order_info item
                $itemKey = array_search($order_id, array_column($transOrderInfo, 'order_id'));
                $transOrderInfo[$itemKey]['gross_amount'] = $updateOrderArray['payment_info.gross_amount'];
                $transOrderInfo[$itemKey]['discount_amount'] = $updateOrderArray['payment_info.discount_amount'];
                $transOrderInfo[$itemKey]['net_amount'] = $updateOrderArray['payment_info.net_amount'];
                $transOrderInfo[$itemKey]['voucher_amount'] = $updateOrderArray['payment_info.voucher_amount'];
                $transOrderInfo[$itemKey]['wallet_amount'] = $updateOrderArray['payment_info.wallet_amount'];
                $transOrderInfo[$itemKey]['coupon_amount'] = $updateOrderArray['payment_info.coupon_amount'];
                $transOrderInfo[$itemKey]['payable_amount'] = $updateOrderArray['payment_info.payable_amount'];

                foreach ($transOrderInfo as $item) {
                    $paymentGross += floatval($item['gross_amount']);
                    $net_amount += floatval($item['net_amount']);
                    $discount_amount += floatval($item['discount_amount']);
                    $voucher_amount += floatval($item['voucher_amount']);
                    $wallet_amount += floatval($item['wallet_amount']);
                    $coupon_amount += floatval($item['coupon_amount']);
                    $payment_amount += floatval($item['payment_amount']);
                    $payable_amount += floatval($item['payable_amount']);
                }

                $transactionArray = array(
                    'payment_info.gross_amount' => round($paymentGross, 2),
                    'payment_info.net_amount' => round($net_amount, 2),
                    'payment_info.discount_amount' => round($discount_amount, 2),
                    'payment_info.voucher_amount' => round($voucher_amount, 2),
                    'payment_info.wallet_amount' => round($wallet_amount, 2),
                    'payment_info.coupon_amount' => round($coupon_amount, 2),
                    'payment_info.payment_amount' => round($payment_amount, 2),
                    'payment_info.payable_amount' => round($payable_amount, 2),
                );
                $transactionArray['order_info'] = $transOrderInfo;
                //return $transactionArray;
                $transactionUpdate = $this->dbo->update('masters', 'transaction', $transactionFilter, $transactionArray, [], []);
            }

            return array("status" => 1, "code" => "10100", "message" => "Vendor accepted successfully");
        } else {
			return array("status" => 1, "code" => "10100", "message" => "Vendor accepted successfully");
            //return array("status" => 0, "code" => "10400", "message" => "Operation Failed, please try again.");
        }
    }

    public function reminder_request()
    {
        return "hello";
    }

    public function upload_invoice_to_blob($payload)
    {
        $file_mode = $payload['file_mode']; //INVOICE
        $order_id = intval($payload['order_id']);
        $blob_container = 'oms';
        if (empty($payload['order_id']) || empty($payload['file_mode']) || empty($_FILES["file"])) {
            return array("status" => 0, "code" => "10200", "message" => "Required fields are missing:order_id,file_mode,file");
        }

        $filter = array("_id" => $order_id);
        $doc = $this->dbo->findOne("masters", "orders", $filter, []);
        if (empty($doc)) {
            return array("status" => 0, "code" => "10300", "message" => "Invalid order id");
        }
        $rss = null;

        $numOfFiles = count($_FILES["file"]['name']);
        for ($i = 0; $i < $numOfFiles; $i++) {
            if (!($obj["file"]['error'][$i] == 0 && $_FILES["file"]['size'][$i] > 0)) {
                return array("status" => 0, "code" => "10400", "message" => "Invalid File");
            }
        }
        $urls = [];

        for ($i = 0; $i < $numOfFiles; $i++) {
            $content = fopen($_FILES["file"]["tmp_name"][$i], 'r');
            $filename = $_FILES["file"]['name'][$i];
            $filePath = $doc['order']['patientinfo']['mrn'] . '/' . 'invoices' . '/' . $order_id . '/' . $filename;
            $filePath = str_replace(' ', '', $filePath);
            $rss = $this->utility->blob_upload_block($blob_container, $filePath, $content);
            if ($rss) {
                // update to order
                $push["order.associate_invoice"] = array(
                    '_id' => $this->dbo->id(),
                    'relative_path' => $filePath,
                    'absolute_path' => AZURE_BASE_PATH . $blob_container . '/' . $filePath,
                    'filename' => $filename,
                    'server_path' => AZURE_BASE_PATH,
                );
                $urls[] = AZURE_BASE_PATH . $blob_container . '/' . $filePath;
                $set = [];
                $cursor = $this->dbo->update("masters", "orders", $filter, $set, $push, array());
            }
        }

        if ($rss) {
            $url = AZURE_BASE_PATH . $filePath;
            return array("status" => 1, "code" => "10100", "message" => "File uploaded successfully", "data" => ["urls" => $urls]);
        } else {
            return array("status" => 0, "code" => "10500", "message" => "Upload failed, Try later");
        }
    }

	public function deletePrescription($payload,$ticket)
    {
		try
		{
			$this->log->create_log("", "", $this->getname(), "Execution", 200, "deletePrescription_start", json_encode($payload), (string) $ticket);
			$order_id = (int)$payload->order_id;
			$mrn = isset($payload->mrn)?$payload->mrn:"";
			$filename = $payload->filename;
			
			$filter = array("_id"=>$order_id);
			$ordDoc = $this->dbo->findOne('masters','orders',$filter,array());
			//print_r($ordDoc);exit;
			$response = array("status"=>0,"message"=>"Operation Failed");
			
			$urlFlag = 0;
			if(isset($payload->url) and $payload->url!="")
			{
				//IF DIRECTLY GIVEN URL
				$file_to_delete = trim($payload->url);
				$urlFlag = 1;
			}
			else
			{
				if($ordDoc['OStatus'] != 1000 and $ordDoc['OStatus'] != 1001)
				{
					$response = array("status"=>0,"message"=>"Action not possible at this order status");
					$this->log->create_log("", "", $this->getname(), "Execution", 200, "deletePrescription_end", json_encode($response), (string) $ticket);
					return $response;
				}
				
				$prescription_images = $ordDoc[order][prescription_images];
				if($prescription_images!= null and !empty($prescription_images))
				{
					$files = array_column($prescription_images, 'filename');
					$pos = array_search($filename, $files);
					
					if($pos === false)
					{
						$response = array("status"=>0,"message"=>"Prescriptions are not available with the filename");
						$this->log->create_log("", "", $this->getname(), "Execution", 200, "deletePrescription_end", json_encode($response), (string) $ticket);
						return $response;
					}
					
					$file_to_delete = $prescription_images[$pos]['fullpath'];					
				}
				else
				{
					$response = array("status"=>0,"message"=>"Action not possible no prescriptions are available");
					$this->log->create_log("", "", $this->getname(), "Execution", 200, "deletePrescription_end", json_encode($response), (string) $ticket);
					return $response;
				}
			}
			
			//CONVERT URL TO SERVER PATH
			$domain = $this->config->getconfig('domainurl',"");
			$rootpath = $this->config->getconfig("rootpath","");
			
			$file_to_delete = str_replace($domain ,$rootpath ,$file_to_delete);
			
			//$file_to_delete = str_replace('https://omsuatv3.callhealth.com','/var/www/html',$file_to_delete);
			
			if (file_exists($file_to_delete))
			{
				try
				{
					$val = unlink($file_to_delete);
				}
				catch(Exception $e)
				{
					$response = array("status"=>0,"Error"=>$e->getMessage());
					$this->log->create_log("", "", $this->getname(), "Execution", 300, "deletePrescription_Error", json_encode($response), (string) $ticket);
					return $response;
				}
				
				if($val)  
				{
					if($urlFlag == 1)
					{
						$response = array("status"=>1,"message"=>"Prescription removed successfully");
						$this->log->create_log("", "", $this->getname(), "Execution", 200, "deletePrescription_end", json_encode($response), (string) $ticket);
						return $response;
					}
					
					$del_prescription = $prescription_images[$pos]; //ADD TO DELETED PRESCRIPTIONS
					//unset($prescription_images[$pos]); //DELETE FROM PRESCRIPTIONS
					
					array_splice($prescription_images, $pos, 1); //DELETE FROM PRESCRIPTIONS
					
					$set = array("order.prescription_images"=> $prescription_images);
					if(empty($prescription_images))
					{
						$set["order.patientinfo.prescription_later"] = "1";
						$set["OStatus"] = 1001;
						$set["WOStatus"] = 1001;
						$set["order.order_status.order_status"] = 1001;
					}
					
					$push = array("order.deleted_prescriptions"=>$del_prescription);
					
					try
					{
						$upd_resp = $this->dbo->update('masters','orders',$filter,$set,$push,array());
						if($upd_resp['nModified'] > 0)
						{
							$response = array("status"=>1,"message"=>"Prescription removed successfully");
							$this->log->create_log("", "", $this->getname(), "Execution", 200, "deletePrescription_end", json_encode($response), (string) $ticket);
							return $response;
						}
					}
					catch(Exception $e)
					{
						$response = array("status"=>0,"QueryError"=>$e->getMessage());
						$this->log->create_log("", "", $this->getname(), "Execution", 300, "deletePrescription_Error", json_encode($response), (string) $ticket);
						return $response;
					}
				}
				else
				{
					$response = array("status"=>0,"message"=>"Problem deleting file, try again");
					$this->log->create_log("", "", $this->getname(), "Execution", 200, "deletePrescription_end", json_encode($response), (string) $ticket);
					return $response;
				}
				
			}
			else
			{
				$response = array("status"=>0,"message"=>"Prescription not available on server");
				$this->log->create_log("", "", $this->getname(), "Execution", 200, "deletePrescription_end", json_encode($response), (string) $ticket);
				return $response;
			}
			
			return $response;
		}
		catch(Exception $e)
		{
			$response = array("status"=>0,"Error"=>$e->getMessage());
			$this->log->create_log("", "", $this->getname(), "Execution", 300, "deletePrescription_Error", json_encode($response), (string) $ticket);
			return $response;
		}
	}
	
	public function orderExportCSV($vendorid){       
        $filter = array(
			"order.patientinfo.service_type"=>'2',
			"order.provider_info.associate_id"=>$vendorid
		);
        $sort = array('order.order_status.created_date' => -1);
        $orderdetails = $this->dbo->find('masters', 'orders', $filter, array(),$sort);
		$filter_status = array(
			"Bid"=>'2'
		);
        $orderstatues = $this->dbo->find('masters', 'workflow_status', $filter_status, array(),array());
        $order_status = array();
		foreach ($orderstatues as $doc) {
		    $order_status[$doc[Workflow]."".$doc[status]."".$doc[MOSid]]=$doc[Nomenclature];
		}
		//print_r($order_status); exit;
		//$order_status = $order_status[0]; 
	
		$fp = fopen('php://output', 'w');
		header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=allorders.csv');
        fputcsv($fp, $header);
        $num_column = count($header);
        fputcsv($fp, array('MRN','Name','SourceType','OrderID','City','Created Date','Status'));
 
        foreach ($orderdetails as $document) {
		    fputcsv($fp, array(
				$document['order']['patientinfo']['mrn'],
				$document['order']['patientinfo']['name'],
				CHANNEL[(int)$document['channel']],
				$document['_id'],
				$document['order']['patientinfo']['city'],
				$document['order']['order_status']['created_date'],
				$order_status[$document['active_component']."".$document['OStatus']."".$document['mode_of_service']]
			)); 
		  //fputcsv($fp, $document);
		}     
   }
}
