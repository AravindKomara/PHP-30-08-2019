<?php

require_once '../libraries/OMS_Redis.php';
class Rtct extends Oms
{
    public $timeOffset = (3600 * 9) + (60 * 37); // difference between php+sys to db : SEarch Clause
    public $DbtimeOffset = 19800; // difference between db mongotime to php : READ call
    public function __construct()
    {
        parent::__construct();

    }

    public function getname()
    {
        return "returns";
    }

    public function get_orders($payload, $ticket)
    {
        $mode = $payload->mode; // ALL|RED|AMBER|GREEN|PINNED
        $page = $payload->page;
        $records_per_page = intval($payload->records_per_page);

        // optional params for filters
        $mrn = intval($payload->mrn);
        $odid = $payload->odid;
        $code = $payload->code;
        $business_id = $payload->business_id;
        $customer_name = $payload->customer_name;
        $associate_name = $payload->associate_name;
        $associate_id = $payload->associate_id;
        $branch_id = (String) $payload->branch_id;
        $officer_id = (String) $payload->officer_id;
        $officer_name = $payload->officer_name;
        $search_date = $payload->search_date; // YYYY-MM-DD i.e 2019-07-24
        $user_id = $payload->user_id;
        // workorder

        $result = [];
        if (empty($mode) || !isset($page)) {
            return array("success" => 0, "code" => "10200", "message" => "Invalid Input Or Required fields are missing");
        }

        if ($mode == 'PINNED' && empty($user_id)) {
            return array("success" => 0, "code" => "10300", "message" => "user_id is required.");
        }
        $limit = 15;
        if (!empty($records_per_page)) {
            $limit = $records_per_page;
        }
        $skip = 0;
        if (intval($page) > 1) {
            $skip = (intval($page) - 1) * $limit;
        }

        // take decision wheather search_date is past current or future
        $date_flag = 'CURRENT';
        $search_date_mongo = $this->dbo->date(time() + $this->timeOffset);
        $search_date_mongo_from = $this->dbo->date(strtotime(date('Y-m-d') . ' 00:00:00') + $this->timeOffset);
        $search_date_mongo_to = $this->dbo->date(strtotime(date('Y-m-d') . ' 23:59:59') + $this->timeOffset);
        if (!empty($search_date)) {
            if (strtotime($search_date) > time() && date('d', strtotime($search_date)) != date('d')) {
                $date_flag = 'FUTURE';
            }
            if (strtotime($search_date) < time() && date('d', strtotime($search_date)) != date('d')) {
                $date_flag = 'PAST';
            }
            $search_date_mongo_from = $this->dbo->date(strtotime($search_date . ' 00:00:00') + $this->timeOffset);
            $search_date_mongo_to = $this->dbo->date(strtotime($search_date . ' 23:59:59') + $this->timeOffset);
        }
        $match = [
            'event_date' => [
                '$gte' => $search_date_mongo,
            ],
        ];
        if ($mode == 'RED' || $mode == 'GREEN') {
            //$match = array_merge($match, ["color" => $mode]);
        }
        $pinned_orders = [];
        if (!empty($user_id)) {
            // get orderids
            $filter = array('user_id' => (String) $user_id);
            $res = $this->dbo->find("masters", "rtct_orders_pinned", $filter, ['order_id' => 1, '_id' => 0]);
            if (!empty($res)) {
                foreach ($res as $odr) {
                    $pinned_orders[] = (int) $odr['order_id'];
                }
                $pinned_orders = array_values(array_unique($pinned_orders));
                if ($mode == 'PINNED') {
                    $match = array_merge($match, ["order_id" => ['$in' => $pinned_orders]]);
                }
            }
        }
        if (!empty($mrn)) {
            $match = array_merge($match, ["mrn" => $mrn]);
        }
        if (!empty($odid)) {
            $match = array_merge($match, ["odid" => $this->dbo->mongoRegex($odid)]);
        }
        if (!empty($business_id)) {
            if (is_array($business_id)) {
                $business_id = array_map('intval', $business_id);
                $match = array_merge($match, ["business_id" => ['$in' => $business_id]]);
            }
            if (is_string($business_id)) {
                $match = array_merge($match, ["business_id" => intval($business_id)]);
            }
        }
        if (!empty($customer_name)) {
            $match = array_merge($match, ["name" => $this->dbo->mongoRegex($customer_name)]);
        }
        if (!empty($associate_name)) {
            $match = array_merge($match, ["associate_name" => $this->dbo->mongoRegex($associate_name)]);
        }
        if (!empty($associate_id)) {
            $match = array_merge($match, ["associate_id" => $associate_id]);
        }
        if (!empty($branch_id)) {
            $match = array_merge($match, ["branch_id" => $branch_id]);
        }
        if (!empty($officer_id)) {
            $match = array_merge($match, ["officer_id" => $officer_id]);
        }
        if (!empty($officer_name)) {
            $match = array_merge($match, ["officer_name" => $this->dbo->mongoRegex($officer_name)]);
        }
        if (!empty($code)) {

            switch ($code) {
                case 'NAS':
                    $match = array_merge($match, ["status" => 0]);
                    break;
                case 'NDL':
                    $match = array_merge($match, ["status" => ['$in' => [2, 801, 3, 4]]]);
                    $match = array_merge($match, ["component_id" => 8]);
                    break;
                case 'DNA':
                    $match = array_merge($match, ["status" => 1]);
                    $match = array_merge($match, ["business_id" => 2]);
                    break;
                case 'NAC':
                    $match = array_merge($match, ["status" => 1]);
                    break;
                case 'NST':
                    $match = array_merge($match, ["status" => 2]);
                    break;
                case 'NRC':
                    $match = array_merge($match, ["status" => 3]);
                    break;
                case 'TIP':
                    $match = array_merge($match, ["status" => 5]);
                    break;
                case 'SNC':
                    $match = array_merge($match, ["status" => 102]);
                    break;
                case 'SNS':
                    $match = array_merge($match, ["status" => 103]);
                    break;
            }
        }
        $match['event_date'] = ['$gte' => $search_date_mongo_from, '$lte' => $search_date_mongo_to];
        if ($mode == 'GREEN' || $mode == 'AMBER') {
            $match['event_date'] = ['$gte' => $search_date_mongo];
            $date_flag = 'FUTURE';
        }
        if ($mode == 'RED') {
            $match['event_date'] = ['$lte' => $search_date_mongo];
            $date_flag = 'PAST';
        }

        $group = [];
        if ($date_flag == 'PAST') {
            $group = [
                '_id' => '$order_id',
                'event_date' => ['$last' => '$event_date'],
                'event_date_type' => ['$last' => '$event_date_type'],
                'color' => ['$last' => '$color'],
                'threshold' => ['$last' => '$threshold'],
            ];
        }

        if ($date_flag == 'FUTURE') {
            $group = [
                '_id' => '$order_id',
                'event_date' => ['$first' => '$event_date'],
                'event_date_type' => ['$first' => '$event_date_type'],
                'color' => ['$first' => '$color'],
                'threshold' => ['$first' => '$threshold'],
                'next_events' => ['$addToSet' => ['event_date' => '$event_date', 'color' => '$color', 'threshold' => '$threshold']],
            ];
        }

        $pipeline[] = ['$match' => $match];
        $pipeline[] = ['$group' => $group];
        if ($date_flag == 'CURRENT') {
            $matchP = $matchF = $match;
            //$matchP['event_date'] = ['$lte' => $search_date_mongo, '$gte' => $search_date_mongo_from];
            //$matchF['event_date'] = ['$gte' => $search_date_mongo, '$lte' => $search_date_mongo_to];
            $matchP['event_date'] = ['$lte' => $search_date_mongo];
            $matchF['event_date'] = ['$gte' => $search_date_mongo];
            $pipeline = [
                [
                    '$facet' => [
                        'past' => [
                            [
                                '$match' => $matchP,
                            ],
                            [
                                '$group' => [
                                    '_id' => '$order_id',
                                    'event_date' => ['$last' => '$event_date'],
                                    'event_date_str' => ['$last' => '$event_date_str'],
                                    'event_date_type' => ['$last' => '$event_date_type'],
                                    'color' => ['$last' => '$color'],
                                    'threshold' => ['$last' => '$threshold'],
                                ],
                            ],
                        ], 'future' => [
                            [
                                '$match' => $matchF,
                            ],
                            [
                                '$group' => [
                                    '_id' => '$order_id',
                                    'event_date' => ['$first' => '$event_date'],
                                    'event_date_str' => ['$first' => '$event_date_str'],
                                    'event_date_type' => ['$first' => '$event_date_type'],
                                    'color' => ['$first' => '$color'],
                                    'threshold' => ['$first' => '$threshold'],
                                    'next_events' => ['$addToSet' => ['event_date' => '$event_date', 'color' => '$color', 'threshold' => '$threshold']],
                                ],
                            ],
                        ],
                    ],
                ], [
                    '$project' => [
                        'orders' => [
                            '$concatArrays' => [
                                '$past',
                                '$future',
                            ],
                        ],
                    ],
                ], [
                    '$unwind' => '$orders',
                ], [
                    '$replaceRoot' => [
                        'newRoot' => '$orders',
                    ],
                ],
            ];
            $pipeline[] = [
                '$group' => [
                    '_id' => '$_id',
                    'event_date' => ['$last' => '$event_date'],
                    'event_date_str' => ['$last' => '$event_date_str'],
                    'event_date_type' => ['$last' => '$event_date_type'],
                    'color' => ['$last' => '$color'],
                    'threshold' => ['$last' => '$threshold'],
                    'next_events' => ['$last' => '$next_events'],
                ],
            ];
        }
        //return $pipeline;
        //return $this->dbo->aggregate('masters', 'rtct_orders_status', $pipeline);
        if (in_array($mode, ['AMBER', 'RED', 'GREEN'])) {
            $pipeline[] = [
                '$match' => ['color' => $mode],
            ];
        }

        $pipeline[] = [
            '$sort' => [
                "event_date" => 1,
                "next_events" => 1,
            ],
        ];

        $pipeline[] = [
            '$skip' => $skip,
        ];

        $pipeline[] = [
            '$limit' => $limit,
        ];

        $pipeline[] = [
            '$lookup' => [
                'from' => 'orders',
                /*'localField' => '_id',
                'foreignField' => '_id', */
                'as' => 'order',
                'let' => [
                    'orderId' => '$_id',
                ],
                'pipeline' => [
                    [
                        '$match' => [
                            '$expr' => [
                                '$and' => [
                                    ['$eq' => ['$_id', '$$orderId']],
                                ],
                            ],
                        ],
                    ],
                    [
                        '$project' => [
                            'OStatus' => 1,
                            'odid' => 1,
                            'wodid' => 1,
                            'wid' => 1,
                            'mode_of_service' => 1,
                            'active_component' => 1,
                            'order.provider_info' => 1,
                            'order.patientinfo.mrn' => 1,
                            'order.patientinfo.service_type' => 1,
                            'order.patientinfo.name' => 1,
                            'order.patientinfo.age' => 1,
                            'order.patientinfo.gender' => 1,
                            'order.patientinfo.contact' => 1,
                            'order.patientinfo.email' => 1,
                            'order.patientinfo.state' => 1,
                            'order.patientinfo.city' => 1,
                            'order.patientinfo.district' => 1,
                            'order.patientinfo.address' => 1,
                            'order.patientinfo.pincode' => 1,
                            'order.patientinfo.delivery_lat' => 1,
                            'order.patientinfo.delivery_lng' => 1,
                            'order.patientinfo.scheduled_date' => 1,
                            'order.patientinfo.servicedate' => 1,
                        ],
                    ],
                ],

            ],
        ];

        $pipeline[] = [
            '$unwind' => '$order',
        ];

        $pipeline[] = [
            '$lookup' => [
                'from' => 'workflow_status',
                'let' => [
                    'mode_of_service' => '$order.mode_of_service',
                    'service_type' => '$order.order.patientinfo.service_type',
                    'order_status' => '$order.OStatus',
                    'component' => '$order.active_component',
                ],
                'pipeline' => [
                    [
                        '$match' => [
                            '$expr' => [
                                '$and' => [
                                    ['$eq' => ['$status', '$$order_status']],
                                    ['$eq' => ['$Bid', '$$service_type']],
                                    ['$eq' => ['$MOSid', '$$mode_of_service']],
                                    ['$eq' => ['$Workflow', '$$component']],
                                ],
                            ],
                        ],
                    ],
                    [
                        '$project' => [
                            "Nomenclature" => 1,
                            '_id' => 0,
                        ],
                    ],
                ],
                'as' => 'nomenclature',
            ],
        ];
        $pipeline[] = [
            '$project' => [
                '_id' => 1,
                'event_date' => 1,
                'event_date_str' => 1,
                'event_date_type' => 1,
                'color' => 1,
                'threshold' => 1,
                'order.OStatus' => 1,
                'order.odid' => 1,
                'order.wodid' => 1,
                'order.wid' => 1,
                'order.mode_of_service' => 1,
                'order.active_component' => 1,
                'order.order.provider_info' => 1,
                'order.order.patientinfo.mrn' => 1,
                'order.order.patientinfo.service_type' => 1,
                'order.order.patientinfo.name' => 1,
                'order.order.patientinfo.age' => 1,
                'order.order.patientinfo.gender' => 1,
                'order.order.patientinfo.contact' => 1,
                'order.order.patientinfo.email' => 1,
                'order.order.patientinfo.state' => 1,
                'order.order.patientinfo.city' => 1,
                'order.order.patientinfo.district' => 1,
                'order.order.patientinfo.address' => 1,
                'order.order.patientinfo.pincode' => 1,
                'order.order.patientinfo.delivery_lat' => 1,
                'order.order.patientinfo.delivery_lng' => 1,
                'order.order.patientinfo.scheduled_date' => 1,
                'order.order.patientinfo.servicedate' => 1,
                'nomenclature' => 1,
                'next_events' => 1,
            ],
        ];
        //return $pipeline;
        $data = $this->dbo->aggregate('masters', 'rtct_orders_status', $pipeline);
        foreach ($data as $item) {
            //return $item;
            $next_events = [];
            if (!empty($item['next_events'])) {
                array_pop($item['next_events']);
                if (!empty($item['next_events'])) {
                    foreach ($item['next_events'] as $event) {
                        $next_events[] = [
                            "color" => $event['color'],
                            "threshold" => $event['threshold'],
                            "event_on" => date('Y-m-d H:i:s', $this->dbo->mongoDateToSec($event['event_date'])),
                        ];
                    }
                }
            }
            //
            $order = $item['order'];
            $nomenclature = $item['nomenclature'][0]['Nomenclature'];
            $engagement_level = $order['mode_of_service'];
            $res_business_id = $order['order']['patientinfo']['service_type'];
            $itemKey = array_search($order['active_component'], array_column($order['order']['provider_info'], 'component_no'));
            $officer_id = $order['order']['provider_info'][$itemKey]['officer_id'];
            $officer_name = $order['order']['provider_info'][$itemKey]['officer_name'];
            $officer_contact_number = $order['order']['provider_info'][$itemKey]['officer_contact_number'];
            $result[$item['color']][] = [
                'id' => $item['_id'],
                'is_pinned' => in_array($item['_id'], $pinned_orders) ? true : false,
                'order_status' => $order['OStatus'],
                'threshold' => $item['threshold'],
                'business_id' => $res_business_id,
                'business_name' => $this->utility->getbusinessDef($res_business_id, $engagement_level),
                'officer_id' => $officer_id,
                'officer_name' => $officer_name,
                'officer_contact_number' => $officer_contact_number,
                'nomenclature' => $nomenclature,
                'odid' => $order['odid'],
                'wodid' => $order['wodid'],
                'wid' => $order['wid'],
                'mrn' => $order['order']['patientinfo']['mrn'],
                'name' => $order['order']['patientinfo']['name'],
                'age' => $order['order']['patientinfo']['age'],
                'gender' => $order['order']['patientinfo']['gender'],
                'contact' => $order['order']['patientinfo']['contact'],
                'email' => $order['order']['patientinfo']['email'],
                'state' => $order['order']['patientinfo']['state'],
                'city' => $order['order']['patientinfo']['city'],
                'district' => $order['order']['patientinfo']['district'],
                'address' => $order['order']['patientinfo']['address'],
                'pincode' => $order['order']['patientinfo']['pincode'],
                'customer_lat' => $order['order']['patientinfo']['delivery_lat'],
                'customer_lng' => $order['order']['patientinfo']['delivery_lng'],
                //'scheduled_date' => date('Y-m-d H:i:s',strtotime($order['order']['patientinfo']['scheduled_date'])),
                'scheduled_date' => date('Y-m-d H:i:s', $this->dbo->mongoDateToSec($order['order']['patientinfo']['servicedate'])),
                'servicedate' => date('Y-m-d H:i:s', $this->dbo->mongoDateToSec($order['order']['patientinfo']['servicedate'])),
                'next_events' => array_reverse($next_events),
            ];
        }
        if (empty($result)) {
            return ['status' => 0, 'message' => 'No data available'];
        } else {
            return ['status' => 1, 'message' => 'Data fetch successfully', 'data' => $result];
        }
    }

    public function set_event($payload, $ticket)
    {
        $tier = 1;
        $order_id = $payload->order_id;
        if (empty($order_id)) {
            return array("success" => 0, "code" => "10200", "message" => "Invalid Input Or Required fields are missing");
        }

        //-------------get order collection based on order_id ------------
        $filter = ['_id' => (int) $order_id]; //255293
        $order = $this->dbo->findOne("masters", "orders", $filter, array("order.orderitem.activity" => 0));
        if (empty($order)) {
            return array("status" => 0, "code" => "10300", "message" => "Invalid Order Id");
        }

        $servicedate = $order['order']['patientinfo']['servicedate'];
        $scheduled_date = $order['order']['patientinfo']['scheduled_date'];
        $status = $order['OStatus'];
        $component_id = $order['active_component'];
        $mode_of_service = $order['mode_of_service'];
        $business_id = $order['order']['patientinfo']['service_type'];
        $odid = $order['odid'];
        $mrn = $order['order']['patientinfo']['mrn'];
        $name = $order['order']['patientinfo']['name'];
        $itemKey = array_search($order['active_component'], array_column($order['order']['provider_info'], 'component_no'));
        $associate_name = $order['order']['provider_info'][$itemKey]['associate_name'];
        $associate_id = $order['order']['provider_info'][$itemKey]['associate_id'];
        $branch_id = $order['order']['provider_info'][$itemKey]['associate_branch_id'];
        $officer_id = $order['order']['provider_info'][$itemKey]['officer_id'];
        $officer_name = $order['order']['provider_info'][$itemKey]['officer_name'];
        $pincode = $order['order']['patientinfo']['pincode'];
        $city = $order['order']['patientinfo']['city'];
        $address = $order['order']['patientinfo']['address'];

        // remove the existing order mapping
        $filter = ['order_id' => (int) $order_id]; //255293
        $this->dbo->delete_all('masters', 'rtct_orders_status', $filter);

        // find next status
        $nextStatus = $this->get_next_status($business_id, $status);

        // call master redis api
        $redis = new OMS_Redis;
        $key = 'OMS_RTCT_' . $tier . '_' . $mode_of_service . '_' . $business_id . '_' . $nextStatus; //OMS_RTCT_1_1_2_2
        $jsonVal = $redis->get($key); //$jsonVal = $redis->get("OMS_RTCT_1_3_2");

        // call master mapping
        //$filter = ['mode_of_service' => $mode_of_service, 'status' => $nextStatus];
        //$jsonVal = $this->dbo->findOne("masters", "rtct_events_mapping", $filter, array("order.orderitem.activity" => 0));

        if (empty($jsonVal)) {
            $this->dbo->delete("masters", "rtct_orders_pinned", $filter);
            return ['status' => 0, 'message' => 'no mapping found in Redis'];
        }

        // trigger RTCT Socket API Async
        $url = $this->config->getconfig('rtct_path', 'order');
        $pLoadSkt = ['orderId' => $order_id, 'status' => $status];
        $this->utility->async_curl($url, json_encode($pLoadSkt));

        $extraFieldsForFilter = [
            "order_id" => (int) $order_id,
            "scheduled_date" => $servicedate,
            "status" => (int) $status,
            "next_status" => (int) $nextStatus,
            "business_id" => (int) $business_id,
            "component_id" => (int) $component_id,
            "odid" => $odid,
            "mrn" => (int) $mrn,
            "name" => $name,
            "associate_name" => $associate_name,
            "associate_id" => $associate_id,
            "branch_id" => $branch_id,
            "officer_id" => $officer_id,
            "officer_name" => $officer_name,
            "pincode" => $pincode, //pincode state city
            "city" => $city,
            "address" => $address,
        ];

        $jsonValArr = json_decode($jsonVal, 1);
        $t = $jsonValArr['T'] * 60;
        $x1 = $jsonValArr['X1'] * 60;
        $x2 = $jsonValArr['X2'] * 60;
        $x3 = $jsonValArr['X3'] * 60;
        $y1 = $jsonValArr['Y1'] * (-60);
        $y2 = $jsonValArr['Y2'] * (-60);
        $y3 = $jsonValArr['Y3'] * (-60);
        $records = [];
        $actionDateInSec = strtotime($order['order']['patientinfo']['scheduled_date']) - $this->timeOffset;
        if (!empty($x3)) {
            $dt = date('Y-m-d H:i:s', $actionDateInSec - $x3);
            $records[] = [
                "event_date_str" => $dt,
                "event_date" => $this->dbo->date(strtotime($dt) + $this->timeOffset),
                "event_date_type" => "SCHEDULED",
                "threshold" => "X3",
                "color" => "GREEN",
            ];
        }
        if (!empty($x2)) {
            $dt = date('Y-m-d H:i:s', $actionDateInSec - $x2);
            $records[] = [
                "event_date_str" => $dt,
                "event_date" => $this->dbo->date(strtotime($dt) + $this->timeOffset),
                "event_date_type" => "SCHEDULED",
                "threshold" => "X2",
                "color" => "AMBER",
            ];
        }
        if (!empty($x1)) {
            $dt = date('Y-m-d H:i:s', $actionDateInSec - $x1);
            $records[] = [
                "event_date_str" => $dt,
                "event_date" => $this->dbo->date(strtotime($dt) + $this->timeOffset),
                "event_date_type" => "SCHEDULED",
                "threshold" => "X1",
                "color" => "RED",
            ];
        }
        if (!empty($y1)) {
            $dt = date('Y-m-d H:i:s', $actionDateInSec + $y1);
            $records[] = [
                "event_date_str" => $dt,
                "event_date" => $this->dbo->date(strtotime($dt) + $this->timeOffset),
                "event_date_type" => "SCHEDULED",
                "threshold" => "Y1",
                "color" => "RED",
            ];
        }
        if (!empty($y2)) {
            $dt = date('Y-m-d H:i:s', $actionDateInSec + $y2);
            $records[] = [
                "event_date_str" => $dt,
                "event_date" => $this->dbo->date(strtotime($dt) + $this->timeOffset),
                "event_date_type" => "SCHEDULED",
                "threshold" => "Y2",
                "color" => "RED",
            ];
        }
        if (!empty($y3)) {
            $dt = date('Y-m-d H:i:s', $actionDateInSec + $y3);
            $records[] = [
                "event_date_str" => $dt,
                "event_date" => $this->dbo->date(strtotime($dt) + $this->timeOffset),
                "event_date_type" => "SCHEDULED",
                "threshold" => "Y3",
                "color" => "RED",
            ];
        }
        foreach ($records as $key => $item) {
            $records[$key] = array_merge($item, $extraFieldsForFilter);
        }
        // insert into collection
        //return $records;
        if (!empty($records)) {
            $this->dbo->insertMany("masters", "rtct_orders_status", $records);
        }
        return ['status' => 1, 'message' => 'Mapping set successfully'];
    }
    /*
     * {
    "_id" : ObjectId("5d2db2dc34ff30eef6e8882c"),
    "name" : "Order accepted",
    "mode_of_service" : 1,
    "status" : 2,
    "threshold" : -30,
    "threshold_txt" : "before 30 Min",
    "x1" : -45,
    "x1_text" : "15 min before T",
    "x2" : -60,
    "x2_text" : "30 min before T",
    "x3" : -90,
    "x3_text" : "1 hr before T",
    "y1" : 2,
    "y1_text" : "2 min after T"
    }
     */

    public function get_next_status($business_id, $currentStatus)
    {
        $next_status = intval($currentStatus) + 1; // default value
        switch ($currentStatus) {
            case 0:$next_status = 1; // unassigned to assign
                break;
            case 1:$next_status = 2; // assign to
                break;
            case 2:$next_status = 3; // acceptance to started
                break;
            case 3:$next_status = 4; // started to reach
                break;
            case 101:$next_status = 102;
                break;
            case 102:$next_status = 103;
                break;
        }
        return $next_status;
    }

    public function get_orders_counts($payload, $ticket)
    {
        // get count based on the color
        $user_id = $payload->user_id;
        $mrn = intval($payload->mrn);
        $odid = $payload->odid;
        $business_id = $payload->business_id;
        $associate_id = $payload->associate_id;
        $branch_id = (String) $payload->branch_id;
        $officer_id = (String) $payload->officer_id;
        $search_date = $payload->search_date; // YYYY-MM-DD i.e 2019-07-24
        $search_date_mongo = $this->dbo->date(time() + $this->timeOffset);
        $res = ["GREEN" => 0, "AMBER" => 0, "RED" => 0, "PINNED" => 0];
        //return $payload;
        $match = [
            'event_date' => [
                '$gte' => $search_date_mongo,
            ],
        ];

        if (!empty($mrn)) {
            $match = array_merge($match, ["mrn" => $mrn]);
        }
        if (!empty($odid)) {
            $match = array_merge($match, ["odid" => $this->dbo->mongoRegex($odid)]);
        }
        if (!empty($business_id)) {
            if (is_array($business_id)) {
                $business_id = array_map('intval', $business_id);
                $match = array_merge($match, ["business_id" => ['$in' => $business_id]]);
            }
            if (is_string($business_id)) {
                $match = array_merge($match, ["business_id" => intval($business_id)]);
            }
        }
        if (!empty($customer_name)) {
            $match = array_merge($match, ["name" => $this->dbo->mongoRegex($customer_name) ]);
        }
        if (!empty($associate_name)) {
            $match = array_merge($match, ["associate_name" => $this->dbo->mongoRegex($associate_name)]);
        }
        if (!empty($associate_id)) {
            $match = array_merge($match, ["associate_id" => $associate_id]);
        }
        if (!empty($branch_id)) {
            $match = array_merge($match, ["branch_id" => $branch_id]);
        }
        if (!empty($officer_id)) {
            $match = array_merge($match, ["officer_id" => $officer_id]);
        }
        if (!empty($officer_name)) {
            $match = array_merge($match, ["officer_name" => $this->dbo->mongoRegex($officer_name) ]);
        }
        $pinned_orders = [];
        if (!empty($user_id)) {
            // get orderids
            $filter = array('user_id' => (String) $user_id);
            $res1 = $this->dbo->find("masters", "rtct_orders_pinned", $filter, ['order_id' => 1, '_id' => 0]);
            if (!empty($res1)) {
                foreach ($res1 as $odr) {
                    $pinned_orders[] = (int) $odr['order_id'];
                }
                $pinned_orders = array_values(array_unique($pinned_orders));
                if ($mode == 'PINNED') {
                    $match = array_merge($match, ["order_id" => ['$in' => $pinned_orders]]);
                }
            }
        }

        $matchP = $matchF = $match;
        //$matchP['event_date'] = ['$lte' => $search_date_mongo, '$gte' => $search_date_mongo_from];
        //$matchF['event_date'] = ['$gte' => $search_date_mongo, '$lte' => $search_date_mongo_to];
        $matchP['event_date'] = ['$lte' => $search_date_mongo];
        $matchF['event_date'] = ['$gte' => $search_date_mongo];
        $pipeline = [
            [
                '$facet' => [
                    'past' => [
                        [
                            '$match' => $matchP,
                        ],
                        [
                            '$group' => [
                                '_id' => '$order_id',
                                'event_date' => ['$last' => '$event_date'],
                                'event_date_type' => ['$last' => '$event_date_type'],
                                'color' => ['$last' => '$color'],
                                'threshold' => ['$last' => '$threshold'],
                            ],
                        ],
                    ], 'future' => [
                        [
                            '$match' => $matchF,
                        ],
                        [
                            '$group' => [
                                '_id' => '$order_id',
                                'event_date' => ['$first' => '$event_date'],
                                'event_date_type' => ['$first' => '$event_date_type'],
                                'color' => ['$first' => '$color'],
                                'threshold' => ['$first' => '$threshold'],
                            ],
                        ],
                    ],
                ],
            ], [
                '$project' => [
                    'orders' => [
                        '$concatArrays' => [
                            '$past',
                            '$future',
                        ],
                    ],
                ],
            ], [
                '$unwind' => '$orders',
            ], [
                '$replaceRoot' => [
                    'newRoot' => '$orders',
                ],
            ],
        ];
        $pipeline[] = [
            '$group' => [
                '_id' => '$_id',
                'event_date' => ['$last' => '$event_date'],
                'event_date_type' => ['$last' => '$event_date_type'],
                'color' => ['$last' => '$color'],
                'threshold' => ['$last' => '$threshold'],
            ],
        ];
        $pipeline[] = [
            '$group' => [
                '_id' => '$color',
                'count' => ['$sum' => 1],
            ],
        ];
        $data = $this->dbo->aggregate('masters', 'rtct_orders_status', $pipeline);
        foreach ($data as $item) {
            $res[$item['_id']] = $item['count'];
        }
        //if(!empty($user_id)){}
        $pipeline = [['$match' => ['user_id' => $user_id]], ['$count' => 'myCount']];
        $res['PINNED'] = intval($this->dbo->aggregate('masters', 'rtct_orders_pinned', $pipeline)[0]['myCount']);
        //$res['GREEN'] = $res['GREEN'] - $res['AMBER'];
        return ['status' => 1, 'message' => 'Data fetch successfully', 'data' => $res];
    }

    public function mark_pinnable($payload, $ticket)
    {
        $order_id = $payload->order_id;
        $user_id = $payload->user_id;
        $is_pinned = $payload->is_pinned; // true or false
        if (empty($order_id) || !isset($is_pinned) || empty($user_id)) {
            return array("success" => 0, "code" => "10200", "message" => "Invalid Input Or Required fields are missing");
        }

        $filter = array('order_id' => (int) $order_id, 'user_id' => (String) $user_id);
        $pinned_order = $this->dbo->findOne("masters", "rtct_orders_pinned", $filter, []);
        if ($is_pinned) {
            if (empty($pinned_order)) {
                $this->dbo->insert("masters", "rtct_orders_pinned", $filter);
            }
        } else {
            $this->dbo->delete_all("masters", "rtct_orders_pinned", $filter);
        }
        return ['status' => 1, 'message' => 'Data updated successfully'];
    }

    public function get_order_flow($payload, $ticket)
    {
        $order_id = $payload->order_id;
        if (empty($order_id)) {
            return array("success" => 0, "code" => "10200", "message" => "Required fields are missing");
        }

        // get order log
        $filter = array('_id' => (int) $order_id);
        $order = $this->dbo->findOne("masters", "orderlog", $filter, ["order_log" => 1, "component_order" => 1]);
        if (empty($order)) {
            return array("success" => 0, "code" => "10200", "message" => "Invalid order id");
        }

        $noOfComponent = count($order['component_order']);
        $component_order = array_map('intval', $order['component_order']);
        $pre_component_id = $component_order[0];
        $ordrSeq = [];
        foreach ($order['order_log'] as $item) {
            if (empty($item['component_no'])) {
                $item['component_no'] = $pre_component_id;
            }
            if ($item['component_no'] != $pre_component_id) {
                $pre_component_id = $item['component_no'];
            }
            $ordrSeq[$item['component_no'] . '_' . $item['order_status']] = $item;
        }

        //return $ordrSeq;
        $filter = array('component_id' => ['$in' => $component_order]);
        $mapping = $this->dbo->find("masters", "rtct_statusflow_mapping", $filter, []);
        if (empty($mapping)) {
            return array("success" => 0, "code" => "10300", "message" => "No mapping found");
        }
        $ordrSeqFinal = [];

        foreach ($mapping as $item) {
            foreach ($item['sequence'] as $seq) {
                if ($seq['is_enable'] == false) {
                    continue;
                }
                $temp = $ordrSeq[$item['component_id'] . '_' . $seq['status']];
                unset($seq['is_enable']);
                $seq['action_on'] = $temp['created_date'];
                $seq['action_by'] = $temp['actionByName'];
                $seq['action_by_id'] = $temp['actionById'];
                $seq['is_completed'] = true;
                $ordrSeqFinal[] = $seq;
            }
        }

        $deleteSeq = 0;
        $ordrSeqFinal = array_reverse($ordrSeqFinal);
        $noOfRec = count($ordrSeqFinal);
        foreach ($ordrSeqFinal as $key => $value) {
            if ($key > 0 && $key < $noOfRec && $value['status'] == 6) {
                unset($ordrSeqFinal[$key]);
                continue;
            }
            if ($noOfComponent == 1 && $value['status'] == 106) {
                unset($ordrSeqFinal[$key]);
                continue;
            }
            if (empty($value['action_on'])) {
                if ($deleteSeq) {
                    unset($ordrSeqFinal[$key]);
                    continue;
                }
                $value['is_completed'] = false;
                $ordrSeqFinal[$key] = $value;
            } else {
                $deleteSeq = 1;
            }
        }
        $ordrSeqFinal = array_reverse($ordrSeqFinal);

        return array("success" => 1, "code" => "10100", "message" => "Data Fetch successfully", "data" => $ordrSeqFinal);
    }

    public function get_single_order_detail($payload, $ticket)
    {
        $order_id = $payload->order_id;
        $user_id = $payload->user_id;
        if (empty($order_id)) {
            return array("success" => 0, "code" => "10200", "message" => "Required fields are missing");
        }

        //-------------get order collection based on order_id ------------
        $filter = ['_id' => (int) $order_id]; //255293
        $order = $this->dbo->findOne("masters", "orders", $filter, array("order.orderitem.activity" => 0));
        if (empty($order)) {
            return array("status" => 0, "code" => "10300", "message" => "Invalid Order Id");
        }
        $res = array("status" => 0, "code" => "10400", "message" => "No records found");
        $payloadI = (Object) [
            "mode" => "ALL",
            "user_id" => $user_id,
            "page" => 1,
            "odid" => $order['odid'],
        ];
        return $data = $this->get_orders($payloadI, $ticket);
        if ($data['status'] == 1) {
            $data = array_values($data['data'])[0][0];
            return ["status" => 1, "code" => "10100", "message" => "Data Fetch successfully", 'data' => $data];
        }
        return $res;
    }

    public function get_orders_counts_by_status($payload, $ticket)
    {

        //return $this->dbo->find('masters','orders',["OStatus" => 6],[],['_id'=> -1],10,mt_rand(1,100));
        //return $this->dbo->find('masters','appointments',["conferenceType" => "1"],[],['_id'=> -1],10,mt_rand(1,100));
        //return $this->dbo->findOne('masters','orders',["OStatus" => 6]);
        //return $this->dbo->countitem('masters','orders',["OStatus" => 6]);
        //return $this->dbo->delete('masters','xx_temp',["item" => "box"]);
        //return $this->dbo->delete_all('masters','xx_temp',["item" => "box"]);
        //return $this->dbo->distinct('masters','xx_temp',"item");
        //return $this->dbo->update('masters', 'xx_temp', ["item" => "box"], ["item1" => "box2"], ["itemPush" => "box"], ['multi' => true]);
        //return $this->dbo->findAndModify('masters', 'xx_temp', ["item" => "box"], ["item3" => "box4"]);
        return $this->dbo->insert('masters', 'xx_temp', ["item" => "box"]);
        //return $this->dbo->insertMany('masters', 'xx_temp', [["item" => "box", "item" => "box4"],["item" => "box", "item" => "box5"]]);

        $statues = [
            'NAS' => 'Not Assigned',
            'NAC' => 'Not Accepted',
            'NST' => 'Not Started',
            'NRC' => 'Not Reached',
            'DNA' => 'Drug Not accepted',
            'SNC' => 'Sample Not Collected',
            'SNS' => 'Sample Not Submitted',
            'TIP' => 'Test In Progress', //
            'NDL' => 'Not Delivered', //
            //'NCM' => 'Not Completed',
            //'PCL' => 'Pre Closure',
        ];
        foreach ($statues as $key => $value) {
            $res[] = [
                "code" => $key,
                "title" => $value,
                "total" => 0,
                "red" => 0,
                "amber" => 0,
                "green" => 0,
            ];
        }

        $mrn = intval($payload->mrn);
        $business_id = $payload->business_id;
        $associate_id = $payload->associate_id;
        $branch_id = (String) $payload->branch_id;
        $officer_id = (String) $payload->officer_id;
        $pincode = (String) $payload->pincode;
        $state = (String) $payload->state;
        $city = (String) $payload->city;

        // mrn, business_id(array), associate_id, branch_id, officer_id

        // take decision wheather search_date is past current or future
        $date_flag = 'CURRENT';
        $search_date_mongo = $this->dbo->date(time() + $this->timeOffset);
        $search_date_mongo_from = $this->dbo->date(strtotime(date('Y-m-d') . ' 00:00:00') + $this->timeOffset);
        $search_date_mongo_to = $this->dbo->date(strtotime(date('Y-m-d') . ' 23:59:59') + $this->timeOffset);
        if (!empty($search_date)) {
            if (strtotime($search_date) > time() && date('d', strtotime($search_date)) != date('d')) {
                $date_flag = 'FUTURE';
            }
            if (strtotime($search_date) < time() && date('d', strtotime($search_date)) != date('d')) {
                $date_flag = 'PAST';
            }
            $search_date_mongo_from = $this->dbo->date(strtotime($search_date . ' 00:00:00') + $this->timeOffset);
            $search_date_mongo_to = $this->dbo->date(strtotime($search_date . ' 23:59:59') + $this->timeOffset);
        }
        $match = [
            'event_date' => [
                '$gte' => $search_date_mongo,
            ],
        ];

        if (!empty($mrn)) {
            $match = array_merge($match, ["mrn" => $mrn]);
        }
        if (!empty($business_id)) {
            if (is_array($business_id)) {
                $business_id = array_map('intval', $business_id);
                $match = array_merge($match, ["business_id" => ['$in' => $business_id]]);
            }
            if (is_string($business_id)) {
                $match = array_merge($match, ["business_id" => intval($business_id)]);
            }
        }
        if (!empty($associate_id)) {
            $match = array_merge($match, ["associate_id" => $associate_id]);
        }
        if (!empty($branch_id)) {
            $match = array_merge($match, ["branch_id" => $branch_id]);
        }
        if (!empty($officer_id)) {
            $match = array_merge($match, ["officer_id" => $officer_id]);
        }
        if (!empty($pincode)) {
            $match = array_merge($match, ["pincode" => $pincode]);
        }
        if (!empty($state)) {
            $match = array_merge($match, ["address" => $state]);
        }
        if (!empty($city)) {
            $match = array_merge($match, ["city" => $city]);
        }
        $match['event_date'] = ['$gte' => $search_date_mongo_from, '$lte' => $search_date_mongo_to];
        $pipeline[] = ['$match' => $match];
        if ($date_flag == 'CURRENT') {
            $matchP = $matchF = $match;
            //$matchP['event_date'] = ['$lte' => $search_date_mongo, '$gte' => $search_date_mongo_from];
            //$matchF['event_date'] = ['$gte' => $search_date_mongo, '$lte' => $search_date_mongo_to];
            $matchP['event_date'] = ['$lte' => $search_date_mongo];
            $matchF['event_date'] = ['$gte' => $search_date_mongo];
            $pipeline = [
                [
                    '$facet' => [
                        'past' => [
                            [
                                '$match' => $matchP,
                            ],
                            [
                                '$group' => [
                                    '_id' => '$order_id',
                                    //'event_date' => ['$last' => '$event_date'],
                                    //'event_date_type' => ['$last' => '$event_date_type'],
                                    'color' => ['$last' => '$color'],
                                    'status' => ['$last' => '$status'],
                                    'business_id' => ['$last' => '$business_id'],
                                    'component_id' => ['$last' => '$component_id'],
                                    //'threshold' => ['$last' => '$threshold'],
                                ],
                            ],
                        ], 'future' => [
                            [
                                '$match' => $matchF,
                            ],
                            [
                                '$group' => [
                                    '_id' => '$order_id',
                                    //'event_date' => ['$first' => '$event_date'],
                                    //'event_date_type' => ['$first' => '$event_date_type'],
                                    'color' => ['$first' => '$color'],
                                    'status' => ['$first' => '$status'],
                                    'business_id' => ['$first' => '$business_id'],
                                    'component_id' => ['$first' => '$component_id'],
                                    //'threshold' => ['$first' => '$threshold'],
                                ],
                            ],
                        ],
                    ],
                ], [
                    '$project' => [
                        'orders' => [
                            '$concatArrays' => [
                                '$past',
                                '$future',
                            ],
                        ],
                    ],
                ], [
                    '$unwind' => '$orders',
                ], [
                    '$replaceRoot' => [
                        'newRoot' => '$orders',
                    ],
                ],
            ];
            $pipeline[] = [
                '$group' => [
                    '_id' => '$_id',
                    'color' => ['$last' => '$color'],
                    'status' => ['$last' => '$status'],
                    'business_id' => ['$last' => '$business_id'],
                    'component_id' => ['$last' => '$component_id'],
                ],
            ];
            $pipeline[] = [
                '$group' => [
                    '_id' => ['component_id' => '$component_id', 'business_id' => '$business_id', "status" => '$status', "color" => '$color'],
                    'count' => ['$sum' => 1],
                ],
            ];
        }
        $data = $this->dbo->aggregate('masters', 'rtct_orders_status', $pipeline);
        $tmpData = [];

        //'PCL' => 'Pre Closure',
        /*$pcl = $this->get_pre_closuer_orders_counts($payload);
        $tmpData['PCL']['total'] = $pcl['total'];
        $tmpData['PCL']['red'] = $pcl['red'];
        $tmpData['PCL']['green'] = $tmpData['PCL']['amber'] = 0;

        //Not Completed
        $ncm = $this->get_not_completed_orders_count($payload);
        $tmpData['NCM']['total'] = $ncm['total'];
        $tmpData['NCM']['red'] = $ncm['red'];
        $tmpData['NCM']['green'] = $tmpData['NCM']['amber'] = 0; */

        foreach ($data as $value) {
            if ($value['_id']['status'] == 0) {
                $count = $value['count'];
                $tmpData['NAS']['total'] += $count;
                $tmpData['NAS']['red'] += ($value['_id']['color'] == 'RED') ? $count : 0;
                $tmpData['NAS']['green'] += ($value['_id']['color'] == 'GREEN') ? $count : 0;
                $tmpData['NAS']['amber'] += ($value['_id']['color'] == 'AMBER') ? $count : 0;
                continue;
            } elseif ($value['_id']['component_id'] == 8 && in_array($value['_id']['status'], [2, 801, 3, 4])) { //Not delivered
                $count = $value['count'];
                $tmpData['NDL']['total'] += $count;
                $tmpData['NDL']['red'] += ($value['_id']['color'] == 'RED') ? $count : 0;
                $tmpData['NDL']['green'] += ($value['_id']['color'] == 'GREEN') ? $count : 0;
                $tmpData['NDL']['amber'] += ($value['_id']['color'] == 'AMBER') ? $count : 0;
            }

            switch ($value['_id']['status']) {

                case 1: //Not Accepted
                    if ($value['_id']['business_id'] == 2) {
                        $count = $value['count'];
                        $tmpData['DNA']['total'] += $count;
                        $tmpData['DNA']['red'] += ($value['_id']['color'] == 'RED') ? $count : 0;
                        $tmpData['DNA']['green'] += ($value['_id']['color'] == 'GREEN') ? $count : 0;
                        $tmpData['DNA']['amber'] += ($value['_id']['color'] == 'AMBER') ? $count : 0;
                    } else {
                        $count = $value['count'];
                        $tmpData['NAC']['total'] += $count;
                        $tmpData['NAC']['red'] += ($value['_id']['color'] == 'RED') ? $count : 0;
                        $tmpData['NAC']['green'] += ($value['_id']['color'] == 'GREEN') ? $count : 0;
                        $tmpData['NAC']['amber'] += ($value['_id']['color'] == 'AMBER') ? $count : 0;
                    }
                    break;
                case 2: // Not started
                    $count = $value['count'];
                    $tmpData['NST']['total'] += $count;
                    $tmpData['NST']['red'] += ($value['_id']['color'] == 'RED') ? $count : 0;
                    $tmpData['NST']['green'] += ($value['_id']['color'] == 'GREEN') ? $count : 0;
                    $tmpData['NST']['amber'] += ($value['_id']['color'] == 'AMBER') ? $count : 0;
                    break;
                case 3: // Not reached
                    $count = $value['count'];
                    $tmpData['NRC']['total'] += $count;
                    $tmpData['NRC']['red'] += ($value['_id']['color'] == 'RED') ? $count : 0;
                    $tmpData['NRC']['green'] += ($value['_id']['color'] == 'GREEN') ? $count : 0;
                    $tmpData['NRC']['amber'] += ($value['_id']['color'] == 'AMBER') ? $count : 0;
                    break;
                case 5: // Inprogress
                    $count = $value['count'];
                    $tmpData['TIP']['total'] += $count;
                    $tmpData['TIP']['red'] += ($value['_id']['color'] == 'RED') ? $count : 0;
                    $tmpData['TIP']['green'] += ($value['_id']['color'] == 'GREEN') ? $count : 0;
                    $tmpData['TIP']['amber'] += ($value['_id']['color'] == 'AMBER') ? $count : 0;
                    break;
                /*

                'PCL' => 'Pre Closure',
                 */
                case 102: //Sample Not Collected
                    $count = $value['count'];
                    $tmpData['SNC']['total'] += $count;
                    $tmpData['SNC']['red'] += ($value['_id']['color'] == 'RED') ? $count : 0;
                    $tmpData['SNC']['green'] += ($value['_id']['color'] == 'GREEN') ? $count : 0;
                    $tmpData['SNC']['amber'] += ($value['_id']['color'] == 'AMBER') ? $count : 0;
                    break;
                case 103: //Sample Not Submitted
                    $count = $value['count'];
                    $tmpData['SNS']['total'] += $count;
                    $tmpData['SNS']['red'] += ($value['_id']['color'] == 'RED') ? $count : 0;
                    $tmpData['SNS']['green'] += ($value['_id']['color'] == 'GREEN') ? $count : 0;
                    $tmpData['SNS']['amber'] += ($value['_id']['color'] == 'AMBER') ? $count : 0;
                    break;
            }
        }

        foreach ($res as $key => $value) {
            if (!empty($tmpData[$value['code']])) {
                $res[$key]['total'] = $tmpData[$value['code']]['total'];
                $res[$key]['red'] = $tmpData[$value['code']]['red'];
                $res[$key]['green'] = $tmpData[$value['code']]['green'];
                $res[$key]['amber'] = $tmpData[$value['code']]['amber'];
            }
        }

        return ["status" => 1, "code" => "10100", "message" => "Data Fetch successfully", 'data' => $res];

    }

    public function get_pre_closuer_orders_counts($payload)
    {
        $res = ['total' => 0, 'red' => 0];

        $mrn = (String) $payload->mrn;
        $business_id = $payload->business_id;
        $associate_id = (String) $payload->associate_id;
        $branch_id = (String) $payload->branch_id;
        $officer_id = (String) $payload->officer_id;
        $pincode = (String) $payload->pincode;
        $state = (String) $payload->state;
        $city = (String) $payload->city;

        // create filter
        $match['OStatus'] = 6;
        if (!empty($mrn)) {
            $match["order.patientinfo.mrn"] = $mrn;
        }
        if (!empty($business_id)) {
            if (is_array($business_id)) {
                $business_id = array_map('string', $business_id);
                $match["order.patientinfo.service_type"] = ['$in' => $business_id];
            }
            if (is_string($business_id)) {
                $match["order.patientinfo.service_type"] = (String) $business_id;
            }
        }
        if (!empty($associate_id)) {
            $match["order.provider_info.associate_id"] = $associate_id;
        }
        if (!empty($branch_id)) {
            $match["order.provider_info.associate_branch_id"] = $branch_id;
        }
        if (!empty($officer_id)) {
            $match["order.provider_info.officer_id"] = $officer_id;
        }
        if (!empty($pincode)) {
            $match["order.patientinfo.pincode"] = $pincode;
        }
        if (!empty($state)) {
            $match["order.patientinfo.address"] = $this->dbo->mongoRegex($state);
        }
        if (!empty($city)) {
            $match["order.patientinfo.city"] = $this->dbo->mongoRegex($city);
        }

        $pipeline[] = ['$match' => $match];

        $pipeline[] = [
            '$redact' => [
                '$cond' => [
                    'if' => [
                        '$gt' => [
                            [
                                '$subtract' => [
                                    '$order.patientinfo.servicedate', [
                                        '$dateFromString' => [
                                            'dateString' => '$order.patientinfo.order_completion_datetime',
                                        ],
                                    ],
                                ],
                            ],
                            1000, // 1sec difference
                        ],
                    ],
                    'then' => '$$KEEP',
                    'else' => '$$PRUNE',
                ],
            ],
        ];
        $pipeline[] = [
            '$count' => "orders",
        ];
        $data = $this->dbo->aggregate('masters', 'orders', $pipeline, []);
        if (intval($data[0]['orders']) > 1) {
            $res['total'] = intval($data[0]['orders']);
            $res['red'] = intval($data[0]['orders']);
        }
        return $res;
    }

    public function get_not_completed_orders_count($payload)
    {
        $res = ['total' => 0, 'red' => 0];

        $mrn = (String) $payload->mrn;
        $business_id = $payload->business_id;
        $associate_id = (String) $payload->associate_id;
        $branch_id = (String) $payload->branch_id;
        $officer_id = (String) $payload->officer_id;
        $pincode = (String) $payload->pincode;
        $state = (String) $payload->state;
        $city = (String) $payload->city;

        // create filter
        $match['OStatus'] = ['$in' => [103, 106, 5, 505]];
        if (!empty($mrn)) {
            $match["order.patientinfo.mrn"] = $mrn;
        }
        if (!empty($business_id)) {
            if (is_array($business_id)) {
                $business_id = array_map('string', $business_id);
                $match["order.patientinfo.service_type"] = ['$in' => $business_id];
            }
            if (is_string($business_id)) {
                $match["order.patientinfo.service_type"] = (String) $business_id;
            }
        }
        if (!empty($associate_id)) {
            $match["order.provider_info.associate_id"] = $associate_id;
        }
        if (!empty($branch_id)) {
            $match["order.provider_info.associate_branch_id"] = $branch_id;
        }
        if (!empty($officer_id)) {
            $match["order.provider_info.officer_id"] = $officer_id;
        }
        if (!empty($pincode)) {
            $match["order.patientinfo.pincode"] = $pincode;
        }
        if (!empty($state)) {
            $match["order.patientinfo.address"] = $this->dbo->mongoRegex($address);
        }
        if (!empty($city)) {
            $match["order.patientinfo.city"] = $this->dbo->mongoRegex($city);
        }

        $pipeline[] = ['$match' => $match];

        $pipeline[] = [
            '$redact' => [
                '$cond' => [
                    'if' => [
                        '$gt' => [
                            [
                                '$subtract' => [
                                    $this->dbo->date(),
                                    '$order.patientinfo.servicedate',
                                ],
                            ],
                            1000 * 3600 * 24, // 24 Hours difference
                        ],
                    ],
                    'then' => '$$KEEP',
                    'else' => '$$PRUNE',
                ],
            ],
        ];
        //return $pipeline;
        $pipeline[] = [
            '$count' => "orders",
        ];
        $data = $this->dbo->aggregate('masters', 'orders', $pipeline, []);
        if (intval($data[0]['orders']) > 1) {
            $res['total'] = intval($data[0]['orders']);
            $res['red'] = intval($data[0]['orders']);
        }
        return $res;
    }

}
