<?php
//error_reporting(E_ALL);
class OrderWorkFlow extends Oms
{
    public $chissPayload = array();
    public $mdmChkResArr = array();
    public $madRuleApiResArr = array();
    public function __construct()
    {
        parent::__construct();
        $this->orderinfo = new Orderinfo;
    }

    public function getname()
    {
        return "orderworkflow";
    }

    public function change_order_status_bulk($payload, $ticket)
    {
        $res = array();
        $status = 1;
        $orders = $payload->order_id;
        $validatedOrders = [];
        // validate each order, once validated; do operation otherwise data brings onto in-consistant state
        //var_dump($orders); die;
        foreach ($orders as $order) {
            $payload->order_id = $order;
            $payload->is_multi = 1;
            $payload->updateToChiss = 0;
            $resTemp = $this->change_order_status($payload, $ticket);
            //var_dump($resTemp);
            create_debug_log($order, 'StatusChangeBulkProcess', $resTemp, __FILE__);
            if ($resTemp == 'validated') {$validatedOrders[] = $order;
                continue;}
            $res[$order] = $resTemp;
            if ($resTemp['status'] == 0) {
                $status = 0;
            }
        }

        //return $validatedOrders;
        // proceed validated order
        if (!empty($validatedOrders)) {
            foreach ($validatedOrders as $order) {
                $payload->order_id = $order;
                $payload->is_multi = 1;
                $payload->updateToChiss = 1;
                $resTemp = $this->change_order_status($payload, $ticket);
                $res[$order] = $resTemp;
                if ($resTemp['status'] == 0) {
                    $status = 0;
                }
            }
        }

        //return $res;

        // send to chiss and get status
        if (empty($this->chissPayload)) {
            $status = 0;
        } else {
            $rpArr = $this->orderActionChiss($this->chissPayload, $payload->status, $ticket, 1, $updateToChiss);
            //var_dump($rpArr); die;
            foreach ($rpArr as $ord => $rp) {
                if ($rp['status'] == 0) {
                    $status = 0;
                    $res[$ord] = ['status' => 0, 'code' => '30700', 'message' => 'Unable to process Order, request is failed from Chiss : ' . $rp['message']];
                } else {
                    $validatedOrders[] = $ord;
                }
            }
        }

        $status = 1;
        if ($status) {
            return array("status" => 1, "code" => "30300", "message" => "Bulk order processed successfully");
        } else {
            return array("status" => $status, "code" => "30400", "message" => "Unable to process bulk orders.", "data" => $res);
        }

    }

    public function orderActionChiss($input_payload, $status, $ticket, $is_multi, $updateToChiss)
    {
        //echo json_encode($input_payload). ',sts:'.$status. ',tkt:'. $ticket.',multi:'. $is_multi.$updateToChiss; die;
        $status = intval($status);
        if ($is_multi == 0) {
            if (in_array($status, [2, 3, 6])) {
                $yy = $this->orderinfo->chiss_order_action([$input_payload], $ticket)[0];
                create_debug_log($input_payload->order_id, 'ChissApiReturn', $yy, __FILE__);
                return array("status" => 1);
                //var_dump($yy);die;
                if ($yy['status'] == 0) {
                    $code = $message = '';
                    switch ($status) {
                        case 2:
                            $message = "Unable to Accept the order, request failed from Chiss, Reason: " . $yy['message'];
                            $code = "10700";
                            break;
                        case 3:
                            $message = "Unable to Start Order the order, request failed from Chiss. Reason: " . $yy['message'];
                            $code = "30200";
                            break;
                        case 6:
                            $message = "Unable to Complete the order, request failed from Chiss. Reason: " . $yy['message'];
                            $code = "30100";
                            break;
                        default:
                            $message = "Invalid Order Status.";
                            $code = "10600";
                    }
                    return array("status" => 0, "code" => $code, "message" => $message);
                } else {
                    return array("status" => 1);
                }
                //return 234;
            } elseif ($status == 7) {
                //return $input_payload;
                $yy = $this->orderinfo->chiss_api_reschedule((Object) $input_payload, $ticket)['chiss_response'][0];
                create_debug_log($input_payload->order_id, 'ChissApiReturn', $yy, __FILE__);
                if ($yy['status'] == 0) {
                    // @Pallav to do async call: But due to which may cause data integrity issue
                    //return array("status" => 0, "code" => "30600", "message" => "Unable to Reschedule Order, request failed from Chiss. Reason : " . $yy['message']);
                }
                return array("status" => 1);
            } elseif ($status == 8) {
                $yy = $this->orderinfo->chiss_order_cancel([$input_payload], $ticket)[0];
                create_debug_log($input_payload->order_id, 'ChissApiReturn', $yy, __FILE__);
                if ($yy['status'] == 0) {
                    //return array("status" => 0, "code" => "30800", "message" => "Unable to cancel order, request failed from Chiss: " . $yy['message']);
                }
                return array("status" => 1);

            } elseif ($status == 9) {
                //var_dump($input_payload); die;
                create_debug_log($input_payload->order_id, 'ChissApiReturn', $yy, __FILE__);
                $yy = $this->orderinfo->chiss_order_rejection([$input_payload], $ticket)[0];
                if ($yy['status'] == 0) {
                    //return array("status" => 0, "code" => "10800", "message" => "Unable to reject order, request failed from Chiss: " . $yy['message']);
                }
                return array("status" => 1);
            }
        } else { // for multiple
            if (in_array($status, [2, 3, 6])) {
                $yy = $this->orderinfo->chiss_order_action($input_payload, $ticket);
                create_debug_log(0, 'ChissApiReturn', $yy, __FILE__);
            } elseif ($status == 7) {
                $yy = $this->orderinfo->chiss_api_reschedule((Object) $input_payload, $ticket)['chiss_response'];
                //var_dump($input_payload['orders_info']); die;
                create_debug_log(0, 'ChissApiReturn', $yy, __FILE__);
                foreach ($input_payload['orders_info'] as $key => $dd) {
                    $yy[$key]['wo_id'] = $dd->wo_id;
                }
                $input_payload = $input_payload['orders_info'];
            } elseif ($status == 8) {
                $yy = $this->orderinfo->chiss_order_cancel($input_payload, $ticket); //[0];
                create_debug_log(0, 'ChissApiReturn', $yy, __FILE__);
            } elseif ($status == 9) {
                $yy = $this->orderinfo->chiss_order_rejection($input_payload, $ticket);
                create_debug_log(0, 'ChissApiReturn', $yy, __FILE__);
            }

            $res = $xx = [];
            foreach ($input_payload as $ttmp) {
                $xx[$ttmp->wo_id] = $ttmp->order_id;
            }
            foreach ($yy as $item) {
                if ($item['status'] == 1 || $item['status'] == 0) {
                    $res[$xx[$item['wo_id']]] = array("status" => 1, "code" => "10100", "message" => "Order proceed successfully");
                } else {
                    $res[$xx[$item['wo_id']]] = $item;
                }
            }
            return $res;
        }
    }

    public function complete_order_manually($payload, $ticket)
    {
        $searchreq = $payload;
        create_debug_log($payload->order_id, 'COS-Manually', $payload, __FILE__);

        $actionById = $searchreq->actionById; //*
        $actionByName = $searchreq->actionByName; //*
        $order_ids = $searchreq->order_ids; //*
        $status = 6;
        $comment = isset($searchreq->comment) ? $searchreq->comment : '';
        $reason = isset($searchreq->reason) ? $searchreq->reason : '';
        $role = isset($searchreq->role) ? $searchreq->role : '';
        $res = [];
        $failed = 0;
 
        //-------------Validate required fields ------------
        if (empty($actionById) || empty($actionByName) || empty($order_ids) || empty($reason)) {
            return array("status" => 0, "code" => "10200", "message" => "Invalid Input, Required fields are missing");
        }

        foreach ($order_ids as $order_id) {
            $filter = ['_id' => (int) $order_id];
            $document = $this->dbo->findOne("masters", "orders", $filter, array("order.orderitem.activity" => 0));
            if (empty($document)) {
                $res[$order_id] = ['status' => 0, "message" => "Invalid Order id"];
                $failed = 1;
                continue;
            }
            $current_w_id = $document['wid']; //using
            $current_w_did = $document['wodid'];
            $corporateid = $document['order']['patientinfo']['corporateid']; //using 
            $service_type = $document['order']['patientinfo']['service_type']; //using
            $billingDid = $document['billing']['billing_did'];
            //print_r($billingDid);exit;
            $mode_of_service = $document['mode_of_service']; //using
            $component_id = $document['active_component']; //using
            $applicationNumber = isset($document['order']['patientinfo']['application_no']) ? $document['order']['patientinfo']['application_no'] : "";
            $logaction = $log_desc = 'Order Completed Manually';
            $set = array(
                'OStatus' => 6,
                'WOStatus' => 0,
                'order.patientinfo.order_status' => "6",
                'order.order_status.order_status' => "6",
                'order.order_status.reason' => $searchreq->reason,
                'order.order_status.comment' => $comment,
                'order.order_status.last_updated_by' => $actionByName,
                'order.order_status.last_updated_on' => date("Y-m-d\TH:i:s") . ".000Z"
            );

            $push = array("flags"=>$reason);
            // update to chiss
            $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 6];
            $rp = $this->orderActionChiss($input_payload, 6, $ticket, $is_multi = 0, $updateToChiss = 0);
            if ($rp['status'] == 0) {
                return $rp;
            }

            $set['order.patientinfo.order_completion_datetime'] = date("Y-m-d H:i:s");
            $set['order.patientinfo.completed_time'] = date("Y-m-d H:i:s");
            $update = $this->dbo->update("masters", "orders", $filter, $set, $push, array("multi" => true));
            if (!empty($applicationNumber)) {
                $this->update_to_IHS($order_id, $corporateid);
            }
            if (empty($corporateid)) {
                $this->update_to_mdm_on_order_completion($document);
            }

            //checking wheather bill is generated or not
            $billFilter = array("billing.patientinfo.order_id" => $document[_id]);
            $billDetails = $this->dbo->findOne("masters","billing_info",$billFilter);
            //print_r($billDetails);exit;

            if(empty($billDetails))
            {
                $bill_payload = (object)["OrderID" =>$document[_id]];
                $financeObj = new Finance;
                $result = $financeObj->generateBill($bill_payload);
                //print_r($result);exit;
                // if ($result['status'] == "1")  
                // {
                //     return $result;
                // }
            }
            // insert order log
            $extraLogFields["businessId"] = $service_type;
            $extraLogFields["MOSID"] = $mode_of_service;
            $this->orderinfo->createlog($role, $status, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason, $comment, $facility_id = '', $popname = '', $extraLogFields, (isset($searchreq->scheduled_date)) ? 1 : 0, $searchreq->scheduled_date, $component_id);
            $res[$order_id] = ['status' => 1, "message" => "Order Updated Successfully"];
        }

        if ($failed != 1) {
            return ['status' => 1, "code" => "10100", "message" => "Order Updated Successfully"];
        } else {
            return ['status' => 0, "code" => "10300", "message" => "Order Updated Partially", 'data' => $res];
        }
    }

    public function change_order_status($payload, $ticket)
    {
        $searchreq = $payload;
        create_debug_log($payload->order_id, 'COS-Start', $payload, __FILE__);
        //$fg = $this->utility->async_get_curl('http://172.26.7.111/hemant/OMS/demo.php',json_encode($payload));
        $actionById = $searchreq->actionById; //*
        $actionByName = $searchreq->actionByName; //*
        $order_id = $searchreq->order_id; //*
        $status = intval($searchreq->status); //*
        $source = isset($searchreq->source) ? $searchreq->source : 'mobile';
        $comment = isset($searchreq->comment) ? $searchreq->comment : '';
        $reasonType = isset($searchreq->reasonType) ? $searchreq->reasonType : ''; // 1:CH || 2:CUSTOMER 3.OTHER
        $reason = isset($searchreq->reason) ? $searchreq->reason : '';
        //$reason_text = isset($searchreq->reason_text) ? $searchreq->reason_text : '';
        $latitude = isset($searchreq->latitude) ? $searchreq->latitude : '';
        $longitude = isset($searchreq->longitude) ? $searchreq->longitude : '';

        // for bulk processing
        $is_multi = isset($searchreq->is_multi) ? $searchreq->is_multi : 0;
        $updateToChiss = isset($searchreq->updateToChiss) ? $searchreq->updateToChiss : 0;
        $event_flag = 0;

        if (is_array($order_id)) {
            if (count($order_id) == 1) {
                $order_id = (int) $order_id[0];
            }
            if (count($order_id) > 1) {
                return $this->change_order_status_bulk($payload, $ticket);
            }
        }

        //-------------Validate required fields ------------
        if (empty($actionById) || empty($actionByName) || empty($order_id) || !isset($status)) {
            return array("status" => 0, "code" => "10200", "message" => "Invalid Input, Required fields are missing");
        }

        //-------------get order collection based on order_id ------------
        $filter = ['_id' => (int) $order_id]; //255293
        $document = $order = $this->dbo->findOne("masters", "orders", $filter, array("order.orderitem.activity" => 0));
        create_debug_log($order_id, 'COS-OriginalOrder', $order, __FILE__);
        if (empty($order)) {
            return array("status" => 0, "code" => "10300", "message" => "Invalid Order Id");
        }

        //var_dump( $order); die;

        // --- check weather penalty is exist or not order.patientinfo.mrn
        /*
        if($status == 7){
        $filterP = ['mrn' => (int) $document['order']['patientinfo']['mrn'], 'type' => 'PENALTY', 'status' => 4]; //255293 $document
        $penalties = $this->dbo->find("masters", "orders_refund_penalties", $filterP, []);
        $pAmount = 0; $penaltiesArr = [];
        foreach($penalties as $itemm){
        if(floatval($itemm['amount']) > 0 ){
        $pAmount += floatval($itemm['amount']);
        $penaltiesArr[] = ['penalty_id'=> (String)$itemm['_id'], 'amount' => $itemm['amount'] ];
        }
        }
        if (floatval($pAmount) > 0 ) {
        return array("status" => 0, "code" => "40700", "message" => "You have pending penalty, Please pay before rescheduling order", 'data' => ['amount' => $pAmount, 'penalties'=> $penaltiesArr ]  );
        }
        } */

        //-------------check weather same or different status ------------
        $order_status_old = $document['order']['patientinfo']['order_status']; // = 10;

        if ($order_status_old == "6") {
            $response = array("status" => 0, "code" => "40801", "message" => "No action can be taken on a completed Order. Kindly reload the Page.");
            return $response;
        }
        if (isset($searchreq->currentStatus)) {
            //echo  (int)$searchreq->currentStatus.$order_status_old;exit;
            //    echo ((int)$searchreq->currentStatus != (int)order_status_old);exit;
            if ((int) $searchreq->currentStatus != (int) $order_status_old) {
                //echo  $order_status_old.$searchreq->currentStatus;exit;
                $response = array("status" => 0, "code" => "40800", "message" => "Status of this Order has changed. Kindly reload the Page.");
                return $response;
            }
        }

        $component_id = intval($document['active_component']); //using
        if (intval($order_status_old) == $status && $status != 7) {
            return array("status" => 0, "code" => "10400", "message" => "Order already in the same status.");
        }

        if ($component_id == 0) {
            return array("status" => 0, "code" => "20900", "message" => "active component is missing, order not created properly");
        }
        //-------------Validate status precondition // extra validation------------
        $z = $this->validate_status_precondition($order_status_old, $status, $component_id);
        if ($z['status'] == 0) {
            return array("status" => 0, "code" => "10500", "message" => $rest['msg']);
        }

        //-------------log_actions ------------
        switch ($status) {
            case 0:
                $logaction = "Unassigned";
                //$eventid = 31;
                break;
            case 1:
                $logaction = "Assigned";
                //$eventid = 30;
                break;
            case 2:
                $logaction = "accepted";
                $eventid = 23;
                break;
            case 3:
                $logaction = "started";
                $eventid = 24;
                break;
            case 4:
                $logaction = "reached";
                $eventid = 25;
                break;
            case 5:
                $logaction = "delivered"; //InProgress
                $eventid = 23;
                break;
            case 6:
                $logaction = "Completed";
                $eventid = 26;
                break;
            case 7:
                $logaction = "Reschedule";
                $eventid = 31;
                break;
            case 8:
                $logaction = "Cancelled";
                $eventid = 30;
                break;
            case 9:
                $logaction = "rejected";
                $eventid = 29;
                break;
            case 15:
                $logaction = "Cancel Requested";
                $eventid = 30;
                break;
            case 16:
                $logaction = "reschedule requested";
                $eventid = 31;
                break;
        }

        //-------------Fetch required data that is being used for processing ------------
        $yr = date('y');
        $chissInputPayload = null;
        $order_details = [];

        $component_order = $document['component_order']; //using Is array
        $current_w_id = $document['wid']; //using
        $current_w_did = $document['wodid']; //using
        $facility_id = $document['order']['patientinfo']['facility_id']; //using
        $popname = $document['order']['patientinfo']['popname']; //using
        $service_type = $document['order']['patientinfo']['service_type']; //using
        $mode_of_service = $document['mode_of_service']; //using engagement level
        $corporateid = $document['order']['patientinfo']['corporateid']; //using

        //$trans_id = $document['order']['patientinfo']['istransactioncare'];
        $subtype_id = $document['order']['patientinfo']['service_subtype_id'];
        $order_type = isset($document['order']['ordertype']) ? $document['order']['ordertype'] : "";
        $reportDeliveryDate = $document['order']['patientinfo']['final_delivery_date'];
        $scheduled_date = $document['order']['patientinfo']['scheduled_date'];
        $order_did = $document['odid'];
        $order_id = $document['_id'];
        $orderitem = $document['order']['orderitem'];
        $order_pre_status_value = $document['OStatus'];
        $order_officerold = $document['assaigned_to'];
        $applicationNumber = isset($document['order']['patientinfo']['application_no']) ? $document['order']['patientinfo']['application_no'] : "";
        $vdeliveryflag = isset($document['order']['patientinfo']['vdeliver_flag']) ? $document['order']['patientinfo']['vdeliver_flag'] : "";
        //$service_type = $document['order']['patientinfo']['service_type'];
        $is_assistance = isset($document['order']['assocdata']['is_assistance']) ? $document['order']['assocdata']['is_assistance'] : "0";
        $current_time = date("Y-m-d\TH:i:s") . ".000Z";
        $payable_amount = floatval($document['payment_info']['payable_amount']);
        // ------------set role --------------
        $role = "MHO"; //using
        if ($service_type == "4" || $order_type == "childrad" || $order_type == "rad") {
            $role = "Onsite Facilitator";
        } else if ($service_type == "2") {
            $role = "DDO";
        }
        //-------------- $set clause for Order update ----------------
        $set = array(
            'OStatus' => (int) $searchreq->status,
            'WOStatus' => (int) $searchreq->status,
            //'order.patientinfo.cancel_request_time' => (string) $cancelreqesttime,
            //'order.patientinfo.reschedule_request_time' => (string) $reschedulereqesttime,
            //'order.patientinfo.order_guid' => (string) $order_guid,
            'order.patientinfo.order_status' => (string) $searchreq->status,
            //'order.patientinfo.vdeliver_flag' => $vdeliveryflag,
            'order.order_status.order_status' => (string) $searchreq->status,
            'order.order_status.reason' => $searchreq->reason,
            'order.order_status.comment' => $comment,
            'order.order_status.last_updated_by' => $actionByName,
            'order.order_status.last_updated_on' => date("Y-m-d\TH:i:s") . ".000Z",
        );
        $extraLogFields = array();

        $res_msg = "";
        // 1. Medical - type1 (Phlebo) - blood collection officer
        // 2. Medical - type2     Mho/Physio/Nurse/ST/OT/wellness trainers/CCR
        if ($component_id == 1 || $component_id == 2) {

            switch ($status) {

                //------------- for status 2 : accepted------------
                case 2:
                    $log_desc = $res_msg = 'Order Accepted';
                    $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 2];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $input_payload;
                        return "validated";
                    }
                    if ($is_multi == 0) {
                        $rp = $this->orderActionChiss($input_payload, 2, $ticket, $is_multi, $updateToChiss);
                        if ($rp['status'] == 0) {
                            return $rp;
                        }
                    }
                    $set['assigned_to'] = $actionById;
                    $set['order.order_status.assignedto'] = $actionById;
                    $set['order.order_status.mhoname'] = $actionByName;
                    break;
                //------------- for status 3 : Started ------------
                case 3:
                    $log_desc = $res_msg = 'Order Started';
                    //$this->send_associate($order_id, $status, $component_id,$aHelh, $pHelh);
                    //$set['sent_associate'] = 1;
                    $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 3];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $input_payload;
                        return "validated";
                    }
                    if ($is_multi == 0) {
                        //return $updateToChiss;
                        $rp = $this->orderActionChiss($input_payload, 3, $ticket, $is_multi, $updateToChiss);
                        if ($rp['status'] == 0) {
                            return $rp;
                        }
                    }
                    break;
                //------------- for status 4 : reached------------
                case 4:
                    $log_desc = $res_msg = 'Order : Officer Reached';
                    break;
                //------------- for status 5 : Delivered------------
                case 5:
                    $log_desc = $res_msg = 'Order Delivered';
                    break;
                //------------- for status 6 : Completed------------
                case 6:
                    if ((int) $order_pre_status_value != 5) {
                        return array("status" => 0, "code" => "10600", "message" => "Order status cannot be changed");
                    }
                    $log_desc = $res_msg = 'Order Completed';
                    $next_component = $component_order[array_search($component_id, $component_order) + 1];
                    /*if (isset($next_component)) {
                    $set['active_component'] = $next_component;
                    }*/

                    if ($component_id == 1) {

                        $next_component = $component_order[array_search($component_id, $component_order) + 1];
                        if (isset($next_component)) {
                            $status = 106;
                            //$set['order.patientinfo.diag_sample_status']="0";
                        } else if ((int) $service_type == 3) {
                            // urin cotinen
                            $set['order.patientinfo.diag_sample_status'] = "0";
                        }

                        if ($document['report_required'] == 1) {
                            $event_flag = 3;
                        }
                    }

                    $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 6];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $input_payload;
                        return "validated";
                    }
                    if ($is_multi == 0) {
                        $rp = $this->orderActionChiss($input_payload, 6, $ticket, $is_multi, $updateToChiss);
                        if ($rp['status'] == 0) {
                            return $rp;
                        }
                    }

                    if ($component_id == 2) {
                        $set['order.patientinfo.order_completion_datetime'] = date("Y-m-d H:i:s");
                        $set['order.patientinfo.completed_time'] = date("Y-m-d H:i:s");
                        if (!empty($applicationNumber)) {
                            $this->update_to_IHS($order_id, $corporateid);
                        }
                        if (empty($corporateid)) {
                            $this->update_to_mdm_on_order_completion($document);
                        }
                    }
                    // partially completed
                    $set['OStatus'] = $status;
                    $set['WOStatus'] = 0;
                    $set['order.patientinfo.order_status'] = (string) $status;
                    $set['order.order_status.order_status'] = (string) $status;

                    // send to associate
                    //echo "q";exit;
                    $this->send_associate($order_id, $current_w_id, $status, $component_id, $aHelh = 0, $pHelh = 1);
                    $set['sent_associate'] = 1;

                    // set action flag
                    if ($status == 6) {
                        //order.business.is_transaction is_package
                        if (!isset($document['billing']['billing_did'])) {
                            $financeobj = new Finance;
                            $financeobj->generateBill((object) array("OrderID" => $order_id));
                        }

                        if ($document['order']['business']['is_transaction'] == 1) {
                            $event_flag = 22;
                        }
                        if ($document['order']['business']['is_assessment'] == 1) { //assessment
                            $event_flag = 21;
                        }
                        if ($document['order']['business']['is_continuous'] == 1) { // careplan
                            $event_flag = 20;
                        }
                    }

                    break;
                //------------- for status 7 : Rescheduled------------
                case 7:
                    $log_desc = $res_msg = 'Order Rescheduled';
                    if (in_array(array(4, 5), $order_pre_status_value)) {
                        $this->send_associate($order_id, $current_w_id, $status, $component_id, $aHelh = 0, $pHelh = 1);
                    }
                    $schRes = $this->reschedule_order($searchreq, $document, $order_id, $is_multi, $updateToChiss);
                    if ($schRes == 'validated') {
                        return "validated";
                    }
                    if ($schRes['status'] == 0) {
                        return $schRes;
                    }
                    $set = array_merge($set, $schRes['set']);
                    $event_flag = $schRes['event_flag'];
                    $chissInputPayload = $schRes['chissInputPayload'];
                    break;
                //------------- for status 8 : Cancelled------------
                case 8:
                    $log_desc = $res_msg = 'Order Cancelled';

                    if (!isset($searchreq->reason) || empty($searchreq->reason)) {
                        return array("status" => 0, "code" => "30500", "message" => "reason is missing");
                    }
                    $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 8];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $input_payload;
                        return "validated";
                    }
                    if ($is_multi == 0) {
                        //return $updateToChiss;
                        $rp = $this->orderActionChiss($input_payload, 8, $ticket, $is_multi, $updateToChiss);
                        if ($rp['status'] == 0) {
                            return $rp;
                        }
                    }
                    break;
                case 9:
                    $log_desc = $res_msg = 'Order Rejected';
                    if (!isset($searchreq->reason) || empty($searchreq->reason)) {
                        return array("status" => 0, "code" => "30500", "message" => "reason is missing");
                    }
                    // create new work order
                    $seqwoid = $this->utility->getNextSequence("WORKORDERID");
                    $new_workorder_id = $this->utility->getNextSequence("WOID");
                    $new_workorder_did = "WO-000-" . date('y') . "-" . $seqwoid;
                    $orderitem = $document['order']['orderitem'];
                    $provider_info = $document['order']['provider_info'];
                    $scheduled_date = $document['order']['patientinfo']['scheduled_date'];

                    $chissInputPayload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "new_wo_id" => $new_workorder_id, "order_status" => 9];

                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $chissInputPayload;
                        return "validated";
                    }

                    $this->createworkorder($order_id, $new_workorder_id, $new_workorder_did, $scheduled_date, $orderitem, $status, $reason, $provider_info, $component_id);
                    break;
                case 15:
                    $log_desc = $res_msg = 'Request for cancellation';
                    if (!isset($searchreq->reason) || empty($searchreq->reason)) {
                        return array("status" => 0, "code" => "30500", "message" => "reason is missing");
                    }

                    if (in_array(array(4, 5), $order_pre_status_value)) {
                        $this->send_associate($order_id, $current_w_id, $status, $component_id, $aHelh = 0, $pHelh = 1);
                    }
                    $searchreq->subject = $log_desc;
                    $this->generateSugarCrmTicket($searchreq);
                    break;
                case 16:
                    $log_desc = $res_msg = 'Request for reschedule';

                    if (!isset($searchreq->reason) || empty($searchreq->reason)) {
                        return array("status" => 0, "code" => "30500", "message" => "reason is missing");
                    }
                    if (in_array(array(4, 5), $order_pre_status_value)) {
                        $this->send_associate($order_id, $current_w_id, $status, $component_id, $aHelh = 0, $pHelh = 1);
                    }
                    $searchreq->subject = $log_desc;
                    $this->generateSugarCrmTicket($searchreq);
                    break;
                default:

                    //return array("status" => 0, "code" => "10600", "message" => "Invalid Order Status.");
                    $response = array("status" => 0, "code" => "10600", "message" => "Invalid Order Status.");

                    $this->log->create_log("", "", "statusUpdate", "Execution", 200, "change_order_status_end", json_encode($response), (string) $ticket);
                    return $response;
            }

            if (intval($searchreq->date_specified) == 1) {
                if (!isset($searchreq->scheduled_date) || empty($searchreq->scheduled_date)) {
                    return array("status" => 0, "code" => "10900", "message" => "Scheduled date is missing");
                }
                if (!isset($searchreq->start_time) || empty($searchreq->start_time)) {
                    return array("status" => 0, "code" => "20700", "message" => "start_time is missing");
                }
                if (!isset($searchreq->end_time) || empty($searchreq->end_time)) {
                    return array("status" => 0, "code" => "20800", "message" => "end_time is missing");
                }

                $scheduled_date = $searchreq->scheduled_date;
                $scheduled_date = date('Y-m-d\TH:i:s', strtotime($scheduled_date)) . '.000Z';
                $extraLogFields['requested_date'] = $scheduled_date;
                $extraLogFields['start_time'] = $searchreq->start_time;
                $extraLogFields['end_time'] = $searchreq->end_time;
                $extraLogFields['chiss_transaction_id'] = $searchreq->chiss_transaction_id;
                $set['order.patientinfo.scheduled_date'] = $scheduled_date;
                $set['order.patientinfo.servicedate'] = $this->dbo->date(strtotime($scheduled_date));
            }

            $filter = array('order.patientinfo.order_id' => (int) $order_id);
            create_debug_log($order_id, 'COS-setBeforeOdrUpdate', $set, __FILE__);
            $update = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multi" => true));
            //Update workorder
            $order_details[$order_id]['reason'] = $reason;
            $this->orderinfo->changeWoStatus($status, $order_id, $order_details, $current_w_id, $assignedid = $actionById, $assignedname = $actionByName);
            // call chiss for rescheduling //
            $extraLogFields["businessId"] = $service_type;
            $extraLogFields["MOSID"] = $mode_of_service;
            if ($status == 7 || $status == 9) {
                if ($is_multi == 0) {
                    $this->orderinfo->createlog($role, $status, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason, $comment, $facility_id, $popname, $extraLogFields, (isset($searchreq->scheduled_date)) ? 1 : 0, $searchreq->scheduled_date, $component_id);
                    $rp = $this->orderActionChiss($chissInputPayload, $status, $ticket, $is_multi, $updateToChiss);
                    if ($rp['status'] == 0) {
                        return $rp;
                    }
                }
            }

            // create log
            if (!($status == 7 || $status == 9)) {
                $this->orderinfo->createlog($role, $status, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason, $comment, $facility_id, $popname, $extraLogFields, (isset($searchreq->scheduled_date)) ? 1 : 0, $searchreq->scheduled_date, $component_id);
            }
            $this->trigger_email_sms_event($order_id, $status, $component_id, $mode_of_service, $service_type, $event_flag, $corporateid);

            //return array("status" => 1, "code" => "10100", "message" => $res_msg);
            $response = array("status" => 1, "code" => "10100", "message" => $res_msg);
            $this->log->create_log("", "", "statusUpdate", "Execution", 200, "change_order_status_end", json_encode($response), (string) $ticket);
            return $response;
        } else

        // Centre Admin  -  (imaging/radiology)
        if ($component_id == 3) {
            switch ($status) {
                //------------- for status 2 : accepted------------
                case 2:
                    $log_desc = $res_msg = 'Order Accepted';
                    /*$input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 2];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                    $this->chissPayload[] = $input_payload;
                    return "validated";
                    }
                    if ($is_multi == 0) {
                    $rp = $this->orderActionChiss($input_payload, 2, $ticket, $is_multi, $updateToChiss);
                    if ($rp['status'] == 0) {
                    return $rp;
                    }
                    }*/
                    // if scheduled_date is provided then save as it is
                    $set['assigned_to'] = $actionById;
                    $set['order.order_status.assignedto'] = $actionById;
                    $set['order.order_status.mhoname'] = $actionByName;
                    if (!empty($searchreq->scheduled_date)) {
                        $scheduled_date = $searchreq->scheduled_date;
                        $scheduled_date = date('Y-m-d\TH:i:s', strtotime($scheduled_date)) . '.000Z';
                        $set['order.patientinfo.scheduled_date'] = $scheduled_date;
                        $set['order.patientinfo.servicedate'] = $this->dbo->date(strtotime($scheduled_date));
                    }

                    break;
                case 301:
                    $log_desc = $res_msg = 'Customer reached';
                    break;
                case 5:
                    $log_desc = $res_msg = 'In progress';
                    break;
                case 6:
                    $log_desc = $res_msg = 'Order Completed';
                    $next_component = $component_order[array_search($component_id, $component_order) + 1];
                    if (isset($next_component)) {
                        $set['active_component'] = (string) $next_component;
                        $status = 103;
                        // partially completed
                        $set['OStatus'] = $status;
                        $set['WOStatus'] = 6;
                        $set['order.patientinfo.order_status'] = (string) $status;
                        $set['order.order_status.order_status'] = (string) $status;
                    }

                    $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 6];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $input_payload;
                        return "validated";
                    }
                    if ($is_multi == 0) {
                        $rp = $this->orderActionChiss($input_payload, 6, $ticket, $is_multi, $updateToChiss);
                        if ($rp['status'] == 0) {
                            return $rp;
                        }
                    }
                    // send to associate
                    if ($status == 6) {
                        $this->send_associate($order_id, $current_w_id, $status, $component_id, $aHelh = 0, $pHelh = 1);
                        $set['sent_associate'] = 1;
                        $set['order.patientinfo.order_completion_datetime'] = date("Y-m-d H:i:s");
                        $set['order.patientinfo.completed_time'] = date("Y-m-d H:i:s");
                        if (!empty($applicationNumber)) {
                            $this->update_to_IHS($order_id, $corporateid);
                        }
                        if (empty($corporateid)) {
                            $this->update_to_mdm_on_order_completion($document);
                        }
                    }
                    break;
                //------------- for status 7 : Rescheduled------------
                case 7:
                    $log_desc = $res_msg = 'Order Rescheduled';
                    if (in_array(array(4, 5), $order_pre_status_value)) {
                        $this->send_associate($order_id, $current_w_id, $status, $component_id, $aHelh = 0, $pHelh = 1);
                    }
                    $schRes = $this->reschedule_order($searchreq, $document, $order_id, $is_multi, $updateToChiss);
                    if ($schRes == 'validated') {
                        return "validated";
                    }
                    if ($schRes['status'] == 0) {
                        return $schRes;
                    }
                    $set = array_merge($set, $schRes['set']);
                    $event_flag = $schRes['event_flag'];
                    $chissInputPayload = $schRes['chissInputPayload'];
                    break;

                case 8:
                    $log_desc = $res_msg = 'Order Cancelled';
                    if (!isset($searchreq->reason) || empty($searchreq->reason)) {
                        return array("status" => 0, "code" => "30500", "message" => "reason is missing");
                    }
                    $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 8];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $input_payload;
                        return "validated";
                    }
                    if ($is_multi == 0) {
                        //return $updateToChiss;
                        $rp = $this->orderActionChiss($input_payload, 8, $ticket, $is_multi, $updateToChiss);
                        if ($rp['status'] == 0) {
                            return $rp;
                        }
                    }
                    break;
                case 15:
                    $log_desc = $res_msg = 'Request for cancellation';
                    if (!isset($searchreq->reason) || empty($searchreq->reason)) {
                        return array("status" => 0, "code" => "30500", "message" => "reason is missing");
                    }
                    if (in_array(array(4, 5), $order_pre_status_value)) {
                        $this->send_associate($order_id, $current_w_id, $status, $component_id, $aHelh = 0, $pHelh = 1);
                    }
                    $searchreq->subject = $log_desc;
                    $this->generateSugarCrmTicket($searchreq);
                    break;
                case 16:
                    $log_desc = $res_msg = 'Request for reschedule';
                    if (in_array(array(4, 5), $order_pre_status_value)) {
                        $this->send_associate($order_id, $current_w_id, $status, $component_id, $aHelh = 0, $pHelh = 1);
                    }
                    if (!isset($searchreq->reason) || empty($searchreq->reason)) {
                        return array("status" => 0, "code" => "30500", "message" => "reason is missing");
                    }

                    if (intval($searchreq->date_specified) == 1) {
                        if (!isset($searchreq->scheduled_date) || empty($searchreq->scheduled_date)) {
                            return array("status" => 0, "code" => "10900", "message" => "Scheduled date is missing");
                        }
                        if (!isset($searchreq->start_time) || empty($searchreq->start_time)) {
                            return array("status" => 0, "code" => "20700", "message" => "start_time is missing");
                        }
                        if (!isset($searchreq->end_time) || empty($searchreq->end_time)) {
                            return array("status" => 0, "code" => "20800", "message" => "end_time is missing");
                        }
                    }

                    $scheduled_date = $searchreq->scheduled_date;
                    $scheduled_date = date('Y-m-d\TH:i:s', strtotime($scheduled_date)) . '.000Z';
                    $extraLogFields['requested_date'] = $scheduled_date;
                    $extraLogFields['start_time'] = $searchreq->start_time;
                    $extraLogFields['end_time'] = $searchreq->end_time;
                    $extraLogFields['chiss_transaction_id'] = $searchreq->chiss_transaction_id;
                    $searchreq->subject = $log_desc;
                    $this->generateSugarCrmTicket($searchreq);
                    break;
                default:return array("status" => 0, "code" => "10600", "message" => "Invalid Order Status.");
            }
            create_debug_log($order_id, 'COS-setBeforeOdrUpdate', $set, __FILE__);
            $filter = array('order.patientinfo.order_id' => (int) $order_id);
            $update = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multi" => true));
            //Update workorder
            $order_details[$order_id]['reason'] = $reason;
            $this->orderinfo->changeWoStatus($status, $order_id, $order_details, $current_w_id, $assignedid = $actionById, $assignedname = $actionByName);
            // call chiss for rescheduling //
            // create log
            $extraLogFields["businessId"] = $service_type;
            $extraLogFields["MOSID"] = $mode_of_service;
            if ($status == 7) {
                if ($is_multi == 0) {
                    $this->orderinfo->createlog($role, $status, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason, $comment, $facility_id, $popname, $extraLogFields, (isset($searchreq->scheduled_date)) ? 1 : 0, $searchreq->scheduled_date, $component_id);
                    $rp = $this->orderActionChiss($chissInputPayload, 7, $ticket, $is_multi, $updateToChiss);
                    if ($rp['status'] == 0) {
                        return $rp;
                    }
                }
            }
            if ($status != 7) {
                $this->orderinfo->createlog($role, $status, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason, $comment, $facility_id, $popname, $extraLogFields, (isset($searchreq->scheduled_date)) ? 1 : 0, $searchreq->scheduled_date, $component_id);
            }
            $this->trigger_email_sms_event($order_id, $status, $component_id, $mode_of_service, $service_type, $event_flag, $corporateid);
            return array("status" => 1, "code" => "10100", "message" => $res_msg);
        } else
        // Facilitator
        if ($component_id == 4) {
            // To do
        } else
        // Doctor
        if ($component_id == 5) {

            switch ($status) {

                case 0:
                    $log_desc = $res_msg = 'Order Confirmed';
                    $next_component = $component_order[array_search($component_id, $component_order) + 1];
                    if (isset($next_component)) {
                        $set['active_component'] = (string) $next_component;
                    }
                    break;
                //------------- for status 2 : accepted------------
                case 2:
                    $log_desc = $res_msg = 'Order Accepted';
                    $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 2];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $input_payload;
                        return "validated";
                    }
                    if ($is_multi == 0) {
                        $rp = $this->orderActionChiss($input_payload, 2, $ticket, $is_multi, $updateToChiss);
                        if ($rp['status'] == 0) {
                            return $rp;
                        }
                    }
                    $set['assigned_to'] = $actionById;
                    $set['order.order_status.assignedto'] = $actionById;
                    $set['order.order_status.doctorname'] = $actionByName;
                    break;
                //------------- for status 3 : Started ------------
                case 3:
                    $log_desc = $res_msg = 'Consultation Started';
                    //$this->send_associate($order_id, $status, $component_id,$aHelh, $pHelh);
                    //$set['sent_associate'] = 1;
                    $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 3];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $input_payload;
                        return "validated";
                    }
                    if ($is_multi == 0) {
                        //return $updateToChiss;
                        $rp = $this->orderActionChiss($input_payload, 3, $ticket, $is_multi, $updateToChiss);
                        if ($rp['status'] == 0) {
                            return $rp;
                        }
                    }
                    break;

                case 6:
                    $log_desc = $res_msg = 'Consultation Completed';
                    // if status
                    $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 6];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $input_payload;
                        return "validated";
                    }
                    if ($is_multi == 0) {
                        $rp = $this->orderActionChiss($input_payload, 6, $ticket, $is_multi, $updateToChiss);
                        if ($rp['status'] == 0) {
                            return $rp;
                        }
                    }
                    if (floatval($document['payment_info']['payable_amount']) > 0 && empty($corporateid)) {
                        $status = 505;
                        $set['OStatus'] = $status;
                        $set['WOStatus'] = 0;
                        $set['order.patientinfo.order_status'] = (string) $status;
                        $set['order.order_status.order_status'] = (string) $status;
                    } else {
                        $set['order.patientinfo.order_completion_datetime'] = date("Y-m-d H:i:s");
                        $set['order.patientinfo.completed_time'] = date("Y-m-d H:i:s");
                        if (empty($corporateid)) {
                            $this->update_to_mdm_on_order_completion($document);
                        }
                        $financeobj = new Finance;
                        $financeobj->generateBill((object) array("OrderID" => $order_id));
                    }
                    if (!empty($applicationNumber)) {
                        $this->update_to_IHS($order_id, $corporateid);
                    }

                    break;
                //------------- for status 7 : Rescheduled------------
                case 7:
                    $log_desc = $res_msg = 'Order Rescheduled';
                    $schRes = $this->reschedule_order($searchreq, $document, $order_id, $is_multi, $updateToChiss);
                    if ($schRes == 'validated') {
                        return "validated";
                    }
                    if ($schRes['status'] == 0) {
                        return $schRes;
                    }
                    $set = array_merge($set, $schRes['set']);
                    $event_flag = $schRes['event_flag'];
                    $chissInputPayload = $schRes['chissInputPayload'];
                    break;
                //------------- for status 8 : Cancellation------------
                case 8:
                    $log_desc = $res_msg = 'Order Cancelled';
                    $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 8];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $input_payload;
                        return "validated";
                    }
                    if ($is_multi == 0) {
                        //return $updateToChiss;
                        $rp = $this->orderActionChiss($input_payload, 8, $ticket, $is_multi, $updateToChiss);
                        if ($rp['status'] == 0) {
                            return $rp;
                        }
                    }
                    break;
                case 15:
                    $log_desc = $res_msg = 'Request for cancellation';
                    if (!isset($searchreq->reason) || empty($searchreq->reason)) {
                        return array("status" => 0, "code" => "30500", "message" => "reason is missing");
                    }
                    $searchreq->subject = $log_desc;
                    $this->generateSugarCrmTicket($searchreq);
                    break;
                case 16:
                    $log_desc = $res_msg = 'Request for reschedule';
                    if (!isset($searchreq->reason) || empty($searchreq->reason)) {
                        return array("status" => 0, "code" => "30500", "message" => "reason is missing");
                    }

                    if (intval($searchreq->date_specified) == 1) {
                        if (!isset($searchreq->scheduled_date) || empty($searchreq->scheduled_date)) {
                            return array("status" => 0, "code" => "10900", "message" => "Scheduled date is missing");
                        }
                        if (!isset($searchreq->start_time) || empty($searchreq->start_time)) {
                            return array("status" => 0, "code" => "20700", "message" => "start_time is missing");
                        }
                        if (!isset($searchreq->end_time) || empty($searchreq->end_time)) {
                            return array("status" => 0, "code" => "20800", "message" => "end_time is missing");
                        }
                    }

                    $scheduled_date = $searchreq->scheduled_date;
                    $scheduled_date = date('Y-m-d\TH:i:s', strtotime($scheduled_date)) . '.000Z';
                    $extraLogFields['requested_date'] = $scheduled_date;
                    $extraLogFields['start_time'] = $searchreq->start_time;
                    $extraLogFields['end_time'] = $searchreq->end_time;
                    $extraLogFields['chiss_transaction_id'] = $searchreq->chiss_transaction_id;
                    $searchreq->subject = $log_desc;
                    $this->generateSugarCrmTicket($searchreq);
                    break;
                default:return array("status" => 0, "code" => "10600", "message" => "Invalid Order Status.");
            }
            create_debug_log($order_id, 'COS-setBeforeOdrUpdate', $set, __FILE__);
            $filter = array('order.patientinfo.order_id' => (int) $order_id);
            $update = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multi" => true));
            //Update workorder
            $order_details[$order_id]['reason'] = $reason;
            $this->orderinfo->changeWoStatus($status, $order_id, $order_details, $current_w_id, $assignedid = $actionById, $assignedname = $actionByName);
            // call chiss for rescheduling //
            $extraLogFields["businessId"] = $service_type;
            $extraLogFields["MOSID"] = $mode_of_service;
            if ($status == 7) {
                if ($is_multi == 0) {
                    $this->orderinfo->createlog($role, $status, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason, $comment, $facility_id, $popname, $extraLogFields, (isset($searchreq->scheduled_date)) ? 1 : 0, $searchreq->scheduled_date, $component_id);
                    $rp = $this->orderActionChiss($chissInputPayload, 7, $ticket, $is_multi, $updateToChiss);
                    if ($rp['status'] == 0) {
                        return $rp;
                    }
                }
            }
            // create log
            if ($status != 7) {
                $this->orderinfo->createlog($role, $status, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason, $comment, $facility_id, $popname, $extraLogFields, (isset($searchreq->scheduled_date)) ? 1 : 0, $searchreq->scheduled_date, $component_id);
            }
            $this->trigger_email_sms_event($order_id, $status, $component_id, $mode_of_service, $service_type, $event_flag, $corporateid);
            return array("status" => 1, "code" => "10100", "message" => $res_msg);
        } else
        // Adiministrative (GYM/BLOOD bank/Gene mapping)
        if ($component_id == 6) {
            // To do
        } else
        // Associate  (Phlebo/imaging)
        if ($component_id == 7) {
            $report_flag_set = 0;
            switch ($status) {

                //------------- for status 102 : Pending processing to center------------
                case 102:
                    $log_desc = $res_msg = 'Sample Accepted by PHelp';
                    $Updation = new Orderupdation;
                    //return $payload;
                    $res = $Updation->UpdateBarcode($payload);
                    if ($res['response'] == 0) {
                        return array("status" => 0, "code" => "40900", "message" => $res['message']);
                    }
                    $set['order.patientinfo.sample_submitted_by_phelp_date'] = $this->utility->getCurrenttime();
                    $this->send_associate($order_id, $current_w_id, $status, $component_id, $aHelh = 1, $pHelh = 0);

                //------------- for status 102 : accepted------------
                case 103:
                    $log_desc = $res_msg = 'Sample Order Accepted by Associate';
                    $set['assigned_to'] = $actionById;
                    $set['order.order_status.assignedto'] = $actionById;
                    // $set['order.order_status.mhoname'] = $actionByName;
                    $set['order.patientinfo.pickUpBoyName'] = $payload->pickUpBoyName;
                    $set['order.patientinfo.pickUpBoyNo'] = $payload->pickUpBoyNo;
                    $set['order.patientinfo.pickUpBoyType'] = $payload->pickUpBoyType;
                    $set['order.patientinfo.sample_submitted_by_phelp_date'] = $this->utility->getCurrenttime();
                    break;
                //------------- for status 106 : Complete order / generate all report------------
                case 6:
                    $log_desc = $res_msg = 'Order Completed'; /// Generating all reports
                    $next_component = $component_order[array_search($component_id, $component_order) + 1];
                    if (isset($next_component)) {
                        $set['active_component'] = (string) $next_component;

                        if (empty($reportDeliveryDate) || abs((strtotime($reportDeliveryDate) - time()) >= 1314000)) {
                            $reportDeliveryDate = date('Y-m-d\TH:i:s', (time() + 86400)) . '.000Z';
                        }

                        $status = 0;
                        $set['OStatus'] = $status;
                        $set['WOStatus'] = $status;
                        $set['order.patientinfo.order_status'] = (string) $status;
                        $set['order.order_status.order_status'] = (string) $status;
                        $set['order.patientinfo.scheduled_date'] = $reportDeliveryDate;
                        $set['order.patientinfo.slot_transaction_id'] = '';
                        $set['order.patientinfo.servicedate'] = $this->dbo->date(strtotime($reportDeliveryDate));
                        // call

                        $report_flag_set = 1;
                        // async order creation //
                        //$config_obj = new config;
                        $input_payload["order_ids"] = [$order_id];
                        /*   $url = $this->config->getconfig('serverurl', "OMS/api/operation.php/v1/ordercreation_chiss");
                    $param = json_encode($input_payload);
                    $this->utility->async_curl($url, $param); */
                    } else {
                        $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 6];
                        if ($is_multi == 1 && $updateToChiss == 0) {
                            $this->chissPayload[] = $input_payload;
                            return "validated";
                        }
                        if ($is_multi == 0) {
                            $rp = $this->orderActionChiss($input_payload, 6, $ticket, $is_multi, $updateToChiss);
                            if ($rp['status'] == 0) {
                                return $rp;
                            }
                        }

                        $set['order.patientinfo.order_completion_datetime'] = date("Y-m-d H:i:s");
                        $set['order.patientinfo.completed_time'] = date("Y-m-d H:i:s");
                        if (!empty($applicationNumber)) {
                            $this->update_to_IHS($order_id, $corporateid);
                        }
                        if (empty($corporateid)) {
                            $this->update_to_mdm_on_order_completion($document);
                        }
                    }
                    break;

                default:return array("status" => 0, "code" => "10600", "message" => "Invalid Order Status.");
            }

            create_debug_log($order_id, 'COS-setBeforeOdrUpdate', $set, __FILE__);
            $filter = array('order.patientinfo.order_id' => (int) $order_id);
            $update = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multi" => true));
            //Update workorder
            $order_details[$order_id]['reason'] = $reason;
            $this->orderinfo->changeWoStatus($status, $order_id, $order_details, $current_w_id, $assignedid = $actionById, $assignedname = $actionByName);
            // create log
            //echo $status;exit;
            if ($report_flag_set == 1) {

                $seqwoid = $this->utility->getNextSequence("WORKORDERID");
                $new_workorder_id = $this->utility->getNextSequence("WOID");
                $new_workorder_did = "WO-" . date('dmy') . "-" . $seqwoid;
                //  $order_id  $current_w_id
                $this->addworkorder($order_id, $current_w_id, $new_workorder_id, $new_workorder_did, $reportDeliveryDate, $orderitem, "RDO work order created ", "8", "0", $mode_of_service, $service_type);

                //echo "check2";exit;

                $url = $this->config->getconfig('serverurl', "OMS/api/operation.php/v1/ordercreation_chiss");
                $param = json_encode($input_payload);
                //echo json_encode($param);

                if (in_array(13, $component_order) or in_array('13', $component_order)) {
                    $url = $this->config->getconfig('serverurl', "OMS/api/external_delivery.php/v1/delhivery/createOrder");
                    $input_payload = array("order_id" => $order_id, "assignedto" => "delhivery_express");
                    $param = json_encode($input_payload);
                }

                $this->utility->async_curl($url, $param);
            }

            // create log
            $extraLogFields["businessId"] = $service_type;
            $extraLogFields["MOSID"] = $mode_of_service;
            $this->orderinfo->createlog($role, $status, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason, $comment, $facility_id, $popname, $extraLogFields, (isset($searchreq->scheduled_date)) ? 1 : 0, $searchreq->scheduled_date, $component_id);

            $this->trigger_email_sms_event($order_id, $status, $component_id, $mode_of_service, $service_type, $event_flag, $corporateid);
            return array("status" => 1, "code" => "10100", "message" => $res_msg);
        } else

        // RDO/DDO- logistic partners : Delivery officer - Report/Drug
        if ($component_id == 8) {
            switch ($status) {

                //------------- for status 0 : Confirmed/pending aassignment of report delivery------------//
                case 0:
                    $log_desc = $res_msg = 'Confirmed/pending assignment of report delivery';
                    break;
                /*case 1: //Assign
                $log_desc = $res_msg = 'Order Assigned';
                if (!isset($searchreq->scheduled_date) || empty($searchreq->scheduled_date)) {
                return array("status" => 0, "code" => "10900", "message" => "Scheduled date is missing");
                }
                $scheduled_date = $searchreq->scheduled_date;
                $scheduled_date = date('Y-m-d\TH:i:s', strtotime($scheduled_date)) . '.000Z';
                $manual_alloc_payload["orders"][] = (Object) [
                "order_status" => 1,
                "order_id" => $order_id,
                "workorder_id" => $current_w_id,
                "officer_id" => $actionById,
                "officer_name" => $actionByName,
                "scheduled_date" => $scheduled_date,
                ];
                $yy = $this->orderinfo->manual_allocation($manual_alloc_payload, $ticket);
                if ($yy->response == 0) {
                return array("status" => 0, "code" => "20100", "message" => "Unable to Assign order, request failed from Chiss " . $yy->message);
                }
                break;
                 */
                case 2: //Accept
                    $log_desc = $res_msg = 'Order Accepted';
                    $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 2];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $input_payload;
                        return "validated";
                    }
                    if ($is_multi == 0) {
                        $rp = $this->orderActionChiss($input_payload, 2, $ticket, $is_multi, $updateToChiss);
                        if ($rp['status'] == 0) {
                            return $rp;
                        }
                    }
                    $set['assigned_to'] = $actionById;
                    $set['order.order_status.assignedto'] = $actionById;
                    $set['order.order_status.mhoname'] = $actionByName;
                    break;

                case 801: // Pickup
                    $log_desc = $res_msg = 'Report Picked up'; // , Copied from associate
                    break;
                case 3:
                    $log_desc = $res_msg = 'Started'; //Order sent to associate
                    $set['sent_associate'] = 1;
                    $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 3];

                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $input_payload;
                        return "validated";
                    }
                    if ($is_multi == 0) {
                        $rp = $this->orderActionChiss($input_payload, 3, $ticket, $is_multi, $updateToChiss);
                        if ($rp['status'] == 0) {
                            return $rp;
                        }
                    }
                    break;
                //------------- for status 4 : reached------------
                case 4:
                    $log_desc = $res_msg = 'Reached';
                    break;
                //------------- for status 5 : Delivered------------
                case 5:
                    $log_desc = $res_msg = 'Order Delivered';
                    break;
                //------------- for status 6 : Completed------------
                case 6:
                    if ((int) $order_pre_status_value != 5) {
                        return array("status" => 0, "code" => "10600", "message" => "Order status cannot be changed");
                    }
                    $log_desc = $res_msg = 'Order Completed';
                    $next_component = $component_order[array_search($component_id, $component_order) + 1];
                    if (isset($next_component)) {
                        $set['active_component'] = (string) $next_component;
                    } else {
                        $set['order.patientinfo.order_completion_datetime'] = date("Y-m-d H:i:s");
                        $set['order.patientinfo.completed_time'] = date("Y-m-d H:i:s");
                        if (!empty($applicationNumber)) {
                            $this->update_to_IHS($order_id, $corporateid);
                        }
                        if (empty($corporateid)) {
                            $this->update_to_mdm_on_order_completion($document);
                        }
                    }
                    $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 6];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $input_payload;
                        return "validated";
                    }
                    if ($is_multi == 0) {
                        $rp = $this->orderActionChiss($input_payload, 6, $ticket, $is_multi, $updateToChiss);
                        if ($rp['status'] == 0) {
                            return $rp;
                        }
                    }

                    $this->send_associate($order_id, $current_w_id, $status, $component_id, $aHelh = 1, $pHelh = 0);
                    $set['sent_associate'] = 1;

                    break;
                //------------- for status 7 : Rescheduled------------
                case 7:
                    $log_desc = $res_msg = 'Order Rescheduled';
                    if (in_array(array(4, 5), $order_pre_status_value)) {
                        $this->send_associate($order_id, $current_w_id, $status, $component_id, $aHelh = 0, $pHelh = 1);
                    }
                    $schRes = $this->reschedule_order($searchreq, $document, $order_id, $is_multi, $updateToChiss);
                    if ($schRes == 'validated') {
                        return "validated";
                    }
                    if ($schRes['status'] == 0) {
                        return $schRes;
                    }
                    $set = array_merge($set, $schRes['set']);
                    $event_flag = $schRes['event_flag'];
                    $chissInputPayload = $schRes['chissInputPayload'];
                    break;
                //------------- for status 8 : Cancellation------------
                case 8:
                    $log_desc = $res_msg = 'Order Cancelled';
                    $input_payload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "order_status" => 8];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $input_payload;
                        return "validated";
                    }
                    if ($is_multi == 0) {
                        //return $updateToChiss;
                        $rp = $this->orderActionChiss($input_payload, 8, $ticket, $is_multi, $updateToChiss);
                        if ($rp['status'] == 0) {
                            return $rp;
                        }
                    }
                    break;
                //------------- for status 9 : Rejected------------
                case 9:
                    $log_desc = $res_msg = 'Order Rejected';
                    // create new work order
                    $seqwoid = $this->utility->getNextSequence("WORKORDERID");
                    $new_workorder_id = $this->utility->getNextSequence("WOID");
                    $new_workorder_did = "WO-000-" . date('y') . "-" . $seqwoid;
                    $orderitem = $document['order']['orderitem'];
                    $provider_info = $document['order']['provider_info'];
                    $scheduled_date = $document['order']['patientinfo']['scheduled_date'];

                    $chissInputPayload = (Object) ["order_id" => $order_id, "wo_id" => $current_w_id, "new_wo_id" => $new_workorder_id, "order_status" => 9];
                    if ($is_multi == 1 && $updateToChiss == 0) {
                        $this->chissPayload[] = $chissInputPayload;
                        return "validated";
                    }
                    $this->createworkorder($order_id, $new_workorder_id, $new_workorder_did, $scheduled_date, $orderitem, $status, $reason, $provider_info, $component_id);
                    break;
                case 15:
                    $log_desc = $res_msg = 'Request for cancellation';
                    if (!isset($searchreq->reason) || empty($searchreq->reason)) {
                        return array("status" => 0, "code" => "30500", "message" => "reason is missing");
                    }
                    if (in_array(array(4, 5), $order_pre_status_value)) {
                        $this->send_associate($order_id, $current_w_id, $status, $component_id, $aHelh = 0, $pHelh = 1);
                    }
                    $searchreq->subject = $log_desc;
                    $this->generateSugarCrmTicket($searchreq);
                    break;
                case 16:
                    $log_desc = $res_msg = 'Request for reschedule';

                    if (!isset($searchreq->reason) || empty($searchreq->reason)) {
                        return array("status" => 0, "code" => "30500", "message" => "reason is missing");
                    }

                    if (intval($searchreq->date_specified) == 1) {
                        if (!isset($searchreq->scheduled_date) || empty($searchreq->scheduled_date)) {
                            return array("status" => 0, "code" => "10900", "message" => "Scheduled date is missing");
                        }
                        if (!isset($searchreq->start_time) || empty($searchreq->start_time)) {
                            return array("status" => 0, "code" => "20700", "message" => "start_time is missing");
                        }
                        if (!isset($searchreq->end_time) || empty($searchreq->end_time)) {
                            return array("status" => 0, "code" => "20800", "message" => "end_time is missing");
                        }
                    }
                    if (in_array(array(4, 5), $order_pre_status_value)) {
                        $this->send_associate($order_id, $current_w_id, $status, $component_id, $aHelh = 0, $pHelh = 1);
                    }
                    $scheduled_date = $searchreq->scheduled_date;
                    $scheduled_date = date('Y-m-d\TH:i:s', strtotime($scheduled_date)) . '.000Z';
                    $extraLogFields['requested_date'] = $scheduled_date;
                    $extraLogFields['start_time'] = $searchreq->start_time;
                    $extraLogFields['end_time'] = $searchreq->end_time;
                    $extraLogFields['chiss_transaction_id'] = $searchreq->chiss_transaction_id;
                    $searchreq->subject = $log_desc;
                    $this->generateSugarCrmTicket($searchreq);
                    break;
                default:return array("status" => 0, "code" => "10600", "message" => "Invalid Order Status.");
            }
            create_debug_log($order_id, 'COS-setBeforeOdrUpdate', $set, __FILE__);
            $filter = array('order.patientinfo.order_id' => (int) $order_id);
            $update = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multi" => true));
            //Update workorder
            $order_details[$order_id]['reason'] = $reason;
            $this->orderinfo->changeWoStatus($status, $order_id, $order_details, $current_w_id, $assignedid = $actionById, $assignedname = $actionByName);
            $extraLogFields["businessId"] = $service_type;
            $extraLogFields["MOSID"] = $mode_of_service;
            // call chiss for rescheduling //
            if ($status == 7 || $status == 9) {
                if ($is_multi == 0) {
                    $this->orderinfo->createlog($role, $status, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason, $comment, $facility_id, $popname, $extraLogFields, (isset($searchreq->scheduled_date)) ? 1 : 0, $searchreq->scheduled_date, $component_id);
                    $rp = $this->orderActionChiss($chissInputPayload, $status, $ticket, $is_multi, $updateToChiss);
                    if ($rp['status'] == 0) {
                        return $rp;
                    }
                }
            }
            // create log
            if (!($status == 7 || $status == 9)) {
                $this->orderinfo->createlog($role, $status, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason, $comment, $facility_id, $popname, $extraLogFields, (isset($searchreq->scheduled_date)) ? 1 : 0, $searchreq->scheduled_date, $component_id);
            }
            $this->trigger_email_sms_event($order_id, $status, $component_id, $mode_of_service, $service_type, $event_flag, $corporateid);
            return array("status" => 1, "code" => "10100", "message" => $res_msg);
        } else
        // Pharmacy/Supplies vendor
        if ($component_id == 9) {

            switch ($status) {
                case 0: //Order confirmed
                    $log_desc = $res_msg = 'Order confirmed: Vendor accept Order';
                    $set['active_component'] = (string) 8;
                    if (!isset($searchreq->scheduled_date) || empty($searchreq->scheduled_date)) {
                        return array("status" => 0, "code" => "10900", "message" => "Scheduled date is missing");
                    }
                    if (!isset($searchreq->chiss_transaction_id) || empty($searchreq->chiss_transaction_id)) {
                        return array("status" => 0, "code" => "20500", "message" => "chiss_transaction_id is missing");
                    }
                    if (!isset($searchreq->role_id) || empty($searchreq->role_id)) {
                        return array("status" => 0, "code" => "20600", "message" => "role_id is missing");
                    }
                    if (!isset($searchreq->start_time) || empty($searchreq->start_time)) {
                        return array("status" => 0, "code" => "20700", "message" => "start_time is missing");
                    }
                    if (!isset($searchreq->end_time) || empty($searchreq->end_time)) {
                        return array("status" => 0, "code" => "20800", "message" => "end_time is missing");
                    }
                    $scheduled_date = date('Y-m-d', strtotime($searchreq->scheduled_date)) . ' ' . $searchreq->start_time;
                    $chiss_transaction_id = $searchreq->chiss_transaction_id;
                    $scheduled_date = date('Y-m-d\TH:i:s', strtotime($scheduled_date)) . '.000Z';
                    $set['order.patientinfo.scheduled_date'] = $scheduled_date;
                    $set['order.patientinfo.servicedate'] = $this->dbo->date(strtotime($scheduled_date));
                    $set['order.patientinfo.start_time'] = $searchreq->start_time;
                    $set['order.patientinfo.end_time'] = $searchreq->end_time;
                    $set['order.patientinfo.slot_transaction_id'] = $chiss_transaction_id;
                    $set['order.patientinfo.role'] = $role_id;
                    $set['WOStatus'] = 0;

                    if ($payable_amount > 0) {
                        $event_flag = 4; // payment link
                    }

                    break;
                case 902: //Order accept
                    $log_desc = $res_msg = 'Vendor accept Order';

                    if (!empty($searchreq->scheduled_date)) {
                        $scheduled_date = date('Y-m-d', strtotime($searchreq->scheduled_date)) . ' ' . $searchreq->start_time;
                        $chiss_transaction_id = $searchreq->chiss_transaction_id;
                        $scheduled_date = date('Y-m-d\TH:i:s', strtotime($scheduled_date)) . '.000Z';
                        $set['order.patientinfo.scheduled_date'] = $scheduled_date;
                        $set['order.patientinfo.servicedate'] = $this->dbo->date(strtotime($scheduled_date));
                        $order_details[$order_id]['scheduled_date'] = $scheduled_date;
                        $set['workorderinfo.' . count($document['workorderinfo']) - 1 . '.scheduled_date'] = $this->dbo->date(strtotime($scheduled_date));
                    }
                    if (!empty($searchreq->start_time)) {
                        $set['order.patientinfo.start_time'] = $searchreq->start_time;
                    }
                    if (!empty($searchreq->end_time)) {
                        $set['order.patientinfo.end_time'] = $searchreq->end_time;
                    }
                    if (!empty($searchreq->chiss_transaction_id)) {
                        $set['order.patientinfo.slot_transaction_id'] = $chiss_transaction_id;
                    }
                    if (!empty($searchreq->role_id)) {
                        $set['order.patientinfo.role'] = $role_id;
                    }

                    $next_component = $component_order[array_search($component_id, $component_order) + 1];
                    if (isset($next_component)) {
                        $set['active_component'] = (string) $next_component;
                    }
                    $set['order.business.reschedule_block'] = 0;
                    $set['order.business.cancel_block'] = 0;
                    // call order creation api; update to chiss
                    /*  if ($service_type != 13) { // skip for equipment
                    $pLoadOCreate = (Object)["order_ids" => [$order_id]];
                    //print_r($pLoadOCreate); die;
                    $yy = $this->orderinfo->chiss_order_creation($pLoadOCreate, $ticket)[0];
                    if ($yy['status'] == 0) {
                    return array("status" => 0, "code" => "40300", "message" => "chiss order creation failed");
                    }
                    } */
                    // send order confirmation mail with payment link
                    if ($payable_amount > 0) {
                        $event_flag = 4; // payment link
                    }

                    // call acceptance api
                    $url = $this->config->getconfig('serverurl', "OMS/api/medicine_supply.php/v1/orders/accept/vendor");
                    $msPayload = array("order_id" => $order_id, "actionById" => $actionById, "actionByName" => $actionByName);
                    $startTime = microtime(true);
                    $buffer = $this->utility->my_curl($url, 'POST', json_encode($msPayload), 'json', null, 10);
                    $this->log->logThirdPartyCall("OMS", $url, $startTime, $msPayload, $buffer);
                    if ($buffer['status'] == 0) {
                        return $buffer;
                    }

                    break;
                case 24:
                    $log_desc = $res_msg = 'Vendor Reject Order';
                    $set['order.business.reschedule_block'] = 1;
                    $set['order.business.cancel_block'] = 1;
                    break;
                // copied from component 10
                case 1000:
                    $log_desc = $res_msg = 'To be assign'; // not assign to vendor

                    break;
                case 1001:
                    $log_desc = $res_msg = 'Pending Prescription';
                    break;
                case 1002:
                    $log_desc = $res_msg = 'Prescription Uploaded';
                    break;
                case 21:
                    $log_desc = $res_msg = 'L2 assign to Vendor';
                    /*$next_component = $component_order[array_search($component_id, $component_order) + 1];
                    if (isset($next_component)) {
                    $set['active_component'] = $next_component;
                    }*/

                    // check wheather  associate_id is exist or not
                    if (empty($searchreq->associate_id)) {
                        $is_associate_avail = 0;
                        foreach ($document['order']['provider_info'] as $key => $item3) {
                            if ($item3['component_no'] == $component_id) {
                                if (!empty($item3['associate_id'])) {
                                    $is_associate_avail = 1;
                                }
                            }
                        }
                        if ($is_associate_avail == 0) {
                            return array("status" => 0, "code" => "30900", "message" => "Please provide associate_id");
                        }
                    }

                    // associate_id
                    if (!empty($searchreq->associate_id)) {
                        // fetch associate id data
                        $filter1 = ["_id" => (String) $searchreq->associate_id];
                        $assoDetails = $this->dbo->findOne("masters", "medicine_vendors", $filter1, []);
                        if (empty($assoDetails)) {
                            return array("status" => 0, "code" => "40100", "message" => "No data found for provided associate_id");
                        }
                        $assData = [
                            "component_no" => (String) $component_id,
                            "role" => "",
                            "skill" => "",
                            "associate_id" => $assoDetails['userinfo']['USER_ID'],
                            "associate_name" => $assoDetails['userinfo']['USER_NAME'],
                            "associate_address" => $assoDetails['userinfo']['ADDRESS'],
                            "associate_email" => $assoDetails['userinfo']['EMAIL'],
                            "associate_contact_number" => $assoDetails['userinfo']['MOBILE'],
                            "vendor_assigned_date" => date('Y-m-d H:i:s'),
                        ];

                        $set['order.provider_info'][0] = $assData;
                        if (!empty($document['order']['provider_info'])) {
                            $alreadyExist = 0;
                            foreach ($document['order']['provider_info'] as $key => $item3) {
                                if ($item3['component_no'] == $component_id) {
                                    $item3 = $assData;
                                    $alreadyExist = 1;
                                }
                                $set['order.provider_info'][$key] = $item3;
                            }
                            if ($alreadyExist = 0) {
                                array_push($set['order.provider_info'], $assData);
                            }
                        }
                    }

                    break;
                // copied from component 10 End
                default:
                    $response = array("status" => 0, "code" => "10600", "message" => "Invalid Order Status.");
                    $this->log->create_log("", "", "statusUpdate", "Execution", 200, "change_order_status_end", json_encode($response), (string) $ticket);
                    return $response;
                    //return array("status" => 0, "code" => "10600", "message" => "Invalid Order Status.");
            }
            create_debug_log($order_id, 'COS-setBeforeOdrUpdate', $set, __FILE__);
            $filter = array('order.patientinfo.order_id' => (int) $order_id);
            $update = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multi" => true));
            //Update workorder
            $order_details[$order_id]['reason'] = $reason;
            $this->orderinfo->changeWoStatus($status, $order_id, $order_details, $current_w_id, $assignedid = $actionById, $assignedname = $actionByName);
            // create log
            $extraLogFields["businessId"] = $service_type;
            $extraLogFields["MOSID"] = $mode_of_service;
            $this->orderinfo->createlog($role, $status, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason, $comment, $facility_id, $popname, $extraLogFields, (isset($searchreq->scheduled_date)) ? 1 : 0, $searchreq->scheduled_date, $component_id);

            $this->trigger_email_sms_event($order_id, $status, $component_id, $mode_of_service, $service_type, $event_flag, $corporateid);
            $response = array("status" => 1, "code" => "10100", "message" => $res_msg);
            $this->log->create_log("", "", "statusUpdate", "Execution", 200, "change_order_status_end", json_encode($response), (string) $ticket);
            return $response;
            //return array("status" => 1, "code" => "10100", "message" => $res_msg);

        }

        // L2 Pharma - Equipement user
        if ($component_id == 10) {
            switch ($status) {
                case 1000:
                    $log_desc = $res_msg = 'To be assign';
                    break;
                case 1001:
                    $log_desc = $res_msg = 'Pending Prescription';
                    break;
                case 1002:
                    $log_desc = $res_msg = 'Prescription Uploaded';
                    break;
                case 21:
                    $log_desc = $res_msg = 'L2 assign to Vendor';
                    $next_component = $component_order[array_search($component_id, $component_order) + 1];
                    if (isset($next_component)) {
                        $set['active_component'] = (string) $next_component;
                    }
                    break;

                default:
                    //return array("status" => 0, "code" => "10600", "message" => "Invalid Order Status.");
                    $response = array("status" => 0, "code" => "10600", "message" => "Invalid Order Status.");
                    $this->log->create_log("", "", "statusUpdate", "Execution", 200, "change_order_status_end", json_encode($response), (string) $ticket);
                    return $response;
            }
            create_debug_log($order_id, 'COS-setBeforeOdrUpdate', $set, __FILE__);
            $filter = array('order.patientinfo.order_id' => (int) $order_id);
            $update = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multi" => true));
            //Update workorder
            $order_details[$order_id]['reason'] = $reason;
            $this->orderinfo->changeWoStatus($status, $order_id, $order_details, $current_w_id, $assignedid = $actionById, $assignedname = $actionByName);
            // create log
            $extraLogFields["businessId"] = $service_type;
            $extraLogFields["MOSID"] = $mode_of_service;
            $this->orderinfo->createlog($role, $status, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason, $comment, $facility_id, $popname, $extraLogFields, (isset($searchreq->scheduled_date)) ? 1 : 0, $searchreq->scheduled_date, $component_id);

            $this->trigger_email_sms_event($order_id, $status, $component_id, $mode_of_service, $service_type, $event_flag, $corporateid);
            $response = array("status" => 1, "code" => "10100", "message" => $res_msg);
            $this->log->create_log("", "", "statusUpdate", "Execution", 200, "change_order_status_end", json_encode($response), (string) $ticket);
            return $response;
        }

        // Delivery
        if ($component_id == 13) {
            switch ($status) {
                case 2:
                    $log_desc = $res_msg = 'Order has been Shipped';
                    break;
                case 6:
                    $log_desc = $res_msg = 'Order Completed';
                    break;
                case 8:
                    $log_desc = $res_msg = 'Cancel Order';
                    break;

                default:
                    //return array("status" => 0, "code" => "10600", "message" => "Invalid Order Status.");
                    $response = array("status" => 0, "code" => "10600", "message" => "Invalid Order Status.");
                    return $response;
            }
            create_debug_log($order_id, 'COS-setBeforeOdrUpdate', $set, __FILE__);
            $filter = array('order.patientinfo.order_id' => (int) $order_id);
            $update = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multi" => true));
            //Update workorder
            $order_details[$order_id]['reason'] = $reason;
            $this->orderinfo->changeWoStatus($status, $order_id, $order_details, $current_w_id, $assignedid = $actionById, $assignedname = $actionByName);
            // create log
            $extraLogFields["businessId"] = $service_type;
            $extraLogFields["MOSID"] = $mode_of_service;
            $this->orderinfo->createlog($role, $status, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason, $comment, $facility_id, $popname, $extraLogFields, (isset($searchreq->scheduled_date)) ? 1 : 0, $searchreq->scheduled_date, $component_id);

            $this->trigger_email_sms_event($order_id, $status, $component_id, $mode_of_service, $service_type, $event_flag, $corporateid);
            $response = array("status" => 1, "code" => "10100", "message" => $res_msg);
            $this->log->create_log("", "", "statusUpdate", "Execution", 200, "change_order_status_end", json_encode($response), (string) $ticket);
            return $response;
        }

    }

    /**
     * -------Error Codes------------
     * 10100: Order {rescheduled}. // changes based on status
     * 10200: Invalid Input, Required fields are missing
     * 10300: Invalid Order Id
     * 10400: Order already in the same status.
     * 10500: Precondition validation failed // dynamic message
     * 10600: Invalid Order Status.
     * 10700: Unable to accept order, request failed from Chiss
     * 10800: Unable to reject order, request failed from Chiss
     * 10900: Scheduled date is missing
     * 20100: Unable to Assign order, request failed from Chiss
     * 20200: Order source is missing
     * 20300: Reschedule count limit is Exceed
     * 20400: Retained flag is missing
     * 20500: chiss_transaction_id is missing
     * 20600: role_id is missing
     * 20700: start_time is missing
     * 20800: end_time is missing
     * 20900: active component is missing, order not created properly
     * 30100: Unable to Complete the order, request failed from Chiss
     * 30200: Unable to Start Order the order, request failed from Chiss
     * 30300: Bulk order processed successfully
     * 30400: Unable to process bulk order.
     * 30500: reason is missing
     * 30600: Unable to Reschedule Order, request failed from Chiss
     * 30700: Unable to process Order, request failed from Chiss
     * 30800: Unable to cancel Order, request failed from Chiss
     * 30900: Please provide associate_id
     * 40100: No data found for provided associate_id
     * 40200: rescheduled is applicable for roleBasedService only
     * 40300: chiss order creation failed
     * 40400: Order is already cancelled
     * 40500: category_id is missing
     * 40600: sub_category_id is missing
     * 40700: You have pending penalty, Please pay before reschedule
     * 40800: state mismatch of order
     * 40900: Error response
     *
     * Pathology : 1,7,8
     * Imaging : 3,7,8
     * Care@home {trxn, assess, continuous} : 2
     * Wellness : 2
     * Drug : 2
     * Consultation :
     */

    public function send_associate($order_id, $workorder_id, $status, $component_id, $aHelh, $pHelh)
    {
        // update to aHelp
        if ($aHelh) {

            $url = $this->config->getconfig('serverurl', "OMS/api/operation.php/v1/updateAhelpIntdbFromOms");
            //$url = $server_url . "cron_files/completed_orders_inti.php";
            $param = array("orderId" => $order_id, "status" => $status, "component_id" => $component_id);
            $startTime = microtime(true);
            $resultcurl = $this->utility->async_get_curl($url, json_encode($param));
            $this->log->logThirdPartyCall("OMS", $url, $startTime, $param, json_decode($resultcurl), $requestType = 'ASYNC', $method = "GET");
        }
        // update to pHelp
        if ($pHelh) {
            //echo "1";exit;
            $url = $this->config->getconfig('serverurl', "OMS/api/operation.php/v1/updatePhelpIntdbFromOms");
            //$url = $server_url . "cron_files/completed_orders_inti.php";
            $param = array("workOrderId" => $workorder_id, "status" => $status, "component_id" => $component_id);
            $startTime = microtime(true);
            //echo json_encode( $param);

            $resultcurl = $this->utility->async_get_curl($url, json_encode($param));

            $this->log->logThirdPartyCall("OMS", $url, $startTime, $param, json_decode($resultcurl), $requestType = 'ASYNC', $method = "GET");
        }
    }

    public function validate_status_precondition($order_status_old, $status, $component_id)
    {
        return ["status" => 1, "msg" => "ok"];
        if ($component_id == 1) {
            switch ($status) {
                case 2: //Accepted
                    return (in_array($order_status_old, [0, 1])) ? ["status" => 1] : ["status" => 0, "msg" => "Status precondition is not satisfied for status Accepted"];
                    break;
                case 3: //Started
                    return (in_array($order_status_old, [0, 1, 2])) ? ["status" => 1] : ["status" => 0, "msg" => "Status precondition is not satisfied for status Started"];
                    break;
            }
        }
    }

    public function get_reschedule_limit($creation_type, $service_type)
    {
        //$creation_type = 0: Normal | 1: corporate | 2: HDFC | 3: UHC
        //$service_type 1,2,3,4,5,6,30
        //0 means No limit
        $defaultLimit = 3;
        $setting = [
            '0_1' => 3, '0_2' => 3, '0_3' => 3, '0_4' => 3, '0_5' => 3, '0_6' => 3, '0_30' => 3, //Normal
            '1_1' => 3, '1_2' => 3, '1_3' => 3, '1_4' => 3, '1_5' => 3, '1_6' => 3, '1_30' => 3, //corporate
            '2_1' => 0, '2_2' => 0, '2_3' => 0, '2_4' => 0, '2_5' => 0, '2_6' => 0, '2_30' => 0, //HDFC
            '3_1' => 3, '3_2' => 3, '3_3' => 3, '3_4' => 3, '3_5' => 3, '3_6' => 3, '3_30' => 3, //UHC
        ];
        return isset($setting[$creation_type . '_' . $service_type]) ? $setting[$creation_type . '_' . $service_type] : $defaultLimit;
    }

    public function workorderpush($order_id, $workorder_id, $workorder_did, $status, $scheduled_date)
    {
        $wo = array(
            'wid' => $workorder_id,
            'wodid' => $workorder_did,
            'wostatus' => $status,
            "scheduled_date" => $this->dbo->date(strtotime($scheduled_date)),
            "created_date" => $this->utility->getCurrenttime(),
        );
        $filter = array('_id' => (int) $order_id);
        $push = array('workorderinfo' => $wo);
        $log = $this->dbo->update("masters", "orders", $filter, array(), $push, array("multi" => true));
    }

    public function addworkorder($orderid, $current_w_id, $workorder_id, $workorder_did, $scheduled_date, $orderitem, $reason, $component, $status, $MOS, $bid)
    {
        $current_time = substr(date("c", strtotime(date('Y-m-d H:i:s'))), 0, 19) . ".000Z";

        //push new workorders

        //update current workorders
        $set = array(
            'orderinfo.order_status' => $status,
            'orderinfo.final_status' => $status,
            'orderinfo.reason' => $reason,
            'orderinfo.reschedule_time' => $current_time,
            'orderinfo.modified_time' => $current_time,
        );
        $filter = array('_id' => (int) $current_w_id);
        $this->dbo->update("masters", "workorders", $filter, $set, array(), array("multi" => true));

        // update order for old workorder
        $set = array("workorderinfo.$.wostatus" => $status, 'wid' => $workorder_id,
            'wodid' => $workorder_did);
        $this->dbo->update("masters", "orders", ['workorderinfo.wid' => $current_w_id], $set, array(), array("multi" => true));
        // echo $set;exit;
        // insert new workorder
        $version = $this->config->getconfig("version", "");
        $workdocument = array(
            "_id" => $workorder_id,
            "version" => $version,
            "wodid" => $workorder_did,
            "orderinfo" => array(
                "component_no" => $component,
                "order_id" => (int) $orderid,
                "created_time" => $current_time,
                "modified_time" => $current_time,
                "order_status" => 0,
                "assignedto" => "0",
                "start_time" => "",
                "reached_time" => "",
                "delivery_time" => "",
                "completed_time" => "",
                "final_status" => 0,
                "cancel_time" => "",
                "reschedule_time" => "",
                "reason" => "",
                "orderitem" => $orderitem,
                "scheduled_date" => $scheduled_date,
            ),
        );
        //echo "1";exit;
        $this->workorderpush($orderid, $workorder_id, $workorder_did, "0", $scheduled_date);

        $this->dbo->insert("masters", "workorders", $workdocument);
    }

    public function createworkorder($orderid, $workorder_id, $workorder_did, $scheduled_date, $orderitem, $status, $reason, $provider_info, $component_id)
    {
        $current_time = substr(date("c", strtotime(date('Y-m-d H:i:s'))), 0, 19) . ".000Z";
        $version = $this->config->getconfig("version", "");
        //$this->workorderpush($orderid,$workorder_id,$workorder_did,"0",$scheduled_date);
        $workdocument = array(
            "_id" => $workorder_id,
            "version" => $version,
            "wodid" => $workorder_did,
            "orderinfo" => array(
                "component_no" => (string) $component_id,
                "order_id" => (int) $orderid,
                "created_time" => $current_time,
                "modified_time" => $current_time,
                "order_status" => 0,
                "assignedto" => "0",
                "start_time" => "",
                "reached_time" => "",
                "delivery_time" => "",
                "completed_time" => "",
                "final_status" => 0,
                "cancel_time" => "",
                "reschedule_time" => "",
                "reason" => "",
                "orderitem" => $orderitem,
                "scheduled_date" => $scheduled_date,
            ),
            "provider_info" => $provider_info,
        );
        $insert_response = $this->dbo->insert('masters', 'workorders', $workdocument);
    }

    public function reschedule_order($searchreq, $document, $order_id, $is_multi, $updateToChiss)
    {
        if (!isset($searchreq->reason) || empty($searchreq->reason)) {
            return array("status" => 0, "code" => "30500", "message" => "reason is missing");
        }
        if (!isset($searchreq->scheduled_date) || empty($searchreq->scheduled_date)) {
            return array("status" => 0, "code" => "10900", "message" => "Scheduled date is missing");
        }
        if (empty(intval($searchreq->source))) {
            return array("status" => 0, "code" => "20200", "message" => "Invalid source value; The value would be 1:CP,2:CCO,3:Android App,4:Corporate Portal,5:IOS App,6:L2 Pharma,7:Officer App");
        }
        if (!isset($searchreq->retained)) {
            return array("status" => 0, "code" => "20400", "message" => "Retained flag is missing");
        }

        if (!isset($searchreq->chiss_transaction_id) || empty($searchreq->chiss_transaction_id)) {
            return array("status" => 0, "code" => "20500", "message" => "chiss_transaction_id is missing");
        }
        if (!isset($searchreq->role_id) || empty($searchreq->role_id)) {
            return array("status" => 0, "code" => "20600", "message" => "role_id is missing");
        }
        if (!isset($searchreq->start_time) || empty($searchreq->start_time)) {
            return array("status" => 0, "code" => "20700", "message" => "start_time is missing");
        }
        if (!isset($searchreq->end_time) || empty($searchreq->end_time)) {
            return array("status" => 0, "code" => "20800", "message" => "end_time is missing");
        }
        if (!isset($searchreq->category_id) || empty($searchreq->category_id)) {
            //return array("status" => 0, "code" => "40500", "message" => "category_id is missing");
        }
        if (!isset($searchreq->sub_category_id) || empty($searchreq->sub_category_id)) {
            //return array("status" => 0, "code" => "40600", "message" => "sub_category_id is missing");
        }

        $scheduled_date = date('Y-m-d', strtotime($searchreq->scheduled_date)) . ' ' . $searchreq->start_time;
        $chiss_scheduled_date_format = date('Y-m-d H:i:s', strtotime($scheduled_date));
        $scheduled_date = date('Y-m-d\TH:i:s', strtotime($scheduled_date)) . '.000Z';
        $retained = $searchreq->retained;
        $chiss_transaction_id = $searchreq->chiss_transaction_id;
        $role_id = $searchreq->role_id;
        $reason = $searchreq->reason;
        $pincode = (string) $document['order']['patientinfo']['pincode'];
        $reschedule_count = intval($document['order']['patientinfo']['reschedule_count']) + 1;
        $creation_type = $document['creation_type'];
        $orderitem = $document['orderinfo']['orderitem'];

        $reschedule_limit = $this->get_reschedule_limit($creation_type, $document['order']['patientinfo']['service_type']);
        if ($reschedule_limit != 0 && $reschedule_count >= $reschedule_limit) {
            $filter = array('order.patientinfo.order_id' => (int) $order_id);
            $setT['order.business.reschedule_block'] = 1;
            $update = $this->dbo->update("masters", "orders", $filter, $setT, array(), array("multi" => true));
            //return array("status" => 0, "code" => "20300", "message" => "Reschedule count limit is Exceed");
        }

        $seqwoid = $this->utility->getNextSequence("WORKORDERID");
        $new_workorder_id = $this->utility->getNextSequence("WOID");
        $new_workorder_did = "WO-" . date('dmy') . "-" . $seqwoid;
        if ($is_multi == 1 && $updateToChiss == 1) {
            $tempArr = json_decode(json_encode($this->chissPayload), true);
            $key = array_search($order_id, array_column($tempArr["orders_info"], 'order_id'));
            $new_workorder_id = $tempArr["orders_info"][$key]['new_wo_id'];
        }

        if (isset($retained) && $retained == 1) {
            $set['order.patientinfo.retained'] = $retained;
            $set['order.patientinfo.retainedbyname'] = $searchreq->actionByName;
            $set['order.patientinfo.retainedbyid'] = $searchreq->actionById;
        }
        if (empty($all_items)) {
            $all_items = $document['order']['orderitem'];
        }

        $set['order.patientinfo.scheduled_date'] = $scheduled_date;
        $set['order.patientinfo.servicedate'] = $this->dbo->date(strtotime($scheduled_date));
        $set['order.patientinfo.start_time'] = $searchreq->start_time;
        $set['order.patientinfo.end_time'] = $searchreq->end_time;
        $set['order.patientinfo.slot_transaction_id'] = $chiss_transaction_id;

        $set['order.patientinfo.role'] = $role_id;
        $set['WOStatus'] = 0;
        $set['wodid'] = $new_workorder_did;
        $set['wid'] = $new_workorder_id;
        $set['order.order_status.workorder_id'] = $new_workorder_id;
        $set['order.order_status.workorder_did'] = $new_workorder_did;

        $set['assigned_to'] = "";
        $set['order.order_status.assignedto'] = "";
        $set['order.order_status.mhoname'] = "";
        $set['order.patientinfo.reschedule_count'] = $reschedule_count;
        $set['order.patientinfo.inprogress'] = 0;

        //order_reschedule_chiss
        $current_w_id = $document['wid']; //using
        $input_payload["orders_info"][0] = (Object) ["tr_id" => $searchreq->chiss_transaction_id, "order_id" => $order_id, "wo_id" => $current_w_id, "new_wo_id" => $new_workorder_id, "order_status" => 7, "schedule_date" => $chiss_scheduled_date_format];
        $chissInputPayload = $input_payload;
        // update price using MAD Rules First check for Validation
        $itemForPrice = array();
        foreach ($document['order']['orderitem'] as $item) {
            if ($item['item_status'] == 8) {continue;}
            $itemForPrice[] = $item['item_code'];
        }

        $priceChangePayload = (Object) array(
            "transaction_code" => $document['transaction_code'],
            "order_id" => $order_id,
            "action" => 3, //1: Cancellation, 2:Modification, 3:Reschedule
            "line_item" => $itemForPrice,
            "validation" => 1,
            "schedule_date" => $chiss_scheduled_date_format,
        );

        // check wheather MAD Rule appicable or not
        $mdmChkpload = json_encode([
            "entity" => "reschedule",
            "categoryId" => intval($searchreq->category_id),
            "subCategoryId" => (String) intval($searchreq->sub_category_id),
            "source" => (String) intval($searchreq->source),
            "order_id" => $order_id,
        ]);

        if ($is_multi == 0 || ($is_multi == 1 && $updateToChiss == 0)) {
            $startTime = microtime(true);
            $url = $this->config->getconfig('mdmpath', "domain/isMadRulesApplied");
            $mdmChkRes = $this->utility->my_curl($url, 'POST', $mdmChkpload, 'json', null, 10);
            $this->log->logThirdPartyCall("MDM", $url, $startTime, json_decode($mdmChkpload), $mdmChkRes);
            $this->mdmChkResArr[$order_id] = $mdmChkRes;
        }
        if ($is_multi == 1 && $updateToChiss == 1) {
            $mdmChkRes = $this->mdmChkResArr[$order_id];
        }

        //if ($searchreq->reasonType != 1) { // other than callHealth
        $corporateid = $document['order']['patientinfo']['corporateid']; //
        if (($mdmChkRes['isMadRuleApplied'] && empty($corporateid)) || in_array($document['order']['patientinfo']['service_type'], [6, 7, 8])) {
            $hwt = $this->change_order_status_forlineitem($priceChangePayload, $ticket);
            if ($hwt['status'] == 0) {
                $hwt['message'] = 'Price calculation failed: ' . $hwt['message'];
                return $hwt;
            }
        }

        $all_items = [];

        // check weather it has dependent or not for rescheduling only
        if ($document['order']['business']['is_assessment'] == 1 and isset($document['order']['business']['encid'])) {
            // fetch dependant orders for reschedulement asyn
            $encid = $document['order']['business']['encid'];
            $filter = array('_id' => array('$ne' => (int) $order_id), 'order.business.encid' => $encid, 'OStatus' => ['$nin' => [17, 8]]);
            $project = array("_id" => 1);
            $dependnt_odrs = $this->dbo->find("masters", "orders", $filter, $project);
            $dependnt_odrs_oids = [];
            foreach ($dependnt_odrs as $xx) {
                $dependnt_odrs_oids[] = $xx['_id'];
            }
            if (!empty($dependnt_odrs_oids)) {
                $newPayload = (array) $searchreq;
                $newPayload['order_id'] = $dependnt_odrs_oids;
                $newPayload = json_encode($newPayload);
                $url = $this->config->getconfig('serverurl', 'OMS/api/operation.php/v1/order/change/status');
                async_curl_post_json($url, $newPayload);
            }
        }

        if ($is_multi == 1 && $updateToChiss == 0) {
            $this->chissPayload["orders_info"][] = $input_payload["orders_info"][0];
            return 'validated';
        }
        //modeOfService
        $MOS = $document['mode_of_service'];
        //component
        $component = $document['active_component'];
        //Bid
        $bid = $document['order']['patientinfo']['service_type'];

        if ($is_multi == 0 || ($is_multi == 1 && $updateToChiss == 1)) {
            $this->addworkorder($order_id, $current_w_id, $new_workorder_id, $new_workorder_did, $scheduled_date, $all_items, $reason, $component, "7", $MOS, $bid);
        }

        // create new workorder in chiss
        if ($mdmChkRes['isMadRuleApplied'] && empty($corporateid)) { // other than callHealth
            $priceChangePayload->validation = 0;
            $tt = $this->change_order_status_forlineitem($priceChangePayload, $ticket);
            create_debug_log($order_id, 'MADRules_response', $tt, __FILE__);
            if ($tt['status'] == 0) {
                return $tt;
            }
        }
        if ($mdmChkRes['isTicketRequired'] && empty($corporateid)) { // other than callHealth
            $url = $this->config->getconfig('serverurl', 'OMS/api/operation.php/v1/generateTicket');
            $this->utility->async_curl($url, json_encode(["order_id" => $order_id, "reason" => $reason]));
        }

        if ($document['order']['patientinfo']['service_type'] == "3") {
            $final_delivery_date = $scheduled_date;
            $filter1 = ['_id' => intval($order_id)]; //255293
            $document1 = $this->dbo->findOne("masters", "orders", $filter1, array("order.orderitem" => 1));
            $url = $this->config->getconfig('mdmpath', "fetchservice/getTATHours");
            $li = 0;
            foreach ($document1['order']['orderitem'] as $item) {
                if ($item[component_no] == "7") {
                    $reportdeliverydatefrom = $scheduled_date;
                    $item['report_delivery_date'] = $scheduled_date; // default
                    $lineItmsarr = array($item['item_code']);
                    $order_item_payload = json_encode(['pincode' => $pincode, 'serviceCode' => [$item['item_code']]]);
                    $startTime = microtime(true);
                    $buffer = $this->utility->my_curl($url, 'POST', $order_item_payload, 'json', null, 10);
                    $this->log->logThirdPartyCall("MDM", $url, $startTime, json_decode($order_item_payload), $buffer);
                    $tatHours = intval($buffer[data][0]['hours']) + intval($buffer[data][0]['toHours']);
                    $tatHoursFrom = intval($buffer[data][0]['hours']);
                    if ($tatHours <= 0) {
                        $tatHours = 24;
                        $tatHoursFrom = 0;
                    }
                    if ($tatHours > 0) {
                        $reportdeliverydatefrom = date('Y-m-d\TH:i:s', strtotime($scheduled_date) + (3600 * $tatHoursFrom) - 19800) . '.000Z';
                        $item['report_delivery_date'] = date('Y-m-d\TH:i:s', strtotime($scheduled_date) + (3600 * $tatHours) - 19800) . '.000Z';
                    }
                    if (strtotime($item['report_delivery_date']) > strtotime($final_delivery_date)) {
                        $final_delivery_date = $item['report_delivery_date'];
                    }
                    $set['order.orderitem.' . $li . '.reportdeliverydatefrom'] = $reportdeliverydatefrom;
                    $set['order.orderitem.' . $li . '.reportdeliverydateto'] = $item['report_delivery_date'];
                    $set['order.orderitem.' . $li . '.report_delivery_date'] = $item[report_delivery_date];
                }
                $li++;
            }
            // check once...
            $set['order.patientinfo.final_delivery_date'] = $final_delivery_date;
        }

        $event_flag = 1;
        if ($mdmChkRes['requestBy'] == 'By Customer') {
            $event_flag = 2;
        }

        return ['status' => 1, 'set' => $set, 'chissInputPayload' => $chissInputPayload, 'event_flag' => $event_flag];
    }

    public function processing_at_delivery_officer($payload, $ticket) // sample submission

    {
        $order_idArr = $payload->order_ids;
        $totalSamplesSubmitted = $payload->totalSamplesSubmitted;
        //-------------Validate required fields ------------
        if (empty($order_idArr)) {
            return array("status" => 0, "code" => "10200", "message" => "Invalid Input, Required fields are missing");
        }
        if (!is_array($order_idArr)) {
            return array("status" => 0, "code" => "10500", "message" => "order_ids should be an array");
        }
        foreach ($order_idArr as $key => $order_id) {
            //-------------get order collection based on order_id ------------
            $filter = ['_id' => intval($order_id)]; //255293
            $document = $order = $this->dbo->findOne("masters", "orders", $filter, array("order.orderitem.activity" => 0));
            if (empty($order)) {
                return array("status" => 0, "code" => "10300", "message" => "Invalid Order Id");
            }

            $service_type = $document['order']['patientinfo']['service_type'];
            $report_required = $document['order']['patientinfo']['report_required']; //
            $corporateid = $document['order']['patientinfo']['corporateid']; //
            $mode_of_service = $document['mode_of_service'];
            $component_id = $document['active_component'];
            $component_order = $document['component_order'];
            $log_desc = $res_msg = 'Sample submitted successfully';
            $next_component = 7;

            /*  $component_order[array_search($component_id, $component_order) + 1];
            if (isset($next_component)) {
            $set['active_component'] = $next_component;
            } else {
            return array("status" => 0, "code" => "10400", "message" => "Next component is missing");
            } */
            $set['active_component'] = (string) $next_component;
            if ($payload->submissionType == "2") {
                $status = 103;
            } else {
                $status = 101;
            }
            $set['OStatus'] = $status;
            $set['WOStatus'] = $status;
            $set['order.patientinfo.order_status'] = (string) $status;
            $set['order.order_status.order_status'] = (string) $status;
            $set['order.patientinfo.totalSamplesSubmitted'] = intval($totalSamplesSubmitted[$key]);
            $set['order.patientinfo.diag_sample_status'] = 2;
            $set['sent_associate'] = 1;
            $filter = array('order.patientinfo.order_id' => (int) $order_id);
            $update = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multi" => true));

            //create new workorder
            $seqwoid = $this->utility->getNextSequence("WORKORDERID");
            $new_workorder_id = $this->utility->getNextSequence("WOID");
            $new_workorder_did = "WO-000-" . date('y') . "-" . $seqwoid;
            $scheduled_date = $document['order']['patientinfo']['scheduled_date'];
            $orderitem = $document['order']['orderitem'];
            $provider_info = $document['order']['provider_info'];
            if (!empty($provider_info)) {
                $provider_info = array_reverse($provider_info);
            }

            // get $provider_info only for current component
            foreach ($provider_info as $item) {
                if ($item['component_no'] == $next_component) {
                    $provider_info = $item;
                    break;
                }
            }

            $this->createworkorder($order_id, $new_workorder_id, $new_workorder_did, $scheduled_date, $orderitem, $status, $reason, $provider_info, (string) $next_component);

            // send to associate
            $this->send_associate($order_id, $new_workorder_id, $status, $component_id, $aHelh = 1, $pHelh = 0);

            // send notification EMAIL/SMS
            $event_flag = isset($report_required) ? 1 : 0;
            //$this->trigger_email_sms_event($order_id, $sts= 6, $cmpnt = 7, $mode_of_service, $service_type, $event_flag, $corporateid);

            // send to chiss
            /*$input_payload["order_ids"] = [$order_id];
        $url = $this->config->getconfig('serverurl', "OMS/api/operation.php/v1/ordercreation_chiss");
        $param = json_encode($input_payload);
        $this->async_curl($url, $param);*/

        }

        return array("status" => 1, "code" => "10100", "message" => $res_msg);
    }

    /**
     * 10100 : Order processing is started with delivery officer
     * 10200 : Invalid Input, Required fields are missing
     * 10300 : Invalid Order Id
     * 10400 : Next component is missing
     * 10500 : order_ids should be an array
     *
     */

    public function addNewLineItem($payload, $ticket)
    {
        // validate required fields
        $validation_fields = array("itemid", "itemname", "line_item", "service_type", "gross_amount", "discount_amount", "net_amount");
        if ($payload->service_type == 2) { // drug
            $validation_fields = array_merge($validation_fields, array("quantity", "sampletype", "reportdeliverydateto", "reportdeliverydatefrom"));
        }
        if ($payload->service_type == 3) { // pathology
            $validation_fields = array_merge($validation_fields, array("department", "sampletype", "reportdeliverydateto", "reportdeliverydatefrom", "vacutainer"));
        }
        foreach ($validation_fields as $fields) {
            if (!isset($payload->{$fields})) {
                return array("status" => 0, "code" => "10200", "message" => "required field is missing : new_item.$fields");
            }
        }
        $order_id = $payload->order_id;
        $payment = $payload->payment;
        $final_delivery_date = $payload->final_delivery_date;
        $discount_amount += floatval($payment['discount_amount']) + floatval($payload->discount_amount);
        $net_amount += floatval($payment['net_amount']) + floatval($payload->net_amount);
        $gross_amount += floatval($payment['gross_amount']) + floatval($payload->gross_amount);
        if (strtotime($final_delivery_date) < strtotime($payload->reportdeliverydateto)) {
            $payload->final_delivery_date = $payload->reportdeliverydateto;
        }

        $orderitem = array(
            "item_id" => $payload->itemid,
            "item_code" => $payload->line_item,
            "itemname" => $payload->itemname,
            "doctor" => (String) $payload->doctor,
            "coupon" => (String) $payload->coupon,
            "quantity" => (int) $payload->quantity,
            "type" => (String) $payload->type,
            "gross_amount" => (float) $payload->gross_amount,
            "discount_amount" => (float) $payload->discount_amount,
            "net_amount" => (float) $payload->net_amount,
            "item_status" => "0",
            "service_type" => (String) $payload->service_type,
            "invoiceto" => isset($payload->invoiceto) ? $payload->invoiceto : "0",
            "reportto" => isset($payload->reportto) ? $payload->reportto : "",
            "corporateinvoiceemail" => (String) $payload->corporateinvoiceemail,
            "corporatereportemail" => (String) $payload->corporatereportemail,
            "vacutainer" => (String) $payload->vacutainer,
            "reportdeliverydatefrom" => isset($payload->reportdeliverydatefrom) ? date("Y-m-d\TH:i:s", strtotime($payload->reportdeliverydatefrom)) . '.000Z' : '',
            "reportdeliverydateto" => isset($payload->reportdeliverydateto) ? date("Y-m-d\TH:i:s", strtotime($payload->reportdeliverydateto)) . '.000Z' : '',
            "sampletype" => $payload->sampletype,
            "department" => $payload->department,
            "unique_id" => (String) $this->dbo->id(),
        );

        $set = array();
        $push['order.orderitem'] = $orderitem;
        $set['order.patientinfo.discount_amount'] = $discount_amount;
        $set['order.patientinfo.net_amount'] = $net_amount;
        $set['order.patientinfo.gross_amount'] = $gross_amount;
        $set['order.patientinfo.final_delivery_date'] = date("Y-m-d\TH:i:s", strtotime($final_delivery_date)) . '.000Z';
        $filter = array('_id' => (int) $order_id);
        $update = $this->dbo->update("masters", "orders", $filter, $set, $push, array("multi" => true));
        if ($update['ok'] == 1) {
            return array("success" => 1);
        }
        return array("success" => 0, "code" => "20100", "message" => "Unable to add lineitem, please try later");
    }

    public function change_order_status_forlineitem($payload, $ticket)
    {

        //return   [new MongoDate(strtotime(date("Y-m-d\TH:i:s") . ".000Z")),$this->utility->getCurrenttime() ];

        //temp disable MDM Price Manipulation Call
        //return array("status" => 1, "code" => "10100", "message" => "Operation done successfully");
        $order_id = $payload->order_id;
        $action = $payload->action; //1: Cancellation, 3:Reschedule
        $reason = $payload->reason; // optional
        $comment = $payload->comment; // optional
        $schedule_date = $payload->schedule_date; //New schedule date
        $financeObj = new Finance;

        //echo "1";exit;
        // for validation purpose only  //internal use only
        $validation = $payload->validation;
        create_debug_log($order_id, 'MadRuleCalulation', $payload, __FILE__);
        //-------------Validate required fields ------------
        if (empty($action) || empty($order_id)) {
            return array("status" => 0, "code" => "10200", "message" => "Invalid Input, Required fields are missing");
        }

        $filter = ['_id' => (int) $order_id];
        $mainOrder = $this->dbo->findOne("masters", "orders", $filter, []);
        if (empty($mainOrder)) {
            return array("status" => 0, "code" => "10800", "message" => "Invalid order_id");
        }
        //create_debug_log($order_id, 'MadRuleOrder', $mainOrder, __FILE__);
        $source = $mainOrder['channel'];
        $source = CHANNEL[$source]; // CHANNEL is constant variable avail in constant.php
        if (empty($source)) {
            $source = 'CP';
        }

        if ($mainOrder['OStatus'] == 8) {
            return array("status" => 0, "code" => "40400", "message" => "Order is already cancelled");
        }

        $orderTransactionCode = $mainOrder['transaction_code'];

        //-------------get transaction collection based on transaction_code ------------
        $filter = ['transaction_code' => $mainOrder['transaction_code']];
        $doc_txn = $this->dbo->findOne("masters", "transaction", $filter, []);
        if (empty($doc_txn)) {
            return array("status" => 0, "code" => "10400", "message" => "Invalid transaction_code");
        }

        $txn_orders = $existingOrders = $penaltyList = [];
        foreach ($doc_txn["order_info"] as $item) {
            if (isset($item['order_id'])) {
                $txn_orders[$item['order_id']] = $item;
            }
        }
        $billGenerated = $txn_orders_ongoing = [];

        $lineItems = $reportDeliveryChargesList = $clinicalServices = array();
        $coupon = $doc_txn["payment_info"]["coupon"];
        $grossAmount = $couponAmount = $netAmount = $advance_receipt_amt = 0;
        if (!empty($txn_orders)) {
            $filter = array('_id' => ['$in' => array_keys($txn_orders)], 'OStatus' => ['$nin' => [17, 8]]);
            $project = array("workorderinfo" => 0);
            $documents = $this->dbo->find("masters", "orders", $filter, $project);
            if (empty($documents)) {
                return array("status" => 0, "code" => "10700", "message" => "No valid orders found");
            }
            //return $documents;
            $useWallet = false;
            foreach ($documents as $doc) {
                $txn_orders_ongoing[] = intval($doc['_id']); // skip cancel order
                $orderDate = date("d-M-Y H:i A", strtotime($doc['order']['patientinfo']['scheduled_date']));
                if (count($doc['order']['orderitem']) > 1) {
                    $doc['order']['orderitem'] = array_reverse($doc['order']['orderitem']);
                }
                foreach ($doc['order']['orderitem'] as $val) {

                    if ($val['item_status'] == 8) {
                        continue; // skip lineitem
                    }
                    $existingOrders[$doc['_id']]['orderitem'][$val['item_code']] = $val;
                    $actionFlag = 'NA';
                    if ($action == 1 && $order_id == $doc['_id']) { // cancel
                        $actionFlag = "1";
                    }

                    // only reschedule, component related lineitem and non roleBasedService
                    if ($action == 3 && $order_id == $doc['_id']) { // reschedule
                        $actionFlag = "3";
                        $orderDate = date("d-M-Y H:i A", strtotime($schedule_date));
                        if (intval($val['component_no']) == intval($doc['active_component'] && !empty($val['roleBasedService']))) {
                            $actionFlag = "3";
                        }
                        if (empty($val['roleBasedService'])) { // other than roleBasedService item
                            $actionFlag = "3";
                        }

                        //if (empty($val['roleBasedService'])) {
                        //    return array("status" => 0, "code" => "40200", "message" => "reschedule is applicable for roleBasedService only");
                        //}
                    }

                    $associateCode = $associateBranchId = "";
                    foreach ($doc['order']['provider_info'] as $t) { //order.provider_info.component_no
                        if ($t['component_no'] == intval($val['component_no'])) {
                            $associateCode = $t['associate_id'];
                            $associateBranchId = $t['associate_branch_id'];
                            break;
                        }
                    }

                    $isPaid = true;
                    if ($doc['payment_info']['payment_code'] == 0) {
                        $isPaid = false;
                    }
                    // if bill is generated then change status to 6
                    $billGenerated[$doc["_id"]] = 'NO';
                    if (!empty($doc["billing"]['billing_did'])) {
                        $doc["OStatus"] = 6;
                        $billGenerated[$doc["_id"]] = "YES";
                    }

                    // for business 6,7,8
                    $bId = intval($doc["order"]["patientinfo"]["service_type"]);
                    if (in_array($bId, [6, 7, 8])) {
                        $care = new Care;
                        $rst = $care->check_child_session((object) array('orderId' => $doc["_id"]));
                        //print_r($rst);
                        if (empty($rst)) {
                            $val['quantity'] = 1;
                        } else {
                            foreach ($rst as $vv) {
                                if ($vv['_id'] == 'active') {

                                    //$order_id childrad
                                    // $doc['_id'] parent
                                    //$action==1
                                    $checkChild = 0;
                                    if ($action == 1) {

                                        $checkChild = $care->checkIsChild($order_id, $doc['_id']);

                                    }

                                    if ($checkChild == 1) {
                                        $val['quantity'] = intval($vv['count']);
                                        $actionFlag = 3;
                                    } else {
                                        $val['quantity'] = intval($vv['count']) + 1;
                                    }

                                    //echo $checkChild;exit;
                                }
                            }
                        }
                    }
                    $margin = '0.0%';
                    if(floatval($val['margin']) > 0){
                        $margin = floatval($val['margin']).'%';
                    }

                    $li = [
                        "action" => (String) $actionFlag,
                        "orderstatus" => (String) $doc["OStatus"],
                        "sessions" => (intval($val['quantity'])) ? (String) intval($val['quantity']) : "1", //quantity
                        "cartDiscountApplied" => ($val['cartDiscountApplied']) ? true : false,
                        "couponValue" => 0, //?
                        "apportionedCouponAmount" => (String) floatval($val['coupon_amount']),
                        "apportionedWalletAmount" => (String) floatval($val['wallet_amount']),
                        "cartDiscountApportionedAmount" => (floatval($val['cartDiscountApportionedAmount']) > 0) ? (String) floatval($val['cartDiscountApportionedAmount']) : "0",
                        "discountApplied" => ($val['discountApplied']) ? true : false,
                        "cartCouponApplied" => ($val['cartCouponApplied']) ? true : false,
                        "orderNumber" => (String) $doc["_id"],
                        "consultationMode" => (empty($doc['order']['business']['consultationMode'])) ? "1" : (String) $doc['order']['business']['consultationMode'],
                        //1 -> Audio 2 -> Video, 3 -> OnCall, 4-> Second opinion.
                        "orderDate" => $orderDate,
                        "orderApportionedDiscountAmount" => (floatval($val['orderApportionedDiscountAmount']) > 0) ? (String) floatval($val['orderApportionedDiscountAmount']) : "0",
                        "orderDiscountApplied" => ($val['orderDiscountApplied']) ? true : false,
                        "business" => $doc["order"]["patientinfo"]["service_type"],
                        "mrn" => $doc["order"]["patientinfo"]["mrn"],
                        "code" => $val['item_code'],
                        "source" => (String) $source,
                        "unitPrice" => (String) floatval($val['MRP']),
                        "grossAmount" => (String) floatval($val['gross_amount']),
                        "discountAmount" => (String) floatval($val['lineItemDiscountAmount']),
                        "netAmount" => (String) (floatval($val['gross_amount']) - floatval($val['lineItemDiscountAmount'])),
                        "payabaleAmount" => (String) floatval($payabaleAmount), //
                        "manufacturerID" => intval($val['manufacturer_id']),
                        "associateCode" => (String) $associateCode,
                        "associateBranchId" => (String) $associateBranchId,
                        "isPaid" => $isPaid, //
                        "MRP" => (String) $val['MRP'],
                        "isWaiver" => ($val['isWaiver']) ? true : false,
                        "zipcode" => (String) $doc["order"]["patientinfo"]["pincode"],
                        "engage_at" => (String) $doc["mode_of_service"],
                        "OMSNetAmount" => (String) floatval($val['net_amount']),
                        "vendorCode" => (String) $associateCode,
                        "vendorBranchId" => (String) $associateBranchId,
                        "voucherApportionedAmount" => (String) floatval($val['voucher_amount']),
                        // extra
                        "CLI" => (String) floatval($val['cli']),
                        "margin" => "0.0%",
                        "invoiceTo" => $val['invoiceto'],
                        "isReturnable" => ($val['isReturnable']) ? true : false,
                        "itemName" => empty($val['item_name']) ? empty($val['itemname']) ? "" : $val['itemname'] : $val['item_name'],
                        "specialityID" => 0, //
                        "coupon" => $doc["payment_info"]["coupon"],
                        "updatedPrice" => (String) 0, //
                    ];
                    if ($doc["order"]["patientinfo"]["service_type"] == 2) {
                        $li['unitPrice'] = (String) floatval($x['item_mrp']);
                    }
                    if ($doc["order"]["patientinfo"]["service_type"] == 14) {
                        $li['business'] = "100";
                    }
                    if ($doc["order"]["patientinfo"]["service_type"] == 1 && $doc["order"]["business"]["is_consultation"] == 1) {
                        $li['business'] = "10";
                        $li['doctorId'] = (String) $doc["order"]["patientinfo"]["doctorId"];
                        $li['isInternal'] = ($doc["order"]["business"]["internal"]) ? true : false;
                    }
                    if ($doc["OStatus"] == 15 || $doc["OStatus"] == 16) { // Req 4 rescheOrCancellatn
                        $li['orderstatus'] = "4";
                    }

                    if ($val['roleBasedService']) {
                        if ($val['component_no'] == 8) { // DDO || RDO
                            if ($doc["order"]["patientinfo"]["service_type"] == 2) {
                                $medicineDeliveryChargesList[] = $li;
                            } else {
                                $reportDeliveryChargesList[] = $li;
                            }
                            continue;
                        }
                        $clinicalServices[] = $li;
                        continue;
                    }
                    $lineItems[] = $li;
                }

                if (empty($existingOrders[$doc['_id']]['orderitem'])) {
                    continue;
                }

                // constructs penalties
                if (!empty($doc['penalty']) && is_array($doc['penalty'])) {
                    foreach ($doc['penalty'] as $item) {
                        if ($item['type'] == "PENALTY") {
                            $penaltyList[] = [
                                "id" => (String) $item['_id'],
                                "mad_rule_id" => $item['mad_rule_id'],
                                "penalty_code" => $item['penalty_code'],
                                "penalty_type" => $item['penalty_type'],
                                "is_paid" => ($item['status'] == 5) ? true : false,
                                "orderNumber" => $item['order_id'],
                                "penaltyAmount" => $item['amount'],
                            ];
                        }
                    }
                }

                $existingOrders[$doc['_id']]['patientinfo'] = $doc['order']['patientinfo'];
                $existingOrders[$doc['_id']]['payment_info'] = $doc['payment_info'];
                // aggregate payment
                $grossAmount += floatval($doc['payment_info']['gross_amount']);
                $couponAmount += floatval($doc['payment_info']['coupon_amount']);
                $netAmount += floatval($doc['payment_info']['net_amount']);
                $discountAmount += floatval($doc['payment_info']['discount_amount']);
                $walletAmount += floatval($doc['payment_info']['wallet_amount']);
                $voucherAmount += floatval($doc['payment_info']['voucher_amount']);
                $cartDiscountAmount += floatval($doc['payment_info']['cartDiscountAmount']);

                // calculate advance amount
                if (!empty($doc['advance_receipt']) && empty($doc["billing"]['billing_did'])) {
                    foreach ($doc['advance_receipt'] as $receipt) {
                        if ($receipt['type'] != 2) {
                            $advance_receipt_amt += floatval($receipt['receipt_amount']);
                        }
                    }
                }
            }
        }

        $vouchersDlt = [];
        if (!empty($mainOrder['payment_info']['voucher_code'])) {
            $vouchersDlt[] = [
                "voucherType" => $mainOrder['payment_info']['voucher_assoc_code'],
                "voucherNumber" => $mainOrder['payment_info']['voucher_code'],
            ];
        }

        $amountPaid = $this->getPaidAmount($txn_orders_ongoing)['amountPaid'];
        $amountPaid = $advance_receipt_amt + $amountPaid;
        $refundAmount = $financeObj->getRefunds($orderTransactionCode)['amountRefund'];
        $amountPaid = $amountPaid - $refundAmount;
        $data['grossAmount'] = floatval($grossAmount);
        $data['refund'] = floatval($refundAmount);
        $data['cartDiscountAmount'] = floatval($cartDiscountAmount);
        $data['cartMedicineDiscountAmount'] = floatval($cartMedicineDiscountAmount);
        $data['discountApplied'] = (floatval($discountAmount) > 0) ? true : false;
        $data['couponApplied'] = (!empty($doc_txn['payment_info']['coupon'])) ? true : false;
        $data['discountAmount'] = floatval($discountAmount);
        $data['couponAmount'] = floatval($couponAmount);
        $data['referralAmount'] = floatval($referralAmount);
        $data['walletAmount'] = floatval($walletAmount);
        $data['useWallet'] = (floatval($walletAmount) > 0) ? 'true' : 'false';
        $data['voucherAmount'] = floatval($voucherAmount);
        $data['netAmount'] = floatval($netAmount);
        $data['amountPaid'] = floatval($amountPaid);
        $data['penaltyList'] = $penaltyList;
        $data['source'] = $source;
        $data['coupon'] = $coupon;
        $data['vouchers'] = $vouchersDlt;

        $data['LineItems'] = $lineItems;
        if (!empty($reportDeliveryChargesList)) {
            $data['reportDeliveryChargesList'] = $reportDeliveryChargesList;
            $data['addReportDeliveryCharges'] = "yes";
        }
        if (!empty($medicineDeliveryChargesList)) {
            $data['medicineDeliveryChargesList'] = $medicineDeliveryChargesList;
            $data['addMedicineDeliveryCharges'] = "yes";
        }

        if (!empty($clinicalServices)) {
            $data['clinicalServices'] = $clinicalServices;
        }

        //return $data;
        $Logpayload = $data;
        $data = json_encode($data);
        $url = $this->config->getconfig('mdmpath', "domain/OrderUpdateCalculations");
        $startTime = microtime(true);
        // echo $flag;exit;
        //print_r($data);exit;

        if (empty($this->madRuleApiResArr[$order_id])) {
            $api_res = $this->utility->my_curl($url, 'POST', $data, 'json', null, 10);
            $this->log->logThirdPartyCall("MDM", $url, $startTime, $Logpayload, $api_res);
        } else {
            $api_res = $this->madRuleApiResArr[$order_id];
        }
        create_debug_log($order_id, 'MadRuleApiRespose', $api_res, __FILE__);

        if (strtolower($api_res['status']) != "success") {
            return array("status" => 0, "code" => "10600", "message" => "Unable to process your request. Failed from MDM for Price Calculations");
        }

        if ($validation == 1) { ///
            $this->madRuleApiResArr[$order_id] = $api_res;
            return array("status" => 1, "code" => "10100", "message" => "Operation done successfully");
        }

        //return $api_res; penaltyAmount
        /* if (floatval($api_res['penaltyList'][0]['penaltyAmount']) == 0 && floatval($api_res['refund']) == 0) {
        return array("status" => 1, "code" => "10100", "message" => "No refund No penalties");
        } */

        $cartPayableAmt = $api_res['netAmount'];
        $refund = $api_res['refund'];
        $lineItemList = $api_res['lineItemList'];
        if (!empty($api_res['clinicalServices'])) {
            $lineItemList = array_merge($lineItemList, $api_res['clinicalServices']);
        }
        if (!empty($api_res['medicineDeliveryChargesList'])) {
            $lineItemList = array_merge($lineItemList, $api_res['medicineDeliveryChargesList']);
        }
        if (!empty($api_res['reportDeliveryChargesList'])) {
            $lineItemList = array_merge($lineItemList, $api_res['reportDeliveryChargesList']);
        }
        //print_r( $lineItemList);
        $updatedOrders = $updatedTxnOrders = [];
        //return $lineItemList;
        //return $existingOrders;
        //formulate result equivalent to existingOrders
        $mdmRes = [];
        foreach ($lineItemList as $item) {
            /* if (floatval($item['grossAmount']) == 0 || floatval($item['netAmount'] == 0)) {
            continue;
            } */
            $mdmRes[$item['orderNumber']][$item['code']] = $item;
        }
        //return $updatedOrders;
        //return $updatedTxnOrders;
        //return $mdmRes;
        $finalOrders = $existingOrders;
        // update existing order based on MDM payload
        $isRefundSetinOrder = 0;
        foreach ($existingOrders as $key => $val) {
            // first process lineitem
            $orderItem = array();
            $orderGrossAmount = 0;
            $orderNetAmount = 0;
            $orderDiscountAmount = 0;
            $orderCouponAmount = 0;
            $orderVoucherAmount = 0;
            $orderWalletAmount = 0;
            foreach ($val['orderitem'] as $k => $v) { //$k:TS02DRHAECS0145
                if (!empty($mdmRes[$key][$k])) {
                    //print_r($mdmRes[$key][$k]);
                    $coupon_amount = floatval($mdmRes[$key][$k]['apportionedCouponAmount']);
                    $cartDiscountApportionedAmount = floatval($mdmRes[$key][$k]['cartDiscountApportionedAmount']);
                    $orderApportionedDiscountAmount = floatval($mdmRes[$key][$k]['orderApportionedDiscountAmount']);
                    $lineItemDiscountAmount = floatval($mdmRes[$key][$k]['discountAmount']);
                    $gross_amount = floatval($mdmRes[$key][$k]['grossAmount']);
                    $net_amount = floatval($mdmRes[$key][$k]['OMSNetAmount']);
                    $discountAmount = $gross_amount - $net_amount;
                    $voucherAmount = floatval($mdmRes[$key][$k]['voucherApportionedAmount']);
                    $walletAmount = floatval($mdmRes[$key][$k]['apportionedWalletAmount']);
                    $isWaiver = floatval($mdmRes[$key][$k]['isWaiver']);
                    $item_change_log = ($v['item_change_log']) ? $v['item_change_log'] : array();
                    $changes = array(
                        'gross_amount' => $v['gross_amount'],
                        'discount_amount' => $v['discount_amount'],
                        'net_amount' => $v['net_amount'],
                        'wallet_amount' => $v['wallet_amount'],
                        'voucher_amount' => $v['voucher_amount'],
                        'coupon_amount' => $v['coupon_amount'],
                        'cartDiscountApportionedAmount' => $v['cartDiscountApportionedAmount'],
                        'orderApportionedDiscountAmount' => $v['orderApportionedDiscountAmount'],
                        'lineItemDiscountAmount' => $v['lineItemDiscountAmount'],
                        'date' => $this->utility->getCurrenttime(),
                    );
                    array_push($item_change_log, $changes);
                    //print_r($v);
                    //print_r($item_change_log);
                    $updatedItem = array(
                        'gross_amount' => $gross_amount,
                        'discount_amount' => $discountAmount,
                        'net_amount' => $net_amount,
                        'wallet_amount' => $walletAmount, //payabaleAmount
                        'voucher_amount' => $voucherAmount,
                        'coupon_amount' => $coupon_amount,
                        'cartDiscountApportionedAmount' => $cartDiscountApportionedAmount,
                        'orderApportionedDiscountAmount' => $orderApportionedDiscountAmount,
                        'lineItemDiscountAmount' => $lineItemDiscountAmount,
                        'isWaiver' => ($isWaiver) ? true : false,
                        'item_change_log' => $item_change_log,
                    );

                    $updatedItem = array_merge($v, $updatedItem);
                    array_push($orderItem, $updatedItem);

                    $orderGrossAmount += floatval($gross_amount);
                    $orderNetAmount += floatval($net_amount);
                    $orderDiscountAmount += floatval($discountAmount);
                    $orderCouponAmount += floatval($coupon_amount);
                    $orderVoucherAmount += $voucherAmount;
                    $orderWalletAmount += $walletAmount;

                    switch (intval($mdmRes[$key][$k]['action'])) {
                        case 1:$updatedItem['item_status'] = "8";
                            break; // cancel
                        case 3:$updatedItem['item_status'] = "7";
                            break; // reschedule
                    }

                    $updatedTxnOrders[$key]['gross_amount'] += floatval($gross_amount);
                    $updatedTxnOrders[$key]['discount_amount'] += floatval($discount_amount);
                    $updatedTxnOrders[$key]['net_amount'] += floatval($net_amount);
                    $updatedTxnOrders[$key]['wallet_amount'] += floatval($wallet_amount);
                    $updatedTxnOrders[$key]['voucher_amount'] += floatval($voucher_amount);
                    $updatedTxnOrders[$key]['coupon_amount'] += floatval($coupon_amount);
                } else {
                    array_push($orderItem, $v);
                }
            }

            $finalOrders[$key]['orderitem'] = $orderItem;
            //print_r($finalOrders[$key]);
            $finalOrders[$key]['payment_info']["gross_amount"] = $orderGrossAmount;
            $finalOrders[$key]['payment_info']["discount_amount"] = $orderDiscountAmount;
            $finalOrders[$key]['payment_info']["net_amount"] = $orderNetAmount;
            $finalOrders[$key]['payment_info']["wallet_amount"] = $orderWalletAmount;
            $finalOrders[$key]['payment_info']["voucher_amount"] = $orderVoucherAmount;
            $finalOrders[$key]['payment_info']["coupon_amount"] = $orderCouponAmount;

            $finalOrders[$key]['patientinfo']["gross_amount"] = $orderGrossAmount;
            $finalOrders[$key]['patientinfo']["discount_amount"] = $orderDiscountAmount;
            $finalOrders[$key]['patientinfo']["net_amount"] = $orderNetAmount;
            $finalOrders[$key]['patientinfo']["wallet_amount"] = $orderWalletAmount;
            $finalOrders[$key]['patientinfo']["voucher_amount"] = $orderVoucherAmount;
            $finalOrders[$key]['patientinfo']["coupon_amount"] = $orderCouponAmount;

        }

        create_debug_log($order_id, 'MadRulefinalOrders', $finalOrders, __FILE__);
        //return $finalOrders;
        //return [$finalOrders,$existingOrders];

        // update order collection
        $data_trans = array();
        foreach ($finalOrders as $order_id1 => $singleOrder) {
            $set = array();
            $set['order.patientinfo'] = $singleOrder['patientinfo'];
            $set['payment_info'] = $singleOrder['payment_info'];
            $set['order.orderitem'] = $singleOrder['orderitem'];
            if ($order_id1 == $order_id && floatval($api_res['refund']) > 0) {

                $isRefundSetinOrder = 1;
                $set['order.business.refundApplicable'] = true;
            }
            if ($order_id1 == $order_id && floatval($api_res['penaltyList'][0]['penaltyAmount']) > 0) {
                $set['order.business.penaltyApplicable'] = true;
            }
            $filter = array('_id' => (int) $order_id1);
            if ($validation == 0 && $billGenerated[$order_id1] == 'NO') {
                //   $data_trans[]=array("filter"=>$filter,"set"=> $set);
                $update = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multi" => true));
            }
        }
        // print_r($data_trans);exit;
        // update in transaction collection
        $order_info = [];
        foreach ($txn_orders as $key => $val) { //$key == orderid
            if (!empty($updatedTxnOrders[$key]) && $billGenerated[$key] == 'NO') {
                $val = array_merge($val, $updatedTxnOrders[$key]);
            }
            $order_info[] = $val;
        }

        $set = array();
        $walletAmount = ($api_res['useWallet']) ? $api_res['walletAmount'] : 0;
        $payment_amount = $api_res['netAmount']; // payable amount if refund is 0.00
        //$set['payment_info.payment_amount'] = $payment_amount;
        $set['payment_info.net_amount'] = $payment_amount;
        $set['payment_info.refund_amount'] = $api_res['refund'];
        $set['payment_info.wallet_amount'] = $walletAmount;
        $set['payment_info.coupon_amount'] = $api_res['couponAmount'];
        $set['payment_info.voucher_amount'] = $api_res['voucherAmount'];
        $set['order_info'] = $order_info;
        //return $set;
        $filter = ['transaction_code' => $transaction_code]; //1-311218-7083020
        if ($validation == 0) {
            $update = $this->dbo->update("masters", "transaction", $filter, $set, array(), array("multi" => true));
        }

        // create refund or penalty
        $data_i = $litems = [];
        foreach ($mainOrder['order']['orderitem'] as $item) {
            $litems[] = $item['item_code'];
        }
        create_debug_log($order_id, 'orders_refund_penalties', $api_res['penaltyList'], __FILE__);
        if (!empty($api_res['penaltyList'])) {
            foreach ($api_res['penaltyList'] as $penalty) {
                if (floatval($penalty['penaltyAmount']) > 0) {
                    $op_type_amount = floatval($penalty['penaltyAmount']);
                    $penalty_status = 4;
                    if ((int) $api_res['refund'] != 0) {
                        $penalty_status = 5;
                    }

                    $data_i[] = array(
                        "_id" => $this->dbo->id(),
                        "transaction_code" => $mainOrder['transaction_code'],
                        "mrn" => intval($mainOrder['order']['patientinfo']['mrn']),
                        "username" => $mainOrder['order']['patientinfo']['name'],
                        "business_id" => $mainOrder['order']['patientinfo']['service_type'],
                        "order_id" => intval($penalty['orderNumber']),
                        "odid" => $mainOrder['odid'],
                        "appointment_id" => intval($appointment_id),
                        "lineitems" => $litems,
                        "action" => intval($action), // 1:Cancellation, 2:Modification, 3:Reschedule
                        "action_level" => 2, // 1:ORDER_LEVEL 2:ITEM_LEVEL
                        "reason" => $reason,
                        "comment" => $comment, // to do
                        "amount" => floatval($op_type_amount),
                        //"type" => $op_type, // REFUND || PENALTY    please consult pallav
                        "type" => "PENALTY", // REFUND || PENALTY
                        "status" => $penalty_status, // REFUND(1:INITIATED:, 2:PROCESSING, 3:PROCESS_TO_BANK  8:REJECTED,) PENALTY(4:PENDING, 5:PAID)
                        "mad_rule_id" => $penalty['mad_rule_id'],
                        "penalty_code" => $penalty['penalty_code'],
                        "penalty_type" => $penalty['penalty_type'],
                        "price_type_value" => $penalty['price_type_value'],
                        "price_type" => $penalty['price_type'],
                        "created_on" => $this->utility->getCurrenttime(),
                    );
                }
            }
            create_debug_log($order_id, 'orders_refund_penalties', $data_i, __FILE__);
            if ($validation == 0 && !empty($data_i)) {
                $this->dbo->insertMany("masters", "orders_refund_penalties", $data_i);
            }
        }

        if (floatval($api_res['refund']) > 0) {
            $data_i = array(
                "_id" => $this->dbo->id(),
                "transaction_code" => $mainOrder['transaction_code'],
                "mrn" => intval($mainOrder['order']['patientinfo']['mrn']),
                "username" => $mainOrder['order']['patientinfo']['name'],
                "business_id" => $mainOrder['order']['patientinfo']['service_type'],
                "order_id" => intval($order_id),
                "odid" => $mainOrder['odid'],
                "appointment_id" => intval($appointment_id),
                "lineitems" => $litems,
                "action" => intval($action), // 1:Cancellation, 2:Modification, 3:Reschedule
                "action_level" => 2, // 1:ORDER_LEVEL 2:ITEM_LEVEL
                "reason" => $reason,
                "comment" => $comment, // to do
                "amount" => floatval($api_res['refund']),
                "type" => 'REFUND', // REFUND || PENALTY
                "status" => 1, // REFUND(1:INITIATED:, 2:PROCESSING, 3:PROCESS_TO_BANK  8:REJECTED,) PENALTY(4:PENDING, 5:PAID)
                "mad_rule_id" => null,
                "penalty_code" => null,
                "penalty_type" => null,
                "created_on" => $this->utility->getCurrenttime(),
                "log" => array(array(
                    "status" => "1",
                    "created_on" => $this->utility->getCurrenttime(),
                    "comments" => "refund initiated",
                )),
            );
            if ($validation == 0 && !empty($data_i)) {

                $this->dbo->insert("masters", "orders_refund_penalties", $data_i);

                if ($isRefundSetinOrder == 0) {
                    $set['order.business.refundApplicable'] = true;
                    $filter = array('_id' => (int) $order_id);
                    $update = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multi" => true));
                }

            }

        }

        //return $response;
        return array("status" => 1, "code" => "10100", "message" => "Operation done successfully");
    }

    public function getPaidAmount($orderIds)
    {
        $filter['billing.billinginfo.order_id'] = ['$in' => $orderIds];
        $bills = $this->dbo->find("masters", "billing_info", $filter, ["billing.receiptinfo" => 1]);
        $amountPaid = 0;
        foreach ($bills as $bill) {
            foreach ($bill['billing']['receiptinfo'] as $receipt) {
                if ($receipt['type'] != 2) {
                    $amountPaid += floatval($receipt['receipt_amount']);
                }
            }
        }
        return ['amountPaid' => $amountPaid];
    }

    public function update_to_IHS($order_id, $corporateid)
    {
        $payload = json_encode(array("orderID" => (string) $order_id));
        $startTime = microtime(true);
        $hdfc_corporate_id = $this->config->getconfig('hdfc_corporate_id', '');
        if ($corporateid == $hdfc_corporate_id) { //HDFC corporate ID: 674
            $url = $this->config->getconfig('ihspathhdfc', "services/hdfc/updateComplteOrderStatus");
        } else { //else MEDI Assist
            $url = $this->config->getconfig('ihsmediassist', "services/hdfc/updateComplteOrderStatus");
        }
        $buffer = $this->utility->my_curl($url, 'POST', $payload, 'json', null, 10);
        $this->log->logThirdPartyCall("IHS", $url, $startTime, json_decode($payload), $buffer);
    }

    public function doctor_allocation($payload, $ticket)
    {
        $order_id = $payload->order_id;
        $associate_id = $payload->associate_id;
        $associate_branch_id = $payload->associate_branch_id;
        $actionById = $payload->actionById;
        $actionByName = $payload->actionByName;
        //-------------Validate required fields ------------
        if (empty($order_id)) {
            return array("status" => 0, "code" => "10200", "message" => "Invalid Input, Required fields are missing");
        }

        // get order details
        $filter = ['_id' => (int) $order_id]; //255293
        $order = $this->dbo->findOne("masters", "orders", $filter, array("order.orderitem.activity" => 0));
        if (empty($order)) {
            return array("status" => 0, "code" => "10300", "message" => "Invalid Order Id");
        }
        $current_w_id = $order['wid'];
        $current_w_did = $order['wodid'];
        $component_id = $order['active_component'];
        $mode_of_service = $order['mode_of_service'];
        $service_type = $order['order']['patientinfo']['service_type'];
        $corporateid = $order['order']['patientinfo']['corporateid'];

        //create log
        $logaction = $log_desc = 'Doctor allocation';
        $this->orderinfo->createlog($role, 1, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason = '', $comment = '', $facility_id = '', $popname = '', $extraLogFields = [], (isset($payload->scheduled_date)) ? 1 : 0, $payload->scheduled_date, $component_id);

        // call manual allocation api
        $manual_alloc_payload["orders"][] = (Object) [
            "order_status" => 1,
            "order_id" => $order_id,
            "associate_id" => $associate_id,
            "branch_id" => $associate_branch_id,
            "workorder_id" => $order['wid'],
            "officer_id" => $actionById,
            "allocated_by" => "5",
            "officer_name" => $actionByName,
            "scheduled_date" => $order['order']['patientinfo']['scheduled_date'],
        ];
        $yy = $this->orderinfo->manual_allocation((Object) $manual_alloc_payload, $ticket);
        if ($yy["status"] == 1) {
            // trigger email sms event
            $this->trigger_email_sms_event($order_id, 1, $component_id, $mode_of_service, $service_type, $event_flag = 0, $corporateid);
            return array("status" => 1, "code" => "10100", "message" => "Doctor allocate successfully");
        } else {
            return array("status" => 0, "code" => "10400", "message" => "Unable to allocate, Try later");
        }
    }

    public function update_to_mdm_on_order_completion($order = []) // send for cashback

    {
        $mrn = (String) $order["order"]["patientinfo"]["mrn"];
        $coupon = (String) $order["payment_info"]["coupon"];
        $service_type = (String) $order["order"]["patientinfo"]["service_type"];
        $service_subtype_id = (String) $order["order"]["patientinfo"]["service_subtype_id"];
        $order_type = (String) $order["order"]["ordertype"];
        $channel = (String) $order["channel"];
        $orderdate = (String) $order["order"]["patientinfo"]['scheduled_date'];
        $order_did = (String) $order["odid"];
        $referedby = (String) $order["order"]["patientinfo"]["referedby"];
        $bill_gross_amount = (String) $order["payment_info"]["gross_amount"];
        $bill_discount_amount = (String) $order["payment_info"]["discount_amount"];
        $bill_wallet_amount = (String) $order["payment_info"]["wallet_amount"];
        $bill_net_amount = (String) $order["payment_info"]["net_amount"];
        $bill_delivery_amount = "0";
        $receipts_amount = (String) $order["payment_info"]["paid_amount"]; // paid amount
        $vendor_name = ""; // associate name
        foreach ($order['order']['provider_info'] as $t) { //order.provider_info.component_no
            if ($t['component_no'] == 7) {
                $vendor_name = $t['associate_name'];
                break;
            }
        }
        $orderitemlabs = array();
        $itemCost = 0;
        foreach ($order['order']['orderitem'] as $items) {
            if ($items['roleBasedService'] == 1) {
                continue;
            }
            if ($items['component_no'] == 8) {
                $bill_delivery_amount = (String) $items['net_amount'];
            }
            $consultationMode = 1;
            if ($items['item_status'] != "8" && $items['item_code'] != "TS1701DGHSRA00002") {

                $orderitemlabs[] = array(
                    "code" => (string) $items['item_code'],
                    "sessions" => "1",
                    "coupon" => $coupon,
                    "grossAmount" => (string) floatval($items['gross_amount']),
                    "discountAmount" => (string) floatval($items['discount_amount']),
                    "couponAmount" => "",
                    "netAmount" => (string) floatval($items['net_amount']),
                    "payedAmount" => (string) floatval($items['net_amount']),
                    //"consultationMode" => $consultationMode,
                );
                $itemCost = $itemCost + floatval($items['net_amount']);

            }
        }

        $req_data_for_key = json_encode(["mrn" => $mrn]);
        $url = $this->config->getconfig('mdmpath', "getwallettransactionkey");
        $startTime = microtime(true);
        $result = $this->utility->my_curl($url, 'POST', $req_data_for_key, 'json', null, 10);
        $this->log->logThirdPartyCall("MDM", $url, $startTime, json_decode($req_data_for_key), $result);

        if ($result['status'] == "success") {
            if ($service_type == "1") {
                $service_type = "10";
            }

            $key = $result['value'];
            $req_data = array(
                "key" => $key,
                "business" => (string) $service_type,
                //"pop"=>(string)$facilityId,
                "mrn" => $mrn,
                "source" => $channel,
                "orderDate" => date("d-M-Y h:i A", strtotime($orderdate)), //"11-Jun-2019 08:45 AM",
                "orderNumber" => $order_did,
                "coupon" => $coupon,
                "referralCode" => (string) $referedby,
                "grossAmount" => (string) floatval($bill_gross_amount),
                "discountAmount" => (string) floatval($bill_discount_amount),
                "couponAmount" => "",
                "referralAmount" => "",
                "walletAmount" => (string) floatval($bill_wallet_amount),
                "netAmount" => (string) floatval($bill_net_amount),
                "reportDeliveryCharges" => (string) floatval($bill_delivery_amount),
                "medicineDeliveryCharges" => (string) floatval($bill_delivery_amount),
                "payedAmount" => (string) floatval($itemCost),
                "vendorName" => $vendor_name,
                "doctorReferral" => "",
                "LineItems" => $orderitemlabs,
            );

            $req_data = json_encode($req_data);
            $url = $this->config->getconfig('mdmpath', "domain/OrderCompleted");
            $startTime = microtime(true);
            $result = $this->utility->my_curl($url, 'POST', $req_data, 'json', null, 10);
            $this->log->logThirdPartyCall("MDM", $url, $startTime, json_decode($req_data), $result);
        }

    }

    public function generateSugarCrmTicket($payload)
    {
        $reason = explode('-', $payload->reason);
        //$payload->subject = $payload->subject;
        $payload->category = @trim($reason[0]);
        $payload->sub_category = @trim($reason[1]);
        $url = $this->config->getconfig('serverurl', 'OMS/api/operation.php/v1/generateTicket');
        $this->utility->async_curl($url, json_encode($payload));
    }

}
