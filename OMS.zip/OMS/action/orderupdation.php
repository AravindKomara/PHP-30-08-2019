<?php
ini_set('memory_limit', '-1');
class Orderupdation extends Oms
{

    public function getname()
    { 
        return "orderupdation";
    }

    public function __construct()
    {
        parent::__construct();
    }

    public function generateBillingInfo_inbuild($orderid)
    {

        //$request = \Slim\Slim::getInstance()->request();
        //$searchreq = json_decode($request->getBody());
        $billingidseq = $this->utility->getNextSequence("billing_id");
        $yr = date('y');
        $billingid = "B-000-" . $yr . "-" . $billingidseq;

        //$db = $this->dbo->selectDBMongo('masters');
        //$collection = $db->orders;
        //$collection2 = $db->poplist;

        $filterpatient = array("_id" => (int) $orderid);
        //$cursor = $collection->find($filterpatient)->sort(array('_id' => -1));
        $cursor = $this->dbo->find('masters','orders',$filterpatient,[],['_id' => -1]);
        $paid_amount = 0;
        $all_receipt_submitted = "0";
        $payment_status = "1";
        $billing_status = "1";

        if (count($cursor) > 0) {
            foreach ($cursor as $document) {

                $discount_amount = 0;
                $net_amount = 0;
                $gross_amount = 0;
                $due_amount = 0;
                $wallet_amount = 0;
                $invoiceto = "0";
                $processed = "NP";
                $bill_type = "OMS";
                $delivery_charges = 0;
                foreach ($document['order']['orderitem'] as $orderitem) {
                    if (!isset($orderitem['cancelbeforeaccept']) || $orderitem['cancelbeforeaccept'] == "0") {
                        $discount_amount += $orderitem['discount_amount'];
                        $net_amount += (float) $orderitem['net_amount'];
                        $gross_amount += (float) $orderitem['gross_amount'];
                        $invoiceto = isset($orderitem['invoiceto']) ? $orderitem['invoiceto'] : "0";
                    }
                }

                if (isset($document['order']['patientinfo']['wallet_amount'])) {
                    $wallet_amount = $document['order']['patientinfo']['wallet_amount'];

                }

                if (isset($document['order']['ordertype']) && $document['order']['ordertype'] == "rad") {
                    $discount_amount = "0";
                    $net_amount = floor($document['order']['patientinfo']['net_amount']);
                    $gross_amount = round($document['order']['patientinfo']['gross_amount']);
                }

                $receipttrackerid = $document['order']['order_status']['receipts_tracker_id'];
                $gcm = $document['order']['patientinfo']['gcm'];
                $mrn = $document['order']['patientinfo']['mrn'];
                $patient_id = $document['order']['patientinfo']['patient_id'];
                $facility_id = $document['order']['patientinfo']['facility_id'];
                $scheduled_date = $document['order']['patientinfo']['scheduled_date'];
                $prepaid_amount = isset($document['order']['prepayment']['amount']) ? floor($document['order']['prepayment']['amount']) : 0;

                //$net_amount=floor($document['order']['patientinfo']['net_amount']);
                //$gross_amount=floor($document['order']['patientinfo']['gross_amount']);
                //$discount_amount=$document['order']['patientinfo']['discount_amount'];
                $payment_method = $document['order']['patientinfo']['payment_method'];
                $service_type = $document['order']['patientinfo']['service_type'];
                $service_subtype_id = $document['order']['patientinfo']['service_subtype_id'];
                $name = $document['order']['patientinfo']['name'];
                $order_id = $document['order']['patientinfo']['order_id'];
                $mhoid = $document['order']['order_status']['assignedto'];
                $order_did = $document['order']['order_status']['order_did'];
                $loungeplace = isset($document['order']['patientinfo']['loungeplace']) ? $document['order']['patientinfo']['loungeplace'] : "";
                $loungeplaceid = isset($document['order']['patientinfo']['loungeplaceid']) ? $document['order']['patientinfo']['loungeplaceid'] : "";
                $billingdate = date("Y") . "-" . date("m") . "-" . date("d") . "T" . date("H") . ":" . date("i") . ":" . date("s") . ".000Z";

                $discount_amount = floor($discount_amount);
                $net_amount = floor($net_amount);
                $gross_amount = round($gross_amount);

                if ($net_amount < "0" || $net_amount < 0) {
                    $net_amount = 0;
                }

                if ($invoiceto == "2") {
                    $due_amount = (float) 0;
                    $processed = "P";
                    $bill_type = "CORPORATE";
                } else {
                    $due_amount = $net_amount;
                    if ($service_type == 2 || $service_type == "2") {
                        $delivery_charges = isset($document['order']['patientinfo']['medicine_delivery_charge']) ? $document['order']['patientinfo']['medicine_delivery_charge'] : "0";
                        //$gross_amount = (float)$med_del_charge + (float)$gross_amount;
                        //$net_amount = (float)$med_del_charge + (float)$net_amount;
                        $due_amount = (float) $delivery_charges + (float) $due_amount;
                    }
                }
            }

            $isprepaid = "no";
            $receiptinfo = array();
            if ($prepaid_amount > 0 && $document['order']['ordertype'] != "rad") {
                $payment_submited = 0;
                $payment_collected = 0;
                $paymentmode = $document['order']['prepayment']['payment_mode'];
                $referencenumber = $document['order']['prepayment']['payment_ref_no'];
                $receiptdate = $document['order']['prepayment']['receipt_date'];
                $receiptid = $document['order']['prepayment']['receipt_id'];

                $remainamount = $due_amount - (float) $prepaid_amount;
                if ($remainamount < 0) {
                    $due_amount = 0;
                    $all_receipt_submitted = "1";
                    $payment_status = "3";
                    $billing_status = "3";
                    //refund amount to be set

                } else if ($remainamount == 0) {
                    $due_amount = $remainamount;
                    $all_receipt_submitted = "1";
                    $payment_status = "3";
                    $billing_status = "3";
                } else {
                    $due_amount = $remainamount;
                }

                $payment_submited = "1";
                $payment_collected = "1";
                $paid_amount = $prepaid_amount;
                $receiptinfo = array(array('receipt_id' => $receiptid, 'billing_id' => $billingid, 'receipt_amount' => $prepaid_amount, 'payment_mode' => $paymentmode, 'payment_ref_no' => $referencenumber, 'payment_submited' => $payment_submited, 'payment_collected' => $payment_collected, 'receipt_date' => $receiptdate, 'receipt_status' => 1, "processed" => "NP"));
                $isprepaid = "yes";
            }

            if (isset($facility_id)) {
                //$cursor1 = $collection2->find(array("popinfo.FACILITY_ID" => $facility_id));
                $cursor1 = $this->dbo->find('masters','poplist',["popinfo.FACILITY_ID" => $facility_id],[]);
                if (count($cursor1) > 0) {
                    foreach ($cursor1 as $document1) {
                        $facility_did = $document1['popinfo']['FACILITY_DID'];
                    }
                } else {
                    $facility_did = "";
                }
            } else {
                $facility_did = "";
            }

            $due_amount = $due_amount - $wallet_amount;
            $patientinfo = array("gcm" => $gcm, "mrn" => $mrn, "patient_id" => $patient_id, "name" => $name, "facility_id" => $facility_id, "payment_facility_id" => $facility_id, "scheduled_date" => $scheduled_date, "service_type" => $service_type, "service_subtype_id" => $service_subtype_id, "order_id" => $order_id, "source" => $bill_type, "loungeplaceid" => $loungeplaceid, "loungeplace" => $loungeplace);
            $billinginfo = array("billingid" => $billingid, "receipts_tracker_id" => $receipttrackerid, "assignedto" => $mhoid, "net_amount" => $net_amount, "gross_amount" => $gross_amount, "discount_amount" => $discount_amount, "due_amount" => $due_amount, "paid_amount" => $paid_amount, "cancelled_amount" => "0", "processed" => $processed, "submitted_amount" => $paid_amount, "all_receipt_submitted" => $all_receipt_submitted, "billing_date" => $billingdate, "order_id" => $order_id, "order_did" => $order_did, "facility_did" => $facility_did, 'payment_status' => $payment_status, 'billing_status' => $billing_status, "wallet_amount" => $wallet_amount, 'delivery_charges' => (float) $delivery_charges, 'isprepaid' => $isprepaid);
            //$receiptinfo=array("receiptid"=>"","amount_collected"=>"","collection_date"=>"");

            $finalarray = array("_id" => $receipttrackerid, "billing" => array("patientinfo" => $patientinfo, "billinginfo" => $billinginfo, "receiptinfo" => $receiptinfo));
            //$collection1 = $db->billing_info;
            $cursor2 = $this->dbo->find('masters','billing_info',["_id" => (int) $receipttrackerid],[]);
            $updateamounts = $this->dbo->update('masters','orders', 
                    ['_id' => (int) $order_id],
                    ['billing.payment_status' => "1", 'billing.billing_status' => "1"]
            );
            if (count($cursor2) > 0) {
                
            } else {
                $inserted_id = $this->dbo->insert('masters','billing_info',$finalarray);
            }

        }
        //echo json_encode($inserted_id);
    }

    public function cancelItem($orderreq,$ticket)
	{
		
		$this->log->create_log("","",$this->getname(),"Execution",200,"cancelItem_start",json_encode($orderreq),(string)$ticket);
		try
		{
			//print_r($orderreq);exit;
			
			if($orderreq=="")
			{
					$response=array("response"=>"0","msg"=>"Invalid JSON received .");
					return $response;
					//echo json_encode($response);
					//exit;
			}
			
			
			$current_time = $this->utility->getCurrentdatetimesimple();	
			//"Y-m-d H:i:s.000Z" format
			
			if(!isset($orderreq->order_id))
			{
				$response=array("response"=>"0","msg"=>"Invalid JSON received .");
				
				$this->log->create_log("","",$this->getname(),"Execution",200,"cancelItem_issue",json_encode($response),(string)$ticket);
				
				return $response;
				//echo json_encode($response);
				//exit;
			}
			if(!isset($orderreq->item_code))
			{
				$response=array("response"=>"0","msg"=>"Invalid JSON received .");
				
				$this->log->create_log("","",$this->getname(),"Execution",200,"cancelItem_issue",json_encode($response),(string)$ticket);
				
				return $response;
				//echo json_encode($response);
				//exit;
			}
			
			$order_filter = array("_id"=>(int)$orderreq->order_id);
			$order_project = array("order.orderitem"=>1,"transaction_code"=>1,
									"order.patientinfo.service_type"=>1);
			
			$order_cursor = $this->dbo->find('masters','orders',$order_filter,$order_project);
			
			foreach($order_cursor as $order_detail)
			{
				$orderitem = $order_detail[order][orderitem];
				$transaction_code = $order_detail[transaction_code];
				$service_type = (int)$order_detail[order][patientinfo][service_type];
				
				//if all the other items are already cancelled previously it is an orderCancel call now, this also works when there is only oneline item and it is being cancelled, already cancelled items will not be cancelled again.
				$cancel_flag = 1;
				$present_flag = 0; // To check whether the item to cancel is present in order
				
				foreach($orderitem as $item)
				{
					if($item[item_code] != $orderreq->item_code)
					{
						if((int)$item[item_status]!=8)
						{
							$cancel_flag = 0;
						}
					}
					
					else
					{
						$present_flag = 1;
						//Already cancelled Item
						if((int)$item[item_status]==8)
						{
							$response = array("status"=>0,"message"=>"Item already cancelled previously");
							return $response;
						}
					}
				}
				
				if($present_flag == 0)
				{
					$response = array("status"=>0,"message"=>"Item code not available in order");
					return $response;
				}
				
				if($cancel_flag==1)
				{
					//Call orderCancel api
					$ord_payload = array("order_id"=>array($orderreq->order_id)
									,"reason"=>$orderreq->reason
									,"comment"=>$orderreq->comment
									,"reason_text"=>""
									,"actionById"=>""
									,"actionByName"=>""
									);
					$ord_payload = json_encode($ord_payload);
					
					//OLD URL (DUMMY) SHOULD BE UPDATED
					//$sub_url = 'pandu/OMS-10-01-2019/api/operation.php/v1/orderCancel';
					
					$sub_url = 'OMS/api/operation.php/v1/orderCancel';
					
					
					$url = $this->config->getConfig("serverurl",$sub_url); //URL to hit
					
					//echo $url." ".$ord_payload;exit;
					
					//CALLING THE orderCancel API
					$output = $this->utility->my_curl($url,'POST',$ord_payload,'json',null,30);
					//print_r($output);exit;
					
					return $output;
				}
				

				//MAD RULE API call for itemCancel
				$payload = array("transaction_code"=>$transaction_code
								,"action"=>"1"   // for cancellation
								,"line_item"=>$orderreq->item_code
								);
				
				if($service_type != 2 and $service_type!=3 and $service_type!=4)
				{
					$response = array("status"=>0,"message"=>"Service type ".$service_type." Item cannot be cancelled.");
					return $response;
				}
				else
				{
					$payload[appointment_id]= "";
					$payload[order_id]= (int)$orderreq->order_id;
				}
				
				$payload = json_encode($payload);
				
				//Call for MAD Rule API
				$sub_url = 'OMS/api/operation.php/v1/order/change/status/forlineitem';
				
				$url = $this->config->getConfig("serverurl",$sub_url); //URL to hit
		
				//CALLING THE API
				$output = $this->utility->my_curl($url,'POST',$payload,'json',null,30);
				return $output;
			
			}
		}
		
		catch(Exception $e)
		{
			echo 'Message: ' .$e->getMessage();
			
			$this->log->create_log("","",$this->getname(),"Execution",300,"Error_cancelItem",$e->getMessage(),(string)$ticket);
		}
	}

    //CAN FIND THE FUNCTION    IN finance.php
    /* function generateReceiptInfo($searchreq,$ticket)
    {
    $this->log=new Logapp;
    $this->log->create_log("","",$this->getname(),"Execution",200,"generateReceiptInfo_start",json_encode($searchreq),(string)$ticket);
    try
    {
    $this->dbo = new Dbo;
    $this->utility = new Utility;
    $this->config = new Config;

    $order_id=$searchreq->order_id;

    $this->generateBillingInfo_inbuild($order_id);

    $receiptidseq=$this->utility->getNextSequence("receipt_id");
    $yr=date('y');
    $receiptid="R-000-".$yr."-".$receiptidseq;
    $receiptdate=date("Y")."-".date("m")."-".date("d")."T".date("H").":".date("i").":".date("s").".000Z";

    $receiptamount=$searchreq->receiptamount;
    if($receiptamount<=0)
    {
    $response=array("response"=>"0","msg"=>"Please enter a Valid amount.");
    echo json_encode($response);
    exit;
    }
    $billingid=$searchreq->billingid;
    $paymentmode=$searchreq->paymentmode;
    $receipts_tracker_id=$searchreq->receipts_tracker_id;
    $referencenumber=$searchreq->referencenumber;

    $db = $this->dbo->selectDBMongo('masters');
    $collection = $db->billing_info;
    $collection1 = $db->orderlog;
    $collection2 = $db->orders;

    //for log

    $actionById=isset($searchreq->actionById)?$searchreq->actionById:'';
    $actionByName=isset($searchreq->actionByName)?$searchreq->actionByName:'';
    $latitude=isset($searchreq->latitude)?$searchreq->latitude:'';
    $longitude=isset($searchreq->longitude)?$searchreq->longitude:'';
    $source=isset($searchreq->source)?$searchreq->source:'mobile';

    //$orderlog=array("created_date"=>date("Y-m-d H:i:s"),"created_by"=>"MHO","action"=>"receipt genereted- #".$receiptid,"order_status"=>"5");

    $filterpatient = array("_id" =>(int)$receipts_tracker_id);
    $cursor = $collection->find($filterpatient)->sort(array('_id'=>-1));
    if($cursor->count()>0)
    {
    foreach ($cursor as $document)
    {
    $order_id=$document['billing']['billinginfo']['order_id'];
    $dueamount=$document['billing']['billinginfo']['due_amount'];
    $paid_amount=$document['billing']['billinginfo']['paid_amount'];
    $service_type = $document['billing']['patientinfo']['service_type'];
    if($service_type=="4" || $order_type=="childrad" || $order_type=="rad")
    {
    $role ="Onsite Facilitator";
    }
    else if($service_type=="2")
    {
    $role ="DDO";
    }
    else
    {
    $role ="MHO";
    }
    }
    //$newdueamount=($dueamount-$receiptamount);
    //$newpaid_amount=($paid_amount+$receiptamount);
    $newdueamount=((float)round($dueamount,2)-(float)round($receiptamount,2));
    $newdueamount=round($newdueamount,2);
    $newpaid_amount=($paid_amount+$receiptamount);
    }
    $filterpatient4 = array("_id" => (int)$order_id);
    $cursor4 = $collection2->find($filterpatient4);
    foreach ($cursor4 as $document4)
    {
    $servicetypeid=$document4['order']['patientinfo']['service_type'];
    $wid=$document4['wid'];
    $wdid=$document4['wodid'];
    $order_type=isset($document4['order']['ordertype'])?$document4['order']['ordertype']:"";
    $facility_id = $document4['order']['patientinfo']['facility_id'];
    $popname = $document4['order']['patientinfo']['popname'];
    }

    if($newdueamount >= 0)
    {
    $orderlog=array("created_date"=>date("Y-m-d H:i:s"),"role"=>$role,"order_status"=>"5","action"=>"receipt genereted","actionById"=>$actionById,"actionByName"=>$actionByName,'description'=>'source:'.$source.',receiptid:#'.$receiptid.',amount colleceted:'.$receiptamount,'latitude'=>$latitude,'longitude'=>$longitude,'paymentmode'=>$paymentmode,'receiptamount'=>$receiptamount,"wid"=>$wid,"wodid"=>$wdid,"facility_id"=>$facility_id,"popname"=>$popname);

    $receiptarray=array('receipt_id' => $receiptid,'billing_id' => $billingid,'receipt_amount'=>$receiptamount,'payment_mode'=>$paymentmode,'payment_ref_no'=>$referencenumber,'payment_submited'=>0,'payment_collected'=>0,'receipt_date'=>$receiptdate,'receipt_status'=>1,"processed"=>"NP",'mho_id'=>$actionById,"mho_name"=>$actionByName,'submitted_to'=>"0");

    $response=array("response"=>"0","msg"=>"Operation Failed.");
    $updateamounts=$collection->update(
    array('_id' => (int)$receipts_tracker_id),
    array('$set' => array('billing.billinginfo.paid_amount' =>(string)$newpaid_amount,'billing.billinginfo.due_amount' => $newdueamount,'billing.billinginfo.assignedto' =>$actionById,'billing.billinginfo.billing_status' =>"1")),
    array("multi"=>true)
    );
    $updatereceipt =$collection->update(
    array('_id' =>(int)$receipts_tracker_id),
    array('$push' => array('billing.receiptinfo'=>$receiptarray))
    );

    if($updatereceipt['ok']==1)
    {
    $response=array("response"=>"1","msg"=>"Receipt generated successfully","receipt_id"=>$receiptid);
    //for log
    $collection1->update(
    array('order.order_status.receipts_tracker_id' => (int)$receipts_tracker_id),
    array('$push' => array('order_log' =>$orderlog))
    );
    }

    //for sms and email event (start)
    if($servicetypeid=="2")
    {
    $eventid=48;
    $applicationid=10;
    $topicid=3;
    $orderstatus=1;
    $eventtype=4;
    //$evnt=$this->convertOrderToEvent($order_id,$eventid,$applicationid,$topicid,$orderstatus,$eventtype,$receiptamount);
    //print_r($evnt);
    }
    else
    {
    $eventid=33;
    $applicationid=4;
    $topicid=3;
    $orderstatus=1;
    $eventtype=4;

    //$evnt=$this->convertOrderToEvent($order_id,$eventid,$applicationid,$topicid,$orderstatus,$eventtype,$receiptamount);
    //print_r($evnt);
    }
    //for sms and email event (end)

    }
    else
    {
    $response=array("response"=>"0","msg"=>"Operation Failed.");
    }

    $this->log->create_log("","",$this->getname(),"Execution",200,"generateReceiptInfo_end",json_encode($response),(string)$ticket);
    //echo json_encode($response);
    return $response;
    }

    catch(Exception $e)
    {
    echo 'Message: ' .$e->getMessage();
    $this->log->create_log("","",$this->getname(),"Execution",300,"Error_generateReceiptInfo",$e->getMessage(),(string)$ticket);
    }

    }
     */

    /*
    function updateBillingInfoByReceiptId($orderreq,$ticket)
    {
    $this->log=new Logapp;
    $this->log->create_log("","",$this->getname(),"Execution",200,"updateBillingInfoByReceiptId_start",json_encode($orderreq),(string)$ticket);
    try
    {
    $this->dbo = new Dbo;
    $this->utility = new Utility;
    $this->config = new Config;

    if($orderreq=="")
    {
    $response=array("response"=>"0","msg"=>"Invalid Json Received.");

    $this->log->create_log("","",$this->getname(),"Execution",200,"updateBillingInfoByReceiptId_issue",json_encode($response),(string)$ticket);

    echo json_encode($response);
    exit;
    }

    $fields_validation=array('receipt_tracker_id','receipt_id','amt','paymentStatus','actionById','actionByName');
    foreach($fields_validation as $field)
    {
    if(!isset($orderreq->{$field}))
    {
    $response=array("response"=>"0","msg"=>"Invalid Json Received.");

    $this->log->create_log("","",$this->getname(),"Execution",200,"updateBillingInfoByReceiptId_issue",json_encode($response),(string)$ticket);

    echo json_encode($response);
    exit;
    }
    }

    $response=array("response"=>"0","msg"=>"Payment Updation failed.");

    $db = $this->dbo->selectDBMongo('masters');
    $collection = $db->billing_info;
    $collection2 = $db->orders;
    //for log
    $collection1 = $db->orderlog;

    $submited_on=date("Y")."-".date("m")."-".date("d")."T".date("H").":".date("i").":".date("s").".000Z";
    $newsubmitted_amount="0";
    $filterpatient = array("_id" => (int)$orderreq->receipt_tracker_id);
    $cursor = $collection->find($filterpatient);
    foreach ($cursor as $document)
    {

    $cursor2 = $collection2->find(array("_id" => (int)$orderreq->order_id));
    foreach ($cursor2 as $document2)
    {
    $current_w_id = $document2['wid'];
    $current_w_did = $document2['wodid'];
    $facility_id = $document2['order']['patientinfo']['facility_id'];
    $popname = $document2['order']['patientinfo']['popname'];
    }

    $orderlog=array("created_date"=>date("Y-m-d H:i:s"),"role"=>"POP","order_status"=>"5","action"=>"Payment Updated","actionById"=>$orderreq->actionById,"actionByName"=>$orderreq->actionByName,"description"=>"Payment Updated for Receipt ID:".$orderreq->receipt_id,'wid'=>$current_w_id,'wodid'=>$current_w_did,"facility_id"=>$facility_id,"popname"=>$popname);

    $submitted_amount=$document['billing']['billinginfo']['submitted_amount'];
    if($orderreq->paymentStatus=="1")
    {
    $newsubmitted_amount=($submitted_amount+$orderreq->amt);
    }
    else if($orderreq->paymentStatus=="0")
    {
    $newsubmitted_amount=($submitted_amount-$orderreq->amt);
    }
    else
    {
    $newsubmitted_amount = $submitted_amount;
    }

    $update=$collection->update(
    array("_id" => (int)$orderreq->receipt_tracker_id),
    array('$set' => array('billing.billinginfo.submitted_amount' => $newsubmitted_amount,'billing.billinginfo.payment_status' => "2")),
    array("multi"=>true)
    );

    $updatecount=0;
    $receiptitems = count($document['billing']['receiptinfo']);
    for($i=0; $i<$receiptitems; $i++)
    {
    $update1=$collection->update(
    array("billing.receiptinfo.".$i.".receipt_id" => $orderreq->receipt_id,"_id" => (int)$orderreq->receipt_tracker_id),
    array('$set' => array('billing.receiptinfo.'.$i.'.payment_submited' => (int)$orderreq->paymentStatus,'billing.receiptinfo.'.$i.'.submited_date' => $submited_on,'billing.receiptinfo.'.$i.'.pop_id'=>$orderreq->actionById,'billing.receiptinfo.'.$i.'.pop_name'=>$orderreq->actionByName)),
    array("multi"=>true)
    );
    if($update1['ok']==1)
    {
    $updatecount=1;
    }
    }

    if($update['ok']==1)
    {
    $response=array("response"=>$updatecount,"msg"=>"Payment Updated Successfully.");
    //for log
    $collection1->update(
    array('_id' => (int)$orderreq->order_id),
    array('$push' => array('order_log' =>$orderlog))
    );
    }
    }

    $this->log->create_log("","",$this->getname(),"Execution",200,"updateBillingInfoByReceiptId_end",json_encode($response),(string)$ticket);
    echo json_encode($response);
    return $response;
    }

    catch(Exception $e)
    {
    echo 'Message: ' .$e->getMessage();
    $this->log->create_log("","",$this->getname(),"Execution",300,"Error_updateBillingInfoByReceiptId",$e->getMessage(),(string)$ticket);
    }

    }*/

    public function updateReceiptPaymentStatus($orderreq, $ticket)
    {

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "updateReceiptPaymentStatus_start", json_encode($orderreq), (string) $ticket);
        try
        {
            //print_r($orderreq);

            $response = array("response" => "0", "msg" => "Updation failed.");

            // $db = $this->dbo->selectDBMongo('masters');
            // $collection = $db->billing_info;
            // $collection2 = $db->orders;

            //for log
            $actionById = isset($orderreq->actionById) ? $orderreq->actionById : '';
            $actionByName = isset($orderreq->actionByName) ? $orderreq->actionByName : '';
            $latitude = isset($orderreq->latitude) ? $orderreq->latitude : '';
            $longitude = isset($orderreq->longitude) ? $orderreq->longitude : '';
            $source = isset($orderreq->source) ? $orderreq->source : 'mobile';
            $submitted_to = isset($orderreq->submitted_to) ? $orderreq->submitted_to : '1';

            //$collection1 = $db->orderlog;

            //$orderlog=array("created_date"=>date("Y-m-d H:i:s"),"created_by"=>"MHO","action"=>"Payment collected for receipt#".$orderreq->receipt_id);
            if ($orderreq->payment_collected == "1") {
                $action = "Payment collected";
            } else {
                $action = "Payment collection cancelled";
            }

            $filterpatient = array("_id" => (int) $orderreq->receipt_tracker_id);
            $cursor = $this->dbo->find("masters","billing_info",$filterpatient,array(),array());
            //echo json_encode($cursor);exit;

            foreach ($cursor as $document) {

                $service_type = $document['billing']['patientinfo']['service_type'];

                $order_id = $document['billing']['patientinfo']['order_id'];

                $orderFilter = array("_id" => (int) $order_id);
                $cursor4 = $this->dbo->find("masters","orders",$orderFilter,array(),array());
                //echo json_encode($cursor4);exit;

                foreach ($cursor4 as $document4) {
                    $order_type = isset($document4['order']['ordertype']) ? $document4['order']['ordertype'] : "";
                    $facility_id = $document4['order']['patientinfo']['facility_id'];
                    $popname = $document4['order']['patientinfo']['popname'];
                }
                if ($service_type == "4" || $order_type == "childrad" || $order_type == "rad") {
                    $role = "Onsite Facilitator";
                } else if ($service_type == "2") {
                    $role = "DDO";
                } else {
                    $role = "MHO";
                }

                $receiptitems = count($document['billing']['receiptinfo']);
                //print_r($receiptitems);exit;

                for ($i = 0; $i < $receiptitems; $i++) 
                {
                    $updateFilter = array("billing.receiptinfo." . $i . ".receipt_id" => $orderreq->receipt_id, "_id" => (int) $orderreq->receipt_tracker_id);
                    $set = array(
                            'billing.receiptinfo.' . $i . '.payment_collected' => (int) $orderreq->payment_collected,
							//'billing.receiptinfo.' . $i . '.payment_submitted' => 0,
                            'billing.receiptinfo.' . $i . '.submitted_to' => $submitted_to
                    );
                    $options = array("multi" => true);
                    
                   $this->dbo->update("masters","billing_info",$updateFilter,$set,array(),$options,array());
                }
                //for log
                $orderlog = array("created_date" => date("Y-m-d H:i:s"), "role" => $role, "order_status" => "22", "action" => "Payment collected", "actionById" => $actionById, "actionByName" => $actionByName, 'description' => 'source:' . $source . ",receipt id:#" . $orderreq->receipt_id, 'latitude' => $latitude, 'longitude' => $longitude, "facility_id" => $facility_id, "popname" => $popname);

                $logFilter = array('order.order_status.receipts_tracker_id' => (int)$orderreq->receipt_tracker_id);
                $push = array('order_log' => $orderlog);

                $this->dbo->update("masters","orderlog",$logFilter,array(),$push,array(),array());


                //if($update['ok']==1 && $update['nModified']==1){
                $response = array("response" => "1", "msg" => "Updated Successfully.");
                //}
            }
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "updateReceiptPaymentStatus_end", json_encode($response), (string) $ticket);

            //echo json_encode($response);
            return $response;
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_updateReceiptPaymentStatus", $e->getMessage(), (string) $ticket);
        }

    }

    public function updateSampleInfo($request, $ticket) // not using 
    {

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "updateSampleInfo_start", json_encode($request), (string) $ticket);
        try
        {

            //$db = $this->dbo->selectDBMongo('masters');

            //$collection = $db->orders;

            $order_did = $request->OrderId;
            $sample_status = $request->status;

            $totalSamplesCollected = isset($request->totalSamplesCollected) ? $request->totalSamplesCollected : "0";
            $totalSamplesSubmitted = isset($request->totalSamplesSubmitted) ? $request->totalSamplesSubmitted : "0";
            $pickUpBoyName = isset($request->pickUpBoyName) ? $request->pickUpBoyName : "";
            $pickUpBoyMobile = isset($request->pickUpBoyMobile) ? $request->pickUpBoyMobile : "";

            $barcode = array();
            $sampletype = array();
            $current_time = substr(date("c", strtotime(date('Y-m-d H:i:s'))), 0, 19) . ".000Z";

            if (isset($request->barCode) && !empty($request->barCode)) {
                $barcode = $request->barCode;
            }
            if (isset($request->sampleType) && !empty($request->sampleType)) {
                $sampletype = $request->sampleType;
            }

            if (isset($request->collectionDate)) {
                $request->collectionDate = str_replace(" ", "T", $request->collectionDate);
                $request->collectionDate = $request->collectionDate . ".000Z";
            } else {
                $request->collectionDate = $current_time;
            }
            $sample_collection_date = $request->collectionDate;

            if ($sample_status == "0") {
                $date_coloum = "sample_submitted_by_mho_date";
            } else if ($sample_status == "1") {
                $date_coloum = "sample_collection_by_pop_date";
            } else if ($sample_status == "2") {
                $date_coloum = "sample_collection_by_vendor_date";
            } else {
                $response = array("response" => "0", "msg" => "Operation Failed");
                $this->log->create_log("", "", $this->getname(), "Execution", 200, "updateSampleInfo_issue", json_encode($response), (string) $ticket);
                echo json_encode($response);
                exit;
            }

            $response = array("response" => "0", "msg" => "Operation Failed");
            $singleData = array("odid" => $order_did);
            //$result = $collection->find($singleData);
            $result = $this->dbo->find('masters','orders',$singleData,[]);
            if (count($result) == 1) {
                if (!empty($barcode)) {
                    $this->dbo->update('masters','orders',['odid' => $order_did],
                        ['order.patientinfo.barcode.barcode' => $barcode],[],["multi" => true]
                    );
                }
                if (!empty($sampletype)) {
                    $this->dbo->update('masters','orders',['odid' => $order_did],
                        ['order.patientinfo.barcode.sampleType' => $sampletype],[],["multi" => true]
                    );
                }

                if ($sample_status == "0") {
                    $update = $this->dbo->update('masters','orders',
                        ['odid' => $order_did],
                        array(
                            'order.patientinfo.diag_sample_status' => (string) $sample_status,
                            'order.patientinfo.' . $date_coloum => $sample_collection_date,
                            'order.patientinfo.totalSamples' => $totalSamplesSubmitted,
                        ),
                        [],
                        array("multi" => true)
                    );
                } else if ($sample_status == "1") {
                    $update = $this->dbo->update('masters','orders',
                        ['odid' => $order_did],
                        array(
                            'order.patientinfo.diag_sample_status' => (string) $sample_status,
                            'order.patientinfo.' . $date_coloum => $sample_collection_date,
                            'order.patientinfo.totalSamplesCollected' => $totalSamplesCollected,
                            'order.patientinfo.pickUpBoyName' => $pickUpBoyName,
                            'order.patientinfo.pickUpBoyMobile' => $pickUpBoyMobile,
                        ),
                        [],
                        array("multi" => true)
                    );
                } else {
                    $update = $this->dbo->update('masters','orders',
                        ['odid' => $order_did],
                        array(
                            'order.patientinfo.diag_sample_status' => (string) $sample_status,
                            'order.patientinfo.' . $date_coloum => $sample_collection_date,
                            'order.patientinfo.pickUpBoyName' => $pickUpBoyName,
                            'order.patientinfo.pickUpBoyMobile' => $pickUpBoyMobile,
                        ),
                        [],
                        array("multi" => true)
                    );
                }

                if ($update['ok'] == 1) {
                    $response = array("response" => "1", "msg" => "Sample Updated Successfully");
                }
            }

            $this->log->create_log("", "", $this->getname(), "Execution", 200, "updateSampleInfo_end", json_encode($response), (string) $ticket);

            //echo json_encode($response);
            return $response;
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_updateSampleInfo", $e->getMessage(), (string) $ticket);
        }
    }

    public function addOrderItem($searchreq,$ticket)
	{
		$this->log->create_log("","",$this->getname(),"Execution",200,"addOrderItem_start",json_encode($searchreq),(string)$ticket);
		
		try
		{
			if($searchreq=="")
			{
				$response=array("status"=>"0","msg"=>"Invalid JSON received");
				
				$this->log->create_log("","",$this->getname(),"Execution",200,"addOrderItem_issue",json_encode($response),(string)$ticket);
				
				echo json_encode($response);
				exit;
			}
			
			$validation_fields = array("itemname","item_code","gross_amount","discount_amount","net_amount");
			//,"department","sampletype","reportdeliverydateto","reportdeliverydatefrom"
			
			$response = array();	
			if(!isset($searchreq->OrderID))
			{
				$response["status"]="0";
				$response["msg"][]="missing OrderID";
				
			}
			foreach($validation_fields as $fields)
			{
				
				if(!isset($searchreq->itemDetails->{$fields}))
				{
					$response["status"]="0";
					$response["msg"][]="missing $fields";
				}
			}
			
			if(!empty($response))
			{
				$this->log->create_log("","",$this->getname(),"Execution",200,"addOrderItem_issue",json_encode($response),(string)$ticket);
					
				echo json_encode($response);
				exit;
			}
			
			$order_id=(int)$searchreq->OrderID;
			$item_details = $searchreq->itemDetails;
			$item_code = $item_details->item_code;
			
			/* $item_code=$searchreq->item_code ;
			$itemname=$searchreq->itemname ;
			$gross_amountit=$searchreq->gross_amount ;
			$discount_amountit=$searchreq->discount_amount ;
			$net_amountit=$searchreq->net_amount ;
			$department=$searchreq->department;
			$sampletype=$searchreq->sampletype;
			$vacutainer=$searchreq->vacutainer;
			$reportdeliverydatefrom=$searchreq->reportdeliverydatefrom;
			$reportdeliverydateto=$searchreq->reportdeliverydateto;
			$order_id=(int)$searchreq->OrderID; */
			
			$filter = array("_id"=>$order_id);
			$order_cursor = $this->dbo->findOne('masters','orders',$filter,array());
			
			//if order not found
			if(empty($order_cursor) or $order_cursor==null)
			{
				$response = array("status"=>0,"message"=>"No order exists with this OrderID");
				return $response;
			}
			
			$transaction_code = $order_cursor['transaction_code'];
			
			$action ="1"; //addOrderItem
			//print_r($order_cursor);exit;
			
			//if item already exists
			foreach($order_cursor['orderitem'] as $item)
			{
				if($item[item_code] == $item_code)
				{
					$response = array("status"=>0,"message"=>"Line Item ALready Exists");
					return $response;
				}
			}
			
			//if billed
			if(isset($order_cursor[billing][billingdid]) and $order_cursor[billing][billingdid]!= null)
			{
				$response = array("status"=>0,"message"=>"Cannot add items to already billed order");
				return $response;
			}
			
			
			
			//Calling MAD rule API
			
			$payload = array("transaction_code"=>$transaction_code
							,"order_id"=>$order_id
							,"line_item"=>$item_code
							,"action"=>$action
							,"is_new_item"=>true
							,"new_item"=>$item_details
							);
			
			$payload = json_encode($payload);
						
			//MAD Rule API URL
			$sub_url = 'OMS/api/operation.php/v1/order/change/status/forlineitem';
			
			$url = $this->config->getConfig("serverurl",$sub_url); //URL to hit
			//echo $url." ".$payload;exit;
			
			//CALLING THE API
			$output = $this->utility->my_curl($url,'POST',$payload,'json',null,30);
			
			$this->log->create_log("","",$this->getname(),"Execution",200,"addOrderItem_End",json_encode($output),(string)$ticket);
			
			//echo json_encode($response);
			return $output;
		}	
			
		catch(Exception $e)
		{
			echo 'Message: ' .$e->getMessage();
			$this->log->create_log("","",$this->getname(),"Execution",300,"Error_addOrderItem",$e->getMessage(),(string)$ticket);
		}	
			
			
	}
		
    public function generateDocumentInfo($searchreq, $ticket)
    {

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "generateDocumentInfo_start", json_encode($searchreq), (string) $ticket);
        try
        {

            //$db = $this->dbo->selectDBMongo('masters');
            //$collection = $db->orders;

            //for log

            $actionById = isset($searchreq->actionById) ? $searchreq->actionById : '';
            //echo $actionById;exit;
            $actionByName = isset($searchreq->actionByName) ? $searchreq->actionByName : '';
            $latitude = isset($searchreq->latitude) ? $searchreq->latitude : '';
            $longitude = isset($searchreq->longitude) ? $searchreq->longitude : '';
            $source = isset($searchreq->source) ? $searchreq->source : 'mobile';
            //$collection2 = $db->orderlog;

            //$orderlog=array("created_date"=>date("Y-m-d H:i:s"),"created_by"=>"MHO","action"=>"prescription uploaded");

            $current_status = "";
            $filterpatient = array("_id" => (int) $searchreq->OrderID);
            //$cursor = $collection->find($filterpatient)->sort(array('_id' => -1));
            $cursor = $this->dbo->find('masters','orders',$filterpatient,[],['_id' => -1]); 
            //if ($cursor->count() > 0) {
            if (count($cursor) > 0) {
                foreach ($cursor as $document) {
                    $document_tracker_id = $document['order']['order_status']['document_tracker_id'];
                    $gcm = $document['order']['patientinfo']['gcm'];
                    $mrn = $document['order']['patientinfo']['mrn'];
                    $patient_id = $document['order']['patientinfo']['patient_id'];
                    $facility_id = $document['order']['patientinfo']['facility_id'];
                    $popname = $document['order']['patientinfo']['popname'];
                    $scheduled_date = $document['order']['patientinfo']['scheduled_date'];
                    $service_type = $document['order']['patientinfo']['service_type'];
                    $name = $document['order']['patientinfo']['name'];
                    $order_id = $document['order']['patientinfo']['order_id'];
                    $mhoid = $document['order']['order_status']['assignedto'];
                    $current_status = $document['order']['order_status']['order_status'];
                    $created_date = date("Y") . "-" . date("m") . "-" . date("d") . "T" . date("H") . ":" . date("i") . ":" . date("s") . ".000Z";
                }

                $orderlog = array("created_date" => date("Y-m-d H:i:s"), "role" => "MHO", "order_status" => $current_status, "action" => "prescription uploaded", "actionById" => $actionById, "actionByName" => $actionByName, 'description' => 'source:' . $source, 'latitude' => $latitude, 'longitude' => $longitude, "facility_id" => $facility_id, "popname" => $popname);

                $patientinfo = array("gcm" => $gcm, "mrn" => $mrn, "patient_id" => $patient_id, "name" => $name, "facility_id" => $facility_id, "assignedto" => $mhoid, "scheduled_date" => $scheduled_date, "service_type" => $service_type, "order_id" => $order_id);
                $documentinfo = array("document_tracker_id" => $document_tracker_id, "created_date" => $created_date, "file_type" => $searchreq->file_type, "file_content" => $searchreq->base64image, "document_type" => $searchreq->document_type);
                $finalarray = array("_id" => $document_tracker_id, "document" => array("patientinfo" => $patientinfo, "documentinfo" => array($documentinfo)));

                //$collection1 = $db->order_documents;
                $filterdocument = array("_id" => (int) $document_tracker_id);
                //$cursordoc = $collection1->find($filterdocument)->sort(array('_id' => -1));
                $cursordoc = $this->dbo->find('masters','order_documents',$filterdocument,[],['_id' => -1]);
                //if ($cursordoc->count() > 0) {
                if (count($cursordoc) > 0) {
                    $updatereceipt = $this->dbo->update('masters','order_documents',$filterdocument,[],['document.documentinfo' => $documentinfo]);
                } else {
                    $inserted_id = $this->dbo->insert('masters','order_documents', $finalarray);
                }
                //for log
                $this->dbo->update('masters','orderlog',['order.patientinfo.order_id' => (int) $order_id],[],
                    ['order_log' => $orderlog]);
                $response = array("response" => "1", "msg" => "Document uploaded successfully");
            }

            $this->log->create_log("", "", $this->getname(), "Execution", 200, "generateDocumentInfo_End", json_encode($response), (string) $ticket);

            //echo json_encode($response);
            return $response;
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_generateDocumentInfo", $e->getMessage(), (string) $ticket);
        }

    }

    public function getPrescriptioninfo($searchreq, $ticket)
    {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "getPrescriptioninfo_start", json_encode($searchreq), (string) $ticket);
        try
        {
            //$db = $this->dbo->selectDBMongo('masters');
            //$collection = $db->order_documents;
            $filterpatient = array("_id" => (int) $searchreq->document_tracker_id);
            //$cursor = $collection->find($filterpatient)->sort(array('_id' => -1));
            $cursor = $ths->dbo->find('masters','order_documents',$filterpatient,[],['_id' => -1]);
            $response = array("countn" => "0", "itemlist" => "No Records found");
            if (count($cursor) > 0) {
                $response["countn"] = count($cursor);
                foreach ($cursor as $document) {
                    $result = $document['document']['documentinfo'];
                }
                $response["itemlist"] = $result;
            }

            $this->log->create_log("", "", $this->getname(), "Execution", 200, "getPrescriptioninfo_end", json_encode($response), (string) $ticket);
            //echo json_encode($response);
            return $response;
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_getPrescriptioninfo", $e->getMessage(), (string) $ticket);
        }

    }

    //added by prakhar 22-01-2019

    public function insertProcessCompletedTime($payload, $ticket)
    {

        $filterpatient = array("_id" => (int) $payload->order_id);
        $cursor = $this->dbo->find("masters", "orders", $filterpatient, array(), array());
        //echo json_encode($cursor);exit;

        foreach ($cursor as $document) {
            $wid = $document["wid"];
        }

        $filter = array('_id' => (int) $payload->order_id);
        $set = array('order.patientinfo.process_complete_time' => $payload->process_complete_time);
        $options = array("multi" => true);

        $update = $this->dbo->update("masters", "orders", $filter, $set, array(), $options);
        //print_r($update);exit;

        //print_r($response1);exit;

        $filter1 = array('_id' => (int) $wid);
        $set1 = array('orderinfo.process_complete_time' => $payload->process_complete_time);
        $options1 = array("multi" => true);

        $update1 = $this->dbo->update("masters", "workorders", $filter1, $set1, array(), $options1);
        //print_r($update1);exit;

        if ($update["nModified"] == 1 && $update1["nModified"] == 1) {
            $response = array("status" => 1, "message" => "Updated Successfully!");
        } else {
            $response = array("status" => 0, "message" => "Failed to Update");
        }

        return $response;
    }

    public function UpdateBarcode($payload)
    {
        
        if($payload->option==1)
        {
            $filterpatient = array("_id" => (int) $payload->order_id);
            $set = array(
            "order.patientinfo.barcode" => array(
                'sampleType' => $payload->sampleType
            ));
            $cursor = $this->dbo->update("masters", "orders", $filterpatient, $set, array(), array());
			if($cursor[updatedExisting])
				$response = array("response" => "1", "message" => "sampletype updated successfully","msg"=>"Updated Successfully");
			else
				$response = array("response" => "1", "message" => "sampletype not accepted","msg"=>"sampletype not accepted");
            return $response;  
        }
        else if($payload->option==2)
        {
           $filter = array(
			"order.patientinfo.barcode.barcode"=>$payload->barcode,
			"_id" =>array( '$nin'=>array((int) $payload->order_id)));
			
			$count=$this->dbo->countitem("masters", "orders", $filter);
			
			if((int)$count>0)
			{
				$response = array("response" => "0", "message" => "Barcode Duplicate","msg"=>"Barcode Duplicate");
		
                 return $response;
			}




		   $filterpatient = array("_id" => (int) $payload->order_id);
            $set = array(
            "order.patientinfo.barcode" => array(
                'barcode' => [$payload->barcode]
            ));
            $cursor = $this->dbo->update("masters", "orders", $filterpatient, $set, array(), array());
            if($cursor[updatedExisting])
				$response = array("response" => "1", "message" => "Barcode updated successfully","msg"=>"Updated Successfully");
		    else
				$response = array("response" => "1", "message" => "Barcode not accepted","msg"=>"Barcode not accepted");
            return $response;
        }

        else if($payload->option==3)
        {
			
			$filter = array(
			"order.patientinfo.barcode.barcode"=>$payload->barcode,
			"_id" =>array( '$nin'=>array((int) $payload->order_id)));
			
			$count=$this->dbo->countitem("masters", "orders", $filter);
			
			if((int)$count>0)
			{
				$response = array("response" => "0", "message" => "Barcode Duplicate","msg"=>"Barcode Duplicate");
		
                 return $response;
			}
			
            $filterpatient = array("_id" => (int) $payload->order_id);
            $set = array(
            "order.patientinfo.barcode" => array(
                'sampleType' => $payload->sampleType,
                'barcode' => [$payload->barcode]
            ));
            $cursor = $this->dbo->update("masters", "orders", $filterpatient, $set, array(), array());

           if($cursor[updatedExisting])
				$response = array("response" => "1", "message" => "Both barcode and sampletype updated successfully","msg"=>"Updated Successfully");
		    else
				$response = array("response" => "1", "message" => "Barcode not accepted","msg"=>"Barcode not accepted");
			
            return $response;   
        }
        else
        {
            $filter = array(
			"order.patientinfo.barcode.barcode"=>$payload->barcode,
			"_id" =>array( '$nin'=>array((int) $payload->order_id)));
			
			$count=$this->dbo->countitem("masters", "orders", $filter);
			
			if((int)$count>0)
			{
				$response = array("response" => "0", "message" => "Barcode Duplicate","msg"=>"Barcode Duplicate");
		
                 return $response;
			}
			
			
			$filterpatient = array("_id" => (int) $payload->order_id);
            $set = array(
            "order.patientinfo.barcode" => array(
                'sampleType' => $payload->sampleType,
                'barcode' => [$payload->barcode]
            ));
            $cursor = $this->dbo->update("masters", "orders", $filterpatient, $set, array(), array());
			
			if($cursor[updatedExisting])
				$response = array("response" => "1", "message" => "Both barcode and sampletype updated successfully","msg"=>"Updated Successfully");
		    else
				$response = array("response" => "1", "message" => "Barcode not accepted","msg"=>"Barcode not accepted");
		
            return $response;
        }
        
    }
    public function allocate_order($payload,$ticket)
    {
        $filterpatient = array("odid"=>$payload->odid);
        $status = $payload->status;

        $set = 
        array
            (
                "assaigned_to"=>$payload->assaigned_to,
                "order.order_status.assignedto"=>$payload->assignedto,
                "OStatus"=>$status,
                "WOStatus"=>$status,
                "order.patientinfo.order_status"=>$status,
                "order.order_status.order_status"=>$status,
                "order.order_status.mhoname"=>$payload->mho_name,
                "order.provider_info"=>[array
                (
                    "associate_id"=>$payload->associate_id,
                    "associate_branch_id"=>$payload->associate_branch_id,
                    "associate_name"=>$payload->associate_name,
                    "associate_address" => null,
                    "associate_location" => null,
                    "associate_latitude" => null,
                    "associate_longitude" => null,
                    "associate_contact_number" => null,
                    "associate_email_id" => null,
                    "associate_website_url" => null,
                    "associate_license_number" => null,
                    "associate_skill" => null
                )]
            );

        $update = array($filterpatient,$set);
        //echo json_encode($update);exit;

        $result = $this->dbo->update("masters","orders",$filterpatient,$set,array(),array('$multi'=>true));
        //echo json_encode($result);exit;

        if($result['nModified']==1)
        {
            $response= array("status"=>"1","message"=>"Order Updation Successful");
            return $response;
        }
        else
        {
            $response= array("status"=>"0","message"=>"Order Updation Failed");
            return $response;
        }
    }

}
