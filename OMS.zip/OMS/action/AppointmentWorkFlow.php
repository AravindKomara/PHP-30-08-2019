<?php
//error_reporting(E_ALL);
class AppointmentWorkFlow extends Oms
{
    public function __construct()
    {
        parent::__construct();
        $this->orderinfo = new Orderinfo;
    }

    public function getname()
    {
        return "appointmentworkflow";
    }

    public function change_appointment_status($payload, $ticket)
    {
        //var_dump($payload);die;
        $appointmentid = $input_data['appointmentid'] = $payload->appointmentid;
        $actionById = $input_data['actionById'] = $payload->actionById;
        $actionByName = $input_data['actionByName'] = $payload->actionByName;
        $channel = $input_data['channel'] = $payload->channel;
        $status = $input_data['status'] = $payload->status;
        $reason = $input_data['reason'] = $payload->reason;

        //appointmentid*,reason*,status*,actionById*,actionByName*,channel*,scheduled_date,doctorId,doctorName,specialityId,specialityName,transaction_id,role_id,start_time,end_time,

        //-------------Validate required fields ------------
        if (empty($appointmentid) || empty($status) || empty($actionById) || empty($actionByName) || empty($channel)) {
            return array("success" => 0, "code" => "10200", "message" => "Invalid Input, Required fields are missing");
        }

        //-------------get order collection based on appointmentid ------------
        $filter = ['appointmentId' => (string) $appointmentid]; //255293
        $document = $appointment = $this->dbo->findOne("masters", "appointments", $filter, array("activity" => 0));
        if (empty($appointment)) {
            return array("success" => 0, "code" => "10300", "message" => "Invalid Appointment Id");
        }

        //-------------check weather same or different status ------------
        $order_status_old = $document['status']; // = 10;
        if (intval($order_status_old) == $status && $status != 7 && $status != 1) {
            return array("success" => 0, "code" => "10400", "message" => "Appointment already in the same status.");
        }

        switch ($status) {
            //------------- for status 1 : Reassigned------------
            case 1:
                $log_desc = 'Appointment Reassigned';
                if (!isset($payload->doctorId) || empty($payload->doctorId)) {
                    return array("success" => 0, "code" => "20200", "message" => "doctorId is missing");
                }
                if (!isset($payload->specialityId) || empty($payload->specialityId)) {
                    return array("success" => 0, "code" => "20300", "message" => "specialityId is missing");
                }
                if (!isset($payload->reason) || empty($payload->reason)) {
                    return array("success" => 0, "code" => "20700", "message" => "reason is missing");
                }
                $input_data['reschedule_count'] = intval($document['reschedule_count']);
                $input_data['schedule_date'] = $document['schedule_date'];
                $input_data['doctorId'] = $payload->doctorId;
                $input_data['doctorName'] = $payload->doctorName;
                $input_data['specialityId'] = $payload->specialityId;
                $input_data['specialityName'] = $payload->specialityName;

                return $this->assign_appointment($input_data, $ticket);
                break;
            //------------- for status 2 : accepted------------
            case 2:
                $log_desc = 'Appointment Accepted';
                if (empty($reason)) {
                    $reason = 'Appointment Accepted by ' . $actionByName;
                }
                $input_data['reschedule_count'] = intval($document['reschedule_count']);
                $input_data['action'] = $log_desc;
                return $this->accept_appointment($input_data, $ticket);
                break;
            //------------- for status 6 : Completed------------
            case 6:
                $log_desc = 'Appointment Completed';
                if (empty($reason)) {
                    $reason = 'Appointment Completed by ' . $actionByName;
                }
                $input_data['reschedule_count'] = intval($document['reschedule_count']);
                $input_data['action'] = $log_desc;
                $input_data['reason'] = $reason;
                return $this->complete_appointment($input_data, $ticket);
                break;
            //------------- for status 7 : Rescheduled------------
            case 7:
                $log_desc = 'Appointment Rescheduled';

                if (!isset($payload->scheduled_date) || empty($payload->scheduled_date)) {
                    return array("success" => 0, "code" => "10500", "message" => "scheduled_date is missing");
                }

                if (!isset($payload->transaction_id) || empty($payload->transaction_id)) {
                    return array("success" => 0, "code" => "10600", "message" => "transaction_id is missing");
                }
                if (!isset($payload->role_id) || empty($payload->role_id)) {
                    return array("success" => 0, "code" => "10700", "message" => "role_id is missing");
                }
                if (!isset($payload->start_time) || empty($payload->start_time)) {
                    return array("success" => 0, "code" => "10800", "message" => "start_time is missing");
                }
                if (!isset($payload->end_time) || empty($payload->end_time)) {
                    return array("success" => 0, "code" => "10900", "message" => "end_time is missing");
                }
                if (!isset($payload->doctorId) || empty($payload->doctorId)) {
                    return array("success" => 0, "code" => "20200", "message" => "doctorId is missing");
                }
                if (!isset($payload->specialityId) || empty($payload->specialityId)) {
                    return array("success" => 0, "code" => "20300", "message" => "specialityId is missing");
                }
                if (!isset($payload->reason) || empty($payload->reason)) {
                    return array("success" => 0, "code" => "20700", "message" => "reason is missing");
                }

                $reschedule_count = intval($document['reschedule_count']) + 1;
                $reschedule_limit = 3;
                if ($reschedule_count > $reschedule_limit) {
                    return array("success" => 0, "code" => "20100", "message" => "Reschedule count limit is Exceed");
                }

                $input_data['reschedule_count'] = intval($document['reschedule_count']);
                $input_data['action'] = $log_desc;
                $input_data['reason'] = $reason;
                $input_data['scheduled_date'] = $payload->scheduled_date;
                $input_data['doctorId'] = $payload->doctorId;
                $input_data['doctorName'] = $payload->doctorName;
                $input_data['specialityId'] = $payload->specialityId;
                $input_data['specialityName'] = $payload->specialityName;
                $input_data['transaction_id'] = $payload->transaction_id;
                $input_data['role_id'] = $payload->role_id;
                $input_data['startDateTime'] = $payload->start_time;
                $input_data['endDateTime'] = $payload->end_time;
                return $this->reschedule_appointment($input_data, $ticket);
                break;
            //------------- for status 8 : Cancelled------------
            case 8:
                $log_desc = 'Appointment Cancelled';
                if (!isset($payload->reason) || empty($payload->reason)) {
                    return array("success" => 0, "code" => "20700", "message" => "reason is missing");
                }
                $input_data['action'] = $log_desc;
                $input_data['reason'] = $reason;
                $input_data['reschedule_count'] = intval($document['reschedule_count']);
                return $this->cancel_appointment($input_data, $ticket);
                break;
            //------------- for status 9 : Rejected------------
            case 9:
                $log_desc = 'Appointment Rejected';
                if (!isset($payload->reason) || empty($payload->reason)) {
                    return array("success" => 0, "code" => "20700", "message" => "reason is missing");
                }
                $input_data['action'] = $log_desc;
                $input_data['reason'] = $reason;
                $input_data['reschedule_count'] = intval($document['reschedule_count']);
                return $this->reject_appointment($input_data, $ticket);
                break;
            default:return array("success" => 0, "code" => "20200", "message" => "Invalid Appointment Status.");
        }
    }

    /**
     * 10100 : Appointment has been {rescheduled} successfully
     * 10200 : Invalid Input, Required fields are missing
     * 10300 : Invalid Appointment Id
     * 10400 : Appointment already in the same status.
     * 10500 : scheduled_date is missing
     * 10600 : transaction_id is missing
     * 10700 : role_id is missing
     * 10800 : start_time is missing
     * 10900 : end_time is missing
     * 20100 : Reschedule count limit is Exceed
     * 20200 : doctorId is missing
     * 20300 : specialityId is missing
     * 20400 : Unable to reschedule appointment, Chiss failed
     * 20500 : Unable to cancel appointment, Chiss failed
     * 20600 : Unable to accept appointment, Chiss failed
     * 20700 : reason is missing
     * 20800 : Unable to reject appointment, Chiss failed
     * 20900 : Unable to reassign appointment, Chiss failed
     *
     */
    public function appointment_update($data)
    {
        $log = array(
            "action" => $data['action'],
            "channel" => $data['channel'],
            "actionById" => $data['actionById'],
            "actionByName" => $data['actionByName'],
            "app_work_id" => $data['reschedule_count'],
            "reason" => $data['reason'],
            "status" => $data['status'],
        );
        $set = array(
            "status" => $data['status'],
            "reason" => $data['reason'],
        );
        if ($data['status'] == 7) {
            $log2 = array(
                "doctor_id" => $data['doctorId'],
                "doctorName" => $data['doctorName'],
                "specialityid" => $data['specialityId'],
                "speciality" => $data['specialityName'],
                "transaction_id" => $data['transaction_id'],
                "schedule_date" => date('Y-m-d\TH:i:s', strtotime($data['scheduled_date'])) . '.000Z',
                "startDateTime" => $data['startDateTime'],
                "endDateTime" => $data['endDateTime'],
            );
            $log = array_merge($log, $log2);
            $set2 = array(
                "scheduledDate" => date('Y-m-d\TH:i:s', strtotime($scheduled_date)) . '.000Z',
                "startDateTime" => $data['startDateTime'],
                "endDateTime" => $data['endDateTime'],
                "speciality" => $data['specialityName'],
                "doctorId" => $data['doctorId'],
                "doctorName" => $data['doctorName'],
                "transactionId" => $data['transaction_id'], // chiss_transaction_id
                "role_id" => $data['role_id'],
                "specialityid" => $data['specialityId'],
                "reschedule_count" => $data['reschedule_count'],
            );
            $set = array_merge($set, $set2);
        }
        if ($data['status'] == 1) { // re assign
            $set2 = array(
                "doctorId" => $data['doctorId'],
                "doctorName" => $data['doctorName'],
                "reschedule_count" => $data['reschedule_count'],
            );
            $set = array_merge($set, $set2);
        }
        $log['created_date'] = $this->dbo->date(time());
        $filter = array('appointmentId' => (string) $appointmentid);
        $push = array("worklog" => $log);
        $update = $this->dbo->update("masters", "appointments", $filter, $set, $push, array("multi" => true));
        return array("success" => 1, "code" => "10100", "message" => $data['message']);
    }

    public function accept_appointment($data, $ticket)
    {
        $appointmentid = $data['appointmentid'];
        $reschedule_count = $data['reschedule_count'] + 1;

        $chissData = ['appointmentid' => $appointmentid, 'reschedule_count' => $reschedule_count];
        $tt = $this->chiss_accept_appointment($chissData, $ticket);
        if (!$tt['success']) {
            return $tt;
        }
        $data['reschedule_count'] = $reschedule_count;
        $data['message'] = "Appointment has been Accepted successfully";
        return $this->appointment_update($data);
    }

    public function chiss_accept_appointment($data, $ticket)
    {
        $input_payload = (Object) ["order_id" => $data['appointmentid'], "workorder_id" => intval($data['reschedule_count'])];
        $yy = $this->orderinfo->chiss_order_acceptance($input_payload, $ticket)[0];
        //var_dump($yy); die;
        if ($yy['response'] == 0) {
            return array("success" => 0, "code" => "20600", "message" => "Unable to accept appointment, Chiss failed. " . $yy->message);
        }
    }

    public function reschedule_appointment($data, $ticket)
    {
        $appointmentid = $data['appointmentid'];
        $reschedule_count = $data['reschedule_count'] + 1;
        $scheduled_date = $data['scheduled_date'];
        $transaction_id = $data['transaction_id'];

        $chissData = ['appointmentid' => $appointmentid, 'reschedule_count' => $reschedule_count, 'scheduled_date' => $scheduled_date, 'transaction_id' => $transaction_id];
        $tt = $this->chiss_reschedule_appointment($chissData, $ticket);
        if (!$tt['success']) {
            return $tt;
        }
        $data['reschedule_count'] = $reschedule_count;
        $data['message'] = "Appointment has been rescheduled successfully";
        return $this->appointment_update($data);
    }

    public function chiss_reschedule_appointment($data, $ticket)
    {
        $serverpath = $this->config->globalvars['serverurl'];
        $url = $serverpath . 'OMS/api/operation.php/v1/appointmentreschedule_chiss';
        $payload = array(
            'appointmentid' => (string) $data['appointmentid'],
            'workorder_id' => $data['reschedule_count'] - 1,
            'new_workorder_id' => $data['reschedule_count'],
            'scheduled_date' => date('Y-m-d\TH:i:s', strtotime($data['scheduled_date'])) . '.000Z',
            'transaction_id' => $data['transaction_id'],
        );
        $payload = json_encode($payload);
        $res = $this->utility->my_curl($url, "POST", $payload);
        if ($res[0]['status'] == 0) {
            return array("success" => 0, "code" => "20400", "message" => "Unable to reschedule appointment, Chiss failed");
        }
    }

    public function cancel_appointment($data, $ticket)
    {
        $appointmentid = $data['appointmentid'];
        $reschedule_count = $data['reschedule_count'] + 1;
        $chissData = ['appointmentid' => $appointmentid, 'reschedule_count' => $reschedule_count];
        $tt = $this->chiss_cancel_appointment($chissData, $ticket);
        if (!$tt['success']) {
            return $tt;
        }
        $data['reschedule_count'] = $reschedule_count;
        $data['message'] = "Appointment has been cancelled successfully";
        return $this->appointment_update($data);
    }

    public function chiss_cancel_appointment($data, $ticket)
    {
        $payload = (Object) array(
            "order_id" => $data['appointmentid'],
            "workorder_id" => $data['reschedule_count'],
        );
        $res = $this->orderinfo->chiss_order_cancel($payload, $ticket);
        if ($res[0]['status'] == 0) {
            return array("success" => 0, "code" => "20500", "message" => "Unable to cancel appointment, Chiss failed");
        }
    }

    public function reject_appointment($data, $ticket)
    {
        $appointmentid = $data['appointmentid'];
        $reschedule_count = $data['reschedule_count'] + 1;
        $chissData = ['appointmentid' => $appointmentid, 'reschedule_count' => $reschedule_count];
        $tt = $this->chiss_order_rejection($chissData, $ticket);
        if (!$tt['success']) {
            return $tt;
        }
        $data['reschedule_count'] = $reschedule_count;
        $data['message'] = "Appointment has been rejected successfully";
        return $this->appointment_update($data);
    }

    public function chiss_order_rejection($data, $ticket)
    {
        $payload = (Object) array(
            "order_id" => $data['appointmentid'],
            "workorder_id" => $data['reschedule_count'],
            "new_workorder_id" => $data['reschedule_count'] + 1,
        );
        $res = $this->orderinfo->chiss_order_rejection($payload, $ticket);
        if ($res[0]['status'] == 0) {
            return array("success" => 0, "code" => "20800", "message" => "Unable to reject appointment, Chiss failed");
        }
    }

    public function complete_appointment($data, $ticket)
    {
        $data['message'] = "Appointment has been completed successfully";
        return $this->appointment_update($data);
    }

    public function assign_appointment($data, $ticket)
    {
        $appointmentid = $data['appointmentid'];
        $reschedule_count = $data['reschedule_count'] + 1;
        $doctorId = $data['doctorId'];
        $doctorName = $data['doctorName'];
        $schedule_date = $data['schedule_date'];
        $chissData = ['appointmentid' => $appointmentid, 'reschedule_count' => $reschedule_count, 'doctorId' => $doctorId, 'doctorName' => $doctorName, 'schedule_date' => $schedule_date];
        $tt = $this->chiss_assign_appointment($chissData, $ticket);
        if (!$tt['success']) {
            return $tt;
        }
        $data['reschedule_count'] = $reschedule_count;
        $data['message'] = "Appointment has been reassigned successfully";
        return $this->appointment_update($data);
    }

    public function chiss_assign_appointment($data, $ticket)
    {
        $manual_alloc_payload["orders"][] = (Object) [
            "order_status" => 1,
            "order_id" => $data['appointmentid'],
            "workorder_id" => $data['reschedule_count'],
            "officer_id" => $data['doctorId'],
            "officer_name" => $data['doctorName'],
            "scheduled_date" => $data['schedule_date'],
        ];
        $yy = $this->orderinfo->manual_allocation($manual_alloc_payload, $ticket);
        if ($yy->response == 0) {
            return array("status" => 0, "code" => "20900", "message" => "Unable to reassign appointment, Chiss failed " . $yy->message);
        }
    }

}
