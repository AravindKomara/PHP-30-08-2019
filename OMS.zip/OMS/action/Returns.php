<?php
//error_reporting(E_ALL);
class Returns extends Oms
{
    public function __construct()
    {
        parent::__construct();
    }

    public function getname()
    {
        return "returns";
    }

    //  {"id":"1-170119-7083282", "type":"1"}  {"id":"517141", "type":"2"}
    public function get_return_quantity_status($payload, $ticket)
    {
        $itemcodes = $payload->itemcodes;
        $order_id = $payload->order_id;
        //-------------Validate required fields ------------
        if (empty($itemcodes) || empty($order_id)) {
            return array("success" => 0, "code" => "10200", "message" => "Invalid Input Or Required fields are missing");
        }

        if (!is_array($itemcodes)) {
            return array("success" => 0, "code" => "10200", "message" => "itemcodes should be array");
        }

        $itemArr = [];
        foreach ($itemcodes as $item) {
            $itemArr[$item->code] = $item->qty;
        }

        //-------------get order collection based on order_id ------------
        $filter = ['_id' => (int) $order_id]; //255293
        $order = $this->dbo->findOne("masters", "orders", $filter, ["order.orderitem.item_code" => 1, "order.orderitem.quantity" => 1, "order.orderitem.item_status" => 1]);
        if (empty($order)) {
            return array("status" => 0, "code" => "10300", "message" => "Invalid Order Id");
        }
        $data['penalty'] = $data['refund'] = 0;
        $data['return_mode'] = 'FULL_RETURN';
        $data['non_returnable_items'] = [];
        foreach ($order['order']['orderitem'] as $item) {
            if ($item['item_status'] == 8) {
                continue;
            }
            if ($item['quantity'] != $itemArr[$item['item_code']]) {
                $data['return_mode'] = 'PARTIAL_RETURN';
            }
        }

        $content = fopen("../testing/Ticket.pdf", "r");
        //https://ormuatblobonperm.blob.core.windows.net/ container/path
        $rss = $this->utility->blog_upload_block('oms', 'mrn/invoices/return/orderId.pdf', $content);

        return array("status" => 1, "code" => "10100", "message" => "Operation done successfully", "data" => $data);
    }

    public function uploder($payload)
    {
        if (empty($payload['mrn']) || empty($payload['order_id']) || empty($payload['file_mode'])) {
            return array("status" => 0, "code" => "10200", "message" => "Required fields are missing:mrn,order_id,file_mode");
        }
        $rss = null;
        if ($_FILES["file"]['error'] == 0) {
            $content = fopen($_FILES["file"]["tmp_name"], 'r');
            $filePath = $payload['mrn'] . '/invoices/return/' . $payload['order_id'] . '/' . $_FILES["file"]['name'];
            $filePath = str_replace(' ', '', $filePath);
            $rss = $this->utility->blob_upload_block('oms', $filePath, $content);
        }
        if ($rss) {
            $url = AZURE_BASE_PATH . $filePath;
            return array("status" => 1, "code" => "10100", "message" => "File uploaded successfully", "data" => ["url" => $url]);
        } else {
            return array("status" => 0, "code" => "10300", "message" => "Upload failed, Try later");
        }
    }

    public function test($payload, $ticket)
    {
        require_once '../libraries/AzureUploder.php';
        $azure_uploder = new AzureUploder();
        //$res = $azure_uploder->blog_create_container('oms');
        $res = $this->utility->blob_delete_block('oms', '454545/invoices/return/343434/orderId(1).pdf');
        $res = $azure_uploder->list_blobs('oms');
        return $res;
    }
}
