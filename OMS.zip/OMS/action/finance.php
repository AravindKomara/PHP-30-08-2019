<?php

require_once '../libraries/mypdf.php';

class Finance extends Oms {

    public $urlpath = SERVER_PATH;

    public function __construct() {
        parent::__construct();
    }

    private function getname() {
        return "finance";
    }

    public function amount_in_word($amount) {
        $no = floor($amount);
        $hundred = null;
        $digits_1 = strlen($no);
        $i = 0;
        $str = array();
        $words = array(
            '0' => '',
            '1' => 'one',
            '2' => 'two',
            '3' => 'three',
            '4' => 'four',
            '5' => 'five',
            '6' => 'six',
            '7' => 'seven',
            '8' => 'eight',
            '9' => 'nine',
            '10' => 'ten',
            '11' => 'eleven',
            '12' => 'twelve',
            '13' => 'thirteen',
            '14' => 'fourteen',
            '15' => 'fifteen',
            '16' => 'sixteen',
            '17' => 'seventeen',
            '18' => 'eighteen',
            '19' => 'nineteen',
            '20' => 'twenty',
            '30' => 'thirty',
            '40' => 'forty',
            '50' => 'fifty',
            '60' => 'sixty',
            '70' => 'seventy',
            '80' => 'eighty',
            '90' => 'ninety',
        );
        $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
        while ($i < $digits_1) {
            $divider = ($i == 2) ? 10 : 100;
            $number = floor($no % $divider);
            $no = floor($no / $divider);
            $i += ($divider == 10) ? 1 : 2;
            if ($number) {
                $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
                $str[] = ($number < 21) ? $words[$number] .
                        " " . $digits[$counter] . $plural . " " . $hundred :
                        $words[floor($number / 10) * 10]
                        . " " . $words[$number % 10] . " "
                        . $digits[$counter] . $plural . " " . $hundred;
            } else {
                $str[] = null;
            }
        }
        $str = array_reverse($str);
        $result = implode('', $str);
        if ((int) $amount == 0) {
            return "Zero Rupees  " . $result . " only";
        } else {
            return "Rupees  " . $result . " only";
        }
    }

    public function getBillingInfo($payload) {
        $order_id = (int) $payload->OrderID;
        $filterpatient = array("billing.patientinfo.order_id" => $order_id);

        $cursor = $this->dbo->findOne("masters", "billing_info", $filterpatient, array(), array());
        // echo json_encode($filterpatient);exit;
        //print_r($cursor);exit;

        $response = array("countn" => "0", "itemlist" => "No Records found");
        if (!empty($cursor) and $cursor != null) {
            $response["countn"] = 1; //findOne

            $order_id = $cursor['billing']['patientinfo']['order_id'];
            $mrn = $cursor['billing']['patientinfo']['mrn'];
            $result = $cursor;
            //print_r($result);exit;
            //PENALTIES AND PENDING PAYMENTS FETCH FOR MRN
            $finance = new Finance;
            $pendingPayload = new stdclass;
            $pendingPayload->mrn = $mrn;
            $pendingResponse = $finance->getPenaltiesAndPendingPayments($pendingPayload);
            // print_r($pendingResponse);exit;
            $response['penalties_pendingpayments'] = $pendingResponse;

            $response["itemlist"] = $result;
            $response["itemlist"]['order_id'] = $order_id;
            $new_price = "0";

            $filter = array("_id" => $order_id);

            $cursor1 = $this->dbo->findOne("masters", "orders", $filter, array(), array());
            //echo json_encode($cursor1);exit;

            /* if (!empty($cursor1) and $cursor1!=null)
              {
              //$response["itemlist"]['orderitem'] = $cursor1['order']['orderitem'];
              for ($i = 0; $i < count($cursor1['order']['orderitem']); $i++)
              {
              if ($cursor1['order']['orderitem'][$i]['cancelbeforeaccept'] != "1" && $cursor1['order']['orderitem'][$i]['item_status'] == "8")
              {
              $new_price = (float) $new_price + (float) $cursor1['order']['orderitem'][$i]['net_amount'];
              }
              }
              $response["itemlist"]['drug_delivery_charge'] = isset($cursor1['order']['patientinfo']['medicine_delivery_charge']) ? $cursor1['order']['patientinfo']['medicine_delivery_charge'] : 0;
              } */
            $orderinfo = new Orderinfo;
            $penalty = $orderinfo->getAllPendingPaidDetails(array("order_id" => $order_id));
            $totalPenalty = (float) $penalty['PenaltiesPaid'] + (float) $penalty['PenaltiesPending'];
            //$due_amount = (float) $response["itemlist"]['billing']['billinginfo']['due_amount'];
            $response["itemlist"]['billing']['billinginfo']['orderPenaltyAmount'] = $totalPenalty;
            //$response["itemlist"]['billing']['billinginfo']['due_amount']=$due_amount+$totalPenalty;
            // print_r($due_amount);exit;
        }

        return $response;
    }

    public function twoDigitAfterPoint($digit) {
        //return number_format($digit,2,'.','');
        return round((double) $digit, 2);
    }

    public function invoice($orderid, $action = "Download") {
        $equipmentType = array("1" => "Rent", "2" => "Sale");
        $file_name = "";
        if (isset($orderid) && $orderid != "") {
            $project = array(
                "_id" => 1,
                "did" => 1,
                "order.patientinfo.mrn" => 1,
                "mode_of_service" => 1,
                "order.patientinfo.address" => 1,
                "order.patientinfo.contact" => 1,
                "order.patientinfo.name" => 1,
                "order.patientinfo.service_type" => 1,
                "OStatus" => 1,
                "odid" => 1,
                "billing.billing_did" => 1,
                "payment_info" => 1,
                "advance_receipt" => 1,
                "order.order_status.created_date" => 1,
                "order.orderitem" => 1,
                "order.provider_info" => 1,
            );
            $filter = array("_id" => (int) $orderid);
            $orderdetails = $this->dbo->findOne('masters', 'orders', $filter, $project);
            if (isset($orderdetails[_id])) {
				//return $orderdetails;
				
                $filterPenalties = array("order_id" => (int) $orderid, "type" => "PENALTY");
                $getPenalties = $this->dbo->find("masters", "orders_refund_penalties", $filterPenalties, array(), array());
                $PenaltyAmount = 0;
                foreach ($getPenalties as $eachPenalty) {
                    $PenaltyAmount = $PenaltyAmount + (float) $eachPenalty[amount];
                }

                $modeofservice = ModeOfService[$orderdetails[mode_of_service]];
                $voucher_amount = 0;
                $businessId = (int) $orderdetails[order][patientinfo][service_type];
                $gross_amount = $this->twoDigitAfterPoint(isset($orderdetails[payment_info][gross_amount]) ? $orderdetails[payment_info][gross_amount] : 0);
                $net_amount = $this->twoDigitAfterPoint(isset($orderdetails[payment_info][net_amount]) ? $orderdetails[payment_info][net_amount] : 0);
                //$discount_amount = (float)$gross_amount - (float)$net_amount;
                $wallet_amount = $this->twoDigitAfterPoint(isset($orderdetails[payment_info][wallet_amount]) ? $orderdetails[payment_info][wallet_amount] : 0);
                $coupon_amount = $this->twoDigitAfterPoint(isset($orderdetails[payment_info][coupon_amount]) ? $orderdetails[payment_info][coupon_amount] : 0);

                $paid_amount = $this->twoDigitAfterPoint(isset($orderdetails[payment_info][paid_amount]) ? $orderdetails[payment_info][paid_amount] : 0);
                $pending_amount = $this->twoDigitAfterPoint(isset($orderdetails[payment_info][payable_amount]) ? $orderdetails[payment_info][payable_amount] : 0);
                $coupon_code = isset($orderdetails[payment_info][coupon]) ? $orderdetails[payment_info][coupon] : "";
                $voucher_code = isset($orderdetails[payment_info][voucher_assoc_code]) ? $orderdetails[payment_info][voucher_assoc_code] : "";
                $billamount = $paid_amount;
                /* if($pending_amount<0){
                  $pending_amount = 0;
                  }else{
                  $billamount = $billamount + $pending_amount;
                  } */
                $billamount = $net_amount;

                /* $payment_amount = isset($orderdetails[payment_info][payment_amount]) ? (float) $orderdetails[payment_info][payment_amount] : 0; //prepaid
                  $bill_amount = ($net_amount) - ($wallet_amount + $voucher_amount + $coupon_amount);
                  $pending_amount = $bill_amount - $payment_amount; */

                $totalcolspan = 0;
                $status = (int) $orderdetails[OStatus];
                //print_r($status);exit;
                $billodid = isset($orderdetails[billing][billing_did]) ? $orderdetails[billing][billing_did] : "";
                $order_date = isset($orderdetails[order][order_status][created_date]) ? $orderdetails[order][order_status][created_date] : "";
                $order_date = date('Y-m-d h:i A', strtotime($order_date));
                //print_r("working");exit;
                $associateComponent = $this->config->business_to_ahelp_map($businessId);
                $component_key = array_column($orderdetails[order][provider_info], "component_no");
                $keyinProviderInfo = array_search($associateComponent, $component_key);
                $associate_name = isset($orderdetails[order][provider_info][$keyinProviderInfo][associate_name]) ? $orderdetails[order][provider_info][$keyinProviderInfo][associate_name] : "";
                $associate_address = isset($orderdetails[order][provider_info][$keyinProviderInfo][associate_address]) ? $orderdetails[order][provider_info][$keyinProviderInfo][associate_address] : "";

                if (trim($associate_name) == "" && ($businessId == 1 || $businessId == 10)) {
                    $associate_name = isset($orderdetails[order][provider_info][$keyinProviderInfo][officer_name]) ? $orderdetails[order][provider_info][$keyinProviderInfo][officer_name] : "";
                }

                if ($billodid == "" && $status != 6) {
                    $project_bill = array(
                        "_id" => 1,
                        "billing.patientinfo.order_id" => 1,
                        "billing.billinginfo.billingid" => 1,
                    );
                    $filter_bill = array("billing.patientinfo.order_id" => (int) $orderid);
                    $billdetails = $this->dbo->findOne('masters', 'billing_info', $filter_bill, $project_bill);
                    if (isset($billdetails[_id])) {
                        $billodid = $billdetails[billing][billinginfo][billingid];
                    }
                }

                if ($businessId == 2) {
                    //$pdf = new MYPDF_fordrug(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
                    $pdf = new MYPDF_fordrug(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'ISO-8859-1', false);
                } else {
                    //$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
                    $pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'ISO-8859-1', false);
                }
                $pdf->SetCreator(PDF_CREATOR);
                $pdf->SetAuthor('Callhealth');
                $pdf->SetTitle('invoice proforma cashmemo');
                $pdf->setPrintHeader(true);
                $pdf->setPrintFooter(true);
                $pdf->SetMargins(0, 36, 0);
                $pdf->SetAutoPageBreak(true, 45);
                $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
                $pdf->setLanguageArray($l);
                $pdf->AddPage();

                if ($businessId == 2) {
                    $headingimage = $this->urlpath . "/OMS/libraries/tcpdf/images/ch_images/cash_memo.png";
                    $file_name = "Cash Memo";
                } else if ($status == 6) {
                    $headingimage = $this->urlpath . "/OMS/libraries/tcpdf/images/ch_images/invoice.png";
                    $file_name = "Invoice";
                } else {
                    $headingimage = $this->urlpath . "/OMS/libraries/tcpdf/images/ch_images/proforma_inv.png";
                    $file_name = "Proforma Invoice";
                }

                $pdf->Image($headingimage, 0, 38, 35, 8, 'PNG', '', '', false, 300, '', false, false, 0, false, false, false);
                $grossamtinword = $this->amount_in_word(floor($billamount));
            }
            $serviceicon = $this->urlpath . '/OMS/libraries/tcpdf/images/ch_images/proforma_inv.png';

            //return $orderdetails;

            $html = '<table width="100%" cellpadding="1" cellspacing="0" class="table" border="0" style="color:#323232;">
            <tr>
                <td width="4%"></td>
                <td width="46%"></td>
                <td width="46%">
                    <table width="100%" cellpadding="2" border="0">
                        <tr>
                            <td align="left" width="70px" style="font-size:28px;">ORDER #</td>
                            <td align="left" style="font-size:28px;">' . $orderdetails[odid] . '</td>
                        </tr>';
            if ($status == 6) {
                $html = $html . '<tr>
                                <td align="left" style="font-size:28px;">INVOICE # </td>
                                <td align="left" style="font-size:28px;">' . $billodid . '</td>
                            </tr>';
            }
            $html = $html . '<tr>
                            <td align="left" style="font-size:28px;">DATE </td>
                            <td align="left" style="font-size:28px;">' . $order_date . '</td>
                        </tr>
                    </table>
                </td>
                <td width="4%"></td>
            </tr>
        </table>
        <table width="100%" cellpadding="1" cellspacing="0" class="table"  border="0" style="color:#323232;">
            <tr>
                <td width="4%"></td><td width="46%" style="font-size:30px;">';
            if ($status != 6) {
                $html = $html . '<br><br>';
            }
            $html = $html . 'To</td><td width="46%"></td><td width="4%"></td>
            </tr>
            <tr>
                <td width="4%"></td><td width="46%">
                    <table width="100%" cellpadding="2" border="0">
                        <tr>
                            <td align="left" width="20%" style="font-size:30px;">MRN # </td>
                            <td align="left" width="78%" style="font-size:30px;">' . $orderdetails[order][patientinfo][mrn] . '</td>
                        </tr>
                        <tr>
                            <td align="left" style="font-size:30px;">Name # </td>
                            <td align="left" style="font-size:30px;">' . ucfirst($orderdetails[order][patientinfo][name]) . '</td>
                        </tr>
                        <tr>
                            <td align="left" style="font-size:30px;">Address # </td>
                            <td align="left" style="font-size:30px;">' . ucfirst(trim($orderdetails[order][patientinfo][address])) . '</td>
                        </tr>
                        <tr>
                            <td align="left" style="font-size:30px;">Contact # </td>
                            <td align="left" style="font-size:30px;">' . $orderdetails[order][patientinfo][contact] . '<br></td>
                        </tr>
                    </table>
                </td>
                <td width="46%">
                    <table width="100%" cellpadding="2" border="0">
                        <tr>
                            <td align="left" width="100%" style="font-size:30px;">Bill Amount</td>
                        </tr>
                        <tr>
                            <td align="left" style="font-size:50px;">' . $billamount . ' </td>
                        </tr>
                        <tr>
                            <td align="left" style="font-size:30px;" colspan="2">Amount in Words<br>' . $grossamtinword . '</td>
                        </tr>
                    </table>
                </td>
                <td width="4%"></td>
            </tr>
            <tr>
                <td width="4%"></td>
                <td width="92%" colspan="2" style="font-size:30px; line-height:3px;"><hr><div><b>Service Provider Details</b></div>
                </td>
                <td width="4%"></td>
            </tr>
            <tr>
                <td width="4%"></td>
                <td width="46%">
                    <table>
                        <tr>
                            <td style="font-size:30px; padding-top:8px;">' . $associate_name . '</td>
                        </tr>
                        <tr>
                            <td style="font-size:30px; font-color:#DCDDDE;">' . $associate_address . '</td>
                        </tr>
                    </table>
                </td>
                <td width="46%">
                    <table width="100%" cellpadding="2" border="0">';
            if (isset($CIN) && $CIN != "") {
                $html = $html . '<tr>
                            <td align="left" width="20%" style="font-size:30px;">CIN # </td>
                            <td align="left" width="78%" style="font-size:30px;">12345ASE786</td>
                        </tr>';
            }
            if (isset($GST) && $GST != "") {
                $html = $html . '<tr>
                            <td align="left" width="20%" style="font-size:30px;">GST # </td>
                            <td align="left" width="78%" style="font-size:30px;">12345ASE786</td>
                        </tr>';
            }
            if (isset($Contact) && $Contact != "") {
                $html = $html . '<tr>
                            <td align="left" width="20%" style="font-size:30px;">Contact # </td>
                            <td align="left" width="78%" style="font-size:30px;">12345ASE786</td>
                        </tr>';
            }
            $html = $html . '</table>
                </td>
                <td width="4%"></td>
            </tr>
            <tr>
                <td width="4%"></td>
                <td width="92%" colspan="2">
                    <table border="0" width="100%" cellpadding="5" cellspacing="2" class="tablebor" style="background-color:#fff;">
                        <tr style="background-color:#878787; color:#fff;">
                        <th style="font-size:30px;" width="50" height="32">#</th>
                            <th style="font-size:30px;" width="100" height="32">Business</th>';
            if ($businessId == 1) {
                $html = $html . '<th style="font-size:30px;" width="182px" height="32">Service Name</th>
				<th style="font-size:30px;" height="32">Mode of Service</th>';
                $totalcolspan = 4;
            } else if ($businessId == 2) {
                $html = $html . '<th style="font-size:30px;" width="90px" height="32">Medicine Name</th>
				<th style="font-size:30px;" width="80px" height="32">Manufacturer</th>
				<th style="font-size:30px;" width="62px" height="32">Mode of Service</th>
				<th style="font-size:30px;" width="50px" height="32">Qty</th>';
                $totalcolspan = 6;
            } else if ($businessId == 3) {
                $html = $html . '<th style="font-size:30px;" width="282px" height="32">Service Name</th>';
                $totalcolspan = 3;
            } else if ($businessId == 4) {
                $html = $html . '<th style="font-size:30px;" width="282px" height="32">Service Name</th>';
                $totalcolspan = 3;
            } else if ($businessId == 5) {
                $html = $html . '<th style="font-size:30px;" width="170px" height="32">Service Name</th>
				<th style="font-size:30px;" width="50px" height="32">No of Session</th>
				<th style="font-size:30px;" width="62px" height="32">Mode of Service</th>';
                $totalcolspan = 5;
            } else if ($businessId == 6) {
                $html = $html . '<th style="font-size:30px;" width="170px" height="32">Service Name</th>
				<th style="font-size:30px;" width="50px" height="32">No of Session</th>
				<th style="font-size:30px;" width="62px" height="32">Mode of Service</th>';
                $totalcolspan = 5;
            } else if ($businessId == 7) {
                $html = $html . '<th style="font-size:30px;" width="170px" height="32">Service Name</th>
				<th style="font-size:30px;" width="50px" height="32">No of Session</th>
				<th style="font-size:30px;" width="62px" height="32">Mode of Service</th>';
                $totalcolspan = 5;
            } else if ($businessId == 8) {
                $html = $html . '<th style="font-size:30px;" width="170px" height="32">Service Name</th>
				<th style="font-size:30px;" width="50px" height="32">No of Session</th>
				<th style="font-size:30px;" width="62px" height="32">Mode of Service</th>';
                $totalcolspan = 5;
            } else if ($businessId == 11) {
                $html = $html . '<th style="font-size:30px;" width="165px" height="32">Service Name</th><th style="font-size:30px;" width="58px" height="32">Mode of Service</th><th style="font-size:30px;" width="58px" height="32">Service Type</th>';
                $totalcolspan = 5;
            } else if ($businessId == 14) {
                $html = $html . '<th style="font-size:30px;" width="200px" height="32">Service Name</th>
				<!--th style="font-size:30px;" width="170px" height="32">Service</th-->
				<th style="font-size:30px;" width="78px" height="32">Mode of Service</th>
				<!--th style="font-size:30px;" width="62px" height="32">Qty</th-->';
                $totalcolspan = 4;
            } else if ($businessId == 30) {
                $html = $html . '<th style="font-size:30px;" width="282px" height="32">Service Name </th>';
                $totalcolspan = 3;
            }
            $html = $html . '<th style="font-size:30px;" width="80" height="32">MRP</th>
			<th style="font-size:30px;" height="32" width="80">Discount</th>
			<th style="font-size:30px;" height="32" width="80">Total</th>
			</tr>';

            $i = 1;
            foreach ($orderdetails[order][orderitem] as $item) {
                //if ($item[item_status] != "8") {
                if ((int) $item[roleBasedService] == 1 && (int) $item[gross_amount] == 0) {
                    continue;
                }
                if ($i % 2 == 0) {
                    $html = $html . '<tr style="background-color:#ECECEC; color:#323232;">';
                } else if ($item[item_status] == "8") {
                    $html = $html . '<tr style="background-color:#FAB3B6; color:#323232;">';
                } else {
                    $html = $html . '<tr style="background-color:#F5F4F9; color:#323232;">';
                }
                $html = $html . '<td style="font-size:30px;">' . $i . '</td>
					<td style="font-size:30px;">' . $this->utility->getbusinessName($businessId) . '</td><td style="font-size:30px; color:#222222;">' . $item[itemname] . '</td>';

                if ($businessId == 1) {
                    $html = $html . '<th style="font-size:30px;">' . $modeofservice . '</th>';
                } else if ($businessId == 2) {
                    $html = $html . '<th style="font-size:30px;">' . $item[manufacturer] . '</th>
						<th style="font-size:30px;">' . $modeofservice . '</th>
						<th style="font-size:30px;">' . $item[quantity] . '</th>';
                } else if ($businessId == 5) {
                    $html = $html . '<th style="font-size:30px;">' . $modeofservice . '</th>
                        <th style="font-size:30px;">' . $item[quantity] . '</th>';
                } else if ($businessId == 6) {
                    $html = $html . '<th style="font-size:30px;">' . (isset($item[chsessions]) ? $item[chsessions] : "1") . '</th>
						<th style="font-size:30px;">' . $modeofservice . '</th>';
                } else if ($businessId == 7) {
                    $html = $html . '<th style="font-size:30px;">' . (isset($item[chsessions]) ? $item[chsessions] : "1") . '</th>
						<th style="font-size:30px;">' . $modeofservice . '</th>';
                } else if ($businessId == 8) {
                    $html = $html . '<th style="font-size:30px;">' . (isset($item[chsessions]) ? $item[chsessions] : "1") . '</th>
						<th style="font-size:30px;">' . $modeofservice . '</th>';
                } else if ($businessId == 14) {
                    $html = $html . '<th style="font-size:30px;">' . $modeofservice . '</th>
                        <!--th style="font-size:30px;">' . $item[quantity] . '</th-->';
                } else if ($businessId == 11) {
                    $html = $html . '<th style="font-size:30px;">' . $modeofservice . '</th><th style="font-size:30px;">' . (isset($item[type]) ? $equipmentType[$item[type]] : "") . '</th>';
                }

                $html = $html . '<td style="font-size:30px;">' . (($item[item_status] == "8") ? "" : $this->twoDigitAfterPoint($item[gross_amount])) . '</td>
					<td style="font-size:30px;">' . (($item[item_status] == "8") ? "" : $this->twoDigitAfterPoint($item[discount_amount])) . '</td>
					<td style="font-size:30px;">' . (($item[item_status] == "8") ? "" : $this->twoDigitAfterPoint($item[net_amount])) . '</td></tr>';
                $i = $i + 1;
                $voucher_amount = $voucher_amount + (float) $item[voucher_amount];
                //}
            }
            //$discount_amount = $gross_amount - ($wallet_amount+$coupon_amount+$voucher_amount+$net_amount);
            $discount_amount = $gross_amount - ($coupon_amount + $net_amount);
            $html = $html . '<tr style="background-color:#F5F4F9; color:#323232;" width="282px" height="32">
                            <td style="background-color:#fff;" colspan="' . $totalcolspan . '"></td>
                            <th style="font-size:28px;" colspan="2">Total Amount</th>
                            <td style="font-size:28px;">' . $this->twoDigitAfterPoint($gross_amount) . '</td>
                        </tr>
						<tr style="background-color:#F5F4F9; color:#323232;">';
            if ($coupon_amount > 0) {
                $html = $html . '<td style="font-size:28px;" colspan="' . $totalcolspan . '">Coupon Code : ' . $coupon_code . '</td>';
            } else {
                $html = $html . '<td style="background-color:#fff;" colspan="' . $totalcolspan . '"></td>';
            }
            $html = $html . '<th style="font-size:28px;" colspan="2">Applied Coupon Amount</th>
                            <td style="font-size:28px;">' . $this->twoDigitAfterPoint($coupon_amount) . '</td>
                        </tr>
                        <tr style="background-color:#F5F4F9; color:#323232;">
                            <td style="background-color:#fff;" colspan="' . $totalcolspan . '"></td>
                            <th style="font-size:28px;" colspan="2">Total Discount</th>
                            <td style="font-size:28px;">' . $this->twoDigitAfterPoint($discount_amount) . '</td>
                        </tr>
						<tr style="background-color:#F5F4F9; color:#323232;">
                            <td style="background-color:#fff;" colspan="' . $totalcolspan . '"></td>
                            <th style="font-size:28px;" colspan="2">Applied Wallet Amount</th>
                            <td style="font-size:28px;">' . $this->twoDigitAfterPoint($wallet_amount) . '</td>
                        </tr>

                        <tr style="background-color:#F5F4F9; color:#323232;">';
            if ($voucher_code > 0) {
                $html = $html . '<td style="font-size:28px;" colspan="' . $totalcolspan . '">Voucher Code : ' . $voucher_code . '</td>';
            } else {
                $html = $html . '<td style="background-color:#fff;" colspan="' . $totalcolspan . '"></td>';
            }
            $html = $html . '<th style="font-size:28px;" colspan="2">Applied Voucher Amount</th>
                            <td style="font-size:28px;">' . $this->twoDigitAfterPoint($voucher_amount) . '</td>
                        </tr>';
            //print_r($PenaltyAmount); exit;
            if ($PenaltyAmount != 0) {
                $html = $html . '<tr style="background-color:#F5F4F9; color:#323232;">
								<td style="background-color:#fff;" colspan="' . $totalcolspan . '"></td>
								<th style="font-size:28px;" colspan="2">Penalty Amount</th>
								<td style="font-size:28px;">' . $this->twoDigitAfterPoint($PenaltyAmount) . '</td>
							</tr>';
            }
            $html = $html . '<tr style="background-color:#F5F4F9; color:#323232;">
                            <td style="background-color:#fff;" colspan="' . $totalcolspan . '"></td>
                            <th style="font-size:28px;" colspan="2">Amount Paid</th>
                            <td style="font-size:28px;">' . $this->twoDigitAfterPoint($paid_amount) . '</td>
                        </tr>
                        <tr style="background-color:#F5F4F9; color:#323232;">
                            <td style="background-color:#fff;" colspan="' . $totalcolspan . '"></td>
                            <th style="font-size:28px;" colspan="2">Amount Pending</th>
                            <td style="font-size:28px;">' . $this->twoDigitAfterPoint($pending_amount) . '</td>
                        </tr>
                    </table>
                </td>
                <td width="4%"></td>
            </tr>
        </table>';
            //echo "<pre>";
            //print_r($html);exit;
            $pdf->writeHTML($html, true, false, true, false);
            //$pdf->Output('name.pdf', 'F');
            $invnum = $file_name . ' ' . $orderdetails[odid] . '.pdf';
            if ($action == "Download") {
                $pdf->Output($invnum, 'D');
            } else {
                $base64data = $pdf->Output($invnum, 'S');
                $conpdf = unpack('C*', $base64data);
                ini_set('memory_limit', '-1');
                $conpdf = array_values($conpdf);
                $b = json_encode($conpdf);
                //return $b;
            }
        } else {
            $project = array("test");
        }
        //return $project;
    }

    public function prescriptionprint($orderid, $action = "Download") {
        if (isset($orderid) && $orderid != "") {
            $project = array(
                "_id" => 1,
                "did" => 1,
                "order.patientinfo.mrn" => 1,
                "order.patientinfo.age" => 1,
                "order.patientinfo.gender" => 1,
                "order.patientinfo.address" => 1,
                "order.patientinfo.address" => 1,
                "order.patientinfo.landmark" => 1,
                "order.patientinfo.name" => 1,
                "order.patientinfo.service_type" => 1,
                "OStatus" => 1,
                "odid" => 1,
                "order.order_status.created_date" => 1,
                "order.orderitem" => 1,
                "order.provider_info" => 1,
            );
            $filter = array("_id" => (int) $orderid);
            $orderdetails = $this->dbo->findOne('masters', 'orders', $filter, $project);
            // print_r($orderdetails);exit;
            if ($orderdetails[_id]) {
                $mrn = $orderdetails[order][patientinfo][mrn];
                $name = $orderdetails[order][patientinfo][name];
                $gender = $orderdetails[order][patientinfo][gender];
                $age = $orderdetails[order][patientinfo][age];
                $address = $orderdetails[order][patientinfo][address];
                $landmark = isset($orderdetails[order][patientinfo][landmark]) ? $orderdetails[order][patientinfo][landmark] : "";
                $businessId = (int) $orderdetails[order][patientinfo][service_type];
                $business_name = $this->utility->getbusinessName($businessId);
                $ordereddate = $orderdetails[order][order_status][created_date];
                $odid = $orderdetails[odid];
                $contactno = $orderdetails[order][patientinfo][contact];
                $doctorname = $orderdetails[order][business][doctorName];
                $orderitemcount = count($orderdetails[order][orderitem]);
               // print_r($orderdetails[order][provider_info]);exit;

                if ($gender == "2") {
                    $gender = "Male";
                } elseif ($gender == "1") {
                    $gender = "Female";
                } elseif ($gender == "3") {
                    $gender = "Other";
                }
            }

            $pdf = new MYPDF_forPrescription(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'ISO-8859-1', false);
            $pdf->SetCreator(PDF_CREATOR);
            $pdf->SetAuthor('Callhealth');
            $pdf->SetTitle('Prescription');
            $pdf->setPrintHeader(true);
            $pdf->setPrintFooter(true);
            $pdf->SetMargins(5, 36, 5);
            $pdf->SetAutoPageBreak(true, 45);
            $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
            $pdf->setLanguageArray($l);
            $pdf->AddPage();

            $html = "";
            //  $html = '<table><tr><td><img src="' . $top_line_logo . '"></td></tr></table>';
            $html = $html . '<table><tr><td><div style="background-color: #304793;width:100%;float:left;padding-left:20px;margin-left:-20px;"><span style="text-align:center; font-size:50px; font-weight:bold; color:#fff;">' . $business_name . '</span></div></td></tr></table>';
            $html = $html . '<table><tr>';
            $html = $html . '<td style="font-size:34px;"><span width="70px"><b>PATIENT INFORMATION</b><br><b>Name :</b> ' . $name . '<br><b>MRN# :</b> ' . $mrn . '<br><b>Age :</b> ' . $age . '<br><b>Gender :</b> ' . $gender . '<br><b>Address :</b> ' . $address . '<br><b>Landmark :</b> ' . $landmark . '</span></td>';
            $html = $html . '<td style="font-size:34px;"><span width="70px"><b>ORDER INFORMATION</b><br><b>Order Date :</b> ' . $ordereddate . '<br><b>Order # :</b> ' . $odid . '<br><b>Contact No :</b> ' . $contactno . '</span> </td>';


            if ($businessId == "3" || $businessId == "4") {
                $key = array_search('7', array_column($orderdetails[order][provider_info], 'component_no'));//finding array having component no 7
                //echo $key;exit;
                $html = $html . '<td style="font-size:34px;"><span width="70px"><b>LABORATORY INFORMATION</b>
                          <br><b>Name :</b> ' . $orderdetails[order][provider_info][$key][associate_name] . '<br><b>Email :</b> ' . $orderdetails[order][provider_info][$key][email] . '<br><b>Contact :</b> ' . $orderdetails[order][provider_info][$key][contact_number] . '<br><b>Address :</b> ' . $orderdetails[order][provider_info][$key][associate_address] . '<br></span></td>'; 
                             
           } else {
               
                $html = $html . '<td style="font-size:34px;"><span width="70px"><b>DOCTOR INFORMATION</b>
                <br><b>Name :</b><br></td>';
            }
            $html = $html . '</tr><table><tr><td></td></tr></table><table><tr><td><hr></td></tr></table><br>';

            if ($business_name == "Care At Home" || $business_name == "Assessment Order") {
                $html = $html . '<table><tr><th><b>' . $business_name . '</b></th></tr><tr><td><hr></td></tr>';
                if ($orderitemcount > 0) {
                    for ($i = 0; $i < $orderitemcount; $i++) {
                        //$type = isset($orderdetails->order->orderitem[$i]->type) ? $orderdetails->order->orderitem[$i]->type : "N/A";
                        //$department = isset($orderdetails->order->orderitem[$i]->department) ? $orderdetails->order->orderitem[$i]->department : "N/A";
                        if ($businessId == "3") {
                            $dtype = "Lab";
                        } else if ($businessId == "4") {
                            $dtype = "Radiology";
                        }
                        $itemcode = isset($orderdetails[order][orderitem][$i][item_code]) ? $orderdetails[order][orderitem][$i][item_code] : "";
                        $itemname = isset($orderdetails[order][orderitem][$i][itemname]) ? $orderdetails[order][orderitem][$i][itemname] : "";
                        $sessions = isset($orderdetails[order][orderitem][$i][sessions]) ? $orderdetails[order][orderitem][$i][sessions] : "";
                        $html .= "<tr><td> " . $itemname . '(' . $sessions . ' sessions)' . "</td></tr>";
                    }
                }
            } else {
                $html = $html . '<table> <tr><th style="font-size:34px;"><b>S.No</b></th><th style="font-size:34px;"><b>Test Name</b></th></tr> <tr><td colspan="2"></td></tr>';
                $sno = 0;
                if ($orderitemcount > 0) {
                    for ($i = 0; $i < $orderitemcount; $i++) {
                        if ($orderdetails[order][orderitem][$i][item_status] != "8" && $orderdetails[order][orderitem][$i][component_no] == "7") {
                            $sno++;
                            $itemname = isset($orderdetails[order][orderitem][$i][itemname]) ? $orderdetails[order][orderitem][$i][itemname] : "N/A";
                            //echo $itemname;exit;
                            $html .= "<tr><td style='font-size:26px;'>" . $sno . "</td><td style='font-size:26px;'>" . $itemname . "</td></tr>";
                        }
                    }
                }
                $html = $html . '</table><hr>';
                $html = $html . '<table><tr><td style="font-size:34px;"><br><br><b>Order AOE(s)<br>Internal Comments:<br>Report Comments:</b></td></tr></table>';
                $html = $html . '<table><tr><td style="font-size:34px;"><br><br>Approved On: ' . date("Y-m-d h:i a") . '</td><td align="right"><br><br>' . $doctorname . '</td></tr></table>';
            }

            $html = $html . '<table><tr><td style="font-size:34px;"><br><br><br><br><span style="text-align:center; ">.....End of ' . $business_name . ' order.....</span></td></tr></table>';

//   echo "<pre>";
//print_r($html);exit;
            $pdf->writeHTML($html, true, false, true, false);
            $invnum = "Prescription.pdf";
            $pdf->Output($invnum, 'D');
        } else {
            $project = array("test");
        }
    }

    public function generateReceiptInfo($searchreq, $ticket) {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "generateReceiptInfo_start", json_encode($searchreq), (string) $ticket);
        try {
            $updation_obj = new Orderupdation;
            $set_order = array();
            //order_id CAN BE FOUND FROM BILLING_INFO
            //$order_id = $searchreq->order_id;
            //$updation_obj->generateBillingInfo_inbuild($order_id);

            $receiptidseq = $this->utility->getNextSequence("receipt_id");

            $yr = date('y');
            $receiptid = "R-000-" . $yr . "-" . $receiptidseq;
            $receiptdate = date("Y") . "-" . date("m") . "-" . date("d") . "T" . date("H") . ":" . date("i") . ":" . date("s") . ".000Z";

            $receiptamount = $searchreq->receiptamount;
            if ($receiptamount <= 0) {
                $response = array("response" => "0", "msg" => "Please enter a Valid amount.");
                echo json_encode($response);
                exit;
            }

            // $receipts_tracker_id = $searchreq->billingid;
            $paymentmode = strtolower($searchreq->paymentmode);
            $receipts_tracker_id = $searchreq->receipts_tracker_id;
            $referencenumber = $searchreq->referencenumber;
            $associate_id = $searchreq->associate_id;
            $associate_branch_id = $searchreq->branch_id;

            //for log
            $actionById = isset($searchreq->actionById) ? $searchreq->actionById : '';
            $actionByName = isset($searchreq->actionByName) ? $searchreq->actionByName : '';
            $latitude = isset($searchreq->latitude) ? $searchreq->latitude : '';
            $longitude = isset($searchreq->longitude) ? $searchreq->longitude : '';
            $source = isset($searchreq->source) ? $searchreq->source : 'mobile';

            //$orderlog=array("created_date"=>date("Y-m-d H:i:s"),"created_by"=>"MHO","action"=>"receipt genereted- #".$receiptid,"order_status"=>"5");

            $filterpatient = array("_id" => (int) $receipts_tracker_id);
            $cursor = $this->dbo->find("masters", "billing_info", $filterpatient, array(), array('_id' => -1));

            if ($this->dbo->countitem("masters", "billing_info", $filterpatient) > 0) {
                foreach ($cursor as $document) {
                    $billingid = $document['billing']['billinginfo']['billingid'];
                    $order_id = $document['billing']['billinginfo']['order_id'];
                    $dueamount = $document['billing']['billinginfo']['due_amount'];
                    $paid_amount = $document['billing']['billinginfo']['paid_amount'];
                    $service_type = $document['billing']['patientinfo']['service_type'];
                    $payable_amount = isset($document['billing']['billinginfo']['payable_amount']) ?
                            $document['billing']['billinginfo']['payable_amount'] :
                            $document['billing']['billinginfo']['due_amount'];
                    if ($service_type == "4" || $order_type == "childrad" || $order_type == "rad") {
                        $role = "Onsite Facilitator";
                    } else if ($service_type == "2") {
                        $role = "DDO";
                    } else {
                        $role = "MHO";
                    }

                    ///
                    $receiptinfo = $document['billing']['receiptinfo'];
                    ///
                }
                //$newdueamount=($dueamount-$receiptamount);
                //$newpaid_amount=($paid_amount+$receiptamount);
                $newdueamount = ((float) round($dueamount, 2) - (float) round($receiptamount, 2));
                $newdueamount = round($newdueamount, 2);
                ///
                $newpayableamount = $newdueamount;
                ///
                $newpaid_amount = ($paid_amount + $receiptamount);
                //echo $newpayableamount." ".$newdueamount." ".$newpaid_amount;exit;
            }

            $updation_obj->generateBillingInfo_inbuild($order_id);
            $filterpatient4 = array("_id" => (int) $order_id);
            $cursor4 = $this->dbo->find("masters", "orders", $filterpatient4, array(), array());

            foreach ($cursor4 as $document4) {
                $servicetypeid = $document4['order']['patientinfo']['service_type'];
                $wid = $document4['wid'];
                $wdid = $document4['wodid'];
                $order_type = isset($document4['order']['ordertype']) ? $document4['order']['ordertype'] : "";
                $facility_id = $document4['order']['patientinfo']['facility_id'];
                $popname = $document4['order']['patientinfo']['popname'];
            }
            if ($newdueamount >= 0) {

                $orderlog = array("created_date" => date("Y-m-d H:i:s"), "role" => $role, "order_status" => "5", "action" => "receipt generated", "actionById" => $actionById, "actionByName" => $actionByName, 'description' => 'source:' . $source . ',receiptid:#' . $receiptid . ',amount colleceted:' . $receiptamount, 'latitude' => $latitude, 'longitude' => $longitude, 'paymentmode' => $paymentmode, 'receiptamount' => $receiptamount, "wid" => $wid, "wodid" => $wdid, "facility_id" => $facility_id, "popname" => $popname);

                $receiptarray = array('receipt_id' => $receiptid, 'billing_id' => $billingid, 'associate_id' => $associate_id, 'associate_branch_id' => $associate_branch_id, 'receipt_amount' => $receiptamount, 'payment_mode' => $paymentmode, 'payment_ref_no' => $referencenumber, 'payment_collected' => 1, 'receipt_date' => $receiptdate, 'receipt_status' => 1, "processed" => "NP", 'mho_id' => $actionById, "mho_name" => $actionByName, 'submitted_to' => "0");
                ///
                if ($paymentmode == 'cash') {
                    $receiptarray['payment_submited'] = 0;
                    $receiptarray['payment_submitted'] = 0;
                    $receiptarray['payment_collected'] = 0;
                } else {
                    $receiptarray['payment_submited'] = 1;
                    $receiptarray['payment_submitted'] = 1;
                }
                ///

                $response = array("response" => "0", "msg" => "Operation Failed.");

                $filter = array('_id' => (int) $receipts_tracker_id);
                $push = array('billing.receiptinfo' => $receiptarray);
                $updatereceipt = $this->dbo->update("masters", "billing_info", $filter, array(), $push, array());

                if ($updatereceipt['nModified'] > 0) {
                    $filter = array('_id' => (int) $receipts_tracker_id);
                    $cursor = $this->dbo->findOne("masters", "billing_info", $filter, array(), array('_id' => -1));

                    //Check whether all payments are collected and submitted
                    $receiptinfo = $cursor['billing']['receiptinfo'];
                    $receiptflag = 1;
                    foreach ($receiptinfo as $info) {
                        if ($info[payment_collected] == 0 or $info[payment_submited] == 0) {
                            $receiptflag = 0;
                        }
                    }

                    $filter = array('_id' => (int) $receipts_tracker_id);
                    $set = array(
                        'billing.billinginfo.paid_amount' => (string) $newpaid_amount, 'billing.billinginfo.due_amount' => $newdueamount,
                        'billing.billinginfo.assignedto' => $actionById, 'billing.billinginfo.billing_status' => "1",
                        'billing.billinginfo.payable_amount' => $payable_amount,
                    );

                    if ($receiptflag == 1 and $newdueamount == 0) {
                        $set['billing.billinginfo.all_receipt_submitted'] = "1";
                        $set['billing.billinginfo.payment_status'] = "3";
                        $set['billing.billinginfo.billing_status'] = "3";
                        $set_order['billing.payment_status'] = "3";
                        $set_order['billing.billing_status'] = "3";
                    }

                    $options = array("multi" => true);
                    $updateamounts = $this->dbo->update("masters", "billing_info", $filter, $set, array(), $options);

                    //Update in update
                    $filter_order = array('order.order_status.receipts_tracker_id' => (int) $receipts_tracker_id);
                    $set_order["payment_info.paid_amount"] = (float) $newpaid_amount;
                    $set_order["payment_info.payable_amount"] = (float) $payable_amount;
                    $updateamounts_order = $this->dbo->update("masters", "order", $filter_order, $set_order, array(), $options);
                }

                if ($updatereceipt['ok'] == 1) {
                    $response = array("response" => "1", "msg" => "Receipt generated successfully", "receipt_id" => $receiptid);
                    //for log
                    $filter = array('order.order_status.receipts_tracker_id' => (int) $receipts_tracker_id);
                    $push = array('order_log' => $orderlog);
                    $result = $this->dbo->update("masters", "order_log", $filter, array(), $push, array());
                } else {
                    $response = array("response" => "0", "msg" => "Operation Failed.");
                }

                $this->log->create_log("", "", $this->getname(), "Execution", 200, "generateReceiptInfo_end", json_encode($response), (string) $ticket);
                return $response;
            } else {
                $response = array("status" => 0, "message" => "Action not possible,check due amount");
                $this->log->create_log("", "", $this->getname(), "Execution", 200, "generateReceiptInfo_end", json_encode($response), (string) $ticket);
                return $response;
            }
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_generateReceiptInfo", $e->getMessage(), (string) $ticket);
        }
    }

    public function getReceiptinfoByMhoID($payload) {
        $filter1 = array('$match' => array
                (
                "billing.receiptinfo.mho_id" => $payload->assignedto,
                "billing.receiptinfo.payment_mode" => array('$in' => array('Cash', 'cash', 'CASH', 0, "0", 100, "100")),
            //,"billing.billinginfo.payment_status" => array('$ne' => "3"),
            ),
        );

        $filter2 = array('$unwind' => array('path' => '$billing.receiptinfo'));

        $filter3 = array('$match' => array(
                "billing.receiptinfo.payment_collected" => 0,
                "billing.receiptinfo.mho_id" => $payload->assignedto,
                "billing.receiptinfo.payment_mode" => array(
                    '$in' => array('Cash', 'cash', 'CASH', 0, "0", 100, "100"),
                ),
            ),
        );
        $project = array('$project' => array("billing.receiptinfo" => 1, "billing.billinginfo" => 1, "billing.patientinfo" => 1));

        $pipeline = array($filter1, $filter2, $filter3, $project);
        //echo json_encode($pipeline);exit;

        $cursor = $this->dbo->aggregate("masters", "billing_info", $pipeline);
        //echo json_encode($cursor);exit;

        $response = array("countn" => "0", "itemlist" => "No Records found");

        if (count((array) $cursor) > 0) {
            $response["countn"] = count((array) $cursor);
            $itemlist = array();
            foreach ($cursor as $document) {
                //$receiptinfo =array();
                $receiptinfo = $document['billing']['receiptinfo'];
                //print_r($receiptinfo);exit;
                $receiptinfo['name'] = $document['billing']['patientinfo']['name'];
                $receiptinfo['businessID'] = $document['billing']['patientinfo']['service_type'];
                $receiptinfo['payment_status'] = $document['billing']['billinginfo']['payment_status'];
                $receiptinfo['receipt_tracker_id'] = $document['billing']['billinginfo']['receipts_tracker_id'];
                $receiptinfo['order_id'] = $document['billing']['billinginfo']['order_id'];
                $receiptinfo['order_did'] = $document['billing']['billinginfo']['order_did'];
                //$receiptinfo['submitted_to'] = "0";
                //$receiptinfo['name']=$document['billing']['patientinfo']['name'];
                //$result[] = $receiptinfo;
                //$result1[]=$result;
                array_push($itemlist, $receiptinfo);
            }
            $response["itemlist"] = $itemlist; //exit;
        }
        //echo json_encode($response);
        return $response;
    }

    //end of function

    public function getCashReceipts($payload, $ticket) {
        $filter = array(
            "billing.billinginfo.billing_status" => array('$ne' => 3),
            "billing.billinginfo.payment_status" => array('$ne' => 3),
            "billing.receiptinfo.payment_mode" => array('$in' => array("cash", "Cash", "CASH")),
        );

        if (isset($payload->associateId) && trim($payload->associateId) != "") {
            $filter["billing.receiptinfo.associate_id"] = (string) $payload->associateId;
        }
        if (isset($payload->associateBranchId) && trim($payload->associateBranchId) != "") {
            $filter["billing.receiptinfo.associate_branch_id"] = (string) $payload->associateBranchId;
        }

        //print_r($payload);exit;

        $enddate = date('Y-m-d', strtotime(date('Y-m-d', strtotime($payload->endDate)) . ' +1 days'));

        if (isset($payload->mrn)) {
            $filter["billing.patientinfo.mrn"] = $payload->mrn;
        } else if (isset($payload->order_did)) {
            $filter["billing.billinginfo.order_did"] = $payload->order_did;
        } else {
            if (empty($payload->startDate) || empty($payload->endDate)) {
                $response = array("status" => 0, "message" => "Please provide startDate and endDate.");
                return $response;
            }
            $filter["billing.billinginfo.billing_date"] = array('$gte' => $payload->startDate, '$lte' => $enddate);
        }

        if (isset($payload->skip) && isset($payload->limit)) {
            array_push($pipeline, array('$skip' => $payload->skip), array('$limit' => $payload->limit));
        }

        $lookup = array(
            "from" => "orders",
            "localField" => "billing.patientinfo.order_id",
            "foreignField" => "_id",
            "as" => "orderDetails",
        );

        $project = array(
            "billing.patientinfo.order_id" => 1,
            "billing.patientinfo.mrn" => 1,
            "billing.billinginfo" => 1,
            "billing.receiptinfo" => 1,
            "orderDetails.OStatus" => 1,
            "orderDetails.order.patientinfo.scheduled_date" => 1,
            "orderDetails.order.patientinfo.completed_time" => 1,
            "orderDetails.order.order_status.created_date" => 1,
        );

        $pipeline = array(
            array('$match' => $filter),
            array('$lookup' => $lookup),
            array('$project' => $project),
        );

        //echo json_encode($pipeline);exit;

        $cashReceipts = $this->dbo->aggregate("masters", "billing_info", $pipeline);

        if (!empty($cashReceipts)) {
            $response = array("status" => 1, "message" => "Receipts for order exists", "count" => count($cashReceipts), "data" => $cashReceipts);
            return $response;
        } else {
            $response = array("status" => 0, "message" => "Receipts for order not found", "data" => []);
            return $response;
        }
    }

    public function generateBill($searchreq, $ticket = 12345) {

        $this->log->create_log("", "", "finance", "Execution", 200, "generate bill", json_encode($searchreq), (string) $ticket);

        //GET NEXT BILLING_ID IN SEQUENCE
        $response = array("status" => "0", "message" => "Bill Creation Failed", "billing_id" => "");
        $billingidseq = $this->utility->getNextSequence("billing_id");
        $yr = date('dmy');
        $billingid = "B-" . $yr . "-" . $billingidseq;

        //Empty or No OrderId
        if ($searchreq->OrderID == "" || !isset($searchreq->OrderID)) {
            $response["message"] = "Order ID is missing";
            $this->log->create_log("", "", "finance", "Execution", 200, "generate bill end", json_encode($response), (string) $ticket);
            return $response;
        }

        //CHECK IF ORDER IS ALREADY BILLED
        $filterpatient_bill = array("billing.patientinfo.order_id" => (int) $searchreq->OrderID);
        $count_bill = $this->dbo->countitem('masters', 'billing_info', $filterpatient_bill);
        if ($count_bill > 0) {
            $response = array("status" => "1", "message" => "Bill Already exists for this order");
            $this->log->create_log("", "", "finance", "Execution", 200, "generate bill end", json_encode($response), (string) $ticket);
            return $response;
        }

        //IF NOT BILLED FIND THE ORDER AND CONSTRUCT BILLING_INFO
        $filterpatient = array("_id" => (int) $searchreq->OrderID);
        $cursor = $this->dbo->findOne('masters', 'orders', $filterpatient, array());
        if (!isset($cursor[_id])) {
            $response["message"] = "Invalid Order ID";
            $this->log->create_log("", "", "finance", "Execution", 200, "generate bill end", json_encode($response), (string) $ticket);
            return $response;
        }
        $is_invoiceto_set = 0;
        $gross_amount = 0;
        $net_amount = 0;
        $corporatePaidAmount = 0;
        $coupon_amount = 0;
        $voucher_amount = 0;
        $orderDiscount_amount = 0;
        $cartDiscount_amount = 0;
        $wallet_amount = 0;
        $paid_amount = 0;
        $penalty_amount = 0;
        $prepaid_amount = 0;
        $discount_amount = 0;
        $due_amount = 0;
        $refund_amount = 0;
        $processed = "NP";
        $bill_type = "OMS";
        $payment_status = "1";
        $billing_status = "1";
        $all_receipt_submitted = "0";
        $receiptinfo = array();
        $penaltyinfo = array();
        $refundinfo = array();
        $receipttrackerid = $cursor['order']['order_status']['receipts_tracker_id'];
        $mrn = $cursor['order']['patientinfo']['mrn'];
        $creation_type = $cursor['creation_type'];
        $scheduled_date = $cursor['order']['patientinfo']['scheduled_date'];
        $advance_receipt = $cursor['advance_receipt'];
        //advance_receipt
        if (count($advance_receipt) > 0) {
            $receiptinfo = $advance_receipt;
            foreach ($receiptinfo as $receipts) {
                if ($receipts["type"] == 2) {
                    continue;
                }

                $prepaid_amount = $prepaid_amount + (float) $receipts["receipt_amount"];
            }
        }

        //ADD AMOUNTS IN LINEITEMS
        $lineitems = $cursor['order']['orderitem'];

        foreach ($lineitems as $item) {
            //NOT CANCELLED
            if ($item['item_status'] != 8) {
                //print_r($lineitems); exit;
                if ($item['invoiceto'] == "2") {
                    $is_invoiceto_set = 1;
                    $bill_type = "CORPORATE";
                    $corporatePaidAmount += $item['net_amount'];
                }
                $gross_amount += $item['gross_amount'];
                $net_amount += $item['net_amount'];
                $coupon_amount += $item['coupon_amount'];
                $voucher_amount += $item['voucher_amount'];
                $orderDiscount_amount += $item['orderApportionedDiscountAmount'];
                $cartDiscount_amount += $item['cartDiscountApportionedAmount'];
                $lineDiscount_amount += $item['lineItemDiscountAmount'];
                $wallet_amount += $item['wallet_amount'];
            }
        }
        //print_r($lineitems); exit;
        //IHS BILLS ZERO GROSS ORDERS
        if ($gross_amount == 0) {
            if (isset($cursor['order']['patientinfo']['corporateid']) and $cursor['order']['patientinfo']['corporateid'] != "") {
                $response = array("status" => "1", "paymentRequired" => false, "message" => "Bill generation from IHS");
                //    return $response;
            } else {
                $response = array("status" => "1", "paymentRequired" => false, "message" => "Bill cannot be generated for cancelled order");
                //    return $response;
            }
        }

        $discount_amount = $cursor[payment_info][discount_amount];
        $markup_amount = $cursor[payment_info][markup_amount];
        $cli_amount = $cursor[payment_info][cli];
        $surge_amount = $cursor[payment_info][surge_amount];
        /* if (isset($cursor[payment_info][wallet_amount])) {
          $wallet_amount = $cursor[payment_info][wallet_amount];
          } */
        $payment_method = $cursor['order']['patientinfo']['payment_method'];
        $service_type = $cursor['order']['patientinfo']['service_type'];
        $name = $cursor['order']['patientinfo']['name'];
        $order_id = $cursor['order']['patientinfo']['order_id'];
        $mhoid = $cursor['order']['order_status']['assignedto'];
        $order_did = $cursor['order']['order_status']['order_did'];
        $loungeplace = isset($cursor['order']['patientinfo']['loungeplace']) ? $cursor['order']['patientinfo']['loungeplace'] : "";
        $loungeplaceid = isset($cursor['order']['patientinfo']['loungeplaceid']) ? $cursor['order']['patientinfo']['loungeplaceid'] : "";
        $billingdate = date("Y-m-d") . "T" . date("H:i:s") . ".000Z";
        $this->log->create_log("", "", "finance", "Execution", 200, "generate bill mid", json_encode($response), (string) $ticket);
        $patientinfo = array(
            "mrn" => $mrn,
            "name" => $name,
            "scheduled_date" => $scheduled_date,
            "service_type" => $service_type,
            "order_id" => $order_id,
            "source" => $bill_type,
            "loungeplaceid" => $loungeplaceid,
            "loungeplace" => $loungeplace,
        );

        $billinginfo = array(
            "billingid" => $billingid,
            "receipts_tracker_id" => $receipttrackerid,
            "assignedto" => $mhoid,
            "processed" => $processed,
            "all_receipt_submitted" => $all_receipt_submitted,
            "billing_date" => $billingdate,
            "order_id" => $order_id,
            "order_did" => $order_did,
            'payment_status' => $payment_status,
            'billing_status' => $billing_status,
            'corporatePaidAmount' => $corporatePaidAmount,
        );
        $due_amount = (float) $net_amount - ((float) $wallet_amount + (float) $prepaid_amount + (float) $corporatePaidAmount);
        //echo $due_amount;exit;

        /* Check due aamount is in minus then refund has to generate but
          if there is some penalty amount then penalty amount shoud be minus
          then also due amount is minus so refund has to generate. */
        //print_r($due_amount); exit;
        if ($due_amount < 0) {
            $refund_amount = -1 * $due_amount;
            if ($refund_amount > 0) {
                //Check penalties to be paid for the customer
                $penaltyPayload = new stdclass;
                $penaltyPayload->mrn = $mrn;
                $penaltyCursor = $this->getPenaltiesAndPendingPayments($penaltyPayload, $ticket);

                if ($penaltyCursor['response'] == 1) {
                    $remain_refundamt = $refund_amount;
                    $penalties = $penaltyCursor['data']['pendingPenalties'];
                    foreach ($penalties as $penalty) {
                        if (($remain_refundamt - $penalty['amount']) > 0) {
                            $remain_refundamt = $remain_refundamt - $penalty['amount'];
                            $penalty_amount += $penalty['amount'];
                            $penalty["penalty_id"] = (object) array('$id' => $penalty["_id"]->{'$id'});
                            $pay[] = (object) $penalty;
                        }
                    }
                    $payPayload->mrn = $mrn;
                    $payPayload->penalties = $pay;

                    //Call payPenaltiesAndPendingPayments to pay penalties from part of refund amount
                    $payResp = $this->payPenaltiesAndPendingPayments($payPayload, $ticket);
                    if ($payResp["response"] == 1) {
                        $refund_amount = $remain_refundamt;
                        $penaltyinfo = $pay;
                    } else {
                        $penalty_amount = 0;
                    }
                }
            }

            //UPDATE THE REFUND DETAILS
            if ($refund_amount > 0) {
                //Generate the refund
                $refundPayload = new stdclass;
                $refundPayload->orderId = $order_id;
                $refundPayload->refundAmount = $refund_amount;
                //$refundPayload->comment = "";  //CAN ADD COMMENT IF NEEDED
                $refundResp = $this->generateRefund($refundPayload, $ticket);
                //print_r($refundResp);exit;
                if ($refundResp["response"] == 1) {
                    $refundinfo[] = $refundResp["refundObj"];
                }
            }

            //AFTER ALL REFUNDS ARE GENERATED OR PAID AS PENALTIES DUE AMOUNT NEEDS TO BE ZERO
            $due_amount = 0;

            $billinginfo["all_receipt_submitted"] = "1";
            $billinginfo["payment_status"] = "3";
            $billinginfo["billing_status"] = "3";
        } else if ((float) $due_amount == 0) {
            $billinginfo["all_receipt_submitted"] = "1";
            $billinginfo["payment_status"] = "3";
            $billinginfo["billing_status"] = "3";
        }

        //$billinginfo["markup_amount"]=$markup_amount;
        $billinginfo["gross_amount"] = $gross_amount;
        $billinginfo["discount_amount"] = $gross_amount - $net_amount;
        $billinginfo["net_amount"] = $net_amount;
        $billinginfo["coupon_amount"] = $coupon_amount;
        $billinginfo["voucher_amount"] = $voucher_amount;
        $billinginfo["wallet_amount"] = $wallet_amount;
        $billinginfo["cli"] = $cli_amount;
        $billinginfo["surge_amount"] = $surge_amount;
        $billinginfo["due_amount"] = $due_amount;
        $billinginfo["adv_amount"] = $prepaid_amount;
        $billinginfo["paid_amount"] = $prepaid_amount;
        $billinginfo["submitted_amount"] = $prepaid_amount;
        $billinginfo["refund_amount"] = $refund_amount;
        $billinginfo["penalty_amount"] = $penalty_amount;
        $billinginfo["orderDiscount_amount"] = $orderDiscount_amount;
        $billinginfo["cartDiscount_amount"] = $cartDiscount_amount;
        $billinginfo["lineDiscount_amount"] = $lineDiscount_amount;

        $finalarray = array(
            "_id" => $receipttrackerid
            , "billing" => array(
                "patientinfo" => $patientinfo,
                "billinginfo" => $billinginfo,
                "receiptinfo" => $receiptinfo,
                "penaltyinfo" => $penaltyinfo,
                "refundinfo" => $refundinfo,
            ),
        );

        $ordfilter = array('_id' => (int) $order_id);
        $ordset = array(
            'billing.payment_status' => $payment_status,
            'billing.billing_status' => $billing_status,
            "billing.billing_did" => $billingid,
            "billing.billing_date" => $billingdate,
        );

        //ADD TO ORDER.ORDERSTATUS IF REFUND IS APPLICABLE
        if ($refund_amount > 0) {
            $ordset["order.order_status.refundApplicable"] = true;
        }

        $updateamounts = $this->dbo->update('masters', 'orders', $ordfilter, $ordset, array(), array());
        $inserted_id = $this->dbo->insert('masters', 'billing_info', $finalarray);

        if ($inserted_id) {
            $response = array("status" => "1", "message" => "Bill Generated Successfully", "billing_id" => $billingid);
        }
        $this->log->create_log("", "", "finance", "Execution", 200, "generate bill end", json_encode($response), (string) $ticket);
        return $response;
    }

    public function generateRefund($payload, $ticket) 
    {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "generateRefund_start", json_encode($payload), (string) $ticket);

        try {
            $orderId = (int) $payload->orderId;
            $refundAmount = (float) $payload->refundAmount;
            $reason = isset($payload->reason) ? $payload->reason : "";
            $actionById = isset($payload->actionById) ? $payload->actionById : "";
            $actionByName = isset($payload->actionByName) ? $payload->actionByName : "";
            $ticket_id = isset($payload->ticket_id) ? $payload->ticket_id : "";
			$sub_type = isset($payload->sub_type) ? $payload->sub_type : "";
            $filter = array("_id" => $orderId);
            $result = $this->dbo->findOne("masters", "orders", $filter, array());

            if (empty($result)) {
                $response = array("response" => 0, "message" => "Order not found to generate refund");
                $this->log->create_log("", "", $this->getname(), "Execution", 200, "generateRefund_end", json_encode($response), (string) $ticket);
                return $response;
            }

            $refundObj = array(
                "transaction_code" => $result['transaction_code'],
                "mrn" => $result['order']['patientinfo']['mrn'],
                "username" => $result['order']['patientinfo']['name'],
                "order_id" => $orderId,
                "odid" => $result['odid'],
                "action" => 1,
                "action_level" => 1,
                "amount" => $refundAmount,
                "status" => 1,
                "type" => 'REFUND',
				"sub_type" => $sub_type,
                "actionById" => $actionById,
                "actionByName" => $actionByName,
                "ticket_id" => $ticket_id,
                "reason" => $reason,
                "created_on" => $this->utility->getCurrentdatetime(),
                "log" => array(array(
                        "status" => "1",
                        "created_on" => $this->utility->getCurrenttime(),
                        "comments" => "refund initiated",
                    )),
            );
            //print_r($refundObj);exit;

            try {
                $insertResp = $this->dbo->insert('masters', 'orders_refund_penalties', $refundObj);

                if ($insertResp['ok'] == 1) {
                    $response = array("response" => 1, "message" => "Refund Inserted", "refundObj" => $refundObj);
                    $set['order.business.refundApplicable'] = true;
                    $filter = array('_id' => (int) $orderId);
                    $update = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multi" => true));
                } else {
                    $response = array("response" => 0, "message" => "Refund Insertion Failed");
                }

                $this->log->create_log("", "", $this->getname(), "Execution", 200, "generateRefund_end", json_encode($response), (string) $ticket);
                return $response;
            } catch (Exception $e) {
                $response = array("response" => 0, "QueryError" => $e->getMessage());
                $this->log->create_log("", "", $this->getname(), "Execution", 200, "generateRefund_Issue", json_encode($response), (string) $ticket);
                return $response;
            }
        } catch (Exception $e) {
            $response = array("response" => 0, "Error" => $e->getMessage());
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "generateRefund_Issue", json_encode($response), (string) $ticket);
            return $response;
        }
    }


    /* ----------------- For Airtel / Vodafone / Mpaisa ------- */

    // for airtel/ mpaisa and vodafone.
    public function getCashReceiptsByMhoID($payload, $ticket) {
        //$this->config->validate_omsapi_key();
        $chospl = [2,11];
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "getCashReceiptsByMhoID_start", json_encode($payload), (string) $ticket);
        if (empty($payload->OfficerID)) {
            $response = array("success" => 0, "code" => "10200", "message" => "Invalid Input, Required fields are missing");
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "getCashReceiptsByMhoID_result", json_encode($response), (string) $ticket);
            return $response;
        }
        $select = array(
            "billing.receiptinfo" => 1,
            "billing.billinginfo.receipts_tracker_id" => 1,
            "billing.patientinfo.name" => 1,
            "billing.patientinfo.service_type" => 1,
            "billing.billinginfo.order_did" => 1,
        );
        $filter = array(
            "billing.receiptinfo.mho_id" => $payload->OfficerID,
            "billing.receiptinfo.payment_submited" => array('$lt' => 1),
        );
        $filter2 = array(
            "billing.receiptinfo.mho_id" => $payload->OfficerID,
            "billing.receiptinfo.payment_submited" => array('$lt' => 1),
            "billing.receiptinfo.payment_mode" => array('$in' => array('Cash', 'cash', 'CASH')),
        );
        $pipeline = array(
            array('$match' => $filter),
            array('$unwind' => '$billing.receiptinfo'),
            array('$match' => $filter2),
        );
        //print_r($pipeline);exit;
        $cursor = $this->dbo->aggregate("masters", "billing_info", $pipeline);
        if (empty($cursor)) {
            $response = array("success" => 0, "code" => "10300", "message" => "No records found");
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "getCashReceiptsByMhoID_result", json_encode($response), (string) $ticket);
            return $response;
        }
        $count = 0;
        $itemlist = [];
        foreach ($cursor as $document) {
            $account_type = 'CHSPL';
            if(in_array((int)$document['billing']['patientinfo']['service_type'],$chospl)){
                $account_type = 'CHOSPL';
            }
            $receiptinfo = $document['billing']['receiptinfo'];
            $receiptinfos = array();
            $PAYMENT_TYPE = strtolower(trim($receiptinfo['payment_mode']));
            $count++;
            $receiptinfos['receipt_tracker_id'] = $document['billing']['billinginfo']['receipts_tracker_id'];
            $receiptinfos['receipt_id'] = $receiptinfo['receipt_id'];
            $receiptinfos['billing_id'] = $receiptinfo['billing_id'];
            $receiptinfos['receipt_amount'] = $receiptinfo['receipt_amount'];
            $receiptinfos['officer_id'] = $receiptinfo['mho_id'];
            $receiptinfos['officer_name'] = $receiptinfo['mho_name'];
            $receiptinfos['customer_name'] = $document['billing']['patientinfo']['name'];
            $receiptinfos['order_did'] = $document['billing']['billinginfo']['order_did'];
            $receiptinfos['account_type'] = $account_type;
            $itemlist[] = $receiptinfos;
        }
        $response = array("success" => 1, "code" => "10100", "message" => "Data fetch successfully", "data" => ["count" => $count, "itemlist" => $itemlist]);
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "getCashReceiptsByMhoID_result", json_encode($response), (string) $ticket);
        return $response;
    }

    // for airtel/ mpaisa and vodafone.
    public function updateReceiptsforMho($payload, $ticket) {
        $this->config->validate_omsapi_key();
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "thirdparty_updateReceiptsforMho_start", json_encode($payload), (string) $ticket);
        //source_name : Vodafone || Airtel

        if (empty($payload->source_name) || empty($payload->totalamount) || empty($payload->receipts) || !is_array($payload->receipts)) {
            $response = array("success" => 0, "code" => "10200", "message" => "Invalid Input, Required fields are missing");
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "thirdparty_updateReceiptsforMho_result", json_encode($response), (string) $ticket);
            return $response;
        }
        //"receipt_tracker_id": "_id","receipt_id": "receipt_id","authCode": "payment_ref_no","amt": "vodafone_amount"
        $checkcount = $checkamt = 0;

        //print_r($payload); exit;
        foreach ($payload->receipts as $field) {

            if (isset($field->receipt_tracker_id) && isset($field->receipt_id) && isset($field->authCode) && isset($field->amount)) {
                $checkamt += (float) $field->amount;
                $checkcount++;
            } else {
                $response = array("success" => 0, "code" => "10300", "message" => "Sorry, unable to proceed, Invalid receipts found");
                $this->log->create_log("", "", $this->getname(), "Execution", 200, "thirdparty_updateReceiptsforMho_result", json_encode($response), (string) $ticket);
                return $response;
            }
        }

        //print_r($checkamt); exit;
        if (floatval($checkamt) != floatval($payload->totalamount)) {
            $response = array("success" => 0, "code" => "10400", "message" => "Invalid amount, Calulated total and provided total is not equal");
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "thirdparty_updateReceiptsforMho_result", json_encode($response), (string) $ticket);
            return $response;
        }

        $updatedcount = 0;
        foreach ($payload->receipts as $field) {

            $submited_on = date("Y-m-d\TH:i:s") . ".000Z";
            $newsubmitted_amount = "0";
            $filterpatient = array("_id" => (int) $field->receipt_tracker_id);
            $document = $this->dbo->findOne("masters", "billing_info", $filterpatient, array());
            //print_r($cursor); exit;
            if (isset($document[_id])) {
                //}foreach ($cursor as $document) {
                //print_r($document);exit;
                $order_id = $document['billing']['patientinfo']['order_id'];
                $filter = array("_id" => (int) $order_id);
                $project = array("_id" => 1, "OStatus" => 1);
                $document4 = $this->dbo->findOne("masters", "order", $filter, $project, array());
                $order_status = isset($document4['OStatus']) ? $document4['OStatus'] : "";
                $updatecount = 0;
                $paymentStatus = 1;
                $all_receipt_submit = 0;
                $billingStatus = 1;
                $received_amount = 0;
                $activeReceiptAmount = 0;
                foreach ($document['billing']['receiptinfo'] as $documentreceipt) {
                    if ($documentreceipt["receipt_id"] == (string) $field->receipt_id) {
                        $activeReceiptAmount = (float) $documentreceipt["receipt_amount"];
                    }
                    if (strtolower($documentreceipt["payment_mode"]) == "cash") {
                        if ((int) $documentreceipt["payment_collected"] > 1 && (int) $documentreceipt["payment_submitted"] > 1) {
                            $received_amount = $received_amount + (float) $documentreceipt["receipt_amount"];
                        }
                    } else {
                        $received_amount = $received_amount + (float) $documentreceipt["receipt_amount"];
                    }
                }
                //print_r($activeReceiptAmount); exit;
                if ($activeReceiptAmount != (float) $field->amount && (int) $activeReceiptAmount != (int) $field->amount) {
                    continue;
                }
                //$submitted_amount = $document['billing']['billinginfo']['submitted_amount'];
                $to_be_paid_amount = (int) $document['billing']['billinginfo']['paid_amount'] + (float) $document['billing']['billinginfo']['due_amount'];
                $newreceived_amount = (float) $received_amount + (float) $field->amount;
                //print_r($newreceived_amount); exit;
                if ((int) $newreceived_amount < $to_be_paid_amount) {
                    $paymentStatus = 2;
                    $all_receipt_submit = 0;
                    $billingStatus = 1;
                } else if ((int) $newreceived_amount == $to_be_paid_amount) {
                    $paymentStatus = 3;
                    $all_receipt_submit = 1;
                    $billingStatus = 3;
                } else {
                    $paymentStatus = 1;
                    $all_receipt_submit = 0;
                    $billingStatus = 1;
                }
                if ($order_status == "8" || $order_status == 8) {
                    $billingStatus = 2;
                }

                $filter = array("_id" => (int) $field->receipt_tracker_id, "billing.receiptinfo.receipt_id" => $field->receipt_id);
                $set = array(
                    'billing.receiptinfo.$.submitted_to_ch' => (int) 0,
                    'billing.receiptinfo.$.payment_collected' => (int) 1,
                    'billing.receiptinfo.$.payment_submited' => (int) 1,
                    'billing.receiptinfo.$.submited_date' => $submited_on,
                    'billing.receiptinfo.$.pop_id' => $payload->source_name, //'Vodafone',
                    'billing.receiptinfo.$.pop_name' => $payload->source_name, //'Vodafone',
                    'billing.receiptinfo.$.payment_ref_no' => $field->authCode,
                    'billing.receiptinfo.$.lastc_ation_dateTime' => date('Y-m-d') . "T" . date('H:i:s') . ".000Z",
                    'billing.receiptinfo.$.submitted_to_thirdparty' => (int) 1,
                    'billing.receiptinfo.$.thirdparty_name' => strtolower(trim($payload->source_name)),
                    'billing.receiptinfo.$.thirdparty_datetime' => $this->utility->getCurrenttime(),
                    'billing.receiptinfo.$.thirdparty_reference_no' => $field->authCode,
                    //'billing.billinginfo.submitted_amount' => $newsubmitted_amount,
                    'billing.billinginfo.all_receipt_submitted' => $all_receipt_submit,
                    'billing.billinginfo.billing_status' => $billingStatus,
                    'billing.billinginfo.payment_status' => $paymentStatus,
                );
                if ($payload->source_name == 'Vodafone') {
                    $set['billing.receiptinfo.$.vodafone_amount'] = $field->amount;
                } else {
                    $set['billing.receiptinfo.$.airtel_amount'] = $field->amount;
                }
                //print_r($set);exit;
                $options = array("multi" => true);
                $update = $this->dbo->update("masters", "billing_info", $filter, $set, [], $options);
                //print_r($update);
                if ($update[ok] == 1 && $update[nModified] == 1) {

                    $updatecount = 1;
                    $orderlog = array(
                        "created_date" => date("Y-m-d H:i:s"),
                        "role" => $payload->source_name, //'Vodafone',
                        "order_status" => "22",
                        "action" => "Payment collected",
                        "actionById" => $payload->source_name, //'Vodafone',
                        "actionByName" => $payload->source_name, //'Vodafone',
                        'description' => "source:" . $payload->source_name . ",receipt id:#" . $field->receipt_id,
                            //"facility_id" => $facility_id,
                            //"popname" => $popname,
                    );

                    $filter = array('_id' => (int) $order_id);
                    $set = array(
                        'billing.payment_status' => $paymentStatus,
                        'billing.billing_status' => $billingStatus,
                    );
                    $options = array("multi" => true);
                    $result1 = $this->dbo->update("masters", "orders", $filter, $set, [], $options);

                    $filter = array('_id' => (int) $order_id);
                    $push = array('order_log' => $orderlog);
                    $result2 = $this->dbo->update("masters", "orderlog", $filter, [], $push, []);

                    //print_r($result1);
                    //print_r($result2);exit;
                    if ($result1[nModified] == 1 && $result2[nModified] == 1) {
                        $updatedcount = $updatedcount + 1;
                    }
                }
            }
        }
        //echo"not working";
        //print_r($updatedcount); exit;
        if ($checkcount == $updatedcount) {

            $response = array("success" => 1, "code" => "10100", "message" => "Updated Successfully");
        } else {
            if ($updatedcount > 0) {
                $response = array("success" => 0, "code" => "10500", "message" => "Partial Updation is done");
            } else {
                $response = array("success" => 0, "code" => "10600", "message" => "Unable to process your request");
            }
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "thirdparty_updateReceiptsforMho_result", json_encode($response), (string) $ticket);
        return $response;
    }

    /* ----------------- End For Airtel / Vodafone / Mpaisa ------- */

    public function getBillDetails($payload) {
        if (!empty($payload->order_id)) {
            $filter = array
                (
                "_id" => (int) $payload->order_id,
                    //"billing.billing_did"=>array('$exists'=>true)
            );

            $result = $this->dbo->findOne("masters", "orders", $filter, array());
            //print_r($result['billing']['billing_did']);exit;
            //echo json_encode($result);

            if (isset($result[billing][billing_did])) {
                $filter = array
                    (
                    "billing.billinginfo.order_id" => (int) $payload->order_id,
                );

                $result1 = $this->dbo->findOne("masters", "billing_info", $filter, array(), array());
                //print_r(count($result1));exit;

                if (count($result1) > 0) {
                    $response = array("status" => 1, "message" => "data found successfully", "data" => $result1);
                    return $response;
                } else {
                    $response = array("status" => 0, "message" => "data not found", "data" => []);
                    return $response;
                }
            } else {
                $filter = array("_id" => (int) $payload->order_id);
                $project = array("advance_receipt" => 1);

                $result2 = $this->dbo->findOne("masters", "orders", $filter, $project);
                //print_r(count($result2));exit;
                //print_r($result2); exit;
                if (count($result2) > 0) {
                    $response = array("status" => 1, "message" => "data found successfully", "data" => $result2);
                    return $response;
                } else {
                    $response = array("status" => 0, "message" => "data not found", "data" => []);
                    return $response;
                }
            }
        } else {
            $response = array("status" => 0, "message" => "Please provide order_id in request", "data" => []);
            return $response;
        }
    }

//end of function

    public function receiptDetails($paylod, $ticket) {
        $startDate = substr(date("c", strtotime(date('2018-12-01'))), 0, 19) . ".000Z";

        $match = array('$match' => array
                (
                "billing.receiptinfo.processed" => 'NP',
                "billing.receiptinfo.receipt_date" => array('$gte' => $startDate),
                "billing.receiptinfo.payment_mode" => array('$nin' => array("demand draft", "Demand Draft", "PaymentAdvance", "paymentadvance")),
                "billing.patientinfo.service_type" => array('$nin' => array("1", "2")),
            ),
        );
        $unwind = array('$unwind' => '$billing.receiptinfo');

        $match2 = array('$match' => array
                (
                "billing.receiptinfo.processed" => 'NP',
                "billing.receiptinfo.receipt_date" => array('$gte' => $startDate),
                "billing.receiptinfo.payment_mode" => array('$nin' => array("demand draft", "Demand Draft", "PaymentAdvance", "paymentadvance")),
                "billing.patientinfo.service_type" => array('$nin' => array("1", "2")),
                "billing.receiptinfo.payment_mode" => array('$nin' => array("cash", "Cash", "CASH")),
                "billing.receiptinfo.receipt_amount" => array('$nin' => array(0)),
            ),
        );

        $pipeline = array($match, $unwind, $match2);
        //echo json_encode($pipeline);exit;

        $cursor = $this->dbo->aggregate("masters", "billing_info", $pipeline);
        //echo json_encode($cursor);exit;
        //print_r($cursor);exit;
        //var_dump($cursor);exit;
        //echo $cursor->count();

        $filter2 = array();
        $cursor3 = $this->dbo->find("facilityMaster", "serviceids", $filter2, array(), array());

        $filter3 = array();
        $cursor2 = $this->dbo->find("facilityMaster", "facilityOU", $filter3, array(), array());

        //print_r($cursor2);exit;

        if (function_exists('openssl_random_pseudo_bytes') === true) {
            $data = openssl_random_pseudo_bytes(16);
            $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // set version to 0100
            $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // set bits 6-7 to 10
            $batch_id = vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
        }

        $current_date = date('Y-m-d H:i:s');
        //print_r($current_date);exit;
        if (count($cursor) > 0) {
            //echo "11111";exit;
            foreach ($cursor as $document) {
                $receipt_tracker_id = $document['_id'];
                if ($receipt_tracker_id != "") {
                    $service_type_code = "";
                    $service_type_name = "";
                    $SERVICE_TYPE_ID = "0";
                    $SERVICE_TYPE_ID = $document['billing']['patientinfo']['service_type'];
                    $service_subtype_id = $document['billing']['patientinfo']['service_subtype_id'];
                    //print_r($SERVICE_TYPE_ID);
                    $source = isset($document['billing']['patientinfo']['source']) ? $document['billing']['patientinfo']['source'] :
                            "";
                    //print_r($source);exit;
                    $Order_ID = $document['billing']['billinginfo']['order_id'];
                    $Order_DID = $document['billing']['billinginfo']['order_did'];
                    $mrn = $document['billing']['patientinfo']['mrn'];

                    $index = array_search($SERVICE_TYPE_ID, array_column($cursor3, '_id'));
                    //print_r($index);exit;
                    $service_type_code = $cursor3[$index]['SERVICE_TYPE_CODE'];
                    $service_type_name = $cursor3[$index]['SERVICE_TYPE_NAME'];

                    $FACILITY_ID = $document['billing']['patientinfo']['facility_id'];
                    //print_r($FACILITY_ID);exit;
                    $FACILITY_DID = $document['billing']['billinginfo']['facility_did'];
                    $CUSTOMER_CODE = null;
                    $TOTAL_GROSS_AMOUNT = $document['billing']['billinginfo']['gross_amount'];
                    $TOTAL_DISCOUNT_AMOUNT = isset($document['billing']['billinginfo']['discount_amount']) ? $document['billing']['billinginfo']['discount_amount'] : "0.00";
                    $TOTAL_NET_AMOUNT = $document['billing']['billinginfo']['net_amount'];

                    $OU_CODE = "";
                    $index1 = array_search($FACILITY_ID, array_column($cursor2, '_id'));
                    //print_r($index1);exit;
                    $OU_CODE = $cursor2[$index1]['ouinfo']['OU_CODE'];
                    //print_r($OU_CODE);exit;

                    $NEW_ServiceReceipt_Uploaded_on = $current_date . "." . rand(100, 999);
                    $NEW_ServiceReceipt_Process_Status = "TP";
                    $NEW_ServiceReceipt_Error_Desc = null;
                    $NEW_ServiceReceipt_Downloaded_on = "";
                    $RTM_BATCH_ID = $batch_id;
                    $BANK_NAME = null;
                    $PAYMENT_TYPE = null;
                    $BANK_CASH_CODE = null;
                    $BANK_CASH_CODE_VODAFONE = null;
                    $POP_ADMIN_ID = "";
                    if ($OU_CODE != "") {
                        $BANK_CASH_CODE = substr($OU_CODE, 0, 6) . substr($service_type_code, -2) . "-EZTAP";
                        $BANK_CASH_CODE_VODAFONE = substr($OU_CODE, 0, 6) . substr($service_type_code, -2) . "-ICICI";
                    }

                    //print_r($BANK_CASH_CODE);exit;
                    //$test_mrns = array("100384","100385","100004","100019","100788","100011","100133","100824","100822","100834");
                    //print_r(count($document['billing']['receiptinfo']));exit;
                    //echo "111111";exit;
                    $receipt_date = str_replace('T', ' ', $document['billing']['receiptinfo']['receipt_date']);
                    //print_r($receipt_date);exit;
                    $RECEIPT_DATE = str_replace('Z', '', $receipt_date);
                    $RECEIPT_AMOUNT = $document['billing']['receiptinfo']['receipt_amount'];
                    //print_r($RECEIPT_AMOUNT);exit;
                    $PAYMENT_TYPE = ucfirst($document['billing']['receiptinfo']['payment_mode']);
                    //print_r($PAYMENT_TYPE);exit;
                    $receipt_id = $document['billing']['receiptinfo']['receipt_id'];
                    $POP_ADMIN_ID = isset($document['billing']['receiptinfo']['pop_id']) ? $document['billing']['receiptinfo'][$i]['pop_id'] : "";
                    //print_r($POP_ADMIN_ID);exit;
                    $POP_ADMIN_NAME = isset($document['billing']['receiptinfo']['pop_name']) ? $document['billing']['receiptinfo']['pop_name'] : "";
                    //print_r($POP_ADMIN_NAME);exit;

                    if ($PAYMENT_TYPE != "Cash" && $PAYMENT_TYPE != "cash" && $PAYMENT_TYPE != "CASH") {
                        $PAYMENT_TYPE = "Card";
                        if ($FACILITY_ID != "" && $SERVICE_TYPE_ID != "0" && $SERVICE_TYPE_ID != "2" && $SERVICE_TYPE_ID != 2 && $SERVICE_TYPE_ID != 1 && $SERVICE_TYPE_ID != "1" && $FACILITY_DID != "" && $RECEIPT_AMOUNT > 0 && !in_array($mrn, $test_mrns)) {

                            if ($SERVICE_TYPE_ID == "30" || $SERVICE_TYPE_ID == 30) {
                                if ($service_subtype_id == "7" || $service_subtype_id == 7) {
                                    $service_type_code = "GEC";
                                    $service_type_name = "eConsultation";
                                    $SERVICE_TYPE_ID = "1";
                                }
                                if ($service_subtype_id == "201" || $service_subtype_id == 201 || $service_subtype_id == "103" || $service_subtype_id == 103) {
                                    $service_type_code = "GCH";
                                    $service_type_name = "Care@Home";
                                    $SERVICE_TYPE_ID = "5";
                                }
                            }
                            $result_data[] = array(
                                'SERVICE_TYPE_ID' => $SERVICE_TYPE_ID,
                                'SERVICE_TYPE_CODE' => $service_type_code,
                                'SERVICE_TYPE_NAME' => $service_type_name,
                                'FACILITY_ID' => $FACILITY_ID,
                                'FACILITY_DID' => $FACILITY_DID,
                                'CUSTOMER_CODE' => $CUSTOMER_CODE,
                                'COST_CENTER_CODE' => $service_type_code,
                                'TOTAL_RECEIPT_AMOUNT' => $RECEIPT_AMOUNT,
                                'RECEIPT_DATE' => $RECEIPT_DATE,
                                'NEW_ServiceReceipt_Uploaded_on' => $NEW_ServiceReceipt_Uploaded_on,
                                'NEW_ServiceReceipt_Process_Status' => $NEW_ServiceReceipt_Process_Status,
                                'NEW_ServiceReceipt_Error_Desc' => $NEW_ServiceReceipt_Error_Desc,
                                'NEW_ServiceReceipt_Downloaded_on' => $NEW_ServiceReceipt_Downloaded_on,
                                'RTM_BATCH_ID' => $RTM_BATCH_ID,
                                'BANK_NAME' => $BANK_NAME,
                                'PAYMENT_TYPE' => $PAYMENT_TYPE,
                                'BANK_CASH_CODE' => $BANK_CASH_CODE,
                                'receipt_tracker_id' => $receipt_tracker_id,
                                'receipt_id' => $receipt_id,
                                'POP_ADMIN_ID' => $POP_ADMIN_ID,
                                'Order_DID' => $Order_DID,
                            );
                        }
                    } else {
                        $PAYMENT_TYPE = "Card";
                        if ($FACILITY_ID != "" && $FACILITY_DID != "" && $RECEIPT_AMOUNT > 0 && !in_array($mrn, $test_mrns)) {
                            if ($SERVICE_TYPE_ID == "30" || $SERVICE_TYPE_ID == 30) {
                                if ($service_subtype_id == "7" || $service_subtype_id == 7) {
                                    $service_type_code = "GEC";
                                    $service_type_name = "eConsultation";
                                    $SERVICE_TYPE_ID = "1";
                                }
                                if ($service_subtype_id == "201" || $service_subtype_id == 201 || $service_subtype_id == "103" || $service_subtype_id == 103) {
                                    $service_type_code = "GCH";
                                    $service_type_name = "Care@Home";
                                    $SERVICE_TYPE_ID = "5";
                                }
                            }
                            $result_data[] = array(
                                'SERVICE_TYPE_ID' => $SERVICE_TYPE_ID,
                                'SERVICE_TYPE_CODE' => $service_type_code,
                                'SERVICE_TYPE_NAME' => $service_type_name,
                                'FACILITY_ID' => $FACILITY_ID,
                                'FACILITY_DID' => $FACILITY_DID,
                                'CUSTOMER_CODE' => $CUSTOMER_CODE,
                                'COST_CENTER_CODE' => $service_type_code,
                                'TOTAL_RECEIPT_AMOUNT' => $RECEIPT_AMOUNT,
                                'RECEIPT_DATE' => $RECEIPT_DATE,
                                'NEW_ServiceReceipt_Uploaded_on' => $NEW_ServiceReceipt_Uploaded_on,
                                'NEW_ServiceReceipt_Process_Status' => $NEW_ServiceReceipt_Process_Status,
                                'NEW_ServiceReceipt_Error_Desc' => $NEW_ServiceReceipt_Error_Desc,
                                'NEW_ServiceReceipt_Downloaded_on' => $NEW_ServiceReceipt_Downloaded_on,
                                'RTM_BATCH_ID' => $RTM_BATCH_ID,
                                'BANK_NAME' => $BANK_NAME,
                                'PAYMENT_TYPE' => $PAYMENT_TYPE,
                                'BANK_CASH_CODE' => $BANK_CASH_CODE,
                                'receipt_tracker_id' => $receipt_tracker_id,
                                'receipt_id' => $receipt_id,
                                'POP_ADMIN_ID' => $POP_ADMIN_ID,
                                'Order_DID' => $Order_DID,
                            );
                        }
                        //print_r($result_data);exit;
                    }
                    if ($POP_ADMIN_ID == 'Vodafone') {
                        $BANK_CASH_CODE = $BANK_CASH_CODE_VODAFONE;
                    } else {
                        $BANK_CASH_CODE = null;
                    }

                    if ($SERVICE_TYPE_ID == "30" || $SERVICE_TYPE_ID == 30) {
                        if ($service_subtype_id == "7" || $service_subtype_id == 7) {
                            $service_type_code = "GEC";
                            $service_type_name = "eConsultation";
                            $SERVICE_TYPE_ID = "1";
                        }
                        if ($service_subtype_id == "201" || $service_subtype_id == 201 || $service_subtype_id == "103" || $service_subtype_id == 103) {
                            $service_type_code = "GCH";
                            $service_type_name = "Care@Home";
                            $SERVICE_TYPE_ID = "5";
                        }
                    }

                    $result_data[] = array(
                        'SERVICE_TYPE_ID' => $SERVICE_TYPE_ID,
                        'SERVICE_TYPE_CODE' => $service_type_code,
                        'SERVICE_TYPE_NAME' => $service_type_name,
                        'FACILITY_ID' => $FACILITY_ID,
                        'FACILITY_DID' => $FACILITY_DID,
                        'CUSTOMER_CODE' => $CUSTOMER_CODE,
                        'COST_CENTER_CODE' => $service_type_code,
                        'TOTAL_RECEIPT_AMOUNT' => $RECEIPT_AMOUNT,
                        'RECEIPT_DATE' => $RECEIPT_DATE,
                        'NEW_ServiceReceipt_Uploaded_on' => $NEW_ServiceReceipt_Uploaded_on,
                        'NEW_ServiceReceipt_Process_Status' => $NEW_ServiceReceipt_Process_Status,
                        'NEW_ServiceReceipt_Error_Desc' => $NEW_ServiceReceipt_Error_Desc,
                        'NEW_ServiceReceipt_Downloaded_on' => $NEW_ServiceReceipt_Downloaded_on,
                        'RTM_BATCH_ID' => $RTM_BATCH_ID,
                        'BANK_NAME' => $BANK_NAME,
                        'PAYMENT_TYPE' => $PAYMENT_TYPE,
                        'BANK_CASH_CODE' => $BANK_CASH_CODE,
                        'receipt_tracker_id' => $receipt_tracker_id,
                        'receipt_id' => $receipt_id,
                        'POP_ADMIN_ID' => $POP_ADMIN_ID,
                        'Order_DID' => $Order_DID,
                    );
                } //end of second if stmt.
            } //end of main foreach loop
        } //end of first if stmt.
        //echo json_encode($result_data); exit;
        /* ?>
          <table>
          <tr>
          <td>Receipt id</td>
          <td>Receipt Date</td>
          <td>Receipt AMount</td>
          <td>Payment Mode</td>
          <td>Faciity DID</td>
          <td>Service Type</td>
          <td>Uploaded ON</td>
          </tr>
          <?php for ($k=0; $k<count($result_data); $k++){ ?>
          <tr>
          <td><?php echo $result_data[$k]['receipt_id'];?></td>
          <td><?php echo $result_data[$k]['RECEIPT_DATE'];?></td>
          <td><?php echo $result_data[$k]['TOTAL_RECEIPT_AMOUNT'];?></td>
          <td><?php echo $result_data[$k]['PAYMENT_TYPE'];?></td>
          <td><?php echo $result_data[$k]['FACILITY_DID'];?></td>
          <td><?php echo $result_data[$k]['SERVICE_TYPE_ID'];?></td>
          <td><?php echo $result_data[$k]['NEW_ServiceReceipt_Uploaded_on'];?></td>
          </tr>
          <?php } ?>
          </table>
          <?php
          exit; */
        //echo odbc_error($connect);

        $connect = odbc_connect("INTDB", "ordmgnt", "CallHealth@1234");
        for ($k = 0; $k < count($result_data); $k++) {
            //echo "111";exit;
            if ($result_data[$k]['receipt_tracker_id'] != "" && $result_data[$k]['FACILITY_ID'] != "") {
                //echo "1111";exit;
                $result_data[$k]['SERVICE_TYPE_NAME'] = null;
                //$result_data[$k]['BANK_CASH_CODE']=NULL;
                //$result_data[$k]['PAYMENT_TYPE']="Cash";

                if ($result_data[$k]['PAYMENT_TYPE'] != "Card" && $result_data[$k]['POP_ADMIN_ID'] != "Vodafone") {
                    echo $query = "INSERT INTO RTM_T_MEDI_SERVICE_RECEIPT (SERVICE_TYPE_ID,SERVICE_TYPE_CODE,SERVICE_TYPE_NAME,FACILITY_ID,FACILITY_DID,CUSTOMER_CODE,COST_CENTER_CODE,TOTAL_RECEIPT_AMOUNT,RECEIPT_DATE,NEW_ServiceReceipt_Uploaded_on,NEW_ServiceReceipt_Process_Status,NEW_ServiceReceipt_Error_Desc,NEW_ServiceReceipt_Downloaded_on,RTM_BATCH_ID,BANK_NAME,PAYMENT_TYPE,BANK_CASH_CODE,ORDER_NO) VALUES (" . $result_data[$k]['SERVICE_TYPE_ID'] . ",'" . $result_data[$k]['SERVICE_TYPE_CODE'] . "',NULL," . $result_data[$k]['FACILITY_ID'] . ",'" . $result_data[$k]['FACILITY_DID'] . "',NULL,'" . $result_data[$k]['COST_CENTER_CODE'] . "'," . $result_data[$k]['TOTAL_RECEIPT_AMOUNT'] . ",'" . $result_data[$k]['RECEIPT_DATE'] . "','" . $result_data[$k]['NEW_ServiceReceipt_Uploaded_on'] . "','" . $result_data[$k]['NEW_ServiceReceipt_Process_Status'] . "',NULL,'" . $result_data[$k]['NEW_ServiceReceipt_Downloaded_on'] . "',NULL,NULL,'" . $result_data[$k]['PAYMENT_TYPE'] . "',NULL,'" . $result_data[$k]['Order_DID'] . "')";
                } else {
                    echo $query = "INSERT INTO RTM_T_MEDI_SERVICE_RECEIPT (SERVICE_TYPE_ID,SERVICE_TYPE_CODE,SERVICE_TYPE_NAME,FACILITY_ID,FACILITY_DID,CUSTOMER_CODE,COST_CENTER_CODE,TOTAL_RECEIPT_AMOUNT,RECEIPT_DATE,NEW_ServiceReceipt_Uploaded_on,NEW_ServiceReceipt_Process_Status,NEW_ServiceReceipt_Error_Desc,NEW_ServiceReceipt_Downloaded_on,RTM_BATCH_ID,BANK_NAME,PAYMENT_TYPE,BANK_CASH_CODE,ORDER_NO) VALUES (" . $result_data[$k]['SERVICE_TYPE_ID'] . ",'" . $result_data[$k]['SERVICE_TYPE_CODE'] . "',NULL," . $result_data[$k]['FACILITY_ID'] . ",'" . $result_data[$k]['FACILITY_DID'] . "',NULL,'" . $result_data[$k]['COST_CENTER_CODE'] . "'," . $result_data[$k]['TOTAL_RECEIPT_AMOUNT'] . ",'" . $result_data[$k]['RECEIPT_DATE'] . "','" . $result_data[$k]['NEW_ServiceReceipt_Uploaded_on'] . "','" . $result_data[$k]['NEW_ServiceReceipt_Process_Status'] . "',NULL,'" . $result_data[$k]['NEW_ServiceReceipt_Downloaded_on'] . "',NULL,NULL,'" . $result_data[$k]['PAYMENT_TYPE'] . "','" . $result_data[$k]['BANK_CASH_CODE'] . "','" . $result_data[$k]['Order_DID'] . "')";
                }

                $result = odbc_exec($connect, $query);
                if ($result) {
                    $filter4 = array("_id" => (int) $result_data[$k]['receipt_tracker_id']);
                    $cursor1 = $this->dbo->find("masters", "billing_info", $filter4, array(), array());
                    if (count($cursor1) > 0) {
                        foreach ($cursor1 as $document1) {
                            $j = 0;
                            foreach ($document1["billing"]["receiptinfo"] as $receipts) {
                                $filter5 = array('billing.receiptinfo.' . $j . '.receipt_id' => $result_data[$k]['receipt_id']);
                                $set = array('$set' => array('billing.receiptinfo.' . $j . '.processed' => 'P'
                                        , 'billing.receiptinfo.' . $j . '.ramco_flag' => $flag_time));
                                $options = array("multi" => true);
                                $update = $this->dbo->update("masters", "billing_info", $filter5, $set, array(), $options);
                            }
                        }
                    }
                    echo $query;
                    print_R($update);
                } else {
                    echo "Query failed " . odbc_error();
                }
                //exit;
            }
        }
        odbc_close($connect);
    }

//end of function
    //added by pandu

    public function payPenaltiesAndPendingPayments($payload, $ticket) {

        $this->log->create_log("", "", "finance", "Execution", 200, "payPenaltiesAndPendingPayments_start", json_encode($payload), (string) $ticket);

        if (!isset($payload->mrn) or $payload->mrn == "") {
            $response = array("response" => 0, "message" => "Invalid or No mrn");
            return $response;
        }

        $response = array("response" => 1, "message" => "Success");

        $mrn = $payload->mrn;

        $penalties = $payload->penalties;
        $pendingPayments = $payload->pendingPayments;

        if (($penalties == null or empty($penalties)) and ( $pendingPayments == null or empty($pendingPayments))) {
            $response = array("response" => 0, "message" => "Need atleast one of penalty or pendingPayments");
            return $response;
        }

        $amounts = array();
        $pendingOrderIds = array();
        $penaltyOrderIds = array();
        $penaltyOrderMap = array();
        $trCodes = array();

        $penaltyAmounts = array();
        $pendingAmounts = array();

        if (isset($payload->penalties)) {
            //PENALTIES
            $penaltyIds = array();
            $actionLevel = array();

            foreach ($penalties as $eachPenalty) {
                $penaltyOrderMap[(int) $eachPenalty->order_id] = is_object($eachPenalty->penalty_id) ?
                        $eachPenalty->penalty_id->{'$id'} : $eachPenalty->penalty_id;
                $penaltyIds[] = $eachPenalty->penalty_id;
                $actionLevel[(int) $eachPenalty->order_id] = $eachPenalty->action_level;
                $penaltyOrderIds[] = $eachPenalty->order_id;
                //$amounts[(int) $eachPenalty->order_id] += (float)$eachPenalty->amount;
                $penaltyAmounts[(int) $eachPenalty->order_id] += (float) $eachPenalty->amount;
            }

            //MAKE MONGO OBJECT IDS FROM FETCHED STD CLASS OBJECTS
            foreach ($penaltyIds as $pid) {
                $str = '$id';
                //print_r($pid->{$str});exit;
                if (!is_object($pid)) {

                    $ids[] = new MongoId($pid);
                } else {

                    $ids[] = new MongoId($pid->{$str});
                }
            }
            //print_r($ids);exit;
            //IF empty array
            if (empty($penaltyIds)) {
                $response['penalties'] = array("response" => 0, "message" => "No Penalties Received");
            } else {
                //$receiptOrders['penalties'] = $amounts;

                $filter = array("_id" => array('$in' => $ids), "mrn" => (int) $mrn, "type" => "PENALTY");
                $set = array("status" => 5);
                $options = array("multiple" => true);

                try {

                    //echo json_encode($filter);

                    $penaltyCursor = $this->dbo->update('masters', 'orders_refund_penalties', $filter, $set, array(), $options);
                    //print_r($penaltyCursor);exit;
                    $response['penalties'] = array("response" => 1, "message" => $penaltyCursor['updatedExisting'] . " Penalties Updated");
                } catch (Exception $e) {
                    $response = array('response' => 0, 'message' => 'QueryError: ' . $e->getMessage());
                    return $response;
                }
            }
        }

        if (isset($payload->pendingPayments)) {
            //PENDING PAYMENTS

            foreach ($pendingPayments as $eachPayment) {
                $pendingOrderIds[] = (int) $eachPayment->order_id;
                //$amounts[(int) $eachPayment->order_id] += (float)$eachPayment->payable_amount;
                $pendingAmounts[(int) $eachPayment->order_id] = (float) $eachPayment->payable_amount;
            }
        }

        //GENERATE Receipt FOR ALL THE AMOUNT Received AGAINST CORRESPONDING ORDERS
        $oids = array_unique(array_merge($penaltyOrderIds, $pendingOrderIds));
        //$oids = array_keys($amounts);

        $billfilter = array("_id" => array('$in' => $oids));
        $billproject = array("_id" => 1, "order.order_status.receipts_tracker_id" => 1, "transaction_code" => 1);

        $billcursor = $this->dbo->find('masters', 'orders', $billfilter, $billproject);

        $penaltyTransactions = array();
        foreach ($billcursor as $each) {
            $billingid[$each[_id]] = $each[order][order_status][receipts_tracker_id];
            $trCodes[] = $each['transaction_code'];

            $eachTran = array();
            $eachTran["order_id"] = $each[_id];
            $eachTran["transaction_code"] = $each[transaction_code];
            if (isset($actionLevel[(int) $each[_id]])) {
                $eachTran["action_level"] = $actionLevel[(int) $each[_id]]; //ONLY AVAILABLE FOR PENALTIES
            }
            array_push($penaltyTransactions, $eachTran);
        }
        //print_r($payload);exit;
        //STRUCTURE RECEIPTS
        $payloads = array();
        foreach ($penaltyOrderIds as $oid) {
            $buff = array();
            $buff["receiptamount"] = $penaltyAmounts[$oid];
            $buff["referencenumber"] = (string) $payload->payment_reference_id; //YET TO FETCH
            $buff["paymentmode"] = (string) $payload->payment_code; //YET TO FETCH
            $buff["order_id"] = $oid;
            $buff["actionById"] = (isset($payload->createdById)) ? (string) $payload->createdById : 0;
            $buff["actionByName"] = (isset($payload->createdByName)) ? (string) $payload->createdByName : "";

            $buff["associate_id"] = (isset($payload->associateId)) ? (string) $payload->associateId : 0;
            $buff["branch_id"] = (isset($payload->associateBranchId)) ? (string) $payload->associateBranchId : "";
            $buff["source"] = (isset($payload->createdByRole)) ? (string) $payload->createdByRole : "CP";
            //latitude and longitude fields can also be added for generateReceiptInfo

            $buff["penalty_id"] = $penaltyOrderMap[(int) $oid];
            $buff["type"] = 2;

            $payloads[] = $buff;
        }

        foreach ($pendingOrderIds as $oid) {
            $buff = array();
            $buff["receiptamount"] = $pendingAmounts[$oid];
            $buff["referencenumber"] = (string) $payload->payment_reference_id; //YET TO FETCH
            $buff["paymentmode"] = (string) $payload->payment_code; //YET TO FETCH
            $buff["order_id"] = $oid;
            $buff["actionById"] = (isset($payload->createdById)) ? (string) $payload->createdById : 0;
            $buff["actionByName"] = (isset($payload->createdByName)) ? (string) $payload->createdByName : "";

            $buff["associate_id"] = (isset($payload->associateId)) ? (string) $payload->associateId : 0;
            $buff["branch_id"] = (isset($payload->associateBranchId)) ? (string) $payload->associateBranchId : "";
            $buff["source"] = (isset($payload->createdByRole)) ? (string) $payload->createdByRole : "CP";
            //latitude and longitude fields can also be added for generateReceiptInfo

            $payloads[] = $buff;
        }
        //print_r($payloads);exit;
        //RECEIPT GENERATIONS FOR ALL AMOUNTS RECEIVED
        $response['receiptGeneration'] = array();
        foreach ($payloads as $eachPayload) {
            //print_r($eachPayload);exit;
            $output = $this->generateReceipt((object) $eachPayload, $ticket);
            $response['receiptGeneration'][] = $output;
        }

        //CALL STATUS CHANGE FOR ORDERS WITH PENDING PAYMENTS BECAUSE IT NEEDS PAYABLE_AMOUNT TO BE ZERO WHICH IS POSSIBLE ONLY AFTER GENERATE RECEIPT API CALL
        if (!empty($pendingOrderIds)) {
            $statusPayload = array(
                "order_id" => $pendingOrderIds,
                "actionById" => "OMS123",
                "actionByName" => "OMS",
                "source" => "CP",
                "status" => 6, // COMPLETE THE ORDER
                "reasonType" => "1",
                "comment" => "Pending payment done",
                "reason" => "Pending payment done",
            );

            ///
            //FUNCTION CALL
            //$statusresponse = $this->OrderWorkFlow->change_order_status($statusPayload,$ticket);
            //API CALL

            $sub_url = 'OMS/api/operation.php/v1/order/change/status';
            $url = $this->config->getconfig("serverurl", $sub_url);

            $statusPayload = json_encode($statusPayload);
            //echo $url." ".$statusPayload;exit;

            $statusresponse = $this->utility->my_curl($url, 'POST', $statusPayload, 'json', null, 10);
            //print_r($statusresponse);exit;
            ///

            $response['pendingPayments'] = array("response" => 1, "message" => "Pending payments received", "statusResponse" => $statusresponse);
        }
        $response['penaltyTransactions'] = $penaltyTransactions;
        $response["transaction"] = $trCodes;

        return $response;
    }

    public function getPenaltiesAndPendingPayments($payload, $ticket) {
        if (!isset($payload->mrn) or $payload->mrn == "") {
            $response = array("response" => 0, "message" => "Invalid or No mrn");
            return $response;
        }
        $response = array("response" => 1, "message" => "Success");
        $mrn = $payload->mrn;
        //PENALTY
        $penaltyfilter = array("mrn" => (int) $mrn, "type" => "PENALTY", "status" => 4);
        $penaltyproject = array(
            "penalty_id" => '$_id',
                //"amount"=>1,
                //"type"=>1,
                //"transaction_code"=>1,
        );
        $pipeline = array(
            array('$match' => $penaltyfilter),
            array('$addFields' => $penaltyproject),
        );
        $penaltyCursor = $this->dbo->aggregate('masters', 'orders_refund_penalties', $pipeline);
        if ($penaltyCursor == "") {
            $penaltyCursor = array();
        }
		
		for($i=0;$i<count($penaltyCursor);$i++)
		{
			$penaltyCursor[$i]['business_name'] = $this->utility->getbusinessName((int)$penaltyCursor[$i]['business_id']);
		}
        $data['pendingPenalties'] = $penaltyCursor;
		
        //PENDING PAYMENT
        $pendingfilter = array("order.patientinfo.mrn" => (string) $mrn, "OStatus" => 505);
        $pendingproject = array(
            "mrn" => '$order.patientinfo.mrn',
            "order_id" => '$_id',
            "order_did" => '$odid',
            "scheduled_date" => '$order.patientinfo.scheduled_date',
            "business_id" => '$order.patientinfo.service_type',
            "payable_amount" => '$payment_info.payable_amount',
        );

        $pipeline = array(array('$match' => $pendingfilter), array('$project' => $pendingproject));

        $pendingCursor = $this->dbo->aggregate('masters', 'orders', $pipeline);

		for($i=0;$i<count($pendingCursor);$i++)
		{
			$pendingCursor[$i]['business_name'] = $this->utility->getbusinessName((int)$pendingCursor[$i]['business_id']);
		}
        $data['pendingOrderPayments'] = $pendingCursor;

        if (count($penaltyCursor) == 0 and count($pendingCursor) == 0) {
            $response['response'] = 0;
            $response["message"] = "No records found";

            $data['pendingOrderPayments'] = array();
            $data['pendingPenalties'] = array();
            $response["data"] = $data;
        } else {
            $response["data"] = $data;
        }
        return $response;
    }

    public function getRefunds($transaction_code) {

        $amountRefund = 0;

        $filter = array("transaction_code" => $transaction_code, 'type' => "REFUND");
        $this->log->create_log("", "", "debug", "Execution", 200, "generate Reciept", json_encode($filter), (string) $ticket);
        $result = $this->dbo->find("masters", "orders_refund_penalties", $filter, array());

        foreach ($result as $refund) {

            $amountRefund += floatval($refund['amount']);
        }
        return ['amountRefund' => $amountRefund];
    }

    public function getRefundInfo($payload, $ticket) {

        if (empty($payload->order_id)) {
            $responce = array("status" => 0, "message" => "Please provide order_id in request");
            return $responce;
        }

        $filter = array("order_id" => (int) $payload->order_id, 'type' => "REFUND");

        $result = $this->dbo->findOne("masters", "orders_refund_penalties", $filter, array());
        //echo json_encode($result);exit;

        if (empty($result)) {
            $responce = array("status" => 0, "message" => "No Refund data found for this order", 'data' => []);
            return $responce;
        } else {
            $responce = array("status" => 1, "message" => "Refund data found for this order", 'data' => $result);
            return $responce;
        }
    }

    public function shipmentlabel($orderid, $action = "Download") {
        if (isset($orderid) && $orderid != "") {

            $project = array(
                "_id" => 1,
                "did" => 1,
                "order.patientinfo.mrn" => 1,
                "order.patientinfo.address" => 1,
                "order.patientinfo.contact" => 1,
                "order.patientinfo.name" => 1,
                "order.patientinfo.service_type" => 1,
                "OStatus" => 1,
                "odid" => 1,
                "billing.billing_did" => 1,
                "order.patientinfo.gross_amount" => 1,
                "order.patientinfo.discount_amount" => 1,
                "order.patientinfo.net_amount" => 1,
                "order.patientinfo.wallet_amount" => 1,
                "order.patientinfo.voucher_amount" => 1,
                "order.patientinfo.coupon_amount" => 1,
                "order.patientinfo.surge_amount" => 1,
                "order.patientinfo.payment_amount" => 1,
                "order.order_status.created_date" => 1,
                "order.orderitem" => 1,
            );
            $filter = array("_id" => (int) $orderid);
            $orderdetails = $this->dbo->findOne('masters', 'orders', $filter, $project);
            // print_r($orderdetails);exit;
            if (isset($orderdetails[_id])) {
                $businessId = (int) $orderdetails[order][patientinfo][service_type];
                $subbusinessId = (int) $orderdetails[order][patientinfo][service_subtype_id];
                $gross_amount = isset($orderdetails[order][patientinfo][gross_amount]) ? (float) $orderdetails[order][patientinfo][gross_amount] : 0;
                $discount_amount = isset($orderdetails[order][patientinfo][discount_amount]) ? (float) $orderdetails[order][patientinfo][discount_amount] : 0;
                $net_amount = isset($orderdetails[order][patientinfo][net_amount]) ? (float) $orderdetails[order][patientinfo][net_amount] : 0;
                $wallet_amount = isset($orderdetails[order][patientinfo][wallet_amount]) ? (float) $orderdetails[order][patientinfo][wallet_amount] : 0;
                $voucher_amount = isset($orderdetails[order][patientinfo][voucher_amount]) ? (float) $orderdetails[order][patientinfo][voucher_amount] : 0;
                $coupon_amount = isset($orderdetails[order][patientinfo][coupon_amount]) ? (float) $orderdetails[order][patientinfo][coupon_amount] : 0;
                $surge_amount = isset($orderdetails[order][patientinfo][surge_amount]) ? (float) $orderdetails[order][patientinfo][surge_amount] : 0;
                $shipping_charges = isset($orderdetails[order][patientinfo][medicine_delivery_charge]) ? (float) $orderdetails[order][patientinfo][medicine_delivery_charge] : 0;
                $payment_amount = isset($orderdetails[order][patientinfo][payment_amount]) ? (float) $orderdetails[order][patientinfo][payment_amount] : 0; //prepaid
                $bill_amount = ($net_amount + $surge_amount) - ($wallet_amount + $voucher_amount + $coupon_amount);
                $pending_amount = $bill_amount - $payment_amount;
                $totalcolspan = 0;
                $status = (int) $orderdetails[OStatus];
                $billodid = isset($orderdetails[billing][billing_did]) ? (float) $orderdetails[billing][billing_did] : "";
                $order_date = isset($orderdetails[order][order_status][created_date]) ? $orderdetails[order][order_status][created_date] : "";
                $order_date = date('Y-m-d h:i A', strtotime($order_date));
            }

            $pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'ISO-8859-1', false);
            $pdf->SetCreator(PDF_CREATOR);
            $pdf->SetAuthor('Callhealth - Drug');
            $pdf->SetTitle('ShimentLable');
            $pdf->setPrintHeader(true);
            $pdf->setPrintFooter(true);
            $pdf->SetMargins(5, 36, 5);
            $pdf->SetAutoPageBreak(true, 45);
            $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
            $pdf->setLanguageArray($l);
            $pdf->AddPage();

            $html = '<table style="width:100%">
            <tr>
            <td><span style="text-align:center; font-weight:bold; text-decoration:underline; font-size:40px;">SHIPMENT LABEL</span></td>
            </tr>

	    <tr>
            <td><br><br>
		<span style="text-align:left; font-size:32px;">Order No. - ' . $orderid . '</span><br>
		<span style="text-align:left; font-size:32px;">Order Date - ' . $order_date . '</span><br>
	   </td>
           </tr>

	   <tr>
           <td>
	     <span style="text-align:left; font-weight:bold; text-decoration:underline; font-size:32px;">Delivery Address</span><br>
	     <span style="text-align:left; font-size:32px;">Name - ' . ucfirst($orderdetails[order][patientinfo][name]) . '</span><br>
	     <span style="text-align:left; font-size:32px;">Address -  ' . ucfirst(trim($orderdetails[order][patientinfo][address])) . '</span><br>
	     <span style="text-align:left; font-size:32px;">Phone No. -  ' . $orderdetails[order][patientinfo][contact] . '</span><br>
	   </td>
           </tr>

	   <tr>
           <td><br>
	     <span style="text-align:left; font-weight:bold; font-size:40px;">Amount to be Collected Rs. ' . $net_amount . '/-</span><br>
	   </td>
           </tr>

	   <tr>
           <td align="center"><br>
	       <table width="100%" border="1" cellspacing="0" cellpadding="0" class="conten_tabler">
	       <tr><th>Description</th><th>Total</th></tr>

               <tr>
               <td>MRP</td>
               <td>' . $gross_amount . '</td>
               </tr>

               <tr>
               <td>Discounted Price</td>
               <td>' . $net_amount . '</td>
               </tr>

               <tr>
               <td>Shipping Charges</td>
               <td>' . $shipping_charges . '</td>
               </tr>

               <tr>
               <td>Amount To Be Collected </td>
               <td>' . $net_amount . '</td>
               </tr>

	       </table>

	</td>
        </tr>

	<tr>
        <td><br><br>
	  <span style="text-align:left; font-size:32px;">E. & O. E</span><br>
          <span style="text-align:left; font-size:32px;">Note: - The Hyderabad Courts shall have exclusive jurisdiction to settle any disputes which may arise out of or in connection with this transaction.</span><br><br>
          <span style="text-align:left; font-weight:bold; font-size:32px;">________________________</span><br><br><br>
          <span style="text-align:right; font-weight:bold; font-size:32px;">Authorized Signatory</span><br>
          <span style="text-align:left; font-size:32px;">Note: - THIS IS COMPUTER GENERATED INVOICE AND DOES NOT REQUIRE SIGNATURE</span><br>
        </td>
        </tr>
        </table>';

            //print_r($html);exit;
            $pdf->writeHTML($html, true, false, true, false);
            //$pdf->Output('name.pdf', 'F');
            $invnum = 'Shipment_Lable' . $orderid . '.pdf';
            if ($action == "Download") {
                $pdf->Output($invnum, 'D');
            } else {
                $base64data = $pdf->Output($invnum, 'S');
                $conpdf = unpack('C*', $base64data);
                ini_set('memory_limit', '-1');
                $conpdf = array_values($conpdf);

                /* $a = base64_decode($base64data);
                  $b = array();
                  foreach(str_split($a) as $c)
                  {
                  $b[] = sprintf("%08b", ord($c));
                  }
                 */
                //print_r($conpdf);exit;
                $b = json_encode($conpdf);
                return $b;
            }
        } else {
            $project = array("test");
        }
        return $project;
    }

    public function updateRefundInfo($payload, $ticket) {
        //print_r($payload);exit;
        $refundId = $payload->refund_id;
        $status = (int) $payload->status;
        $transactionCode = $payload->transaction_code;
        $transactionType = $payload->transaction_type;
        $transactionAmount = (float) $payload->amount;
        $reason = $payload->reason;
        $userId = $payload->user_id;
        $userName = $payload->username;
        $cateogry = isset($payload->category) ? $payload->category : "";
        $sub_cateogry = isset($payload->sub_category) ? $payload->sub_category : "";
        $sub_category_description = isset($payload->sub_category_description) ? $payload->sub_category_description : "";
        $comment_text = isset($payload->comment_text) ? $payload->comment_text : "";
        $ticket_id = isset($payload->ticket_id) ? $payload->ticket_id : "";

        $filter = array("_id" => new MongoId($refundId));
        $result = $this->dbo->findOne("masters", "orders_refund_penalties", $filter, array());
        //print_r($result);exit;

        if (empty($result)) {
            return array("status" => 0, "message" => "Refund for the order does not exist");
        }

        if ($result[status] == $status) {
            return array("status" => 0, "message" => "order is already in same state");
        } else {
            $log_details = array(
                "status" => $status,
                "created_on" => $this->utility->getCurrenttime(),
                "userId" => $userId,
                "userName" => $userName,
                "transaction_id" => (isset($transactionCode) && !empty($transactionCode)) ? $transactionCode : "",
                "amount" => (isset($transactionAmount) && !empty($transactionAmount)) ? $transactionAmount : 0,
                "refund_type" => $transactionType,
                "comments" => $comment_text,
            );

            //print_r($log_details);exit;
            //$filter1 = array("order_id"=>(int)$orderId);

            $set = array('status' => (int) $status);
            if ($status == 4) {
                $set['reason'] = $sub_category_description;
                $set['comment'] = $comment_text;
                $set['ticket_id'] = $ticket_id;
                $log_details['category'] = $cateogry;
                $log_details['sub_category'] = $sub_cateogry;
                $log_details['sub_category_description'] = $sub_category_description;
                $log_details['ticket_id'] = $ticket_id;
            }
            $push = array('log' => $log_details);
            //print_r($push);exit;
            $updateResult = $this->dbo->update("masters", "orders_refund_penalties", $filter, $set, $push, array());
            //print_r($updateResult);exit;
        }

        if ($updateResult['nModified'] == 1) {
            return array("status" => 1, "message" => "Log generated successfully");
        } else {
            return array("status" => 0, "message" => "Log generation failed");
        }
    }

    public function generateReceipt($request, $ticket)
    {

        $this->log->create_log("", "", "finance", "Execution", 200, "generate Reciept", json_encode($request), (string) $ticket);
        //VALIDATING REQUEST

        $fields = ['paymentmode', 'order_id', 'receiptamount'];
        foreach ($fields as $field) {
            if (!isset($request->{$field}) or $request->{$field} == "") {
                $response = array("response" => "0", "message" => "Need a valid " . $field);
                $this->log->create_log("", "", "finance", "Execution", 200, "generate Reciept", json_encode($response), (string) $ticket);
                return $response;
            }
        }
        if (!isset($request->receiptamount) or !is_numeric($request->receiptamount)) {
            $response = array("response" => "0", "message" => "Need a valid receiptamount");
            $this->log->create_log("", "", "finance", "Execution", 200, "generate Reciept", json_encode($response), (string) $ticket);
            return $response;
        }

        if ((strtolower($request->paymentmode) != "cash" or $request->paymentmode != 0) && (!isset($request->referencenumber)) && $request->referencenumber == "") {
            $response = array("response" => "0", "message" => "Need a valid referencenumber");
            $this->log->create_log("", "", "finance", "Execution", 200, "generate Reciept", json_encode($response), (string) $ticket);
            return $response;
        }

        //GET REQUEST DETAILS
        $order_id = (int) $request->order_id;
        $type = isset($request->type) ? (int) $request->type : 1;
        $receiptamount = $request->receiptamount;
        $paymentmode = $request->paymentmode;
        $referencenumber = $request->referencenumber;
        $receipts_tracker_id = isset($request->billingid) ? $request->billingid : "";
        $associate_id = isset($request->associate_id) ? $request->associate_id : "";
        $branch_id = isset($request->branch_id) ? $request->branch_id : "";
        $actionById = isset($request->actionById) ? $request->actionById : "";
        $actionByName = isset($request->actionByName) ? $request->actionByName : "";
        $reason = isset($request->reason) ? $request->reason : "";

        //$filterBill = array("_id" => (int) $receipts_tracker_id);
        //$filterOrder = array("order.order_status.receipts_tracker_id" => (int) $receipts_tracker_id);
        $filterOrder = array("_id" => (int) $order_id);
        $filterBill = array("billing.patientinfo.order_id" => (int) $order_id);
        $custMobile = null;

        //  echo json_encode($filterBill);exit;
        //TRY QUERYING
        try {
            //FIND BILL FOR THE TRACKER ID
            $orderCursor = $this->dbo->findOne("masters", "orders", $filterOrder, array());
            $billCursor = $this->dbo->findOne("masters", "billing_info", $filterBill, array());
            $custMobile = $orderCursor['order']['patientinfo']['contact'];
        } catch (Exception $e) {
            $response = array("response" => "0", "message" => "QueryError: " . $e->getMessage());
            $this->log->create_log("", "", "finance", "Execution", 200, "generate Reciept", json_encode($response), (string) $ticket);
            return $response;
        }
        if (isset($billCursor[_id]) && $receipts_tracker_id = "") {
            $response = array("status" => 0, "message" => "Need a valid billingid");
            $this->log->create_log("", "", "finance", "Execution", 200, "generate Reciept", json_encode($response), (string) $ticket);
            return $response;
        }

        //GENERATE NEW RECEIPT ID
        $receiptidseq = $this->utility->getNextSequence("receipt_id");

        $yr = date('y');
        $receiptid = "R-000-" . $yr . "-" . $receiptidseq;
        $receiptdate = $this->utility->getCurrentdatetimesimple();
        //date("Y") . "-" . date("m") . "-" . date("d") . "T" . date("H") . ":" . date("i") . ":" . date("s") . ".000Z";

        //MAKE RECEIPT ARRAY
        $receiptarray = array(
            'receipt_id' => $receiptid,
            'type' => $type,
            'associate_id' => $associate_id,
            'associate_branch_id' => $branch_id,
            'receipt_amount' => $receiptamount,
            'payment_mode' => $paymentmode,
            'payment_code' => $paymentmode,
            'payment_ref_no' => $referencenumber,
            'payment_collected' => 1,
            'receipt_date' => $receiptdate,
            'receipt_status' => 1,
            "processed" => "NP",
            'mho_id' => $actionById,
            "mho_name" => $actionByName,
            'submitted_to' => "0",
            "reason" => $reason
        );

        if (isset($request->penalty_id)) {
            $receiptarray['penalty_id'] = $request->penalty_id;
        }

        if ($paymentmode == 0) {
            $receiptarray['payment_submited'] = 0;
            $receiptarray['payment_submitted'] = 0;
            $receiptarray['payment_collected'] = 0;
        } else {
            $receiptarray['payment_submited'] = 1;
            $receiptarray['payment_submitted'] = 1;
        }

        //DEFAULT FAILURE RESPONSE
        $response = array("status" => 0,"response" => 0, "message" => "Operation Failed.");
        //echo "1";exit;
        //RECEIPT UPDATION
        //print_r($billCursor);exit;
        if (!isset($billCursor[_id])) {

            //PUSH RECEIPT TO "advance_receipt" IN ORDERS AS BILL IS NOT YET GENERATED
            if ($type != 2) {
                $updOptions = array(
                    '$inc' => array(
                        "payment_info.paid_amount" => (float) $receiptamount,
                        "payment_info.payable_amount" => (-1 * (float) $receiptamount),
                    ),
                );
            } else {
                $updOptions = array();
            }
            $push = array('advance_receipt' => $receiptarray);
            //echo json_encode(array($filter,array('$set'=>$set,'$push'=>$push)));exit;
            //TRY UPDATING
            try {
                $updateCursor = $this->dbo->update('masters', 'orders', $filterOrder, array(), $push, array(), $updOptions);
            } catch (Exception $e) {
                $response = array("response" => "0", "message" => "QueryError: " . $e->getMessage());
                return $response;
            }
            if ($updateCursor['nModified'] > 0) {
                $response = array("status" => 1,"response"=>1, "message" => "Receipt generated successfully", "receipt_id" => $receiptid);
            }

            //print_r($response);exit;
        } else {
            //IF BILL ALREADY EXISTS FOR THE ORDER PUSH RECEIPT TO "billing.receiptinfo"

            $billingid = $billCursor['billing']['billinginfo']['billingid'];
            $order_id = $billCursor['billing']['billinginfo']['order_id'];
            $dueamount = $billCursor['billing']['billinginfo']['due_amount'];
            $paid_amount = $billCursor['billing']['billinginfo']['paid_amount'];
            $service_type = $billCursor['billing']['patientinfo']['service_type'];
            $payable_amount = isset($billCursor['billing']['billinginfo']['payable_amount']) ?
            $document['billing']['billinginfo']['payable_amount'] :
            $document['billing']['billinginfo']['due_amount'];
            //CALCULATE NEW AMOUNTS
            if ($type != 2) {
                $newdueamount = ((float) round($dueamount, 2) - (float) round($receiptamount, 2));
                $newdueamount = round($newdueamount, 2);
                $newpaid_amount = ($paid_amount + $receiptamount);
            } else {
                $newdueamount = $dueamount;
                $newpaid_amount = $paid_amount;
            }
            $newpayableamount = $newdueamount;

            $orderinfo = new Orderinfo;
            $penalty = $orderinfo->getAllPendingPaidDetails(array("order_id" => $order_id));
            $totalPenalty = (float) $penalty['PenaltiesPaid'] + (float) $penalty['PenaltiesPending'];

            //$applicable_due_amount=$totalPenalty+$newdueamount;
            //print_r($billCursor);
            $applicable_due_amount = $newdueamount;

            //echo (float) round($receiptamount, 2);exit;
            //echo $applicable_due_amount;exit;
            if ($applicable_due_amount >= 0) {
                //BILLING_ID CAN BE ADDED AS BILL EXISTS
                $receiptarray['billing_id'] = $billingid;
                //print_r($receiptarray);exit;
                $filter = array('_id' => (int) $receipts_tracker_id);
                $push = array('billing.receiptinfo' => $receiptarray); 
                //TRY UPDATING
                try {
                    // echo "2";exit;
                    $updatereceipt = $this->dbo->update("masters", "billing_info", $filterBill, array(), $push, array());

                } catch (Exception $e) {
                    $response = array("response" => "0", "message" => "QueryError: " . $e->getMessage());
                    $this->log->create_log("", "", "finance", "Execution", 200, "generate Reciept", json_encode($response), (string) $ticket);
                    return $response;
                }
                //print_r($updatereceipt);exit;
                if ($updatereceipt['nModified'] > 0) {
                    $filter = array('_id' => (int) $receipts_tracker_id);
                    $cursor = $this->dbo->findOne("masters", "billing_info", $filterBill, array());

                    //Check whether all payments are collected and submitted
                    $receiptinfo = $cursor['billing']['receiptinfo'];
                    $receiptflag = 1;
                    foreach ($receiptinfo as $info) {
                        if ($info['payment_collected'] == 0 or $info['payment_submited'] == 0) {
                            $receiptflag = 0;
                        }
                    }

                    $filter = array('_id' => (int) $receipts_tracker_id);
                    $set = array('billing.billinginfo.paid_amount' => (string) $newpaid_amount,
                        'billing.billinginfo.due_amount' => $newdueamount,
                        'billing.billinginfo.assignedto' => $actionById,
                        'billing.billinginfo.billing_status' => "1",
                        'billing.billinginfo.payable_amount' => $newpayableamount,
                    );

                    if ($receiptflag == 1 and $newdueamount == 0) {
                        $set['billing.billinginfo.all_receipt_submitted'] = "1";
                        $set['billing.billinginfo.payment_status'] = "3";
                        $set['billing.billinginfo.billing_status'] = "3";
                    }

                    $options = array();

                    //TRY UPDATING
                    try
                    {
                        $updateamounts = $this->dbo->update("masters", "billing_info", $filterBill, $set, array(), $options);

                        $filter = array('order.order_status.receipts_tracker_id' => (int) $receipts_tracker_id);

                        //IF NOT PENALTY AMOUNT REDUCE PAYABLE_AMOUNT
                        if ($type != 2) {
                            $updOptions = array('$inc' => array(
                                "payment_info.paid_amount" => (float) $receiptamount,
                                "payment_info.payable_amount" => (-1 * (float) $receiptamount),
                            ),
                            );
                            $updateCursor = $this->dbo->update('masters', 'orders', $filterOrder, array(), array(), array(), $updOptions);
                        }
                    } catch (Exception $e) {
                        $response = array("response" => "0", "message" => "QueryError: " . $e->getMessage());
                        $this->log->create_log("", "", "finance", "Execution", 200, "generate Reciept", json_encode($response), (string) $ticket);
                        return $response;
                    }

                    $response = array("status" => 1, "response" =>1, "message" => "Receipt generated successfully", "receipt_id" => $receiptid);
                }
            } else {
                $response = array("status" => 0,"response"=>0, "message" => "Action not possible,check due amount");
            }

        }

        if ($response['status'] == 1 && !empty($custMobile)) {
            //TO SEND CUSTOMER A CONFIRMATION ON SUCCESSFUL RECEIPT GENERATION
            $eventType = 1;
            $notif = new Notification;
            $payload = array('amount' => (string) $receiptamount);
            $notif->generic_sms($custMobile, $payload, $eventType);
        }

        $this->log->create_log("", "", "finance", "Execution", 200, "generate Reciept", json_encode($response), (string) $ticket);
        return $response;

    }

    public function calculate_transaction($data = []) {
        // update transaction
        $order_id = $data['order_id'];
        $filter = ['transaction_code' => $data['transaction_code']]; //1-311218-7083020
        $txn = $this->dbo->findOne("masters", "transaction", $filter, ["order_info" => 1, "payment_info" => 1]);
        unset($txn['_id']);
        foreach ($txn['order_info'] as $key => $order) {
            $set_txn['order_info'][$key] = $order;
            if ($order['order_id'] == $order_id) {
                $set_txn['order_info'][$key]["gross_amount"] = $data['gross_amount'];
                $set_txn['order_info'][$key]["discount_amount"] = $data['discount_amount'];
                $set_txn['order_info'][$key]["net_amount"] = $data['net_amount'];
                $set_txn['order_info'][$key]["voucher_amount"] = $data['voucher_amount'];
                $set_txn['order_info'][$key]["wallet_amount"] = $data['wallet_amount'];
                $set_txn['order_info'][$key]["coupon_amount"] = $data['coupon_amount'];
                $set_txn['order_info'][$key]["payable_amount"] = $data['payable_amount'];
                $set_txn['order_info'][$key]["payment_amount"] = $data['payment_amount'];
            }
            $set_txn['payment_info.gross_amount'] += $txn['order_info'][$key]['gross_amount'];
            $set_txn['payment_info.discount_amount'] += $txn['order_info'][$key]['discount_amount'];
            $set_txn['payment_info.net_amount'] += $txn['order_info'][$key]['net_amount'];
            $set_txn['payment_info.voucher_amount'] += $txn['order_info'][$key]['voucher_amount'];
            $set_txn['payment_info.wallet_amount'] += $txn['order_info'][$key]['wallet_amount'];
            $set_txn['payment_info.coupon_amount'] += $txn['order_info'][$key]['coupon_amount'];
            $set_txn['payment_info.payable_amount'] += $txn['order_info'][$key]['payable_amount']; // due amt
            $set_txn['payment_info.payment_amount'] += $txn['order_info'][$key]['payment_amount']; // paid amt
        }
        $update = $this->dbo->update("masters", "transaction", $filter, $set_txn, array(), array("multi" => true));
    }

    public function receiptsPendingToCH($payload, $ticket) {
        $dbo = new Dbo;

        $project = array(
            'billing.patientinfo.mrn' => 1
            , 'billing.patientinfo.name' => 1
            , 'billing.patientinfo.scheduled_date' => 1
            , 'billing.patientinfo.service_type' => 1
            , 'billing.billinginfo.billingid' => 1
            , 'billing.billinginfo.assignedto' => 1
            , 'billing.billinginfo.order_did' => 1
            , 'billing.receiptinfo.receipt_id' => 1
            , 'billing.receiptinfo.receipt_amount' => 1
            , 'billing.receiptinfo.payment_mode' => 1
            , 'billing.receiptinfo.payment_submited' => 1
            , 'billing.receiptinfo.payment_collected' => 1
            , 'billing.receiptinfo.receipt_date' => 1
            , 'billing.receiptinfo.mho_id' => 1
            , 'billing.receiptinfo.mho_name' => 1
            , 'billing.receiptinfo.submited_date' => 1
            , 'billing.receiptinfo.pop_id' => 1
            , 'billing.receiptinfo.pop_name' => 1,
        );

        //Payload details
        $from_date = $payload->startDate;
        $to_date = $payload->endDate;
        $submitted_to_CH = $payload->submitted_to_CH;

        //Change submited to submitted
        $match = array(
            'billing.receiptinfo.payment_submited' => 1,
            'billing.receiptinfo.payment_mode' => array(
                '$in' => array('Cash', 'cash', 'CASH', 0, "0", 100, "100")
            ),
            'billing.receiptinfo.submitted_to_ch' => array(
                '$exists' => $submitted_to_CH
            )
        );

        if (isset($payload->search_type) && $payload->search_type != null && $payload->search_type != "" && trim($payload->search_txt) != "") {
            if ((int) $payload->search_type == 1) {
                $match['billing.billinginfo.order_did'] = trim($payload->search_txt);
            }
        } else {
            $match['billing.receiptinfo.submited_date'] = array(
                '$gte' => $from_date . "T00:00:00",
                '$lte' => $to_date . "T23:59:59"
            );
        }
        /* if (isset($payload->searchType) and $payload->searchType != null) {
          if (isset($payload->searchText) and $payload->searchText != null) {
          $searchType = $payload->searchType;
          $searchText = $payload->searchText;

          $matchVal = array('$regex' => $searchText, '$options' => '$i');
          if ($searchType == "order_did" or $searchType == "billingid") {
          $match['billing.billinginfo.' . $searchType] = $matchVal;
          } else if ($searchType == "mrn") {
          $match['billing.patientinfo.mrn'] = $matchVal;
          } else if ($searchType == "receipt_id") {
          $match['billing.receiptinfo.receipt_id'] = $matchVal;
          } else {
          $response = array("status" => 0, "message" => 'Invalid searchType');
          return $response;
          }

          }
          } */

        if (isset($payload->associateId) and $payload->associateId != null) {
            $match['billing.receiptinfo.associate_id'] = $payload->associateId;
        }

        if (isset($payload->associateBranchId) and $payload->associateBranchId != null) {
            $match['billing.receiptinfo.associate_branch_id'] = $payload->associateBranchId;
        }

        $unwind = '$billing.receiptinfo';

        if ($submitted_to_CH == true) {
            $project['billing.receiptinfo.submitted_to_ch'] = 1;
            $project['billing.receiptinfo.phelp_transaction_id'] = 1;
            $project['billing.receiptinfo.submitted_to_ch_date'] = 1;
        }
        //print_r($match);exit;
        $pipeline = array(array('$unwind' => $unwind), array('$match' => $match), array('$project' => $project));

        //echo json_encode($pipeline);exit;
        try {
            $result = $dbo->aggregate('masters', 'billing_info', $pipeline);
            //print_r($result);exit;
        } catch (Exception $e) {
            $response = array("status" => 0, "message" => 'Query Error: ' . $e->getMessage());
            return $response;
        }

        if (count($result) > 0 and $result != null) {
            $response = array("status" => 1, "message" => "Success", "count" => count($result), "receipts" => $result);
            return $response;
        } else {
            $response = array("status" => 0, "message" => "No Receipts found for this filter");
            return $response;
        }
    }

    public function shipmentLable($orderid, $action = "Download") {
        if (isset($orderid) && $orderid != "") {
            $project = array();
            $footerimage = "footer_cashmemo.jpg";
            $filter = array("_id" => (int) $orderid);
            $orderdetails = $this->dbo->findOne('masters', 'orders', $filter, $project);
            //print_r($orderdetails);exit;
            if ($orderdetails[_id] != "") {

                $net = 0;
                $walletAmount = isset($orderdetails[order][patientinfo][wallet_amount]) ? (float) $orderdetails[order][patientinfo][wallet_amount] : 0;
                $shipingcharge = isset($orderdetails[order][patientinfo][medicine_delivery_charge]) ? (float) $orderdetails[order][patientinfo][medicine_delivery_charge] : (isset($orderdetails[order][patientinfo][delivery_charge]) ? (float) $orderdetails[order][patientinfo][delivery_charge] : 0);
                $prepaid = isset($orderdetails[order][prepayment]) ? (float) $orderdetails[order][prepayment][amount] : 0;
                $voucher_amount = isset($orderdetails[order][patientinfo][voucher_amount]) ? (float) $orderdetails[order][patientinfo][voucher_amount] : 0;
                $voucher_code = isset($orderdetails[order][patientinfo][voucher_code]) ? (float) $orderdetails[order][patientinfo][voucher_code] : "";

                $cus_address = isset($orderdetails[order][patientinfo][address]) ? $orderdetails[order][patientinfo][address] : "";
                $cus_address .= (isset($orderdetails[order][patientinfo][district]) && trim($orderdetails[order][patientinfo][district]) != "") ? ", " . $orderdetails[order][patientinfo][district] : ((isset($orderdetails[order][patientinfo][city]) && trim($orderdetails[order][patientinfo][city]) != "") ? ", " . $orderdetails[order][patientinfo][city] : "");
                $cus_address .= (isset($orderdetails[order][patientinfo][state]) && trim($orderdetails[order][patientinfo][state]) != "") ? ", " . $orderdetails[order][patientinfo][state] : "";
                $cus_address .= (isset($orderdetails[order][patientinfo][pincode]) && trim($orderdetails[order][patientinfo][pincode]) != "") ? ", " . $orderdetails[order][patientinfo][pincode] : "";

                foreach ($orderdetails[order][orderitem] as $items) {
                    if ($items[item_status] == "8" || (isset($items[cancelbeforeaccept]) && $items[cancelbeforeaccept] == "1")) {
                        continue;
                    }
                    $gross = $gross + (float) $items[gross_amount];
                    $net = $net + (float) $items[net_amount];
                }
                //echo "<pre>";
                //print_r($html);exit;
                $discount = $gross - $net;
                $tobecollected = ((($net + $shipingcharge) - $walletAmount) - $prepaid) - $voucher_amount;
                $netamt = "";
                $orderid = isset($orderdetails[_id]) ? $orderdetails[_id] : "";
                $datetime = date("d-m-Y", strtotime($orderdetails[order][order_status][created_date]));

                //Create new PDF document
                $pdf = new TCPDF('P', PDF_UNIT, 'A6', true, 'UTF-8', false);

                // set document information
                $pdf->SetCreator(PDF_CREATOR);
                $pdf->SetAuthor('Callhealth - Drug');
                $pdf->SetTitle('Shipment-Label');
                //set margin left,top,right
                $pdf->SetMargins(2, 2, 2);
                $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
                //set some language-dependent strings
                $pdf->setLanguageArray($l);
                $pdf->setPrintHeader(false);
                $pdf->setPrintFooter(false);
                $pdf->SetFont('dejavusans', '', 10);
                // add a page
                $pdf->AddPage();

                $html = '<table width="100%" cellpadding="8" border="0" style="color:#323232;"><tr><td>
			<span style="text-align:center; font-weight:bold; font-size:32px;">CALLHEALTH ONLINE SERVICES PVT LTD</span><br>
			<span style="text-align:center; font-size:32px;">#10th & 11th Floor, Ramky Towers Grandiose,</span><br>
			<span style="text-align:center; font-size:32px;">Gachibowli, Hyderabad – 500 032, Telangana, India.</span><br><hr>
		</td></tr></table>
		<table width="100%" border="0" align="center" style="color:#323232;"><tr><td>
			<table width="98%" cellpadding="5" align="left"  border="0"style="color:#323232;">
				<tr><td width="40%">
					<span style="text-align:left; font-size:30px;">Order No. - ' . $orderid . '</span>
				</td><td width="58%">
					<span style="text-align:right; font-size:30px;">Order Date - ' . $datetime . '</span>
				</td></tr>
			</table>
			<table width="100%" cellpadding="5" border="0" style="color:#323232;"><tr><td>
				<span style="text-align:left; font-weight:bold; text-decoration:underline; font-size:28px;">Delivery To</span><br>
				<span style="text-align:left; font-size:28px;">Name - ' . $orderdetails['order']['patientinfo']['name'] . '</span><br>
				<span style="text-align:left; font-size:28px;">Address -  ' . $cus_address . '</span><br>
				<span style="text-align:left; font-size:28px;">Phone No. -  ' . $orderdetails['order']['patientinfo']['contact'] . '</span>
			</td></tr></table>
			<table width="100%" cellpadding="5" border="0" style="color:#323232;"><tr><td style="text-align:left;">
				<span style="text-align:left; font-weight:bold; font-size:32px;">Amount to be Collected Rs. ' . $tobecollected . '/-</span>
			</td></tr>
			<tr><td align="center">
				<table width="90%" border="1" cellspacing="0" cellpadding="1">
					<tr><th>Description</th><th>Total</th></tr>
					<tr><td style="text-align:left; font-size:28px;"> a) Consignment Value</td><td>' . $gross . '</td></tr>
					<tr><td style="text-align:left; font-size:28px;"> b) Discount </td><td>' . $discount . '</td></tr>
					<tr><td style="text-align:left; font-size:28px;"> c) Shipping Charges </td><td>' . $shipingcharge . '</td></tr>
					<tr><td style="text-align:left; font-size:28px;"> d) Wallet Amount</td><td>' . $walletAmount . '</td></tr>
					<tr><td style="text-align:left; font-size:28px;"> e) Voucher Amount</td><td>' . $voucher_amount . '</td></tr>
					<tr><td style="text-align:left; font-size:28px;"> f) Online Paid Amount</td><td>' . $prepaid . '</td></tr>
					<tr><td style="text-align:left; font-size:28px;"> Net Amount To Be Collected </td><td>' . $tobecollected . '</td></tr>
				</table>
			</td></tr><tr><td>
				<br><br><span style="text-align:left; font-size:28px;"><b>Note: - </b> The Hyderabad Courts shall have exclusive jurisdiction to settle any disputes which may arise out of or in connection with this transaction.</span><br>
			</td></tr></table>
		</td></tr></table>';

                $pdf->writeHTML($html, true, false, true, false);
                $invnum = 'shipment-label.pdf';
                $pdf->Output($invnum, 'D');
            }
        } else {
            $project = array("test");
        }
        return $project;
    }

    function phelpCashSubmission($payload, $ticket) {
        $dbo = new Dbo;
        $utility = new Utility;

        if ($payload->transactionId != null and isset($payload->transactionId)) {
            $transaction_id = $payload->transactionId;
        } else {
            $response = array("status" => 0, "message" => "Invalid or No transactionId");
            return $response;
        }

        if (isset($payload->receiptIds) and is_array($payload->receiptIds) and $payload->receiptIds != null) {
            $receipts = $payload->receiptIds;
        } else {
            $response = array("status" => 0, "message" => "Invalid or No receiptIds,need in array format");
            return $response;
        }

        $amount = $payload->amount;
        if ($amount == null or ! is_numeric($amount)) {
            $response = array("status" => 0, "message" => "Invalid or No amount");
            return $response;
        }

        $date = $utility->getCurrenttime();

        $data = array("transaction_id" => $transaction_id
            , "receipt" => $receipts
            , "amount" => $amount
            , "submitted_date" => $date
        );

        if (isset($payload->type) and $payload->type != null) {
            $phelp_details['payment_type'] = $payload->type;
        }

        if (isset($payload->associateId) and $payload->associateId != null) {
            $phelp_details['associate_id'] = $payload->associateId;
        }

        if (isset($payload->associateBranchId) and $payload->associateBranchId != null) {
            $phelp_details['associate_branch_id'] = $payload->associateBranchId;
        }

        if (isset($payload->officerId) and $payload->officerId != null) {
            $phelp_details['officer_id'] = $payload->officerId;
        }

        if (isset($payload->officerName) and $payload->officerName != null) {
            $phelp_details['officer_name'] = $payload->officerName;
        }

        $data[phelp_details] = $phelp_details;

        $count_filter = array("transaction_id" => $transaction_id);

        //TO OPTIMIZE
        $count = $dbo->countitem('masters', 'phelp_cash', $count_filter);
        //echo $count;exit; 

        if ($count > 0) {
            $response = array("status" => 0, "message" => 'Transaction already done with this id');
            return $response;
        }

        $insert_resp = $dbo->insert('masters', 'phelp_cash', $data);

        $billing_filter = array('billing.receiptinfo.receipt_id' => array('$in' => $receipts));
        $billing_set = array("billing.receiptinfo.$.submitted_to_ch" => 1
            , "billing.receiptinfo.$.phelp_transaction_id" => $transaction_id
            , "billing.receiptinfo.$.submitted_to_ch_date" => $date
            , "billing.receiptinfo.$.submission_phelp_details" => $phelp_details
        );
        $billing_push = array();
        $billing_options = array('multiple' => true);

        $update_resp = $dbo->update('masters', 'billing_info', $billing_filter, $billing_set, $billing_push, $billing_options);

        //print_r($update_resp);exit;

        if ($update_resp['nModified'] == count($receipts) and count($receipts) != null) {
            $response = array("status" => 1, "message" => "Successfully Updated");
        } else {
            $response = array("status" => 0, "message" => "Updating receipts failed");
        }

        return $response;
    }

    function getThirdPartyReceipts($ticket) {
        try {

            $response = array("status" => 0, "message" => "Operation Failed");

            $match = array(
                "billing.receiptinfo.submitted_to_thirdparty" => 1
                    //,"billing.receiptinfo.thirdparty_name"=>array('$regex'=>"airtel",'$options'=>'i')
            );
            $project = array(
                "_id" => 0,
                "order_id" => '$billing.patientinfo.order_id',
                "billingid" => '$billing.billinginfo.billingid',
                "receiptDetails" => array(
                    '$map' => array(
                        'input' => '$billing.receiptinfo',
                        'as' => 'receipt',
                        'in' => array(
                            'receipt_id' => '$$receipt.receipt_id',
                            'thirdparty_name' => '$$receipt.thirdparty_name',
                            'receipt_amount' => '$$receipt.receipt_amount',
                            'thirdparty_reference_no' => '$$receipt.thirdparty_reference_no'
                        )
                    )
                )
            );

            $sort = array(
                "billing.receiptinfo.thirdparty_datetime" => -1
            );

            $pipeline = array(array('$match' => $match), array('$sort' => $sort), array('$project' => $project));

            //echo json_encode($pipeline);exit;

            $cursor = $this->dbo->aggregate('masters', 'billing_info', $pipeline);
            //print_r($cursor);exit;

            if (count($cursor) > 0 and $cursor != "") {
                $response = array("status" => 1, "message" => "Data Found", "data" => $cursor);
            } else {
                $response = array("status" => 0, "message" => "Data not Found", "data" => array());
            }
        } catch (Exception $e) {
            $response = array("status" => 0, "ErrorMessage" => $e->getMessage());
        }
        return $response;
    }

    public function generate_refund_waiver($payload,$ticket)
    {
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "refund_generate_addition_waiver_start", json_encode($payload), (string) $ticket);
        $orderId = (int)isset($payload->orderId)?$payload->orderId:"";
        $refundAmount = (float)isset($payload->waiver_amount)?$payload->waiver_amount:"";
        $reason = isset($payload->reason)?$payload->reason:"";
        $actionById = isset($payload->actionById)?$payload->actionById:"";
        $actionByName = isset($payload->actionByName)?$payload->actionByName:"";
        $ticket_id = isset($payload->ticket_id)?$payload->ticket_id:"";
		
		
		if(empty($orderId) || empty($refundAmount) || $refundAmount<0.1 || empty($reason) || empty($actionById)){
			$response = array("response" => 0, "message" => "Provide the correct value of orderId/waiver_amount/reason/actionById");
			$this->log->create_log("", "", $this->getname(), "Execution", 200, "refund_generate_addition_waiver_end", json_encode($response), (string) $ticket);
			return $response;
		}		
		
		$filter = array("_id" => $orderId);
		$result = $this->dbo->findOne("masters", "orders", $filter, array());

		if (empty($result)){
			$response = array("response" => 0, "message" => "Order not found to generate addition waiver");
			$this->log->create_log("", "", $this->getname(), "Execution", 200, "refund_generate_addition_waiver_end", json_encode($response), (string) $ticket);
			return $response;
		}
		
        $addition_waiver = array(
            "orderId" => $orderId,
            "refundAmount" => $refundAmount,
            "reason" => $reason,
            "actionById" => $actionById,
            "actionByName" => $actionByName,
            "ticket_id" => $ticket_id,
			"sub_type"=> "Waiver"
        );
		try {
			$result = $this->generateRefund((object)$addition_waiver);
			//print_r($result); exit;
			if($result[response]==1 && isset($result[refundObj][amount])){
				//$response = array("response" => 1, "message" => "Refund Waiver inserted sucessfully.","refundObj"=>$result[refundObj]);
				$response = array("response" => 1, "message" => "Refund Waiver inserted sucessfully.");
				return $response;
			} else {
				$response = array("response" => 0, "message" => "Refund Waiver Insertion Failed");
				return $response;
			}
		}catch (Exception $e) {
			$response = array("response" => 0, "QueryError" => $e->getMessage());
			$this->log->create_log("", "", $this->getname(), "Execution", 200, "refund_generate_addition_waiver_issue", json_encode($response), (string) $ticket);
			return $response;
		}       
    }
}

//end of file!!