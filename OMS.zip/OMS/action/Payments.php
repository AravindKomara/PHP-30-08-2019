<?php
//error_reporting(E_ALL);
class Payments extends Oms
{
    public function __construct()
    {
        parent::__construct();
        $this->orderinfo = new Orderinfo;
    }

    public function getname()
    {
        return "payments";
    }

    //  {"id":"1-170119-7083282", "type":"1"}  {"id":"517141", "type":"2"}
    public function send_payment_link($payload, $ticket)
    {
        $id = $payload->id; // 1 for create link for transactionOrder   2. create link for orderIds 3.penaltyIds
        $type = $payload->mode; // 1:transaction_id, 2:order_id, 3:penalty
        $link_expiry_minute = $payload->link_expiry_minute;
        $channel = $payload->channel; // CP, CCO, MOBILE
        $email = $payload->email;
        $contact_no = $payload->phone;

        //-------------Validate required fields ------------
        if (empty($id) || empty($type) || empty($channel) || (is_array($id) && ($type == 1 || $type == 3))) {
            return array("success" => 0, "code" => "10200", "message" => "Invalid Input Or Required fields are missing");
        }
        $service_type = '00';
        $username = $contact_no_db = $email_db = "";
        $penalty_id = $order_id = $transaction_code = null;
        if ($type == 1) {
            $filter = ['transaction_code' => (String) $id];
            $res = $this->dbo->findOne('masters', 'transaction', $filter, ['order_info' => 1, 'mrn' => 1]);
            if (!empty($res)) {
                //$res['externalRefNumber'] = (String) $res['transaction_code'] . '-' . $channel . '-' . $type;
                $res['externalRefNumber'] = (String) 'CH' . date('ymdHis') . mt_rand(100, 999);
            }
            $transaction_code = (String) $id;
        } elseif ($type == 2) {
            if (is_array($id)) {
                $id = (int) $id[0];
            }
            $filter = ['_id' => (int) $id];
            $res = $order = $this->dbo->find('masters', 'orders', $filter, ['order_info' => 1, 'order.patientinfo.mrn' => 1, 'order.patientinfo.service_type' => 1, 'order.patientinfo.email' => 1, 'order.patientinfo.name' => 1, 'order.patientinfo.contact' => 1, 'payment_info' => 1, 'odid' => 1]);
            if (!empty($res)) {
                $res['mrn'] = $res[0]['order']['patientinfo']['mrn'];
                //$res['externalRefNumber'] = (String) $res['odid'] . '-' . $channel . '-' . $type;
                $res['externalRefNumber'] = (String) 'CH' . date('ymdHis') . mt_rand(100, 999);
                $service_type = $res[0]['order']['patientinfo']['service_type'];
                $contact_no_db = $res[0]['order']['patientinfo']['contact'];
                $email_db = $res[0]['order']['patientinfo']['email'];
                $username = $res[0]['order']['patientinfo']['name'];
            }
            $order_id = (String) $id;
            $transaction_code = (String) $res[0]['transaction_code'];
        } elseif ($type == 3) { // get latest penalty
            $filter = ['_id' => $this->dbo->id($id)];
            $res = $this->dbo->findOne('masters', 'orders_refund_penalties', $filter, []);
            if (!empty($res)) {
                if ($res['type'] == 'PENALTY' && $res['status'] == '4') {
                    $res['externalRefNumber'] = (String) 'CH' . date('ymdHis') . mt_rand(100, 999);
                } else {
                    return array("success" => 0, "code" => "10800", "message" => "There is no pending PENALTY");
                }
                $username = $res['username'];
                $res['mrn'] = $res['mrn'];
                $order_id = $res['order_id'];
                $transaction_code = $res['transaction_code'];
            }
            $penalty_id = $id;
        }

        if (empty($res)) {
            return array("success" => 0, "code" => "10300", "message" => "Invalid id");
        }

        if (empty($contact_no)) {
            $contact_no = $contact_no_db;
        }
        if (empty($email)) {
            $email = $email_db;
        }

        //return $res;
        $mrn = $res['mrn']; // = 256131;
        $externalRefNumber = $res['externalRefNumber'];

        // check weather already sent and not expired
        if ($type == 1) { // transaction code
            $filter = ["transaction_code" => (String) $id];
            $oldRes = $this->dbo->find('masters', 'ezetab_log', $filter, [], ["actiondate" => -1], 1, 0); // add sort by
        }
        if ($type == 2) { // order id
            $filter = ["order_id" => (String) $id];
            $oldRes = $this->dbo->find('masters', 'ezetab_log', $filter, [], ["actiondate" => -1], 1, 0); // add sort by
        }
        if ($type == 3) { // penalty
            $filter = ["penalty_id" => (String) $id];
            $oldRes = $this->dbo->find('masters', 'ezetab_log', $filter, [], ["actiondate" => -1], 1, 0); // add sort by
        }
        if (!empty($oldRes)) {
            //$expiryTime = ($oldRes[0]['requestdata']->remotePayLinkExpiryTime * 60);
            $expiryTime = (intval($oldRes[0]['requestdata']['expiryTime']) * 60);
            if ((strtotime($oldRes[0]['actiondate']) + $expiryTime) > time()) {
                return array("success" => 0, "code" => "10600", "message" => "Payment link is already sent and not yet expired.", 'data' => ['paymentLink' => $oldRes[0]['result']['paymentLink']]);
            }
        }

        if (empty($contact_no)) {
            // get mrn details // latest user info
            $patient_payload = array("mrnIds" => [$mrn], "addressIds" => []);
            $patient_payload = json_encode($patient_payload);

            $sub_url = 'GcmJava/services/gcm/oms/getbulkdetails';
            $url = $this->config->getConfig("cpservicepath", $sub_url); //URL to hit

            $startTime = microtime(true);
            $buffer = $this->utility->my_curl($url, 'POST', $patient_payload, 'json', null, 10);
            $this->log->logThirdPartyCall("GCM", $url, $startTime, json_decode($patient_payload), $buffer);

            $contact_no = $buffer['allCustDetails'][$mrn]['mobile'];
            $username = $buffer['allCustDetails'][$mrn]['firstName'] . ' ' . $buffer['allCustDetails'][$mrn]['lastName'];
            $email = $buffer['allCustDetails'][$mrn]['email'];

            if (empty($contact_no)) {
                return array("success" => 0, "code" => "10400", "message" => "No mobile number associate with mrn:" . $mrn);
            }
        }
        //$contact_no = '8275289662'; // comment after workdone
        // get all order ids and appointment ids
        $dueAmount = 0;
        if ($type == 1) {
            $ids = $appintIds = [];
            foreach ($res['order_info'] as $item) {
                if (isset($item['order_id'])) {
                    $ids['order'][] = $item['order_id'];
                }
                if (isset($item['appointmentId'])) {
                    $ids['appoint'][] = $item['appointmentId'];
                }
            }

            if (!empty($ids['order'])) {
                $filter = ['_id' => ['$in' => $ids['order']]];
                $res = $this->dbo->find('masters', 'orders', $filter, ['payment_info' => 1]);
                foreach ($res as $item) {
                    $dueAmount += floatval($item['payment_info']['payable_amount']);
                }
            }

            if (!empty($ids['appoint'])) {
                $filter = ['appointmentId' => ['$in' => $ids['appoint']]];
                $res = $this->dbo->find('masters', 'appointments', $filter, []);
                foreach ($res as $item) {
                    $dueAmount += floatval($item['payment_info']['payable_amount']);
                }
            }
        }

        if ($type == 2) {
            foreach ($order as $item) {
                $dueAmount += floatval($item['payment_info']['payable_amount']);
            }
        }

        if ($type == 3) {
            $dueAmount = floatval($res['amount']);
        }

        if (floatval($dueAmount) <= 0) {
            return array("success" => 0, "code" => "10700", "message" => "There is not due amount Or payment_info is missing.");
        }
        if (empty($username)) {$username = 'CCO';}
        $ezetap = $this->config->ezetab(); // It is in minute
        $uniqueRef = $this->dbo->id();
        if (empty($link_expiry_minute)) {
            $link_expiry_minute = $ezetap['keytime'][$service_type];
            if (empty($link_expiry_minute)) {
                $link_expiry_minute = 15; //minutes
            }
        }
        //$contact_no = '8275289662'; $dueAmount = 1;
        $payment_payload = array(
            "paymentFlow" => "REMOTEPAY_FLOW2",
            "amount" => round($dueAmount, 2),
            "username" => "CCO", //$username, 5896321478
            "org_code" => "CALL_HEALTH_3239",
            "orgCode" => "CALL_HEALTH_3239",
            "externalRefNumber" => (String) $externalRefNumber, //$service_type . "-" . $id,
            "customerMobileNumber" => $contact_no,
            "appKey" => $ezetap['appkey'],
            "expiryTime" => $link_expiry_minute, //$ezetap['keytime'][$service_type],
            //"remotePayLinkExpiryTime" => $link_expiry_minute, //$ezetap['keytime'][$service_type],
            //"agentMobileNumber" => $contact_no,
            //"nonce" => mt_rand(10000, 99999), //"ext_1",
            //"customerEmail" => $email,
            //"confirmationURL" => SERVER_PATH. "/OMS/api/operation.php/v1/orders/payments/pg/ezetap/callback",
        );

        /* $payment_payload = [
        "username" => "5896321478",
        "customerMobileNumber" => "8275289662",
        "expiryTime" => "10",
        "paymentFlow" => "REMOTEPAY_FLOW2",
        "amount" => "1.0",
        "externalRefNumber" => "CF250",
        "appKey" => "3c394538-df2d-4ed0-b119-5718385c6c5f",
        ]; */
        $payment_payload = json_encode($payment_payload);
        $url = $ezetap['url'];

        $startTime = microtime(true);
        $result = $this->utility->my_curl($url, "POST", $payment_payload, 'json');
        $this->log->logThirdPartyCall("EZEETAB", $url, $startTime, json_decode($payment_payload), $result);
        //var_dump($result);die;
        $apidata['type'] = $type; // newFields 1 || 2
        $apidata['mrn'] = $mrn; // newFields
        $apidata['externalRefNumber'] = $externalRefNumber; // newFields
        $apidata['payment_status'] = 0; // newFields 0:INITIATED 1:PENDING 2:PAID 3:FAILED

        $apidata['_id'] = $uniqueRef;
        $apidata['order_id'] = $order_id; // orderid, penaltyid, transationId
        $apidata['penalty_id'] = $penalty_id;
        $apidata['transaction_code'] = $transaction_code;
        $apidata['service_type'] = $service_type;
        $apidata['api'] = "SendSmsEzetab";
        $apidata['channel'] = $channel;
        $apidata['actiondate'] = date("Y-m-d H:i:s"); //new MongoDate(time() + 19800); //
        $apidata['requestdata'] = $payment_payload;
        $apidata['result'] = json_encode($result);
        $this->dbo->insert('masters', 'ezetab_log', $apidata);

        if ($result['success'] == true) {
            if ($type == 1) {
                $set = array('ezzetab_sms' => "1", 'ezzetab_sms_sent_on' => date("Y-m-d\TH:i:s") . '.000Z');
                $filter = ['transaction_code' => (String) $id];
                $this->dbo->update('masters', 'orders', $filter, $set, array(), array("multi" => true));
            }
            if ($type == 2) {
                foreach ($order as $item) {
                    $set = array('order.patientinfo.ezzetab_sms' => "1", 'order.patientinfo.ezzetab_sms_sent_on' => date("Y-m-d\TH:i:s") . '.000Z');
                    $filter = array("_id" => (int) $item['_id']);
                    $this->dbo->update('masters', 'orders', $filter, $set, array(), array("multi" => true));
                }
            }
            if ($type == 3) {
                $set = array('ezzetab_sms' => "1", 'ezzetab_sms_sent_on' => date("Y-m-d\TH:i:s") . '.000Z');
                $filter = ['_id' => $this->dbo->id($id)];
                $this->dbo->update('masters', 'orders_refund_penalties', $filter, $set, array(), array("multi" => true));
            }
            return array("success" => 1, "code" => "10100", "message" => "Payment link has been sent to customer", 'data' => ['paymentLink' => $result['paymentLink'], 'txnId' => $result['txnId'], 'txnType' => $result['txnType'], "externalRefNumber" => (String) $externalRefNumber]);
        }
        return array("success" => 0, "code" => "10500", "message" => "Payment gateway is not responding, Please try later.");
    }

    /**
     * 10100 : Payment link has been sent to customer
     * 10200 : Invalid Input, Required fields are missing
     * 10300 : Invalid id
     * 10400 : No mobile number associate with mrn
     * 10500 : Payment gateway is not responding, Please try later.
     * 10600 : Payment link is already generated and not yet expired.
     * 10700 : There is not due amount Or payment_info is missing.
     * 10800 : There is no pending PENALTY.
     *
     */
    public function ezetap_push_notification($payload, $ticket)
    {
        // insert payload first : received from payment gateway
        if (empty($payload)) {
            return ['status' => 0, 'message' => 'Invalid request'];
        }
        $externalRefNumber = $payload->externalRefNumber;
        $filter = ["_id" => $externalRefNumber];
        $res = $this->dbo->findOne('masters', 'ezetap_pushnotifications', $filter, []);
        if (empty($res)) {
            $payload->_id = $externalRefNumber;
            $this->dbo->insert('masters', 'ezetap_pushnotifications', $payload);
        } else {
            $set = (Array) $payload;
            if (empty($res['previous_playload'])) {
                $set['previous_playload'][] = $res;
            } else {
                $previous_playload = $res['previous_playload'];
                unset($res['previous_playload']);
                array_push($previous_playload, $res);
                $set['previous_playload'] = $previous_playload;
            }
            $this->dbo->update('masters', 'ezetap_pushnotifications', $filter, $set, array(), array("multi" => true));
        }
        //1 order html entity
        if ($payload->status != "AUTHORIZED" /*|| $payload->states[0] != "SETTLED" */) {
            // check wheather is it failed or not
            $set['payment_status'] = 1; //
            if ($payload->status == "FAILED") {
                $set['payment_status'] = 3;
            }
            $filter = ["externalRefNumber" => $externalRefNumber];
            $this->dbo->update('masters', 'ezetab_log', $filter, $set, array(), array("multi" => true));
            exit(0);
        }

        // get ezetab_log
        $filter = ["externalRefNumber" => (String) $externalRefNumber];
        $sort = ["actiondate" => -1];
        $records = $this->dbo->find('masters', 'ezetab_log', $filter, [], $sort);
        $record = $records[0];

        if ($record['type'] == 1) { // transaction_code
            // ftech transaction details
            $filter = ['transaction_code' => $record['transaction_code']];
            $doc_txn = $this->dbo->findOne("masters", "transaction", $filter, []);
            if (empty($doc_txn)) {
                return array("status" => 0, "code" => "10400", "message" => "Invalid transaction_code");
            }

            // update all orders and generate receipt for each
            $orderIds = [];
            foreach ($doc_txn['order_info'] as $key => $odr) {
                $orderIds[] = $odr['order_ids'];
                $doc_txn['order_info'][$key]['payable_amount'] = 0;
                $doc_txn['order_info'][$key]['payment_amount'] = floatval($doc_txn['order_info'][$key]['payable_amount']) + floatval($doc_txn['order_info'][$key]['payment_amount']);
            }
            $this->payment_completion_and_generate_receipt($orderIds, $payload);

            // update payment info for txn and all orders
            $set = [];
            $set['payment_info.payment_amount'] = (float) $doc_txn['payment_amount'] + (float) $doc_txn['payable_amount'];
            $set['payment_info.payable_amount'] = 0;
            $set['order_info'] = $doc_txn['order_info'];
            $filter = ['transaction_code' => $record['transaction_code']]; //1-311218-7083020
            $update = $this->dbo->update("masters", "transaction", $filter, $set, [], array("multi" => true));

        } elseif ($record['type'] == 2) { // orderId
            $this->payment_completion_and_generate_receipt([$record['order_id']], $payload);

            // update transaction
            $filter = ['transaction_code' => $record['transaction_code']];
            $doc_txn = $this->dbo->findOne("masters", "transaction", $filter, []);
            if (empty($doc_txn)) {
                return array("status" => 0, "code" => "10400", "message" => "Invalid transaction_code");
            }

            // update all orders and generate receipt for each
            $orderIds = [];
            foreach ($doc_txn['order_info'] as $key => $odr) {
                if ($odr['order_id'] == $record['order_id']) {
                    $doc_txn['order_info'][$key]['payable_amount'] = 0;
                    $doc_txn['order_info'][$key]['payment_amount'] = floatval($doc_txn['order_info'][$key]['payable_amount']) + floatval($doc_txn['order_info'][$key]['payment_amount']);
                }
            }

            // update payment info for txn and all orders
            $set = [];
            $set['payment_info.payment_amount'] = (float) $doc_txn['payment_amount'] + (float) $record['amount'];
            $set['payment_info.payable_amount'] = $doc_txn['payment_info']['payable_amount'] - (float) $record['amount'];
            $set['order_info'] = $doc_txn['order_info'];
            $filter = ['transaction_code' => $transaction_code]; //1-311218-7083020
            $update = $this->dbo->update("masters", "transaction", $filter, $set, [], array("multi" => true));

        } elseif ($record['type'] == 3) { // penalty

            //get penalty details
            $filter = ['_id' => $this->dbo->id($record['penalty_id'])];
            $records = $this->dbo->find('masters', 'orders_refund_penalties', $filter, []);
            $set = ["status" => 5];
            $this->dbo->update('masters', 'orders_refund_penalties', $filter, $set, array(), array("multi" => true));
            $receiptamount = floatval($order['amount']);
            // generate receipt for penalty
            $associate_id = $branch_id = '';
            $receiptData = [
                "receiptamount" => $receiptamount, //MANDATORY
                "referencenumber" => $payload->txnId, //MANDATORY
                "paymentmode" => "100", //MANDATORY
                "order_id" => $record['order_id'], //MANDATORY
                "actionById" => "Ezetab",
                "actionByName" => "OMS",
                "type" => 2,
                "associate_id" => $associate_id, //OF PRESENT ACTIVE COMPONENT
                "branch_id" => $branch_id, //OF PRESENT ACTIVE COMPONENT
                "source" => 'Ezetab',
            ];
            $url = $this->config->getconfig('serverurl', "OMS/api/operation.php/v1/generateReceipt");
            $startTime = microtime(true);
            $buffer = $this->utility->my_curl($url, 'POST', json_encode($receiptData), 'json', null, 10);
            $this->log->logThirdPartyCall("OMS", $url, $startTime, $receiptData, $buffer);
        }

        // trigger email or sms
        //$this->trigger_email_sms_event($order_id, $status, $component_id, $mode_of_service, $service_type, $event_flag, $corporateid);

        return ['status' => 1, 'message' => 'Operation done successfully'];
    }

    public function get_payment_status($payload, $ticket)
    {
        $externalRefNumber = $payload->externalRefNumber;
        if (empty($externalRefNumber)) {
            return array("success" => 0, "code" => "10200", "message" => "Invalid Input, Required fields are missing");
        }

        $filter = ["externalRefNumber" => $externalRefNumber];
        $oldRes = $this->dbo->find('masters', 'ezetab_log', $filter, [], ["actiondate" => -1], 1, 0); // add sort by
        $record = $oldRes[0];
        $status_name = 'PENDING';
        if ($record['is_paid'] = 1) {
            $status_name = 'PAID';
        } elseif ($record['is_paid'] = 2) {
            $status_name = 'FAILED';
        }
        return array("success" => 1, "code" => "10100", "message" => "Data fetch successfully", "data" => ["status" => $record['is_paid'], "status_name" => $status_name]);
    }

    public function payment_completion_and_generate_receipt($order_ids = [], $payload)
    {

        foreach ($order_ids as $order_id) {
            // get order details
            $filter = ['_id' => (int) $order_id];
            $order = $this->dbo->findOne('masters', 'orders', $filter, []);
            $Old_paid_amount = $order['payment_info']['payment_amount'];
            $receiptamount = floatval($order['payment_info']['payable_amount']);
            // update order
            $paid_amount = floatval($Old_paid_amount) + $receiptamount;
            $set = [
                //"payment_info.payable_amount" => 0,
                "payment_info.payment_mode" => 100,
                "payment_info.payment_code" => 100,
                //"payment_info.paid_amount" => $paid_amount,
                "payment_info.payment_amount" => $paid_amount,
                "payment_info.payment_service" => "Ezetap",
            ];
            $this->dbo->update('masters', 'orders', $filter, $set, array(), array("multi" => true));
            $associate_id = $branch_id = '';
            foreach ($order['order']['provider_info'] as $key => $item3) {
                if ($item3['component_no'] == $order['active_component']) {
                    $associate_id = $item3['associate_id'];
                    $branch_id = $item3['associate_branch_id'];
                }
            }
            // create payment receipt
            $receiptData = [
                "receiptamount" => $receiptamount, //MANDATORY
                "referencenumber" => $payload->txnId, //MANDATORY
                "paymentmode" => "100", //MANDATORY
                "order_id" => $order_id, //MANDATORY
                "actionById" => "Ezetab",
                "actionByName" => "OMS",
                "type" => 1,
                "associate_id" => $associate_id, //OF PRESENT ACTIVE COMPONENT
                "branch_id" => $branch_id, //OF PRESENT ACTIVE COMPONENT
                "source" => 'Ezetab',
            ];
            $url = $this->config->getconfig('serverurl', "OMS/api/operation.php/v1/generateReceipt");
            $startTime = microtime(true);
            $buffer = $this->utility->my_curl($url, 'POST', json_encode($receiptData), 'json', null, 10);
            $this->log->logThirdPartyCall("OMS", $url, $startTime, $receiptData, $buffer);
            if ($order['order']['business']['is_package'] && $order['order']['patientinfo']['service_type'] == 14) {
                // call pandu's API async
                $url = $this->config->getconfig('serverurl', "OMS/api/operation.php/v1/createPackageChildOrders");
                $param = json_encode(["order_id" => $order_id]);
                async_curl_post_json($url, $param);
            }
        }
    }
}

/*
------------------Old receipt generation code  ---------------------
$receiptidseq = $this->utility->getNextSequence("receipt_id");
$receiptid = "R-000-" . $yr . "-" . $receiptidseq;
$receiptarray = array(
'receipt_id' => $receiptid,
'amount' => (double) $payload->amount,
'receipt_amount' => (double) $payload->amount,
'payment_type' => 'Ezetap',
'payment_mode' => 'Online Link',
'payment_collected' => 1,
'payment_submited' => 1,
'payment_ref_no' => $payload->txnId,
'payment_status' => '0', // 1:Pending 2:Partial Paid 3:Complete
'processed' => 'NP',
'receipt_date' => date('Y-m-d\TH:i:s') . '.000Z',
'submited_date' => date('Y-m-d\TH:i:s') . '.000Z',
'submitted_date' => date('Y-m-d\TH:i:s') . '.000Z',
);
$set = array("order.prepayment" => $receiptarray, "order.patientinfo.prepaid" => "1");
$this->dbo->update('masters', 'orders', $filter, $set, array(), array("multi" => true));

$filter = ["_id" => (int) $record['order_id']];
$set = array("order.prepayment" => $receiptarray, "order.patientinfo.prepaid" => "1");
$this->dbo->update('masters', 'orders', $filter, $set, array(), array("multi" => true));
 */
