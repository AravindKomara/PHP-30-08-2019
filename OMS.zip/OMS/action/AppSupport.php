<?php 
/* include '../dbo.php';
include '../utility.php'; */
ini_set('memory_limit', '-1');
//require_once "OrderWorkFlow.php";

class AppSupport extends Oms
{

    public function __construct()
    {
        parent::__construct();
    }

    public function getname()
    {
        return "AppSupport";
    }

    public function loginAppSupportUser($payload)
    {
        $username = $payload->user_id;
        //print_r($username);exit;
        $officer_id = $payload->officer_id;
        $password = md5($payload->password);

        $filter = array();
        $filter = array("password"=>$password);
    
        if(!empty($username))
        {
            $filter["user_id"] = (string)$username;
        }

        if(!empty($officer_id))
        {
            $filter["officer_id"] = (string)$officer_id;
        }


        //echo json_encode($filter);exit; 
        $project = array("name"=>1,"user_id"=>1); 

        $result = $this->dbo->findOne("masters","app_support_users",$filter,$project);
        //echo json_encode($result);exit; 

        if(empty($result)) 
        {
            return array("status"=>0,"message"=>"User Authentication Failed");
        }
        else
        {
            return array("status"=>1,"message"=>"User Authentication Successfull","data"=>$result);
        }
    }
}