<?php
/* include '../dbo.php';
include '../utility.php'; */
ini_set('memory_limit', '-1');
date_default_timezone_set("Asia/Calcutta");

class Orderinfo extends Oms
{

    public function __construct()
    {
        parent::__construct();
    }

    public function getname()
    {
        return "orderinfo";
    }

    public function getordersbyfilter($payload)
    {
        $addfields = array('$addFields' => array("business" => '$order.business'));
        $project = array(
            "_id" => 1,
            //"did"=>1,
            "odid" => 1,
            "wodid" => 1,
            "wid" => 1,
            "OStatus" => 1,
            "WOStatus" => 1,
            "assaigned_to" => 1,
            "mode_of_service" => 1,
            "order.patientinfo.mrn" => 1,
            "order.patientinfo.age" => 1,
            "order.patientinfo.gender" => 1,
            "order.patientinfo.city" => 1,
            "order.patientinfo.address" => 1,
            "order.patientinfo.barcode" => 1,
            "order.patientinfo.prescription_link_sent_dt" => 1,
            "order.patientinfo.prescription_link_sent_count" => 1,
            "active_component" => 1,
            "component_order" => 1,
            "order.patientinfo.pincode" => 1,
            "order.patientinfo.contact" => 1,
            "order.patientinfo.email" => 1,
            "order.patientinfo.name" => 1,
            "order.patientinfo.service_type" => 1,
            "order.patientinfo.service_subtype_id" => 1,
            "order.patientinfo.role_id" => 1,
            "order.patientinfo.skill_id" => 1,
            "order.patientinfo.delivery_lat" => 1,
            "order.patientinfo.delivery_lng" => 1,
            "order.patientinfo.scheduled_date" => 1,
            "order.patientinfo.expected_delivery_time" => 1,
            "order.patientinfo.gross_amount" => 1,
            "order.patientinfo.discount_amount" => 1,
            "order.patientinfo.net_amount" => 1,
            "order.patientinfo.wallet_amount" => 1,
            "order.patientinfo.voucher_amount" => 1,
            "order.patientinfo.medicine_delivery_charge" => 1,
            "order.patientinfo.voucher_code" => 1,
            "order.patientinfo.coupon_amount" => 1,
            "order.patientinfo.surge_amount" => 1,
            "order.patientinfo.payment_amount" => 1,
            "order.patientinfo.doctorId" => 1,
            "order.patientinfo.address_id" => 1,
            "order.patientinfo.address_id" => 1,
            "order.patientinfo.diag_sample_status" => 1,
            "order.patientinfo.consultationtype" => 1,
            "payment_info" => 1,
            "order.order_status.created_date" => 1,
            "order.order_status.order_id" => 1,
            "order.order_status.workorder_id" => 1,
            "order.order_status.mhoname" => 1,
            "order.order_status.receipts_tracker_id" => 1,
            "order.provider_info" => 1,
            "order.business" => 1,
            "order.orderitem" => 1,
            "billing" => 1,

            "order.ordertype" => 1,
            //"order.ordertyp"=>1,
            "order.patientinfo.patient_id" => 1,
            "order.patientinfo.order_id" => 1,
            "order.patientinfo.gender_pref" => 1,
            "order.order_status.order_id" => 1,
            "order.order_status.order_status" => 1,
            "order.order_status.order_did" => 1,
            "order.patientinfo.istransactioncare" => 1,
            "order.patientinfo.final_delivery_date" => 1,
            "order.patientinfo.order_status" => 1,
            "order.patientinfo.landmark" => 1,
            "order.patientinfo.corporateid" => 1,
            "order.patientinfo.corporatename" => 1,
            "order.assocdata" => 1,
            "order.vendorinfo" => 1,
            "transaction_code" => 1,
            "createdById" => 1,
            "channel" => 1,
            "createdByName" => 1,
            "data" => 1,
            "order.prescription_images" => 1,
            //"order.orderitem.report_delivery_date"=>1
        );

        $utilityobj = new Utility;
        $dbo_obj = new Dbo;
        $date_required = "0";
        $error_message = array();
        $necessary_project = array();
        //$sort = "_id";//commented due to an issue
        $responce = array("status" => 0, "message" => "data not found", "data" => array());

        //print_r($payload);
        //    exit;

        if (isset($payload->dateFilter)) {
            $sort = "order.order_status.created_date";
        } else {
            $sort = "_id";
        }

        if ($payload->transaction_code) {
            //$filter["transaction_code"]=array();
            $filter["transaction_code"] = array('$in' => $payload->transaction_code);

            $necessary_project["transaction_code"] = 1;
            $date_required = "0";
        } else {
            $filter["transaction_code"] = array('$exists' => true, '$nin' => array('', null));
            $necessary_project["transaction_code"] = 1;
        }
        //print_r($payload);exit;
        if (isset($payload->orderStatus) && is_array($payload->orderStatus)) {
            if (is_array($payload->orderStatus)) {
                if (isset($payload->NotInActionON) && is_array($payload->NotInActionON) && in_array("orderStatus", $payload->NotInActionON)) {
                    $filter["OStatus"] = array('$nin' => $payload->orderStatus);
                } else {
                    $filter["OStatus"] = array('$in' => $payload->orderStatus);
                }
                //$filter["OStatus"]=array('$in'=>$payload->orderStatus);
                $date_required = "1";
                $necessary_project["OStatus"] = 1;
            } else {
                $responce["message"] = "Please provide orderStatus value in array format.";
                return json_encode($responce);
            }
        }

        if (isset($payload->componentNo) && is_array($payload->componentNo)) {
            if (is_array($payload->componentNo)) {
                $filter["order.provider_info.component_no"] = $payload->componentNo;
                $date_required = "1";
                $necessary_project["order.provider_info.component_no"] = 1;
            } else {
                $responce["message"] = "Please provide componentNo in value format.";
                return json_encode($responce);
            }
        }

        if (isset($payload->officerId) && is_array($payload->officerId)) {
            if (is_array($payload->officerId)) {
                $filter["assaigned_to"] = array('$in' => $payload->officerId);
                $date_required = "1";
                $necessary_project["assaigned_to"] = 1;
            } else {
                $responce["message"] = "Please provide officerId value in array format.";
                return json_encode($responce);
            }
        }
        if (isset($payload->businessId)) {
            if (is_array($payload->businessId)) {
                $filter["order.patientinfo.service_type"] = array('$in' => $payload->businessId);
                $date_required = "0";
                $necessary_project["order.patientinfo.service_type"] = 1;
            } else {
                $responce["message"] = "Please provide businessId value in array format.";
                return json_encode($responce);
            }
        }

        if (isset($payload->city)) {
            if (is_array($payload->city)) {
                $filter["order.patientinfo.city"] = array('$in' => $payload->city);
                $date_required = "0";
                $necessary_project["order.patientinfo.city"] = 1;
            } else {
                $responce["message"] = "Please provide city field in array format.";
                return json_encode($responce);
            }
        }

        if (isset($payload->facilityId) && is_array($payload->facilityId)) {
            if (is_array($payload->facilityId)) {
                $filter["order.patientinfo.facility_id"] = array('$in' => $payload->facilityId);
                $date_required = "1";
                $necessary_project["order.patientinfo.facility_id"] = 1;
            } else {
                $responce["message"] = "Please provide facilityId value in array format.";
                return json_encode($responce);
            }
        }

        ///Addition of corporateId ,applicationNo filters
        //corporateid search
        if (isset($payload->corporateId) && is_array($payload->corporateId)) {
            if (is_array($payload->corporateId)) {
                $filter["order.patientinfo.corporateid"] = array('$in' => $payload->corporateId);
                $date_required = "1";
                $necessary_project["order.patientinfo.corporateid"] = 1;
            } else {
                $responce["message"] = "Please provide corporateid value in array format.";
                return json_encode($responce);
            }
        }

        //application_no search
        if (isset($payload->applicationNo) && is_array($payload->applicationNo)) {
            if (is_array($payload->applicationNo)) {
                $filter["order.patientinfo.application_no"] = array('$in' => $payload->applicationNo);
                $date_required = "1";
                $necessary_project["order.patientinfo.application_no"] = 1;
            } else {
                $responce["message"] = "Please provide application_no value in array format.";
                return json_encode($responce);
            }
        }

        ///

        //Addition for last associate search
        $secondfilter = array();
        if (isset($payload->associateId) && trim($payload->associateId) != "") {
            $filter["order.provider_info"] = array('$type' => 4); //only array values of provider_info
            $secondfilter["order.provider_info.associate_id"] = $payload->associateId;
            //$filter["order.provider_info"] = array('$type'=>4);//accept only array typed provider_info
            $date_required = "1";
            $necessary_project["order.provider_info"] = 1;
            /*  $necessary_project['provider_info'] = array('$arrayElemAt' => array('$order.provider_info', -1)); */
            //}
            if (isset($payload->associateBranchId) && trim($payload->associateBranchId) != "") {
                $secondfilter["order.provider_info.associate_branch_id"] = $payload->associateBranchId;
                //$date_required="1";
                //$necessary_project["order.provider_info"]=1;
                //$firstProject['provider_info']= array('$arrayElemAt'=>array('order.provider_info',-1));
            }
        } //Branch_id has significance only when associate_id is given

        if (isset($payload->mrn) && trim($payload->mrn) != "") {
            $filter["order.patientinfo.mrn"] = $payload->mrn;
            $necessary_project["order.patientinfo.mrn"] = 1;
            $date_required = "0";
        } else if (is_array($payload->mrn) && count($payload->mrn) > 0) {
            $filter["order.patientinfo.mrn"] = array('$in' => $payload->mrn);
            $necessary_project["order.patientinfo.mrn"] = 1;
            $date_required = "0";
        }
        if (isset($payload->order_id) && trim($payload->order_id) != "") {
            $filter["_id"] = (int) $payload->order_id;
            $necessary_project["_id"] = 1;
            $date_required = "0";
        } else if (isset($payload->order_did) && trim($payload->order_did) != "") {
            $filter["odid"] = $payload->order_did;
            $necessary_project["odid"] = 1;
            $date_required = "0";
        } else if (isset($payload->workorder_id) && trim($payload->workorder_id) != "") {
            $filter["wid"] = (int) $payload->workorder_id;
            $necessary_project["wid"] = 1;
            $date_required = "0";
        } else if (isset($payload->workorder_did) && trim($payload->workorder_did) != "") {
            $filter["wodid"] = $payload->workorder_did;
            $necessary_project["wodid"] = 1;
            $date_required = "0";
        }

        //print_r($date_required);exit;
        if ($date_required == "1" || count($filter) < 1 || (isset($payload->startDate) && isset($payload->endDate))) {
            //echo "11111";exit;
            $searchdatetype = "order.order_status.created_date";
            if (isset($payload->dateFilter) && trim($payload->dateFilter) != "" && in_array($payload->dateFilter, array("created_date", "scheduled_date"
                ///
                , "last_updated_on",
                ///
            ))) {
                if ($payload->dateFilter == "scheduled_date") {
                    $searchdatetype = "order.patientinfo.scheduled_date";
                } else if ($payload->dateFilter == "created_date") {
                    $searchdatetype = "order.order_status.created_date";
                }
                ///
                else if ($payload->dateFilter == "last_updated_on") {
                    $searchdatetype = "order.order_status.last_updated_on";
                }
                ///
            }
            $necessary_project[$searchdatetype] = 1;
            $sort = $searchdatetype;

            if (isset($payload->startDate) && isset($payload->endDate) && $payload->startDate != "" && $payload->endDate != "") {
                $end_date = date('Y-m-d', strtotime('+1 days', strtotime($payload->endDate)));
                $filter[$searchdatetype] = array('$gte' => $payload->startDate, '$lt' => $end_date);
                if ($utilityobj->validateDate_Ymd($payload->startDate) == false || $utilityobj->validateDate_Ymd($payload->endDate) == false) {
                    $responce["message"] = "startDate and endDate format is invalid. please provide date in yyyy-mm-dd format.";
                    return json_encode($responce);
                }
            } else {
                $responce["message"] = "Please provide start date and end date.";
                return json_encode($responce);
            }
        }

        $lookup = array(
            'from' => 'workflow_status',
            'let' => array
            (
                'mode_of_service' => '$mode_of_service',
                'service_type' => '$order.patientinfo.service_type',
                'order_status' => '$OStatus',
                'component' => '$active_component',
            ),
            'pipeline' => array(array
                (
                    '$match' => array
                    ('$expr' => array
                        ('$and' => array(
                            array('$eq' => array('$status', '$$order_status')),
                            array('$eq' => array('$Bid', '$$service_type')),
                            array('$eq' => array('$MOSid', '$$mode_of_service')),
                            array('$eq' => array('$Workflow', '$$component')),
                        ),
                        ),
                    )),
                array('$project' => array("Nomenclature" => 1, '_id' => 0, "reschedule_block" => 1, "cancel_block" => 1)),
            ),
            'as' => 'data',
        );

        //"reschedule_block":{$or:["$order.business.reschedule_block","$data.reschedule_block"]},
        //"cancel_bock":{$or:["$order.business.reschedule_block","$data.reschedule_block"]}

        $new_project = ["reschedule_block" => array('$or' => array('$business.reschedule_block', '$data.reschedule_block')),
            "cancel_block" => array('$or' => array('$business.cancel_block', '$data.cancel_block'))];
        // set the necessary projection
        $project = array_merge($project, $necessary_project, $new_project);
        //$project = array_merge($project,$necessary_project);

        // Setting of pipeline for aggregatev(if search by associate_id , we must query on last array element so we do the match after projecting last provider_info array element)

        if (!empty($secondfilter)) {

            $pipeline = array(array('$match' => $filter), $addfields, array('$lookup' => $lookup), array('$unwind' => '$data'),
                array('$project' => $project),
                array('$match' => $secondfilter));
        } else {
            $pipeline = array(array('$match' => $filter), $addfields, array('$lookup' => $lookup), array('$unwind' => '$data'), array('$project' => $project));
        }

        $lastproject = array();

        //Remove the projected array last value of provider_info from projection
        if (isset($necessary_project['provider_info'])) {
            $lastproject['provider_info'] = 0;
        }

        // by default care@home item activity is disabled, if user want then activity will come(is_care_activity=1).
        if ((!isset($payload->is_care_activity) && trim($payload->is_care_activity) == "") || trim($payload->is_care_activity) == "0") {
            $lastproject['order.orderitem.activity'] = 0;
        }

        //Only if any of above conditions hold true
        if (!empty($lastproject)) {
            array_push($pipeline, array('$project' => $lastproject));
        }
        //array_push($pipeline,array('$limit'=>));

        // dynamic sort
        if (isset($payload->sortBy)) {
            if (trim($payload->sortBy) == "ASE" || trim($payload->sortBy) == "ase") {
                array_push($pipeline, array('$sort' => array($sort => 1)));
            }
            if (trim($payload->sortBy) == "DESC" || trim($payload->sortBy) == "desc") {
                array_push($pipeline, array('$sort' => array($sort => -1)));
            }
        }

        if (isset($payload->skip) && isset($payload->limit)) {
            array_push($pipeline, array('$skip' => $payload->skip), array('$limit' => $payload->limit));
        }

        // end the setting of pipeline for aggregate
        //echo json_encode($pipeline); exit;
        //call the aggregate function

        $orderdetails = $dbo_obj->aggregate('masters', 'orders', $pipeline);

        //$orderdetails=$dbo_obj->find('masters','orders',$filter,$project,"");
        if (count($orderdetails) > 0) {
            $responce["status"] = 1;
            $responce["message"] = "Success";
        }
        /*  foreach ($orderdetails['orders'] as $key => $val) {
        $orderdetails['orders'][$key]['reschedule_block'] = ($orderdetails['orders'][$key]['reschedule_block']) ? $orderdetails['orders'][$key]['reschedule_block'] : 0;
        $orderdetails['orders'][$key]['cancel_block'] = ($orderdetails['orders'][$key]['cancel_block']) ? $orderdetails['orders'][$key]['cancel_block'] : 0;
        } */
        $responce["data"] = $orderdetails;
        $responce["countn"] = count($orderdetails);
        // for reschedule_block

        return $responce;

    } //end of function

    public function getMyOrders($payload)
    {
        //print_r($payload);exit;
        $utility_obj = new Utility;
        $dbo_obj = new Dbo;
        $config_obj = new Config;
        $payload->type = $payload->datetype;

        $responce = array("status" => 0, "message" => "data not found");
        //$sort = "_id";
        if (isset($payload->orderDid) && $payload->orderDid != "") {
            $request = array("order_did" => $payload->orderDid, "mrn" => $payload->mrn);

            $order = $this->getordersbyfilter((object) $request);

            $final_result = array("status" => 1, "message" => "success", "data" => array("orders" => $order[data]));

            return $final_result;

        }

        if (isset($payload->status) && is_array($payload->status)) {
            if (is_array($payload->status)) {
                $status = array('$in' => $payload->status);
            } else {
                $responce["message"] = "Please provide status value in array format.";
                return $responce;
            }
        }

        $data = $config_obj->search_by_status($payload->status, $payload);
        //echo json_encode($data['OStatus']['$in']);exit;
        $OStatus = $data['OStatus']['$in'];

        $filter = array(
            "order.patientinfo.mrn" => array('$in' => $payload->mrn),
            //"order.patientinfo.mrn"=>$payload->mrn,
        );
        if (isset($payload->businessId) and $payload->businessId != null) {
            $filter["order.patientinfo.service_type"] = array('$in' => $payload->businessId);
        }

        //echo json_encode($filter);exit;
        $filter = array_merge($filter, $data);
        $filter = array('$match' => $filter);

        //echo json_encode($filter);exit;

        $group = array(
            '$group' => array('_id' => array('transaction_code' => '$transaction_code',
                "id" => '$_id',
            )),
        );
        $sort = array(
            '$sort' => array('_id.id' => -1),
        );
        /*$skip = array('$skip'=>$payload->skip);
        $limit = array('$limit'=>$payload->limit);*/

        //preparing the pipeline for final push
        $pipeline = array($filter, $group, $sort);
        //echo json_encode($pipeline);exit;

        $result = $dbo_obj->aggregate('masters', 'orders', $pipeline);
        //echo json_encode($result);exit;

        foreach ($result as $res) {
            if ($res['_id']['transaction_code']) {
                $txn_code[] = $res['_id']['transaction_code'];
            }

        }

        $result = array_unique($txn_code, SORT_STRING);

        $count = count($result);

        //print_r($result);exit;
        if (!($skip == "") && !($limit == "")) {
            $txn_code = array_slice($result);
        } else {
            $txn_code = array_slice($result, $payload->skip, $payload->limit);
        }

        //print_r($txn_code);exit;
        //print_r($payload->type);exit;

        if (empty($payload->datetype)) {
            $request = array(
                //"dateFilter"=>$payload->type,
                //"startDate"=>$payload->from_date,
                //"endDate"=>$payload->to_date,
                "orderStatus" => $OStatus,
                "businessId" => $payload->businessId,
                "transaction_code" => $txn_code,
                "mrn" => $payload->mrn,
                //"skip"=> $payload->skip,
                //"limit" => $payload->limit,
                "sortBy" => $payload->sortBy,
            );
        } else {
            $request = array(
                "dateFilter" => $payload->datetype,
                "startDate" => $payload->from_date,
                "endDate" => $payload->to_date,
                "orderStatus" => $OStatus,
                "businessId" => $payload->businessId,
                "transaction_code" => $txn_code,
                "mrn" => $payload->mrn,
                //"skip"=> $payload->skip,
                //"limit" => $payload->limit,
                "sortBy" => $payload->sortBy,
            );
        }
        //echo json_encode($request);exit;
        $order = $this->getordersbyfilter((object) $request);

        $final_result = array("status" => 1, "message" => "success", "data" => array("orders" => $order[data]), "txn" => $txn_code, "count" => $count);

        return $final_result;
    } //end of function

    public function getMyAppointments($payload)
    {
        $utility_obj = new Utility;
        $dbo_obj = new Dbo;
        $config_obj = new Config;

        $responce = array("status" => 0, "message" => "data not found");
        //$sort = "_id";

        if (isset($payload->status) && is_array($payload->status)) {
            if (is_array($payload->status)) {
                $status = array('$in' => $payload->status);
            } else {
                $responce["message"] = "Please provide status value in array format.";
                return $responce;
            }
        }

        $dataapp = $config_obj->search_by_status_appointment($payload->status, $payload);
        //print_r($dataapp);exit;

        $filterapp = array(
            "mrn" => array('$in' => $payload->mrn),
            //"mrn"=>$payload->mrn
        );
        if (isset($payload->transaction_code)) {
            $filterapp['transaction_code'] = array('$in' => $payload->transaction_code);
        }

        $filterapp = array_merge($filterapp, $dataapp);
        $filterapp = array('$match' => $filterapp);

        $pipeline = array($filterapp);
        //echo json_encode($pipeline);exit;

        $resultapp = $dbo_obj->aggregate('masters', 'appointments', $pipeline);
        //echo json_encode($resultapp);exit;

        return $resultapp;
    } //end of function

    public function getAppointments($payload)
    {
        $utility_obj = new Utility;
        $dbo_obj = new Dbo;
        $config_obj = new Config;

        $responce = array("status" => 0, "message" => "data not found");
        //$sort = "_id";

        //print_r($payload);exit;
        if (isset($payload->from_date) && trim($payload->from_date) != "") {
            $from_date = $payload->from_date;
        } else {
            $responce["message"] = "Please provide from_date value";
            return $responce;
        }

        if (isset($payload->to_date) && trim($payload->to_date) != "") {
            $to_date = $payload->to_date;
        } else {
            $responce["message"] = "Please provide to_date value";
            return $responce;
        }

        if (isset($payload->status) && is_array($payload->status)) {
            if (is_array($payload->status)) {
                $status = array('$in' => $payload->status);
            } else {
                $responce["message"] = "Please provide status value in array format.";
                return $responce;
            }
        }

        //print_r($payload->mrn);exit;
        /* if(isset($payload->mrn) && is_array($payload->mrn))
        {
        if(is_array($payload->mrn))
        {
        $mrn=array('$in'=>$payload->mrn);
        }
        else
        {
        $responce["message"]="Please provide mrn value in array format.";
        return $responce;
        }
        } */

        if (empty($payload->type)) {
            $responce["message"] = "Please provide type value as either created_date or scheduled_date";
            return $responce;
        }

        if ($payload->type == "scheduled_date" && $payload->status == 1) {
            $response["message"] = "You cannot search with scheduled_date when status is 1. Try searching with created_date";
            return $response;
        }

        $dataapp = $config_obj->search_by_status_appointment($payload->status, $payload);
        //print_r($dataapp);exit;
        $requestapp = array(
            "type" => $payload->type,
            "from_date" => $payload->from_date,
            "to_date" => $payload->to_date,
            "status" => $dataapp,
            "mrn" => $payload->mrn,
            "doctorId" => $payload->doctorId,
            "skip" => $payload->skip,
            "limit" => $payload->limit,

        );
        $appointment = $this->paginate_appointments((object) $requestapp);

    }

    public function get_appointments($request)
    {

        $filter = array(
            "transaction_code" => array('$in' => $request->transaction_code),
            "status" => $request->status,
        );

        $project = array();
        //print_r($filter);exit;
        $result = $this->dbo->find('masters', 'appointments', $filter, $project, array());
        //print_r($result);exit;
        return $result;
    } //end of function

    public function paginate_appointments($requestapp)
    {

        $filter = array(
            "transaction_code" => array('$in' => $requestapp->transaction_code),
            "status" => $requestapp->status,
        );

        $skip = $requestapp->skip;
        $limit = $requestapp->limit;

        //$options = array('skip'=>$skip,'limit'=>$limit);
        //print_r($filter);exit;
        $project = array();

        $result = $this->dbo->find('masters', 'appointments', $filter, $project, array(),
            $skip, $limit);
        //print_r($result);exit;
        return $result;
    } //end of function

    public function orderHistory($payload)
    {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "order_history_start", json_encode($payload), (string) $ticket);
        if (empty($payload->officerId)) {
            $response = array("status" => 0, "message" => "please provide officerId");
            return $response;

        }

        if (empty($payload->from_date)) {
            $response = array("status" => 0, "message" => "please provide from_date");
            return $response;
        }

        if (empty($payload->to_date)) {
            $response = array("status" => 0, "message" => "please provide to_date");
            return $response;
        }

        $filter = array(
            "orderinfo.assignedto" => $payload->officerId,
            "orderinfo.order_status" => array('$in' => array(6, 15, 16, 22, 106, "6", "15", "16", "22", "106")),
            "orderinfo.scheduled_date" => array('$gte' => $payload->from_date, '$lte' => $payload->to_date),
        );

        $lookup = array(
            "from" => "orders",
            "localField" => "orderinfo.order_id",
            "foreignField" => "_id",
            "as" => "Details",
        );
        $unwind = array('$unwind' => '$Details');

        $project1 = array("order" => '$Details');

        $project2 = array(
            "order.odid" => 1,
            "order.wodid" => 1,
            "order.wid" => 1,
            "order.OStatus" => 1,
            "order.WOStatus" => 1,
            "order.order.patientinfo.mrn" => 1,
            "order.order.patientinfo.age" => 1,
            "order.order.patientinfo.gender" => 1,
            "order.order.patientinfo.city" => 1,
            "order.order.patientinfo.address" => 1,
            "order.order.patientinfo.pincode" => 1,
            "order.order.patientinfo.contact" => 1,
            "order.order.patientinfo.email" => 1,
            "order.order.patientinfo.name" => 1,
            "order.order.patientinfo.service_type" => 1,
            "order.order.patientinfo.service_subtype_id" => 1,
            "order.order.patientinfo.role_id" => 1,
            "order.order.patientinfo.skill_id" => 1,
            "order.order.patientinfo.delivery_lat" => 1,
            "order.order.patientinfo.delivery_lng" => 1,
            "order.order.patientinfo.scheduled_date" => 1,
            "order.order.patientinfo.expected_delivery_time" => 1,
            "order.order.patientinfo.gross_amount" => 1,
            "order.order.patientinfo.discount_amount" => 1,
            "order.order.patientinfo.net_amount" => 1,
            "order.order.patientinfo.wallet_amount" => 1,
            "order.order.patientinfo.voucher_amount" => 1,
            // "order.order.patientinfo.medicine_delivery_charge"=>1,
            "order.order.patientinfo.voucher_code" => 1,
            "order.order.patientinfo.coupon_amount" => 1,
            //"order.order.patientinfo.surge_amount"=>1,
            "order.order.patientinfo.payment_amount" => 1,
            "order.order.patientinfo.popname" => 1,
            "order.order.order_status.created_date" => 1,
            "order.order.order_status.order_id" => 1,
            "order.order.order_status.workorder_id" => 1,
            "order.order.order_status.mhoname" => 1,
            "order.order.order_status.receipts_tracker_id" => 1,
            "order.order.provider_info" => 1,
            "order.order.business" => 1,
            //"order.order.orderitem"=>1,
            "order.billing" => 1,
            "order.order.business" => 1,

            "order.order.ordertype" => 1,
            //"order.ordertyp"=>1,
            "order.order.patientinfo.patient_id" => 1,
            "order.order.patientinfo.order_id" => 1,
            "order.order.patientinfo.gender_pref" => 1,
            "order.order.order_status.order_id" => 1,
            "order.order.order_status.order_status" => 1,
            "order.order.order_status.order_did" => 1,
            "order.order.patientinfo.istransactioncare" => 1,
            "order.order.patientinfo.order_status" => 1,
            "order.order.patientinfo.landmark" => 1,
            "order.order.patientinfo.corporatename" => 1,
            "order.order.assocdata" => 1,
            "order.transaction_code" => 1,
            "order.createdById" => 1,
            "order.channel" => 1,
            "order.active_component" => 1,
            "order.mode_of_service" => 1,
            "order.createdByName" => 1,
        );

        $skip = array('$skip' => $payload->skip);
        $limit = array('$limit' => $payload->limit);

        $lookup_status = array(
            'from' => 'workflow_status',
            'let' => array
            (
                'mode_of_service' => '$order.mode_of_service',
                'service_type' => '$order.order.patientinfo.service_type',
                'order_status' => '$order.OStatus',
                'component' => '$order.active_component',
            ),
            'pipeline' => array(array
                (
                    '$match' => array
                    ('$expr' => array
                        ('$and' => array(
                            array('$eq' => array('$status', '$$order_status')),
                            array('$eq' => array('$Bid', '$$service_type')),
                            array('$eq' => array('$MOSid', '$$mode_of_service')),
                            array('$eq' => array('$Workflow', '$$component')),
                        ),
                        ),
                    )),
                array('$project' => array("Nomenclature" => 1, '_id' => 0)),
            ),
            'as' => 'data',
        );

        $pipeline = array(array('$match' => $filter), array('$lookup' => $lookup), $unwind, array('$project' => $project1),
            array('$project' => $project2), $skip, $limit, array('$lookup' => $lookup_status));
        //print_r($pipeline);exit;
        //echo json_encode($pipeline);exit;

        $result = $this->dbo->aggregate("masters", "workorders", $pipeline);

        $count = count($result);
        //print_r($count);exit;

        if ($count > 0) {
            $response = array("status" => 1, "count" => $count, "message" => "Order Retrieved Successfully", "data" => $result);
        } else {
            $response = array("status" => 0, "count" => $count, "message" => "No Data Found");
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "order_history_end", json_encode($response), (string) $ticket);

        return $response;
        //print_r($result);exit;
    } //end of function

    //PREVIOUS FUNCTION
    /* public function getAppointmentsDetails($payload)
    {
    $status = $this->config->search_by_status_appointment($payload->status,$payload);

    if(!empty($payload->key)&&is_array($payload->value))
    {
    if($payload->key=="doctorId")
    {
    //echo "123";exit;
    $match = array(
    "order.orderitem.caregiverid"=>array('$in'=>$payload->value),
    "OStatus"=>$status[status],
    "order.patientinfo.is_consultation"=>1
    );

    $project = array
    (
    'appointmentId' =>'$_id',
    'order_id' => '$_id',
    'mrn' =>'$order.patientinfo.mrn',
    'conferenceType' =>'$order.patientinfo.conferenceType',
    'consultationType' => '$order.patientinfo.consultationType',
    'doctorId' =>'$order.orderitem.caregiverid',
    'reason' =>'$order.patientinfo.reason',
    'scheduledTime' =>'$order.patientinfo.scheduled_date',
    'endDateTime' =>'',
    'duration' =>'$order.patientinfo.duration',
    'status' =>'$OStatus',
    'createdBy' =>'$order.patientinfo.actionById',
    'createdDate' =>'$order.order_status.created_date',
    'engagementLevel' =>'$mode_of_service',
    'corporateid' =>'$order.patientinfo.corporateid',
    'corporatename' =>'$order.patientinfo.corporatename',
    'mer' => '$order.patientinfo.mer'
    );

    $skip = (string)$payload->skip;
    //print_r($skip);exit;
    $limit =(string) $payload->limit;
    //print_r($skip);exit;

    $unwind = array('path'=>'$order.orderitem');

    $pipeline = array(array('$match'=>$match),array('$unwind'=>$unwind),array('$project'=>$project));
    if(!( $skip=="") && !( $limit==""))
    {
    array_push($pipeline,array('$skip'=>(int)$skip),array('$limit'=>(int)$limit));

    }

    //echo json_encode($pipeline);exit;

    //echo json_encode($pipeline);exit;
    $result = $this->dbo->aggregate("masters","orders",$pipeline);

    $response = array("status"=>1,"message"=>"Data Found","count"=>count($result),"data"=>$result);
    return $response;
    }

    if($payload->key=="mrn")
    {
    //echo "1224";exit;
    $match = array(
    "order.patientinfo.mrn"=>array('$in'=>$payload->value),
    "OStatus"=>$status[status],
    "order.patientinfo.is_consultation"=>1
    );

    $project = array
    (
    'appointmentId' =>'$_id',
    'order_id' => '$_id',
    'mrn' =>'$order.patientinfo.mrn',
    'conferenceType' =>'$order.patientinfo.conferenceType',
    'consultationType' => '$order.patientinfo.consultationType',
    'doctorId' =>'$order.orderitem.0.caregiverid',
    'createdBy' => '$createdById',
    'reason' =>'$order.patientinfo.reason',
    'scheduledTime' =>'$order.patientinfo.scheduled_date',
    'endDateTime' =>'',
    'duration' =>'$order.patientinfo.duration',
    'status' =>'$OStatus',
    'createdBy' =>'$order.patientinfo.actionById',
    'createdDate' =>'$order.order_status.created_date',
    'engagementLevel' =>'$mode_of_service',
    'corporateid' =>'$order.patientinfo.corporateid',
    'corporatename' =>'$order.patientinfo.corporatename',
    'mer' => '$order.patientinfo.mer'
    );

    $skip = (string)$payload->skip;
    //print_r($skip);exit;
    $limit =(string) $payload->limit;
    //print_r($skip);exit;

    $unwind = array('path'=>'$order.orderitem');

    $pipeline = array(array('$match'=>$match),array('$unwind'=>$unwind),array('$project'=>$project));
    if(!( $skip=="") && !( $limit==""))
    {
    array_push($pipeline,array('$skip'=>(int)$skip),array('$limit'=>(int)$limit));

    }

    //echo json_encode($pipeline);exit;

    //echo json_encode($pipeline);exit;
    $result = $this->dbo->aggregate("masters","orders",$pipeline);

    $response = array("status"=>1,"message"=>"Data Found","count"=>count($result),"data"=>$result);
    return $response;
    }

    if($payload->key=="appointmentId")
    {
    //echo "1224";exit;
    $match = array(
    "_id"=>array('$in'=>$payload->value),
    "OStatus"=>$status[status],
    "order.patientinfo.is_consultation"=>1
    );

    $project = array
    (
    'appointmentId' =>'$_id',
    'order_id' => '$_id',
    'mrn' =>'$order.patientinfo.mrn',
    'conferenceType' =>'$order.patientinfo.conferenceType',
    'consultationType' => '$order.patientinfo.consultationType',
    'doctorId' =>'$order.orderitem.0.caregiverid',
    'reason' =>'$order.patientinfo.reason',
    'scheduledTime' =>'$order.patientinfo.scheduled_date',
    'endDateTime' =>'',
    'duration' =>'$order.patientinfo.duration',
    'status' =>'$OStatus',
    'createdBy' =>'$order.patientinfo.actionById',
    'createdDate' =>'$order.order_status.created_date',
    'engagementLevel' =>'$mode_of_service',
    'corporateid' =>'$order.patientinfo.corporateid',
    'corporatename' =>'$order.patientinfo.corporatename',
    'mer' => '$order.patientinfo.mer'
    );

    $skip = (string)$payload->skip;
    //print_r($skip);exit;
    $limit =(string) $payload->limit;
    //print_r($skip);exit;

    $unwind = array('path'=>'$order.orderitem');

    $pipeline = array(array('$match'=>$match),array('$unwind'=>$unwind),array('$project'=>$project));
    if(!( $skip=="") && !( $limit==""))
    {
    array_push($pipeline,array('$skip'=>(int)$skip),array('$limit'=>(int)$limit));

    }

    //echo json_encode($pipeline);exit;

    $result = $this->dbo->aggregate("masters","orders",$pipeline);

    $response = array("status"=>1,"message"=>"Data Found","count"=>count($result),"data"=>$result);
    return $response;
    }
    }
    else
    {
    $response = array("status"=>0,"message"=>"Please provide request parameters in correct format","data"=>$result);
    return $response;
    }
    }//end of function
     */

    public function getItemCodeCountByCity($payload, $ticket)
    {

        if (empty($payload->itemcode)) {
            $response = array("status" => 0, "message" => "Please provide itemcode");
            return $response;
        }

        if (empty($payload->from_date)) {
            $response = array("status" => 0, "message" => "Please provide from_date");
            return $response;
        }

        if (empty($payload->to_date)) {
            $response = array("status" => 0, "message" => "Please provide to_date");
            return $response;
        }

        $filter = array('$match' => array(
            "order.orderitem.item_code" => $payload->itemcode,
            "order.order_status.created_date" => array('$gte' => $payload->from_date, '$lte' => $payload->to_date),
            "order.patientinfo.city" => array('$nin' => array('Array', 'No Records Found')),
        ));

        $group = array(
            '$group' => array(
                "_id" => '$order.patientinfo.city',
                'count' => array('$sum' => 1),
            ),
        );

        $pipeline = array($filter, $group);
        //echo json_encode($pipeline);exit;

        $result = $this->dbo->aggregate("masters", "orders", $pipeline);
        $city_data = array();
        foreach ($result as $city) {
            if ($city['_id'] != null && $city['_id'] != '' && strlen($city) < 20) {
                array_push($city_data, $city);
            }
        }
        /*print_r($city_data);
        exit;*/
        return $city_data;
    }

    public function getOrderCountByState($payload, $ticket)
    {

        $filter = array(
            '$match' => array(
                "order.order_status.created_date" => array('$gte' => $payload->from_date, '$lte' => $payload->to_date),
                "order.patientinfo.state" => array('$in' => $payload->states),
            ),
        );

        $project = array(
            '$project' => array(
                "OStatus" => 1,
                "result" => array(
                    '$_id',
                    '$OStatus',
                    '$order.patientinfo.scheduled_date',
                    '$assaigned_to',
                    '$order.order_status.mhoname',
                ),
            ),
        );

        $group = array(
            '$group' => array(
                "_id" => '$OStatus',
                'count' => array('$sum' => 1),
                'data' => array('$addToSet' => '$result'),
            ),
        );

        $sort = array(
            '$sort' => array('count' => 1),
        );

        $pipeline = array($filter, $project, $group, $sort);
        //echo json_encode($pipeline);

        $result = $this->dbo->aggregate("masters", "orders", $pipeline);
        //echo json_encode($result);

        if (empty($result)) {
            $response = array("status" => 0, "message" => "Operation Failed", "count" => count($result), "data" => $result);
            return $response;
        } else {
            $response = array("status" => 1, "message" => "Operation Success", "count" => count($result), "data" => $result);
            return $response;
        }
    }

    public function couponUsageCount($payload, $ticket)
    {
        $coupon = (string) $payload->coupon;
        $filter = array(
            '$match' => array(
                "order.patientinfo.coupon" => array('$regex' => $coupon, '$options' => "i"),
                "order.patientinfo.mrn" => array('$in' => $payload->mrn),
                "order.order_status.order_status" => array('$ne' => array("17", "11")),
            ),
        );

        /*$group = array(
        '$group' => array(
        "_id" =>array('$toLower'=>'$order.patientinfo.coupon'),
        'count' => array('$sum' => 1),
        ),
        );*/

        $sort = array(
            '$sort' => array('count' => -1),
        );

        $group = array(
            '$group' => array(
                "_id" => array('$toLower' => '$order.patientinfo.coupon'),
                "UN_transaction_code" => array('$addToSet' => '$transaction_code'),
            ),
        );
        $unwind = array('$unwind' => '$UN_transaction_code');
        $group1 = array(
            '$group' => array(
                "_id" => array('$toLower' => '$_id'),
                'count' => array('$sum' => 1),
            ),
        );

        $pipeline = array($filter, $group, $unwind, $group1, $sort);
        //$pipeline = array($filter, $group, $sort);
        //echo json_encode($pipeline);exit;

        $result = $this->dbo->aggregate("masters", "orders", $pipeline);
        //echo json_encode($result);

        foreach ($result as $key => $value) 
        {
            $result[$key]['name'] = $value['_id'];
            unset($result[$key]['_id']);
        }

        if (empty($result)) {
            $response = array("status" => 0, "message" => "No Data Found", "data" => array(array("count" => 0)));
            return $response;
        } else {
            $response = array("status" => 1, "message" => "Data Found", "data" => $result);
            return $response;
        }
    } //end of function

    public function getAllOrderStatusInfoByMrn($payload, $ticket)
    {

        $statuses = $this->dbo->findOne("masters", "order_statuses", array(), array());
        //return $result1;
        //var_dump($result1[1]);exit;

        $filter = array(
            '$match' => array(
                "order.patientinfo.mrn" => array('$in' => $payload->mrn),
                "OStatus" => array('$nin' => array(11)),
            ),
        );

        $group = array(
            '$group' => array(
                "_id" => '$OStatus',
                'count' => array('$sum' => 1),
            ),
        );

        $sort = array(
            '$sort' => array('count' => -1),
        );

        $pipeline = array($filter, $group, $sort);
        //echo json_encode($pipeline);exit;
        $response = array();
        $result = $this->dbo->aggregate("masters", "orders", $pipeline);
        //print_r($result); exit;
        foreach ($result as $key => $item) {
            $count = $count + $item['count'];
            if ($item["_id"] == 6) {
                $response["Completed"]["status"] = "Completed";
                $response["Completed"]["count"] = $response["Completed"]["count"] + $item['count'];
            } else if ($item["_id"] == 8) {
                $response["Cancelled"]["status"] = "Cancelled";
                $response["Cancelled"]["count"] = $response["Cancelled"]["count"] + $item['count'];
            } else if ($item["_id"] == 17) {
                $response["Draft"]["status"] = "Draft";
                $response["Draft"]["count"] = $response["Draft"]["count"] + $item['count'];
            } else {
                $response["Inprogress"]["status"] = "Inprogress";
                $response["Inprogress"]["count"] = $response["Inprogress"]["count"] + $item['count'];
            }
        }
        //$result["totalCount"] = $count;
        if (empty($result)) {
            $response = array("status" => 0, "message" => "Operation Failed", "data" => []);
            return $response;
        } else {
            $response = array("status" => 1, "message" => "Operation Success", "data" => ["total_count" => $count, "statuswise_count" => $response]);
            return $response;
        }
    }

    public function createlog($role, $order_status, $action, $userid, $username, $description, $current_w_id, $current_w_did, $orderid, $reason, $comment, $assigned_pop_id, $popname, $extraFields = array(), $dateChanged, $scheduledDate, $component_no = 0)
    {
        $orderlog = array(
            "created_date" => date("Y-m-d H:i:s"),
            "createdDate" => $this->utility->getCurrenttime(),
            "role" => $role,
            "log_type" => 'ORDER', // ORDER || FINANCE
            "log_sub_type" => 'ORDER', // ORDER:ORDER, FINANCE:PENALTY,REFUND,RECEIPT_GEN
            "order_status" => $order_status,
            "action" => $action,
            "actionById" => $userid,
            "actionByName" => $username,
            'description' => $description,
            'wid' => $current_w_id,
            'wodid' => $current_w_did,
            'reason' => $reason,
            'comment' => $comment,
            "facility_id" => $assigned_pop_id,
            'popname' => $popname,
            'component_no' => $component_no,
        );
        if (!empty($extraFields) && is_array($extraFields)) {
            $orderlog = array_merge($orderlog, $extraFields);
        }
        if (isset($extraFields["businessId"]) && isset($extraFields["MOSID"])) {
            $orderlog["status_name"] = $this->utility->getStatusName($extraFields["businessId"], $extraFields["MOSID"], $component_no, $order_status);
        }
        $set = array();
        //IF SCHEDULED DATE IS CHANGED WE NEED TO UPDATE IN ORDER OBJECT OF ORDERLOG
        if ($dateChanged && $scheduledDate != "") {
            $set['order.patientinfo.scheduled_date'] = $scheduledDate;
            $set['order.patientinfo.servicedate'] = $this->dbo->date(strtotime($scheduledDate));
        }

        $filter = array('_id' => (int) $orderid);
        $push = array('order_log' => $orderlog);
        $log = $this->dbo->update("masters", "orderlog", $filter, $set, $push, array("multiple" => true));
        //print_r($orderlog);exit;

        // trigger RTCT API Async
        $url = $this->config->getconfig('serverurl', 'OMS/api/rtct.php/v3/rtct/orders/event/set');
        $this->utility->async_curl($url, json_encode(['order_id' => $orderid]));
        
        return array("requestdata" => $push, "result" => $log);
        if ($log['nModified'] == 0) {
            //echo "Orderlog updated for ".$orderid."failed\n";
            return $orderid;
        }
        return 0;

    }

    public function changeWoStatus($status, $order_id, $order_details, $current_w_id, $assignedid, $assignedname)
    {

        $current_time = $this->utility->getCurrentdatetimesimple();

        $details = $order_details[$order_id];
        $setarray = array(
            'orderinfo.order_status' => $status,
            'orderinfo.final_status' => $status,
            'orderinfo.reason' => $details[reason],
            'orderinfo.modified_time' => $current_time,
        );
        if (isset($details[associate_id]) and $details[associate_id] != null) {
            $setarray['orderinfo.associate_id'] = $details[associate_id];
        }

        if (isset($details[associate_branch_id]) and $details[associate_branch_id] != null) {
            $setarray['orderinfo.associate_branch_id'] = $details[associate_branch_id];
        }
        if (isset($details[component_no]) and $details[component_no] != null) {
            $setarray['orderinfo.component_no'] = $details[component_no];
        }

        //CHANGE SCHEDULED DATE IF SCHEDULED DATE IS SET IN DETAILS
        if (isset($details[scheduled_date]) and $details[scheduled_date] != "") {
            $setarray['orderinfo.scheduled_date'] = $details[scheduled_date];
        }

        if ($status == "1" || $status == 1) {
            $setarray['orderinfo.assigned_time'] = $current_time;
            $setarray['orderinfo.assignedto'] = $assignedid;
            $setarray['orderinfo.assignedname'] = $assignedname;
        }
        if ($status == "26" || $status == 26) {
            $setarray['orderinfo.assigned_time'] = $current_time;
            $setarray['orderinfo.assignedto'] = $assignedid;
            $setarray['orderinfo.assignedname'] = $assignedname;
        }
        if ($status == "2" || $status == 2) {
            $setarray['orderinfo.accept_time'] = $current_time;
        }
        if ($status == "3" || $status == 3) {
            $setarray['orderinfo.start_time'] = $current_time;
            $setarray['payment_applicable'] = true;
        }
        if ($status == "4" || $status == 4) {
            $setarray['orderinfo.reach_time'] = $current_time;
            $setarray['payment_applicable'] = true;
        }
        if ($status == "5" || $status == 5) {
            $setarray['orderinfo.delivery_time'] = $current_time;
            $setarray['payment_applicable'] = true;
        }
        if ($status == "6" || $status == 6) {
            $setarray['orderinfo.completed_time'] = $current_time;
            $setarray['payment_applicable'] = true;
        }
        if ($status == "8" || $status == 8) {
            $setarray['orderinfo.cancel_time'] = $current_time;
        }
        if ($status == "7" || $status == 7) {
            $setarray['orderinfo.reschedule_time'] = $current_time;
        }

        //UPDATE WORKORDER TABLE
        $filter = array('_id' => (double) $current_w_id);
        $update = array('$set' => $setarray);
        $wo_update = $this->dbo->findAndModify("masters", "workorders", $filter, $update);

        //UPDATE WORKORDER INFO UPDATING IN ORDER TABLE

        $filter = array('workorderinfo.wid' => $current_w_id);
        $set = array("workorderinfo.$.wostatus" => $status);
        $order_update = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multiple" => true));

    }

    public function unAllocateOrders($payload, $ticket)
    {

        $this->log->create_log("", "", "order_unallocation", "Execution", 200, "unAllocateOrders_start", json_encode($payload), (string) $ticket);

        try {
            $order_ids = array();
            $workorder_ids = array();
            $workorder_document = array();

            //print_r($payload);exit;
            $data = $payload->orders;
            $allocated_by = $payload->allocated_by;
            //print_r($data);exit;

            //print_r($collection);exit;
            $current_time = substr(date("c", strtotime(date('Y-m-d H:i:s'))), 0, 19) . ".000Z";

            $yr = date('y');
            foreach ($data as $order) {
                // print_r($order);
                $order_id = $order->order_id;
                $workorder_id = $order->workorder_id;
                array_push($order_ids, $order_id);
                array_push($workorder_ids, $workorder_id);

                $filter = array("_id" => $order_id);
                $project = array(
                    "order.patientinfo.scheduled_date" => 1,
                    "wid" => 1,
                    "wodid" => 1,
                    "OStatus" => 1,
                    "order.patientinfo.facility_id" => 1,
                    "order.patientinfo.popname" => 1,
                    "numberOfWO" => array('$size' => '$workorderinfo'),
                );
                $pipeline = array(
                    array('$match' => $filter),
                    array('$limit' => 1),
                    array('$project' => $project),
                );

                $order_data = $this->dbo->aggregate("masters", "orders", $pipeline);
                $patientinfo = $order_data[0]['order']['patientinfo'];
                $scheduled_date = $patientinfo['scheduled_date'];
                $numberOfWO = (int) $order_data[0]['numberOfWO'];
                $orderstatus = 0;
                if ($order_data[0]['OStatus'] == 26) {
                    $orderstatus = 25;
                }

                $filter = array("_id" => $order_id, 'OStatus' => array('$nin' => array(6, 8, 11, 17, 0, 18)));
                //print_r($filter);exit;

                $set = array(
                    "workorderinfo." . ($numberOfWO - 1) . ".wostatus" => '9',
                    "assaigned_to" => "",
                    "OStatus" => $orderstatus,
                    "WOStatus" => $orderstatus,
                    'order.patientinfo.order_status' => (string) $orderstatus,
                    'order.order_status.order_status' => (string) $orderstatus,
                    'order.order_status.assignedto' => "",
                    'order.order_status.mhoname' => "",
                    'order.order_status.last_updated_on' => date("Y-m-d") . "T" . date("H:i:s") . ".000Z",
                    'order.patientinfo.unallocation_time' => date("Y-m-d") . "T" . date("H:i:s") . ".000Z",
                );
                //}

                //print_r($set);exit;
                $options = array("multiple" => true);
                try {
                    $update_order = $this->dbo->update("masters", "orders", $filter, $set, array(), $options);
                    $this->log->create_log("", "", "order_unallocation", "Execution", 200, "unAllocateOrders_end", array("mongo_result" => $update_order, "order_id" => $order_id), (string) $ticket);

                    $this->createlog("CHISS", '9', "Reject Work-Order", "CH155", "CHISS", "Reject Work-Order", $order_data[0]['wid'], $order_data[0]['wodid'],
                        (int) $order_id, "Reject Work-Order", "", $patientinfo['facility_id'], $patientinfo['popname']);

                } catch (Exception $e) {
                    echo 'Message: ' . $e->getMessage();
                    $this->log->create_log("", "", "order_unallocation", "Execution", 300, "Error_unAllocateOrders", $e->getMessage(), (string) $ticket);
                }
                //print_r($update_order);exit;
                if ($update_order[nModified] == 1 && $update_order[ok] == 1) {
                    $current_time = substr(date("c", strtotime(date('Y-m-d H:i:s'))), 0, 19) . ".000Z";

                }
            }

            $update = $this->dbo->update('masters', 'workorders', array(
                "_id" => (int) $order_data[0]['wid'],
            ), array(
                "orderinfo.final_status" => "9",
                "orderinfo.order_status" => "9",
            ), array(), array());

            $response = array("status" => 1, "message" => "Order unallocated successfully", "data" => array("unallocated_workorders" => $workorder_ids, "unallocated_orders" => $order_ids));
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", "order_unallocation", "Execution", 300, "Error_unAllocateOrders", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", "order_unallocation", "Execution", 200, "unAllocateOrders_end", $response, (string) $ticket);

        return ($response);

    } //end of function

    public function chiss_api_reschedule($payload, $ticket)
    {

        $sub_url = '';
        $api_key = $this->config->getConfig("chissapikey", $sub_url);

        $payload->api_key = $api_key;

        ///
        $ordersinfo = $payload->orders_info;
        $order_ids = array();
        foreach ($ordersinfo as $order) {
            $order_ids[] = (int) $order->order_id;
        }

        $filter = array('_id' => array('$in' => $order_ids));
        $project = array('order.patientinfo.application_no' => 1); //.application_no
        $order_cursor = $this->dbo->find('masters', 'orders', $filter, $project, array());

        foreach ($order_cursor as $ord_details) {
            $application_no = null;
            if (array_key_exists('application_no', $ord_details[order][patientinfo])) {
                $application_no = $ord_details[order][patientinfo][application_no];
            }
            if ($application_no != null and trim($application_no) != "") {
                $app_num[(int) $ord_details[_id]] = $application_no;
            }
        }

        for ($i = 0; $i < count($ordersinfo); $i++) {
            $payload->orders_info[$i]->tr_id = (string) $payload->orders_info[$i]->tr_id;
            $id = (int) $ordersinfo[$i]->order_id;
            if (array_key_exists($id, $app_num)) {
                $payload->orders_info[$i]->application_number = $app_num[$id];
            }
        }

        ///

        //print_r($payload);exit;

        $chiss_reschedule_payload = json_encode($payload);
        //print_r($payload->orders_info[0]->order_id);exit;
        //echo $chiss_reschedule_payload;exit;

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "chiss_reschedule_function_start", $chiss_reschedule_payload, (string) $ticket);

        //GETTING URL
        $sub_url = 'api/apoorders';
        $url = $this->config->getConfig("chissurl", $sub_url); //URL to hit
        //$url = 'https://chissapouat.callhealth.com/api/apoorders';

        //CALLING THE API

        $startTime = microtime(true);
        $buffer = $this->utility->my_curl($url, 'POST', $chiss_reschedule_payload, 'json', null, 20);
        $this->log->logThirdPartyCall("CHISS", $url, $startTime, $payload, $buffer);

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "chiss_reschedule_function_end", json_encode($buffer), (string) $ticket);
        //print_r($buffer);exit;

        $response['status'] = 1;

        if (empty($buffer)) {
            $response['status'] = 0;
            $response['message'] = $payload->orders_info[0]->order_id . ' order_id cannot be found';

            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Empty response CHISS", $buffer, (string) $ticket);
            return $response;
        } else {
            $flag = 1;
            //$buffer = json_decode($buffer);
            //print_r($buffer);exit;
            foreach ($buffer as $each_out) {
                if ((int) $each_out[status] == 0 or (int) $each_out[status] == 1) {
                    $flag = 0;
                    $logmessage[] = $each_out;
                } else if ((int) $each_out[status] == 2) {
                    //$flag = 1;
                    $logmessage[] = $each_out;
                    //print_r($buffer);exit;
                    $order_id = $each_out[order_id];
                    $wo_id = $each_out[wo_id];
                    $officer_id = $each_out[officer_id];
                    $officer_name = $each_out[officer_name];
                    $officer_contact_number = $each_out[officer_contact_number];
                    $associate_id = $each_out[associate_id];
                    $branch_id = $each_out[branch_id];
                    $dateChanged = false;
                    $scheduled_date = ""; //$each_out[order_start_time];
                    //$modified_date = substr($scheduled_date,0,10)." ".substr($scheduled_date,11,19);

                    //$modified_date = $utility->convert_date($scheduled_date);

                    $manual_alloc_payload["allocated_by"] = "4";
                    $manual_alloc_payload["assigning_officer_id"] = "CH155";
                    $manual_alloc_payload["assigning_officer_name"] = "CHISS";

                    $ord_creation_data = array("order_id" => $order_id
                        , "workorder_id" => $wo_id
                        , "associate_id" => $associate_id
                        , "branch_id" => $branch_id
                        , "officer_id" => $officer_id
                        , "officer_name" => $officer_name
                        , "officer_contact_number" => $officer_contact_number
                        , "date_Changed" => $dateChanged
                        , "scheduled_date" => $scheduled_date,
                    );
                    $manual_alloc_payload['orders'][] = (object) ($ord_creation_data);

                    //print_r($manual_alloc_payload);exit;
                }
            }

            if (isset($manual_alloc_payload) and $manual_alloc_payload != null and !empty($manual_alloc_payload['orders'])) {

                $this->log->create_log("", "", $this->getname(), "Execution", 200, "manual_alloc _in_reschedule_start", json_encode($manual_alloc_payload), (string) $ticket);

                $output = $this->manual_allocation((object) $manual_alloc_payload, $ticket);
                //$output = json_encode($output);
                $man_alloc_resp[] = $output;
            }

            if ($logmessage != null) {
                $response = array("status" => $flag, "chiss_response" => $logmessage, "manual_alloc_response" => $man_alloc_resp);
            }

            $this->log->create_log("", "", $this->getname(), "Execution", 200, "manual_alloc _in_reschedule_end", $response, (string) $ticket);
            return $response;
        }

    }

    public function manual_allocation($jdcode, $ticket)
    {

        $this->log->create_log("", "", "manual_allocation", "Execution", 200, "manual_allocation_start", json_encode($jdcode), (string) $ticket);

        $allocated_by = $jdcode->allocated_by;
        try {
            $assigning_officer_id = $jdcode->assigning_officer_id;
            $assigning_officer_name = $jdcode->assigning_officer_name;
            if ((int) $allocated_by == 4) {
                $assigning_officer_id = "CH155";
                $assigning_officer_name = "CHISS";
            }
            $orders = $jdcode->orders;
            $assoc_payload = array();
            foreach ($orders as $each_order) {
                /* if(isset($each_order->branch_id))
                {
                $associate_ids[] = $each_order->associate_id.'_'.$each_order->branch_id;
                }
                else
                {
                $associate_ids[] = $each_order->associate_id;
                } */

                $order_ids[] = (int) $each_order->order_id;
                $work_order_ids[$each_order->order_id] = $each_order->workorder_id;
                $associate_ids[$each_order->order_id] = $each_order->associate_id;
                $branch_ids[$each_order->order_id] = $each_order->branch_id;
                $officer_ids[$each_order->order_id] = $each_order->officer_id;
                $officer_names[$each_order->order_id] = $each_order->officer_name;
                $officer_contact_numbers[$each_order->order_id] =
                $each_order->officer_contact_number;
                $date_Changed[$each_order->order_id] = $each_order->date_Changed;
                $scheduledDate[$each_order->order_id] = $each_order->scheduled_date;
				
				if(isset($each_order->reason) and trim($each_order->reason)!="")
				{
					$reason[$each_order->order_id] = $each_order->reason;
				}
				
				if(isset($each_order->officer_skill) and $each_order->officer_skill!="")
				{
					$officer_skill[$each_order->order_id] = $each_order->officer_skill;
				}

                if (isset($each_order->health_coach)) {
                    $health_coach[$each_order->order_id] = $each_order->health_coach;
                }
                if (isset($each_order->secondary_coach)) {
                    $secondary_coach[$each_order->order_id] = $each_order->secondary_coach;
                }

                if ($each_order->associate_id != "") {
                    array_push($assoc_payload, $each_order);
                }
            }

            /* //GET CREATION_TYPE FOR CALLING B2B OR NORMAL ASSOCIATE
            $filter = array("_id"=>(int) $each_order->order_id);
            $project = array("creation_type"=>1);
            $cur = $this->dbo->find('masters','orders',$filter,$project,array());
            foreach($cur as $min_cur)
            {
            //$creation_type[$min_cur[_id]] = $min_cur[creation_type];
            $k = 0;
            foreach($orders as $ord)
            {
            if($min_cur[_id] == (int)$ord->order_id)
            {
            $orders[$k]->creation_type = $min_cur[creation_type];
            $k++;
            }
            }
            } */

            //CALLING CHISS FOR UPDATION IF NOT ALLOCATED BY THEM(CHISS)

            $chiss_log = array();
            if ((int) $allocated_by != 5 and (int) $allocated_by != 4) {
                $api_key = $this->config->getconfig("chissapikey", "");
                $chiss_payload[api_key] = $api_key;
                $i = 0;
                foreach ($order_ids as $o_id) {
                    $chiss_payload[orders_info][$i][order_status] = 1;
                    $chiss_payload[orders_info][$i][order_id] = $o_id;
                    $chiss_payload[orders_info][$i][wo_id] = $work_order_ids[$o_id];
                    $chiss_payload[orders_info][$i][officer_id] = $officer_ids[$o_id];
                    $i++;
                }

                $chiss_payload = json_encode($chiss_payload);

                $sub_url = 'api/apoorders';
                $url = $this->config->getConfig("chissurl", $sub_url); //URL to hit
                //$url = 'https://chissapouat.callhealth.com/api/apoorders';
                //echo $url;exit;

                //CALLING THE API

                $output = $this->utility->my_curl($url, 'POST', $chiss_payload, 'json', null, 20);
                //print_r($output);exit;
                $i = 0;
                foreach ($output as $each_out) {
                    if (isset($each_out[status]) and $each_out[status] == 0) {

                        $this->log->create_log("", "", "manual_allocation", "Execution", 300, "Empty response for manual alloc CHISS", (string) $each_out, (string) $ticket);

                        $chiss_log[] = $each_out;
                        //$chiss_log[] = $each_out[message] . ' for o_id ' . $each_out[order_id];
                    } else {
                        $this->log->create_log("", "", "manual_allocation", "Execution", 200, "Manual alloc Response from CHISS", (string) $each_out, (string) $ticket);

                        $chiss_log[] = $each_out;
                        //$chiss_log[] = $each_out[message] . ' for wo_id ' . $each_out[wo_id] . ' o_id ' . $each_out[order_id];
                    }

                    $i++;
                }
            }

            //SEND ONLY ORDERS WITH A ASSOCIATE_ID
            //$assoc_payload = array_values(array_unique($assoc_payload));//SEND UNIQUE ASS_ID_BR_ID
            if (!empty($assoc_payload)) {
                $associate = new Associate;
                $associate_output = $associate->get_associate_info($assoc_payload);

                if ((int) $associate_output['status'] === 0 and isset($associate_output['message'])) {
                    $this->log->create_log("", "", "manual_allocation", "Execution", 200, json_encode($associate_output), "Manual alloc Response_associate details_issue", (string) $ticket);
                    return $associate_output;
                }
            }

            //To record order_ids not in orders collection or failed updating
            $order_ids_present = array();
            //To record previous and present statuses
            $prev_status = array();
            $present_status = array();

            $order_filter = array('_id' => array('$in' => $order_ids));
            $order_project = array('wid' => 1, 'wodid' => 1, 'active_component' => 1
                , 'OStatus' => 1, 'order' => 1);

            $order_cursor = $this->dbo->find('masters', 'orders', $order_filter, $order_project, array());

            foreach ($order_cursor as $document) {
                //print_r($document);exit;
                $order_id = $document['_id'];
                $order_ids_present[] = $order_id;
                $current_w_id = $document['wid'];
                $current_w_did = $document['wodid'];
                $popid = $document['order']['patientinfo']['facility_id'];
                $popname = $document['order']['patientinfo']['popname'];
                $service_type = $document['order']['patientinfo']['service_type'];
                $current_ord_status = (int) $document['OStatus'];
                $active_component = $document['active_component'];

                //Statuses for facilitation
                if ($service_type == 4 or $service_type == "4") {
                    $Ostatus = "1";
                    if ($current_ord_status == 0 || $current_ord_status == 1) {
                        $Ostatus = "1";
                    } else if ($current_ord_status == 25 || $current_ord_status == 26 || $current_ord_status == 7 || $current_ord_status == 9) {
                        $Ostatus = "26";
                    }
                } else {
                    $Ostatus = "1";
                }

                if ((int) $allocated_by == 5) {
                    $Ostatus = "3"; //on self allocation orders starts
                }

                $prev_status[] = $current_ord_status;
                $present_status[] = $Ostatus;

                if ($branch_ids[$order_id] != null and isset($branch_ids[$order_id])) {
                    $associate_id_branch_id = $associate_ids[$order_id] . "_" . $branch_ids[$order_id];

                } else {
                    $associate_id_branch_id = $associate_ids[$order_id];
                }

                /* if($document['order']['provider_info'][0]['associate_branch_id'] != null)
                {
                $associate_id_branch_id = $document['order']['provider_info'][0]['associate_id'].'_'.
                $document['order']['provider_info'][0]['associate_branch_id'];
                }
                else{
                $associate_id_branch_id = $document['order']['provider_info'][0]['associate_id'];
                } */

                //$associate_id_branch_id = "DC00000009990212_3130"; //DUMMY REMOVE OR COMMENT
                $details = $associate_output[$associate_id_branch_id];
                //print_r($associate_output);exit;
                //print_r($details);exit;

                //UPDATING PROVIDER_INFO
                $provider_info = array('associate_id' => $details[associate_id],
                    'associate_branch_id' => $details[associate_branch_id],
                    'associate_name' => $details[associate_name],
                    'associate_address' => $details[associate_address],
                    'associate_location' => $details[associate_location],
                    'associate_latitude' => $details[associate_latitude],
                    'associate_longitude' => $details[associate_longitude],
                    'associate_contact_number' => $details[associate_contact_number],
                    'associate_email_id' => $details[associate_email_id],
                    'associate_website_url' => $details[associate_website_url],
                    'associate_license_number' => $details[associate_license_number],
                    'associate_skill' => $details[associate_skill],
                    'officer_id' => $officer_ids[$order_id],
                    'officer_name' => $officer_names[$order_id],
                    'officer_contact_number' => $officer_contact_numbers[$order_id],
                );

                //UPDATE PROVIDER_INFO ARRAY VALUE WITH ACTIVE_COMPONENT NUMBER
                $filter = array('order.patientinfo.order_id' => (int) $order_id,
                    'order.provider_info.component_no' => (string) $active_component);
                $set = array(
                    "assaigned_to" => $officer_ids[$order_id],
                    "OStatus" => (int) $Ostatus, "WOStatus" => (int) $Ostatus,
                    'order.patientinfo.order_status' => (string) $Ostatus,
                    'order.order_status.order_status' => (string) $Ostatus,
                    'order.order_status.assignedto' => $officer_ids[$order_id],
                    'order.order_status.mhoname' => $officer_names[$order_id],
                    'order.order_status.last_updated_on' => date("Y-m-d") . "T" . date("H:i:s") . ".000Z",
                    "assignedbypop" => '1',
                    'order.patientinfo.actionById' => $assigning_officer_id,
                    'order.patientinfo.actionByName' => $assigning_officer_name,
                );
				
				if(isset($officer_skill[$order_id]) and $officer_skill[$order_id]!="")
				{
					$set['assigned_officer_role'] = $officer_skill[$order_id];
				}

                //ADD DOCTORID, AS CONSULTATION IS ASSIGNED TO THE DOCTOR
                if ((int) $service_type == 1 and isset($document[order][business][is_consultation]) and (int) $document[order][business][is_consultation] == 1) {
                    $set['order.patientinfo.doctorId'] = $officer_ids[$order_id];
                    $set['order.business.doctorId'] = $officer_ids[$order_id];
                    $set['order.patientinfo.doctorName'] = $officer_names[$order_id];
                    $set['order.business.doctorName'] = $officer_names[$order_id];
                }

                //ADD HEALTH, SECONDARY COACHES IF SET( WILL BE IN CASE OF WELLNESS PACKAGES)
                if ($health_coach != null and !empty($health_coach)) {
                    $set['order.business.health_coach'] = $health_coach[$order_id];
                }
                if ($secondary_coach != null and !empty($secondary_coach)) {
                    $set['order.business.secondary_coach'] = $secondary_coach[$order_id];
                }

                //IF DATE CHANGED UPDATE SCHEDULED DATE  in orders,workorders,orderlog
                if ($date_Changed[$order_id] == true) {
                    $set['order.patientinfo.scheduled_date'] = $this->utility->modify_date($scheduledDate[$order_id]);
                    $set['order.patientinfo.servicedate'] = $this->dbo->date(strtotime($this->utility->modify_date($scheduledDate[$order_id])));
                }

                foreach ($provider_info as $key => $value) {
                    $set['order.provider_info.$.' . $key] = $value;
                }

                //echo json_encode($filter)." ".json_encode($set);exit;

                $options = array("multiple" => true);
                $update = $this->dbo->update('masters', 'orders', $filter, $set, array(), $options);

                //print_r($update);exit;

                if ($update['nModified'] > 0) {
                    //WORKORDER TABLE UPDATING
                    $order_details[$order_id][created_time] = $document[order][order_status][created_date];

                    $order_details[$order_id][order_status] = (string) $Ostatus;
                    $order_details[$order_id][assigned_to] = $officer_ids[$order_id];

                    $order_details[$order_id][associate_id] = $associate_ids[$order_id];
                    $order_details[$order_id][associate_branch_id] = $branch_ids[$order_id];
                    $order_details[$order_id][component_no] = $active_component;

                    //ONLY CHANGE DATE IN WORKORDER IF UPDATED IN ORDER
                    if ($date_Changed[$order_id] == true) {
                        $order_details[$order_id][scheduled_date] = $scheduledDate[$order_id];
                    }

                    $this->changeWoStatus($Ostatus, $order_id, $order_details, $work_order_ids[$order_id], $officer_ids[$order_id], $officer_names[$order_id]);

                    $orderlog_resp = array();

                    /* $order_filter = array('wid' => (int) $work_order_ids[$order_id]);
                    $order_project = array('wodid' => 1);
                    $order_cursor = $this->dbo->find('masters', 'orders', $order_filter, $order_project, array());

                    foreach ($order_cursor as $document) {
                    $w_did = $document[wodid];

                    } */

                    //$response=array("response"=>"1","msg"=>"Order Assigned.");
                    //ORDER LOG UPDATE
                    $role_name = $this->utility->assigning_role((int) $allocated_by);

					if(isset($reason[$order_id]) and $reason[$order_id]!="")
					{
						$reasonVal = $reason[$order_id];
					}
					else
					{
						$reasonVal = "Officer Allocation " . $officer_names[$order_id] . "(" . $officer_ids[$order_id] . ")";
					}
					
                    $resp = $this->createlog($role_name,
                        (string) $Ostatus, "officer Assignment",
                        $assigning_officer_id, $assigning_officer_name,
                        "MHO Allocation " . $officer_names[$order_id] . "(" . $officer_ids[$order_id] . ")",
                        $work_order_ids[$order_id],
                        $current_w_did,
                        (int) $order_id, $reasonVal,
                        "", $popid, $popname, $date_Changed[$order_id], $scheduledDate[$order_id]);

                    if ($resp != 0) {
                        $orderlog_resp[] = $resp;
                    }

                } else {
                    //$response = array("response"=>"0","msg"=>"Order assignment failed.");

                    //Remove order_id from order_ids_present if unable to update the order
                    foreach (array_keys($order_ids_present, $order_id) as $key) {
                        unset($order_ids_present[$key]);
                    }
                }

            }

            //Getting orders not present in collection and not updated
            $order_ids_failed = array_diff($order_ids, $order_ids_present);

            //STRUCTURING RESPONSE
            if (empty($order_ids_present)) {
                $response = array("status" => 0);
            } else {
                $response = array("status" => 1);
            }

            $response["orders_modified"] = $order_ids_present;
            $response["orders_unchanged"] = array_values($order_ids_failed);
            $response["chiss_updation_order_log"] = $chiss_log;
            $response["previous_status"] = $prev_status;
            $response["present_status"] = $present_status;
            //$response["orderlog_updated_failed"] = $orderlog_resp;//NOT REQUIRED

        } catch (Exception $e) {
            $message = $e->getMessage();
            $this->log->create_log("", "", "manual_allocation", "Execution", 400, "ERROR_manual_allocation", $message, (string) $ticket);
        }
        //echo json_encode($response);
        //exit;
        //print_r($associate_output);
        $this->log->create_log("", "", "manual_allocation", "Execution", 200, "manual_allocation_end", $response, (string) $ticket);
        return $response;

    }

    public function chiss_appointment_creation($payload, $ticket)
    {
        $app_id = $payload->appointment_id;

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "chiss_appointment_creation_start", json_encode($payload), (string) $ticket);
        try
        {
            //INSTANCES

            //DB CALL
            $app_filter = array('appointmentId' => array('$in' => $app_id));
            $app_cursor = $this->dbo->find('masters', 'appointments', $app_filter, array(), array());
            //print_r($app_cursor);exit;

            //CHISS PAYLOAD

            //$api_key = $this->config->getConfig("chissapikey","");
            //$chiss_payload[api_key] = $api_key;
            //print_r($chiss_payload);exit;

            $orders_info = array();
            foreach ($app_cursor as $app_details) {
                $buffer[order_id] = $app_details[appointmentId];
                $buffer[wo_id] = 1;
                $buffer[order_status] = 0;
                $buffer[engagement_level] = 3;
                $buffer[business_id] = 1;
                $buffer[sub_business_id] = 7;
                $buffer[role_id] = "10";
                $buffer[skill] = 1;
                $buffer[service_did] = "1";
                $buffer[patient_mrn] = (int) $app_details[mrn];
                $buffer[patient_age] = isset($app_details[age]) ? $app_details[age] : 30;
                if (isset($app_details[application_no])) {
                    $buffer['application_number'] = $app_details[application_no];
                }
                ///

                $gender = $this->utility->genderStringtoNumber($app_details[gender]);
                /*if($gender=='F' || $gender=='Female' || $gender=='FEMALE' || $gender=='1' || $gender==1)
                {
                $gender = "1";
                }

                else if($gender=='M' || $gender=='Male' || $gender=='MALE' || $gender=='2' || $gender==2)
                {
                $gender = "2";
                }
                else
                {
                $gender = "0";
                }*/

                $buffer[patient_gender] = isset($app_details[$gender]) ? $gender : 1;
                ///

                //$buffer[patient_gender] = isset($app_details[gender])?$app_details[gender]:1;
                $buffer[associate_id] = "";
                $buffer[branch_id] = "";
                $buffer[speciality_id] = $app_details[specialityid];

                $buffer[preferred_officer] = $app_details[doctorId];
                //$buffer[pin_code]= "500016";
                //$buffer[order_latitude]= "12";
                //$buffer[order_longitude]= "1";

                $buffer[type_of_date] = 1; //Hardcoded for now

                //IF TYPE_OF_DATE = 1
                $modified_date = $this->utility->convert_date($app_details[scheduledTime]);
                $buffer[schedule_date] = $modified_date;

                //IF TYPE_OF_DATE = 2
                //$buffer[from_date] = $app_details[appointmentId];
                //$buffer[to_date] = $app_details[appointmentId];
                //$buffer[slot_timing_enum] = $app_details[appointmentId];

                $buffer[tr_id] = $app_details[transactionId];

                $orders_info[] = $buffer;
            }
            //print_r($orders_info);exit;
            //echo json_encode($orders_info);exit;

            $chissobj = new Chiss;
            $output = $chissobj->get_officer($orders_info, $ticket);
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_appointment_creation", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "chiss_appointment_creation_end", $output, (string) $ticket);
        //print_r($output);exit;
        return $output;
    }

    public function chiss_order_action($payload, $ticket)
    {
        //FOR ACCEPT,START,COMPLETED

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "chiss_order_action_start", json_encode($payload), (string) $ticket);
        try
        {
            /*
            $ordersinfo = array();
            $chissobj = new Chiss;

            $order_id = $payload->order_id;
            $wo_id = $payload->workorder_id;
            $order_status = $payload->status;

            $ordersinfo[] = array("order_id" => (int) $order_id,
            "wo_id" => (int) $wo_id,
            "order_status" => $order_status,
            );
            $output = $chissobj->get_officer($ordersinfo); */
            $chissobj = new Chiss;
            $output = $chissobj->get_officer($payload, $ticket);
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_order_action", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "chiss_order_action_end", json_encode($output), (string) $ticket);
        return $output;
    }

    /*function chiss_order_acceptance($payload,$ticket)
    {
    $this->log=new Logapp;
    $this->log->create_log("","",$this->getname(),"Execution",200,"chiss_order_acceptance_start",json_encode($payload),(string)$ticket);
    try
    {
    $ordersinfo = array();
    $chissobj  = new Chiss;

    $order_id = $payload->order_id;
    $wo_id = $payload->workorder_id;
    $order_status = 2;

    $ordersinfo[] = array("order_id"=>(int)$order_id,
    "wo_id"=>(int)$wo_id,
    "order_status"=>$order_status
    );
    $output = $chissobj->get_officer($ordersinfo);
    }
    catch(Exception $e)
    {
    echo 'Message: ' .$e->getMessage();
    $this->log->create_log("","",$this->getname(),"Execution",300,"Error_order_accept",$e->getMessage(),(string)$ticket);
    }

    $this->log->create_log("","",$this->getname(),"Execution",200,"chiss_order_acceptance_end",json_encode($output),(string)$ticket);
    return $output;
    }*/

    public function chiss_order_rejection($payload, $ticket)
    {

        $this->log->create_log("", "", "order_rejection", "Execution", 200, "chiss_order_rejection_start", $payload, (string) $ticket);
        try
        {
            $chissobj = new Chiss;
            /* $ordersinfo = array();
            $chissobj = new Chiss;

            $order_id = $payload->order_id;
            $wo_id = $payload->workorder_id;
            $new_wo_id = $payload->new_workorder_id;
            $order_status = 9;

            $ordersinfo[] = array("order_id" => (int) $order_id,
            "wo_id" => (int) $wo_id,
            "new_wo_id" => (int) $new_wo_id,
            "order_status" => $order_status,
            );
            //print_r($ordersinfo);exit;
            $response = $chissobj->get_officer($ordersinfo, $ticket); */

            $response = $chissobj->get_officer($payload, $ticket);
            //print_r($response);exit;

            ///Manual Allocation of officer
            $manual_alloc_payload = array();
            $manual_alloc_payload["allocated_by"] = "4";
            $manual_alloc_payload["assigning_officer_id"] = "CH155";
            $manual_alloc_payload["assigning_officer_name"] = "CHISS";

            foreach ($response as $each_resp) {

                /* if ((isset($each_resp[status]) && (int) $each_resp[status] == 0) || (isset($each_resp[status]) && (int) $each_resp[status] == 1))
                {
                //$output = json_encode($each_resp);
                //echo json_encode(array("chiss_response" => $each_resp));
                $this->log->create_log("", "", "order_rejection", "Execution", 200, "function_end", $output, (string) $ticket);
                //return array("chiss_response" => $each_resp);
                }  */
                if ((int) $each_resp[status] == 2) {

                    $order_ids_assigned[] = $each_resp[order_id];

                    /* if(isset($order_response[branch_id]))
                    {
                    $associate_branch_ids[]
                    = array($order_response[associate_id],$order_response[branch_id]);
                    }
                    else
                    {
                    $associate_branch_ids[]    = array($order_response[associate_id]);
                    } */

                    /* $associates = array((object)$associate_branch_ids);
                    //print_r($associates);exit;
                    $associate_obj = new Associate;
                    $associate_output = $associate_obj->get_associate_info($associates); */

                    // UPDATION REMOVED

                    $ord_creation_data = array("order_id" => $each_resp[order_id]
                        , "workorder_id" => $each_resp[wo_id]
                        , "associate_id" => $each_resp[associate_id]
                        , "branch_id" => $each_resp[branch_id]
                        , "officer_id" => $each_resp[officer_id]
                        , "officer_name" => $each_resp[officer_name]
                        , "officer_contact_number" => $each_resp[officer_contact_number]
                        , "date_Changed" => isset($each_resp[date_Changed]) ? $each_resp[date_Changed] : false
                        , "scheduled_date" => "",
                    );

                    if ($ord_creation_data[date_Changed]) {
                        $ord_creation_data["scheduled_date"] = $each_resp['schedule_date'];
                    }

                    $manual_alloc_payload["orders"][] = (object) $ord_creation_data; //(object)
                }
            }

            if (!empty($manual_alloc_payload["orders"])) {

                try
                {
                    $output = $this->manual_allocation((object) $manual_alloc_payload, $ticket);
                }

                //catch exception
                 catch (Exception $e) {
                    echo 'Message: ' . $e->getMessage();
                    $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_manual_alloc", $e->getMessage(), (string) $ticket);
                }

            } else {
                $output = $response;
            }

        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_order_rejection", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", "order_rejection", "Execution", 200, "chiss_order_rejection_end", $output, (string) $ticket);
        return $output;
    }

    public function chiss_order_cancel($payload, $ticket)
    {

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "chiss_order_cancel_start", json_encode($payload), (string) $ticket);
        try
        {
            /*
            $ordersinfo = array();
            $chissobj = new Chiss;

            $order_id = $payload->order_id;
            $wo_id = $payload->workorder_id;
            $order_status = 8;

            $ordersinfo[] = array("order_id" => (int) $order_id,
            "wo_id" => (int) $wo_id,
            "order_status" => $order_status,
            );
            $output = $chissobj->get_officer($ordersinfo,$ticket); */
            $chissobj = new Chiss;
            $output = $chissobj->get_officer($payload, $ticket);
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_order_cancel", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "chiss_order_cancel_end", $output, (string) $ticket);
        return $output;

    }

    public function chiss_appointment_reschedule($payload, $ticket)
    {

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "chiss_appointment_reschedule_start", json_encode($payload), (string) $ticket);

        try
        {

            $chissobj = new Chiss;

            $ordersinfo = array();

            $order_id = $payload->appointmentid;
            //$wo_id =$payload->workorder_id;

            $filter = array('appointmentId' => (string) $order_id);
            $project = array("reschedule_count" => 1, "_id" => 1);

            $data = $this->dbo->findOne("masters", "appointments", $filter, $project);

            $new_wo_id = (int) $data['reschedule_count'];
            $wo_id = $new_wo_id - 1;
            $order_status = 7;
            $schedule_date = $payload->scheduled_date;

            $schedule_date = $this->utility->convert_date($schedule_date);
            $tr_id = $payload->transaction_id;

            $ordersinfo[] = array("order_id" => $order_id,
                "wo_id" => $wo_id,
                "new_wo_id" => $new_wo_id,
                "order_status" => $order_status,
                "schedule_date" => $schedule_date,
                "tr_id" => $tr_id,
            );

            //print_r($ordersinfo);exit;
            $output = $chissobj->get_officer($ordersinfo, $ticket);
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_appointment_reschedule", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_end", $output, (string) $ticket);

        return $output;
    }

    public function chiss_order_creation($payload, $ticket)
    {
        $order_ids = $payload->order_ids;
        $order_ids = array_values(array_unique($order_ids));
        //print_r($order_ids);exit;

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "chiss_order_creation_start", $payload, (string) $ticket);

        //CONNECTING TO DB

        $order_filter = array('_id' => array('$in' => $order_ids));
        $order_project = array('wid' => 1, 'order' => 1, "odid" => 1, "active_component" => 1, "mode_of_service" => 1);
        $order_details = $this->dbo->find('masters', 'orders', $order_filter, $order_project, array());

        foreach ($order_details as $document) {
            //print_r($document);
            //DATA IN LOOP TO BE CHANGED ACC. TO SPECIFICATIONS
            $buffer = array();

            $patientinfo = $document[order][patientinfo];
            $order_status = $document[order][order_status];
            $associate_data = $document[order][provider_info];
            if (isset($document[order][business]) and !empty($document[order][business])) {
                $business = $document[order][business];
            }

            $buffer['order_id'] = $document[_id];
            $buffer['order_did'] = $document[odid];
            $buffer['wo_id'] = $document[wid];
            $active_component = $document[active_component];

            $buffer['order_status'] = "0"; //$order_status[order_status];// HardCoded for creation
            $buffer['engagement_level'] = $document[mode_of_service];
            $buffer['business_id'] = $patientinfo[service_type];
            $buffer['sub_business_id'] = $patientinfo[service_subtype_id];
            $ahelpinfo = array();
            //CAN GET ROLE FROM PROVIDER_INFO NOW
            foreach ($associate_data as $associate) {
                if ($associate['component_no'] == $active_component) {
                    $buffer['role_id'] = $associate['role'];
                    $buffer['skill'] = $associate['skill'];
                    $buffer['associate_id'] = isset($associate['associate_id']) ? $associate['associate_id'] : "";
                    $buffer['branch_id'] = isset($associate['associate_branch_id']) ? $associate['associate_branch_id'] : "";

                }
                if ((int) $associate['component_no'] == 7) {
                    $ahelpinfo = $associate;
                }
            }
            if ((int) $document[active_component] == 3 and ($patientinfo[service_type] == "3" || $patientinfo[service_type] == "4")) {
                $buffer['associate_id'] = isset($ahelpinfo['associate_id']) ? $ahelpinfo['associate_id'] : "";
                $buffer['branch_id'] = isset($ahelpinfo['associate_branch_id']) ? $ahelpinfo['associate_branch_id'] : "";
            }
            
			//$buffer['service_did'] = $document[order][orderitem][0][item_code];
			$serviceDid = array();
            foreach($document[order][orderitem] as $item)
			{
				if($item['roleBasedService'] == 0)
				{
					$serviceDid[] = $item[item_code];
				}
			}
			
			if(empty($serviceDid))
			{
				$buffer['service_did'] = $document[order][orderitem][0][item_code];
			}
			else
			{
				$buffer['service_did'] = implode(",",$serviceDid);
			}
			
			$buffer['patient_mrn'] = $patientinfo[mrn];

            if (isset($patientinfo[application_no]) and $patientinfo[application_no] != null
                and trim($patientinfo[application_no]) != "") {
                $buffer['application_number'] = $patientinfo[application_no];
            }

            $businessid = $patientinfo[service_type];
            $subbusinessid = $patientinfo[service_subtype_id];
            $service_id = $buffer['service_did'];

            if ($businessid == 1 and $business[is_consultation] == 1) {
                $buffer['preferred_officer'] = $business[doctorId];
            }

            if ($business[is_continuous] == 1) {
                $buffer['careplan'] = 'Y';
                $buffer['session_id'] = $business['session_no'];

                $care_orders[] = $buffer['order_id'];
            }

            //PREVIOUSLY USED TO GET ROLE_ID AND SKILL
            //$roledata = $this->get_role_for_order($businessid, $service_id, $subbusinessid);
            //$buffer['role_id'] = $roledata['role'];
            //$buffer['skill'] = $roledata['skill'];

            $patientinfo[age] = preg_replace("/[^0-9]/", "", $patientinfo[age]);
            $buffer['patient_age'] = $patientinfo[age];

            $gender = $this->utility->genderStringtoNumber($patientinfo[gender]);
            /*$gender = $patientinfo[gender];
            if($gender=='F' || $gender=='Female' || $gender=='FEMALE' || $gender=='1' || $gender==1)
            {
            $gender = "1";
            }

            else if($gender=='M' || $gender=='Male' || $gender=='MALE' || $gender=='2' || $gender==2)
            {
            $gender = "2";
            }
            else
            {
            $gender = "0";
            }*/

            $buffer['patient_gender'] = $gender;
            //$buffer['associate_id'] = ""; //$associate_data[]; //NotFound
            //$buffer['branch_id'] = ""; //$associate_data[]; //NotFound
            $buffer['pin_code'] = $patientinfo[pincode];
            $buffer['order_latitude'] = $patientinfo[delivery_lat];
            $buffer['order_longitude'] = $patientinfo[delivery_lng];

            $buffer['type_of_date'] = 1; //HARDCODED FOR NOW
            if ((int) $businessid == 3 and $active_component == "8") {
                $buffer['type_of_date'] = 3;
            }

            //$this->utility = new Utility;
            $buffer['schedule_date'] = $this->utility->convert_date($patientinfo[scheduled_date]); //TO BE GIVEN WHEN type_of_date = 1

            /* $buffer['from_date'] = ""; //TO BE GIVEN WHEN type_of_date = 2
            $buffer['to_date'] = ""; //TO BE GIVEN WHEN type_of_date = 2
            $buffer['slot_timing_enum'] = 1; //TO BE GIVEN WHEN type_of_date = 2 */

            if (gettype($patientinfo[slot_transaction_id]) == "array") {
                $buffer['tr_id'] = (string) $patientinfo[slot_transaction_id][0];
            } else {
                $buffer['tr_id'] = (string) $patientinfo[slot_transaction_id];
            }

            $orders_info[] = $buffer;
        }
        //print_r($orders_info);exit;

        $chissobj = new Chiss;
        $output = $chissobj->get_officer($orders_info, $ticket);
        //print_r($output);exit;

        /*  print_r($chiss_payload);
        print_r($output);
         */

        $flag = 1;
        $order_ids_assigned = array();
        $manual_alloc_payload = array();
        $manual_alloc_payload["allocated_by"] = "4";
        $manual_alloc_payload["assigning_officer_id"] = "CH155";
        $manual_alloc_payload["assigning_officer_name"] = "CHISS";
        foreach ($output as $order_response) {

            if ((int) $order_response[status] == 2) {
                $order_ids_assigned[] = $order_response[order_id];

                //GETTING ASSOCIATEINFO DONE IN
                /* if (isset($order_response[branch_id])) {
                $associate_branch_ids[]
                = array($order_response[associate_id], $order_response[branch_id]);
                } else {
                $associate_branch_ids[] = array($order_response[associate_id]);
                }

                $associates = array((object)$associate_branch_ids);
                //print_r($associates);exit;
                $associate_obj = new Associate;
                $associate_output = $associate_obj->get_associate_info($associates); */

                // UPDATION REMOVED

                $ord_creation_data = array("order_id" => $order_response[order_id]
                    , "workorder_id" => $order_response[wo_id]
                    , "associate_id" => $order_response[associate_id]
                    , "branch_id" => $order_response[branch_id]
                    , "officer_id" => $order_response[officer_id]
                    , "officer_name" => $order_response[officer_name]
                    , "officer_contact_number" => $order_response[contact_number]
                    , "date_Changed" => isset($order_response[date_Changed]) ? $order_response[date_Changed] : false
                    , "scheduled_date" => "",
                );

                if ($ord_creation_data[date_Changed]) {
                    $ord_creation_data["scheduled_date"] = $order_response['scheduled_date'];
                }

                //IF CARE ORDER CHANGE THE SCHEDULED DATE AS RETURNED BY CHISS
                if (in_array($order_response[order_id], $care_orders)) {
                    $ord_creation_data["date_Changed"] = true;
                    $ord_creation_data["scheduled_date"] = $order_response['scheduled_date'];
                }

                $manual_alloc_payload["orders"][] = (object) $ord_creation_data; //(object)
            }

        }

        if (!empty($manual_alloc_payload["orders"]) and $manual_alloc_payload["orders"] != null) {
            //IF positive response from chiss

            try {
                $response = $this->manual_allocation((object) $manual_alloc_payload, $ticket);
            }

            //catch exception
             catch (Exception $e) {
                echo 'Message: ' . $e->getMessage();
                $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_manual_alloc", $e->getMessage(), (string) $ticket);
            }

        } else {
            //IF negative response from chiss
            $response = $output;
        }

        //print_r($response);exit;
        //$output = json_encode($output);
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "chiss_order_creation_end", $response, (string) $ticket);
        return $response;

        /* //STRUCTURING RESPONSE
    $order_ids_failed = array_diff($order_ids,$order_ids_assigned);

    if(!empty(array_values($order_ids_failed)))
    {
    $flag = 0;
    $logmessage[] = implode(',',$order_ids_failed).' orders creation with chiss failed';
    }

    if($flag == 0)
    {
    $response = json_encode(array("status"=>$flag ,"output"=>$logmessage));
    }
    else
    {
    $response =  json_encode(array("status"=>$flag ,"output"=>"Chiss Order created successfully"));
    }

    //print_r($response);exit;
    return $response; */
    }

    public function get_available_officers($payload, $ticket)
    {
        $order_id = $payload->order_id;

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "get_available_officers_start", $payload, (string) $ticket);

        $order_filter = array('_id' => (int) $order_id);
        $order_project = array('order.orderitem.item_code' => 1, 'order.orderitem.component_no' => 1, 'mode_of_service' => 1, 'order.patientinfo' => 1, 'order.provider_info' => 1, 'odid' => 1, 'wid' => 1, "active_component" => 1,
            'order.business.is_continuous' => 1,
        );

        $document = $this->dbo->findone('masters', 'orders', $order_filter, $order_project);

        $sub_url = '';
        $api_key = $this->config->getconfig("chissapikey", $sub_url);
        //    print_r($order_cursor);exit;

        //print_r($document);exit;
        $patientinfo = $document[order][patientinfo];
        $business = $document[order][business];
        $data[api_key] = $api_key; //To be changed
        $data[engagement_level] = $document[mode_of_service];
        $data[order_id] = $document[_id];
        $data[order_did] = $document[odid];
        $data[wo_id] = $document[wid];
        $data[business_id] = (string) $patientinfo[service_type];
        $data[sub_business_id] = (string) $patientinfo[service_subtype_id];
        //$data[role_id] = (string)$patientinfo[role];
        //$data[skill] = (string)isset($patientinfo[skill])? $patientinfo[skill]:"";

        ///

        // print_r($roles);//exit;

        $provider_info = $document[order][provider_info];
        $active_component = $document[active_component];

        //print_r($provider_info);exit;

        foreach ($provider_info as $provider) {

            if ($provider[component_no] == $active_component) {
                //print_r($provider);exit;
                $data[role_id] = $provider['role'];
                $data[skill] = $provider['skill'];
            }
        }

        if (empty($data[role_id])) {

            $this->log->create_log("", "", $this->getname(), "Execution", 300, "CHISS FETCH OFFICERS", "Roles are not defined for business Id :" . $businessName, (string) $ticket);
            //  echo "Roles are not defined for business Id :" . $business_id;

            $roles = $this->get_role_for_order(
                (int) $patientinfo[service_type],
                (string) $document[order][orderitem][0][item_code],
                (int) $patientinfo[service_subtype_id]
            );
            $data[role_id] = $roles['role'];
            $data[skill] = $roles['skill'];
        }

        ///

        $data[service_did] = (string) $document[order][orderitem][0][item_code];
        $data[patient_mrn] = (string) $patientinfo[mrn];

        $patientinfo[age] = preg_replace("/[^0-9]/", "", $patientinfo[age]);
        $data[patient_age] = (string) $patientinfo[age];

        $gender = $this->utility->genderStringtoNumber($patientinfo[gender]);
        $continous = 0;
        if (isset($business['is_continuous']) and $business['is_continuous'] == 1) {
            $continous = 1;
        }
		
		// For corporate order like hdfc pass the application number
		if(isset($patientinfo[application_no]) and trim($patientinfo[application_no]) != "")
		{
			$data[application_no] = $patientinfo[application_no];
		}
		
        /*if( $gender=="F" || $gender=="Female" || $gender=="FEMALE" || $gender==1 || $gender=="1")
        {
        $gender=1;
        }
        else
        {
        $gender=2;
        }*/
        //$this->utility=new Utility;

        if ((int) $payload->roleType == 1) {
            $data[branch_id] = "";
            $data[associate_id] = "";
        } else if ((int) $payload->roleType == 2) {
            //print_r($document);exit;
            $component = $document[active_component];
            $provider = $document[order][provider_info];

            foreach ($provider as $some) {
                //print_r($component);
                //print_r($some);exit;
                if ($component == $some[component_no]) {
                    $data[branch_id] = "";
                    $data[associate_id] = $some[associate_id];
                }
            }
        } else if ((int) $payload->roleType == 3) {
            $component = $document[active_component];

            $provider = $document[order][provider_info];

            foreach ($provider as $some) {
                if ($component == $some[component_no]) {
                    $data[associate_id] = $some[associate_id];
                    $data[branch_id] = $some[associate_branch_id];
                }
            }
        }
		
		if(isset($payload->associate_id) and trim($payload->associate_id) != "")
		{
			$data[associate_id] = $payload->associate_id;
		}
		if(isset($payload->branch_id) and trim($payload->branch_id) != "")
		{
			$data[branch_id] = $payload->branch_id;
		}

        if ($continous == 1) {
            $provider = $document[order][provider_info];
            $data["careplan"] = "Y";
            $data[associate_id] = $provider[0][associate_id];
            $data[branch_id] = $provider[0][associate_branch_id];

        }

        $data[patient_gender] = (string) $gender;
        //$data[branch_id] = isset($payload->branch_id) ? $payload->branch_id : "";
        //$data[associate_id] = isset($payload->associate_id) ? $payload->associate_id : "";
        $data[pin_code] = (string) $patientinfo[pincode];
        $data[order_latitude] = (string) $patientinfo[delivery_lat];
        $data[order_longitude] = (string) $patientinfo[delivery_lng];
        $date = (string) $payload->scheduled_date;

        if (strpos($date, "T") !== false) {
            $date = $this->utility->convert_date($date);
        }
        $data[schedule_date] = $date; //$patientinfo[scheduled_date];

        //FOR MEDICINE ORDERS
        if (isset($payload->normal_slots)) {
            $data['normal_slots'] = $payload->normal_slots;
        }

        $chiss_payload = $data;
        // $chiss_payload[service_did] = "1234";
        // print_r($chiss_payload);exit;

        //Dealing Errors
        $flag = 1;
        if (!isset($data[role_id])) {
            $flag = 0;
            $logmessage[] = "role not available";
        }

        //

        //Output
        if ($flag == 1) {
            $chissobj = new Chiss;
            $buffer = $chissobj->get_slot($chiss_payload, $ticket);
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "get_available_officers_end", $buffer, (string) $ticket);
            return $buffer;

        } else {
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Issue with Fields", 'Some fields missing or invalid', (string) $ticket);
            return array('status' => $flag, 'message' => $logmessage);
        }

    }

    public function get_role_for_order($businessid, $service_id, $subbusinessid)
    {
        $businessid = (int) $businessid;
        $subbusinessid = (int) $subbusinessid;
        $roleskill = array();
        //echo $businessid.$service_id.$subbusinessid;exit;
        if ($businessid == 1) {
            $roleskill = array("role" => "1", "skill" => "");
        } else if ($businessid == 2) {
            $roleskill = array("role" => "9", "skill" => "");
        } else if ($businessid == 3) {
            $roleskill = array("role" => "8", "skill" => "");
        } else if ($businessid == 4) {
            $roleskill = array("role" => "3", "skill" => "");
        } else if ($businessid == 6) {

            /* $sub_url = 'fetchservice/entity';//UPDATE CONFIG FILE TO UPDATE SUB_URL to""
            $url = $this->config->getConfig("mdmpath",$sub_url);
            $url = $this->config->getConfig("mdmpath",$sub_url);
            $mdmpayload=array( "entity"=>"nursing" ,
            "colNames"=>"code", "colValues"=>$service_id
            , "search"=>"true", "getPrice"=>"false","pop"=>"100343", "source" =>"CCO");

            $buffer = $this->utility->my_curl($url,'POST',$mdmpayload,'json',null,20);
            print_r($buffer);  */

            $sub_url = 'crud/entitiesByColumn/careathome/code/' . $service_id; //UPDATE CONFIG FILE TO UPDATE SUB_URL to""
            $url = $this->config->getConfig("mdmpath", $sub_url);

            // echo $url;
            //exit;
            $buffer = $this->utility->my_curl($url, 'get', array(), 'json', null, 20);

            $subbusinessid = (int) $buffer[0]['subBusinessID'];

            if ($subbusinessid == 201) {
                $roleskill = array("role" => "5", "skill" => "");
            } else if ($subbusinessid == 102) {
                $roleskill = array("role" => "1", "skill" => "");
            } else if ($subbusinessid == 103) {
                $roleskill = array("role" => "1", "skill" => "2,3");
            } else if ($subbusinessid == 104) {
                $roleskill = array("role" => "1", "skill" => "3");
            } else {
                $roleskill = array("role" => "1", "skill" => "");
            }

        } else if ($businessid == 5) {

            $sub_url = 'crud/entitiesByColumn/careathome/code/' . $service_id; //UPDATE CONFIG FILE TO UPDATE SUB_URL to""
            $url = $this->config->getConfig("mdmpath", $sub_url);

            // echo $url;
            //exit;
            $buffer = $this->utility->my_curl($url, 'get', array(), 'json', null, 20);

            $subbusinessid = (int) $buffer[0]['subBusinessID'];
            if ($subbusinessid == 201) {
                $roleskill = array("role" => "5", "skill" => "");
            } else if ($subbusinessid == 102) {
                $roleskill = array("role" => "1", "skill" => "");
            } else if ($subbusinessid == 103) {
                $roleskill = array("role" => "1", "skill" => "2,3");
            } else if ($subbusinessid == 104) {
                $roleskill = array("role" => "1", "skill" => "3");
            } else {
                $roleskill = array("role" => "1", "skill" => "");
            }

        } else if ($businessid == 30) {
            if ($subbusinessid == 201) {
                $businessid = 7;
                $roleskill = array("role" => "5", "skill" => "1");
            } else if ($subbusinessid == 103) {
                $businessid = 6;
                $roleskill = array("role" => "2", "skill" => "");
            } else {
                $roleskill = array("role" => "1", "skill" => "");
            }
            //$roleskill=array("role"=>"26","skill"=>"");
        }

        $roleskill['businessid'] = $businessid;
        $roleskill['subbusinessid'] = $subbusinessid;
        //print_r($roleskill);exit;
        return $roleskill;
    }

    public function order_track($payload, $ticket)
    {
        $response = array("status" => 0, "message" => "Order tracking details are not found", "data" => array());
        $orderID = $payload->order_id;

        $filter = array('_id' => (int) $orderID);
        //$project = array("order_log" => 1, "_id" => 1);
        /*$lookup = array(
        'from' => 'workflow_status',
        'let' => array
        (
        'mode_of_service' => '$mode_of_service',
        'service_type' => '$order.patientinfo.service_type',
        'order_status' => '$OStatus',
        'component' => '$active_component',
        ),
        'pipeline' => array(array
        (
        '$match' => array
        ('$expr' => array
        ('$and' => array(
        array('$eq' => array('$status', '$$order_status')),
        array('$eq' => array('$Bid', '$$service_type')),
        array('$eq' => array('$MOSid', '$$mode_of_service')),
        array('$eq' => array('$Workflow', '$$component')),
        ),
        ),
        )),
        array('$project' => array("Nomenclature" => 1, '_id' => 0)),
        ),
        'as' => 'status_meaning',
        );

        //echo json_encode($lookup);exit;
        $pipeline = array(array('$match' => $filter), array('$lookup' => $lookup));
        //echo json_encode($pipeline);exit;

        $data = $this->dbo->aggregate("masters", "orderlog", $pipeline);*/

        $data = $this->dbo->findone('masters', 'orderlog', $filter, array());
        if (count($data) > 0) {
            $response["status"] = 1;
            $response["message"] = "Success";
            $response["data"] = $data;
        }
        return $response;
    }

    public function get_available_slots($payload, $ticket)
    {
        // get payload data
        //print_r($payload);exit;
        $from_date = date('Y-m-d', strtotime($payload->from_date));
        $to_date = date('Y-m-d', strtotime($payload->to_date));
        $businessName = $payload->business_id; //*  //Ex. nursing
        $subbusinessName = $payload->sub_business_id;
        $service_id = $payload->service_did; //*  //Ex. TS1501CAHNSA00020
        $pop_id = $payload->pop_id; //*
        $patient_mrn = $payload->patient_mrn;
        $patient_age = intval($payload->patient_age);
        $patientid = $payload->patientId;
        $preferred_officer = $payload->preferred_officer;

        ///

        $gender = $this->utility->genderStringtoNumber($payload->patient_gender);
        /*if($gender=='F' || $gender=='Female' || $gender=='FEMALE' || $gender=='1' || $gender==1)
        {
        $gender = "1";
        }

        else if($gender=='M' || $gender=='Male' || $gender=='MALE' || $gender=='2' || $gender==2)
        {
        $gender = "2";
        }
        else
        {
        $gender = "0";
        }
        $patient_gender = $gender;*/
        ///

        //$patient_gender = $payload->patient_gender;

        $pin_code = $payload->pin_code;
        $latitude = round($payload->order_latitude, 6);
        $longitude = round($payload->order_longitude, 6);
        //print_r($payload);exit;

        // get_role_for_order
        $roles = $this->get_role_for_order($businessName, $service_id, $subbusinessName);

        //print_r($roles);exit;
        if (empty($roles)) {

            $this->log->create_log("", "", $this->getname(), "Execution", 300, "CHISS FETCH SLOTS", "Roles are not defined for business Id :" . $businessName, (string) $ticket);
            //  echo "Roles are not defined for business Id :" . $business_id;
        }
        $role_id = $roles['role'];
        $skill = $roles['skill'];
        $businessName = $roles['businessid'];
        $subbusinessName = $roles['subbusinessid'];
        // payload to get slots
        //$from_date = $to_date = '2018-11-22'; $business_id = 1; $sub_business_id = 2;
        $sub_url = ""; //UPDATE CONFIG FILE TO UPDATE SUB_URL to""
        $api_key = $this->config->getConfig("chissapikey", $sub_url);
        $curl_params = array(
            "api_key" => $api_key, // constant
            "engagement_level" => 1, //Mandatory (1-@Home,2-@center,3-@Platform)
            "from_date" => $from_date, //Mandatory
            "to_date" => $to_date, //Mandatory
            "role_id" => $role_id, //Mandatory
            "pin_code" => $pin_code,
            //"preferred_officer" =>$preferred_officer,
            "skill" => $skill, // "1,2,3", //1-Achiever,2-Competent,3-Expert
            "associate_id" => "",
            "branch_id" => "",
            "business_id" => $businessName,
            "sub_business_id" => $subbusinessName,
            "service_did" => $service_id, //"TS1801CAHPKA1",
            "patient_mrn" => $patient_mrn,
            "patient_age" => $patient_age,
            "patient_gender" => $patient_gender, //2,
            "order_latitude" => $latitude,
            "order_longitude" => $longitude,
        );
        if ($preferred_officer != "") {
            $curl_params["preferred_officer"] = $preferred_officer;
            $curl_params["engagement_level"] = 3; //Mandatory (1-@Home,2-@center,3-@Platform)
            unset($curl_params["pin_code"]);
            unset($curl_params["role_id"]);
        }

        //FOR MEDICINE ORDERS
        if (isset($payload->normal_slots)) {
            $curl_params['normal_slots'] = $payload->normal_slots;
        }

        // echo json_encode($curl_params);exit;
        $chiss_payload = $curl_params;
        $chissobj = new Chiss;
        $slots = $chissobj->slot($chiss_payload, $ticket);
        //print_r($slots); exit;
        if ($slots['status'] != 1) {
            $data = array("success" => "0", "message" => "No slots are available");
            return $data;
        }

        $data = array("success" => "1", "role_id" => $role_id, "message" => "Slots are available", "data" => $slots['slots']);
        return $data;
    }

    /**
     * Get cart and send to MDM
     *
     *
     */
    public function getCart($payload, $ticket)
    {
        $transaction_code = $payload->transaction_code;
        $action = $payload->action; //1: Cancellation, 2:Modification, 3:Reschedule
        $line_item = $payload->line_item;
        //-------------get transaction collection based on transaction_code ------------

        $filter = ['transaction_code' => $transaction_code]; //1-311218-7083020
        $documents = $this->dbo->findOne("masters", "transaction", $filter, array("orders" => 0, "payment_info" => 0));
        if (empty($documents)) {
            return array("status" => 0, "code" => "10300", "message" => "Invalid transaction_code");
        }
        $orders = $documents["order_info"];
        $order_ids = [];
        foreach ($orders as $item) {
            $order_ids[] = $item['order_id'];
        }

        $filter = array('_id' => ['$in' => $order_ids]);
        $project = array( /*"order.patientinfo" => 0, "order.order_status" => 0,*/"order.payment_info" => 0, "workorderinfo" => 0);
        $documents = $this->dbo->find("masters", "orders", $filter, $project);
        $lineItems = array();
        $grossAmount = $couponAmount = $netAmount = 0;
        $coupon = "";
        foreach ($documents as $doc) {
            $patientinfo = $doc['order']['patientinfo'];
            $order_status = $doc['order']['order_status']['order_status'];
            $payment_mode = $doc['order']['payment_info']['payment_mode'];
            $orderDate = date("Y-m-d\TH:i:s", strtotime($doc['order']['order_status']['created_date'])) . '.000Z';
            foreach ($doc['order']['orderitem'] as $x) {
                $sessions = $x['quantity'];
                if (empty($sessions)) {$sessions = 1;}

                $consultationMode = $x['quantity'];
                if (empty($sessions)) {$consultationMode = 1;}

                $unitPrice = $x['item_mrp'];
                if ($patientinfo['service_type'] == 2) {
                    $unitPrice = $x['item_mrp'];
                }

                $isPaid = false;
                if ($payment_mode == "Online") {
                    $isPaid = true;
                }
                $item = array(
                    "business" => intval($patientinfo['service_type']),
                    "mrn" => $patientinfo['mrn'],
                    "code" => $x['item_code'],
                    "pop" => $patientinfo['facility_id'],
                    "sessions" => $sessions,
                    "source" => $x['source'],
                    "consultationMode" => null, // should be dynamic
                    "orderDate" => $orderDate,
                    //"sub_business_id" => intval($patientinfo['service_subtype_id']),
                    "action" => $action,
                    "orderstatus" => $order_status,
                    "unitPrice" => $unitPrice, // should be dynamic
                    "grossAmount" => $x['gross_amount'],
                    "apportionedDiscountAmount" => $x['discount_amount'],
                    "netAmount" => $x['net_amount'],
                    "payabaleAmount" => $x['net_amount'],
                    "isPaid" => $isPaid, // should be dynamic
                    "patient_id" => $patientinfo['patient_id'],
                    "corporateid" => $patientinfo['corporateid'],
                    "age" => $patientinfo['age'],
                    "gender" => $patientinfo['gender'],
                    "pincode" => $patientinfo['pincode'], // delivery address pincode
                    "coupon" => $coupon = $patientinfo['coupon'],
                );
                array_push($lineItems, $item);
            }
            // aggregate payment
            $grossAmount += floatval($doc['payment_info']['gross_amount']);
            $couponAmount += floatval($doc['payment_info']['coupon_amount']);
            $netAmount += floatval($doc['payment_info']['net_amount']);
        }
        $data['source'] = $source;
        $data['grossAmount'] = $grossAmount;
        $data['couponAmount'] = $couponAmount;
        $data['netAmount'] = $netAmount;
        $data['coupon'] = $coupon;
        $data['lineItems'] = $lineItems;
        return array("status" => 1, "code" => "10100", "message" => "Data Available", "data" => $data);
    }

    public function getOrderWithBillingDetails($payload)
    {
        $utilityobj = new Utility;
        $dbo_obj = new Dbo;
        $filter = array();
        $filterSecond = array();
        /*if(isset($payload->orderStatus) && is_array($payload->orderStatus)){
        if(is_array($payload->orderStatus)){
        $filter["OStatus"]=array('$in'=>$payload->orderStatus);
        $date_required="1";
        $necessary_project["OStatus"]=1;
        }else{
        $responce["message"]="Please provide orderStatus value in array format.";
        return json_encode($responce);
        }
        }*/
        $searchdatetype = "order.order_status.created_date";
        if (isset($payload->dateFilter) && trim($payload->dateFilter) != "" && in_array($payload->dateFilter, array("created_date", "scheduled_date"))) {
            if ($payload->dateFilter == "scheduled_date") {
                $searchdatetype = "order.patientinfo.scheduled_date";
            } else if ($payload->dateFilter == "created_date") {
                $searchdatetype = "order.order_status.created_date";
            }
        }
        $necessary_project[$searchdatetype] = 1;
        $sort = $searchdatetype;

        if (isset($payload->startDate) && isset($payload->endDate) && $payload->startDate != "" && $payload->endDate != "") {
            $end_date = date('Y-m-d', strtotime('+1 days', strtotime($payload->endDate)));
            $filter[$searchdatetype] = array('$gte' => $payload->startDate, '$lt' => $end_date);
            if ($utilityobj->validateDate_Ymd($payload->startDate) == false || $utilityobj->validateDate_Ymd($payload->endDate) == false) {
                $responce["message"] = "startDate and endDate format is invalid. please provide date in yyyy-mm-dd format.";
                return json_encode($responce);
            }
        } else {
            $responce["message"] = "Please provide start date and end date.";
            return json_encode($responce);
        }

        if (isset($payload->associateId) && trim($payload->associateId) != "") {
            $filter["order.provider_info.associate_id"] = $payload->associateId;
        }

        if (isset($payload->associateBranchId) && trim($payload->associateBranchId) != "") {
            $filter["order.provider_info.associate_branch_id"] = $payload->associateBranchId;
        }

        $filter["billing.payment_status"] = array('$ne' => "3");
        $filter["billing.billing_status"] = array('$ne' => "3");
        $filter["version"] = "3";

        //Only get provider_info of array type(BSON of array is 4)
        //$filter['order.provider_info'] = array('$type'=> 4);
        //joining two tables

        $projectFirst = array(
            "odid" => 1,
            "OStatus" => 1,
            "order.patientinfo.scheduled_date" => 1,
            "order.patientinfo.completed_time" => 1,
            "order.order_status.created_date" => 1,
            "order.order_status.order_id" => 1,
            "billing" => 1,
            "order.provider_info" => 1,
            "provider_info" => array('$arrayElemAt' => array('$order.provider_info', -1)),
        );

        $lookup = array(
            "from" => "billing_info",
            "localField" => "_id",
            "foreignField" => "billing.patientinfo.order_id",
            "as" => "BillDetails",
        );

        $projectSecond = array(
            "BillDetails.billing.patientinfo.order_id" => 1,
            "BillDetails.billing.billinginfo" => 1,
            "BillDetails.billing.receiptinfo" => 1,
            "odid" => 1,
            "OStatus" => 1,
            "order.patientinfo.scheduled_date" => 1,
            "order.patientinfo.completed_time" => 1,
            "order.order_status.created_date" => 1,
            "order.order_status.order_id" => 1,
            "order.provider_info" => 1,
            "billing" => 1,
        );

        $filterSecond["BillDetails.billing.patientinfo.order_id"] = array('$exists' => "true");
        $filterSecond["BillDetails.billing.billinginfo.payment_status"] = array('$ne' => "3");
        $filterSecond["BillDetails.billing.billinginfo.billing_status"] = array('$ne' => "3");
        $filterSecond["BillDetails.billing.receiptinfo.payment_mode"] = array('$in' => array("cash", "Cash", "CASH"));
        if (isset($payload->associateId) && trim($payload->associateId) != "") {
            $filterSecond["BillDetails.billing.receiptinfo.associate_id"] = $payload->associateId;
        }
        if (isset($payload->associateBranchId) && trim($payload->associateBranchId) != "") {
            $filterSecond["BillDetails.billing.receiptinfo.associate_branch_id"] = $payload->associateBranchId;
        }

        $pipeline = array(
            array('$match' => $filter),
            array('$project' => $projectFirst),
            array('$lookup' => $lookup),
            array('$match' => $filterSecond),
            array('$project' => $projectSecond),
        );
        //print_r($pipeline); exit;
        //print_r(json_encode($pipeline)); exit;
        $billorder_data = $dbo_obj->aggregate("masters", "orders", $pipeline);
        return $billorder_data;
        if (count($billorder_data) > 0) {
            $responce["status"] = 1;
            $responce["message"] = "Success";
        }
        $responce["data"] = $billorder_data;
        $responce["countn"] = count($billorder_data);

        return $responce;
    }

    public function received_themoney_from_officer($payload)
    {
        date_default_timezone_set("Asia/Calcutta");
        $recipt_id = $payload->recipt_id;
        $billing_id = $payload->billing_id;
        $user_name = $payload->user_name;
        $user_id = $payload->user_id;
        $response = array("status" => "0", "message" => "Payment is received info. is not update.");

        $filter = array("billing.billinginfo.billingid" => $billing_id);
        $document = $order = $this->dbo->findOne("masters", "billing_info", $filter, array("billing" => 1));
        $due_amount = (float) isset($document["billing"]["billinginfo"]["due_amount"]) ? $document["billing"]["billinginfo"]["due_amount"] : "NA";
        $collectedamount = 0;
        $totalsubmittedamount = 0;
        foreach ($document["billing"]["receiptinfo"] as $receipt) {
            if ($receipt["receipt_id"] == $recipt_id) {
                $totalsubmittedamount = $totalsubmittedamount + (float) $receipt["receipt_amount"];
            }
            if ((int) $receipt["payment_submited"] > 0 && (int) $receipt["payment_collected"] > 0) {
                $totalsubmittedamount = $totalsubmittedamount + (float) $receipt["receipt_amount"];
            }
            if ((int) $receipt["payment_submited"] < 1 && (int) $receipt["payment_collected"] > 0) {
                $collectedamount = $collectedamount + (float) $receipt["receipt_amount"];
            }
        }
        $setbill = array(
            "billing.receiptinfo.$.payment_submited" => 1,
            "billing.billinginfo.submitted_amount" => $totalsubmittedamount,
        );
        $payable_amount = (float) $document["billing"]["billinginfo"]["payable_amount"];
        //print_r($totalsubmittedamount); exit;
        /*if($totalsubmittedamount == $payable_amount){
        $setbill["billing.billinginfo.billing_status"]="3";
        $setbill["billing.billinginfo.payment_status"]="3";
        $setbill["billing.billinginfo.all_receipt_submitted"]="1";
        }*/
        if (isset($document["billing"]["billinginfo"]["payable_amount"]) && $totalsubmittedamount == $payable_amount) {
            $setbill["billing.billinginfo.billing_status"] = "3";
            $setbill["billing.billinginfo.payment_status"] = "3";
            $setbill["billing.billinginfo.all_receipt_submitted"] = "1";
        } else if ($totalsubmittedamount == $collectedamount && (int) $due_amount == 0) {
            $setbill["billing.billinginfo.billing_status"] = "3";
            $setbill["billing.billinginfo.payment_status"] = "3";
            $setbill["billing.billinginfo.all_receipt_submitted"] = "1";
        }

        $setbill["billing.receiptinfo.$.pop_id"] = $user_id;
        $setbill["billing.receiptinfo.$.pop_name"] = $user_name;
        $setbill["billing.receiptinfo.$.submited_date"] = substr(date("c", strtotime(date('Y-m-d H:i:s'))), 0, 19) . ".000Z";

        $filterforBilling = array("billing.billinginfo.billingid" => $billing_id, "billing.receiptinfo.receipt_id" => $recipt_id);
        $updatebill = $this->dbo->update("masters", "billing_info", $filterforBilling, $setbill, array(), array());
        //print_r($updatebill); exit;
        if ($updatebill[nModified] == 1) {
            if (isset($setbill["billing.billinginfo.payment_status"]) && $setbill["billing.billinginfo.payment_status"] == "3") {
                $setorder = array(
                    "billing.payment_status" => "3",
                    "billing.billing_status" => "3",
                );
                $filterforOrder = (int) $document["billing"]["patientinfo"]["order_id"];
                $update = $this->dbo->update("masters", "orders", array("_id" => $filterforOrder), $setorder, array(), array("multiple" => true));
            }
            $response = array("status" => "1", "message" => "Payment received info. is updated successfully.");
        }
        return $response;
    }

    //added by prakhar 22-1-2019----------------------------------
    public function getSampleTypeforBarcode($payload)
    {

        $filter = array("_id" => (int) $payload->order_id);
        $project = array("order.patientinfo.barcode" => 1);

        $cursor = $this->dbo->find("masters", "orders", $filter, $project, array());
        //echo json_encode($cursor);exit;

        $response = array("status" => "0", "data" => "No Records found");

        if ($this->dbo->countitem("masters", "orders", $filter) > 0) {
            //echo "here";exit;
            $response["countn"] = $this->dbo->countitem("masters", "orders", $filter);
            foreach ($cursor as $document) {
                $response['barcode'] = $document['order']['patientinfo']['barcode']['barcode'];
                $response['sampleType'] = $document['order']['patientinfo']['barcode']['sampleType'];
            }
            $response['data'] = "Barcode Retrieved Successfully";
            $response['status'] = "1";
            //$response["data"]=$result;
        }
        return $response;
    }

    public function getReceiptinfoByMhoID($payload)
    {

        /* $filterpatient = array(
        "billing.receiptinfo.mho_id" => $payload->assignedto,
        "billing.billinginfo.payment_status"=> array('$nin'=>"1","2")
        );*/

        $filter1 = array('$match' => array
            (
                "billing.receiptinfo.mho_id" => $payload->assignedto,
                //"billing.receiptinfo.payment_mode"=>array('$in'=>array('Cash','cash','CASH')),
                "billing.billinginfo.payment_status" => array('$ne' => "3"),
            ),
        );

        $filter2 = array('$unwind' => array('path' => '$billing.receiptinfo'));

        $filter3 = array('$match' => array("billing.receiptinfo.payment_collected" => 0));
        $project = array('$project' => array("billing.receiptinfo" => 1, "billing.billinginfo" => 1, "billing.patientinfo" => 1));

        $pipeline = array($filter1, $filter2, $filter3, $project);
        //echo json_encode($pipeline);exit;

        $cursor = $this->dbo->aggregate("masters", "billing_info", $pipeline);
        //echo json_encode($cursor);exit;

        $response = array("countn" => "0", "itemlist" => "No Records found");

        if (count((array) $cursor) > 0) {
            $response["countn"] = count((array) $cursor);
            $itemlist = array();
            foreach ($cursor as $document) {
                $receiptinfo = $document['billing']['receiptinfo'];
                //print_r($receiptinfo);exit;
                if (($receiptinfo['payment_collected'] == 0 || $receiptinfo['payment_collected'] == "0") &&
                    $receiptinfo['mho_id'] == $payload->assignedto) {
                    $receiptinfo['name'] = $document['billing']['patientinfo']['name'];
                    $receiptinfo['businessID'] = $document['billing']['patientinfo']['service_type'];
                    $receiptinfo['payment_status'] = $document['billing']['billinginfo']['payment_status'];
                    $receiptinfo['receipt_tracker_id'] = $document['billing']['billinginfo']['receipts_tracker_id'];
                    $receiptinfo['order_id'] = $document['billing']['billinginfo']['order_id'];
                    $receiptinfo['order_did'] = $document['billing']['billinginfo']['order_did'];
                    $receiptinfo['submitted_to'] = "0";
                    //$receiptinfo['name']=$document['billing']['patientinfo']['name'];

                    //$result[] = $receiptinfo;
                    //$result1[]=$result;
                    array_push($itemlist, $receiptinfo);
                }
            }
            $response["itemlist"] = $itemlist; //exit;
        }
        //echo json_encode($response);
        return $response;
    }

    public function getDebriefRecordByAppointmentID($payload)
    {

        //print_r($payload);exit;

        $filterpatient = array("appointmentid" => array('$in' => $payload->appointmentid));
        //print_r($filterpatient);exit;

        $cursor = $this->dbo->find('masters', 'debrief', $filterpatient, array(), array());
        //print_r($cursor);exit;

        $response = array("count" => "0", "itemlist" => array(), "msg" => "No Records found");

        if ($this->dbo->countitem("masters", "debrief", $filterpatient) > 0) {
            foreach ($cursor as $document) {
                $result[] = $document;
            }
            $response = array("count" => $this->dbo->countitem("masters", "debrief", $filterpatient), "itemlist" => $result, "msg" => "Records found");
        }
        return $response;
    }

    public function changestatus($order_status, $orderid, $reason, $reason_text, $comment, $count, $order_item)
    {
        $db = 'masters';

        $collection = 'orders';

        $filter = array('order.patientinfo.order_id' => (int) $orderid);

        $set = array('order.patientinfo.order_status' => $order_status, 'order.order_status.order_status' => $order_status, 'order.order_status.reason_id' => $reason, 'order.order_status.reason' => $reason_text, 'order.order_status.comment' => $comment, 'OStatus' => (int) $order_status, 'WOStatus' => (int) $order_status, 'order.order_status.last_updated_on' => date("Y-m-d") . "T" . date("H:i:s") . ".000Z");

        $push = array(); //EMPTY

        $options = array("multiple" => true);

        if ((int) $order_status == 8) {
            $i = 0;
            $set['order.patientinfo.order_cancel_date'] = date("Y-m-d") . "T" . date("H:i:s") . ".000Z";
            foreach ($order_item as $item) {
				if($item['item_status']!='8'){
					$set['order.orderitem.' . $i . '.item_status'] = '11';
					$set['order.orderitem.' . $i . '.item_cancel_reason'] = $reason_text;
					$set['order.orderitem.' . $i . '.item_cancel_date'] = (date("Y-m-d") . "T" . date("H:i:s") . ".000Z");
				}
                $i++;
            }
        }
        $cursor = $this->dbo->update($db, $collection, $filter, $set, $push, $options);

    }

    public function billing_cancel($receipts_tracker_id)
    {
        $db = 'masters';
        $collection1 = 'billing_info';
        $collection2 = 'orders';

        $filter = array("_id" => (int) $receipts_tracker_id);
        $set = array('billing.billinginfo.billing_status' => "2");
        $options = array("multiple" => true);

        $cursor1 = $this->dbo->update($db, $collection1, $filter, $set, array(), $options);

        $filter = array('order.order_status.receipts_tracker_id' => (int) $receipts_tracker_id);
        $set = array('billing.billing_status' => "2");
        $options = array("multiple" => true);

        $cursor2 = $this->dbo->update($db, $collection2, $filter, $set, array(), $options);

    }

    public function order_cancel($payload, $ticket)
    {
        $orderreq = $payload;
        $is_manual = 0;
        $disable_mad_rule = 0;
        if(isset($payload->is_manual)){
            if($payload->is_manual == 1){
                $is_manual = 0;
            }
        }
        if(isset($payload->disable_mad_rule)){
            if($payload->disable_mad_rule == 1){
                $disable_mad_rule = 1;
            }
        }
        $response = array();

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "order_cancel_start", $payload, (string) $ticket);

        if ($orderreq == "") {
            $response = array("status" => "0", "msg" => "Invalid Json Received. ");
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "order_cancel_Issue", json_encode($response), (string) $ticket);
            return $response;
        }

        if (empty($orderreq->order_id)) {
            $response[status] = "0";
            $response[msg] = "Need valid order_id field, in array format";
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "order_cancel_Issue", json_encode($response), (string) $ticket);
            return $response;
        }

        $madRulePayload = array(
            "entity" => "cancellation",
            "categoryId" => (int) $orderreq->categoryId,
            "subCategoryId" => (string) $orderreq->subCategoryId,
            "source" => (string) $orderreq->source,
            "order_id" => $orderreq->order_id,
        );
        $mdm = new Mdm;
        $madRuleResp = [];
        if($disable_mad_rule == 0){
            $madRuleResp = $mdm->isMadRulesApplied($madRulePayload, $ticket);
        }
        if($is_manual){
            $madRuleResp['requestBy'] = 'By CallHealth';
        }
        //print_r($madRuleResp);exit;

        $filterpatient = array("_id" => array('$in' => array_map('intval',$orderreq->order_id)));
        //$cursor = $collection->find($filterpatient);
        $cursor = $this->dbo->find('masters', 'orders', $filterpatient, array());

        $order_ids_present = array();
        $mrn = '';
        foreach ($cursor as $document) {
            $order_ids_present[] = $document[_id];
            $mrn = $document['order']['patientinfo']['mrn'];
        }

        // --- check weather penalty is exist or not order.patientinfo.mrn
        $filterP = ['mrn' => (int) $mrn, 'type' => 'PENALTY', 'status' => 4]; //255293 $document
        $penalties = $this->dbo->find("masters", "orders_refund_penalties", $filterP, []);
        $pAmount = 0;
        $penaltiesArr = [];
        foreach ($penalties as $itemm) {
            if (floatval($itemm['amount']) > 0) {
                $pAmount += floatval($itemm['amount']);
                $penaltiesArr[] = ['penalty_id' => (String) $itemm['_id'], 'amount' => $itemm['amount']];
            }
        }
        if (floatval($pAmount) > 0) {
            return array("status" => 0, "code" => "40700", "message" => "You have pending penalty, Please pay before cancelling order", 'data' => ['amount' => $pAmount, 'penalties' => $penaltiesArr]);
        }

        //print_r($order_ids_present);exit;
        if (!empty(array_diff($orderreq->order_id, $order_ids_present))) {
            $response[status] = "0";
            $response[msg] = "Order details for " . implode(",", array_diff($orderreq->order_id, $order_ids_present)) . " not found to cancel";

            $this->log->create_log("", "", $this->getname(), "Execution", 300, "order_cancel_Issue", json_encode($response), (string) $ticket);

            return $response;
        }

        $reason = isset($orderreq->reason) ? $orderreq->reason : "";
        $comment = isset($orderreq->comment) ? $orderreq->comment : "";

        //STATUS FLAG
        $flag = 1;
        $response_arr = array();

        if (count($cursor) > 0 and $cursor != null) {
            foreach ($cursor as $document) {
                $orderid = $document['_id']; //ORDERID
                $creation_type = $document['creation_type'];
                if ($document['order']['patientinfo']['service_type'] != 11) { // not for equipment
                    //MANDATORY FIELDS FOR EACH ORDER
                    $numFields = ['categoryId', 'subCategoryId', 'source'];
                    foreach ($numFields as $field) {
                        if ((!is_numeric($orderreq->{$field}) or !isset($orderreq->{$field})) and $creation_type != 1) {
                            $response[status] = "0";
                            $response[msg] = "Need a valid " . $field . " ,in numeric format";
                            $this->log->create_log("", "", $this->getname(), "Execution", 300, "order_cancel_Issue", json_encode($response), (string) $ticket);
                            return $response;
                        }
                    }
                }
                $servicetype = $document['order']['patientinfo']['service_type'];
                //MAD RULES APPLICABLE FOR NORMAL ORDERS ONLY
                if ($creation_type != 2) {
                    //COMMENTED FOR NOW
                    /* if($madRuleResp['isTicketRequired'] == 1)
                    {
                    //TICKET GENERATION API
                    $suburl = 'OMS/api/operation.php/v1/generateTicket';
                    $url = $this->config->getConfig('serverurl',$suburl);

                    $ticketPayload = json_encode(array('order_id' => $orderid));
                    $ticketResp = $this->utility->my_curl($url,'POST',$ticketPayload,'json',null,20);
                    //print_r($ticketResp);exit;
                    } */

                    $corporateid = $document['order']['patientinfo']['corporateid']; //
                    //echo json_encode($madRuleResp);exit;
                    if (($madRuleResp['isMadRuleApplied'] == 1 && empty($corporateid)) || $servicetype == "6" || $servicetype == "7" || $servicetype == "8") {
                        //CALL MAD RULE FUNCTION AND SKIP CANCELLATION IF STATUS = 0
                        if(!$is_manual){
                            require_once "OrderWorkFlow.php";
                            $owf = new OrderWorkFlow;
                            $pload = ["order_id" => $document['_id'], "action" => 1, "reason" => $reason, "comment" => $comment];
                            $tt = $owf->change_order_status_forlineitem((object) $pload, mt_rand(1000, 9999));
                        }
                        //print_r($tt);exit;
                        /* if ($tt['status'] == 0)
                    {
                    $flag = 0;
                    $resp_buffer[response] = "0";
                    $resp_buffer[msg] = "Cancellation of ".$orderid." failed";
                    array_push($response_arr,$resp_buffer);

                    continue;
                    } */
                    } else {
                        if (floatval($document['payment_info']['paid_amount']) > 0) {
                            $litems = [];
                            foreach ($document['order']['orderitem'] as $item) {
                                $litems[] = $item['item_code'];
                            }
                            // call refund api to create refund
                            $refundPayload = (Object) [
                                "transaction_code" => $document['transaction_code'],
                                "mrn" => $document['order']['patientinfo']['mrn'],
                                "username" => $document['order']['patientinfo']['name'],
                                "order_id" => $document['_id'],
                                "appointment_id" => null,
                                "odid" => $document['odid'],
                                "line_items" => $litems,
                                "action" => 1, // 1:Cancellation, 2:Modification, 3:Reschedule
                                "action_level" => 1, // 1:ORDER_LEVEL 2:ITEM_LEVEL
                                "reason" => $reason,
                                "comment" => $comment,
                                "amount" => $document['payment_info']['paid_amount'],
                            ];
                            $this->_create_refund($refundPayload, mt_rand(10000, 99999));
                        }
                    }
                }

                $order_type = $document['order']['ordertype'];
                $order_guidold = $document['order']['patientinfo']['order_guid'];
                $current_w_id = $document['wid'];
                $current_w_did = $document['wodid'];
                $current_time = $this->utility->getCurrentdatetimesimple();
                $current_order_status = $document['order']['order_status']['order_status'];
                $facility_id = $document['order']['patientinfo']['facility_id'];
                $popname = $document['order']['patientinfo']['popname'];

                $receipts_tracker_id = $document['order']['order_status']['receipts_tracker_id'];
                ///
                //$this->billing_cancel($receipts_tracker_id);

                //Order Status for Cancel
                $order_status = "8";
                if ($current_order_status == "17") {
                    $order_status = "11";
                }

                //Get Reason , Text and Comment
                $reason = $orderreq->reason;
                $reason_text = $orderreq->reason_text;
                $comment = $orderreq->comment;
                if ($reason_text != "") {
                    $reason_text = str_replace("\n", " ", $reason_text);
                }

                $mrn = $document['order']['patientinfo']['mrn'];
                $trans_id = $document['order']['patientinfo']['istransactioncare'];
                $count = count($document['order']['orderitem']);
                $order_item = $document["order"]["orderitem"];
                $type = $document['order']['patientinfo']['service_type'];
                $subtype = $document['order']['patientinfo']['service_subtype_id'];

                ///
                $this->changestatus($order_status, $orderid, $reason, $reason_text, $comment, $count, $order_item);

                $order_details[$orderid][reason] = $reason;
                $assignedid = "";
                $assignedname = "";

                $this->changeWoStatus($order_status, $orderid, $order_details, $current_w_id, $assignedid, $assignedname);

                ///
                //$this->generateCreditNote($orderreq->order_id);

                $filter = array("parent_order_id" => $orderid);
                $set = array("xray_count" => "0", "ultra_count" => "0", "cityscan_count" => "0", "mri_count" => "0");
                $options = array("multiple" => true);

                $cursor_u = $this->dbo->update('masters', 'asscociate_slots', $filter, $set, array(), $options);

                $resp_buffer = array();

                $resp_buffer[response] = "1"; //By default "1" any issue occurs changed to "0"
                $resp_buffer[msg] = "Order_id: " . $orderid . " is Cancelled";

                $this->log->create_log("", "", $this->getname(), "Execution", 200, "order_cancel", $resp_buffer, (string) $ticket);

                //NO chiss cancellation for transactional care, 1=>no cancellation,0=>cancel

                $chiss_cancel_payload = array("order_id" => (int) $document['_id'], "wo_id" => $current_w_id, "order_status" => "8");
                $chiss_cancel_payload = (object) $chiss_cancel_payload;

                //CALL FOR CANCELLATION IN CHISS
                $chiss_resp = $this->chiss_order_cancel(array($chiss_cancel_payload), $ticket);

                $resp_buffer['chiss_response'] = $chiss_resp;

                //for changing status in zero inventory(start)

                //for changing status in zero inventory(end)


                // for medicine business
                if(in_array((int)$current_order_status, [21,24,1000,1001]) ){
                    if(floatval($document['payment_info']['wallet_amount']) > 0){
                        // return wallet
                        $ms = new MedicineSupplies;
                        $wallet_response = $ms->walletTransaction("Medicine", $document['_id'], "credit", $document['payment_info']['wallet_amount'], $mrn, $ticket);

                        $set123['order.patientinfo.wallet_amount'] = $set123['payment_info.wallet_amount'] = 0.0;
                        $options123 = array("multiple" => true);
                        $filter123 = ['_id' => (int) $document['_id']];
                        $orderupdate = $this->dbo->update('masters', 'orders', $filter123, $set123, array(), $options123);
                    }
                }


                //for log get Role
                if (isset($orderreq->source)) {
                    $service_type = $document['order']['patientinfo']['service_type'];
                    $order_type = isset($document['order']['ordertype']) ? $document['order']['ordertype'] : "";
                    if ($service_type == "4" || $order_type == "childrad" || $order_type == "rad") {
                        $role = "Onsite Facilitator";
                    } else if ($service_type == "2") {
                        $role = "DDO";
                    } else if ($service_type == "5") {
                        $role = "HHO";
                    } else {
                        $role = "MHO";
                    }
                }

                $this->createlog($role, $order_status, "cancelled", $orderreq->actionById, $orderreq->actionByName, "Order Cancelled", $current_w_id, $current_w_did, $orderid, $reason_text, $comment, $facility_id, $popname);
                //logend

                //trigger email sms
                $event_flag = 1;
                if ($madRuleResp['requestBy'] != 'By CallHealth') {
                    $event_flag = 2;
                }
                $this->trigger_email_sms_event($document['_id'], 8, $document['active_component'], $document['mode_of_service'], $document['order']['patientinfo']['service_type'], $event_flag, $document['order']['patientinfo']['corporateid']);

                //buffers for child id and chiss response
                $id_log = array();
                $chiss_child = array();
                $childflag = 0;
                if ($type = "6" || $type == "7" || $type == "8") {
                    $is_parent = (int) $document['order']['business']['is_parent'];
                    $repeats = (int) $document['order']['business']['repeats'];
                    if ($is_parent == 1 && $repeats >= 2) {
                        $childflag = 1;
                    }
                }

                //Delete Care at home child orders.
                if ($childflag) {

                    $filterpatient = array("order.business.parent_id" => (int) $orderid);
                    //print_r($filterpatient);exit;

                    $cursor = $this->dbo->find('masters', 'orders', $filterpatient, array());

                    if (count($cursor) > 0 and !empty($cursor)) {
                        foreach ($cursor as $document) {

                            $current_w_id = $document['wid'];
                            $current_w_did = $document['wodid'];
                            $facility_id = $document['order']['patientinfo']['facility_id'];
                            $popname = $document['order']['patientinfo']['popname'];
                            $receipts_tracker_id = $document['order']['order_status']['receipts_tracker_id'];

                            //$this->billing_cancel($receipts_tracker_id);
                            $this->changestatus($order_status, $document['_id'], $reason, $reason_text, $comment, $count, $order_item);

                            ///    //$this->changeWoStatus_cancel($order_status,$current_w_id,$reason,$reason_text,$comment);

                            $this->changeWoStatus($order_status, $orderid, $order_details, $current_w_id, $assignedid, $assignedname);

                            //$resp_buffer=array("response"=>"1","msg"=>"Order cancelled.");
                            $id_log[] = $document[_id];
                            //echo json_encode($response);

                            $this->createlog($role, $order_status, "cancelled", $orderreq->actionById, $orderreq->actionByName, "Order Cancelled", $current_w_id, $current_w_did, (int) $document['_id'], $reason, $comment, $facility_id, $popname);

                            //$this->generateCreditNote($document['_id']);

                            $chiss_cancel_payload = array("order_id" => (int) $document['_id'], "wo_id" => $current_w_id, "order_status" => "8");
                            $chiss_cancel_payload = (object) $chiss_cancel_payload;

                            //CALL FOR CANCELLATION IN CHISS
                            $chiss_resp = $this->chiss_order_cancel(array($chiss_cancel_payload), $ticket);

                            $resp_buffer['chiss_response'] = $chiss_resp;

                        }

                        if ($id_log != null and !empty($id_log)) {

                            $child_response = array();
                            $child_response['msg'] =
                            "Order ids " . implode(",", $id_log) . " are cancelled";

                            $child_response['chiss_response'] = $chiss_child;

                            $resp_buffer['child_response'] = $child_response;

                        }
                    }

                }

                if (!empty($resp_buffer) and $resp_buffer != null) {
                    array_push($response_arr, $resp_buffer);
                } else {
                    $flag = 0;
                    $resp_buffer[response] = "0";
                    $resp_buffer[msg] = "Cancellation of " . $order_id . " failed";
                    array_push($response_arr, $resp_buffer);
                }
                //Delete Care at home child orders end.
            }

            $response[status] = (string) $flag;
            $response[msg] = $response_arr;
        } else {
            $response[status] = "0";
            $response[msg] = "Order details not found to cancel";
        }

        return $response;

    }

    public function chiss_wellness_creation($payload, $ticket)
    {

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "chiss_wellness_creation_start", $payload, (string) $ticket);

        if (!isset($payload->order_id) or $payload->order_id == "") {
            $response = array("status" => "0", "message" => "Need a valid parent order_id");
            return $response;
        }

        $order_id = (int) $payload->order_id;

        //Instances
        $dbo_obj = new Dbo;
        $utility_obj = new Utility;

        //Fetch parent order
        $mainfilter = array("_id" => (int) $order_id);
        $parent_order = $this->dbo->findOne('masters', 'orders', $mainfilter, array());
        //print_r($parent_order);exit;

        //NEED PARENT ORDER
        if ($parent_order[patientinfo][package_parent_id] != null) {
            $response = array("status" => "0", "message" => "Need a order_id that is a wellness parent order");
            return $response;
        }

        //Chiss payload
        $chiss_payload = array();

        if (gettype($parent_order[order][patientinfo][slot_transaction_id]) == "array") {
            $chiss_payload['tr_id'] = $parent_order[order][patientinfo][slot_transaction_id][0];
        } else {
            $chiss_payload['tr_id'] = $parent_order[order][patientinfo][slot_transaction_id];
        }

        $chiss_payload[package_service_did] = $parent_order[order][orderitem][0][item_code];
        $chiss_payload[is_package] = 'Y';
        $chiss_payload[pc_service_did] = $parent_order[order][business][primaryCoachCode]; //Add once confirmed
        $chiss_payload[wellness_speciality_code] = $parent_order[order][business][wellness_speciality_code];

        $orders_info = array();
        $subfilter = array('order.patientinfo.package_parent_id' => $order_id);
        $subproject = array('wid' => 1, 'order' => 1, 'mode_of_service' => 1, "active_component" => 1, "odid" => 1);
        $order_details = $this->dbo->find('masters', 'orders', $subfilter, $subproject, array());

        //print_r($order_details);exit;
        foreach ($order_details as $document) {
            $buffer = array();

            $patientinfo = $document[order][patientinfo];
            $order_status = $document[order][order_status];
            $associate_data = $document[order][provider_info];
            if (isset($document[order][business]) and !empty($document[order][business])) {
                $business = $document[order][business];
            }

            $buffer['order_id'] = $document[_id];
            $buffer['order_did'] = $document[odid];
            $buffer['wo_id'] = $document[wid];
            $active_component = $document[active_component];

            $buffer['order_status'] = "0"; //$order_status[order_status];// HardCoded for creation
            $buffer['engagement_level'] = $document[mode_of_service];
            $buffer['business_id'] = $patientinfo[service_type];
            $buffer['sub_business_id'] = $patientinfo[service_subtype_id];

            //CAN GET ROLE FROM PROVIDER_INFO NOW
            foreach ($associate_data as $associate) {
                if ($associate['component_no'] == $active_component) {
                    $buffer['role_id'] = $associate['role'];
                    $buffer['skill'] = $associate['skill'];
                }
            }

            $buffer['service_did'] = $document[order][orderitem][0][item_code];
            $buffer['patient_mrn'] = $patientinfo[mrn];

            //only IF HDFC Wellness packages exists
            if (isset($patientinfo['application_no']) and $patientinfo['application_no'] != null
                and trim($patientinfo['application_no']) != "") {
                $buffer['application_number'] = $patientinfo[application_no];
            }

            $businessid = $patientinfo[service_type];
            $subbusinessid = $patientinfo[service_subtype_id];
            $service_id = $buffer['service_did'];

            if ($businessid == 1 and $business[is_consultation] == 1) {
                $buffer['preferred_officer'] = $business[doctorId];
                $buffer['speciality_id'] = $business[specialityId];
            }

            if ($business[is_continuous] == 1) {
                $buffer['careplan'] = 'Y';
                $buffer['session_id'] = $business['session_no'];

                $care_orders[] = $buffer['order_id'];
            }

            $patientinfo[age] = preg_replace("/[^0-9]/", "", $patientinfo[age]);
            $buffer['patient_age'] = $patientinfo[age];

            $gender = $this->utility->genderStringtoNumber($patientinfo[gender]);
            $buffer['patient_gender'] = $gender;
            $buffer['pin_code'] = $patientinfo[pincode];
            $buffer['order_latitude'] = $patientinfo[delivery_lat];
            $buffer['order_longitude'] = $patientinfo[delivery_lng];

            $buffer['type_of_date'] = 1; //HARDCODED FOR NOW

            $buffer['schedule_date'] = $this->utility->convert_date($patientinfo[scheduled_date]); //TO BE GIVEN WHEN type_of_date = 1

            $orders_info[] = $buffer;
        }

        //print_r($orders_info);exit;
        $chiss_payload[orders_info] = $orders_info;

        //echo json_encode($chiss_payload);exit;

        ////
        //CALL CHISS API
        ////
        $chissobj = new Chiss;
        $output = $chissobj->get_wellness_officer($chiss_payload, $ticket);
        //print_r($output);exit;

        $output = $output[0];

        if ((int) $output['status'] == 1) {
            $health_coach = $output['health_coach'];
            $secondary_coach = $output['secondary_coach'];
            $order_result = $output['order_result'];

            $flag = 1;
            $order_ids_assigned = array();
            $manual_alloc_payload = array();
            $manual_alloc_payload["allocated_by"] = "4";
            $manual_alloc_payload["assigning_officer_id"] = "CH155";
            $manual_alloc_payload["assigning_officer_name"] = "CHISS";
            foreach ($order_result as $order_response) {
                if ((int) $order_response[status] == 2) {
                    $order_ids_assigned[] = $order_response[order_id];

                    //GETTING ASSOCIATEINFO DONE IN
                    /* if (isset($order_response[branch_id])) {
                    $associate_branch_ids[]
                    = array($order_response[associate_id], $order_response[branch_id]);
                    } else {
                    $associate_branch_ids[] = array($order_response[associate_id]);
                    }

                    $associates = array((object)$associate_branch_ids);
                    //print_r($associates);exit;
                    $associate_obj = new Associate;
                    $associate_output = $associate_obj->get_associate_info($associates); */

                    // UPDATION REMOVED

                    $ord_creation_data = array("order_id" => $order_response[order_id]
                        , "workorder_id" => $order_response[wo_id]
                        , "associate_id" => $order_response[associate_id]
                        , "branch_id" => $order_response[branch_id]
                        , "officer_id" => $order_response[officer_id]
                        , "officer_name" => $order_response[officer_name]
                        , "officer_contact_number" => $order_response[contact_number]
                        , "date_Changed" => true
                        , "scheduled_date" => $order_response['order_start_time']
                        , "health_coach" => $health_coach
                        , "secondary_coach" => $secondary_coach,
                    );

                    $manual_alloc_payload["orders"][] = (object) $ord_creation_data; //(object)
                }

            }

            //MANUAL ALLOCATION
            if (!empty($manual_alloc_payload["orders"]) and $manual_alloc_payload["orders"] != null) {
                //IF positive response from chiss

                try {
                    $response = $this->manual_allocation((object) $manual_alloc_payload, $ticket);

                    //INSERT HEALTH_COACH AND SECONDARY_COACH IN PARENT WELLNESS ORDER IF WELLNESS PACKAGE AS WE ONLY GET HEALTH_COACH VALUE AFTER CHISS ALLOCATION
                    $filt = array("_id" => $order_id);
                    $set = array("order.business.health_coach" => $health_coach,
                        "order.business.secondary_coach" => $secondary_coach,
                    );
                    try
                    {
                        $upd_cur = $this->dbo->update('masters', 'orders', $filt, $set, array(), array());

                        $financeobj = new Finance;
                        $financeobj->generateBill((object) array("OrderID" => $order_id));
                    } catch (Exception $e) {
                        $Error = array("WellnessUpdationError" => $e->getMessage());
                        $logobj->create_log("", "", getname(), "Execution", 300, "chiss_wellness_creation_Error", json_encode($Error), (string) $ticket);
                    }
                }

                //catch exception
                 catch (Exception $e) {
                    echo 'Message: ' . $e->getMessage();
                    $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_manual_alloc", $e->getMessage(), (string) $ticket);
                }

            } else {
                //IF negative response from chiss
                $response = $output;
            }
        } else {
            //IF negative response from chiss
            $response = $output;
        }
        //print_r($response);exit;
        //$output = json_encode($output);
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "chiss_wellness_creation_end", $response, (string) $ticket);
        return $response;

    }

    public function change_order_cp($payload, $ticket)
    {

        $status = $payload->status;
        $payload->reasonType = (intval($payload->reasonType)) ? intval($payload->reasonType) : 1;

        if ($status == 8) {
            $response = $this->order_cancel($payload, $ticket);
        } else if ($status == 7) {

            $owf = new OrderWorkFlow;
            $response = $owf->change_order_status($payload, $ticket);
        } else {
            $response = array("status" => 0, "message" => "Status not supported");
        }

        $request = array("transaction_code" => $payload->transaction_code);
        $result = $this->getordersbyfilter((object) $request);
        //print_r($result[data]);exit;
        $transaction = $result[data];
        $response['transaction'] = $transaction;
        return $response;
        //exit;
        //end of foreach

        //return $result;
    }

    public function refundedOrders($payload)
    {
        // print_r($payload);exit;
        $utilityobj = new Utility;
        $date_required = "0";
        $searchdatetype = "created_on";
        $responce["countn"] = 0;
        $responce["data"] = [];
        if (!empty($payload->type)) {
            $filter["type"] = (int) $payload->type;
        }
        if (!empty($payload->mrn)) {
            $filter["mrn"] = (int) $payload->mrn;
            $payload->startDate = $payload->endDate = null;
        }
        if (!empty($payload->order_did)) {
            $filter["odid"] = $payload->order_did;
            $payload->startDate = $payload->endDate = null;
        }
        if (!empty($payload->search_refund_status)) {
            $filter["status"] = (int) $payload->search_refund_status;
            $payload->startDate = $payload->endDate = null;
        }
        //echo count($filter);exit;
        if (!empty($payload->startDate) && !empty($payload->endDate)) {
            $end_date = date('Y-m-d', strtotime('+1 days', strtotime($payload->endDate)));
            $filter[$searchdatetype] = array('$gte' => $this->dbo->date(strtotime($payload->startDate)), '$lte' => $this->dbo->date(strtotime($end_date)));
        }

        /*
        if ($date_required == "1" || count($filter) <= 1) {
        if (isset($payload->startDate) && isset($payload->endDate) && $payload->startDate != "" && $payload->endDate != "") {
        $end_date = date('Y-m-d', strtotime('+1 days', strtotime($payload->endDate)));
        $filter[$searchdatetype] = array('$gte' => $payload->startDate, '$lt' => $end_date);
        if ($utilityobj->validateDate_Ymd($payload->startDate) == false || $utilityobj->validateDate_Ymd($payload->endDate) == false) {
        $responce["message"] = "startDate and endDate format is invalid. please provide date in yyyy-mm-dd format.";
        return json_encode($responce);
        }

        } else {
        $responce["message"] = "Please provide start date and end date.";
        return json_encode($responce);
        }
        } */

        $filter["type"] = "REFUND";
        $project = array();
        //print_r(json_encode($filter));exit;
        $result = $this->dbo->find('masters', 'orders_refund_penalties', $filter, $project, array());
        if (!empty($result)) {
            $responce["countn"] = sizeof($result);
            $responce["data"] = $result;
        }
        // print_r($responce);exit;
        return $responce;
    }

    public function getUniqueStates($payload, $ticket)
    {
        $search = (string) $payload->searchBy;

        if (!empty($payload->searchBy)) {
            if ($search == "state") {
                $filter = array("order.patientinfo.state" => array('$nin' => array("null", "", null)));
                $fieldName = "order.patientinfo.state";
                $result = $this->dbo->distinct("masters", "orders", $fieldName, $filter);
            } else if ($search == "city") {
                $filter = array("order.patientinfo.city" => array('$nin' => array("null", "", null)));
                $fieldName = "order.patientinfo.city";
                $result = $this->dbo->distinct("masters", "orders", $fieldName, $filter);
            }
        } else {
            $response = array("status" => 0, "message" => "please provide search crieteria in request");
            echo json_encode($response);
        }
        return $result;
    }
    //--------------------------end------------

    public function _create_refund($payload, $ticket)
    {
        $data_i = array(
            "_id" => $this->dbo->id(),
            "transaction_code" => $payload->transaction_code,
            "mrn" => intval($payload->mrn),
            "username" => $payload->username,
            "order_id" => intval($payload->order_id),
            "odid" => $payload->odid,
            "appointment_id" => intval($payload->appointment_id),
            "lineitems" => $payload->line_items,
            "action" => intval($payload->action), // 1:Cancellation, 2:Modification, 3:Reschedule
            "action_level" => 2, // 1:ORDER_LEVEL 2:ITEM_LEVEL
            "reason" => $payload->reason,
            "comment" => $payload->comment, // to do
            "amount" => floatval($payload->amount),
            "type" => "REFUND", // REFUND || PENALTY
            "status" => 1, // REFUND(1:INITIATED:, 2:PROCESSING, 3:PROCESS_TO_BANK  8:REJECTED,) PENALTY(4:PENDING, 5:PAID)
            "mad_rule_id" => null,
            "penalty_code" => null,
            "penalty_type" => null,
            "created_on" => $this->utility->getCurrenttime(), "log" => array(array(
                "status" => "1",
                "created_on" => $this->utility->getCurrenttime(),

                "comments" => "refund initiated",
            )),
        );
        $this->dbo->insert("masters", "orders_refund_penalties", $data_i);
        $filterTT = array('_id' => (int) intval($payload->order_id));
        $setTT['order.business.refundApplicable'] = true;
        $this->dbo->update("masters", "orders", $filterTT, $setTT, [], array("multiple" => true));

    }

    public function removePrescriptions($payload, $ticket)
    {
        $order_id = $payload->order_id;
        $filename = $payload->name;

        if (empty($order_id)) {
            $response = array("status" => 0, "message" => "Please provide order_id");
            return $response;
        }

        if (empty($filename)) {
            $response = array("status" => 0, "message" => "Please provide filename");
            return $response;
        }

        $filter = array("_id" => (int) $order_id);

        $mainOrders = $this->dbo->findOne("masters", "orders", $filter, array());
        //echo json_encode($mainOrders);die;
        //print_r($mainOrders["order"]["prescription_images"]);exit;

        if (empty($mainOrders)) {
            $response = array("status" => 0, "message" => "No prescription found for this order");
            return $response;
        } else {
            foreach ($mainOrders["order"]["prescription_images"] as $foundPrescription) {
                if ($foundPrescription["filename"] == $filename) {
                    $pull = array("order.prescription_images" => array("filename" => $filename));
                    //echo json_encode($pull);exit;
                    $result = $this->dbo->update("masters", "orders", $filter, array(), array(), $pull, array(), array());
                }
            }
            if ($result["nModified"] == 1) {
                $response = array("status" => 1, "message" => "Prescription removed successfully");
                return $response;
            } else {
                $response = array("status" => 0, "message" => "Prescription removal not successfull");
                return $response;
            }
        }
    }
    public function getPenaltyRefundDetails($payload, $ticket)
    {
        $order_id = $payload->order_id;

        if (empty($order_id)) {
            $response = array("status" => 0, "message" => "Please provide order_id");
            return $response;
        }

        $filter = array("order_id" => (int) $order_id, "type" => "PENALTY");
        $getOrder = $this->dbo->find("masters", "orders_refund_penalties", $filter, array(), array());
        // echo json_encode($getOrder);exit;

        if (empty($getOrder)) {
            $response = array("status" => 0, "message" => "Neither refund nor penalty found for this order. Please check order_id and try again");
            return $response;
        }

        $response = array("status" => 1, "message" => "Penalty found for this order", "data" => $getOrder);
        return $response;

    }

    public function getAllPendingPaidDetails($payload, $ticket)
    {
        $order_id = $payload->order_id;

        if (empty($order_id)) {
            $response = array("status" => 0, "message" => "Please provide order_id");
            return $response;
        }

        $match = array('$match' => array(
            "order_id" => (int) $order_id,
            "type" => "PENALTY",
            "status" => array('$in' => array(4, 5)),
        ),
        );

        $group = array(
            '$group' => array(
                "_id" => array('type' => '$type', 'status' => '$status'),
                "amount" => array('$sum' => '$amount'),
            ),
        );

        $pipeline = array($match, $group);
        //echo json_encode($pipeline);
        $penPaidResult = $this->dbo->aggregate("masters", "orders_refund_penalties", $pipeline);

        //return $result;

        $res = array("PenaltiesPaid" => 0, "PenaltiesPending" => 0);

        foreach ($penPaidResult as $pp) {
            if ($pp['_id']['status'] == 5) {
                $res['PenaltiesPaid'] += $pp['amount'];
            }
            if ($pp['_id']['status'] == 4) {
                $res['PenaltiesPending'] += $pp['amount'];
            }
        }
        return $res;
    }

    public function unAssignedOrdersChiss($ticket)
    {
        try
        {
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "unAssignedOrdersChiss_start", "GetRequest", (string) $ticket);

            $date = $this->utility->getCurrentdatetime();
            $date = $this->dbo->date(strtotime($date));
            //FUTURE ORDERS AFTER 25MINUTES
            //$date = substr(date("c", strtotime(date('Y-m-d H:i:s',strtotime('+ 25minute',strtotime($date))))), 0, 19) . ".000Z";

            $order_filter = array("order.patientinfo.servicedate" => array('$gt' => $date), "OStatus" => 0);

            $order_project = array('wid' => 1, 'order' => 1, "odid" => 1, "active_component" => 1, "mode_of_service" => 1);

            //echo json_encode(array($order_filter, $order_project));exit;
            $order_details = $this->dbo->find('masters', 'orders', $order_filter, $order_project, array("order.patientinfo.servicedate" => 1));

            $orders_info = array();
            foreach ($order_details as $document) {
                //print_r($document);
                //DATA IN LOOP TO BE CHANGED ACC. TO SPECIFICATIONS
                $buffer = array();

                $patientinfo = $document[order][patientinfo];
                $order_status = $document[order][order_status];
                $associate_data = $document[order][provider_info];
                if (isset($document[order][business]) and !empty($document[order][business])) {
                    $business = $document[order][business];
                }

                $buffer['order_id'] = $document[_id];
                $buffer['order_did'] = $document[odid];
                $buffer['wo_id'] = $document[wid];
                $active_component = $document[active_component];

                $buffer['order_status'] = "0"; // HardCoded for creation
                $buffer['engagement_level'] = $document[mode_of_service];
                $buffer['business_id'] = $patientinfo[service_type];
                $buffer['sub_business_id'] = $patientinfo[service_subtype_id];

                $ahelpinfo = array();
                //CAN GET ROLE FROM PROVIDER_INFO NOW
                foreach ($associate_data as $associate) {
                    if ($associate['component_no'] == $active_component) {
                        $buffer['role_id'] = $associate['role'];
                        $buffer['skill'] = $associate['skill'];
                        $buffer['associate_id'] = isset($associate['associate_id']) ? $associate['associate_id'] : "";
                        $buffer['branch_id'] = isset($associate['associate_branch_id']) ? $associate['associate_branch_id'] : "";

                    }
                    if ((int) $associate['component_no'] == 7) {
                        $ahelpinfo = $associate;
                    }
                }
                if ((int) $document[active_component] == 3 and ($patientinfo[service_type] == "3" || $patientinfo[service_type] == "4")) {
                    $buffer['associate_id'] = isset($ahelpinfo['associate_id']) ? $ahelpinfo['associate_id'] : "";
                    $buffer['branch_id'] = isset($ahelpinfo['associate_branch_id']) ? $ahelpinfo['associate_branch_id'] : "";
                }
                $buffer['service_did'] = $document[order][orderitem][0][item_code];
                $buffer['patient_mrn'] = $patientinfo[mrn];

                if (isset($patientinfo[application_no]) and $patientinfo[application_no] != null
                    and trim($patientinfo[application_no]) != "") {
                    $buffer['application_number'] = $patientinfo[application_no];
                }

                $businessid = $patientinfo[service_type];
                $subbusinessid = $patientinfo[service_subtype_id];
                $service_id = $buffer['service_did'];

                if ($businessid == 1 and $business[is_consultation] == 1) {
                    $buffer['preferred_officer'] = $business[doctorId];
                }

                if ($business[is_continuous] == 1) {
                    $buffer['careplan'] = 'Y';
                    $buffer['session_id'] = $business['session_no'];

                    $care_orders[] = $buffer['order_id'];
                }

                //PREVIOUSLY USED TO GET ROLE_ID AND SKILL
                //$roledata = $this->get_role_for_order($businessid, $service_id, $subbusinessid);
                //$buffer['role_id'] = $roledata['role'];
                //$buffer['skill'] = $roledata['skill'];

                $patientinfo[age] = preg_replace("/[^0-9]/", "", $patientinfo[age]);
                $buffer['patient_age'] = $patientinfo[age];

                $gender = $this->utility->genderStringtoNumber($patientinfo[gender]);
                $buffer['patient_gender'] = $gender;

                $buffer['pin_code'] = $patientinfo[pincode];
                $buffer['order_latitude'] = $patientinfo[delivery_lat];
                $buffer['order_longitude'] = $patientinfo[delivery_lng];

                $buffer['type_of_date'] = 1; //HARDCODED FOR NOW
                if ((int) $businessid == 3 and $active_component == "8") {
                    $buffer['type_of_date'] = 3;
                }

                $buffer['schedule_date'] = $this->utility->convert_date($patientinfo[scheduled_date]); //TO BE GIVEN WHEN type_of_date = 1

                /* $buffer['from_date'] = ""; //TO BE GIVEN WHEN type_of_date = 2
                $buffer['to_date'] = ""; //TO BE GIVEN WHEN type_of_date = 2
                $buffer['slot_timing_enum'] = 1; //TO BE GIVEN WHEN type_of_date = 2 */

                /* if (gettype($patientinfo[slot_transaction_id]) == "array") {
                $buffer['tr_id'] = (string)$patientinfo[slot_transaction_id][0];
                } else {
                $buffer['tr_id'] = (string)$patientinfo[slot_transaction_id];
                } */

                $orders_info[] = $buffer;
            }

            if (!empty($orders_info)) {
                $response = array("status" => 1, "message" => "Success", "count" => count($orders_info), "orders_info" => $orders_info);
            } else {
                $response = array("status" => 0, "message" => "No Orders Found", "orders_info" => $orders_info);
            }

            $this->log->create_log("", "", $this->getname(), "Execution", 200, "unAssignedOrdersChiss_end", $response, (string) $ticket);
        } catch (Exception $e) {
            $response = array("status" => 0, "errorMessage" => $e->getMessage());
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "unAssignedOrdersChiss_Error", $response, (string) $ticket);
        }

        return $response;

    }

    public function paymentDenial($payload, $ticket)
    {
        //print_r($payload);exit;
        $order_id = $payload->order_id;
        $category = $payload->category;
        $sub_category = $payload->order_id;
        $sub_category_description = $payload->order_id;
        $associate_id = $payload->associate_id;
        $associate_branch_id = $payload->associate_branch_id;
        $payload->type = "SR_complaints";
        $payload->subject = "Payment Denial";
        $sugarCRM = new SugarCRM;

        $response = $sugarCRM->raise_ticket($payload);
        return $response;
    }

    public function addMedicineVendor($payload, $ticket)
    {
        try
        {
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "addMedicineVendor_start", json_encode($payload), (string) $ticket);

            $source_type = isset($payload->source_type) ? $payload->source_type : "";
            $api_key = isset($payload->api_key) ? $payload->api_key : "";
            $response = array("status" => "0", "message" => "Please check the request parameter.");

            $collection = 'medicine_vendors';
            if (isset($payload->isEquipmentVendor) and $payload->isEquipmentVendor == true) {
                $collection = 'mequipment_vendors';
            }

            if ($source_type == 'Associate Portal' && $api_key == 'zxcvbn-456873-asdfgh-065432') {
                $vendor_id = $payload->vendor_id;
                $vendor_name = $payload->vendor_name;
                $vendor_email = $payload->vendor_email;
                $vendor_address = $payload->vendor_address;
                $vendor_pincode = $payload->vendor_pincode;
                $vendor_statename = $payload->vendor_statename;
                $vendor_lat = isset($payload->vendor_lat) ? $payload->vendor_lat : "";
                $vendor_long = isset($payload->vendor_long) ? $payload->vendor_long : "";
                $vendor_mobile = isset($payload->vendor_mobile) ? $payload->vendor_mobile : "";
                $vendor_license = isset($payload->vendor_license) ? $payload->vendor_license : "";
                $vendor_gstno = isset($payload->vendor_gstno) ? $payload->vendor_gstno : "";
                $devide_vendor_id = explode("0", $vendor_id);
                $vendor_type = $devide_vendor_id[0];
                $sessionid = "";

                $sub_url = 'mdm/services/crud/PinCode/' . $vendor_pincode; //UPDATE CONFIG FILE TO UPDATE SUB_URL to""
                $url = $this->config->getConfig("cpservicepath", $sub_url);
                $headersetcurl = array("Content-Type: application/x-www-form-urlencoded", "Authorization:" . $sessionid);
                $fact_result = $this->utility->common_curl($url, array(), 0, $headersetcurl);
                $fact_result = json_decode($fact_result);
                $vendor_facility_id = $fact_result->facilityID;

                $filter = array("_id" => $vendor_id);
                $project = array();
                $vdetails = $this->dbo->find('masters', $collection, $filter, $project, array());
                //print_r($vdetails);exit;
                if (count($vdetails) > 0 and $vdetails != null) {
                    $set = array();
                    if (trim($vendor_name) != "") {$set["userinfo.USER_NAME"] = $vendor_name;}
                    if (trim($vendor_email) != "") {$set["userinfo.EMAIL"] = $vendor_email;}
                    if (trim($vendor_address) != "") {$set["userinfo.ADDRESS"] = $vendor_address;}
                    if (trim($vendor_lat) != "") {$set["userinfo.LAT"] = $vendor_lat;}
                    if (trim($vendor_long) != "") {$set["userinfo.LONG"] = $vendor_long;}
                    if (trim($vendor_mobile) != "") {$set["userinfo.MOBILE"] = $vendor_mobile;}
                    if (trim($vendor_license) != "") {$set["userinfo.License_No"] = $vendor_license;}
                    if (trim($vendor_gstno) != "") {$set["userinfo.GST_No"] = $vendor_gstno;}

                    $result = $this->dbo->update("masters", $collection, $filter, $set, array(), array("multiple" => true));
                    if ($result[nModified] > 0) {
                        $response['status'] = '1';
                        $response['message'] = 'Vendor Updated Successfully';
                    } else if ($result[ok] == 1) {
                        $response['status'] = '1';
                        $response['message'] = 'Vendor details unchanged.';
                    }
                } else {
                    $insertdata = array(
                        '_id' => $vendor_id,
                        'userinfo' => array(
                            'USER_ID' => $vendor_id,
                            'USER_NAME' => $vendor_name,
                            'EMAIL' => $vendor_email,
                            'PASSWORD' => '2ac9cb7dc02b3c0083eb70898e549b63',
                            'ACTIVE_INACTIVE_E' => '1',
                            'FACILITY_ID' => "" . $vendor_facility_id,
                            'vendor_type' => $vendor_type,
                            'GROUP_NAME' => 'Vendor',
                            'GROUP_ID' => '10001',
                            "ADDRESS" => $vendor_address,
                            "LAT" => $vendor_lat,
                            "LONG" => $vendor_long,
                            "MOBILE" => $vendor_mobile,
                            "License_No" => $vendor_license,
                            "GST_No" => $vendor_gstno,
                            'STATE' => array(array('statename' => $vendor_statename)),
                        ),
                        'service_pop' => array(array('FACILITY_NAME' => '', 'FACILITY_NAME' => '')),
                    );

                    $inserted_id = $this->dbo->insert("masters", $collection, $insertdata);
                    if ($inserted_id[ok] == "1" || $inserted_id[ok] == 1) {
                        $response['status'] = '1';
                        $response['message'] = 'Vendor Added Successfully';
                    }
                }

            } else {
                $response['message'] = "API Key or Source Type not Matched!";
            }
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "addMedicineVendor_end", $response, (string) $ticket);
        } catch (Exception $e) {
            $response = array("status" => "0", "errorMessage" => $e->getMessage());
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "addMedicineVendor_Error", $response, (string) $ticket);
        }
        return $response;
    }

    public function updateScheduleDate($payload, $ticket)
    {
        try
        {
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "updateScheduleDate_START", "postRequest", (string) $ticket);

            $date = (string) $payload->new_scheduled_date;
            $order_id = $payload->order_ids;
            $reason = (string) $payload->reason;
            $actionById = (string) $payload->actionById;
            $actionByName = (string) $payload->actionByName;

            $mongoDate = substr(date("c", strtotime($date)), 0, 19) . ".000Z";
            $serviceDate = $this->dbo->date(strtotime($date)+19800);

            if ((empty($order_id) && is_array($order_id)) || empty($date)) {
                $response = array("status" => 0, "message" => "Please provide order_id in array and date in request");
                return $response;
            }

            $orderFilter = array("_id" => array('$in' => $order_id));
            //echo json_encode($orderFilter);exit;
            $orderResult = $this->dbo->find("masters", "orders", $orderFilter);
            //echo json_encode($orderResult);exit;
            if (empty($orderResult)) {
                $response = array("status" => 0, "message" => "No data found");
                return $response;
            } else {
                foreach ($orderResult as $key => $item) {
                    //print_r($item[createdById]);exit;
                    $filter = array("_id" => $item[_id]);
                    $set = array(
                        "order.patientinfo.scheduled_date" => $mongoDate,
                        "order.patientinfo.reason" => $reason,
                        "order.patientinfo.servicedate" => $serviceDate,
                        "createdById" => $actionById,
                        "createdByName" => $actionByName,
                    );

                    $push = array("flags"=>$reason);
                    $result = $this->dbo->update("masters", "orders", $filter, $set, $push);
                }
            }

            if ($result['nModified'] == 1) {
                $response = array("status" => 1, "message" => "Date updated successfully");
                return $response;
            } else {
                $response = array("status" => 0, "message" => "Date updation failed");
                return $response;
            }
        } catch (Exception $e) {
            $response = array("status" => 0, "errorMessage" => $e->getMessage());
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "updateScheduleDate_Error", $response, (string) $ticket);
        }

    }

    public function addCriteriaInfo($payload, $ticket)
    {
        try
        {
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "addCriteriaInfo_start", json_encode($payload), (string) $ticket);

            $response = array("status" => 0, "message" => "Operation Failed");

            if (!is_array($payload->orderId)) {
                $response["description"] = "Please provide order ids in array.";
                return $response;
            }

            $criteria_info = array();
            $orderId = $payload->orderId;
            $date = $this->utility->getCurrentdatetime();

            unset($payload->orderId);
            unset($payload->ticket);
            $payload->date_added = $date;

            $filter = array("_id" => array('$in' => $orderId));
            $set = array(
                "order.business.ignore_criteria" => (int)$payload->criteria,
            );
 
            $push = array('order.business.criteria_info' => $payload);
            //print_r($set);exit;

            try {
                $order_updation = $this->dbo->update("masters", "orders", $filter, $set, $push, array("multiple" => true));
                if ($order_updation['nModified'] > 0) {
                    $response = array("status" => 1, "message" => "Order updated successfully");
                }
            } catch (Exception $e) {
                $response = array("status" => 0, "QueryError" => $e->getMessage());
            }

        } catch (Exception $e) {
            $response = array("status" => 0, "errorMessage" => $e->getMessage());
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "addCriteriaInfo_end", json_encode($response), (string) $ticket);
        return $response;
    }

    public function getDependentOrders($payload, $ticket)
    {
        try
        {
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "getDependentOrders_start", json_encode($payload), (string) $ticket);

            $orderId = (int) $payload->orderId;

            //RETURN Order
            $match = array("_id" => $orderId);
            $lookup = array(
                "from" => "orders",
                "localField" => "order.business.reference_order_id",
                "foreignField" => "_id",
                "as" => "dependentOrder",
            );
            //$project = array("order"=>'$dependentOrder');

            $pipeline = array(array('$match' => $match), array('$lookup' => $lookup)); //,array('$project'=>$project));
            //echo json_encode($pipeline);exit;

            $response = array("status" => 0, "message" => "Data Not Found", "returnorder" => array(), "dependant" => array());

            try
            {
                $order_docs = $this->dbo->aggregate("masters", "orders", $pipeline);

                if (count($order_docs) > 0 and $order_docs != "") {
                    $ord = $order_docs[0];
                    $dependentOrder = $ord['dependentOrder'][0];
                    unset($ord['dependentOrder']);

                    $response = array("status" => 1, "message" => "Data Found", "returnorder" => $ord, "dependant" => $dependentOrder);
                }
            } catch (Exception $e) {
                $response = array("status" => 0, "QueryError" => $e->getMessage());
            }

        } catch (Exception $e) {
            $response = array("status" => 0, "errorMessage" => $e->getMessage());
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "getDependentOrders_end", json_encode($response), (string) $ticket);
        return $response;
    }

    public function getCampaignMrns($payload, $ticket)
    {
        try
        {
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "getCampaignMrns_start", json_encode($payload), (string) $ticket);

            $campaignId = $payload->campaignId;
            $testCodes = $payload->testCodes;
            $dateFrom = $payload->dateFrom;
            $dateTo = $payload->dateTo;

            //VALIDATIONS
            if ($campaignId == "" or trim($campaignId) == "") {
                $response = array("status" => 0, "message" => "campaignId is Invalid or Missing.");
                $this->log->create_log("", "", $this->getname(), "Execution", 200, "getDependentOrders_end", json_encode($response), (string) $ticket);
                return $response;
            }
            if (!is_array($testCodes)) {
                $response = array("status" => 0, "message" => "testCodes is Invalid or Missing, Need in array.");
                $this->log->create_log("", "", $this->getname(), "Execution", 200, "getDependentOrders_end", json_encode($response), (string) $ticket);
                return $response;
            }

            if ($this->utility->validateDate_Ymd($dateFrom) == false || $this->utility->validateDate_Ymd($dateTo) == false) {
                $response = array("status" => 0, "message" => "dateFrom or dateFrom format is invalid. please provide date in yyyy-mm-dd format.");
                $this->log->create_log("", "", $this->getname(), "Execution", 200, "getDependentOrders_end", json_encode($response), (string) $ticket);
                return $response;
            }

            //BUILD QUERY
            $match = array(
                "order.orderitem.item_code" => array('$all' => $testCodes),
                "order.orderitem.campaignId" => $campaignId,
                "order.patientinfo.servicedate" => array('$gte' => $dateFrom, '$lte' => $dateTo),
				"OStatus"=>6
            );

            $group = array("_id" => 1, "mrn" => array('$push' => '$order.patientinfo.mrn'));
            $project = array("mrn" => 1, "_id" => 0);

            $pipeline = array(array('$match' => $match), array('$group' => $group), array('$project' => $project));

            $response = array("status" => 1, "response" => 0, "mrn" => []);

            try
            {
                $order_docs = $this->dbo->aggregate("masters", "orders", $pipeline);
                if (count($order_docs) > 0 and $order_docs != "" and !empty($order_docs[0][mrn])) {
                    $response = $order_docs[0];
                    $response = array('status' => 1, 'response' => 1, 'mrn' => $order_docs[0][mrn]);
                }
            } catch (Exception $e) {
                $response = array("status" => 0, "QueryError" => $e->getMessage());
            }

        } catch (Exception $e) {
            $response = array("status" => 0, "errorMessage" => $e->getMessage());
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "getCampaignMrns_end", json_encode($response), (string) $ticket);
        return $response;
    }

    public function orderSearchByWO($payload,$ticket)
    {
        try
        {
            $this->log->create_log("", "", $this->getname(), "Execution", 200, "orderSearchByWO_start", json_encode($payload), (string) $ticket);

            $mrn = isset($payload->mrn) ? $payload->mrn : "";
            $customerName = isset($payload->patient_name) ? $payload->patient_name : "";
            $order_did = isset($payload->order_did) ? $payload->order_did : "";
            $officerId = isset($payload->officer_id) ? $payload->officer_id : "";
            $serviceType = isset($payload->service_type) ? $payload->service_type : "";
            $type = isset($payload->componentType) ? $payload->componentType : "";
            $status = (int)$payload->status;
            $fromDate = isset($payload ->startDate) ? $payload ->startDate : "";
            $toDate = isset($payload ->endDate) ? $payload ->endDate : "";

            if(empty($status) || $status!=1)
            {
                return array("status"=>0,"message"=>"Please provide status as 1 in request");
            }

            $orderData = $this->config->search_by_wo_status($status, $payload);
            $finalStatus = $orderData['orderinfo.final_status']['$in'];

            $componentData = $this->config->workorder_type_component_mapping($type);
            $componentType = $componentData['orderinfo.component_no']['$in'];

            //echo json_encode($componentType);exit;
            //echo json_encode($data['OStatus']['$in']);exit;
            
            
            $filter = array(
                "orderinfo.final_status" => array('$in'=>$finalStatus),
                "version" => array('$in' => array("3.0","3",3))
            );

            if(!empty($toDate) && !empty($fromDate))
            {
                $filter["orderinfo.scheduled_date"] = array('$gte' => $fromDate,'$lte' => $toDate); 
            }

            $filter["orderinfo.component_no"] = array('$in' => $componentType); 

            //echo json_encode($filter);exit;

            $lookup = array(
                "from" => "orders",
                "localField" => "orderinfo.order_id",
                "foreignField" => "_id",
                "as" => "orderDetails"
            );

            $unwind = array('$unwind' => '$orderDetails');

            //$project1 = array("order" => '$Details');


            $project = array
            (
                "order_id" => '$orderDetails._id',
                "order_did" => '$orderDetails.odid',               
                "workorder_did" => '$orderDetails.wodid',
                "workorder_id" => '$orderDetails.wid',
                "OStatus" => '$orderDetails.OStatus',
                "workOrderStatus" => '$orderDetails.WOStatus',
                "mrn" => '$orderDetails.order.patientinfo.mrn',
                "age" => '$orderDetails.order.patientinfo.age',
                "gender" => '$orderDetails.order.patientinfo.gender',
                "city" => '$orderDetails.order.patientinfo.city',
                "address" =>'$orderDetails.order.patientinfo.address',
                "pincode"  =>"orderDetails.order.patientinfo.pincode",
                "contact" =>'$orderDetails.order.patientinfo.contact',
                "email" =>'$orderDetails.order.patientinfo.email',
                "name" =>'$orderDetails.order.patientinfo.name',
                "service_type" =>'$orderDetails.order.patientinfo.service_type',
                "sub_service_type" => '$orderDetails.order.patientinfo.service_subtype_id',
                "role_id" =>'$orderDetails.order.patientinfo.role_id',
                "skill_id" =>'$orderDetails.order.patientinfo.skill_id',
                "delivery_lat" =>'$orderDetails.order.patientinfo.delivery_lat',
                "delivery_long" => '$orderDetails.order.patientinfo.delivery_lng',
                "scheduled_date" => '$orderDetails.order.patientinfo.scheduled_date',
                "expected_elivery_time" => '$orderDetails.order.patientinfo.expected_delivery_time',
                "gross_amount" => '$orderDetails.order.patientinfo.gross_amount',
                "discount_amount" => '$orderDetails.order.patientinfo.discount_amount',
                "net_amount" => '$orderDetails.order.patientinfo.net_amount',
                "wallet_amount" => '$orderDetails.order.patientinfo.wallet_amount',
                "voucher_amount" => '$orderDetails.order.patientinfo.voucher_amount',
                // '$orderDetails.order.patientinfo.medicine_delivery_charge'=>1,
                "voucher_code" => '$orderDetails.order.patientinfo.voucher_code',
                "coupon_amount" => '$orderDetails.order.patientinfo.coupon_amount',
                //'$orderDetails.order.patientinfo.surge_amount'=>1,
                "payment_amount" => '$orderDetails.order.patientinfo.payment_amount',
                "popname" => '$orderDetails.order.patientinfo.popname',
                "created_date" => '$orderDetails.order.order_status.created_date',
                "order_id" => '$orderDetails.order.order_status.order_id',
                "workorder_id" => '$orderDetails.order.order_status.workorder_id',
                "mhoname" => '$orderDetails.order.order_status.mhoname',
                "receipt_tracker_id" => '$orderDetails.order.order_status.receipts_tracker_id',
                "provider_info" => '$orderDetails.order.provider_info', 
                "orderitem" =>'$orderDetails.order.orderitem',
                "billing" => '$orderDetails.billing',
                "business" => '$orderDetails.order.business',

                "orderType" => '$orderDetails.order.ordertype',
                //'$orderDetails.ordertyp'=>1,
                "patient_id" => '$orderDetails.order.patientinfo.patient_id',
                "corporate_name" => '$orderDetails.order.patientinfo.corporatename',
                "order_id" => '$orderDetails.order.patientinfo.order_id',
                "gender_pref" => '$orderDetails.order.patientinfo.gender_pref',
                "order_id" => '$orderDetails.order.order_status.order_id',
                "order_status" => '$orderDetails.order.order_status.order_status',
                "odid" => '$orderDetails.order.order_status.order_did',
                "istransactioncare" => '$orderDetails.order.patientinfo.istransactioncare',
                "orderStats" => '$orderDetails.order.patientinfo.order_status',
                "landmark" => '$orderDetails.order.patientinfo.landmark',
                "corporate_name" => '$orderDetails.order.patientinfo.corporatename',
                "accociate" => '$orderDetails.order.assocdata',
                "transaction_code" => '$orderDetails.transaction_code',
                "created_b_id" => '$orderDetails.createdById',
                "channel" => '$orderDetails.channel',
                "active_component" => '$orderDetails.active_component',
                "mode_of_service" => '$orderDetails.mode_of_service',
                "created_by_name" => '$orderDetails.createdByName',
                "workorder_completed_time" => '$orderinfo.completed_time',
                "workorder_type"=>
                array(
                    array(

                        '$switch' => array(
                        'branches' => array(
             
                              array('case'=> array('$eq' =>['$orderinfo.component_no', "1" ] ),'then' =>"Phelbo" ),
                              array('case'=> array('$eq' =>['$orderinfo.component_no', "2" ] ),'then' =>"Nursing/Physio" ),
                              array('case'=> array('$eq' =>['$orderinfo.component_no', "3" ] ),'then' =>"ImagingPhelboAtCentre" ),
                              array('case'=> array('$eq' =>['$orderinfo.component_no', "7" ] ),'then' =>"AssociateLabs" ),
                              array('case'=> array('$eq' =>['$orderinfo.component_no', "8" ] ),'then' =>"Logistics"),
             
                         ),
                        'default' => "Did not match"
             
                        )
                    )
                )
            );

            $lookupWorkflow = array(
                'from' => 'workflow_status',
                'let' => array
                (
                    'mode_of_service' => '$mode_of_service',
                    'service_type' => '$service_type',
                    'order_status' => '$OStatus',
                    'component' => '$active_component',
                ),
                'pipeline' => array(array
                    (
                        '$match' => array
                        ('$expr' => array
                            ('$and' => array(
                                array('$eq' => array('$status', '$$order_status')),
                                array('$eq' => array('$Bid', '$$service_type')),
                                array('$eq' => array('$MOSid', '$$mode_of_service')),
                                array('$eq' => array('$Workflow', '$$component')),
                            ),
                            ),
                        )),
                    array('$project' => array("Nomenclature" => 1, '_id' => 0, "reschedule_block" => 1, "cancel_block" => 1)),
                ),
                'as' => 'data',
            );
 
            $filter2 = array();

            if(!empty($mrn))
            {
                $filter2["mrn"] = (string)$mrn;
            }

            if(!empty((string)$order_did)) 
            {
                $filter2["odid"] = array('$regex' => $order_did, '$options' => "i");
            }

            if(!empty($officerId))
            {
                $filter2["orderDetails.assigned_to"] = (string)$officerId;
            }

            if(!empty($serviceType))
            {
                $filter2["service_type"] = (string)$serviceType;
            }
            
            if(!empty($customerName))
            {
                $filter2["name"] = array('$regex' => $customerName, '$options' => "i");
            }

            //echo json_encode($filter2);exit;

            $sort = array('$sort'=> array('created_time'=>-1));

            $pipeline = array(array('$match' => $filter),array('$lookup' => $lookup),$unwind,array('$project' => $project),array('$lookup' => $lookupWorkflow),$sort);

            if(!empty($filter2))
            {
                $pipeline = array(array('$match' => $filter),array('$lookup' => $lookup),$unwind,array('$project' => $project),array('$match' => $filter2),array('$lookup' => $lookupWorkflow),$sort);
            }

            if (isset($payload->skip) && isset($payload->limit)) 
            {
                array_push($pipeline, array('$skip' => $payload->skip), array('$limit' => $payload->limit));
            }
            else
            {
                array_push($pipeline, array('$skip' => 0), array('$limit' => 100));
            }

            //echo json_encode($pipeline);exit; 

            $orderResult = $this->dbo->aggregate("masters","workorders",$pipeline);
            //echo json_encode($orderResult);exit;  
            if(empty($orderResult))
            {
                return array("status"=> 0, "message"=> "Completed workorders not found for this request.");
            }
            else 
            {
                return array("status"=> 1, "message"=> "Data Found", "data"=>$orderResult, "countn" => count($orderResult));
            }
 
        }
        catch (Exception $e) 
        {
            $response = array("status" => 0, "errorMessage" => $e->getMessage());
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "orderSearchByWO_end", json_encode($response), (string) $ticket);
        return $response;
    }
    
    public function applicationNoDetails($payload)
    {
        //print_r($payload);exit;
        //print_r($application_no);
        //$application_no = $payload->applicationNo;
        $filter = array("order.patientinfo.application_no"=>(string)$payload);
        //echo json_encode($filter);exit;
        $project = array("odid" => 1);

        $result = $this->dbo->find("masters","orders",$filter,$project);

        if(empty($result))
        {
            return array("status"=>0,"message"=>"No data found");
        }
        else
        {
            return array("status"=>1,"message"=>"data found","data"=>$result);
        } 
    }

    public function changeLatLongPincode($payload)
    {
        $latitude = $payload->lat;
        //print_r($latitude);exit;
        $longitude = $payload->long;  
        $pincode = $payload->pincode;
        $reason = $payload->reason;
        //print_r($pincode);exit;
        
        $order_ids = $payload->order_ids;

        if(empty($order_ids))
        {
            return array("status"=>0,"message"=> "Please provide order_ids in array format");
        }

        if(empty($reason))
        {
            return array("status"=>0,"message"=> "Please provide reason for updating order");
        }

        $orderFilter = array(
            "_id" => array('$in' => $order_ids)
        );

        //echo json_encode($orderFilter);exit;

        $orderData = $this->dbo->find("masters","orders",$orderFilter);
        
        if(!empty($orderData))
        {
            $result = [];
            foreach($orderData as $data)
            {
                $filter1 = array("_id" => $data[_id]);
                //print_r($data);exit;
                $set = array(
                    "order.patientinfo.delivery_lat"=>$latitude,
                    "order.patientinfo.delivery_lng" => $longitude,
                    "order.patientinfo.pincode" => $pincode,
                );

                $push = array("flags"=>$reason);
                //echo json_encode($set);exit;
                $result = $this->dbo->update("masters","orders",$filter1,$set,$push,array(),array());
            }

            if($result['nModified']== 1)
            {
                return array("status"=>1,"message"=>"Operation Successfull");
            }
            else
            {
                return array("status"=>0,"message"=>"Operation Failed");
            }
        }
        else
        {
            return array("status"=>0,"message"=> "No data exist for request"); 
        }
    }

    /* public function customerclassification($payload,$ticket)
{
$key = "5625d15f-fa98-16eb-5abe-75a7013a2c85";
$response = array(
"status"=>"0",
"message"=>"Failed",
"data"=>array()
);

$idorder = array();
$result = array();
$mainresult = array();

if($payload->apikey==$key)
{
if( $payload->searchdate==null || $payload->searchduration==null ||
$this->utility->validateDate_Ymd($payload->searchdate) == false )
{
$response["status"]="0";
$response["message"]="Please provide required parameters(searchdate(YYYY-MM-DD), searchduration(no. of months))";
}
else
{
$input_date = isset($payload->searchdate)?$payload->searchdate:"";
$input_duration = isset($payload->searchduration)?$payload->searchduration:"";
$till_date = date('Y-m-d', strtotime('-'.$input_duration.' Months',strtotime($input_date)));
$input_date = date('Y-m-d', strtotime($input_date));

//FILTER ORDER
$orderfilter = array("order.order_status.created_date" => array('$gte' => $till_date, '$lte' => $input_date)
,"OStatus" => 6);

$orderproject = array(
"_id"=>1,
"odid"=>1,
"OStatus"=>1,
"order.patientinfo.mrn"=>1,
"order.patientinfo.service_type"=>1,
"order.patientinfo.tags"=>1,
"order.patientinfo.scheduled_date"=>1,
"order.parentconsid"=>1,
"order.order_status.created_date"=>1
);
$cursor = $this->dbo->find('masters','orders',$orderfilter,$orderproject);
if(!empty($cursor) or $cursor != "")
{
foreach ($cursor as $document)
{
$result[$document['_id']]=$document;
array_push($idorder,$document['_id']);
}
}

//FILTER BILL
$billfilter = array("billing.patientinfo.order_id"=>array('$in'=>$idorder));
$billproject = array(
"billing.patientinfo.order_id"=>1,
"billing.billinginfo.gross_amount"=>1
);
$billcoll=$this->dbo->find('masters','billing_info',$billfilter,$billproject);
$i=0;
foreach ($billcoll as $billcollD)
{
if($result[$billcollD['billing']['patientinfo']['order_id']])
{
$id=$billcollD['billing']['patientinfo']['order_id'];
$mainresult[$i]['mrn']=$result[$id]["order"]["patientinfo"]["mrn"];
$mainresult[$i]['orderId']=$result[$id]["_id"];
$mainresult[$i]['business']=$result[$id]["order"]["patientinfo"]["service_type"];
$mainresult[$i]['amount']=$billcollD["billing"]["billinginfo"]["gross_amount"];
$mainresult[$i]['status']=$result[$id]["OStatus"];
$mainresult[$i]['date']=$result[$id]["order"]["order_status"]["created_date"];
$mainresult[$i]['tags']=$result[$id]["order"]["patientinfo"]["tags"];
$mainresult[$i]['isparent']=0;
if(isset($result[$id]["order"]["patientinfo"]["tags"]) && (int)$result[$id]["order"]["patientinfo"]["tags"]==0)
{
$mainresult[$i]['isparent']=1;
}
$i=$i+1;
}
}
$response["status"]="1";
$response["message"]="success";
$response["count"] = count($mainresult);
$response["data"]=$mainresult;
}
}
return $response;
} */

}
