<?php
require_once '../libraries/Encrypt.php';

class Notification extends Oms
{
    public function __construct()
    {
        parent::__construct();

    }

    public function customerInvoice($payload, $ticket)
    {
        $finance = new finance;
        try {
            $invoice = $finance->invoice($payload->order_id,"");
        } catch (Exception $e) {
            return array("response" => 0, "message" => "Issue in generating Invoice");
        }
        print_r($invoice); exit;
        //print_r($payload);exit;
        $filter = array("_id" => (int) $payload->order_id);
        //echo json_encode($filter);exit;
        $result = $this->dbo->findOne("masters", "orders", $filter, array());
        //echo json_encode($result);exit;

        $mrn = $result["order"]["patientinfo"]["mrn"];
        $email = $payload->email;
        $name = $result["order"]["patientinfo"]["name"];
        $orderid = $result["odid"];
        $oid = $result["_id"];
        $type = $result["order"]["patientinfo"]["service_type"];
        $doctor = $result["order"]["orderitem"][0]["doctor"];
        $itemname = $result["order"]["orderitem"][0]["itemname"];
        $contact = $result["order"]["patientinfo"]["contact"];
        $address = $result["order"]["patientinfo"]["address"];
        $gross_amount = $result["order"]["orderitem"][0]["gross_amount"];
        $discount_amount = $result["order"]["orderitem"][0]["discount_amount"];
        $net_amount = $result["order"]["orderitem"][0]["net_amount"];
        $date = date('Y-m-d');

        //echo json_encode($attachmentContent);

        if ($type == "1") {
            $result = $result->data;
            $email_event = '{"to":"' . $email . '","subject":"Invoice Copy","templateID":"81158","attachments":[{"fileName":"' . $orderid . '.pdf","content":' . $invoice . '}],"paramsJson":{"orderNumber":"' . $orderid . '","customerName":"' . $name . '","chPhoneNo":"33557799","link":"https:\/\/www.callhealth.com\/","date":"' . $date .
                '","orderStatus":"Completed",
            "doctor":"' . $doctor . '",
            "speciality":"' . $itemname . '","serviceName":"E-Consultation",
                "contact":"' . $contact . '",
                "customerAddress":"' . $address . '",
                "orderAmount":"' . $gross_amount . '",
                "discount":"' . $discount_amount . '",
                "netAmount":"' . $net_amount . '",
                "discountAmount":"' . $discount_amount . '",
                "amount":"' . $gross_amount . '"

                }}';
            //json_encode($email_event);
        } else {
            $email_event = '{"to":"' . $email . '","subject":"Invoice Copy","templateID":"81157","attachments":[{"fileName":"' . $orderid . '.pdf","content":' . $invoice . '}],"paramsJson":{"medicalRecordNumber":"' . $mrn . '","customerName":"' . $name . '","chPhoneNo":"33557799","link":"https:\/\/www.callhealth.com\/"}}';
        }
        $url = $this->config->getconfig('SendEmail', "");
        // $url = $this->config->getconfig('smsemail', "SendEmail");
        // echo $url.$email_event;exit;

        $result = $this->utility->my_curl($url, 'POST', $email_event, 'json', null, 10);

        return array("response" => 1, "message" => "Email sent successfully", "gateway_response" => $result);
    }

    public function send_prescription_upload_link($payload, $ticket)
    {
        $payload->order_id;
        $payload->component_id;
        $payload->order_status = 'NA';
        $payload->template_id = 90166; // upload prescription
        $payload->mode = 2; // sms
        $dt = $this->get_notification_event_data($payload, $ticket);
        if ($dt['success']) {
            //save sent time // update count
            $opt['$inc'] = ["order.patientinfo.prescription_link_sent_count" => 1];
            $set['order.patientinfo.prescription_link_sent_dt'] = date('Y-m-d H:i:s');
            $filter = array('order.patientinfo.order_id' => (int) $payload->order_id);
            $update = $this->dbo->update("masters", "orders", $filter, $set, [], array("multi" => true),$opt);
            $dt['message'] = "Prescription upload link has been sent successfully";
        }
        return $dt;
    }

    public function capture_feedback($payload, $ticket)
    {
        $insertData = [
            "order_id" => $payload->order_id,
            "rating" => $payload->rating,
            "name" => $payload->name,
            "email" => $payload->email,
            "feedback" => $payload->feedback,
        ];
        $this->dbo->insert('masters', 'orders_feedbacks', $insertData);
        return array("success" => 1, "code" => "10100", "message" => "Feedback save successfully");
    }

    public function get_notification_event_data($payload, $ticket)
    {

        //return $_SERVER['SERVER_NAME'] == '172.26.7.111';
        $mdm = new Mdm;
        $data = [];
        $order_id = $payload->order_id;
        $order_status = $payload->order_status;
        $component_id = $payload->component_id;
        $template_id = $data['templateId'] = (String) $payload->template_id;
        $mode = $data['mode'] = (String) $payload->mode; //1: email 2:sms
        $email = $sms = 0;

        if (empty($order_id) || !isset($order_status) || empty($component_id) || empty($template_id)) {
            return array("success" => 0, "code" => "10200", "message" => "Invalid Input, Required fields are missing");
        }

        //-------------get order collection based on order id ------------
        $filter = ['_id' => (int) $order_id]; //255293
        $document = $this->dbo->findOne("masters", "orders", $filter, []);
        if (empty($document)) {
            return array("success" => 0, "code" => "10300", "message" => "Invalid Order Id");
        }

        $component_key = array_column($document[order][orderitem], "component_no");
        //print_r($component_key);exit;
        $key = array_search("8", $component_key);
        //print_r($key);exit;

        if ($key == "" || $key == null) {
            $data['deliveryCharges'] = 0.00;
        } else {
            $data['deliveryCharges'] = (float) $document[order][orderitem][$key][net_amount];

        }
        $data['patientEmail'] = $toEmail = $document['order']['patientinfo']['email'];
        $data['patientmobile'] = $toMobile = $document['order']['patientinfo']['contact'];
        $data['mrn'] = $mrn = $document['order']['patientinfo']['mrn'];
        $data['reason'] = $document['order']['order_status']['reason'];

        if (($mode == 1 && (empty($toEmail) || !filter_var($toEmail, FILTER_VALIDATE_EMAIL))) || ($mode == 2 && empty($toMobile))) {
            // get mrn details // latest user info
            $patient_payload = array("mrnIds" => [$mrn], "addressIds" => []);
            $patient_payload = json_encode($patient_payload);

            $sub_url = 'GcmJava/services/gcm/oms/getbulkdetails';
            $url = $this->config->getConfig("cpservicepath", $sub_url); //URL to hit

            $startTime = microtime(true);
            $buffer = $this->utility->my_curl($url, 'POST', $patient_payload, 'json', null, 10);
            $this->log->logThirdPartyCall("GCM", $url, $startTime, json_decode($patient_payload), $buffer);

            $toMobile = $buffer['allCustDetails'][$mrn]['mobile'];
            $username = $buffer['allCustDetails'][$mrn]['firstName'] . ' ' . $buffer['allCustDetails'][$mrn]['lastName'];
            $toEmail = $buffer['allCustDetails'][$mrn]['email'];
        }
        //$toMobile = '8275289662'; // remove in live env
        //$toEmail = 'hemant.hingave@callhealth.com'; // remove in live env

        if ($mode == 1 && (empty($toEmail) || !filter_var($toEmail, FILTER_VALIDATE_EMAIL))) {
            return array("success" => 0, "code" => "11200", "message" => "No email is associate with MRN:" . $mrn . " or Email is invalid");
        }
        if ($mode == 2 && empty($toMobile)) {
            return array("success" => 0, "code" => "11300", "message" => "No mobile number is associate with MRN:" . $mrn);
        }

        $m = $this->check_email_sms_sending_eligibility($document['creation_type'], $document['order']['patientinfo']['corporateid'], $document['order']['patientinfo']['application_no'], $document['WOStatus']);

        if (!in_array($component_id, $document['component_order'])) {
            return array("success" => 0, "code" => "10400", "message" => "Invalid Component Id");
        }

        $engagement_level = $document['mode_of_service'];
        $data['businessId'] = $business_id = intval($document['order']['patientinfo']['service_type']);
        $data['walletBalance'] = $data['rescheduleCharges'] = $data['cancellationCharges'] = "0.00";

        //order.patientinfo.service_type
        if ($order_status == 7) {
            //$document['workorderinfo'] =
            $data['OldScheduledDate'] = date('Y-m-d H:i:s', ($document['workorderinfo'][sizeof($document['workorderinfo']) - 2]['scheduled_date']->sec) - 19800);
            $filterREs = ['type' => 'PENALTY', 'order_id' => $order_id, 'action' => 3];
            $penalties = $this->dbo->find("masters", "orders_refund_penalties", $filterREs, [], ['order_id' => -1]);
            if (!empty($penalties)) {
                $penalty = $penalties[0];
                $document['workorderinfo'];
                $newWO = end($document['workorderinfo']);
                $timeDiff = abs($penalty['created_on']->sec - $newWO['created_date']->sec);
                if ($timeDiff < 90) { // within 60 sec
                    $data['rescheduleCharges'] = $penalty['amount'];
                }
            }
        }
        if ($order_status == 8) {
            $filterREs = ['type' => 'PENALTY', 'order_id' => $order_id, 'action' => 1];
            $penalties = $this->dbo->find("masters", "orders_refund_penalties", $filterREs, [], ['order_id' => -1]);
            if (!empty($penalties)) {
                $penalty = $penalties[0];
                $data['cancellationCharges'] = $penalty['amount'];
            }
        }
        //return $data;
        $data['order_id'] = $order_id;
        $data['status'] = $order_status;
        //echo "1";exit;
        //print_r($mrn); exit;//rescheduleCharges cancellationCharges

        $data['ServiceName'] = $this->utility->getbusinessDef($business_id, $engagement_level);
        $data['orderNumber'] = $document['odid'];
        $data['date'] = date('d-m-Y', strtotime($document['order']['patientinfo']['scheduled_date']) - 19800);
        $data['scheduledDate'] = date('d-m-Y', strtotime($document['order']['patientinfo']['scheduled_date']) - 19800);
        //return $document['order']['patientinfo']['scheduled_date'];

        $data['firstName'] = $document['order']['patientinfo']['name'];
        $f = explode(' ', $data['firstName']);
        $data['lastName'] = '';
        if (count($f) > 1) {
            $fgh = array_pop($f);
            $data['lastName'] = empty($fgh) ? '' : $fgh;
            $data['firstName'] = implode(' ', $f);
        }
        $data['startTime'] = date("h:i A", strtotime($document['order']['patientinfo']['scheduled_date']) - 19800);
        //$data['startTime'] = date("h:i A", strtotime($data['scheduledDate'] . ' ' . $document['order']['patientinfo']['start_time']));

        $data['endTime'] = date("h:i A", strtotime($data['scheduledDate'] . ' ' . $document['order']['patientinfo']['end_time']));
        //$data['reasonCancel'] = $document['order']['patientinfo']['reason'];

        $data['grossAmount'] = floatval($document['payment_info']['gross_amount']);
        $data['discountAmount'] = floatval($document['payment_info']['discount_amount']);
        $data['netAmount'] = floatval($document['payment_info']['net_amount']);
        $data['couponAmount'] = floatval($document['payment_info']['coupon_amount']);
        $data['walletAmountUsed'] = floatval($document['payment_info']['wallet_amount']);

        $data['voucherAmount'] = floatval($document['payment_info']['voucher_amount']);
        $data['voucherCode'] = floatval($document['payment_info']['voucher_code']);
        $data['payableAmount'] = floatval($document['payment_info']['payment_amount']);
        if ($document['payment_info']['payment_code'] == 0) {
            $data['payableAmount'] = floatval($document['payment_info']['payable_amount']);
        }
        $data['payable_amount'] = floatval($document['payment_info']['payable_amount']);
        $data['paidAmount'] = floatval($document['payment_info']['payment_amount']);

        $data['paymentService'] = $document['payment_info']['payment_service'];

        //for delivery charges

        //getting correct component from providerinfo
        /*$component_key = array_column($document[order][provider_info],"component_no");

        //getting correct item in provider_info
        $key = array_search(8,$component_key);//*/

        //  $data['deliveryCharges'] = 0.00; // to do

        // E-con
        $data['Speciality'] = $document['order']['orderitem'][0]['itemname'];
        $data['conferenceType'] = ($document['order']['patientinfo']['conferenceType'] == 1) ? 'Audio' : 'Video';
        $f = explode(' ', $document['order']['patientinfo']['doctorName']);
        $data['DoctorLastname'] = $data['DoctorFirstname'] = $data['Title'] = '';
        if (count($f) > 1) {
            $fgh = array_pop($f);
            $data['DoctorLastname'] = empty($fgh) ? '' : $fgh;
            $fgh = array_pop($f);
            $data['DoctorFirstname'] = empty($fgh) ? '' : $fgh;
            $data['Title'] = implode(' ', $f);
        }
        // Nursing
        $data['CarePlanStartDate'] = $data['pacakageStartDate'] = date("d-m-Y h:i A", strtotime($data['scheduledDate'] . ' ' . $document['order']['patientinfo']['start_time']) - 19800);
        $data['CarePlanEndDate'] = $data['pacakageEndDate'] = date("d-m-Y h:i A", strtotime($data['scheduledDate'] . ' ' . $document['order']['patientinfo']['end_time']) - 19800);
        $data['duration'] = $document['order']['patientinfo']['duration']; // package duration

        $data['patientAddress'] = $data['deliveryAddress'] = $document['order']['patientinfo']['address'] . ' ' . $document['order']['patientinfo']['landmark'];
        $provider_info = $document['order']['provider_info'];

        foreach ($provider_info as $item) {

            if ($item['component_no'] == $component_id) {

                $data['officerName'] = $item['officer_name'];
                $data['officerContactNumber'] = isset($item['officer_contact_number']) ? $item['officer_contact_number'] : $item['contact_number'];

            }
        }

        if ($data['businessId'] == "4" || $data['businessId'] == "3") {
            $component_id = "7";
        }

        foreach ($provider_info as $item) {
            if ($item['component_no'] == $component_id) {
                $data['Centername'] = $item['associate_name'];
                $data['centerAddress'] = $data['labAddress'] = $data['clinicAddress'] = $item['associate_address'];
            }
        }

        $itemsHtml = "";
        $itemsHtmlOderDid = '
        <td style="border: 1pt solid rgb(204, 204, 204); padding: 3.75pt;">
            <p align="center" style="text-align: center;margin: 0in; margin-bottom: .0001pt;">
                <b>' . $oid . '</b>
            </p>
        </td>';
        $styleTd = 'border-top-width: 1pt; border-right-width: 1pt; border-bottom-width: 1pt; border-style: solid solid solid none; border-top-color: rgb(204, 204, 204); border-right-color: rgb(204, 204, 204); border-bottom-color: rgb(204, 204, 204); padding: 3.75pt;';
        $styleP = 'text-align: center;margin: 0in; margin-bottom: .0001pt;';
        foreach ($document["order"]["orderitem"] as $li) {
            if ($li['item_status'] == "8") {
                continue;
            }
            $itemname = empty($li["item_name"]) ? $li["itemname"] : $li["item_name"];
            $data['lineitems'][] = array(
                "itemName" => $itemname,
                "quantity" => empty($li["quantity"]) ? 1 : $li["quantity"],
                "grossAmount" => floatval($li["gross_amount"]),
                "discount" => floatval($li["discount_amount"]),
                "netAmount" => floatval($li["net_amount"]),
            );
            $data['itemNames'][] = $itemname;
            $itemsHtml .= '
                <tr>' . $itemsHtmlOderDid . '
                    <td style="' . $styleTd . '">
                        <p align="center" style="' . $styleP . '"><b>' . $itemname . '</b></p>
                    </td>
                    <td style="' . $styleTd . '">
                        <p align="center" style="' . $styleP . '"><b>' . $li["gross_amount"] . '</b></p>
                    </td>
                    <td style="' . $styleTd . '">
                        <p align="center" style="' . $styleP . '"><b>' . $li["discount_amount"] . '</b></p>
                    </td>
                    <td style="' . $styleTd . '">
                        <p align="center" style="' . $styleP . '"><b>' . $li["net_amount"] . '</b></p>
                    </td>
                </tr>';
        }

        $data['itemsHtml'] = str_replace(array("\r\n", "\r", "\n", "  "), "", $itemsHtml);

        $data['cancellationReason'] = $document['order']['order_status']['reason'];

        $data['reportDeliveryDate'] = date("d-m-Y", strtotime($document['order']['patientinfo']['final_delivery_date']) - 19800);
        $data['reportDeliveryTime'] = date("h:i A", strtotime($document['order']['patientinfo']['final_delivery_date']) - 19800);

        if (empty($document['order']['patientinfo']['final_delivery_date'])) {
            if (empty($document['order']['patientinfo']['expected_delivery_date'])) {
                $data['reportDeliveryDate'] = '-';
                $data['reportDeliveryTime'] = '-';
            } else {
                $data['reportDeliveryDate'] = date("d-m-Y", strtotime($document['order']['patientinfo']['expected_delivery_date']) - 19800);
                $data['reportDeliveryTime'] = date("h:i A", strtotime($document['order']['patientinfo']['expected_delivery_date']) - 19800);
            }
        }

        if (in_array($business_id, [2, 3, 4]) && $order_status == 6) {
            $filter12 = ['_id' => $order_id];
            $logDoc = $this->dbo->findOne("masters", "orderlog", $filter12, []);
            $itemKey = array_search(5, array_column($logDoc['order_log'], 'order_status'));
            $created_date = $logDoc['order_log'][$itemKey]['created_date'];
            $data['reportDeliveryDate'] = date("d-m-Y", strtotime($created_date));
            $data['reportDeliveryTime'] = date("h:i A", strtotime($created_date));
        }

        //return $data;
        $rs = [];
        if ($mode == 1) {
            $rs = $this->compose_emails_params($data);
        }
        if ($mode == 2) {
            $rs = $this->compose_sms_params($data);
        }
        $rs = array_map(function ($item) {
            if (empty($item)) {
                return "";
            } else {
                return (String) $item;
            }

        }, $rs);

        unset($rs['status']);
        //return $rs;
        $rs['order_id'] = (String) $order_id;
        if ($mode == 1) {
            $postArray = [
                "to" => $toEmail,
                //"from" => "response@callhealth.co.in",
                //"replyTo" => "response@callhealth.co.in",
                "subject" => "",
                "templateID" => $template_id,
                "paramsJson" => $rs,
            ];
            $postArrayJson = json_encode($postArray);
            //echo $postArrayJson;exit;
            $startTime = microtime(true);
            //$url = 'http://cpuat.callhealth.com:8080/SmsEmailGateway/services/domain/SendEmail';
            $url = $this->config->getConfig("SendEmail", "");
            $buffer = $this->utility->my_curl($url, 'POST', $postArrayJson, 'json', null, 10);
            $this->log->logThirdPartyCall("EMAIL_SMS", $url, $startTime, $postArray, $buffer);
        }

        if ($mode == 2) {
            $postArray = [
                "mobileNumber" => $toMobile,
                "templateID" => $template_id,
                "paramsJson" => $rs,
            ];
            $postArrayJson = json_encode($postArray);
            //echo $postArrayJson;exit;
            $startTime = microtime(true);
            //$url = 'http://cpuat.callhealth.com:8090/domain/SendSms';
            $url = $this->config->getConfig("SendSms", "");
            $buffer = $this->utility->my_curl($url, 'POST', $postArrayJson, 'json', null, 10);
            $this->log->logThirdPartyCall("EMAIL_SMS", $url, $startTime, $postArray, $buffer);
        }

        return array("success" => 1, "code" => "10100", "message" => "Data fetch successfully", "data" => $rs);

    }

    /**
     * 10100 : Data fetch successfully
     * 10200 : Invalid Input, Required fields are missing
     * 10300 : Invalid Order Id
     * 10400 : Invalid Component Id
     * 10500 : Unable to fetch wallet balance from MDM
     * 10600 : Invalid template_id
     * 10700 : Unable to generate payment link
     * 10800 : Workorder is missing
     * 10900 : Unable to generate feedback link
     * 11100 : Notification feature is not available for this order.
     * 11200 : No email associate with MRN:" . $mrn ." or Email is invalid
     * 11300 : No mobile number is associate with MRN:
     */

    public function compose_emails_params($data = array())
    {
        //echo "11111";exit;
        $mdm = new Mdm;
        $templateId = (String) $data['templateId'];
        $businessId = $data['businessId'];
        $promotional_content = "";

        $params = array(
            "status" => 1,
            "walletBalance" => "0.00",
            "FirstName" => $data['firstName'],
            "LastName" => $data['lastName'],
            "Businessname" => $data['ServiceName'],
            "OrderNumber" => $data['orderNumber'],
            "Amount" => number_format(round($data['netAmount'], 2), 2, ".", ","),
            "amount" => number_format(round($data['netAmount'], 2), 2, ".", ","),
            "MRP" => number_format(round($data['grossAmount'], 2), 2, ".", ","),
            "priceDiscount" => number_format(round($data['discountAmount'], 2), 2, ".", ","),
            "walletUsed" => number_format(round($data['walletAmountUsed'], 2), 2, ".", ","),
            "couponDiscount" => number_format(round($data['couponAmount'], 2), 2, ".", ","),
            "price" => number_format(round($data['payableAmount'], 2), 2, ".", ","),
            "AmountPaid" => number_format(round($data['paidAmount'], 2), 2, ".", ","),
            "Amountpaid" => number_format(round($data['paidAmount'], 2), 2, ".", ","),
            "amountpaid" => number_format(round($data['paidAmount'], 2), 2, ".", ","),
            "payableAmount" => number_format(round($data['payable_amount'], 2), 2, ".", ","),
            "savedPrice" => number_format(round($data['discountAmount'] + $data['walletAmountUsed'], 2), 2, ".", ","),
            "officername" => $data['officerName'],
            "officerName" => $data['officerName'],
            "officerContactNumber" => $data['officerContactNumber'],
            "MRN" => $data['mrn'],
            "ServiceName" => $data['ServiceName'], //implode(',', $data['itemNames']),
            "Date" => $data['scheduledDate'],
            "TimeRange" => $data['startTime'], //. ' To ' . $data['endTime'], // time range
            "Deliverycharges" => number_format(round($data['deliveryCharges'], 2), 2, ".", ","),
            "Reason" => $data['reason'],
            "Centeraddress" => $data['Centername'] . ' ' . $data['centerAddress'],
            "Clinicaddress" => $data['Centername'] . ' ' . $data['centerAddress'],
            "CenterAddress" => $data['Centername'] . ' ' . $data['centerAddress'],
            "Centername" => $data['Centername'],
            "rescheduledDate" => $data['scheduledDate'],
            "rescheduledTimeRange" => $data['startTime'] . ' To ' . $data['endTime'],

            "DeliveredDate" => $data['reportDeliveryDate'],
            "DeliveredTime" => $data['reportDeliveryTime'],

            // Econ
            "Speciality" => $data['Speciality'],
            "Title" => $data['Title'],
            "DoctorFirstname" => $data['DoctorFirstname'], //E-Wellness also
            "DoctorLastname" => $data['DoctorLastname'], //E-Wellness also
            "ConsultationMode" => $data['conferenceType'], //Audio/Video //E-Wellness also

            // Nursing
            "CarePlanStartDate" => $data['CarePlanStartDate'],
            "CarePlanEndDate" => $data['CarePlanEndDate'],
            "StartDate" => $data['pacakageStartDate'],
            "EndDate" => $data['pacakageEndDate'],
            "packageExpiryDate" => $data['pacakageEndDate'],
            "Duration" => $data['duration'],
            "PackageName" => implode(',', $data['itemNames']),

            //E-Wellness
            "WellnessPlanStartDate" => $data['WellnessPlanStartDate'],
            "WellnessPlanEndDate" => $data['WellnessPlanEndDate'],
            "TitleofNutrition" => $data['TitleofNutrition'],
            "FirstnameofNutrition" => $data['FirstnameofNutrition'],
            "LastnameofNutrition" => $data['LastnameofNutrition'],

            "rescheduleCharges" => $data['rescheduleCharges'],
            "RescheduleCharges" => $data['rescheduleCharges'],
            "cancellationCharges" => $data['cancellationCharges'],
            "CancellationCharges" => $data['cancellationCharges'],
            "pc" => $promotional_content,
        );

        //print_r($params);exit;
        if ($data['status'] == 7) {
            $params["Date"] = date('d-m-Y', strtotime($data['OldScheduledDate']));
            $params["TimeRange"] = date('h:i a', strtotime($data['OldScheduledDate']));
        }
        //workorderinfo rescheduleDate

        $specificParams = $amtRes = $wo = [];
        // get values from dependant component
        // for wallet amount
        if (in_array($templateId, ["91235", "91265", "91267", "91268", "91286", "91287", "91275", "91276", "91277", "91236", "91237", "91266", "91285", "91238", "91239", "91288", "91246", "91259", "91252", "91284", "91295", "91296", "91297", "91298", "91299", "91306", "91307", "91308", "91320", "91321", "91322", "91323", "91324", "91325", "91326", "91327", "91328", "91329", "91330", "91331", "91343", "91344", "91345", "91346", "91356", "91357", "91358", "91359", "91360", "91361", "91362", "91363", "91373", "91374", "91375", "91376", "91386", "91387", "91388", "91389", "91401", "91402", "91403", "91404", "91412", "91413", "91414", "91422", "91423", "91424", "91425", "91426", "91427", "91428"])):
            sleep(5); // add sleep
            $amtRes = $mdm->getWalletAmount((object) array("mrn" => $data[mrn]), "");
            if ($amtRes['status'] == "1" || floatval($amtRes['amount']) > 0) {
                //$params["walletBalance"] = number_format(round($amtRes['amount'], 2), 2, ".", ",");
                $params["walletBalance"] = $amtRes['amount'];
            }
        endif;

        // to get feedback link
        if (in_array($templateId, ["91247", "91267", "91269", "91286", "91276", "91277", "91278", "91289", "91237", "91266", "91285", "91260", "91295", "91298", "91300", "91306", "91309", "91321", "91325", "91332", "91333", "91334", "91343", "91345", "91348", "91349", "91357", "91361", "91364", "91365", "91373", "91375", "91378", "91379", "91387", "91389", "91395", "91403", "91405", "91414", "91415", "91423", "91424", "91425", "91426", "91427", "91429"])):
            $lnkF = $this->get_feedback_link($data['order_id']);
            if (!$lnkF['success']) {
                return $lnkF;
            }
            $params["FeedbackLink"] = $params["Feedbacklink"] = $params["feedbackLink"] = $lnkF['link'];
        endif;

        // to get payment link
        if (in_array($templateId, ["91237", "91266", "91285", "91295", "91306", "91321", "91325", "91329", "91343", "91346", "91357", "91361", "91373", "91376", "91387", "91423", "91425"])):
            $lnk = $this->get_payment_link($data['order_id']);
            if (!$lnk['success']) {
                return $lnk;
            }
            $params["paymentLink"] = $params["link"] = $lnk['link'];
        endif;

        // to get upload link
        if (in_array($templateId, ["90166"])):
            $lnk = $this->get_upload_link($data['order_id']);
            if (!$lnk['success']) {
                return $lnk;
            }
            $params["uploadlink"] = $lnk['link'];
        endif;

        // to get workorder details
        if (in_array($templateId, ["91269", "91278", "91289", "91242", "91243", "91250", "91251", "91273", "91274", "91292", "91293", "91255", "91256", "91263", "91264", "91281", "91282", "91303", "91304", "91312", "91313", "91332", "91333", "91334", "91340", "91341", "91348", "91349", "91355", "91364", "91365", "91370", "91371", "91378", "91379", "91384", "91385", "91392", "91393", "91395", "91398", "91399", "91405", "91409", "91410", "91415", "91419", "91420", "91429", "91432", "91433"])):
            $wo = $this->get_workorder_details($data['order_id'], $data['status']);
            if ($wo['success'] == 0) {
                return $wo;
            }
            //$params["Reason"] = $wo['reason'];
            $wo_completed_date = $wo_completed_time = '';
            if (!empty($wo['completedOn'])) {
                $wo_completed_date = date("d-m-Y", strtotime($wo['completedOn']));
                $wo_completed_time = date("h:i A", strtotime($wo['completedOn']));
            }
            $params["completedDate"] = $params["CompletedDate"] = $wo_completed_date;
            $params["completedTime"] = $params["CompletedTime"] = $params["CompletedTimeRange"] = $wo_completed_time;
        endif;

        return $params;
        // Return all variables

        $templateParams = array(
            /************ Diagnostics ************ */
            //@Home
            "91235" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,Deliverycharges,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice",
            "91236" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,Deliverycharges,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice,AmountPaid",
            "91237" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,Deliverycharges,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice,paymentLink,feedbackLink",
            "91238" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,Deliverycharges,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice,AmountPaid",
            "91239" => "FirstName,LastName,Businessname,MRN,officerName,officerContactNumber,ServiceName,OrderNumber,Date,TimeRange,MRP,Deliverycharges,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice,AmountPaid",
            "91240" => "FirstName,LastName,Businessname,MRN,officerName,officerContactNumber,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91241" => "FirstName,LastName,Businessname,MRN,officerName,officerContactNumber,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91242" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason",
            "91243" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason",
            "91244" => "FirstName,LastName,Businessname,OrderNumber",
            "91245" => "FirstName,LastName,Businessname,OrderNumber",
            "91246" => "FirstName,LastName,Businessname,MRN,officerName,officerContactNumber,ServiceName,OrderNumber,Date,TimeRange,MRP,Deliverycharges,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice",
            "91247" => "FirstName,LastName,Businessname,MRN,officerName,officerContactNumber,ServiceName,OrderNumber,Date,TimeRange,DeliveredDate,DeliveredTime,feedbackLink",
            "91248" => "FirstName,LastName,Businessname,MRN,officerName,officerContactNumber,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91249" => "FirstName,LastName,Businessname,MRN,officerName,officerContactNumber,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91250" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason",
            "91251" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason",
            //@Center
            "91252" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,MRP,Deliverycharges,priceDiscount,walletUsed,walletBalance,couponDiscount,price,savedPrice,Amount",
            "91253" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange,Centeraddress",
            "91254" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange,Centeraddress",
            "91255" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason,Centeraddress",
            "91256" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason,Centeraddress",
            "91257" => "FirstName,LastName,Businessname,OrderNumber",
            "91258" => "FirstName,LastName,Businessname,OrderNumber",
            "91259" => "FirstName,LastName,Businessname,MRN,officerName,officerContactNumber,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,MRP,Deliverycharges,priceDiscount,walletUsed,walletBalance,couponDiscount,price,savedPrice,Amount",
            "91260" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,DeliveredDate,DeliveredTime,Centeraddress,feedbackLink",
            "91261" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange,Centeraddress",
            "91262" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange,Centeraddress",
            "91263" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason,Centeraddress",
            "91264" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason,Centeraddress",

            /************ E-Consultation ************ */
            //@Home
            "91265" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,MRP,walletBalance,AmountPaid,Amount,priceDiscount,walletUsed,couponDiscount,price,savedPrice",
            "91266" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,MRP,walletBalance,AmountPaid,Amount,priceDiscount,walletUsed,couponDiscount,price,savedPrice,paymentLink,feedbackLink",
            "91267" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,MRP,walletBalance,AmountPaid,Amount,priceDiscount,walletUsed,couponDiscount,price,savedPrice,feedbackLink",
            "91268" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,MRP,walletBalance,Amount,priceDiscount,walletUsed,couponDiscount,price,savedPrice",
            "91269" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,Amount,completedDate,completedTime,feedbackLink",
            "91270" => "FirstName,LastName,Businessname,OrderNumber,Speciality,Title,DoctorFirstname,DoctorLastname",
            "91271" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,Amount,rescheduledDate,rescheduledTimeRange",
            "91272" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,Amount,rescheduledDate,rescheduledTimeRange",
            "91273" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,Reason",
            "91274" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,Reason",
            //@Center
            "91275" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,MRP,walletBalance,Amount,priceDiscount,walletUsed,couponDiscount,price,savedPrice,Centeraddress",
            "91276" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,MRP,walletBalance,Amount,payableAmount,priceDiscount,walletUsed,couponDiscount,price,savedPrice,paymentLink,feedbackLink",
            "91277" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,MRP,walletBalance,Amount,AmountPaid,priceDiscount,walletUsed,couponDiscount,price,savedPrice,feedbackLink",
            "91278" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,MRP,Amount,priceDiscount,walletUsed,couponDiscount,price,savedPrice,feedbackLink,Centeraddress",
            "91279" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,Centeraddress,rescheduledDate,rescheduledTimeRange",
            "91280" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,Centeraddress,rescheduledDate,rescheduledTimeRange",
            "91281" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,Centeraddress,Reason",
            "91282" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,Centeraddress,Reason",
            "91283" => "FirstName,LastName,Businessname,OrderNumber,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,Centeraddress",
            //@Platform
            "91284" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,ConsultationMode,MRP,Amount,AmountPaid,priceDiscount,walletUsed,couponDiscount,price,savedPrice",
            "91285" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,ConsultationMode,MRP,Amount,priceDiscount,walletUsed,couponDiscount,price,savedPrice,feedbackLink",
            "91286" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,ConsultationMode,MRP,Amount,AmountPaid,priceDiscount,walletUsed,couponDiscount,price,savedPrice,feedbackLink",
            "91287" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,ConsultationMode,MRP,Amount,priceDiscount,walletUsed,couponDiscount,price,savedPrice",
            "91288" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,ConsultationMode,MRP,Amount,priceDiscount,walletUsed,couponDiscount,price,savedPrice",
            "91289" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,completedDate,completedTime",
            "91290" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,rescheduledDate,rescheduledTimeRange",
            "91291" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,rescheduledDate,rescheduledTimeRange",
            "91292" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,Reason",
            "91293" => "FirstName,LastName,Businessname,OrderNumber,MRN,ServiceName,Date,TimeRange,Speciality,Title,DoctorFirstname,DoctorLastname,Reason",
            "91294" => "FirstName,LastName,Businessname,OrderNumber,Speciality,Title,DoctorFirstname,DoctorLastname",

            /************Drugs************ */
            //@Home
            "91295" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount,paymentLink,feedbackLink",
            "91296" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount",
            "91297" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid",
            "91298" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid,feedbackLink",
            "91299" => "FirstName,LastName,Businessname,MRN,officerName,officerContactNumber,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount",
            "91300" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,DeliveredDate,DeliveredTime,feedbackLink",
            "91301" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91302" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91303" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason",
            "91304" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason",
            "91305" => "FirstName,LastName",
            //@Center
            "91306" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount,paymentLink,feedbackLink",
            "91307" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid",
            "91308" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid",
            "91309" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,DeliveredDate,DeliveredTime,feedbackLink",
            "91310" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,rescheduledDate,rescheduledTimeRange",
            "91311" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,rescheduledDate,rescheduledTimeRange",
            "91312" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,Reason",
            "91313" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,Reason",
            "91314" => "FirstName,LastName",

            /************Nursing************ */
            //@Home
            "91320" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid",
            "91321" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount,paymentLink,feedbackLink",
            "91322" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,Deliverycharges,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice,AmountPaid",
            "91323" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,Deliverycharges,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice,AmountPaid",
            "91324" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount",
            "91325" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount,paymentLink,feedbackLink",
            "91326" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid",
            "91327" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid",
            "91328" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,CarePlanStartDate,CarePlanEndDate,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount",
            "91329" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,CarePlanStartDate,CarePlanEndDate,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount,paymentLink",
            "91330" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,CarePlanStartDate,CarePlanEndDate,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid",
            "91331" => "FirstName,LastName,Businessname,MRN,officerName,officerContactNumber,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,walletUsed,walletBalance,couponDiscount,price,savedPrice,Amount",
            "91332" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,CompletedDate,CompletedTime,feedbackLink",
            "91333" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,Date,CompletedDate,CompletedTime,feedbackLink",
            "91334" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,StartDate,EndDate,CompletedDate,CompletedTime,feedbackLink",
            "91335" => "FirstName,LastName,Businessname,OrderNumber",
            "91336" => "FirstName,LastName,Businessname,OrderNumber",
            "91337" => "FirstName,LastName,Businessname,OrderNumber",
            "91338" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91339" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91340" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason",
            "91341" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason",
            "91342" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,StartDate,EndDate,packageExpiryDate,Duration",
            //@Center
            "91343" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount,paymentLink,feedbackLink",
            "91344" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid",
            "91345" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid,feedbackLink",
            "91346" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,CarePlanStartDate,CarePlanEndDate,Centeraddress,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount,paymentLink",
            "91347" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,CarePlanStartDate,CarePlanEndDate,Centeraddress,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid",
            "91348" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,Date,TimeRange,CompletedDate,CompletedTime,Centeraddress,feedbackLink",
            "91349" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,StartDate,EndDate,CompletedDate,CompletedTime,Centeraddress,feedbackLink",
            "91350" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber",
            "91351" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber",
            "91352" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91353" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange,Clinicaddress",
            "91354" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange,Clinicaddress",
            "91355" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason,Clinicaddress",

            /************ Physio *************/
            //@Home
            "91356" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount",
            "91357" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount,paymentLink,feedbackLink",
            "91358" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid",
            "91359" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid",
            "91360" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,CarePlanStartDate,CarePlanEndDate,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount",
            "91360" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,CarePlanStartDate,CarePlanEndDate,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount",
            "91361" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,CarePlanStartDate,CarePlanEndDate,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount,paymentLink",
            "91362" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,CarePlanStartDate,CarePlanEndDate,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid",
            "91363" => "FirstName,LastName,Businessname,MRN,officerName,officerContactNumber,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,walletUsed,walletBalance,couponDiscount,price,savedPrice,Amount",
            "91364" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,CompletedDate,CompletedTime,feedbackLink",
            "91365" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,StartDate,EndDate,CompletedDate,CompletedTime,feedbackLink",
            "91366" => "FirstName,LastName,Businessname,OrderNumber",
            "91367" => "FirstName,LastName,Businessname,OrderNumber",
            "91368" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91369" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91370" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason",
            "91371" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason",
            "91372" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,StartDate,EndDate,packageExpiryDate,Duration",
            //@Center
            "91373" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount,paymentLink,feedbackLink",
            "91374" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid",
            "91375" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centeraddress,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid,feedbackLink",
            "91376" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,CarePlanStartDate,CarePlanEndDate,Centeraddress,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount,paymentLink",
            "91377" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,CarePlanStartDate,CarePlanEndDate,Centeraddress,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,AmountPaid",
            "91378" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,Date,TimeRange,CompletedDate,CompletedTime,Centeraddress,feedbackLink",
            "91379" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,PackageName,StartDate,EndDate,CompletedDate,CompletedTime,Centeraddress,feedbackLink",
            "91380" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber",
            "91381" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber",
            "91382" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange,Clinicaddress",
            "91383" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange,Clinicaddress",
            "91384" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason,Clinicaddress",
            "91385" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason,Clinicaddress",
            /************ Imaging *************/
            //@center
            "91386" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centername,Centeraddress,MRP,Deliverycharges,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,amount",
            "91387" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centername,Centeraddress,MRP,Deliverycharges,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,amount,feedbackLink,paymentLink",
            "91388" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centername,Centeraddress,MRP,Deliverycharges,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amountpaid",
            "91389" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centername,Centeraddress,MRP,Deliverycharges,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amountpaid,feedbackLink",
            "91390" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centername,Centeraddress,rescheduledDate,rescheduledTimeRange",
            "91391" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centername,Centeraddress,rescheduledDate,rescheduledTimeRange",
            "91392" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centername,Reason,Centeraddress",
            "91393" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centername,Reason,Centeraddress",
            "91394" => "FirstName,LastName,Businessname,MRN,Centername,officerName,officerContactNumber,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,walletUsed,walletBalance,couponDiscount,price,savedPrice,Amount",
            "91395" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centername,Centeraddress,feedbackLink",
            "91396" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centername,Centeraddress,rescheduledDate,rescheduledTimeRange",
            "91397" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centername,Centeraddress,rescheduledDate,rescheduledTimeRange",
            "91398" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centername,Reason,Centeraddress",
            "91399" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Centername,Reason,Centeraddress",

            /************ E-Wellness *************/
            //@Home
            "91400" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,amount,PackageName,WellnessPlanStartDate,WellnessPlanEndDate,TitleofNutrition,FirstnameofNutrition,LastnameofNutrition",
            "91401" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,amount,PackageName,WellnessPlanStartDate,WellnessPlanEndDate,TitleofNutrition,FirstnameofNutrition,LastnameofNutrition",
            "91402" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amountpaid,PackageName,WellnessPlanStartDate,WellnessPlanEndDate",
            "91403" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amountpaid,PackageName,WellnessPlanStartDate,WellnessPlanEndDate,feedbackLink",
            "91404" => "FirstName,LastName,Businessname,MRN,officerName,officerContactNumber,ServiceName,OrderNumber,Date,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,Amount",
            "91405" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,CompletedDate,CompletedTime,feedbackLink",
            "91407" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91408" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91409" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason",
            "91410" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason",
            //@center
            "91412" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,Centeraddress,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,amount,PackageName,WellnessPlanStartDate,WellnessPlanEndDate,TitleofNutrition,FirstnameofNutrition,LastnameofNutrition",
            "91413" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,Centeraddress,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,amount,PackageName,WellnessPlanStartDate,WellnessPlanEndDate,AmountPaid",
            "91414" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,Centeraddress,TimeRange,MRP,priceDiscount,couponDiscount,walletUsed,walletBalance,price,savedPrice,amount,PackageName,WellnessPlanStartDate,WellnessPlanEndDate,AmountPaid,feedbackLink",
            "91415" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,Centeraddress,TimeRange,completedDate,completedTime,feedbackLink",
            "91417" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,Centeraddress,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91418" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,Centeraddress,TimeRange,rescheduledDate,rescheduledTimeRange",
            "91419" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,Centeraddress,TimeRange,Reason",
            "91420" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,Centeraddress,TimeRange,Reason",
            //@platform
            "91422" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Speciality,DoctorFirstname,DoctorLastname,ConsultationMode,MRP,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice,AmountPaid",
            "91423" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Speciality,DoctorFirstname,DoctorLastname,ConsultationMode,MRP,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice,paymentLink,feedbackLink",
            "91424" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Speciality,DoctorFirstname,DoctorLastname,ConsultationMode,MRP,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice,AmountPaid,feedbackLink",
            "91425" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Speciality,DoctorFirstname,DoctorLastname,ConsultationMode,MRP,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice,paymentLink,feedbackLink,PackageName,WellnessPlanStartDate,WellnessPlanEndDate",
            "91426" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Speciality,DoctorFirstname,DoctorLastname,ConsultationMode,MRP,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice,AmountPaid,feedbackLink,PackageName,WellnessPlanStartDate,WellnessPlanEndDate",
            "91427" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Speciality,DoctorFirstname,DoctorLastname,ConsultationMode,MRP,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice,AmountPaid,feedbackLink,PackageName,WellnessPlanStartDate,WellnessPlanEndDate",
            "91428" => "FirstName,LastName,Businessname,MRN,officerName,officerContactNumber,ServiceName,OrderNumber,Date,TimeRange,Speciality,DoctorFirstname,DoctorLastname,ConsultationMode,MRP,priceDiscount,walletUsed,walletBalance,couponDiscount,price,Amount,savedPrice,AmountPaid,PackageName,WellnessPlanStartDate,WellnessPlanEndDate",
            "91429" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,DoctorFirstname,DoctorLastname,Amount,completedDate,completedTime,feedbackLink",
            "91430" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,rescheduledDate,rescheduledTimeRange",
            "91431" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,rescheduledDate,rescheduledTimeRange",
            "91432" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason",
            "91433" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,Date,TimeRange,Reason",
            "91434" => "FirstName,LastName,Businessname,MRN,ServiceName,OrderNumber,DoctorFirstname,DoctorLastname",
            "91435" => "FirstName,LastName,Businessname,MRN,PackageName,Duration,packageExpiryDate",
        );

        $reqiredParams = $templateParams[$templateId];
        if (!isset($reqiredParams)) {
            return array("status" => 0, "message" => "Invalid template_id ");
        }
        $reqiredParamsArr = explode(',', $reqiredParams);
        foreach ($reqiredParamsArr as $item) {
            $finalArr[$item] = $params[$item];
        }
        return $finalArr;
    }

    public function compose_sms_params($data = array())
    {
        //echo "1111";exit;
        //print_r($data[mrn]);exit;
        $mdm = new Mdm;
        $CHnumber = "(+91) 9133557799";
        $templateId = (String) $data['templateId'];
        $businessId = $data['businessId'];
        $reportDeliveryDate = $data['reportDeliveryDate'] . ' ' . $data['reportDeliveryTime'];
        $hrs = floor(abs(strtotime($reportDeliveryDate) - time()) / 3600);
        $mins = floor((strtotime($reportDeliveryDate) / 60) % 60);
        $appointmentStartByMinute = floor((strtotime($data['scheduledDate'] . ' ' . $data['startTime']) / 60) % 60);
        //minutes

        $promotional_content = "";
        $params = array(
            "status" => 1,
            "walletBalance" => "0.00",
            "ordernumber" => $data['orderNumber'],
            "OrderNumber" => $data['orderNumber'],
            "MRN" => $data['mrn'],
            "order" => $data['orderNumber'],
            "business" => $data['ServiceName'],
            "ServiceName" => $data['ServiceName'],
            "date" => $data['scheduledDate'],
            "Time" => $data['startTime'],
            "time" => $data['startTime'],
            "HomeAddress" => $data['patientAddress'],
            "officerName" => $data['officerName'],
            "Reason" => $data['reason'],
            "officerContactNumber" => $data['officerContactNumber'],
            "amount" => number_format(round($data['payableAmount'], 2), 2, ".", ","),
            "Amount" => number_format(round($data['payableAmount'], 2), 2, ".", ","),
            "payableAmount" => number_format(round($data['payable_amount'], 2), 2, ".", ","),
            "AmountPaid" => number_format(round($data['paidAmount'], 2), 2, ".", ","),
            "Amountpaid" => number_format(round($data['paidAmount'], 2), 2, ".", ","),
            "amountpaid" => number_format(round($data['paidAmount'], 2), 2, ".", ","),
            "hrs" => $hrs,
            "mins" => $mins,
            "CHnumber" => $CHnumber,
            "Chnumber" => $CHnumber,
            "email" => $data['patientEmail'],
            "labAddress" => $data['Centername'] . ' ' . $data['labAddress'],
            //"labAddress" => $data['labAddress'],
            "Labname" => $data['Centername'],
            "centerlocation" => $data['centerAddress'],
            "diagnosticCenterAddress" => $data['centerAddress'],
            "Centerlocation" => $data['centerAddress'],
            "clinicaddress" => $data['centerAddress'],
            "reportDeliveryDate" => $data['reportDeliveryDate'],
            "reportDeliveryTime" => $data['reportDeliveryTime'],
            // econ
            "doctor" => $data['Title'] . ' ' . $data['DoctorFirstname'] . ' ' . $data['DoctorLastname'],
            "speciality" => $data['Speciality'],
            "ConsultationMode" => '--',
            "minutes" => $appointmentStartByMinute,

            "CarePlanEndDate" => $data['CarePlanEndDate'],
            //Title,CustomerFirstname,CustomerLastname
            //"FirstName,LastName",
            "Title" => $data['Title'],
            "FirstName" => $data['firstName'],
            "LastName" => $data['lastName'],
            "CustomerFirstname" => $data['firstName'],
            "CustomerLastname" => $data['lastName'],

            "rescheduleCharges" => $data['rescheduleCharges'],
            "RescheduleCharges" => $data['rescheduleCharges'],
            "cancellationCharges" => $data['cancellationCharges'],
            "CancellationCharges" => $data['cancellationCharges'],
            "pc" => $promotional_content,

        );

        $specificParams = $amtRes = $wo = [];
        // get values from dependant component
        // for wallet amount
        if (in_array($templateId, ["90066", "90086", "90116", "90128", "90141", "90157",
            "90182", "90186", "90207", "90210", "90230", "90249", "90270"])):
            //echo "111111";exit;
            $amtRes = $mdm->getWalletAmount((object) array("mrn" => $data[mrn]), "");
            if ($amtRes['status'] == "1" || floatval($amtRes['amount']) > 0) {
                //$params["walletamount"] = number_format(round($amtRes['amount'], 2), 2, ".", ",");
                $params["walletamount"] = $amtRes['amount'];
            }
        endif;

        // to get feedback link
        if (in_array($templateId, ["90070", "90079", "90097", "90121", "90132", "90146", "90121", "90161", "90173", "90193", "90194", "90195", "90214", "90215", "90216", "90290", "90278"])):
            $lnkF = $this->get_feedback_link($data['order_id']);
            if (!$lnkF['success']) {
                return $lnkF;
            }
            $params["FeedbackLink"] = $params["Feedbacklink"] = $params["feedbackLink"] = $lnkF['link'];
        endif;

        // to get upload link
        if (in_array($templateId, ["90166"])):
            $lnk = $this->get_upload_link($data['order_id'], $data['mrn']);
            if (!$lnk['success']) {
                return $lnk;
            }
            $params["uploadlink"] = $lnk['link'];
        endif;

        // to get payment link
        if (in_array($templateId, ["90067", "90087", "90117", "90129", "90142", "90155", "90169", "90181", "90185", "90189", "90206", "90209", "90212", "90229", "90248", "90251", "90253", "90254", "90269"])):
            $lnk = $this->get_payment_link($data['order_id']);
            if (!$lnk['success']) {
                return $lnk;
            }
            $params["paymentLink"] = $params["link"] = $lnk['link'];
        endif;

        // to get workorder details
        if (in_array($templateId, ["90071"])):
            $wo = $this->get_workorder_details($data['order_id'], $data['status']);
            if ($wo['success'] == 0) {
                return $wo;
            }
            //$params["Reason"] = $wo['reason'];
            $params["completedDate"] = date("d-m-Y", strtotime($wo['completedOn']));
            $params["completedTime"] = date("h:i A", strtotime($wo['completedOn']));
        endif;

        return $params;
        // Return all variables

        //return $params;
        $templateParams = array(
            /************ Diagnostics ************ */
            //@Home Diag
            "90065" => "ordernumber,date,time,HomeAddress,amount",
            "90066" => "business,ordernumber,date,time,amount,walletamount",
            "90067" => "business,ordernumber,amount,paymentLink",
            "90072" => "ordernumber,amount",
            "90068" => "officerName,officerContactNumber",
            "90070" => "hrs,mins,amount,FeedbackLink",
            "90071" => "ServiceName,date,time,Reason,CHnumber",
            "90073" => "business,ordernumber,date,time",
            "90074" => "business,ordernumber,date,time",
            "90075" => "ordernumber",
            "90076" => "ordernumber,email",
            "90077" => "ordernumber,email",
            "90078" => "officerContactNumber,officerName,date,time",
            "90079" => "FeedbackLink",
            "90080" => "ordernumber,date,time",
            "90082" => "ordernumber",
            "90083" => "ordernumber",
            //@Center Diag
            "90084" => "business,date,time",
            "90085" => "ordernumber,business,date,time,amount,labAddress",
            "90086" => "ordernumber,date,time,labAddress,amount,walletamount",
            "90087" => "business,ordernumber,labAddress,amount,paymentLink",
            "90088" => "ordernumber,amount",
            "90089" => "amount,FeedbackLink",
            "90090" => "ordernumber,date,time",
            "90091" => "business,ordernumber,date,time",
            "90092" => "business,ordernumber,date,time",
            "90093" => "order",
            "90094" => "ordernumber",
            "90095" => "ordernumber,email",
            "90096" => "officerName,officerContactNumber,reportDeliveryDate,reportDeliveryTime",
            "90097" => "FeedbackLink",
            "90098" => "ordernumber,date,time",
            "90099" => "date,time",
            "90100" => "officerName",
            "90101" => "officerName",

            /************ E-Consultation ************ */
            //@Home E-Con
            "90116" => "doctor,speciality,date,time,amount,walletamount",
            "90117" => "ordernumber,amount,paymentLink",
            "90118" => "ordernumber",
            "90119" => "ordernumber",
            "90120" => "ordernumber",
            "90121" => "amount,FeedbackLink",
            "90122" => "ordernumber,email",
            "90123" => "MRN,date,time,CHnumber",
            "90124" => "ordernumber,date,time",
            "90125" => "business,ordernumber,date,time",
            "90126" => "business,ordernumber,date,time",
            "90127" => "order",
            //@Center E-Con
            "90128" => "doctor,clinicaddress,date,time,amount,walletamount",
            "90129" => "doctor,clinicaddress,date,time,amount,paymentLink",
            "90130" => "ordernumber",
            "90131" => "clinicaddress",
            "90132" => "amount,FeedbackLink",
            "90133" => "ordernumber,date,time",
            "90134" => "business,ordernumber,date,time",
            "90135" => "business,ordernumber,date,time",
            "90136" => "ordernumber",
            "90137" => "ordernumber,email",
            "90138" => "MRN,date,time,clinicaddress,CHnumber",
            //@Platform E-Con
            "90139" => "ordernumber",
            "90140" => "doctor,speciality,date,time,amount",
            "90141" => "doctor,speciality,date,time,amount,walletamount",
            "90142" => "ordernumber,amount,paymentLink",
            "90143" => "ordernumber",
            "90144" => "officerName,officerContactNumber",
            "90146" => "amount,FeedbackLink",
            "90147" => "ordernumber,date,time",
            "90148" => "business,ordernumber,date,time",
            "90149" => "business,ordernumber,date,time",
            "90150" => "order",
            "90151" => "ordernumber,email",
            "90152" => "MRN,minutes,CHnumber",

            /************ Drug ************ */
            //@Home Drug
            "90153" => "date,time",
            "90155" => "ordernumber,date,time,amount,paymentLink",
            "90156" => "ordernumber,date,time,amount",
            "90157" => "ordernumber,date,time,amount,walletamount",
            "90158" => "amount,order",
            "90159" => "officerName,officerContactNumber",
            "90161" => "ordernumber,amount,FeedbackLink",
            "90162" => "ordernumber,date,time",
            "90163" => "business,ordernumber,date,time",
            "90164" => "business,ordernumber,date,time",
            "90165" => "order",
            "90166" => "MRN,ordernumber,uploadlink",
            "90167" => "CHnumber",
            //@Center DRUGS
            "90168" => "date,time",
            "90169" => "ordernumber,date,time,amount,paymentLink",
            "90170" => "ordernumber,date,time,amount",
            "90171" => "amount,order,Centerlocation",
            "90172" => "ordernumber",
            "90173" => "ordernumber,amount,FeedbackLink",
            "90174" => "ordernumber,date,time",
            "90175" => "ordernumber,business,date,time",
            "90176" => "business,ordernumber,date,time",
            "90177" => "ordernumber",

            //**************Nursing****************//
            //@Home
            "90179" => "CHnumber",
            "90180" => "business,ordernumber,date,time,amount",
            "90181" => "business,ordernumber,amount,paymentLink",
            "90182" => "business,ordernumber,date,time,amount,walletamount,",
            "90183" => "order",
            "90184" => "business,ordernumber,date,time,amount",
            "90185" => "business,ordernumber,amount,paymentLink",
            "90186" => "business,ordernumber,date,time,amount,walletamount",
            "90187" => "ordernumber",
            "90188" => "ordernumber,amount",
            "90189" => "business,ordernumber,paymentLink",
            "90190" => "order",
            "90191" => "officerName,officerContactNumber",
            "90193" => "ordernumber,FeedbackLink",
            "90194" => "ordernumber,FeedbackLink",
            "90195" => "ordernumber,FeedbackLink",
            "90196" => "ordernumber",
            "90197" => "ordernumber",
            "90198" => "ordernumber",
            "90199" => "ordernumber,date,time",
            "90200" => "business,ordernumber,date,time",
            "90201" => "business,ordernumber,date,time",
            "90202" => "order",
            "90203" => "MRN,CHnumber,date,time",
            "90204" => "MRN,completeddate,CHnumber",
            "90205" => "MRN,Title,CustomerFirstname,CustomerLastname,link", //link,cfn,cln

            //@Center
            "90206" => "business,Centerlocation,ordernumber,date,time,amount,paymentLink",
            "90207" => "ordernumber,date,time,Centerlocation,amount,walletamount",
            "90208" => "order,Centerlocation",
            "90209" => "business,Centerlocation,ordernumber,date,time,amount,paymentLink",
            "90210" => "ordernumber,date.time,Centerlocation,amount,walletamount",
            "90211" => "order,Centerlocation",
            "90212" => "Centerlocation,ordernumber,date,time,amount,paymentLink",
            "90213" => "ordernumber,Centerlocation",
            "90214" => "ordernumber,FeedbackLink",
            "90215" => "ordernumber,FeedbackLink",
            "90216" => "ordernumber,FeedbackLink",
            "90217" => "ordernumber",
            "90218" => "OrderNumber",
            "90219" => "OrderNumber",
            "90220" => "ordernumber,date,time",
            "90221" => "business,ordernumber,date,time",
            "90222" => "business,ordernumber,date,time",
            "90223" => "order",
            "90224" => "MRN,Date,Time,Centerlocation,CHnumber",
            "90225" => "MRN,CHnumber,date",
            "90226" => "Title,CustomerFirstname,CustomerLastname",
            //*****************Physio**********************//
            //@Home
            "90227" => "CHnumber",
            "90228" => "business,ordernumber,date,time,amount",
            "90229" => "ordernumber,amount,paymentLink",
            "90230" => "ordernumber,date,time,amount,walletamount",
            "90231" => "order",
            "90232" => "business,ordernumber,amount",
            "90233" => "business,ordernumber,amount,paymentLink",
            "90234" => "order",
            "90235" => "officerName,officerContactNumber",
            "90236" => "ordernumber",
            "90237" => "ordernumber,FeedbackLink",
            "90238" => "ordernumber,FeedbackLink",
            "90239" => "ordernumber,email",
            "90240" => "ordernumber,email",
            "90241" => "ordernumber,date,time",
            "90242" => "business,ordernumber,date,time",
            "90243" => "business,ordernumber,date,time",
            "90244" => "ordernumber",
            "90245" => "date,time,CHnumber",
            "90246" => "MRN,date,CHnumber",
            "90247" => "MRN,date,CHnumber",
            //@Center
            "90248" => "business,Centerlocation,CHnumber,paymentLink",
            "90249" => "ordernumber,date,time,Centerlocation,amount,walletamount",
            "90250" => "order,Centerlocation",
            "90251" => "ordernumber,date,time,Centerlocation,amount,paymentLink",
            "90252" => "ordernumber,Centerlocation",
            "90253" => "ordernumber,FeedbackLink",
            "90254" => "ordernumber,FeedbackLink",
            "90255" => "ordernumber",
            "90256" => "ordernumber,email",
            "90257" => "ordernumber,date,time",
            "90258" => "business,ordernumber,date,time",
            "90259" => "business,ordernumber,date,time",
            "90260" => "ordernumber",
            "90261" => "ordernumber,date,time,Centerlocation,CHnumber",
            "90262" => "MRN,CarePlanEndDate,CHnumber",
            "90263" => "Title,CustomerFirstname,CustomerLastname",
            "90264" => "FirstName,LastName",
        );
        $reqiredParams = $templateParams[$templateId];
        if (!isset($reqiredParams)) {
            return array("status" => 0, "message" => "Invalid template_id ");
        }
        $reqiredParamsArr = explode(',', $reqiredParams);
        foreach ($reqiredParamsArr as $item) {
            $finalArr[$item] = $params[$item];
        }
        return $finalArr;

    }

    public function get_wallet_amount($mrn = null)
    {
        //return array("success" => 1, 'walletBalance' => 9999); // detete this line
        // get wallet amount
        //http://cpuat.callhealth.com:8080/mdm/services/getWalletBalance/256887

        //sleep for 5 seconds
        //sleep(5); // wallet deduction is doing by CP
        $url = $this->config->getconfig('mdmpath', "getWalletBalance/" . $mrn);
        $startTime = microtime(true);
        $dd = $this->utility->my_curl($url);
        var_dump($dd);
        $this->log->logThirdPartyCall("MDM", $url, $startTime, json_decode(['mrn' => $mrn]), $dd);
        $dd = json_decode($dd, true);
        if ($dd->status != 'success') {
            return array("success" => 1, 'walletBalance' => 0, "code" => "10500", "message" => "Unable to fetch wallet balance from MDM"); // Jugad
        } else {
            return array("success" => 1, 'walletBalance' => floatval($dd['object']['Balance']));
        }
    }

    public function get_payment_link($order_id)
    {
        require_once 'Payments.php';
        $payments = new Payments;
        $payload = (Object) [
            "id" => $order_id,
            "mode" => 2,
            "channel" => "CP",
        ];
        //var_dump($payload); die;
        $link = '#';
        $res = $payments->send_payment_link($payload, mt_rand(10000, 99999));
        if ($res['success'] || $res['code'] == '10600') {
            $link = $res['data']['paymentLink'];
        }
        if (!$order_id) {
            return array("success" => 0, "code" => "10700", "message" => "Unable to generate payment link");
        } else {
            return array("success" => 1, 'link' => $link);
        }
    }

    public function get_upload_link($order_id, $mrn)
    {
        $encrypt = new OMSEncrypt();
        if (!$order_id) {
            return array("success" => 0, "code" => "10700", "message" => "Unable to generate payment link");
        } else {
            $t = $encrypt->encode($order_id);
            $link = $this->config->getconfig('serverurl', "uploadprescription/index.php?token=" . $t . '&t=t');
            // http://172.26.7.111/uploadprescription/index.php?orderid=534592
            // update order collection
            $set['order.patientinfo.prescription_upload_link'] = $link;
            $set['order.patientinfo.is_prescription_uploaded'] = 0;
            $filter = array('order.patientinfo.order_id' => (int) $order_id);
            $update = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multi" => true));
            return array("success" => 1, 'link' => $link);
        }
    }

    public function get_feedback_link($order_id)
    {
        $encrypt = new OMSEncrypt();
        if (!$order_id) {
            return array("success" => 0, "code" => "10900", "message" => "Unable to generate Feedback link");
        } else {
            $t = $encrypt->encode($order_id);
            $link = $this->config->getconfig('serverurl', "OMS/feedback?token=" . $t . '&t=t');
            //http://172.26.7.111/hemant/OMS/feedback/?token=d2t6TnlNVE4=
            return array("success" => 1, 'link' => $link);
        }
    }

    public function get_workorder_details($order_id = null, $status)
    {
        $filter = ['orderinfo.order_id' => (int) $order_id];
        $document = $this->dbo->find("masters", "workorders", $filter, [], ['_id' => -1], 2);
        if ($status == 7) {
            $document = $document[1];
        } else {
            $document = $document[0];
        }
        if (empty($document)) {
            return array("success" => 0, "code" => "10800", "message" => "Workorder is missing");
        }
        $reason = $document["orderinfo"]["reason"];
        $completed_time = $document["orderinfo"]["completed_time"];
        return array("success" => 1, "reason" => $reason, "completedOn" => $completed_time);
    }

    public function check_email_sms_sending_eligibility($creation_type, $corporate_id, $application_no, $Ostatus)
    {
        return ["email" => 1, "sms" => 1];
    }

    public function generic_sms($toMobile, $rs, $eventType)
    {
        if ((int) $eventType == 1) {
            $template_id = 80012;
        }

        $postArray = [
            "mobileNumber" => $toMobile,
            "templateID" => $template_id,
            "paramsJson" => $rs,
        ];
        $postArrayJson = json_encode($postArray);
        //echo $postArrayJson;exit;
        $startTime = microtime(true);
        //$url = 'http://cpuat.callhealth.com:8090/domain/SendSms';
        $url = $this->config->getConfig("SendSms", "");
        $buffer = $this->utility->my_curl($url, 'POST', $postArrayJson, 'json', null, 10);
        $this->log->logThirdPartyCall("EMAIL_SMS_SPL", $url, $startTime, $postArray, $buffer);
    }

}
