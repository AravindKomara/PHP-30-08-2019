<?php
//error_reporting(E_ALL);
class LineItemsMulti extends Oms
{
    public $chissPayload = array();
    public function __construct()
    {
        parent::__construct();
        $this->orderinfo = new Orderinfo;
        $this->finance = new Finance;
    }

    public function getname()
    {
        return "lineitems";
    } 

    public function crud($payload, $ticket)
    {
        $actionById = $payload->actionById;
        $actionByName = $payload->actionByName; //items is array
        $order_id = $payload->order_id;
        $quantity = $payload->quantity;
        $action = intval($payload->action); // 4:add // 1:delete // 2:modify // 5:return 
        $source = isset($payload->source) ? $searchreq->source : 'mobile'; // CP, CCO, L2
        $comment = isset($payload->comment) ? $searchreq->comment : '';
        $reason = isset($payload->reason) ? $searchreq->reason : '';

        //-------------Validate required fields ------------
        if (empty($actionById) || empty($actionByName) || empty($order_id) || !isset($action)) {
            return array("status" => 0, "code" => "10200", "message" => "Invalid Input, Required fields are missing");
        }

        $filter = ['_id' => (int) $order_id];
        $mainOrder = $this->dbo->findOne("masters", "orders", $filter, []);
        if (empty($mainOrder)) {
            return array("status" => 0, "code" => "10300", "message" => "Invalid order_id");
        }

        if (!in_array(intval($mainOrder['order']['patientinfo']['service_type']), [2, 3, 4])) {
            return array("status" => 0, "code" => "10400", "message" => "Functionality is not applicable for this order");
        }

        $payload->service_type = $mainOrder['order']['patientinfo']['service_type'];
        $status = $mainOrder['order']['patientinfo']['order_status'];
        $current_w_id = $mainOrder['wid'];
        $current_w_did = $mainOrder['wodid'];
        $facility_id = $mainOrder['order']['patientinfo']['facility_id'];
        $popname = $mainOrder['order']['patientinfo']['popname'];
        $transaction_code = $mainOrder['transaction_code'];
        $mrn = $mainOrder['order']['patientinfo']['mrn'];
        $message = 'Operation done successfully';
        $final_delivery_date = date('Y-m-d H:i:s');
        if ($action == 4) { // add
            $message = 'Item added successfully';
            $logaction = 'Lineitem addition';
            foreach($payload->items as $item){
                $item->service_type = $mainOrder['order']['patientinfo']['service_type'];
                $item->final_delivery_date = $mainOrder['order']['patientinfo']['final_delivery_date'];
                $log_desc .= 'Lineitem ( ' . $item->line_item . ' - ' . $item->itemname . ' ) is added';
                $res = $this->add($item, $ticket, $mainOrder);
                if ($res["status"] == 0) {
                    return $res;
                }
                $itemAdded = 0;
                foreach ($mainOrder["order"]["orderitem"] as $key => $val) {
                    if ($val['item_status'] == 0 && $item->line_item == $val['item_code']) {
                        return array("status" => 0, "code" => "10600", "message" => "Unable to add lineitem. Lineitem is already exist");
                    }
                    //1. if lineitem is cancelled and adding same item again then Update existing lineitem
                    if ($val['item_status'] == 8 && $item->line_item == $val['item_code']) {
                        $mainOrder["order"]["orderitem"][$key] = array_merge($val, $res['orderitem']);
                        $itemAdded = 1;
                    }
                }
                if ($itemAdded == 0) {
                    array_push($mainOrder["order"]["orderitem"], $res['orderitem']);
                }
            }
        }
        //return $mainOrder["order"]["orderitem"];
        if ($action == 1) { // cancel/delete
            $message = 'Item deleted successfully';
            $logaction = 'Line item ( ' . $payload->item->itemid . ' - ' . $payload->item->itemname . ' ) is cancelled';
        }
        if ($action == 2) { // Quantity updation
            $message = 'Item Quantity updated successfully';
            $logaction = 'Item Quantity for Line item ( ' . $payload->item->itemid . ' - ' . $payload->item->itemname . ' ) is updated';
        }

        $LineItems = $reportDeliveryChargesList = $clinicalServices = [];
        //return $mainOrder["order"]["orderitem"];
        foreach ($mainOrder["order"]["orderitem"] as $val) {

            if ($val['item_status'] == 8 && $payload->lineitem == $val['item_code'] && $payload->action == 1) {
                return array("status" => 0, "code" => "10700", "message" => "Unable to delete lineitem. Lineitem is already deleted");
            }

            if ($val['item_status'] == 8 && $payload->lineitem == $val['item_code'] && $payload->action == 2) {
                return array("status" => 0, "code" => "10800", "message" => "Unable to change quantity. Lineitem is already cancelled");
            }

            if ($val['item_status'] == 8) {
                continue; // skip lineitem
            }
            $actionFlag = 'NA';
            if (in_array($val['item_code'], $payload->lineitem) ){
                if ($payload->action == 2) {
                    $val['quantity'] = $quantity;
                }
                $actionFlag = $payload->action;
            }
            $associateCode = $associateBranchId = "";
            foreach ($mainOrder['order']['provider_info'] as $t) { //order.provider_info.component_no
                if ($t['component_no'] == intval($val['component_no'])) {
                    $associateCode = $t['associate_id'];
                    $associateBranchId = $t['associate_branch_id'];
                    break;
                }
            }

            $isPaid = true;
            $payabaleAmount = 0;
            if ($val['payment_code'] == 0 ) {
                $isPaid = false;
                $payabaleAmount = $val['net_amount'] - (floatval($val['voucher_amount']) + floatval($val['wallet_amount']));
            }
            $created_date = explode('|', date('Y|m|d|H|i|s', strtotime($mainOrder["order"]["order_status"]["created_date"])));
            $orderDate = [
                "year" => $created_date[0],
                "month" => $created_date[1],
                "dayOfMonth" => $created_date[2],
                "hourOfDay" => $created_date[3],
                "minute" => $created_date[4],
                "second" => $created_date[5],
            ];

            if ($actionFlag == 4) {
                $li = [
                    "action" => (String) $actionFlag,
                    "sessions" => (intval($val['quantity'])) ? (String) intval($val['quantity']) : "1", //quantity
                    "business" => $mainOrder["order"]["patientinfo"]["service_type"],
                    "code" => $val['item_code'],
                    "zipcode" => (String) $mainOrder["order"]["patientinfo"]["pincode"],
                    "engage_at" => (String) $mainOrder["mode_of_service"],
                    "mrn" => $mainOrder["order"]["patientinfo"]["mrn"],
                    "orderDate" => $orderDate,
                    "source" => $payload->source,
                    "associateCode" => (String) $associateCode,
                    "associateBranchId" => (String) $associateBranchId,
                ];
            } else {
                $li = [
                    "action" => (String) $actionFlag,
                    "sessions" => (intval($val['quantity'])) ? (String) intval($val['quantity']) : "1", //quantity
                    "cartDiscountApplied" => ($val['cartDiscountApplied']) ? true : false,
                    "couponValue" => 0, //?
                    "apportionedCouponAmount" => (String) floatval($val['coupon_amount']),
                    "apportionedWalletAmount" => (String) floatval($val['wallet_amount']),
                    "cartDiscountApportionedAmount" => (floatval($val['cartDiscountApportionedAmount']) > 0) ? (String) floatval($val['cartDiscountApportionedAmount']) : "0",
                    "discountApplied" => ($val['discountApplied']) ? true : false,
                    "cartCouponApplied" => ($val['cartCouponApplied']) ? true : false,
                    "orderNumber" => (String) $mainOrder["_id"],
                    "consultationMode" => (String) 1, //
                    "penalty_amount" => (String) 0, //
                    "isFastingRequired" => false, //? orderDiscountApplied
                    "orderApportionedDiscountAmount" => (floatval($val['orderApportionedDiscountAmount']) > 0) ? (String) floatval($val['orderApportionedDiscountAmount']) : "0",
                    "orderDiscountApplied" => ($val['orderDiscountApplied']) ? true : false,
                    "business" => $mainOrder["order"]["patientinfo"]["service_type"],
                   // "businessId" => $mainOrder["order"]["patientinfo"]["service_type"],
                  //  "businessID" => $mainOrder["order"]["patientinfo"]["service_type"],
                    "mrn" => $mainOrder["order"]["patientinfo"]["mrn"],
                    "code" => $val['item_code'],
                    "source" => $payload->source,
                    "orderDate" => $orderDate,
                    "unitPrice" => (String) floatval($val['MRP']),
                    "grossAmount" => (String) floatval($val['gross_amount']),
                    "discountAmount" => (String) floatval($val['lineItemDiscountAmount']),
                    "netAmount" => (String) (floatval($val['gross_amount']) - floatval($val['lineItemDiscountAmount'])),
                    "payabaleAmount" => (String) floatval($payabaleAmount), //
                    "manufacturerID" => intval($val['manufacturer_id']),
                    "associateCode" => (String) $associateCode,
                    "associateBranchId" => (String) $associateBranchId,
                    "isPaid" => $isPaid, //
                    "MRP" => (String) $val['MRP'],
                    "isWaiver" => ($val['isWaiver']) ? true : false,
                    "zipcode" => (String) $mainOrder["order"]["patientinfo"]["pincode"],
                    "engage_at" => (String) $mainOrder["mode_of_service"],
                    "OMSNetAmount" => (String) floatval($val['net_amount']),
                    "voucherApportionedAmount" => (String) floatval($val['voucher_amount']),
                    // extra
                    "CLI" => (String) floatval($val['cli']),
                    "margin" => "0.0%",
                    "invoiceTo" => $val['invoiceto'],
                    "isReturnable" => ($val['isReturnable']) ? true : false,
                    "itemName" => empty($val['item_name']) ? empty($val['itemname']) ? "" : $val['itemname'] : $val['item_name'],
                    "specialityID" => 0, //
                    "coupon" => $mainOrder["payment_info"]["coupon"],
                    "updatedPrice" => (String) 0, //
                ];
            }
            if ($mainOrder["order"]["patientinfo"]["service_type"] == 2) {
                $li['unitPrice'] = (String) floatval($x['item_mrp']);
            }
            if ($val['roleBasedService']) {
                if ($val['component_no'] == 8) { // DDO || RDO
                    $reportDeliveryChargesList[] = $li;
                    continue;
                }
                $clinicalServices[] = $li;
                continue;
            }
            $LineItems[] = $li;
        }

        // get penalty amount
        $penaltyAmount = 0;
        if (!empty($mainOrder['penalty']) && is_array($mainOrder['penalty'])) {
            foreach ($mainOrder['penalty'] as $item) {
                if ($item['type'] == "PENALTY" && $item['status'] == 4) {
                    $penaltyAmount += floatval($item['amount']);
                }
            }
        }

        //$orderitem;
        if (!empty($mainOrder['advance_receipt'])) {
            foreach ($mainOrder['advance_receipt'] as $receipt) {
                if($receipt['type'] != 2){
                    $advance_receipt_amt += floatval($receipt['receipt_amount']);
                }
            }
        }
        $amountPaid = $this->getPaidAmount([$order_id])['amountPaid'];
        $amountPaid = $advance_receipt_amt + $amountPaid; 
        // create payload and send to MDM
        $vouchersDlt = [];
        if (!empty($mainOrder['payment_info']['voucher_code'])) {
            $vouchersDlt[] = [
                "voucherType" => $mainOrder['payment_info']['voucher_assoc_code'],
                "voucherNumber" => $mainOrder['payment_info']['voucher_code'],
            ];
        }
        $reqPayload = [
            "vouchers" => $vouchersDlt,
            "useWallet" => 'true',
            "penaltyAmount" => (String) $penaltyAmount,
            "paidAmount" => (String) round(floatval($amountPaid), 2),
            "LineItems" => $LineItems,
            "clinicalServices" => $clinicalServices,
        ];
        if($mainOrder['order']['patientinfo']['service_type'] == 2){
            $reqPayload['medicineDeliveryChargesList'] = $reportDeliveryChargesList;
        }else{
            $reqPayload['reportDeliveryChargesList'] = $reportDeliveryChargesList;
        }
        if (empty($reportDeliveryChargesList)) {
            unset($reqPayload['reportDeliveryChargesList']);
        }
        if (empty($clinicalServices)) {
            unset($reqPayload['clinicalServices']);
        }
		
		//FOR RETURN ORDER
		if($action == 5)
		{
			$reqPayload['isDROChargesApplied'] = true;
			$returnfilter = ['order.business.reference_order_id' => (int) $order_id];
			$returnOrder = $this->dbo->findOne("masters", "orders", $returnfilter, []);
			//print_r($returnOrder);exit;
			
			//IF A RETURN ORDER IS ALREADY GENERATED DRO CHARGE NEED NOT BE ADDED AGAIN
			if(!empty($returnOrder)) 
			{
				$reqPayload['isDROChargesApplied'] = false;
			}
        }
		
        //return $reqPayload;
        //:http://gcmuatv3.callhealth.com:8080/mdm_v3/services/domain/OrderLevelUpdateCalculations
        $url = $this->config->getconfig('mdmpath', "domain/OrderLevelUpdateCalculations");
        $startTime = microtime(true);
        $api_res = $this->utility->my_curl($url, 'POST', json_encode($reqPayload), 'json', null, 10);
        $this->log->logThirdPartyCall("MDM", $url, $startTime, $reqPayload, $api_res);
        //return $api_res;
        //die;
        if (strtolower($api_res['status']) != 'success') {
            return array("status" => 0, "code" => "10400", "message" => "Request failed from MDM : " . $api_res['message']);
        }

        if (!empty($api_res['reportDeliveryChargesList'])) {
            array_push($api_res['lineItems'], $api_res['reportDeliveryChargesList']);
        }
        if (!empty($api_res['clinicalServices'])) {
            array_push($api_res['lineItems'], $api_res['clinicalServices']);
        }
        if (!empty($api_res['medicineDeliveryChargesList'])) {
            array_push($api_res['lineItems'], $api_res['medicineDeliveryChargesList']);
        }
        //return $api_res;
        $penaltyAmount = $api_res['penaltyAmount'];
        foreach ($api_res['lineItems'] as $item) {
            $resLi[$item['code']] = $item;
        }

        //return $resLi;
        //create str for modified orderitem
        $updatedLi = [];
        $discount_amount = $net_amount = $gross_amount = $voucher_amount = $coupon_amount = $wallet_amount = $cli = $penalty_amount = $payable_amount = 0;
        foreach ($mainOrder["order"]["orderitem"] as $val) {

            //add validation rules here if any
            //1. Existing cancel item save as it is
            if ($val['item_status'] == 8) { //if ($payload->lineitem == $val['item_code']) {
                $updatedLi[] = $val; // save as it is
                continue;
            }
            if (in_array($val['item_code'], $payload->lineitem) && $action == 1 ){
                $val['item_status'] = 8;
                $updatedLi[] = $val; // save as it is
                continue;
            }
            if (in_array($val['item_code'], $payload->lineitem) && $action == 2 ){
                $val['item_status'] = 2;
                $val['quantity'] = $val['sessions'] = $quantity;
            }
            $LiDiscount = floatval($resLi[$val['item_code']]['grossAmount']) - floatval($resLi[$val['item_code']]['OMSNetAmount']); 
            $discount_amount += $LiDiscount;
            $net_amount += floatval($resLi[$val['item_code']]['OMSNetAmount']);
            $gross_amount += floatval($resLi[$val['item_code']]['grossAmount']);
            $cli += floatval($resLi[$val['item_code']]['CLI']);
            $coupon_amount += floatval($resLi[$val['item_code']]['apportionedCouponAmount']);
            $wallet_amount += floatval($resLi[$val['item_code']]['apportionedWalletAmount']);
            $voucher_amount += floatval($resLi[$val['item_code']]['voucherApportionedAmount']);
            $payable_amount += floatval($resLi[$val['item_code']]['payabaleAmount']);

            $updatedLi[] = array_merge($val, [
                // "database_column" => "payload_response"
                "discount_amount" => floatval($LiDiscount),
                "net_amount" => floatval($resLi[$val['item_code']]['OMSNetAmount']),
                "gross_amount" => floatval($resLi[$val['item_code']]['grossAmount']),
                "cli" => floatval($resLi[$val['item_code']]['CLI']),
                "coupon_amount" => floatval($resLi[$val['item_code']]['apportionedCouponAmount']),
                "wallet_amount" => floatval($resLi[$val['item_code']]['apportionedWalletAmount']),
                "voucher_amount" => floatval($resLi[$val['item_code']]['voucherApportionedAmount']),
                "cartDiscountApportionedAmount" => floatval($resLi[$val['item_code']]['cartDiscountApportionedAmount']),
                "lineItemDiscountAmount" => floatval($resLi[$val['item_code']]['lineItemDiscountAmount']),
                "isWaiver" => ($resLi[$val['item_code']]['isWaiver']) ? true : false,
            ]);
        }
		
		
		//IN CASE OF RETURN ORDER WE NEED NOT APPLY IN THE ORDER
		if($action != 5)
		{
			$set = array();
			// patientinfo
			$set['order.patientinfo.discount_amount'] = $discount_amount;
			$set['order.patientinfo.net_amount'] = $net_amount;
			$set['order.patientinfo.gross_amount'] = $gross_amount;
			$set['order.patientinfo.voucher_amount'] = $voucher_amount;
			$set['order.patientinfo.coupon_amount'] = $coupon_amount;
			$set['order.patientinfo.wallet_amount'] = $wallet_amount;
			$set['order.patientinfo.cli'] = $cli;
			$set['order.patientinfo.final_delivery_date'] = date("Y-m-d\TH:i:s", time() + 86400 ) . '.000Z';
			// update payment_info
			$set['payment_info.gross_amount'] = $gross_amount;
			$set['payment_info.discount_amount'] = $discount_amount;
			$set['payment_info.net_amount'] = $net_amount;
			$set['payment_info.wallet_amount'] = $wallet_amount;
			$set['payment_info.voucher_amount'] = $voucher_amount;
			$set['payment_info.coupon_amount'] = $coupon_amount;
			$set['payment_info.penalty_amount'] = $penalty_amount;
			$set['payment_info.payable_amount'] = $payable_amount;
			$set['payment_info.cli'] = $cli;
			$set['order.orderitem'] = $updatedLi;  // update orderinfo
			//return $set;
			$filter = array('_id' => (int) $order_id);
			$update = $this->dbo->update("masters", "orders", $filter, $set, [], array("multi" => true));

			// update transaction
			$txnUpdate['transaction_code'] = $transaction_code;
			$txnUpdate['order_id'] = $order_id;
			$txnUpdate['gross_amount'] = $gross_amount;
			$txnUpdate['net_amount'] = $net_amount;
			$txnUpdate['discount_amount'] = $discount_amount;
			$txnUpdate['wallet_amount'] = $wallet_amount;
			$txnUpdate['voucher_amount'] = $voucher_amount;
			$txnUpdate['coupon_amount'] = $coupon_amount;
			$txnUpdate['payable_amount'] = $payable_amount; 
			$txnUpdate['payment_amount'] = $amountPaid;
			$this->finance->calculate_transaction($txnUpdate);

			// create order log for
			$this->orderinfo->createlog($actionByName, $payload->status, $logaction, $actionById, $actionByName, $log_desc, $current_w_id, $current_w_did, $order_id, $reason, $comment, $facility_id, $popname, $extraLogFields = []);
		}
		
		$response = array("status" => 1, "code" => "10100", "message" => $message);
		if(isset($api_res['returnCollection']))
		{
			$response['message'] = 'Return charge received';
			$response['droCharge'] = $api_res['returnCollection'];
		}	

        return $response; 
    }

    /**
     * 10100:
     * 10200: Invalid Input, Required fields are missing
     * 10300: Invalid order_id
     * 10400: Functionality is not applicable for this order
     * 10500: Invalid line_item, No data return from MDM
     * 10600: Unable to add lineitem. Order lineitem is already exist
     * 10700: Unable to delete lineitem. Lineitem is already deleted
     * 10800: Unable to change quantity. Lineitem is already cancelled
     *
     *  */

    // add new line item
    public function add($payload, $ticket, $order)
    {

        // validate required fields
        $validation_fields = array("itemid", "itemname", "line_item", "service_type", "gross_amount", "discount_amount", "net_amount");
        if ($payload->service_type == 2) { // drug
            $validation_fields = array_merge($validation_fields, array("quantity", "sampletype", "reportdeliverydateto", "reportdeliverydatefrom"));
        }
        if ($payload->service_type == 3) { // pathology
            $validation_fields = array_merge($validation_fields, array("department", "sampletype", "reportdeliverydateto", "reportdeliverydatefrom", "vacutainer"));
        }
        //return $payload;
        foreach ($validation_fields as $fields) {
            if (!isset($payload->{$fields})) {
                return array("status" => 0, "code" => "10200", "message" => "Required fields are missing : item.$fields");
            }
        }

        $final_delivery_date = $payload->final_delivery_date;
        $discount_amount += floatval($payload->discount_amount);
        $net_amount += floatval($payload->net_amount);
        $gross_amount += floatval($payload->gross_amount);
        if (strtotime($final_delivery_date) < strtotime($payload->reportdeliverydateto)) {
            $payload->final_delivery_date = $payload->reportdeliverydateto;
        }

        // call MDM api to get itemdetails
        $url = $this->config->getconfig('mdmpath', "fetchservice/getLineItemsByServiceCodes");
        $pLoad = ["data" => [["business" => $payload->service_type, "itemcodes" => [$payload->line_item]]]];
        $startTime = microtime(true);
        $buffer = $this->utility->my_curl($url, 'POST', json_encode($pLoad), 'json', null, 10);
        $this->log->logThirdPartyCall("MDM", $url, $startTime, $pLoad, $buffer);
        if (empty($buffer)) {
            return array("status" => 0, "code" => "10500", "message" => "Invalid line_item, No data return from MDM for ".$payload->line_item);
        }
        $masterLI = $buffer[$payload->line_item];

        $orderitem = array(
            "item_id" => $payload->itemid,
            "item_code" => $payload->line_item,
            "itemname" => $payload->itemname,
            "doctor" => (String) $payload->doctor,
            "coupon" => (String) $payload->coupon,
            "quantity" => (int) $payload->quantity,
            "type" => (String) $payload->type,
            "gross_amount" => (float) $payload->gross_amount,
            "discount_amount" => (float) $payload->discount_amount,
            "net_amount" => (float) $payload->net_amount,
            "cli" => (float) $payload->cli,
            "MRP" => (float) $payload->mrp,
            "item_status" => "0",
            "service_type" => (String) $payload->service_type,
            "invoiceto" => isset($payload->invoiceto) ? $payload->invoiceto : "0",
            "reportto" => isset($payload->reportto) ? $payload->reportto : "",
            "corporateinvoiceemail" => (String) $payload->corporateinvoiceemail,
            "corporatereportemail" => (String) $payload->corporatereportemail,
            "reportdeliverydatefrom" => isset($payload->reportdeliverydatefrom) ? date("Y-m-d\TH:i:s", strtotime($payload->reportdeliverydatefrom)) . '.000Z' : '',
            "reportdeliverydateto" => isset($payload->reportdeliverydateto) ? date("Y-m-d\TH:i:s", strtotime($payload->reportdeliverydateto)) . '.000Z' : '',
            "sampletype" => $payload->sampletype,
            "department" => $payload->department,
            "roleBasedService" => 0,
            "unique_id" => (String) $this->dbo->id(),// using if want to revert changes
        );
        //prescription_required:true; packsize:4; category:1; subcategory_id:23,
        if ($payload->service_type == 3 || $payload->service_type == 4) {
            $orderitem['component_no'] = "7";
            $orderitem['itemname'] = $masterLI['name'];
            $orderitem['prescribed'] = $masterLI['prescribed'];
            $orderitem['department'] = $masterLI['departmentName'];
            $orderitem['vacutainer'] = $masterLI['vacutainer'];
            $orderitem['sampleType'] = $masterLI['sampleType'];
            $orderitem['item_id'] = $masterLI['testID'];
        }

        if ($payload->service_type == 2) {
            $orderitem['item_mrp'] = $payload->priceperunit;
            $orderitem['old_item_mrp'] = $payload->priceperunit;
            $orderitem['old_gross_amount'] = $payload->gross_amount;
            $orderitem['old_discount_amount'] = $payload->discount_amount;
            $orderitem['old_net_amount'] = $payload->net_amount;
            $orderitem['markup_amount'] = $payload->markup_amount;
            $orderitem['manufacturer_id'] = $masterLI['manufacturerID'];
            $orderitem['manufacturer'] = $masterLI['manufactureName'];
            $orderitem['category'] = $masterLI['categoryID'];
            $orderitem['prescribed'] = $masterLI['prescribed'];
            $orderitem['isReturnable'] = $masterLI['returnable'];
            $orderitem['itemname'] = $masterLI['name'];
            $orderitem['component_no'] = "8";
        }

        return ["status" => 1, 'orderitem' => $orderitem];

    }
    public function getPaidAmount($orderIds)
    {
        $filter['billing.billinginfo.order_id'] = ['$in' => $orderIds];
        $bills = $this->dbo->find("masters", "billing_info", $filter, ["billing.receiptinfo" => 1]);
        $amountPaid = 0;
        foreach ($bills as $bill) {
            foreach ($bill['billing']['receiptinfo'] as $receipt) {
                if($receipt['type'] != 2){
                    $amountPaid += floatval($receipt['receipt_amount']);
                }
            }
        }
        return ['amountPaid' => $amountPaid];
    }

}
