<?php

error_reporting(E_ALL);

require '../api/vendor/autoload.php';
require '../order.php';
include 'RtctInfo';
require '../api/apihandler.php';


ini_set('memory_limit', '-1');
date_default_timezone_set("Asia/Calcutta"); 

$app = new Slim\App();


$app->post('/v1/orders/all', 'allOrders');

$app->run();

function getname()
{
    return "rtct_route"; 
}

function allOrders($request, $response)
{

    $apiobj = new Apihandler;
    $payload = $apiobj->apirequest($request, "cancel");
    $obj = new RtctInfo;
    $apiresponse = $obj->getAllOrders($payload, $payload->ticket);
    $response = $apiobj->apiresponse($response, "cancel", $apiresponse, $payload->ticket);
    return $response;

}