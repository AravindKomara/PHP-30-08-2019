<?php


ini_set('memory_limit', '-1');

class RtctInfo extends Oms
{

    public function __construct()
    {
        parent::__construct();
    }

    public function getname()
    {
        return "RtctInfo";
    }
    
    // public function getOrderCountByState($payload, $ticket)
    // {

    //     $filter = array(
    //         '$match' => array(
    //             "order.order_status.created_date" => array('$gte' => $payload->from_date, '$lte' => $payload->to_date),
    //             "order.patientinfo.state" => array('$in' => $payload->states),
    //         ),
    //     );

    //     $project = array(
    //         '$project' => array(
    //             "OStatus" => 6,
    //             "result" => array(
    //                 '$_id',
    //                 '$OStatus',
    //                 '$order.patientinfo.scheduled_date',
    //                 '$assaigned_to',
    //                 '$order.order_status.mhoname',
    //             ),
    //         ),
    //     );

    //     $group = array(
    //         '$group' => array(
    //             "_id" => '$OStatus',
    //             'count' => array('$sum' => 1),
    //             'data' => array('$addToSet' => '$result'),
    //         ),
    //     );

    //     $sort = array(
    //         '$sort' => array('count' => 1),
    //     );

    //     $pipeline = array($filter, $project, $group, $sort);
    //     echo json_encode($pipeline);exit;

    //     $result = $this->dbo->aggregate("masters", "orders", $pipeline);
    //     //echo json_encode($result);exit;

    //     if (empty($result)) {
    //         $response = array("status" => 0, "message" => "Operation Failed", "count" => count($result), "data" => $result);
    //         return $response;
    //     } else {
    //         $response = array("status" => 1, "message" => "Operation Success", "count" => count($result), "data" => $result);
    //         return $response;
    //     }
    // }

    public function getAllOrders($payload,$ticket)
    {
        $status = $payload->status;
        $states = $payload->states;
        $cities = $payload->city;
        $date = $payload->date_type;
        $from = $payload->from_date;
        $businessId = $payload->business_id;
        $to = $payload ->to_date;
        //$sortBy = $payload->sortBy;

        $sort = array();

        $filter = array
                (
                    "OStatus" => array('$nin' =>array(6))
                );

        
        if($date == "created_date")
        {
            $filter["order.order_status.created_date"] = array('$gte' => $from, '$lte' => $to);   
            $sort = ["order.order_status.created_date" => -1] ;
        }

        else if($date == "scheduled_date")
        {
            $filter["order.patientinfo.scheduled_date"] = array('$gte' => $from, '$lte' =>$to); 
            $sort = ["order.patientinfo.scheduled_date" => -1];   
        }

        else if($date == "completed_date")
        {
            $filter["order.patientinfo.completed_date"] = array('$gte' => $from, '$lte' =>$to);
            $sort = ["order.patientinfo.completed_date" => -1] ;     
        }
        else
        {
            $filter["order.patientinfo.scheduled_date"] = array('$gte' => $from, '$lte' =>$to); 
            $sort = ["order.patientinfo.scheduled_date" => -1]; 
        }


        if(isset($cities))
        {
            $filter["order.patientinfo.city"] = array('$in' => $cities);
        }

        if(isset($states))
        {
            $filter["order.patientinfo.state"] = array('$in' => $states);
        }

        $project = array(
            "orderDid" =>'$odid',
            "orderStatus" => '$OStatus',
            "officerID" => '$assaigned_to',
			"officerName" => '$order.order_status.mhoname',
			"customerMRN" => '$order.patientinfo.mrn',
            "customerAddress" => '$order.patientinfo.address',
            "customerName" => '$order.patientinfo.name',
            "serviceTaken" => '$order.patientinfo.service_type',
            "scheduledDate" => '$order.patientinfo.scheduled_date'
			//"officerNumber" => '',
        );


        $pipeline = array(array('$match'=>$filter),array('$project'=>$project),array('$sort'=>$sort));
        //echo json_encode($pipeline);exit;

        $finalOrderDetials = $this->dbo->aggregate("masters","orders",$pipeline);
        //print_r($finalOrderDetials);exit;

        foreach($finalOrderDetials as $key => $orderDetails)
        {
            $finalOrderDetials[$key]['serviceTaken'] = $this->utility->getbusinessName($orderDetails[serviceTaken]);
        }
        return $finalOrderDetials;









    }

}//end of file!!!!!