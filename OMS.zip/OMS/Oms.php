<?php
//error_reporting(E_ALL);

//action
require 'action/finance.php';
require 'action/MedicineSupplies.php';
require 'action/orderinfo.php';
require 'action/orderupdation.php';
require 'action/OrderWorkFlow.php';
require 'action/Payments.php';
require 'action/Notification.php';
require 'action/AppSupport.php';

//business
include 'business/care.php';
include 'business/imaging.php';
include 'business/medicine.php';
include 'business/wellness.php';
include 'business/pathology.php';
include 'business/econsultation.php';
include 'business/mediequipment.php';
include 'business/package.php';

//libraries
include 'libraries/choice.php';
include 'libraries/ihs.php';
include 'libraries/sugar_crm.php'; 
include 'libraries/mdm.php';
include 'libraries/gcm.php';
include 'libraries/associate.php';
include 'libraries/chiss.php';
include 'libraries/DelhiveryExpressLibrary.php';
//include 'libraries/smsemail.php';

//rtct
include 'rtct/RtctInfo.php';

class Oms
{
    // Hold the class instance.
    private static $instance;

    public function __construct()
    {
        self::$instance = &$this;
        $this->utility = ($this->utility) ? $this->utility : new Utility;
        $this->config = ($this->config) ? $this->config : new Config;
        $this->dbo = ($this->dbo) ? $this->utility : new Dbo;
        $this->log = ($this->log) ? $this->log : new Logapp;
    }

    public static function getInstance()
    {
        if (self::$utility == null) {
            self::$utility = new Utility;
        }
        if (self::$config == null) {
            self::$config = new Config;
        }
        if (self::$dbo == null) {
            self::$dbo = new Dbo;
        }
        if (self::$log == null) {
            self::$log = new Logapp;
        }
        return self::$instance;
    }
	
	public function trigger_email_sms_event($order_id, $status, $component_id, $mode_of_service, $business_id, $flag, $corporate_id)
    {
        if (!empty($corporate_id)) {
            return false;
        }
		if($flag == 5){ // for COD order send prepay link
			$flag = 4;
		}
		if($flag == 8){ // assess
			$flag = 10;
        }
        if($flag == 12){ // trans
			$flag = 14;
        }
        if($flag == 16){ // careplan
			$flag = 18;
		}
        if($business_id == 8){ // attendant -> nursing
			$business_id = 6;
		}
        
        //print_r($flag);exit;
		if (in_array($corporate_id, [-1])) {
            return false;
        }
        $filter = ['component_id' => intval($component_id), 'status' => intval($status), 'mode_of_service' => intval($mode_of_service),'business_id' => intval($business_id), 'action_flag_id' => intval($flag), 'is_active' => true];
        $resArr = $this->dbo->find('masters', 'email_sms_template_mappings', $filter, []);
		$filter['order_id'] = $order_id;
		$filter['corporate_id'] = $corporate_id;
		$this->log->logThirdPartyCall("EMAIL_SMS", 'trigger_email_sms_event', microtime(true), $filter, $resArr, $requestType = 'ASYNC', $method = "POST");
        if (empty($resArr)) {
            return false;
        }
		$url = $this->config->getconfig('serverurl', 'OMS/api/operation.php/v1/orders/notification/eventdata');
		foreach($resArr as $res){
			if (!empty($res['email_template_id']) && $res['enable_email']) {
				$param = json_encode(["order_id" => $order_id, "order_status" => $status, "component_id" => $component_id, "mode" => 1, "template_id" => $res['email_template_id']]);
				$startTime = microtime(true);
				$rs = $this->utility->async_curl($url, $param);
				$this->log->logThirdPartyCall("EMAIL_SMS", $url, $startTime, json_decode($param),['success' => $rs], $requestType = 'ASYNC', $method = "POST");
			}
			if (!empty($res['sms_template_id']) && $res['enable_sms']) {
				$param = json_encode(["order_id" => $order_id, "order_status" => $status, "component_id" => $component_id, "mode" => 2, "template_id" => $res['sms_template_id']]);
				$startTime = microtime(true);
				$rs = $this->utility->async_curl($url, $param);
				$this->log->logThirdPartyCall("EMAIL_SMS", $url, $startTime, json_decode($param), ['success' => $rs], $requestType = 'ASYNC', $method = "POST");
			}
		}
        return true;
    }

}
