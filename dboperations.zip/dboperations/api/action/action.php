<?php

/* include '../dbo.php';
  include '../utility.php'; */
ini_set('memory_limit', '-1');
require 'dbo.php';
class Action {

   public function userRegistration($payload){
      // print_r($payload);exit;
       $dboobj = new Dbo;//creating object for db operations file
       $apidata['username'] = $payload->username;
       $apidata['email'] = $payload->email;
       $apidata['password'] = $payload->password;
       //test is database
       //users is collection
       $response = $dboobj->insert("test", "users", $apidata);//calling mongodb insert method
      // print_r($response);exit;
       return $response;
   }
}

?>
