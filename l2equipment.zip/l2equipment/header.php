<?php include_once("config/config.php");?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
		<title>CallHealth</title>
		<link rel="icon" href="images/favicon.ico" type="image/gif" sizes="16x16" />
		<link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/css-style.css" rel="stylesheet">
		<link href="css/datepicker.css" rel="stylesheet">
		<!--<script src="css/bootstrap-datetimepicker.css"></script> -->
		<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		
		<style>
		.loader {
			position: fixed;
			left: 0px;
			top: 0px;
			width: 100%;
			height: 100%;
			z-index: 9999;
			background: url('images/loader.gif') 50% 50% no-repeat rgb(0,0,0);
			opacity: .9;
		}
		</style>
	</head>
<body>
<div class="loader"></div>
	<header>
	<div class="container-fluid main_header">
		<nav id="navbar-example" class="navbar navbar-default navbar-static">
			<div class="container-fluid header_contain">
				<div class="navbar-header">
					<button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".bs-example-js-navbar-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand cust_brand" href="#" title="CallHealth Everything About Health" alt="CallHealth Everything About Health">
						<img class="logo-main" alt="CallHealth Everything About Health" title="CallHealth Everything About Health" src="images/ch-logo.png" />
					</a>
				</div>                 
			</div>
		</nav>
	</div>    
	<nav class="navbar-default main_nav">
		<div class="overlay">
			<div class="container-fluid">
				<div class="row">
					<div class="collapse navbar-collapse bs-example-js-navbar-collapse topmenu">
						<ul class="nav navbar-nav navbar-right mobile_log">
							<li>
								<a href="#"  class="super_pop" id="call_status">
									<i class="fa fa-circle available"></i>Available
								</a>							
							</li> 
							<li class="cust_divider">&nbsp;</li>
							<li id="fat-menu" class="dropdown">
								<a href="#" class="user_details" data-toggle="dropdown">
								   Welcome &nbsp; <b><?php echo $_SESSION['l2equp_user_name']; ?></b>
									<i class="fa fa-user fa-fw"></i><span class="caret"></span>
								</a>
								<ul class="dropdown-menu" aria-labelledby="drop3">
									<li>
										<div class="navbar-login">
											<div class="row">
												<div class="col-sm-12 col-xs-12">
													<ul class="profile_section">
														<li class="myprofile"><a onclick="change_status(1)" href="#"><i class="fa fa-circle available" aria-hidden="true"></i>Available</a></li>
														<li class="myprofile"><a onclick="change_status(2)" href="#"><i class="fa fa-circle unavailable" aria-hidden="true"></i>Away</a></li>
														<li class="myprofile"><a onclick="change_status(3)" href="#"><i class="fa fa-circle cancel" aria-hidden="true"></i>Busy</a></li>
														<li class="divider">&nbsp;</li>
														<li class="myprofile"><a onclick="logout()" href="#"><span class="glyphicon glyphicon-off">&nbsp;</span>Logout</a></li>
													</ul>

												</div>                                          
											</div>
										</div>
									</li>                                
								</ul>
							</li>                 
						</ul>                     
					</div>
				</div>
			</div>
		</div>
	</nav> 
</header>