﻿<?php
include_once("config/config.php");
//echo "<pre>";
//print_r($_GET);exit;
$sessionId = $_GET['crmSessionId'];
$phone = ($_GET['phone'])?$_GET['phone']:"";

// for test
$_SESSION['l2equp_crmSessionId']="xyz";//temporary purpose
$_SESSION['l2equp_user_name']="test";//temporary purpose
$_SESSION['l2equp_user_id']="test"; 
$_SESSION['l2equp_patient_mobile']=""; 
//$_SESSION['l2equp_patient_mobile']="7780241401";
header("location:dashboard.php");
//exit;
// end for test	 
if(isset($sessionId) && trim($phone) !== "") {
	if (preg_match("/^\d+$/", $phone)){
		$response = validate_the_request($securl,$sessionId, $phone); //validating session
		if ($response == "1") {			
			header("location:dashboard.php");
		} else {
			echo 'session key received but not validated';
			exit;
		}
	} else {
		echo 'phone number should contain only numbers';
		exit;
	}
}elseif (isset($sessionId) && trim($phone)==""){
    $response = validate_the_request($securl,$sessionId,""); //validating session
    if ($response == "1") { 
            header("location:dashboard.php");    
    } else {
           echo 'session key received but not validated';
           exit;      
    }
}else {
    echo 'Please contact to admin.';
    exit;
}

function validate_the_request($securl,$sessionId,$phone) {
    $url = $securl . "/api/validateSessionKeyId";    
    $header = array('x-session-key-id:' . $sessionId);	
    $result = common_curl_call($url, "", $header, "post");
    $result = json_decode($result); 
    $status = 0;
    if ($result->status == "1") {
		if($result->roleId=="251"){
			$status = 1;
		}
    }
    if ($status == 1) {
        $_SESSION['l2equp_crmSessionId']=$sessionId;//temporary purpose
        $_SESSION['l2equp_user_name']=$result->officer->fname;//temporary purpose
        $_SESSION['l2equp_user_id']=$_GET['userId'];
		$_SESSION['l2equp_patient_mobile']=$phone;
        $_SESSION['l2equp_type'] = "agent";
		$_SESSION['l2equp_patient_mobile'] = $phone;
        /*if (trim($phone) !== "") {
            $_SESSION['l2equp_patient_mobile'] = $phone;
        }*/
        return "1";
    } else {
        return "0";
    }
}

function common_curl_call($url, $param,$header,$method) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    if ($param != "") {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
    }
    if ($method == "post") {
        curl_setopt($ch, CURLOPT_POST, true);
    }
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    $resultcurl = curl_exec($ch);
    // print_r($resultcurl);exit;
    curl_close($ch);
    return $resultcurl;
}
?>