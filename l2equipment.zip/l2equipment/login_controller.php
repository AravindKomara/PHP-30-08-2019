<?php include_once("config/config.php");
//for SEC login case
if ($_COOKIE["_chz_id"] != null) {
        $response = validate_the_request($securl,$_COOKIE["_chz_id"]);//validating session
        if ($response == "1") {
            header("location:dashboard.php");
        } else {
            $_SESSION['invalidmethod'] = "Invalid User";
            header("location:index.php");
        }
}else{
    $uname = $_POST['username'];
    $upass = $_POST['password'];			
    $reqparmt = array(
		'userName'=>$uname,
		'password'=>$upass
	);			
    $reqparmt = json_encode($reqparmt);
    $url = $serverhostpath.'PharmaServices/meqindex.php/v1/userAuthentication';
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $reqparmt);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER,array('Content-Type: application/json'));
    $result = curl_exec($ch);
    curl_close($ch);
    $response=json_decode($result);
//echo "<pre>";
//print_r($response);exit;				
     if($response->response->status==1){
	//if($response->userinfo->userinfo->GROUP_ID=="12"){
	if($response->userinfo->userinfo->GROUP_ID=="500009"){
		$_SESSION['user_name']=$response->userinfo->userinfo->FIRST_NAME." ".$response->userinfo->userinfo->LAST_NAME;
		$_SESSION['user_id']=$response->userinfo->userinfo->OFFICER_ID;
		$_SESSION['group_id']=$response->userinfo->userinfo->GROUP_ID;
		$val=isset($response->userinfo->userinfo->user_work_place)?$response->userinfo->userinfo->user_work_place:"Hyderabad";
		if(trim($val)==""){
			$_SESSION['work_place']="Hyderabad";
		}else{
			$_SESSION['work_place']=trim($val);
		}		
		header("location:dashboard.php"); 
	}else{
		$_SESSION['invalidmethod']="Invalid User";
		header("location:index.php");
	}
   }else{	
	$_SESSION['invalidmethod']="User doesn't exist";
	header("location:index.php");
   }
}

function validate_the_request($securl,$sessionkey) { 
    $url = $securl . "/api/validateSessionKey";
    $header = array('x-session-key:' . $sessionkey);
    $result = common_curl_call($url, "", $header, "post");
    $result = json_decode($result);
    print_r($result);exit;
    $status = 1;
    if ($result->status == "1") {
        if (isset($result->officer->accessRoles)) {
            foreach ($result->officer->accessRoles as $role) {
                if ($role == "medical_equipments_viewer") {
                    $status = 1;
                }
            }
        }
    }
    if ($status == 1) {
        $_SESSION['user_name'] = ($result->officer->fname . " " . $result->officer->lname);
        $_SESSION['user_id'] = $result->officer->officerId;
        return "1";
    } else {
        return "0";
    }
}

//common curl call
function common_curl_call($url, $param, $header, $method) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    if ($param != "") {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
    }
    if ($method == "post") {
        curl_setopt($ch, CURLOPT_POST, true);
    }
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    $resultcurl = curl_exec($ch);
    // print_r($resultcurl);exit;
    curl_close($ch);
    return $resultcurl;
    
}
?>