var RestServiceURL = sessionStorage.getItem('base_url')+"OMS/api/";
var SHOW_LOADER = "1";
var NO_SHOW_LOADER = "0";
var getsource_of_referral="";
var vendor="";
var typeofEquipement="";
var rowdrug=0;

//common ajax call
function _ajaxEventHandler(_method,payload,responce,showLoader=1,methodtype="POST",route_file="medicine_supply.php/v1/"){
	if(showLoader=='1')
	{$(".loader").show();}
	var url = RestServiceURL+route_file+_method;
	$.ajax({
		url: url, 
		type: methodtype,
    	data: JSON.stringify(payload),
    	contentType: "application/json",
        success: responce,
		error:errormsg
    });
}

function logout() {
    sessionStorage.clear();
    window.location = "logout.php";
}

function usersession() {
    if ($.trim(sessionStorage.getItem('loginid')) == "" && $.trim(sessionStorage.getItem('loginname')) == "") {
        logout();
    }
}
usersession();



function hidecbk() {
    location.reload();
}

function errormsg(error){
	console.log(error);
	alert(error);
	$(".loader").hide();
}

//Google GEO location
var placeSearch, autocomplete;
var componentForm = {
  route: 'long_name',
  locality: 'long_name',
  administrative_area_level_1: 'short_name',
  country: 'long_name',
  postal_code: 'short_name' 
};
function initAutocomplete() {
	// Create the autocomplete object, restricting the search to geographical // location types.
	autocomplete = new google.maps.places.Autocomplete(
		/** @type {!HTMLInputElement} */
		(document.getElementById('autocomplete')),{types: ['geocode']}
	);
	// When the user selects an address from the dropdown, populate the address   // fields in the form.
	autocomplete.addListener('place_changed', fillInAddress);
}
function fillInAddress() {
	// Get the place details from the autocomplete object.
	var place = autocomplete.getPlace();
	for (var component in componentForm) {
		document.getElementById(component).value = '';
		document.getElementById(component).disabled = false;
	}
	// Get each component of the address from the place details
	// and fill the corresponding field on the form.
	for (var i = 0; i < place.address_components.length; i++) {
		$("#address1").val('');
	  //alert(place.address_components);
		var addressType = place.address_components[i].types[0];
		if (componentForm[addressType]) {
			var pincode = place.address_components[i][componentForm[addressType]];
			document.getElementById(addressType).value = pincode;
			if(addressType=="postal_code")
			{
				var _data={pincode:pincode};
				_ajaxEventHandler("Getpopnamefrompincode",_data,cbk_getpopnamefrompincode,SHOW_LOADER);
			}
		}
	}
	//document.getElementById("latlong1").value =(place.geometry.location.lat())+','+(place.geometry.location.lng());
	var latitude = place.geometry.location.lat();
	var longitude = place.geometry.location.lng();
	$("#longitude").val(longitude);
	$("#latitude").val(latitude);
}

function geolocate() {
	debugger;
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var geolocation = {
        lat: position.coords.latitude,
        lng: position.coords.longitude		
      };
	  debugger;
      var circle = new google.maps.Circle({
        center: geolocation,
        radius: position.coords.accuracy
      });
	  debugger;
      autocomplete.setBounds(circle.getBounds());
	  debugger;
    });
  }
}

//service type in an array
var servicetype = {
	"1" : "Consultation Order",
	"2" : "Drug Order",
	"3" : "Diagnostics Order",
	"4" : "Facilitation Order",
	"5" : "Care@Home Order",
	"30" : "Assessment Order"
};

var channel = {
	1:"CP",
	2:"CCO",
	3:"Android App",
	4:"Corporate Portal",
	5:"IOS App",
	6:"L2 Pharma",
	7:"Officer App"
};

var paymentModeName = {
	0:"COD",
	1:"Prepaid (payU)",
	2:"Prepaid (ICICI)",
	3:"Prepaid (Mobikwik)",
	4:"Prepaid (ccavenue)",
	5:"Prepaid (ITZCASH)",
	6:"Prepaid (paytm)",
	7:"Prepaid (AIRTEL)",
	8:"Prepaid (PaytmQR)"
};

function age_calculation(dob){
	dob = new Date(dob);
	var today = new Date();
	return Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
}

function setgender(valu){
	var valu= $.trim(valu);
	var setgender="";
	if(valu=="1" || valu=="F"){setgender="Female";}
	else if(valu=="2" || valu=="M"){setgender="Male";}
	else if(valu=="3"){setgender="Other";}
	else if(valu=="Female"){setgender="Female";}
	else if(valu=="Male"){setgender="Male";}
	else{setgender="Not Stated";}
	return setgender;
}

// Date time format
function todayDateforMDM() {
	var monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
	var d = new Date(),
	//month = '' + (d.getMonth() + 1),
	month = ''+monthNames[d.getMonth()],
	day = ''+d.getDate(),
	hour = ''+d.getHours(),
	minute = ''+d.getMinutes(),
	second = ''+d.getSeconds(),
	year = d.getFullYear();
	if (month.length < 2) month = '0' + month;
	if (day.length < 2) day = '0' + day;
	if (hour.length < 2) hour = '0' + hour;
	if (minute.length < 2) minute = '0' + minute;
	if (second.length < 2) second = '0' + second;
	return [day,month,year].join('-')+" "+[hour,minute,second].join(':');
}

function todayDatetime() {
	var d = new Date(),
	month = '' + (d.getMonth() + 1), 
	day = '' + d.getDate(),
	year = d.getFullYear();
	hour = d.getHours();
	minute = d.getMinutes();
	if (month.length < 2) month = '0' + month;
	if (day.length < 2) day = '0' + day;
	if (hour.length < 2) hour = '0' + hour;
	if (minute.length < 2) minute = '0' + minute;
	return ([year, month, day].join('-')+" "+[hour, minute].join(':'));
}

function todayDate() {
	var d = new Date(),
	month = '' + (d.getMonth() + 1),
	day = '' + d.getDate(),
	year = d.getFullYear();
	hour = d.getHours();
	minute = d.getMinutes();
	if (month.length < 2) month = '0' + month;
	if (day.length < 2) day = '0' + day;
	if (hour.length < 2) hour = '0' + hour;
	if (minute.length < 2) minute = '0' + minute;
	return ([year, month, day].join('-'));
}

function tommorowDate() {
	var d = new Date(new Date().getTime() + 24 * 60 * 60 * 1000),
	month = '' + (d.getMonth() + 1),
	day = '' + d.getDate(),
	year = d.getFullYear();
	hour = d.getHours();
	minute = d.getMinutes();
	if (month.length < 2) month = '0' + month;
	if (day.length < 2) day = '0' + day;
	if (hour.length < 2) hour = '0' + hour;
	if (minute.length < 2) minute = '0' + minute;
	return ([year, month, day].join('-'));
}

function changedate(dt) {
    if (typeof dt != 'undefined') {
        return dt.replace('T', ' ').replace('.000Z', '');
    }else{
		return "-";
	}
}

function calculteDayMonthsYears(type, obj) {
    var rowId = $(obj).parents('tr').attr('id');
    var calValue = $(obj).val();	
    var days = '';
    var months = '';
    var years = '';	
    if (type == 'day') {
        months = getMonths(calValue, type);
        years = getYears(calValue);
		days = calValue;
    } else if (type == 'month') {
        days = getDays(calValue, type);
        years = getYears(days);
		months = calValue;
    } else if (type == 'year') {
        days = getDays(calValue, type);
        months = getMonths(calValue, type);
		years = calValue;
    }
    $('#' + rowId).find('input[name=s_days]').val(days);
    $('#' + rowId).find('input[name=s_month]').val(months);
    $('#' + rowId).find('input[name=s_year]').val(years);
}

function getDays(entereddays, type) {
    var days = "";
    entereddays = +entereddays;
    if (Number.isInteger(+entereddays)) {
        if(type === "month"){
            days = entereddays * 30;
            return days;
        }else if(type === "year") {
            days = entereddays * 365;
            return days;
        }
    } else {
        return 'not a number';
    }
}

function getMonths(entereddays, type) {
    entereddays = entereddays;
    var months = "";
    if (Number.isInteger(+entereddays)) {
        if (type === "day"){			
            months = Math.floor(entereddays / 30);
            var days = entereddays % 30;
            if (days === 0) {
                return months;
            } else {
                months = months + "." + days;
                return months;
            }
        } else if (type === "year") {
            months = entereddays * 12;
            return months;
        }
    } else {
        return 'not a number';
    }
}

function getYears(entereddays) {
    var totaldays = 365;
    var remainder = entereddays % totaldays;
    var year = (entereddays - remainder) / totaldays;
    return year;
}

function calcaprice($this,type) {	
    $rowId = $($this).parents('tr').attr('id');
	$qty = $('#' + $rowId).find('input[name="productQuantity"]').val();
	if($('#' + $rowId).find('input[name="drugsearch"]').val()==""){
		alert("Please choose the item for this row."); return;
		$('#'+$rowId).find('input[name="s_'+type+'"]').val(0)
	}
    if(type=="quantity"){
		$('#'+$rowId).find('span[name="mrp"]').html($('#'+$rowId).find('input[name="s_mrp"]').val() * $qty);
		$('#'+$rowId).find('span[name="baseprice"]').html($('#'+$rowId).find('input[name="s_baseprice"]').val() * $qty);
		$('#'+$rowId).find('span[name="sellingprice"]').html($('#'+$rowId).find('input[name="s_sellingprice"]').val() * $qty);
	}else{
		$s_mrp = parseFloat($('#'+$rowId).find('input[name="s_mrp"]').val());
		$s_baseprice = parseFloat($('#'+$rowId).find('input[name="s_baseprice"]').val());
		$s_sellingprice = parseFloat($('#'+$rowId).find('input[name="s_sellingprice"]').val());
		if($s_mrp<$s_baseprice || $s_mrp<$s_sellingprice){
			alert("Base price and selling price should be less than MRP.");
			$('#'+$rowId).find('input[name="s_'+type+'"]').val(0)
		}else if($s_baseprice>$s_sellingprice){
			alert("Base price should be less than selling price.");
			$('#'+$rowId).find('input[name="s_'+type+'"]').val(0)
		}else{
			var calculated = $('#'+$rowId).find('input[name="s_'+type+'"]').val() * $qty;
			$('#'+$rowId).find('span[name="'+type+'"]').html(calculated);
		}
	}
}

function settimeslot(mainordertime = ""){
	//$('#pmslot').attr('disabled',true);
	var date1 = tommorowDate();
	var date2 = $("#mainorderdate").val();
	//get today time
	var dt = new Date();
	var time = dt.getHours();	
	var date1Updated = new Date(date1.replace(/-/g,'/'));  
	var date2Updated = new Date(date2.replace(/-/g,'/'));
	if(date1===date2){
		$("#scheduledslot option[id='wrongslot']").prop('selected', true);
		$("#mainorderdate").val(date1);		
		if(time>=10){
			$("#scheduledslot option[value='14:00:00']").prop('selected', true);
			$('#10amslot').attr('disabled',false);
			$('#2pmslot').attr('disabled',false);
			$('#6pmslot').attr('disabled',false);
			$("#scheduledslot option[value='"+mainordertime+":00:00']").prop('selected', true);
		}if(time>=14){
			$('#10amslot').attr('disabled',true);
			$("#scheduledslot option[value='18:00:00']").prop('selected', true);
			$('#2pmslot').attr('disabled',false);
			$('#6pmslot').attr('disabled',false);
			$("#scheduledslot option[value='"+mainordertime+":00:00']").prop('selected', true);
		}if(time>=18){
			$("#scheduledslot option[value='22:00:00']").prop('selected', true);
			//$('#').attr('disabled',true);
			$('#10amslot').attr('disabled',true);
			$('#2pmslot').attr('disabled',true);
			$('#6pmslot').attr('disabled',false);
			$("#scheduledslot option[value='"+mainordertime+":00:00']").prop('selected', true);
		}if(time>=22){
			$('#10amslot').attr('disabled',true);
			$('#2pmslot').attr('disabled',true);
			$('#6pmslot').attr('disabled',true);
			$("#scheduledslot option[id='wrongslot']").prop('selected', true);
		}
		
	}else if(date1Updated<date2Updated){
		$('#6amslot').attr('disabled',false);
		$('#10amslot').attr('disabled',false);
		$('#2pmslot').attr('disabled',false);
		$('#6pmslot').attr('disabled',false);
		$("#scheduledslot option[value='"+mainordertime+":00:00']").prop('selected', true);
	}else{
		$("#mainorderdate").val(date1);
		settimeslot();
	}
}