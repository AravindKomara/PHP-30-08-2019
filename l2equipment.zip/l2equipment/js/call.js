var runCallback = "";
function start_polling()
{
	var user_id=sessionStorage.getItem("loginuserid");
	//alert('2');
	//console.log('1');
	var _data = {user_id:user_id};
	if(sessionStorage.getItem("availability")==1){
		
		try{
		_ajaxEventHandler("auto_call",_data,cbk_start_polling,NO_SHOW_LOADER);
		}catch(err)
		{
			start_polling();
		}
	}
	else{
		runCallback= window.setTimeout(function(){ 
			

			start_polling();    
		}, 10000);	
	}	
	//console.log(user_id);
}
function cbk_start_polling(response)
{	
	console.log(response);
	var user_id=sessionStorage.getItem("loginuserid");
	var obj = JSON.parse(response);	
	if(obj.status=="1"){
		var agentid = ($.trim(obj.agentid)!="")?obj.agentid:"1";
		var agentname = ($.trim(obj.agentname)!="")?obj.agentname:"Test";
		$("#callagentid").val(agentid);
		$("#callagenttype").val(agentname);
		sessionStorage.setItem("agentid",agentid);
		sessionStorage.setItem("agentname",agentname);
		var lead_id =(typeof obj.lead_id != 'undefined')?obj.lead_id:'';
		var callNumber =(typeof obj.callNumber != 'undefined')?obj.callNumber:'';
		//$("#attendbutton").attr("onclick","open_patient_records('252080','','1')");
		$("#attendbutton").attr("onclick","open_patient_records('"+obj.mrn+"','"+obj.orderid+"','"+obj.encounterid+"','"+obj.patientid+"','yes','"+lead_id+"','"+callNumber+"')");
		$("#attendbutton").prop("disabled", false);
		custcallbtnup();		
		console.log(response+obj.mrn);
		//sessionStorage.setItem("availability","2");
		//var _data = {mrn:obj.mrn};
		//_ajaxEventHandler("getPatientdetails",_data,cbk_getPatientdetails,NO_SHOW_LOADER);
	}
	window.setTimeout(start_polling, 10000);
		
}
function cbk_getPatientdetails(response)
{
	console.log(response);
	var obj = JSON.parse(response);
	var DisplayText="<table>";
        var result = $.parseJSON(response);
        
	//alert(obj.MRN);
	$.each(obj[0], function(k, v) { DisplayText=DisplayText+"<tr><td>"+k+"</td><td>"+v+"</td></tr>";;});
        DisplayText=DisplayText+"</table>";
	$('#main_content').html(DisplayText);
	//$('#call_status').html('<i class="fa fa-circle cancel"></i>Incall');
	//$("#attendbutton").css("display", "none");
	//$("#endcallbutton").css("display", "block");
		
}


function endcall(){
	$(".loader").show();
	change_status(1);
	endcallTransferPage();
	$("#callagentid").val("");
	$("#callagenttype").val("");
	sessionStorage.setItem("availability",1);
	$('#call_status').html('<i class="fa fa-circle available"></i>Available');
	$("#attendbutton").css("display","block");
	$("#endcallbutton").css("display","none");
	$("#transfercallbutton").css("display","none");
	$("#attendbutton").prop("disabled", true);
	runCallback= window.setTimeout(function(){ 
		start_polling();
	}, 3000);
//$('#main_content').html("");
}


function transcall(){
	var terminal_id=sessionStorage.getItem('sipid');
	var patient_id=typeof(sessionStorage.getItem('patientid')=="undefined")?"":sessionStorage.getItem('patientid');
	var patinet_encounterid=typeof(sessionStorage.getItem('encounterid')=="undefined")?"":sessionStorage.getItem('encounterid');
	var patient_mobile=typeof(sessionStorage.getItem('contactno')=="undefined")?"":sessionStorage.getItem('contactno');
	//var user_role = 2;
	var agent_id=typeof(sessionStorage.getItem('agentid')=="undefined")?($("#callagentid").val()):sessionStorage.getItem('agentid');
	var conf_id=typeof(sessionStorage.getItem('conferenceid')=="undefined")?"":sessionStorage.getItem('conferenceid');
	var doctor_name=typeof(sessionStorage.getItem('l2name')=="undefined")?"":sessionStorage.getItem('l2name');
	var screenid=2;
	$.ajax({
		type: "POST",
		url: sessionStorage.getItem("dialerpath"),
		data: {agent_id:agent_id,conf_id:conf_id,patient_mobile:patient_mobile,patinet_encounterid:patinet_encounterid,patient_id:patient_id,doctor_name:doctor_name,screenid:screenid},
		success: function(result1){			
			console.log(result1);
		}
	});
}

