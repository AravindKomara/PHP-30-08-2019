function getwidgetCount() {
    dashboard_widgets_render();
    $(".loader").hide();
}

function patient_search(searchType, searchText, records_per_page, pagenumber, responsefun) {
    records_per_page = records_per_page || 10;
    pagenumber = pagenumber || 1;
    responsefun = responsefun || "patient_search_list";
    var _data = {searchType: searchType, searchText: searchText, records_per_page: records_per_page, pagenumber: pagenumber};
    _ajaxEventHandler("customerSearch", _data, responsefun, SHOW_LOADER);
    $("#patientsearchvalue").val(searchText);
    $("#patientsearchtype").val(searchType);
}

function open_patient_details() {
    var searchType = $("#patientsearchtype").val();
    var searchText = $("#patientsearchvalue").val();
	if(searchType=="mobile"){
		patient_search(searchType, searchText, 10, 1, patient_search_list);
	}else{
		patient_search(searchType, searchText, 10, 1, cbk_open_patient_records);
	}    
}

function showAddressList(){
    var mrn = sessionStorage.getItem("patientmrn");
    var _datamrn = {mrn: mrn};
   _ajaxEventHandler("getAddress", _datamrn, cbk_getAddress);
}

function cbk_getAddress(response) {
    if (typeof response == 'string') {
        var patientAddressJson = JSON.parse(response);
    } else {
        var patientAddressJson = response;
    }
    var patientAddressArray = [];
    if (patientAddressJson.status == 1) {
        patientAddressArray = patientAddressJson.data.addressDetails;
    }
    patientAddressList(patientAddressArray);    
}

function selectAddress(addressId, modify) {
    modify = modify || false;
    var addressDivId = '#' + addressId;
    var landmark = $(addressDivId).find('.landMarkVal').text();
    var cityVal = $(addressDivId).find('.cityVal').text();
    var areaVal = $(addressDivId).find('.areaVal').text();
    var stateVal = $(addressDivId).find('.stateVal').text();
    var zipcodeVal = $(addressDivId).find('.zipcodeVal').text();
    var countryVal = sessionStorage.getItem("country");
    var latitude = $(addressDivId).find('.latitude').text();
    var longitude = $(addressDivId).find('.logitude').text();
    var addressNickName = $(addressDivId).find('.addressNickName').text();
    var district = $(addressDivId).find('.districtVal').text();
    var addressVal = $(addressDivId).find('.addressVal').text();
    var address = addressVal + ", " + areaVal + ", " + cityVal + ", " + stateVal + ", " + countryVal + ", " + zipcodeVal;
    var contactno = sessionStorage.getItem("contactno");
    var alternetcontactno = sessionStorage.getItem("alternetcontactno");
    if (modify == true) {
        $('#address_nick_name').val(addressNickName);
        $('#address1').val(addressVal);
        $('#administrative_area_level_1').val(stateVal);
        $('#locality').val(cityVal);
        $('#route').val(areaVal);
        $('#postal_code').val(zipcodeVal);
        $('#autocomplete').val(landmark);
        $('#pcontactno').val(contactno);
        $('#latitude').val(latitude);
        $('#longitude').val(longitude);
        $('#alternetcontactno').val(alternetcontactno);
        $('.update_address_btn').html('Update Address');
    } else {
        sessionStorage.setItem("landmark", landmark);
        sessionStorage.setItem("city", cityVal);
        sessionStorage.setItem("district", district);
        sessionStorage.setItem("state", stateVal);
        sessionStorage.setItem("country", countryVal);
        sessionStorage.setItem("zipcode", zipcodeVal);
        sessionStorage.setItem("address_nickname", addressNickName);
        sessionStorage.setItem("address", address);
        sessionStorage.setItem("address_id", addressId);
        sessionStorage.setItem("address", address);
        sessionStorage.setItem("address_id", addressId);
        sessionStorage.setItem("latitude", latitude);
        sessionStorage.setItem("longitude", longitude);
        $('#showdelvaddress').html(address);
        $('#addressListModal').modal('hide');
    }
    $('#selected_address_id').val(addressId);
}

function getAddressLatLong(address){
    var geocoder = new google.maps.Geocoder();
    geocoder.geocode({address: address}, function (results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
            var latitude = results[0].geometry.location.lat();
            var longitude = results[0].geometry.location.lng();
           $('#latitude').val(latitude);
           $('#longitude').val(longitude);
        }
    });
}

function cbk_open_patient_records(response) {
    //window.clearTimeout(runCallback);
    if (typeof response.status != "undefined" && response.status == 1) {
        var Obj = response.data.customerList[0];
        //console.log(Obj);
		//return;
        sessionStorage.setItem("patientid", ""); // required
        sessionStorage.setItem("name", Obj.salutation + " " + Obj.firstName + " " + Obj.lastName);
        sessionStorage.setItem("salutation", Obj.salutation);
        sessionStorage.setItem("patientfname", Obj.firstName);
        sessionStorage.setItem("patientlname", Obj.lastName);
        sessionStorage.setItem("patientmrn", Obj.mrn);
        //sessionStorage.setItem("mrn", Obj.mrn);
        //sessionStorage.setItem("displaygender", Obj.Gender);
        sessionStorage.setItem("patientgender", setgender(Obj.gender));
        sessionStorage.setItem("patientdob", Obj.dob);
        sessionStorage.setItem("age", age_calculation(sessionStorage.getItem("patientdob"))); // required
        sessionStorage.setItem("email", Obj.email);
        sessionStorage.setItem("contactno", Obj.mobile);
        sessionStorage.setItem("alternetcontactno", ""); // required
        sessionStorage.setItem("servicetype", "2");
        sessionStorage.setItem("TagName", Obj.tagsList.toString());
        //addressVal
		var landmark = (typeof(Obj.defaultAddressDetails[0].landmark)!="undefined")?Obj.defaultAddressDetails[0].landmark:"";
        sessionStorage.setItem("landmark", landmark);
        sessionStorage.setItem("city", Obj.defaultAddressDetails[0].cityVal);
        sessionStorage.setItem("district", Obj.defaultAddressDetails[0].district);
        sessionStorage.setItem("state", Obj.defaultAddressDetails[0].stateVal);
        sessionStorage.setItem("country", Obj.defaultAddressDetails[0].countryVal);
        sessionStorage.setItem("postal_code", Obj.defaultAddressDetails[0].zipcodeVal);
        //sessionStorage.setItem("zipcode", Obj.defaultAddressDetails[0].zipcodeVal);
        sessionStorage.setItem("longitude", Obj.defaultAddressDetails[0].lngVal);
        sessionStorage.setItem("latitude", Obj.defaultAddressDetails[0].latVal);
        sessionStorage.setItem("address_id", Obj.defaultAddressDetails[0].addressId);
        sessionStorage.setItem("address_type_id", Obj.defaultAddressDetails[0].addressType);
        sessionStorage.setItem("address_nickname", Obj.defaultAddressDetails[0].addressNickName);
        var address = Obj.defaultAddressDetails[0].addressVal + ", " +
		Obj.defaultAddressDetails[0].areaVal + ", " +
		Obj.defaultAddressDetails[0].cityVal + ", " +
		Obj.defaultAddressDetails[0].stateVal + ", " +
		Obj.defaultAddressDetails[0].countryVal + ", " +
		Obj.defaultAddressDetails[0].zipcodeVal;
        sessionStorage.setItem("address", address);

        //remain
        sessionStorage.setItem("ordersmscreate", "0");
        sessionStorage.setItem("prescriptionobj", "");

        sessionStorage.setItem("doctorid", "");
        sessionStorage.setItem("doctorname", "");
        sessionStorage.setItem("popname", "");
        sessionStorage.setItem("facility_id", "100345");
        sessionStorage.setItem("home_popname", "");
        sessionStorage.setItem("home_facility_id", "");

        $("#address1").val(sessionStorage.getItem('address'));
        $("#locality").val(sessionStorage.getItem('city'));
        $("#administrative_area_level_1").val(sessionStorage.getItem('state'));
        $("#route").val(sessionStorage.getItem('district'));
        $("#postal_code").val(sessionStorage.getItem('postal_code'));
        $("#autocomplete").val(sessionStorage.getItem('landmark'));
        $("#popname").val(sessionStorage.getItem('popname'));
        $("#popid").val(sessionStorage.getItem('facility_id'));
        $("#latitude").val(sessionStorage.getItem('latitude'));
        $("#longitude").val(sessionStorage.getItem('longitude'));
        $("#pcontactno").val(sessionStorage.getItem('contactno'));
        $("#alcontactno").val(sessionStorage.getItem('alternetcontactno'));
		
		sessionStorage.setItem("open_order_type",2); 
        render_actiontab_for_mrn(); //pharma_widgets();
        renderBanner();
        renderorderHeader();
		
		//sessionStorage.setItem("is_cart","1");		//_ajaxEventHandler("getItemsFormCart",{"mrn":sessionStorage.getItem("patientmrn"),"businessId":"11"},cbk_open_patient_orders);
		cbk_open_patient_orders("");
		//var _datamrn = {"mrn": sessionStorage.getItem("patientmrn")};
        var _dataforvendor = {systemType:"equipment"};
		_ajaxEventHandler("vendor_list", _dataforvendor, cbk_vendor_list);
		sessionStorage.setItem("ezzetab_sms","");
        $("#backbutton").css("display","block");
    }else{
		console.log(response.data.message);
		alert("Please provide the correct MRN number.");
		$(".loader").hide();
	}
}

//open the order tab with and without order id
function cbk_open_patient_orders(response){
    //console.log(response);
	//extra functionality
	sessionStorage.setItem("open_order_flag","0");
	sessionStorage.setItem("equipmenttype","0");
	sessionStorage.setItem("selectedvendor","0");
	getsource_of_referral="";
	//extra functionality
	
	$(".loader").hide();
	sessionStorage.setItem("source_of_referral", "");
	var _dataforvendor = {systemType:"equipment"};
	var _datamrn = {"mrn": sessionStorage.getItem("patientmrn")};
	_ajaxEventHandler("vendor_list", _dataforvendor, cbk_vendor_list);
	_ajaxEventHandler("get_customer_type", _datamrn,cbk_get_customer_type);
	_ajaxEventHandler("getsource_of_referral", "", cbk_getsource_of_referral);	
	//Need to be check.
	//_ajaxEventHandler("getwalletamt",_datamrn,cbk_getwalletamt);
	rowdrug = 0; 
	renderCreateOrder(response);
	$("#l2vsourcereferral").val("");
	$("#l2vreferby").val("");
	$("#l2vclosedby").val("");
	$("#l2vsreferbymrn").val("");
	if (response.status==1 || response.status=="1"){
		var myarray = [];
		if(sessionStorage.getItem("is_cart")=="1"){
		}else{
			if(sessionStorage.getItem("open_order_type")==0){
				//pending
				var data = response.data;
				console.log(response);
				sessionStorage.setItem('orderid',data._id);
				// set the timeslot
				var mainorderdate = "";
				var mainordertime = "";
				if(typeof data.order.patientinfo.expected_delivery_date != "undefined"){
					mainorderdate1 = changedate(data.order.patientinfo.expected_delivery_date).split(" ");
					mainorderdate = mainorderdate1[0];
					mainordertime = mainorderdate1[1].split(":");
					mainordertime = mainordertime[0];
				}else if(typeof data.order.patientinfo.scheduled_date != "undefined"){
					mainorderdate1 = changedate(data.order.patientinfo.scheduled_date).split(" ");
					mainorderdate = mainorderdate1[0];
					mainordertime = mainorderdate1[1].split(":");
					mainordertime = mainordertime[0];
				}else{
					mainorderdate = tommorowDate();
				}				
				$("#mainorderdate").val(mainorderdate);
				settimeslot(mainordertime);
				//end set the timeslot
				
				$("#l2vreferby").val(data.order.patientinfo.referred_officerid);
				$("#l2vclosedby").val(data.order.patientinfo.closedby);
				$("#l2vsreferbymrn").val(data.order.patientinfo.referred_mrn);
				//$("#l2vsourcereferral option[value='"++"']").prop('selected', true);
				getsource_of_referral = data.order.patientinfo.source_of_referral;
				//$("#").val();
			}
			// address
			sessionStorage.setItem("address_id",((typeof data.order.patientinfo.address_id !="undefined")?data.order.patientinfo.address_id:""));
			sessionStorage.setItem("landmark",((typeof data.order.patientinfo.landmark !="undefined")?data.order.patientinfo.landmark:""));
			sessionStorage.setItem("city",((typeof data.order.patientinfo.city !="undefined")?data.order.patientinfo.city:""));
			sessionStorage.setItem("district",((typeof data.order.patientinfo.district !="undefined")?data.order.patientinfo.district:""));
			sessionStorage.setItem("state",((typeof data.order.patientinfo.state !="undefined")?data.order.patientinfo.state:""));
			sessionStorage.setItem("country",((typeof data.order.patientinfo.country !="undefined")?data.order.patientinfo.country:""));
			sessionStorage.setItem("zipcode",((typeof data.order.patientinfo.pincode !="undefined")?data.order.patientinfo.pincode:""));
			sessionStorage.setItem("address_nickname","");			
			sessionStorage.setItem("latitude",((typeof data.order.patientinfo.delivery_lat !="undefined")?data.order.patientinfo.delivery_lat:""));
			sessionStorage.setItem("longitude",((typeof data.order.patientinfo.delivery_lng !="undefined")?data.order.patientinfo.delivery_lng:""));
			sessionStorage.setItem("address",((typeof data.order.patientinfo.address_id !="undefined")?data.order.patientinfo.address:""));				
			$("#showdelvaddress").html(((typeof data.order.patientinfo.address_id !="undefined")?data.order.patientinfo.address:""));
			//end address
		}
	}else{
		
	}
	
	
    /*sessionStorage.setItem("orderstatuscurorder","");    
    sessionStorage.setItem("prescription_file_length", "0");    
    var Obj = response;
    
    //check mrn is related to corporate or not.
    
    //console.log(Obj);
    if (response.countn > 0) {
        //console.log(Obj.itemlist);
        sessionStorage.setItem("doctorid", ((typeof Obj.itemlist.patientinfo.doctorid != 'undefined') ? Obj.itemlist.patientinfo.doctorid : ""));
        sessionStorage.setItem("doctorid", ((typeof Obj.itemlist.patientinfo.doctorid != 'undefined') ? Obj.itemlist.patientinfo.doctorid : ""));
        sessionStorage.setItem("doctorname", ((typeof Obj.itemlist.patientinfo.doctorname != 'undefined') ? Obj.itemlist.patientinfo.doctorname : ""));
        var orderstatus = (typeof (Obj.itemlist.patientinfo.order_status) == "undefined") ? " " : Obj.itemlist.patientinfo.order_status;
        sessionStorage.setItem("orderstatuscurorder", orderstatus);
        var vendor_id = (typeof Obj.itemlist.vendorinfo != 'undefined') ? Obj.itemlist.vendorinfo.VendorCode : "0";
        //ezeetab
        var ezeetab = (typeof (Obj.itemlist.patientinfo.ezzetab_sms) == "undefined") ? "" : Obj.itemlist.patientinfo.ezzetab_sms;
        sessionStorage.setItem("ezzetab_sms", ezeetab);
        var encid = (typeof (Obj.itemlist.patientinfo.encid) == "undefined") ? "" : Obj.itemlist.patientinfo.encid;
        var service_subtype = (typeof (Obj.itemlist.patientinfo.service_subtype) == "undefined") ? " " : Obj.itemlist.patientinfo.service_subtype;
        var ordersmscreate = (typeof (Obj.itemlist.patientinfo.ordersmscreate) == "undefined") ? "0" : Obj.itemlist.patientinfo.ordersmscreate;
        sessionStorage.setItem("ordersmscreate", ordersmscreate);
        sessionStorage.setItem("placedfromdoctorplace", (typeof (Obj.itemlist.patientinfo.placedfromdoctorplace) == "undefined") ? "0" : Obj.itemlist.patientinfo.placedfromdoctorplace);
        //counpon
        if ($.trim(Obj.itemlist.patientinfo.coupon) != "") {
            $("#l2vCoupanCode").val($.trim(Obj.itemlist.patientinfo.coupon));
            $("#l2vCoupanCode").attr($.trim(Obj.itemlist.patientinfo.couponitem));
        }
        if (encid != "" && orderstatus != "6") {
            $("#orderfrom").html("| SubType - " + service_subtype);
            sessionStorage.setItem("encounterid", encid);
            sessionStorage.setItem("orderstatusencounterid", orderstatus);
            $("#l2vopenprescriptionmadal").show();
            $("#checkboxprescriptionsms").hide();
            $("#checkboxprescriptionsmsname").hide();
            getECpriscription(sessionStorage.getItem("mrn"));
        } else if (orderstatus != "6") {
            sessionStorage.setItem("encounterid", "");
            sessionStorage.setItem("orderstatusencounterid", "");
            $("#orderfrom").html("");
        } else if (orderstatus == "6") {
            var ezeetab = "";
            sessionStorage.setItem("encounterid", "");
            sessionStorage.setItem("orderstatusencounterid", "");
            $("#orderfrom").html("");
            sessionStorage.setItem("ezzetab_sms", ezeetab);
            $("#l2vCoupanCode").val($.trim(""));
            $("#l2vCoupanCode").attr($.trim(""));
            vendor_id = "0";
            $("#l2vCoupanCode").val("");
            $("#l2vCoupanCode").attr("");
            sessionStorage.setItem("placedfromdoctorplace", "0");
        }
        vendor_id = $.trim(vendor_id);
        //$("#vendorname").val(vendor_id);	
        $(".vendorname").val(vendor_id);

        //Set workorder details
        sessionStorage.setItem("orderwid", ((typeof (Obj.itemlist.order_status.workorder_id) == "undefined") ? " " : Obj.itemlist.order_status.workorder_id));
        sessionStorage.setItem("orderwdid", ((typeof (Obj.itemlist.order_status.workorder_did) == "undefined") ? " " : Obj.itemlist.order_status.workorder_did));

        var lead_id = ((typeof (Obj.itemlist.patientinfo.lead_id) == "undefined") ? "" : Obj.itemlist.patientinfo.lead_id);
        var callNumber = ((typeof (Obj.itemlist.patientinfo.callNumber) == "undefined") ? "" : Obj.itemlist.patientinfo.callNumber);
        if ($.trim(lead_id) != "") {
            sessionStorage.setItem("lead_id", lead_id);
        }
        if ($.trim(callNumber) != "") {
            sessionStorage.setItem("callNumber", callNumber);
        }

        //End workorder details

        var address = (typeof (Obj.itemlist.patientinfo.address) == "undefined") ? " " : Obj.itemlist.patientinfo.address;
        var state = (typeof (Obj.itemlist.patientinfo.state) == "undefined") ? " " : Obj.itemlist.patientinfo.state;
        var city = (typeof (Obj.itemlist.patientinfo.city) == "undefined") ? " " : Obj.itemlist.patientinfo.city;
        var area = (typeof (Obj.itemlist.patientinfo.area) == "undefined") ? " " : Obj.itemlist.patientinfo.area;
        var pincode = (typeof (Obj.itemlist.patientinfo.pincode) == "undefined") ? " " : Obj.itemlist.patientinfo.pincode;
        var landmark = (typeof (Obj.itemlist.patientinfo.landmark) == "undefined") ? " " : Obj.itemlist.patientinfo.landmark;
        var popname = (typeof (Obj.itemlist.patientinfo.popname) == "undefined") ? " " : Obj.itemlist.patientinfo.popname;

        var popid = (typeof (Obj.itemlist.patientinfo.facility_id) == "undefined") ? "100345" : Obj.itemlist.patientinfo.facility_id;
        var pcontactno = (typeof (Obj.itemlist.patientinfo.contactno) == "undefined") ? "" : Obj.itemlist.patientinfo.contactno;
        var alcontactno = (typeof (Obj.itemlist.patientinfo.alternetcontactno) == "undefined") ? "" : Obj.itemlist.patientinfo.alternetcontactno;
        sessionStorage.setItem("popname", popname);
        sessionStorage.setItem("facility_id", popid);
        var delivery_lat = (typeof (Obj.itemlist.patientinfo.delivery_lat) == "undefined") ? " " : Obj.itemlist.patientinfo.delivery_lat;
        var delivery_lng = (typeof (Obj.itemlist.patientinfo.delivery_lng) == "undefined") ? " " : Obj.itemlist.patientinfo.delivery_lng;
        if ($.trim(address) != "") {
            $("#address1").val(Obj.itemlist.patientinfo.address);
        }
        if ($.trim(state) != "") {
            $("#administrative_area_level_1").val(Obj.itemlist.patientinfo.state);
        }
        if ($.trim(city) != "") {
            $("#locality").val(Obj.itemlist.patientinfo.city);
        }
        if ($.trim(area) != "") {
            $("#route").val(Obj.itemlist.patientinfo.area);
        }
        if ($.trim(pincode) != "") {
            $("#postal_code").val(Obj.itemlist.patientinfo.pincode);
        }
        if ($.trim(landmark) != "") {
            $("#autocomplete").val(Obj.itemlist.patientinfo.landmark);
        }
        if ($.trim(popname) != "") {
            $("#popname").val(Obj.itemlist.patientinfo.popname);
        }
        if ($.trim(popid) != "") {
            $("#popid").val(Obj.itemlist.patientinfo.facility_id);
        }
        if ($.trim(delivery_lat) != "") {
            $("#latitude").val(Obj.itemlist.patientinfo.delivery_lat);
        }
        if ($.trim(delivery_lng) != "") {
            $("#longitude").val(Obj.itemlist.patientinfo.delivery_lng);
        }
        if ($.trim(pcontactno) != "") {
            $("#pcontactno").val(Obj.itemlist.patientinfo.contactno);
        }
        if ($.trim(alcontactno) != "") {
            $("#alcontactno").val(Obj.itemlist.patientinfo.alternetcontactno);
        }
        //check pin no
        populatepopsetailsbypin(Obj.itemlist.patientinfo.pincode);
        // for show #showdelvpop - pop name		
        $("#showdelvpop").html($("#popname").val());
        $("#showdelvaddress").html($("#address1").val() + " " + $("#administrative_area_level_1").val() + " " + $("#locality").val() + " " + $("#route").val() + " " + $("#postal_code").val());

        if ((typeof (Obj.itemlist.patientinfo.payment_method) != "undefined") && Obj.itemlist.patientinfo.payment_method != null) {
            $("#payment_method").val('' + Obj.itemlist.patientinfo.payment_method);
        } else {
            $("#payment_method").val("0");
        }
        var prescription_file = (typeof (Obj.itemlist.prescription_file) == "undefined") ? "0" : Obj.itemlist.prescription_file;
        if (prescription_file.length == 0 || prescription_file == "0") {
            if (sessionStorage.getItem("encounterid") == "") {
                $("#l2vopenprescriptionmadal").hide();
            }
            sessionStorage.setItem("prescriptionobj", "");
        } else {
            if (orderstatus == "6") {
                $("#l2vopenprescriptionmadal").hide();
                sessionStorage.setItem("prescriptionobj", "");
            } else {
                $("#l2vopenprescriptionmadal").show();
                sessionStorage.setItem("prescriptionobj", prescription_file);
            }
        }
        if (typeof prescription_file.length != "undefined" && prescription_file.length != null) {
            sessionStorage.setItem("prescription_file_length", prescription_file.length);
        } else {
            sessionStorage.setItem("prescription_file_length", "0");
        }

        //refer ans source of referal
        var referedby = (typeof (Obj.itemlist.patientinfo.referedby) == "undefined") ? "" : Obj.itemlist.patientinfo.referedby;
        var referred_mrn = (typeof (Obj.itemlist.patientinfo.referred_mrn) == "undefined") ? "" : Obj.itemlist.patientinfo.referred_mrn;
        var source_of_referral = (typeof (Obj.itemlist.patientinfo.source_of_referral) == "undefined") ? "" : Obj.itemlist.patientinfo.source_of_referral;
        sessionStorage.setItem("source_of_referral", source_of_referral);
        $("#l2vreferby").val($.trim(referedby));
        if ($.trim(referedby) != "9999") {
            $("#referedbylist").html('<option value="9999">9999</option><option value="' + $.trim(referedby) + '">' + $.trim(referedby) + '</option>');
        }
        $("#l2vsreferbymrn").val($.trim(referred_mrn));

        //wallet
        var walletstatus = (typeof (Obj.itemlist.patientinfo.walletstatus) == "undefined") ? "0" : Obj.itemlist.patientinfo.walletstatus;
        if (walletstatus == "1" && (orderstatus != "6")) {
            var walletamt = (typeof (Obj.itemlist.patientinfo.wallet_amount) == "undefined") ? "0" : Obj.itemlist.patientinfo.wallet_amount;
            sessionStorage.setItem("walletstatus", walletstatus);
            $("#l2vwalletbutton").hide();
            $("#l2vitemwalletamount").html(walletamt);
        } else {
            sessionStorage.setItem("walletstatus", "0");
            $("#l2vwalletbutton").show();
            if (orderstatus != "6") {
                walletstatus = "0";
                sessionStorage.setItem("walletstatus", walletstatus);
            }
        }
        //scheduled date
        var secheduledate = Obj.itemlist.patientinfo.scheduled_date.split("T");
        var secheduletime = secheduledate[1].split(":");
        if (orderstatus != "6") {
            settimeslot(secheduledate[0], secheduletime[0]);
        } else {
            $("#mainorderdate").val(tommorowDate());
            settimeslot(tommorowDate());
        }
        if (typeof (Obj.itemlist.prepayment) != "undefined") {
            $("#l2vprepaidamount").html(Obj.itemlist.prepayment.amount);
        }
        checkpricefrommdm();
    }else{
        if ($.trim(sessionStorage.getItem("encounterid")) != "") {
            $("#l2vopenprescriptionmadal").show();
        } else {
            $("#l2vopenprescriptionmadal").hide();
        }
        sessionStorage.setItem("walletstatus", "0");
        checkpricefrommdm();
    }*/
}

function check_itemisavailable(){
	$(".rowdrug").each(function (){
		var tscode = (typeof($(this).find('.drugsearch').attr("data-tscode")) != "undefined")?$(this).find('.drugsearch').attr("data-tscode"):"";
        var listid = $(this).find('.drugsearch').attr("list");
		var entitytype = "mediequipment";
		if(tscode != "") {
			var _data = {filtercolumn:"code",brandname:tscode,listid:listid,entitytype:entitytype}
			_ajaxEventHandler("search_item", _data, cbk_loaddruglist, SHOW_LOADER);
		}
	});
}

function cbk_getsource_of_referral(res){
	var str = "<option value=''>Choose refferal source</option>";
	if(res.status=="0"){
		alert(res.message);
	}else{		
		$.each(res.data, function (key, val) {
			var selected="";
			if(getsource_of_referral!="" && getsource_of_referral==$.trim(val.name)){
				selected = "selected";
			}
			str += "<option value='" + $.trim(val.name) + "' "+selected+">" + $.trim(val.name) + "</option>";
		});	
	}
    $("#l2vsourcereferral").html(str);
    if (sessionStorage.getItem("source_of_referral") != "") {
        var referral = sessionStorage.getItem("source_of_referral");
        $('#l2vsourcereferral').val($.trim(referral));
    }
}

function cbk_get_customer_type(res){
    if (res.status === "0"){
		sessionStorage.setItem("mrncoporateid","");
        sessionStorage.setItem("mrncoporatename","");        
    }else {
        if (typeof res.data != "undefined") {
            sessionStorage.setItem("mrncoporateid", res.data.ID);
            sessionStorage.setItem("mrncoporatename", res.data.name);
        }
    }
	$(".loader").hide(); 
}

function cbk_vendor_list(res){
	if(res.status){
		var htmlBanner = '<option value="0" selected>Select Vendor</option>';
		$.each(res.data, function (key, val) {
			//console.log(val._id);
			var selected="";
			if(vendor!="" && vendor==val.userinfo.USER_ID){
				selected = "selected";
			}
			htmlBanner += '<option value="'+val.userinfo.USER_ID+'" '+selected+'>'+val.userinfo.USER_NAME +'</option>';
		});
		$(".vendorname").html(htmlBanner);
	}else{
		alert(res.message);
	}    
}

function cbk_getwalletamt(res) {
    //console.log(res);
    if (res.itemlist.status == "success") {
        var walletamount = res.itemlist.object.Balance;
        walletamount = parseFloat(walletamount.replace(/,/g, "")).toFixed(2);
        $("#l2vwalletamt").html(walletamount);
        sessionStorage.setItem("walletamount", walletamount);
    } else if (res.itemlist.status == "fail") {
        $("#l2vwalletamt").html("0");
        sessionStorage.setItem("walletamount", 0);
    }
    $(".loader").hide();
}

function loaddruglist(e, $this) {
	if(sessionStorage.getItem("is_cart")=="1"){
		sessionStorage.setItem("is_cart","0");
	}	
    if (e.keyCode != '38' && e.keyCode != '40' && e.keyCode != '13') {
        var str = $($this).val();
        var listid = $($this).attr('list');
        var entitytype = "mediequipment";
        if (str.length >= 3) {
            var _data = {filtercolumn:"name",brandname:str,listid:listid,entitytype:entitytype}
            _ajaxEventHandler("search_item", _data, cbk_loaddruglist, SHOW_LOADER);
        } else {
            $('#' + listid).html("");
        }
    }
}

function cbk_loaddruglist(Obj) {
    $(".loader").hide();
	var druglists="";
    if(Obj.status==1){
		var listid = Obj.listid;
		$.each(Obj.data,function(key, val) {
			druglists += '<option '+
			'data-codedid="' + val.code + 
			'" data-id="' + val.ID + 
			'" data-grossamount="' + val.grossAmount + 
			'" data-discountamount="' + val.discountAmount + 
			'" data-netamount="' + val.netAmount + 
			'" data-prescribed="' + val.prescribed + 
			'" data-priceperunit="' + val.pricePerUnit + 
			'" data-category="' + val.categoryID + 
			'" data-subcategoryid="' + val.subCategoryID + 
			'" data-brand="' + val.brand + 
			'" data-rentalSale="' + val.rentalSale + 
			'" value="' + val.name + 
			'" data-mrp="' + val.mrp + 
			'" data-minQuantity="' + val.minQuantity + 
			'" data-maxQuantity="' + val.maxQuantity + '">';
		});
		$('#'+listid).html(druglists);
		if(sessionStorage.getItem("is_cart")=="1"){
			//console.log($('#'+listid).parent().find('.drugsearch'));
			loadanotherdrug($('#'+listid).parent().find('.drugsearch'));
		}
	}else{
		alert(Obj.message);
	}
}

function loadanotherdrug($this) {
    
	var currentRowId = $($this).parents('tr').attr('id');
	var selecteddiag = $('#' + currentRowId).find("input[name=drugsearch]").val();
    var newlistid = $('#' + currentRowId).find("input[name=drugsearch]").attr("list");
    var id = $($this).attr('id');
	
	console.log(newlistid);
	console.log(selecteddiag);
    console.log($('#' + newlistid + ' [value="' + selecteddiag + '"]'));
    var itemcodefind = ($('#' + newlistid + ' [value="' + selecteddiag + '"]').data('codedid'));
    var drugbrand = ($('#' + newlistid + ' [value="' + selecteddiag + '"]').data('brand'));
    var currentIndex = $($this).parents('tr').index();
    console.log(currentIndex);
 
    $datacode = $(".drugsearch").map(function () {
        return $(this).data('code');
    }).get();
	
    var currentDrug = $($this).val();
    //if (($.inArray(currentDrug, $drugList) > -1) || ($.inArray(itemcodefind, $datacode) > -1)) {
    if ($.inArray(itemcodefind, $datacode) > -1) {
        alert('Same item cannot be ordered two times');
        $($this).val('');
        return;
    }

    var optionval = "";
    var flag = false;
    $('#' + newlistid + " option").each(function () {
        optionval = this.value;
        if (optionval == selecteddiag) {
            flag = true;
            return false;
        }
    });
    if (flag == false && (selecteddiag.trim() != "")){
        alert("Please Select the Correct Test Name");
        $('#loading').hide();
        $('#' + id).focus();
        return false;
    }
    if (selecteddiag.trim() == "")
    {
        return false;
    }
    currentIndex = parseInt(currentIndex) + 1;
    var currentRowId = $($this).parents('tr').attr('id');

    var datalist = $('#' + currentRowId).find('.data_druglist [value="' + currentDrug + '"]');
    console.log(datalist);
    console.log(datalist.data('mrp'));
    var s_mrp = 0.00;
    var brand = datalist.data('brand');
    var codedid = datalist.data('codedid');
    var s_baseprice = 0.00;
    var s_sellingprice = 0.00;
    $('#' + currentRowId).find("input[name=drugsearch]").attr("data-code",codedid);
    $('#' + currentRowId).find("input[name=drugbrand]").val(brand);
    $('#' + currentRowId).find("input[name=productQuantity]").val('1');
    $('#' + currentRowId).find("input[name=s_mrp]").val(s_mrp);
    $('#' + currentRowId).find("input[name=s_baseprice]").val(s_baseprice);
    $('#' + currentRowId).find("input[name=s_sellingprice]").val(s_sellingprice);

    var tBody = $('#mtable').find("tbody");
    var trLength = tBody.find('tr').length;
    if (parseInt(trLength) == currentIndex) {
        $('#mtable tbody').append($("#mtable tbody tr:last").clone().find('input').val('').end());
        rowdrug = rowdrug +1;
		var rowId = 'rowdrug-' + rowdrug;
        var dataListId = 'datalist-' + rowdrug;
        $("#mtable tbody tr:last").attr('id', rowId);
		$("#mtable tbody tr:last").find('.drugsearch').attr('data-code',"");
        $("#mtable tbody tr:last").find('.drugsearch').attr('list', dataListId);
        $("#mtable tbody tr:last").find('.data_druglist').attr('id', dataListId);
		
    }
}

function cancellineitemdiag($this) {
    $index = $('#mtable').find("tbody tr").length;
    console.log($index);
    if ($index > 1) {
        $($this).parents('tr').remove();
    }
}

function addincart(){
	var orders = [];
	$(".rowdrug").each(function (){
        $drugname = $(this).find('.drugsearch').val();
        if ($.trim($drugname)!=""){
            var datalist = $(this).find('.data_druglist [value="' + $drugname + '"]');
            orders.push({
				"mrn": sessionStorage.getItem("patientmrn"),
				"businessId": "11",
				"serviceId": datalist.data("codedid")
			});
		}
	});
	var _data = {
		"parentMrn":sessionStorage.getItem("patientmrn"),
		"orders":orders
	};
	_ajaxEventHandler("addItemsToCart", _data, cbk_addItemsToCart, SHOW_LOADER);
}

function cbk_addItemsToCart(response){
	console.log(response);
	alert(response.message);
}

function createOrder(status=""){
    var referredmrn = "";
	//Check the pincode
	if($.trim(sessionStorage.getItem("postal_code"))=="" || $.trim(sessionStorage.getItem("address_id"))==""){
		alert("Please provide the correct delivery address.");
	}
	
	// check the prefer schedule time slot. 
	if($.trim($("#scheduledslot").val())==""){
		alert("Please choose the time slot.");
		$("#scheduledslot").focus(); return;
	}
	
	//validate the address
    /*if ($.trim($("#address1").val())=="") {
        alert('Please enter address'); return;
    }*/
	
	// validate the reffer by
    /*if ($.trim($("#l2vreferby").val())==""){
        alert('Please enter referred by, if no referred by is there please enter 9999.'); return;
    }else{
        referedby = $("#l2vreferby").val();
        if ($("#referedbylist option[value='" + referedby + "']").length > 3 || referedby == "9999") {
        } else {
            alert('Invalid officer id.'); return;
        }
    }	
	// validate the closedby by
    if ($("#l2vclosedby").val() == "") {
        alert('Please enter closed by, if no closed by is there please enter 9999.'); return;
    }else {
        closedby = $("#l2vclosedby").val();
        if ($("#closedbylist option[value='" + closedby + "']").length > 3 || closedby == "9999") {
        } else {
            alert('Invalid officer id.'); return;
        }
    }*/
	
	if ($.trim($("#l2vreferby").val())==""){
        alert('Please enter referred by, if no referred by is there please enter 9999.'); return;
    }
	if ($("#l2vclosedby").val() == "") {
        alert('Please enter closed by, if no closed by is there please enter 9999.'); return;
    }
	referedby = $("#l2vreferby").val();
	closedby = $("#l2vclosedby").val();
	//validate the source of referal
	if ($("#l2vsourcereferral option:selected").val() == "") {
       alert('Please select source.'); return;
    }
	
    var estdate = $.trim($("#mainorderdate").val());    
    var scheduledslot = $("#scheduledslot option:selected").val();
    if (scheduledslot == "00:00:00") {
        alert("Please select time slot."); return;
    }
    //var scheduletimeforordr=estdate+"T"+scheduledslot+".000Z";
    var scheduletimeforordr=estdate+" "+scheduledslot;
    var referredmrn = $("#l2vsreferbymrn").val();
	var mrn = sessionStorage.getItem('patientmrn');
	
    var totalpaybleamount = 0.00;
    var totalbaseamount = 0.00;
    //var orders = [];
    var orders = {};
	var orders_array = [];
    var deliveryarray = [];
    var temp = 1;
	var choosed_vendor="";
    $(".rowdrug").each(function (){
		//alert("yes");
        $drugname = $(this).find('.drugsearch').val();
        if ($.trim($drugname) != "") {
			//alert("yes1");
            var datalist = $(this).find('.data_druglist [value="' + $drugname + '"]');
            var codedidval = datalist.data("codedid");
            if ((typeof codedidval != "undefined") && codedidval != "" && codedidval != "0") {
				//alert("yes2");
                $vendor = $(this).find('.vendorname').val();
                $equipmenttype = $(this).find('.equipmenttype').val();
				$mrp = parseFloat($(this).find('input[name="s_mrp"]').val());
                $sellingprice = parseFloat($(this).find('input[name="s_sellingprice"]').val());
                $baseprice = parseFloat($(this).find('input[name="s_baseprice"]').val());
				
                if ($vendor === "0" || $.trim($vendor) === "") {
                    alert("Please select vendor."); temp = 0; return false;
                }
				if(choosed_vendor==""){choosed_vendor = $.trim($vendor);}
				if(sessionStorage.getItem("open_order_type")==0){
					if(choosed_vendor != $.trim($vendor)){
						alert("Please choose the same vendor for all item."); temp = 0; return false;
					}					
				}
                if($equipmenttype == "" || parseInt($equipmenttype)<1) {
                    alert("Please select the rent/sale"); temp = 0; return false;
                }
				if($mrp<0.1 || $sellingprice<0.1 || $baseprice<0.1){
					alert("Please fill the mrp,selling price and base price properly."); temp = 0; return false;
				}
				if(parseInt($(this).find('input[name="s_days"]').val())<1 && parseInt($equipmenttype)!=2){
					alert("Please provide days/months/year."); temp = 0; return false;
				}
				if(parseInt($(this).find('input[name="productQuantity"]').val())<1){
					alert("Please provide item quantity."); temp = 0; return false;
				}
				
                //new lineitems structure 
                var lineitem ={
					category:(typeof(datalist.data("category"))!="undefined")?datalist.data("category"):"",
					subcategory_id:(typeof(datalist.data("subcategoryid"))!="undefined")?datalist.data("subcategoryid"):"",
					item_code: codedidval,
					manufacturer:(typeof(datalist.data("brand"))!="undefined")?datalist.data("brand"):"",
					quantity:$(this).find('input[name="productQuantity"]').val(),
					type: $equipmenttype,
					MRP:parseFloat($mrp),
					item_selling_p:parseFloat($sellingprice),
					item_base_p:parseFloat($baseprice),
					gross_amount: parseFloat($(this).find('span[name="mrp"]').html()),
					net_amount: parseFloat($(this).find('span[name="sellingprice"]').html()),
					total_baseprice: parseFloat($(this).find('span[name="baseprice"]').html()),
					s_days:$(this).find('input[name="s_days"]').val(),
					s_month:$(this).find('input[name="s_month"]').val(),
					s_year:$(this).find('input[name="s_year"]').val(),
					wallet_amount:0.00,
					voucher_amount:0.00,
					markup_amount:0.00,
					cli:0.00,					
					roleBasedService:0,
					is_cashless:"",
					invoiceto:"",
                    reportto:"",
                    //payment_code:"0",					
                    corporateinvoiceemail:"",
                    corporatereportemail:"",					
					cartCouponApplied:false,
					orderDiscountApplied:false,
					discountApplied:false,					
					cartDiscountApplied:false,
					coupon_amount:0.00,
					cartDiscountApportionedAmount:0,
					orderApportionedDiscountAmount:0,
					lineItemDiscountAmount:0
				};
				totalpaybleamount = totalpaybleamount + parseFloat(($(this).find('span[name="sellingprice"]').html()));
                                totalbaseamount = totalbaseamount + parseFloat(($(this).find('span[name="baseprice"]').html()));//calculating totalpaybale amount         
				if(typeof(orders[$equipmenttype+"-"+$vendor])!="undefined"){
					orders[$equipmenttype+"-"+$vendor].order_item.push(lineitem);
				}else{
					orders[$equipmenttype+"-"+$vendor]={
						mrn: mrn,
						closedby:closedby,
						address_id: sessionStorage.getItem("address_id"),
						associate_id: $vendor,
						associate_branch_id:"",
						service_type: '11',
						scheduled_date: scheduletimeforordr,
						payment_code: $("#payment_method option:selected").attr("data-number"),
						creation_type: 1,
						application_no: "",
						surge_amount: 1,
						mode_of_service:parseInt($("#service_at").val()),
						report_required: "",
						report_delivery_date: "",
						slot_transaction_id: [],
						order_type:$equipmenttype,
						order_item: [lineitem],
					};
					//console.log(orders);
				}				
			}
        }		
    });
	
	//console.log(orders); return;
	
    //terminating script execution if type or vendor not selected
    if (temp === 0){
		alert("Please fill the required details.");
        return false;
    }

    var loginid = sessionStorage.getItem("loginid");
    var loginname = sessionStorage.getItem("loginname");
    var payment_method = $("#payment_method option:selected").val();
    var contactno = $("#pcontactno").val();
    var alternetcontactno = $("#alcontactno").val();
    if (contactno == "") {
        contactno = sessionStorage.getItem('contactno');
    }
    if (alternetcontactno == "") {
        alternetcontactno = (sessionStorage.getItem('alternetcontactno') == "Array") ? "" : sessionStorage.getItem('alternetcontactno');
    }

	$.each(orders,function(key, val) {
		console.log(val);
		orders_array.push(val);
		console.log(orders_array);
	});
	var order_id="";
	if(sessionStorage.getItem("open_order_type")==0){
		order_id=sessionStorage.getItem('orderid');
	}
    //final array structure for medicine,drugs
    var _data = {
        mrn: mrn,
        channel: 2,
        source_of_referral: $("#l2vsourcereferral option:selected").val(),
        referral_id: referedby,
        created_by_id: loginid,
        created_by_name: loginname,
        referral_mrn: referredmrn,
        orders: orders_array,
		order_id:order_id,
        payment_info: {
            payment_amount: parseFloat(parseFloat(totalpaybleamount).toFixed(2)),
            base_amount:parseFloat(parseFloat(totalbaseamount).toFixed(2)),
            payment_service: payment_method,
            payment_mode: 0,
            payment_reference_id: "",
            wallet_amount: 0.00,
            coupon: "",
            coupon_amount: 0.00,
            voucher_assoc_code: "",
            voucher_code: "",
            voucher_amount: 0.00
        }}; 
	//alert(_data);	
	$("#createorderbox").html(_data);
    console.log(_data);
    //return false;
	if(sessionStorage.getItem("open_order_type")==0){
		_ajaxEventHandler("editEquipmentOrder", _data, cbk_createmeqorder, SHOW_LOADER,"POST");
	}else{
		_ajaxEventHandler("createTransaction", _data, cbk_createmeqorder, SHOW_LOADER,"POST","order.php/v1/");
	}    
}

function cbk_createmeqorder(response) {
    $(".loader").hide();
    //var Obj = JSON.parse(response);
	console.log(response.status);
	if(sessionStorage.getItem("open_order_type")==0){
		if (response.status == "1" || response.status == 1) {
			//pressendsms(Obj.order_id,mobileno);
			alert(response.message);
			sessionStorage.setItem('orderid', "");
			sessionStorage.setItem('orderwid', "");
			sessionStorage.setItem('orderwdid', "");
			$("#l2vreferby").val("");
			var _data = {"orderid": ""}
			sessionStorage.setItem("open_order_type",2);
			// _ajaxEventHandler("open_patient_orders",_data,cbk_open_patient_orders);
			newordertab();
		} else {
			alert(response.message);
		}
	}else{
		if (response.status == "1" || response.status == 1) {
			//pressendsms(Obj.order_id,mobileno);
			alert(response.message+". Transaction code is - "+response.transaction[0]);
			sessionStorage.setItem('orderid', "");
			sessionStorage.setItem('orderwid', "");
			sessionStorage.setItem('orderwdid', "");
			$("#l2vreferby").val("");
			var _data = {"orderid": ""}
			// _ajaxEventHandler("open_patient_orders",_data,cbk_open_patient_orders);
			newordertab();
		} else {
			alert(response.message);
		}
	}    
}

// Action on after choose the Equipment type 
function choose_equipmenttype($this) {
	$rowId = $($this).parents('tr').attr('id');
	$value = $($this).val();	
    if ($value == 0) {
		alert($value);
		$('#' + $rowId).find('input[name="productQuantity"]').prop('disabled', true);
		$('#' + $rowId).find('input[name="s_days"]').prop('disabled', true);
		$('#' + $rowId).find('input[name="s_month"]').prop('disabled', true);
		$('#' + $rowId).find('input[name="s_year"]').prop('disabled', true);
		$('#' + $rowId).find('input[name="s_mrp"]').prop('disabled', true);
		$('#' + $rowId).find('input[name="s_baseprice"]').prop('disabled', true);
		$('#' + $rowId).find('input[name="s_sellingprice"]').prop('disabled', true);
	}else{
		$('#' + $rowId).find('input[name="productQuantity"]').prop('disabled', false);
		$('#' + $rowId).find('input[name="s_mrp"]').prop('disabled', false);
		$('#' + $rowId).find('input[name="s_baseprice"]').prop('disabled', false);
		$('#' + $rowId).find('input[name="s_sellingprice"]').prop('disabled', false);
		if ($value === "1") {			
			$('#' + $rowId).find('input[name="s_days"]').prop('disabled', false);
			$('#' + $rowId).find('input[name="s_month"]').prop('disabled', false);
			$('#' + $rowId).find('input[name="s_year"]').prop('disabled', false);
			
		}else {			
			$('#' + $rowId).find('input[name="s_days"]').prop('disabled', true);
			$('#' + $rowId).find('input[name="s_month"]').prop('disabled', true);
			$('#' + $rowId).find('input[name="s_year"]').prop('disabled', true);			
		}
	} 
}

function reorderfun(orderid,type){
	//0 - pending, 1- completed, 2 - new
	sessionStorage.setItem("open_order_type",type);
	sessionStorage.setItem("is_cart","0");
	var _data = {orderid: orderid};
	$("#l2orderdetailsdiv").css("display", "none");
    $("#l2ordercreatediv").css("display", "block");
    $("#l2vsearch_custom").show();
    $("#l2v_completeorder").removeClass("active");
    $("#l2v_pendingorder").removeClass("active");
    $("#l2v_neworder").addClass("active");
    var data = _ajaxEventHandler("getorderdetails",_data,cbk_open_patient_orders,SHOW_LOADER);
}

function clearAddressData() {
    $('.clearAddressData').val('');
    $('.update_address_btn').text('Save Address');
    $('#selected_address_id').val('');
}










































function checkpricefrommdm() {
    /*var pop=sessionStorage.getItem('facility_id');
     if(pop=="" || pop==0 || pop=="0"){
     alert('Non serviceable area, Please update Address with Proper POP Name.');
     return;
     }*/

    var orderDate = todayDateforMDM();
    var business = "2";
    var source = "CCO";
    var lineitems = [];
    var mrnno = sessionStorage.getItem("mrn");
    //console.log(lineitems);
    //console.log(_data)
    //_ajaxEventHandler("checkpricefrommdm",_data,cbk_checkpricefrommdm,SHOW_LOADER);
}

var showcoupenmmsg = 2;
function cbk_checkpricefrommdm(response) {
    console.log(response);
    var countitem = 0;
    var countinvalidcounpen = 0;
    Obj = JSON.parse(response);
    if (Obj.status == "success") {

        $.each(Obj.lineItemList, function (key, val) {
            console.log(val);
            //alert(val.code);
            //alert($('input[data-codedid*='+val.code+']').attr("id"));
            if (typeof $('input[data-codedid*=' + val.code + ']').attr("id") != "undefined") {
                var splitval = $('input[data-codedid*=' + val.code + ']').attr("id").split("drugsearch");
                if (isNaN(parseInt(splitval[1]))) {
                    var num = "";
                }
                else {
                    var num = parseInt(splitval[1]);
                }
                var dis = parseFloat(val.discountAmount) + ((typeof val.apportionedDiscountAmount != 'undefined') ? parseFloat(val.apportionedDiscountAmount) : 0);
                $("#discountamount" + num).val(dis);
                $("#grossamount" + num).val(val.grossAmount);
                $("#itemmrpval" + num).val(val.unitPrice);
                $("#grossamount" + num).attr("data-mrp", val.unitPrice);
                $("#netamount" + num).val(val.netAmount);
                countitem = countitem + 1;
            }
        });

        if (Obj.addMedicineDeliveryCharges == true && (typeof Obj.medicineDeliveryChargesList != "undefined")) {
            $("#l2vdeliverycharge").html($.trim(Obj.medicineDeliveryCharges));
            $("#medicine_delivery").attr({
                "data-codedid": $.trim(Obj.medicineDeliveryChargesList[0].code),
                "data-item_mrp": $.trim(Obj.medicineDeliveryChargesList[0].unitPrice),
                "data-item_gross": $.trim(Obj.medicineDeliveryChargesList[0].grossAmount),
                "data-item_net": $.trim(Obj.medicineDeliveryChargesList[0].netAmount),
                "data-item_discount": $.trim(Obj.medicineDeliveryChargesList[0].discountAmount),
                "data-ignoreToPartner": $.trim(Obj.medicineDeliveryChargesList[0].ignoreToPartner)
            });
            $("#medicine_delivery").val("1");
        } else {
            $("#l2vdeliverycharge").html("0");
            $("#medicine_delivery").val("0");
            $("#medicine_delivery").attr({
                "data-id": "",
                "data-codedid": "",
                "data-item_mrp": 0,
                "data-item_gross": 0,
                "data-item_net": 0,
                "data-item_discount": 0,
                "data-ignoreToPartner": ""
            });
        }
    }

    var totalamt = parseFloat(Obj.netAmount).toFixed(2);
    $("#l2vitemtotalamount").html(parseFloat(totalamt).toFixed(2));
    $("#l2vitemtotalamountgross").html(parseFloat(Obj.grossAmount).toFixed(2));
    $("#l2vitemtotalamountdiscount").html((parseFloat(Obj.discountAmount) + parseFloat(Obj.cartDiscountAmount)).toFixed(2));
    $(".loader").hide();
}


function choose_vendor($this) {
	$rowId = $($this).parents('tr').attr('id');
    var vendorvalue =$('#'+$rowId).find('select[name="selectvendor"]').val();
    // alert(vendorvalue);
	if(vendor!=vendorvalue && sessionStorage.getItem("open_order_type")==0){
		alert("Please choose the same vendor for all items. because this is rejected order.");
		//$('#'+$rowId).find('select[name="selectvendor"] option[value=0]').prop('selected', true);
		//$("#selectvendor"+idvalue+" option[value='0']").prop('selected', true);
		//$().find('option:selected').text();
	}
    // alert(vendorname);
}


/*
function calculateGST(gstvalue) {
    var price = $('#sellingprice').val();
    var amount = price * 1;
    var tot_price = amount + (amount * gstvalue);
    $('#sellingprice1').val(tot_price);
    $('#gst').val(gstvalue);

}

function getOrderStatus(orderstatus) {
    if (orderstatus === "0" || orderstatus === 0) {
        return "Unassigned";
    } else if (orderstatus === "1" || orderstatus === 1) {
        return "Assigned";
    } else if (orderstatus === "2" || orderstatus === 2) {
        return "Accepted";
    } else if (orderstatus === "3" || orderstatus === 3) {
        return "Started";
    } else if (orderstatus === "4" || orderstatus === 4) {
        return "Reached";
    } else if (orderstatus === "5" || orderstatus === 5) {
        return "In Progress";
    } else if (orderstatus === "6" || orderstatus === 6) {
        return "Completed";
    } else if (orderstatus === "7" || orderstatus === 7) {
        return "Rescheduled";
    } else if (orderstatus === "9" || orderstatus === 9) {
        return "Rejected";
    } else if (orderstatus === "10" || orderstatus === 10) {
        return "Reallocation";
    } else if (orderstatus === "13" || orderstatus === 13) {
        return "Item Packed";
    } else if (orderstatus === "14" || orderstatus === 14) {
        return "Assigned to L2 Pharmacists";
    } else if (orderstatus === "15" || orderstatus === 15) {
        return "Request for Cancellation";
    } else if (orderstatus === "16" || orderstatus === 16) {
        return "Request for Reschedule";
    } else if (orderstatus === "17" || orderstatus === 17) {
        return "Draft";
    }
}*/

function createOrder_old() {
    var referedby = "";
    var sourceofreferral = "";
    var referredmrn = "";
	// validate the address
    if ($("#address1").val() == "") {
        alert('Please enter address'); return;
    }
    // validate the reffer by
    if ($("#l2vreferby").val() == "") {
        alert('Please enter referred by, if no referred by is there please enter 9999.'); return;
    } else {
        referedby = $("#l2vreferby").val();
        if ($("#referedbylist option[value='" + referedby + "']").length > 0 || referedby == "9999") {
        } else {
            alert('Invalid officer id.'); return;
        }
    }
	// validate the closedby by
    if ($("#l2vclosedby").val() == "") {
        alert('Please enter closed by, if no closed by is there please enter 9999.'); return;
    } else {
        closedby = $("#l2vclosedby").val();
        if ($("#closedbylist option[value='" + closedby + "']").length > 0 || closedby == "9999") {
        } else {
            alert('Invalid officer id.'); return;
        }
    }
	// validate the source of referal
    if ($("#l2vsourcereferral option:selected").val() == "") {
        alert('Please select source.'); return;
    } else {
        sourceofreferral = $("#l2vsourcereferral option:selected").val();
    }

    referredmrn = $("#l2vsreferbymrn").val();
    // for postal code
    if ($("#postal_code").val() == "" || $("#postal_code").val() == 0 || $("#postal_code").val() == "0") {
        alert('Please enter postal code');
        return;
    }

    // for check test is available or not
   /* var countitm = 0;
    var countitmempty = 0;
    $("input[name=drugsearch]").each(function () {
        if ($.trim($(this).val()) == "") {
            countitm = countitm + 1;
        }
        countitmempty = countitmempty + 1;
    });
    if (countitm == countitmempty) {
        alert("Please enter test name");
        return;
    }
    if ($.trim($("#vendorname").val()) === "s_days") {
        alert("Please enter days");
        return;
    }

    var drugnum = $('input[id^="drugsearch"]:last');
    if (isNaN(parseInt(drugnum.prop("id").match(/\d+/g), 10))) {
        var num = 1;
    }
    else {
        var num = parseInt(drugnum.prop("id").match(/\d+/g), 10);
    }
    */
    var totalpaybleamount = 0.00;
    var lineitems = [];
    var orders_array = [];
    var deliveryarray = [];
    var temp = 1;
    $(".rowdrug").each(function () {
        $drugname = $(this).find('.drugsearch').val();
        if ($.trim($drugname) != "") {
            var datalist = $(this).find('.data_druglist [value="' + $drugname + '"]');
            var codedidval = datalist.data("codedid");
            if ((typeof codedidval != "undefined") && codedidval != "" && codedidval != "0") {
                $vendor = $(this).find('.vendorname').val();
                $equipmenttype = $(this).find('.equipmenttype').val();
                if ($vendor === "0" || $.trim($vendor) === "") {
                    alert("Please select vendor.");
                    temp = 0;
                    return;
                }
                if($equipmenttype == "") {
                    alert("Please select the rent/sale");
                    temp = 0;
                    return;
                }
                $mrp = $(this).find('input[name="s_mrp"]').val();
                $sellingprice = $(this).find('input[name="s_sellingprice"]').val();
                var grossamount = parseFloat($mrp).toFixed(2);
                var netamount = parseFloat($sellingprice).toFixed(2);
                grossamount = grossamount ? grossamount : 0.00;
                netamount = netamount ? netamount : 0.00;
                //new lineitems structure 
                lineitems.push({
                    category: "",
                    subcategory_id: "",
                    item_code: codedidval,
                    type: $equipmenttype, //getting equipmenttype of lineitem
                    equipment_vendorid: $vendor, //getting vendorid of lineitem
                    gross_amount: grossamount,
                    net_amount: netamount,
                    wallet_amount: "0.00",
                    voucher_amount: "0.00",
                    markup_amount: "0.00",
                    cli_amount: "0.00",
                    is_cashless: "",
                    coupon_amount: "0.00"
                });

            }
        }
    });
    //terminating script execution if type or vendor not selected
    if (temp === 0){
        return false;
    }
    //looping lineitems for calculating total amount
    $.each(lineitems, function (key, val) {
        totalpaybleamount = parseFloat(totalpaybleamount) + parseFloat(val.net_amount);//calculating totalpaybale amount         
        totalbaseamount = parseFloat(totalpaybleamount) + parseFloat(val.net_amount);//calculating totalpaybale amount         
    });

    var loginid = sessionStorage.getItem("loginid");
    var loginname = sessionStorage.getItem("loginname");
    var payment_method = $("#payment_method option:selected").val();
    var contactno = $("#pcontactno").val();
    var alternetcontactno = $("#alcontactno").val();
    if (contactno == "") {
        contactno = sessionStorage.getItem('contactno');
    }
    if (alternetcontactno == "") {
        alternetcontactno = (sessionStorage.getItem('alternetcontactno') == "Array") ? "" : sessionStorage.getItem('alternetcontactno');
    }
    //getting current date
    var estdate = $("#mainorderdate").val();
    var date2 = estdate.split(" ");
    var date3 = date2[0].split("-");
    var d1 = date3[0] + "-" + date3[1] + "-" + date3[2];
    var d = new Date(d1);
    var scheduledslot = $("#scheduledslot option:selected").val();
    if (scheduledslot == "00:00:00") {
        alert("Please select time slot.");
        return;
    }
    var month = d.getMonth() + 1;
    month = month < 10 ? '0' + month : month;
    var day = d.getDate();
    day = day < 10 ? '0' + day : day;
    //var scheduletimeforordr=(d.getFullYear()+"-"+month+"-"+day+"T"+scheduledslot+".000Z");
    var scheduletimeforordr = (d.getFullYear() + "-" + month + "-" + day + " " + scheduledslot);

    //creating new order strcture for medicine,drug
    var mrn = sessionStorage.getItem('patientmrn');

    //orders  array structure
    orders_array.push({
        mrn: mrn,
        address_id: "1234",
        associate_id: "123ABCD",
        associate_branch_id: "1234",
        service_type: '11',
        scheduled_date: scheduletimeforordr,
        payment_code: "4",
        prescription: "",
        creation_type: 1,
        application_no: "",
        surge_amount: 1,
        mode_of_service: 1,
        report_required: "",
        report_delivery_date: "",
        slot_transaction_id: [],
        order_item: lineitems,
    });

    //final array structure for medicine,drugs
    var _data = {
        mrn: mrn,
        channel: 2,
        source_of_referral: sourceofreferral,
        referral_id: referedby,
        created_by_id: loginid,
        created_by_name: loginname,
        referral_mrn: referredmrn,
        orders: orders_array,
        payment_info: {
            payment_amount: parseFloat(parseFloat(totalpaybleamount).toFixed(2)),
            payment_service: "",
            source_type: "",
            payment_mode: payment_method,
            payment_reference_id: "",
            wallet_amount: "0.00",
            coupon: "",
            coupon_amount: "0.00",
            voucher_assoc_code: "",
            voucher_code: "",
            voucher_amount: "0.00"
        }};
    console.log(_data);
    //return false;
    _ajaxEventHandler("createTransaction", _data, cbk_createmeqorder, SHOW_LOADER,"POST","order.php/v1/");
}

function cbk_createmeqorder1(response) {
    $(".loader").hide();
    var Obj = JSON.parse(response);
    if (Obj.status == "1") {
        //pressendsms(Obj.order_id,mobileno);
        alert(Obj.message);
        sessionStorage.setItem('orderid', "");
        sessionStorage.setItem('orderwid', "");
        sessionStorage.setItem('orderwdid', "");
        $("#l2vreferby").val("");
        var _data = {"orderid": ""}
        // _ajaxEventHandler("open_patient_orders",_data,cbk_open_patient_orders);
        newordertab();
    } else {
        alert(Obj.message);
    }
}

function newordertab() {
    $("#vendorname").val("0");
    /*sessionStorage.setItem('orderid', "");
    sessionStorage.setItem('orderwid', "");
    sessionStorage.setItem('orderwdid', "");
    sessionStorage.setItem("encounterid", "");
    sessionStorage.setItem("orderstatuscurorder", "");
    $("#l2vreferby").val("");
    var _data = {"orderid": ""}
    //_ajaxEventHandler("open_patient_orders",_data,cbk_open_patient_orders);
    cbk_open_patient_orders("");*/
	//sessionStorage.setItem("is_cart","1");	//_ajaxEventHandler("getItemsFormCart",{"mrn":sessionStorage.getItem("patientmrn"),"businessId":"11"},cbk_open_patient_orders);
	cbk_open_patient_orders("");
	sessionStorage.setItem("open_order_type",2);
    $("#l2orderdetailsdiv").css("display", "none");
    $("#l2ordercreatediv").css("display", "block");
    $("#l2vsearch_custom").show();
    $("#l2v_completeorder").removeClass("active");
    $("#l2v_pendingorder").removeClass("active");
    $("#l2v_neworder").addClass("active");

}

function l2vpendingorder(){
    $("#l2edit").hide();
    var orderstatus_notrequired = [6,8,17];
	var NotInActionON = ["orderStatus"];
	var dateFilter = "created_date";
	var sortBy = "DESC";
    var _data = {mrn: sessionStorage.getItem('patientmrn'),businessId:["11"],orderStatus:orderstatus_notrequired,NotInActionON:NotInActionON,dateFilter:dateFilter,sortBy:sortBy};
    _ajaxEventHandler("orders", _data, cbk_pendingorder, SHOW_LOADER,"POST","operation.php/v1/");
    showcoupenmmsg = 2;
}

function l2vcompleteorder(){
	$("#l2edit").hide();
    var orderstatus = [6];
	var dateFilter = "created_date";
	var sortBy = "DESC";
    var _data = {mrn:sessionStorage.getItem('patientmrn'),businessId:["11"],orderStatus:orderstatus,dateFilter:dateFilter,sortBy:sortBy};
    _ajaxEventHandler("orders", _data, cbk_completedorder, SHOW_LOADER,"POST","operation.php/v1/");
    showcoupenmmsg = 2;
}

function l2vopenthecart() {
	$("#l2edit").hide();
    var _data = {mrn:sessionStorage.getItem('patientmrn'),businessId:"11"};
    //_ajaxEventHandler("getItemsFormCart", _data, cbk_openthecart, SHOW_LOADER);
	cbk_open_patient_orders("");
    showcoupenmmsg = 2;
}
function cbk_pendingorder(response){
	//renderpendingorder(response);
	if(response.status==1){
		render_order_basedonmrn(response,"pending");
		$("#l2v_pendingorder").addClass("active");
		$("#l2v_neworder").removeClass("active");
		$("#l2v_completeorder").removeClass("active");
		$("#l2v_openthecart").removeClass("active");
	}else{
		alert("There are no Pending orders.");
	}	
    $(".loader").hide();
}
function cbk_completedorder(response){
    //rendercompletedorder(response);
	if(response.status==1){
		render_order_basedonmrn(response,"completed");
		$("#l2v_completeorder").addClass("active");
		$("#l2v_neworder").removeClass("active");
		$("#l2v_pendingorder").removeClass("active");
		$("#l2v_openthecart").removeClass("active");
	}else{
		alert("There are no Completed orders.");
	}
    $(".loader").hide();
}

function cbk_openthecart(response){
    //rendercompletedorder(response);
	if(response.status==1){
		render_order_basedonmrn(response,"cart");
		$("#l2v_openthecart").addClass("active");
		$("#l2v_completeorder").removeClass("active");
		$("#l2v_neworder").removeClass("active");
		$("#l2v_pendingorder").removeClass("active");
	}
    $(".loader").hide();
}

//function callallorder(){
function get_allorder() {
    dashboard_widgets_render();
    dashboard_search_render();
    $("#fromdate").val(todayDate());
    $("#todate").val(todayDate());
    $('#l2search').attr('onclick', 'callallorder1()');
    var formdate = $("#fromdate").val();
    var todate = $("#todate").val();
    var city = $("#city").val();
    var status = $("#status_serach").val();
    var _data = {city: city, formdate: formdate, todate: todate, status: status};
    //_ajaxEventHandler("all_orders",_data,allordersview,SHOW_LOADER);
}

function allOrders(ajaxMethod, SuccessFn, withSearch, skip, pagination) {
    withSearch = withSearch || false;
    ajaxMethod = ajaxMethod || false;
    pagination = pagination || false;
    skip = skip || '1';
    sessionStorage.setItem("ajaxMethod", ajaxMethod);
    sessionStorage.setItem("SuccessFn", SuccessFn);
    sessionStorage.setItem("withSearch", withSearch);
    sessionStorage.setItem("pagination", pagination);
    sessionStorage.setItem("skip", skip);
    var searchFn = 'allOrders("' + ajaxMethod + '","' + SuccessFn + '",' + true + ',1,' + pagination + ')';
    if (withSearch === false) {
        //renderCustomSearch();
        dashboard_search_render();
        $("#fromdate").val(todayDate());
        $("#todate").val(todayDate());
        if (ajaxMethod == 'all_orders') {
            getwidgetCount();
        }
    }
    $('#l2search').attr('onclick', searchFn);
    var formdate = $("#fromdate").val();
    var todate = $("#todate").val();
    var city = $("#city").val();
    var status = $("#status_serach").val();
    var orderidser = $("#orderid_search").val();

    if (new Date(formdate) > new Date(todate)) {
        alert("Todate greater than  Form Date");
        return false;
    }
    var _data = {city: city, formdate: formdate, todate: todate, status: status};

    if ((ajaxMethod == 'rx_not_upload')) {
        $("#todate").attr("disabled", "disabled");
        $("#fromdate").attr("disabled", "disabled");
        $("#status_serach").attr("disabled", "disabled");
        var _data = {city: city};
    }

    if (ajaxMethod == 'reminder_request') {
        $("#status_serach").attr("disabled", "disabled");
        $("#city").attr("disabled", "disabled");
        _data = {};
    }
    _data.customsearch = false;
    if (withSearch === true) {
        _data.orderidser = orderidser;
        if (ajaxMethod == 'rx_not_upload') {
            var _data = {city: city, orderidser: orderidser};
        }

        if (ajaxMethod == 'reminder_request') {
            var _data = {formdate: formdate, todate: todate};
        }

        _data.customsearch = true;
    }
    //_data.pagination = false;
    _data.pagination = true;
    _data.skip = skip;
    _data.limit = 10;
    console.log(SuccessFn);
    //SuccessFn = window[SuccessFn];
    //_ajaxEventHandler(ajaxMethod, _data, SuccessFn, SHOW_LOADER);
    _customeDataTable(_data, ajaxMethod, SuccessFn, SHOW_LOADER)
}

function _customeDataTable(_data, ajaxMethod, SuccessFn, showLoader) {
    showLoader = showLoader || 1;
    if (showLoader == '1') {
        $(".loader").show();
    }
    _data.method = ajaxMethod;
    _data.type = "equipment";
    var url = sessionStorage.getItem("base_url") + 'OMS/api/medicine_supply.php/v1/getMedOrdersByFilter';
    $("#Custom_body").customeDataTable({
        data: _data,
        orderby: 0,
        actionurl: url,
        actiontype: "POST",
        tableprepare: SuccessFn,
        pagination: _data.pagination,
        perpage: _data.limit,
        search: false,
        customsearch: _data.customsearch,
        skip: _data.skip
    });
    $(".loader").hide();
}

//single order  view 
function vieworder(order_id) {
    var _data = {orderid: order_id};
    var data = _ajaxEventHandler("getorderdetails", _data, showorderview, SHOW_LOADER);
    //console.log(data);
}

function trackOrder(orderid) {
    if (orderid == "") {
        alert("Please Select the Correct Order.")
    } else {
        var _data = {order_id: orderid};
        _ajaxEventHandler('ordertrack', _data, trackOrderView, SHOW_LOADER,"POST","operation.php/v1/");
    }
}

function showaddress(){
	$("#l2edit").toggle();
}


function openDetails(contentId, orderId, itemCode) {
	
    orderId = orderId || false;
    itemCode = itemCode || false;
    $('.hideAllDetails').hide();
    $('.removeActive').removeClass('active');
    $('.innerModal').addClass("active");
    $('#innerModal').addClass('active in');
    if (orderId !== false) {
        $('#log_omorder_id').val(orderId);
        $('#log_item_id').val(itemCode);
    }
    $('#' + contentId).show();
}

function hideAllDetails() {
    $('.hideAllDetails').hide();
}

function orderlogsubmit() {
    var omorder_id = $('#log_omorder_id').val();
    var item_ids = $('#log_item_id').val();
    var logreasons = $('#orderlogreasons').val();
    var role = 'L2Equipment';
    if ($.trim(logreasons) == '') {
        alert('Kindly fill Log info!');
        //return false;
    } else {
        var vendorid = sessionStorage.getItem('loginid');
        var vendorname = sessionStorage.getItem('loginname');
        var _data = {omorder_id: omorder_id, item_ids: item_ids, rejectreasons: logreasons, vendorid: vendorid, vendorname: vendorname, role: role};
        //console.log(_data); return false;
        _ajaxEventHandler("create_log", _data, logorderhide, SHOW_LOADER);
    }
}

function logorderhide() {
    alert('Log submitted successfully.');
    $('.hideAllDetails').hide();
    $('.removeActive').removeClass('active');
    $('.veiwOrderDetails').addClass("active");
    $('#veiwOrderDetails').addClass('active in');
	$(".loader").hide();
}
/*function findofferid(){
	if($(".referedbylist").val().length>3 && $(".referedbylist").val()!="9999" ){
		if($.trim($(".referedbylist").val().toLowerCase()).substr(0, 2)=="vi"){
			return;
		}
		_data={id:$(".referedbylist").val()}
		_ajaxEventHandler("referbylist",_data,cbk_referbylist);
	}else{
		var str="<option value='9999'>9999</option>";
		$("#referedbylist").html(str);
	}
}*/
/*
function findofferidforclosed(){
    if($(".referedbylist").val().length>3 && $(".referedbylist").val()!="9999" ){
		if($.trim($(".referedbylist").val().toLowerCase()).substr(0, 2)=="vi"){
			return;
		}
		_data={id:$(".referedbylist").val()}
		_ajaxEventHandler("referbylist",_data,cbk_referbylist);
	}else{
		var str="<option value='9999'>9999</option>";
		$("#referedbylist").html(str);
	}
}*/




