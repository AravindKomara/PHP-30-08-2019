/*function renderMenu(action){ 
	var htmlBanner="";
	htmlBanner =  "<article class='patient_details'>"	+
	"<div class='col-md-1 mp'>" 				+
	"<a href='#' class='back_btn'>Back</a>"	+
	"</div>"									+
	"<div class='col-md-4'><h1>Patient Dashboard</h1></div>"					+
	"</article>";	
	$("#pharma_menu").html(htmlBanner);
}*/

//function pharma_widgets(){
function render_actiontab_for_mrn(){
	var htmlBanner="<div class='col-md-12' style='margin-top:8px;'><button class='new_order' id='l2v_pendingorder' onclick='l2vpendingorder();'> Pending Order </button> <button class='new_order active' id='l2v_neworder'  onclick='newordertab();'> New Order </button><button class='new_order' id='l2v_completeorder' onclick='l2vcompleteorder();'> Completed Order </button><button class='new_order pull-right' style='color: white; background : #81b354;' id='previousPage' onclick='hidecbk();'> Back </button></div>";	
	$("#pharma_widgets").html(htmlBanner);	
}

function dashboard_send_header(){
	return "";
}
//function renderWidgets(counts){
function dashboard_widgets_render(counts) {
    counts = counts || '';
    var htmlBanner = "";
    htmlBanner = "<div class='container-fluid custom_pop_rx'><ul class='nav nav-tabs cust_nav'>" +
            "<li class='active'>" +
            "<a onclick=allOrders('all_orders','allordersview',false,1,true); aria-controls='profile' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-shopping-cart ' aria-hidden='true'></i>" +
            "All Orders (<span id='allorderscount'>0</span>)" +
            "</a>" +
            "</li>" +
            "<li role='presentation' >" +
            "<a onclick=allOrders('assignvendororders','allordersview',false,1,true); aria-controls='profile' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-print' aria-hidden='true'></i>" +
            "Assigned to Vendor (<span id='assignvendorcount'>0</span>)" +
            "</a>" +
            "</li>" +
            "<li role='presentation'>" +
            "<a onclick=allOrders('rejected','allordersview',false,1,true); aria-controls='profile' role='tab' data-toggle='tab'>" +
            "<i class='fa fa-print' aria-hidden='true'></i>" +
            "Rejected Orders (<span id='rejectedcount'>0</span>)" +
            "</a>" +
            "</li>" +
            "<li role='presentation'>" +
            "<div class='input-group' style='max-width:266px;'>" +
            "<select class='form-control' id='patientsearchtype' style='width:90px; background:#569D98; color:#fff;'>" +
            "<option value='mrn'>MRN</option>" +
            "<option value='mobile'>Mobile no</option>" +
            "<select>" +
            "<input type='number' class='form-control' id='patientsearchvalue' placeholder='Enter Number' style='width:125px;'>" +
            "<span class='input-group-addon' onclick='open_patient_details();' id='basic-addon2' style='width:50px; background:#569D98; color:#fff;'>Go</span>" +
            "<!--input type='number' class='form-control' id='new_ordermrn' placeholder='enter mrn'>" +
            "<span class='input-group-addon' onclick='new_ordermrn();' style='background:#569D98; color:#fff;' id='basic-addon2'>New Order</span-->" +
            "</div>" +
            "<!--input type='text' class='form-control' style='width:120px; color:#000;' placeholder='Enter mrn'>" +
            "<button class='btn btn-success' style='width:90px;' onclick='allOrders('rx_not_upload','allordersview',false,1,true);'> New Order </button-->" +
            "</li>" +
            "</ul></div>";
    $("#pharma_widgets").html(htmlBanner);
}

function dashboard_search_render(condition) {
    condition = condition || '';
    var htmlBanner = "";
    htmlBanner =
		"<div class='container-fluid'>" +
		"<section class='custom_search'>" +
		"<article class='col-md-12 col-sm-12 col-xs-12'>" +
		"<div class='col-md-2 col-sm-6 col-xs-12 mp'>" +
		"<div class='form-group'>" +
		"<label>From Date :</label>" +
		"<div class='input-group' class='datepicker'>" +
		"<input type='text' id='fromdate' class='form-control datepicker' placeholder='DD/MM/YYYY'>" +
		"<span class='datepicker'>" +
		"<span class='glyphicon glyphicon-calendar cust_cal'></span>" +
		"</span>" +
		"</div>" +
		"</div>" +
		"</div>" +
		"<div class='col-md-2 col-sm-1 col-xs-12 mp'>" +
		"<div class='form-group'>" +
		"<label>To Date :</label>" +
		"<div class='input-group' class='datepicker'>" +
		"<input  type='text' id='todate' class='form-control datepicker' placeholder='DD/MM/YYYY'>" +
		"<span class='datepicker'>" +
		"<span class='glyphicon glyphicon-calendar cust_cal'></span>" +
		"</span>" +
		"</div>" +
		"</div>" +
		"</div>" +
		"<div class='col-md-1 col-sm-1 col-xs-12 mp'>" +
		"<div class='form-group'>" +
		"<label>Order Status :</label>" +
		"<select  name='job_name' id='status_serach' class='form-control new-status'>" +
		"<option value=''>--Select--</option>" +
		"<option value='0'>Unassigned</option>" +
		"<option value='1'>Assigned</option>" +
		"<option value='2'>Accepted</option>" +
		"<option value='3'>Started</option>" +
		"<option value='4'>Reached</option>" +
		"<option value='5'>InProgress</option>" +
		"<option value='6'>Completed</option>" +
		"<option value='7'>Rescheduled</option>" +
		"<option value='8'>Cancelled</option>" +
		"<option value='24'>Rejected</option>" +
		"<option value='15'>Request for cancellation</option>" +
		"<option value='16'>Request for reschedule</option>" +
		"<option value='17'>Draft</option>" +
		"<option value='18'>Vendor Requested for Pickup</option>" +
		"<option value='21'>L2 Assigned to Vendor</option>" +
		"</select>" +
		"</div>" +
		"</div>" +
		"<div class='col-md-2 col-sm-6 col-xs-12'>" +
		"<label>Vendor Pharma Name :</label>" +
		"<select id='vendor_serach' name='job_name' class='form-control new-status'>" +
		"<option value='0'>Select Vendor</option>" +
		"<option value='1161'>Mediworld</option>" +
		"<option value='945'>Health mitra</option>" +
		"<option value='2615'>A N Apollo Pharmacy</option>" +
		"<option value='949'>Healthskool Clinic &amp; Pharmacy</option>" +
		"<option value='5564'>New Health Plus</option>" +
		"</select>" +
		"</div>" +
		"<div class='col-md-1 col-sm-6 col-xs-12'>" +
		"<label>Order ID</label>" +
		"<input type='number' style='min-width:120px' min='1' id='orderid_search' name='orderid_search' class='form-control' placeholder='Enter order id.'>" +
		"</div>" +
		"<div class='col-md-1 col-sm-6 col-xs-12'>" +
		"<a id='l2search' class='med_order_srch'>Search</a>" +
		"</div>" +
		"</article>" +
		" </section>" +
		"</div>";
    $("#Custom_search").html(htmlBanner);
    $("#vendor_serach").attr("disabled", "disabled");
    $("#pop_serach").attr("disabled", "disabled");
	$("#backbutton").css("display","none");
	$("#patientBannerInfo").html("");
}

// on direct call
function dashboard_widgets_render_oncall(counts){
	var htmlBanner ="<div class='container-fluid custom_pop_rx'>"+
		"<ul class='nav nav-tabs cust_nav'>"+
			"<li role='presentation'>"+
				"<div class='input-group' class='mrn_number_searchbox' style='max-width:266px;'>"+
					"<select class='form-control' id='patientsearchtype' style='width:90px; background:#569D98; color:#fff;'>"+
						"<option value='mrn'>MRN</option>"+
						"<option value='mobile'>Mobile no</option>"+
					"<select>"+
					"<input type='number' class='form-control' id='patientsearchvalue' placeholder='Enter Number' style='width:125px;'>"+
					"<span class='input-group-addon' onclick='open_patient_details();' id='basic-addon2' style='width:50px; background:#569D98; color:#fff;'>Go</span>"+
				"</div>"+
			"</li>"+
		"</ul>"+
	"</div>";
	$("#pharma_widgets").html(htmlBanner);
}

function allordersview(ordersdetails) {
    if(typeof ordersdetails == 'string'){
    ordersdetails = JSON.parse(ordersdetails);
    }
    htmlBanner = '<section class="container-fluid">' +
		'<article class="main_content">' +
		'<div class="tab-content custom_tab_content">' +
		'<div role="tabpanel" class="tab-pane fade in active" id="mainreplacecontent">' +
		'<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
		'<div class="table-responsive">' +
		'<table id="example"  cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">' +
		'<thead>' +
		'<tr>' +
		'<th>MRN</th>' +
		'<th>Customer Name</th>' +
		'<th>Source Type</th>' +
		'<th>Transaction ID</th>' +
		'<th>Order No.</th>' +
		'<th>Order DID</th>' +
		'<th>Location</th>' +
		'<th>Order Created Date </th>' +
		'<th>Preferred Date/Time </th>' +
		'<th>Scheduled Date/Time </th>' +
		'<th>Type</th>'+
		'<th>Vendor Name</th>' +
		'<th>Order Status</th>' +
		'<th>Payment Type</th>' +
		'<th>Order Details</th>' +
		'<th>Order Track</th>' +
		'</tr>' +
		'</thead>' +
		'<tbody>';
    if(ordersdetails.data.length > 0){
        $.each(ordersdetails.data, function (key, val) {
            //console.log(val.order.orderitem);
            var patientname = val.order.patientinfo.name;
            if(patientname == null){
               patientname = ''; 
            }
			var typeoff="";
            //patientname = patientname.replace("null", "");
			$.each(val.order.orderitem, function (key1, val1) {
				console.log(val1);
				//typeoff = val1.type;
				if(typeof val1.type !== "undefined"){
					if((val1.type ==="1" || val1.type ===1) && typeoff.indexOf("Rent") == -1){
						if(typeoff!="") typeoff+=",";
						typeoff+="Rent";
					}else if((val1.type ==="2" || val1.type ===2) && typeoff.indexOf("Sale") == -1){
						if(typeoff!="") typeoff+=",";
						typeoff+="Sale";
					}
				}
				
			});
            htmlBanner += '<tr>' +
				'<td>' + val.order.patientinfo.mrn + '</td>' +
				'<td>' + patientname + '</td>' +
				'<td>' + ((typeof(val.channel)!="undefined")?channel[val.channel]:"") + '</td>' +
				'<td>' + ((typeof(val.transaction_code)!="undefined")?val.transaction_code:"") + '</td>' +
				'<td>' + val._id + '</td>' +
				'<td>' + val.odid + '</td>' +
				'<td>' + val.order.patientinfo.city + '</td>' +
				'<td>' + val.order.order_status.created_date + '</td>' +
				'<td>' + changedate(val.order.patientinfo.expected_delivery_time) + '</td>';
				if (val.OStatus != 1000 && val.OStatus != 1001 && val.OStatus != 21) {
					htmlBanner += '<td>'+changedate(val.order.patientinfo.scheduled_date)+'</td>';
				} else {
					htmlBanner += '<td>-</td>';
				}
				htmlBanner += '<td>' + typeoff + '</td>' +
				'<td>' + ((typeof (val.order.provider_info) == "undefined") ? "" : ((typeof val.order.provider_info[0].associate_name == "undefined") ? "" : val.order.provider_info[0].associate_name)) + '</td>' +
				'<td>' + ((typeof(val.statusName[0])!="undefined")?val.statusName[0].Nomenclature:"NA") + '</td>' +
				'<td>' + ((typeof (val.order.patientinfo.prepaid) == "undefined") ? "COD" : ((typeof (val.order.patientinfo.prepaid) == 1) ? "" : "PrePaid")) + '</td>' +
				'<td> <a onclick="vieworder(' + val._id + ')" target="_new" class="view">View</a> </td>' +
				'<td><a onclick="trackOrder(' + val._id + ')" class="track_btn">Deliver Track</a></td>' +
				'</tr>'; //href=order_view.php?id='+val._id.value+' 
        });
    }else{
        htmlBanner += '<tr><td colspan=16><p class="text-center">'+ordersdetails.message+'</p></td></tr>';
    }
    htmlBanner += '</tbody>' +
            '</table></div></div>';
    htmlBanner += ' </div>' +
	'</div>' +
	'</div>' +
	' </div>' +
	'</article>' +
	'</section>';
    //$("#Custom_body").html(htmlBanner);
    $("#allorderscount").html(ordersdetails.all_orders);
    $("#assignvendorcount").html(ordersdetails.assignvendororders);
    $("#rejectedcount").html(ordersdetails.rejected);
    $(".loader").hide();
    return htmlBanner;
}

function showorderview(resposne) {
    if (typeof resposne == 'string') {
        ordersdetails = JSON.parse(resposne);
    } else {
        ordersdetails = resposne;
    }
    if (ordersdetails.data.length <= 0) {
        htmlBanner = '<section class="container-fluid"><article class="p_details"><div class="col-md-12 col-sm-12 col-xs-12 mp"><h4 class="text-center">' + ordersdetails.message + '</h4></div></article></section>'
        $("#Custom_body").html(htmlBanner);
        $("#Custom_search").html("");
        $(".loader").hide();
        return;
    }
    
    var ordersdetails = ordersdetails.data;
    var vendordetails = ordersdetails.medivendorinfo;
    var payment_info = (typeof(ordersdetails.payment_info)!="undefined"?ordersdetails.payment_info:"");
    var patientinfo = ordersdetails.order.patientinfo;
    patientinfo.name = patientinfo.name ? patientinfo.name : "NaN";
    patientinfo.mrn = patientinfo.mrn ? patientinfo.mrn : "NaN";
    patientinfo.source_type = patientinfo.source_type ? patientinfo.source_type : "NaN";
    patientinfo.city = patientinfo.city ? patientinfo.city : "NaN";
    patientinfo.expected_delivery_time = patientinfo.expected_delivery_time ? patientinfo.expected_delivery_time : "NaN";
    patientinfo.scheduledate = patientinfo.scheduledate ? patientinfo.scheduledate : "NaN";

    htmlBanner = '<section class="container-fluid">' +
	'<article class="p_details">' +
	'<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
	'<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
	'<h3>Order ID #' + ordersdetails._id + ' | MRN - ' + patientinfo.mrn + '| DID-No. - ' + ordersdetails.odid + '</h3>' +
	' <section class="complete_order_search">' +
	'<article class="col-md-12 col-sm-12 col-xs-12 mobile_mp">' +
	' <div class="col-md-2 col-sm-1 col-xs-12 mp">' +
	'<div class="form-group">' +
	'<label>Customer Name </br>' + patientinfo.name + ' </label>' +
	'<label>Delivery Address</label>' +
	'<small>' + patientinfo.address +'</small>' +
	'</div>' +
	'</div>' +
	'<div class="col-md-1 col-sm-6 col-xs-12 mnp">' +
	'<label>Mobile No. </br>' + patientinfo.contact + ' </label>' +
	'<label>Alternate Mobile No. : </br>' + ((typeof patientinfo.alternetcontactno!="undefined")?patientinfo.alternetcontactno:"") + ' </label>' +
	'<label>Pin Code </br>' + patientinfo.pincode + ' </label>' +
	'</div>' +
	'<div class="col-md-2 col-sm-6 col-xs-12 mnp">' +
	'<label>Preferred Date/Time : </br>' + changedate(patientinfo.expected_delivery_time) + ' </label>' +
	'<label>Scheduled Date/Time : </br>' + changedate(patientinfo.scheduled_date) + ' </label>' +
	'</div>' +
	'<div class="col-md-1 col-sm-6 col-xs-12 mnp">' +
	'<label>Payment Mode </br>' + patientinfo.payment_method + ' </label>';
    if ((typeof ordersdetails.order.prepayment != "undefined") && patientinfo.prepaid == 1) {
        htmlBanner += '<label>Prepaid Amount  &#8377;&nbsp; ' + ordersdetails.order.prepayment.amount.toFixed(2) + ' </label>';
    }
    htmlBanner += '</div>';
    if (ordersdetails.OStatus == 17 || ordersdetails.OStatus == 9 || ordersdetails.OStatus == 24 || ordersdetails.OStatus == 7) {
        htmlBanner += '<div class="col-md-2 col-sm-6 col-xs-12 mnp">' +
                '</div>';
    }
    if (ordersdetails.OStatus == 17 || ordersdetails.OStatus == 9 || ordersdetails.OStatus == 24 || ordersdetails.OStatus == 7) {
        htmlBanner += '<div class="col-md-2 col-sm-1 col-xs-12 mnp">' +
                '<div class="form-group">' +
                '<label>Vendor Name :</label>' +
                '<select name="vendor" id="vendor" class="form-control new-status">';
        var vedcode = (typeof (ordersdetails.order.vendorinfo = "undefined") ? "NA" : ordersdetails.order.vendorinfo.VendorCode);
        $.each(vendordetails, function (key, val) {
            if (val._id == vedcode)
            {
                htmlBanner += '<option value=' + val._id + ' selected>' + val.userinfo.USER_NAME + '</option> ';
            }
            else {
                htmlBanner += '<option value=' + val._id + '>' + val.userinfo.USER_NAME + '</option> ';
            }
        });
        htmlBanner += '</select>' +
                '</div>' +
                '</div>' +
                '<div class="col-md-3 col-sm-6 col-xs-12 mnp text-right group_btns">';
        if (ordersdetails.OStatus == 17 || ordersdetails.OStatus == 9 || ordersdetails.OStatus == 24 || ordersdetails.OStatus == 7 || ordersdetails.OStatus == 0) {
            htmlBanner += '<a class="cancel_order_btn" onclick="cancelorder(' + ordersdetails._id + ')">Cancel Order</a>&nbsp;&nbsp;&nbsp;';
        }
        htmlBanner += '<a class="comp_apply_btn" onclick="assignvendor(' + ordersdetails._id + ')">Assign to Vendor</a>';
        '</div>';
    }
    htmlBanner += '' +
	'</article>' +
	'</section>' +
	'<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
	'<div class="table-responsive">' +
	'<table class="table table-condensed table-bordered table-striped medicine_home_order_table" id="toggleColumn-datatable">' +
	'<thead>' +
	'<tr>' +
	'<th>Product Name</th>' +
	'<th>Brand Name</th>' +
	'<th>Type</th>' +
	'<th>Order Qty</th>' +
	'<th>days</th>' +
	'<th>month</th>' +
	'<th>year</th>' +
	'<th>Item MRP</th>' +
	'<th>Gross Amount</th>' +
	'<th>Base Price</th>' +
	'<th>Selling Price</th>'+
	'<th>Commission</th>' +
	'<th>Comments</th>' +
	'<th>Actions</th>' +
	'<th>Log Info</th>' +
	'<th>Add Log</th>' +
	'</tr>' +
	'</thead>' +
	'<tbody>';
    var order_mrp = 0;
    var order_sellingprice = 0;
    var order_discount = 0;
    var order_comission = 0;
    var order_baseprice = 0;
    var order_gst = 0;
    $.each(ordersdetails.order.orderitem, function (key, val) {
		var manufacturer = (typeof val.manufacturer != "undefined")?val.manufacturer:"";
		var equipmenttype = "";
		if (val.type == 1) {
			equipmenttype = 'Rental';
		}
		if (val.type == 2) {
			equipmenttype = 'Sale';
		}
		var quantity =  (typeof val.quantity != "undefined")?val.quantity:"1";
		var days =  (typeof val.s_days != "undefined")?val.s_days:"0";
		var month =  (typeof val.s_month != "undefined")?val.s_month:"0";
		var year =  (typeof val.s_year != "undefined")?val.s_year:"0";
		var MRP = (typeof val.MRP != "undefined")?val.MRP:"0";
		var gross_amount = (typeof val.gross_amount != "undefined")?val.gross_amount:"0";
		var net_amount = (typeof val.net_amount != "undefined")?val.net_amount:"0";
		var total_baseprice = (typeof val.total_baseprice != "undefined")?val.total_baseprice:((typeof val.baseprice != "undefined")?val.baseprice:"0");
		var commissionAmount = parseFloat(net_amount) - parseFloat(total_baseprice);
        //console.log(val);
        var item_count = ordersdetails.order.orderitem.length;
        if (val.item_status != 8){
			
            /*order_mrp += parseFloat(val.mrp);
            order_sellingprice += parseFloat(val.sellingprice);
            order_discount += parseFloat(val.discountAmount);
            order_comission += parseFloat(val.commissionAmount);
            order_baseprice += parseFloat(val.baseprice);
            order_gst += parseFloat(val.gst);*/
            if (val.item_status == 9) {
                htmlBanner += '<tr style="background-color:orange">' +
				'<td>' + val.itemname + '</td>' +
				'<td>' + manufacturer + '</td>'+
				'<td>' + equipmenttype + '</td>'+
				'<td class="oneliner">' + quantity + ' </td>' +
				'<td>' + days + '</td>' +
				'<td>' + month + '</td>' +
				'<td>' + year + '</td>'+
				'<td>' + MRP + '</td>'+
				'<td>' + gross_amount + '</td>' +
				'<td>' + total_baseprice + '</td>' +
				'<td>' + net_amount + '</td>' +
				'<td>' + commissionAmount + '</td>' +
				'<td><a data-toggle="tooltip" title="' + val.item_reject_reason + '">Reason</a></td>';
                        order_baseprice = order_baseprice + total_baseprice;
                if (item_count > 1) {
					htmlBanner += '<td><button style="background-color: #0008ff;color: #eef5ee;font-weight: bold !important;" onclick=itemcancel("' + val.item_code + '",' + ordersdetails._id + ')>Cancel Item</button></td>';
                }else {
                    htmlBanner += ' <td>N/A</td>';
                }
                /*htmlBanner+='<td><label id="l2vaccept" title="Log details"><a href="#" class="mpt"  onclick="user_log_view(\''+ordersdetails._id+'\',\''+val.item_code+'\')"><i class="fa fa-info cust_check" aria-hidden="true"></i></a></label></td>';*/
                /** changes htmlBanner+= **/
                var box1 = '<td><div class="dropdown"><button class="dropbtn"> <i class="fa fa-info cust_check" aria-hidden="true"></i></button><div class="dropdown-content" style="right:10%;"><table class="table table-bordered table-condensed table-striped table-responsive"><thead><tr><th>Role</th><th>Name</th><th>Log Details</th><th>Date/Time</th></tr></thead><tbody>';
                var testdata = "";
                if (typeof ordersdetails.user_log != "undefined") {
                    $.each(ordersdetails.user_log, function (bkey, bval) {
                        if (bval.item_code == val.item_code) {
                            testdata += '<tr><td>' + bval.role + '</td><td>' + bval.actionbyname + '</td><td>' + bval.log_reason + '</td><td>' + bval.action_date + '</td></tr>';
                        }
                    });
                }

                if (testdata == "") {
                    htmlBanner += '<td colspan="">NA</td>';
                } else {
                    htmlBanner += (box1 + testdata + '</tbody></table></div></div></td>');
                }
				
                htmlBanner += '<td> <a href="#" class="mpt" onclick="openDetails(\'orderLog\',\'' + ordersdetails._id + '\',\'' + val.item_code + '\')" >Add Log</a></td>' +
                        '</tr> ';
            } else {
                htmlBanner += '<tr>' +
				'<td>' + val.itemname + '</td>' +
				'<td>' + manufacturer + '</td>'+
				'<td>' + equipmenttype + '</td>'+
				'<td class="oneliner">' + quantity + '</td>'+
				'<td>' + days + '</td>' +
				'<td>' + month + '</td>' +
				'<td>' + year + '</td>' +
				'<td>' + MRP + '</td>'+
				'<td>' + gross_amount + '</td>' +
				'<td>' + total_baseprice + '</td>' +
				'<td>' + net_amount + '</td>' +
				'<td>' + commissionAmount + '</td>' +
				'<td>N/A</td>' +
				'<td>N/A</td>';
                        
                        order_baseprice = order_baseprice + total_baseprice;
                /** changes htmlBanner+= **/
                var box1 = '<td><div class="dropdown"><button class="dropbtn"> <i class="fa fa-info cust_check" aria-hidden="true"></i></button><div class="dropdown-content" style="right:10%;"><table class="table table-bordered table-condensed table-striped table-responsive"><thead><tr><th>Role</th><th>Name</th><th>Log Details</th><th>Date/Time</th></tr></thead><tbody>';
                var testdata = "";
                if (typeof ordersdetails.user_log != "undefined") {
                    $.each(ordersdetails.user_log, function (bkey, bval) {
                        if (bval.item_code == val.item_code) {
                            testdata += '<tr><td>' + bval.role + '</td><td>' + bval.actionbyname + '</td><td>' + bval.log_reason + '</td><td>' + bval.action_date + '</td></tr>';
                        }
                    });
                }

                if (testdata == "") {
                    htmlBanner += '<td colspan="">NA</td>';
                } else {
                    htmlBanner += (box1 + testdata + '</tbody></table></div></div></td>');
                }
                /** changes **/

                htmlBanner += '<td> <a href="#" class="mpt" onclick="openDetails(\'orderLog\',\'' + ordersdetails._id + '\',\'' + val.item_code + '\')" >Add Log</a></td>' +
                        '</tr> ';
            }
        } else if (val.item_status == "8" && (typeof val.cancelbeforeaccept == "undefined")) {
            //for order cancel
            //item_count++;
			htmlBanner += '<tr style="background:#FFB4B7;">' +
			'<td>' + val.itemname + '</td>' +
			'<td>' + manufacturer + '</td>'+
			'<td>' + equipmenttype + '</td>'+
			'<td>' + val.doctor + '</td>' +
			'<td>' + val.item_mrp + '</td>' +
			'<td class="oneliner">' + quantity + ' </td>' +
			'<td>' + days + '</td>' +
			'<td>' + month + '</td>' +
			'<td>' + year + '</td>' +
			'<td>' + MRP + '</td>'+
			'<td>' + gross_amount + '</td>' +
			'<td>' + total_baseprice + '</td>' +
			'<td>' + net_amount + '</td>' +
			'<td>' + commissionAmount + '</td>' +
			'<td>N/A</td>' +
			'<td>N/A</td>' +
			'<td>N/A</td>';
			htmlBanner += '</tr> ';
        }
    });

    htmlBanner +=
	'</tbody>' +
	'</table>' +
	'</div>';   
	//console.log(payment_info);
	if(payment_info!="" && payment_info!=null){
		console.log(payment_info);
	}
	//console.log((payment_info.gross_amount).toFixed(2));
	//return;
	//var base_amount = (typeof payment_info.base_amount !="undefined")?payment_info.base_amount:0;
	htmlBanner += '<div class="col-md-2 col-sm-12 col-xs-12 text-right view_prec">' +
	'<label>MRP &nbsp; : &nbsp; &#8377; ' + (payment_info.gross_amount).toFixed(2) + '</label>' +
	'<label>Base Price &nbsp; : &nbsp; &#8377;&nbsp; ' + (order_baseprice).toFixed(2) + '</label>' +
	'<label>Selling Price &nbsp; : &nbsp; &#8377;&nbsp; ' + (payment_info.net_amount).toFixed(2) + '</label>' +
	'<label>Discount &nbsp; : &nbsp; &#8377;&nbsp; ' + (payment_info.discount_amount).toFixed(2) + '</label>' +
	'<!--label>GST &nbsp; : &nbsp; &#8377;&nbsp; ' + (payment_info.gross_amount).toFixed(2) + '</label-->' +
	'<label>Commission &nbsp; : &nbsp; &#8377;&nbsp; ' + (payment_info.net_amount - order_baseprice).toFixed(2) + '</label>' +
	'</div>';
    
    htmlBanner += '<div class="col-md-12 col-sm-12 col-xs-12">' + ((typeof patientinfo.reject_reason == "undefined") ? "" : "<b>Reject Reason : </b>" + patientinfo.reject_reason) + '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</article>' +
            '</section>';
    var htmlModals = '<!-- Showing prescption images uplaoding for l2   -->' +
            '<div class="hideAllDetails uploadPrescription" id="uploadPrescription" style="display:none;">' +
            '<h4 class="" style="margin-top: 10px; border:0px;">Prescription </h4>' +
            '<div>' +
            '<form  id="formsum"  method="post" enctype="multipart/form-data">' +
            '<div class="col-md-3"><input type="file" name="pic[]" id ="l2prescptionname" multiple></div>' +
            '<input type="hidden" name="orderid" value='+ordersdetails._id+' id="orderid">' +
            '<div class="col-md-3"><button type="button" class="btn btn-success" onclick="l2prescptionupload()" >Upload</button></div>' +
            '</form>' +
            '</div>' +
            '<div class="clearfix"></div>' +
            '<hr style="margin-bottom: 0px;">' +
            '<div class="">' +
            '<table class="table table-striped" id="tblGrid">' +
            ' <thead id="tblHead">' +
            ' <tr>' +
            '<th>Uploaded Prescription Documents</th>' +
            ' </tr>' +
            '</thead>' +
            '<tbody>';
    if (typeof ordersdetails.order.prescription_images != 'undefined' && (ordersdetails.order.prescription_images).length != 0) {
		var i = 1;
        $.each(ordersdetails.order.prescription_images, function (key, val) {
			
            //$.each(val, function (key, val1){
				var name="Prescription - "+i;
				if(typeof val.filename!="undefined"){
					var name=val.filename;
				}				
                htmlModals += '<tr>' +
				'<td>'+i+'. '+name+' <a target="_blank" href="' + val.fullpath+ '">View</a></td>' +
				'</tr>';
				i = i +1;
            //});
        });
    } else {

        htmlModals += '<tr><td>No Prescription</td></tr>';
    }

    htmlModals += ' </tbody>' +
            '</table>' +
            '</div>' +
            '</div>' +
            '<!-- Showing Order Wise user Log  -->' +
            '<div class="hideAllDetails orderWiseUserLog" id="orderWiseUserLog" style="display:none;">' +
            '<h4 class="">Log Details </h4>' +
            '<div id="userLogbody">' +
            '</div>' +
            '</div>' +
            '<!-- Showing Order Wise Log  -->' +
            '<div class="hideAllDetails orderLog" id="orderLog" style="display:none;">' +
            '<h4 class="" style="border:0px;">Log the Activity..! </h4>' +
            '<div class="">' +
            '<div class="col-md-6">' +
            '<input type="text" id="orderlogreasons" name="orderlogreasons" class="form-control" placeholder="Log Info" required="required" style="padding: 6px 18px; font-weight: 600;">' +
            '<input type="hidden" id="log_omorder_id" name="log_omorder_id">' +
            '<input type="hidden" id="log_item_id" name="log_item_id">' +
            '</div>' +
            '<div class="col-md-2"><button type="button" class="btn btn-success" onclick="orderlogsubmit()">Submit</button></div>' +
            '<div class="clearfix"></div></div>' +
            '</div>' +
            '<!-- Showing prescption images  -->' +
            '<div class="hideAllDetails prescriptionImages" id="prescriptionImages">' +
            '</div>';
    //console.log(htmlModals);

    //$("#Custom_body").html(htmlBanner);
    //alert("working");
    //$("#Custom_search").html("");
    //$("#order_total").html(order_total);
    modelWithTab(htmlBanner, htmlModals);
    //console.log(vendordetails.associate_id);
    setTimeout(function () {    
        //console.log('comming');
		//alert(ordersdetails.order.prescription_images);
		//alert(ordersdetails.order.prescription_images.length);
		if (ordersdetails.OStatus == 1000 || ordersdetails.OStatus == 24 || (ordersdetails.OStatus == 1001 && ordersdetails.order.prescription_images.length > 0)){
			//alert("working");
			var _dataforvendor = {"systemType": "equipment"};
			_ajaxEventHandler("vendor_list", _dataforvendor, cbk_setvendorList);
			$("#vendor").attr('disabled',false);
			$('.comp_apply_btn').show();
		}
		$(".loader").hide(); 
    }, 500);
}

function modelWithTab(htmlBanner, htmlModals) {
    var modelTab = '<ul class="nav nav-tabs orderdetailsView">' +
            '<li class="removeActive nav veiwOrderDetails active"><a data-toggle="tab" onclick="hideAllDetails();" href="#veiwOrderDetails" id="anchor_viewOrderDetails">View Order</a></li>' +
            '<li class="disabled removeActive nav innerModal" ><a>Details</a></li>' +
            '</ul>' +
            '<div class="tab-content">' +
            '<div class="removeActive tab-pane fade veiwOrderDetails in active" id="veiwOrderDetails">' + htmlBanner + '</div>' +
            '<div class="removeActive tab-pane fade" id="innerModal">' + htmlModals + '</div>' +
            '</div>';
    var modelHtml = '<div id="viewOrder" class="modal fade" role="dialog">' +
            '<div class="modal-dialog modal-lg" style="width: 97%">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
            '<h4 class="modal-title">View Order</h4>' +
            '</div>' +
            '<div class="modal-body">' + modelTab + '</div>' +
            '</div>' +
            '</div>' +
            '</div>';
    $(".loader").hide();
    $('#viewCompleteOrder').html(modelHtml);
    $('#viewOrder').modal('show');
}

//function patientsearchlistpage(data){
function patient_search_list(data){
	//$("#custom_search").hide();
	$("#backbutton").css("display","none");
	var htmlBanner="";	
	htmlBanner = "<div class='container-fluid'>"+
		"<section class='custom_search'>"+
			"<article class='col-md-12 col-sm-12 col-xs-12'>"+
				"<div class='col-md-9 col-sm-9 col-xs-12 mp'>"+
					"<h2 style='line-height:28px; font-weight:bold;'>Patient List</h2>"+
				"</div>"+
				"<!--div class='col-md-3 col-sm-3 col-xs-12 mp'>"+
					"<a href='#' class='back_btn' style='margin-top:-3px;'>Back</a>"+
				"</div-->"+
			"</article>"+
		"</section>"+
	"</div>";
	//console.log(data);
	//var patientdetails=JSON.parse(data);
	var patientdetails=data;
	var htmlBanner1='';
	if(patientdetails.status=="1"){
		htmlBanner1='<br><section class="container-fluid">'+
		'<article class="main_content">'+
			'<div class="tab-content custom_tab_content">'+
				'<div role="tabpanel" class="tab-pane fade in active">'+
				   '<div class="col-md-12 col-sm-12 col-xs-12 mp">'+
						'<div class="table-responsive">'+
							'<table id="example1" cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">'+
								'<thead>'+
									'<tr>'+
										'<th style="width:100px;">MRN</th>'+										
										'<th style="width:300px;">Name</th>'+
										'<th style="width:100px;">Contact No</th>'+
										'<th></th>'+
										'<th style="width:100px;">Order</th>'+
									'</tr>'+
								'</thead>'+
								'<tbody>';
								var patientlist = "";
								$.each(patientdetails.data.customerList,function(key,val){
									if(parseInt(val.mrn)!=0){
										patientlist+='<tr>'+
											'<td>'+val.mrn+'</td>'+										
											'<td>'+val.firstName+' '+val.lastName+'</td>'+
											'<td>'+val.mobile+'</td>'+
											'<td></td>'+
											'<td><span class="input-group-addon" onclick="patient_search(\'mrn\',\''+val.mrn+'\',10,1,cbk_open_patient_records);" style="background:#569D98; color:#fff;" id="basic-addon2">New Order</span></td>'+
										'</tr>';
									}
								});								
								htmlBanner1+=patientlist;
								htmlBanner1+='</tbody>'+                               
							'</table>'+
					   '</div>'+
				   ' </div>'+
			   '</div>'+
			   '</div>'+
			'</article>'+			
		'</section>';		
		$("#Custom_search").html(htmlBanner);
		$("#Custom_body").html(htmlBanner1);
	}else{
		console.log(patientdetails.message);
		console.log(patientdetails.data.message);
		alert(patientdetails.data.message);
	}	
	$(".loader").hide();
}

//patientinfo banner
function renderBanner(){
    if (sessionStorage.getItem("iscall") == "no") {
    } else {
        $("#attendbutton").css("display", "none");
        $("#endcallbutton").css("display", "block");
        $("#transfercallbutton").css("display", "block");
    }
    var htmlBanner = "";

     htmlBanner = " <div class='row'><div class='container-fluid'><article class='medicine_home'><div class='col-md-12'><h2>" +sessionStorage.getItem('name')+ "<small> | " + sessionStorage.getItem('patientgender') + " | " + sessionStorage.getItem('age') + " Y | MRN-" +sessionStorage.getItem('patientmrn') + " <span class='mailid'>Mail ID Available</span> <i class='fa fa-tags' aria-hidden='true' title=" + sessionStorage.getItem('TagName') + "></i><br> English | Service Type : Supplies@home <span id='orderfrom'></span></small></h2></div></article></div></div>";
    $("#patientBannerInfo").html(htmlBanner);
    $(".loader").hide();
 
}

function renderBanner1() {
    if (sessionStorage.getItem("iscall") == "no") {
    } else {
        $("#attendbutton").css("display", "none");
        $("#endcallbutton").css("display", "block");
        $("#transfercallbutton").css("display", "block");
    }
    var htmlBanner = "";

    var htmlBanner = " <div class='row'><div class='container-fluid'><article class='medicine_home'><div class='col-md-12'><h2>" + Obj[0].firstName +" "+ Obj[0].lastName+ "<small> | " + setgender(Obj[0].gender) + " | " + Obj[0].Age + " Y | MRN-" + Obj[0].mrn + " <span class='mailid'>Mail ID Available</span> <i class='fa fa-tags' aria-hidden='true' title=" + Obj[0].TagName + "></i><br>" + ((typeof (Obj[0].language) == 'undefined') ? 'English' : Obj[0].language) + " | Service Type : Supplies@home <span id='orderfrom'></span></small></h2></div></article></div></div>";
    $("#patientBannerInfo").html(htmlBanner);
    $(".loader").hide();

}

function renderorderHeader() {
	var orderdate = tommorowDate();
	var htmlBanner = "";
	htmlBanner = "<section class='container-fluid' id='l2vsearch_custom'>" +
	"<section class='complete_order_search' style='background:#ECF8F8; border: 1px #C4C4C4 solid; margin:15px 0px -4px 0px;'>" +
	"<article class='col-md-12 col-sm-12 col-xs-12 mobile_mp'>" +
	"<div class='col-sm-4 col-xs-12 mp' style='margin:4px 0px;'>" +
    "<div class='form-group' style='margin: 0px;'>" +
	"<label style='color:#408DAE;font-weight: bold;display: inline-block;'>Delivery Address</label> &nbsp;" +
    "<label class='' style='cursor:pointer;display: inline-block;background-color:#408DAE; color:#fff; padding-right: 15px;' onclick='showAddressList();' > &nbsp; Change the address<i class='fa fa-pencil-square-o' style='background-color:#408DAE'></i></label>" +
	"<label id='showdelvaddress' style='color:#408DAE'>" + ((sessionStorage.getItem("address") == 'Array') ? '' : ((sessionStorage.getItem("address")) + ", ")) +
	((sessionStorage.getItem("city") == 'Array') ? '' : ((sessionStorage.getItem("city")) + ", ")) +
	((sessionStorage.getItem("state") == 'Array') ? '' : ((sessionStorage.getItem("state")) + ", ")) +
	((sessionStorage.getItem("district") == 'Array') ? '' : ((sessionStorage.getItem("district")) + ", ")) +
	((sessionStorage.getItem("postal_code") == 'Array') ? '' : ((sessionStorage.getItem("postal_code")))) +
	" " + "</label>" +
	"</div>" +
	"</div>" +
	"<!--div class='col-sm-2 col-xs-12 mp'>" +
	"<label style='color:#408DAE'>Pop Name</label>" +
	"<small id='showdelvpop' style='color:#408DAE'>" + ((typeof sessionStorage.getItem("popname") != "undefined") ? sessionStorage.getItem("popname") : sessionStorage.getItem("home_popname")) + "</small>" +
	"</div-->" +
	"<div class='col-md-8 col-sm-8 col-xs-12 mp'>" +
	"<div class='row'>" +
	"<div class='col-md-2 col-sm-2 col-xs-12 mnp'>" +
	"<div class='form-group'>" +
	"<label style='color:#408DAE'>Prefered Date :</label>" +
	"<div class='input-group date datepicker' id='orderdatediv'>" +
	"<input id='mainorderdate' type='text' onchange='settimeslot();' class='form-control'  value='" + orderdate + "' readonly=''>" +
	"<span class='input-group-addon'>" +
	"<i class='fa fa-calendar' aria-hidden='true'></i>" +
	"</span>" +
	"</div>" +
	"</div>" +
	"</div>" +
	"<div class='col-md-2 col-sm-2 col-xs-12 mnp'>" +
	"<div class='form-group'>" +
	"<label style='color:#408DAE'>Prefered Time Slot :</label>" +
	"<select name='job_name'  id='scheduledslot' class='form-control new-status'>" +
	"<option id='wrongslot' value=''>Please choose the slot</option>" +
	"<option id='10amslot' value='14:00:00'>10AM-02PM</option>" +
	"<option id='2pmslot' value='18:00:00'>02PM-06PM</option>" +
	"<option id='6pmslot' value='22:00:00'>06PM-10PM</option>" +
	"</select>" +
	"</div>" +
	"</div>" +           
	"<div class='col-md-2 col-sm-1 col-xs-12 mnp'>" +
	"<label style='color:#408DAE'>Payment Mode :</label>" +
	"<select name='payment_method' id='payment_method' class='form-control new-status'>" +
	"<option data-number='0' value='COD'>Cash</option>"+
	"<!--option value='CARD'>Credit Card</option>"+
	"<option value='DCARD'>Debit Card</option>" +
	"<option value='NETBANKING'>Internet Banking</option>" +
	"<option value='PAYTM'>Paytm</option>" +
	"<option value='PAYUMONEY'>PayUMoney</option>" +
	"<option value='MOBIQUICK'>Mobikquik</option>" +
	"<option value='OXYGEN'>Oxygen</option-->" +
	"</select>"+
	"</div>"+
	"<div class='col-md-2 col-sm-1 col-xs-12 mnp'>" +
	"<label style='color:#408DAE'>Service At :</label>" +
	"<select name='service_at' id='service_at' class='form-control new-status'>" +
	"<option value='1'>Home</option>"+
	"</select>"+
	"</div>"+
	"<!--div class='col-md-2 col-sm-1 col-xs-12 mnp'>" +
	"<label style='color:#408DAE'>Vendor :</label>" +
	"<select name='service_at' id='service_at' class='form-control new-status'>" +
	"<option value='1'>Home</option>"+
	"</select>"+
	"</div-->"+
	"</div>" +
	"</article>" +
	"</section>" +
	"</section>";
    $("#Custom_search").html(htmlBanner);
	$("#backbutton").css("display","none");
	$("#patientBannerInfo").html("");
	settimeslot();
}

function renderCreateOrder(bj) {
	//Dynamic addition/deletion of line item and 
	htmlBanner = "<section class='container-fluid' name='order section'>"+
	"<div class='col-md-12 col-sm-12 col-xs-12 mp'>" +
	"<div class=''>"+
	"<table class='table cust_table_order table-condensed table-bordered table-striped medicine_home_order_table' id='mtable'>"+
	"<thead>"+
	"<tr>"+
	"<th style='width:23%;'>Product Name</th>"+
	"<th style='width:14%;'>Brand Name</th>"+
	"<th style='width:8%;'>Type</th>"+
	"<th style='width:11%;'>Vendor Name</th>"+	
	"<th style='width:65px;'>Order Qty</th>"+                
	"<th style='width:65px;'>Days</th>"+
	"<th style='width:65px;'>Month</th>"+
	"<th style='width:65px;'>Year</th>"+
	"<th style='width:80px;'>MRP</th>"+
	"<th style='width:80px;'>Baseprice</th>"+
	"<th style='width:50px;'>Sellingprice</th>"+	
	"<th>Actions</th>"+
	"</tr>"+
	"</thead>"+
	"<tbody>";
	//var rowdrug=0;
	
	var open_order_flag=sessionStorage.getItem("open_order_flag");
	var equipmenttype=sessionStorage.getItem("equipmenttype");
	//
    if (bj.status==1 || bj.status=="1"){
		var myarray = [];
		if(sessionStorage.getItem("is_cart")=="1"){
			$.each(bj.data, function(key, val){
				//console.log(myarray);
				if(jQuery.inArray(val.serviceId, myarray) > -1){
					return;
				}
				myarray.push(val.serviceId);
				htmlBanner +="<tr class='rowdrug' id='rowdrug-"+rowdrug+"'>"+
				//Search Box code
				"<td>"+
				"<div class='form-group'>"+
				"<div class='input-group input-group-md'>"+
				"<div class='icon-addon'>"+
				"<input type='text' list='druglist-"+rowdrug+"' data-tscode='"+val.serviceId+"' value='"+val.name+"' data-code='' class='form-control drugsearch' id='drugsearch' name='drugsearch' onkeyup='loaddruglist(event,this);' onchange='loadanotherdrug(this);'>"+
				"<datalist id='druglist-"+rowdrug+"' class='data_druglist'>"+				
				"<option value='"+val.name+"' data-codedid='"+val.serviceId+">"+val.name+"</option>"+
				"</datalist>"+
				"</div>" +
				"<span class='input-group-btn'>" +
				"<button class='btn btn-default' type='button'><i class='fa fa-search' aria-hidden='true'></i></button>" +
				"</span>" +
				"</div>" +
				"</div>" +
				"</td>" +
				//Item Manufacture Name
				"<td>" +
				"<div class='form-group'>" +
				"<input type='text' disabled  class='form-control' id='drugbrand' name='drugbrand'>" +
				"</div>" +
				"</td>" +
				//choose the product for rent/sale
				"<td>" +
				"<div class='form-group'>" +
				"<select name='equipmenttype' id='equipmenttype' class='form-control new-status equipmenttype' onchange='choose_equipmenttype(this);'>"+               
				"<option value='0' selected='selected'>Select Type</option>"+
				"<option value='1'>Rent</option>"+
				"<option value='2'>Sale</option>"+
				"</select>"+
				"</div>"+
				"</td>"+
				//Choose the vendor
				"<td>"+
				"<select name='selectvendor' id='selectvendor' class='form-control new-status vendorname' onchange='choose_vendor(this);'>"+
				"<option value='0' selected='selected'>Select Vendor</option>"+
				"</select>"+
				"</td>"+
				//Choose the quantity
				"<td>"+		
				"<input type='number' min='1' class='form-control typestatus'  name='productQuantity' id='productQuantity' onchange='calcaprice(this,\"quantity\");' value='1' disabled='true'>" +
				"</td>"+
				//Choose the days/months/year
				"<td><input type='text'  min='1' max='31' class='form-control typestatus' name='s_days' onchange='calculteDayMonthsYears(\"day\",this);' id='s_days' disabled='true' value='0'></td>" +
				"<td><input  type='text' min='1' max='12' class='form-control typestatus' name='s_month' onchange='calculteDayMonthsYears(\"month\",this);'  id='s_month' disabled='true' value='0'></td>" +               
				"<td><input  type='text' min='1' max='10' class='form-control typestatus' name='s_year' onchange='calculteDayMonthsYears(\"year\",this);' id='s_year' disabled='true' value='0'></td>" +
				//Single line item MRP
				"<td>"+
				"<input type='text' min='1' class='form-control typestatus' name='s_mrp' id='s_mrp' onchange='calcaprice(this,\"mrp\");' value='0' disabled='true'>"+
				"<span id='s_mrp_span' name='mrp' style='margin-top:5px; color:#277C75;'>0.00</span>"+
				"</td>"+
				//Single line item Base Price"+"
				"<td>"+
				"<input type='text' min='1' class='form-control typestatus' name='s_baseprice'  id='s_baseprice' onchange='calcaprice(this,\"baseprice\");' value='0' disabled='true'>"+
				"<span id='s_baseprice_span' name='baseprice' style='margin-top:5px; color:#277C75;'>0.00</span>"+
				"</td>"+
				//Single line item Selling price
				"<td>"+
				"<input type='text' min='1' class='form-control typestatus' name='s_sellingprice' id='s_sellingprice' onchange='calcaprice(this,\"sellingprice\");' value='0' disabled='true'>"+
				"<span id='s_sellingprice_span' name='sellingprice' style='margin-top:5px; color:#277C75;'>0.00</span>"+
				"</td>"+
				"<td>"+
				"<label id='l2vaccept' title='hello'>"+
				"<i class='fa fa-info cust_check' aria-hidden='true'></i>"+
				"</label>"+
				"<label name='l2vcancel' id='l2vcancel' onclick='cancellineitemdiag(this);'>"+
				"<i class='fa fa-times cust_times' aria-hidden='true'></i>"+
				"</label>"+
				"</td>"+
				"</tr>";
				rowdrug = rowdrug + 1;
			});
		}else{
			sessionStorage.setItem("is_cart","0");
			$.each(bj.data.order.orderitem, function(key, val){
				console.log(val);
				htmlBanner +="<tr class='rowdrug' id='rowdrug-"+rowdrug+"'>"+
				//Search Box code
				"<td>"+
				"<div class='form-group'>"+
				"<div class='input-group input-group-md'>"+
				"<div class='icon-addon'>"+
				"<input type='text' list='druglist-"+rowdrug+"' class='form-control drugsearch' id='drugsearch' name='drugsearch' data-code='"+val.item_code+"' onkeyup='loaddruglist(event,this);' onchange='loadanotherdrug(this);' value='"+val.itemname+"'>"+
				"<datalist id='druglist-"+rowdrug+"' class='data_druglist'>"+			
				"<option value='"+val.itemname+"'  data-codedid='"+val.item_code+"'>"+val.itemname+"</option>"+
				"</datalist>"+
				"</div>"+
				"<span class='input-group-btn'>"+
				"<button class='btn btn-default' type='button'><i class='fa fa-search' aria-hidden='true'></i></button>"+
				"</span>"+
				"</div>"+
				"</div>"+
				"</td>"+
				//Item Manufacture Name
				"<td>"+
				"<div class='form-group'>"+
				"<input type='text' disabled  class='form-control' id='drugbrand' name='drugbrand' value='"+val.manufacturer+"'>" +
				"</div>"+
				"</td>"+
				//choose the product for rent/sale
				"<td>"+
				"<div class='form-group'>"+
				"<select name='equipmenttype' id='equipmenttype' class='form-control new-status equipmenttype' onchange='choose_equipmenttype(this);'>";
				typeofEquipement = val.type;
				if(bj.data.OStatus!=6){
					equipmenttype = val.type;
					if(equipmenttype==1){
						htmlBanner +="<option value='1' selected>Rent</option>";
					}else{
						htmlBanner +="<option value='2' selected>Sale</option>";
					}					
				}else{
					open_order_flag=0;
					htmlBanner +="<option value='1' "+((val.type==1)?'selected':'')+">Rent</option>"+
					"<option value='2' "+((val.type==2)?'selected':'')+">Sale</option>";
				}
				htmlBanner +="</select>"+
				"</div>"+
				"</td>"+
				//Choose the vendor
				"<td>";				
				if(typeof(bj.data.order.provider_info)!="undefined" && typeof(bj.data.order.provider_info[0].associate_id)!="undefined"){
					vendor = bj.data.order.provider_info[0].associate_id;
					//htmlBanner +="<select name='selectvendor' id='selectvendor' class='form-control new-status' onchange='choose_vendor(this);'>"+
					//"<option value='"+bj.data.order.provider_info[0].associate_id+"'>"+bj.data.order.provider_info[0].associate_name+"</option>"+
					//"</select>";
				}
				htmlBanner +="<select name='selectvendor' id='selectvendor' class='form-control new-status vendorname' onchange='choose_vendor(this);'></select>";
				htmlBanner +="</td>"+
				//Choose the quantity 
				"<td>"+		
				"<input type='number' min='1' class='form-control typestatus'  name='productQuantity' id='productQuantity' onchange='calcaprice(this,\"quantity\");' value='"+val.quantity+"' disabled='true'>" +
				"</td>"+
				//Choose the days/months/year
				"<td><input type='text'  min='1' max='31' class='form-control typestatus' name='s_days' onchange='calculteDayMonthsYears(\"day\",this);' value='"+val.s_days+"' id='s_days' "+((val.type==2)?'disabled=true':'')+" value='0'></td>" +
				"<td><input  type='text' min='1' max='12' class='form-control typestatus' name='s_month' onchange='calculteDayMonthsYears(\"month\",this);' value='"+val.s_month+"'  id='s_month' "+((val.type==2)?'disabled=true':'')+" value='0'></td>" +               
				"<td><input  type='text' min='1' max='10' class='form-control typestatus' name='s_year' onchange='calculteDayMonthsYears(\"year\",this);' value='"+val.s_year+"' id='s_year' "+((val.type==2)?'disabled=true':'')+" value='0'></td>" +
				//Single line item MRP
				"<td>"+
				"<input type='text' min='1' class='form-control typestatus' name='s_mrp' id='s_mrp' onchange='calcaprice(this,\"mrp\");' value='"+val.MRP+"'>"+
				"<span id='s_mrp_span' name='mrp' style='margin-top:5px; color:#277C75;'>"+val.gross_amount+"</span>"+
				"</td>"+
				//Single line item Base Price"+"
				"<td>"+
				"<input type='text' min='1' class='form-control typestatus' name='s_baseprice' id='s_baseprice' onchange='calcaprice(this,\"baseprice\");' value='"+val.item_base_p+"'>"+
				"<span id='s_baseprice_span' name='baseprice' style='margin-top:5px; color:#277C75;'>"+val.total_baseprice+"</span>"+
				"</td>"+
				//Single line item Selling price
				"<td>"+
				"<input type='text' min='1' class='form-control typestatus' name='s_sellingprice' id='s_sellingprice' onchange='calcaprice(this,\"sellingprice\");' value='"+val.item_selling_p+"'>"+
				"<span id='s_sellingprice_span' name='sellingprice' style='margin-top:5px; color:#277C75;'>"+val.net_amount+"</span>"+
				"</td>"+
				"<td>"+
				"<label id='l2vaccept' title='hello'>"+
				"<i class='fa fa-info cust_check' aria-hidden='true'></i>"+
				"</label>"+
				"<label name='l2vcancel' id='l2vcancel' onclick='cancellineitemdiag(this);'>"+
				"<i class='fa fa-times cust_times' aria-hidden='true'></i>"+
				"</label>"+
				"</td>"+
				"</tr>";
				rowdrug = rowdrug + 1;				
			});
		}
	}
	htmlBanner +="<tr class='rowdrug' id='rowdrug-"+rowdrug+"'>"+
	//Search Box code
	"<td>"+
	"<div class='form-group'>"+
	"<div class='input-group input-group-md'>"+
	"<div class='icon-addon'>"+
	"<input type='text' list='druglist-"+rowdrug+"'  class='form-control drugsearch' id='drugsearch' name='drugsearch' onkeyup='loaddruglist(event,this);' onchange='loadanotherdrug(this);'>"+
	"<datalist id='druglist-"+rowdrug+"' class='data_druglist'></datalist>"+
	"</div>" +
	"<span class='input-group-btn'>" +
	"<button class='btn btn-default' type='button'><i class='fa fa-search' aria-hidden='true'></i></button>" +
	"</span>" +
	"</div>" +
	"</div>" +
	"</td>" +
	//Item Manufacture Name
	"<td>" +
	"<div class='form-group'>" +
	"<input type='text' disabled  class='form-control' id='drugbrand' name='drugbrand'>" +
	"</div>" +
	"</td>" +
	//choose the product for rent/sale
	"<td>" +
	"<div class='form-group'>"+
	"<select name='equipmenttype' id='equipmenttype' class='form-control new-status equipmenttype' onchange='choose_equipmenttype(this);'><option value='0' selected='selected'>Select Type</option>";
	if(sessionStorage.getItem("open_order_type")==0){
		if(typeofEquipement==1){
			htmlBanner +="<option value='1'>Rent</option>";
		}else{
			htmlBanner +="<option value='2'>Sale</option>";
		}
	}else{
		htmlBanner +="<option value='1'>Rent</option><option value='2'>Sale</option>";
	}
	htmlBanner +="</select>"+
	"</div>"+
	"</td>"+
	//Choose the vendor
	"<td>"+
	"<select name='selectvendor' id='selectvendor' class='form-control new-status vendorname' onchange='choose_vendor(this);'>"+
	"<option value='0' selected='selected'>Select Vendor</option>"+
	"</select>"+
	"</td>"+
	//Choose the quantity
	"<td>"+		
	"<input type='number' min='1' class='form-control typestatus'  name='productQuantity' id='productQuantity' onchange='calcaprice(this,\"quantity\");' value='1' disabled='true'>" +
	"</td>"+
	//Choose the days/months/year
	"<td><input type='text'  min='1' max='31' class='form-control typestatus' name='s_days' onchange='calculteDayMonthsYears(\"day\",this);' id='s_days' disabled='true' value='0'></td>" +
	"<td><input  type='text' min='1' max='12' class='form-control typestatus' name='s_month' onchange='calculteDayMonthsYears(\"month\",this);'  id='s_month' disabled='true' value='0'></td>" +               
	"<td><input  type='text' min='1' max='10' class='form-control typestatus' name='s_year' onchange='calculteDayMonthsYears(\"year\",this);' id='s_year' disabled='true' value='0'></td>" +
	//Single line item MRP
	"<td>"+
	"<input type='text' min='1' class='form-control typestatus' name='s_mrp' id='s_mrp' onchange='calcaprice(this,\"mrp\");' value='0' disabled='true'>"+
	"<span id='s_mrp_span' name='mrp' style='margin-top:5px; color:#277C75;'>0.00</span>"+
	"</td>"+
	//Single line item Base Price"+"
	"<td>"+
	"<input type='text' min='1' class='form-control typestatus' name='s_baseprice'  id='s_baseprice' onchange='calcaprice(this,\"baseprice\");' value='0' disabled='true'>"+
	"<span id='s_baseprice_span' name='baseprice' style='margin-top:5px; color:#277C75;'>0.00</span>"+
	"</td>"+
	//Single line item Selling price
	"<td>"+
	"<input type='text' min='1' class='form-control typestatus' name='s_sellingprice' id='s_sellingprice' onchange='calcaprice(this,\"sellingprice\");' value='0' disabled='true'>"+
	"<span id='s_sellingprice_span' name='sellingprice' style='margin-top:5px; color:#277C75;'>0.00</span>"+
	"</td>"+
	"<td>"+
	"<label id='l2vaccept' title='hello'>"+
	"<i class='fa fa-info cust_check' aria-hidden='true'></i>"+
	"</label>"+
	"<label name='l2vcancel' id='l2vcancel' onclick='cancellineitemdiag(this);'>"+
	"<i class='fa fa-times cust_times' aria-hidden='true'></i>"+
	"</label>"+
	"</td>"+
	"</tr>";
	htmlBanner +="</tbody></table></div></div></section>";
	//End the Dynamic addition/deletion of line item and 
	
	//coupon, refer by(officer), closed by, reffered by mrn(customer)
	htmlBanner += "<section class='container-fluid'>" +
	"<div class='col-lg-8'>"+
	//Coupon code
	"<!--div class='col-lg-4'>"+
	"<label style='color:#408DAE; font-weight:bold;'>Coupon</label><br>" +
	"<input type='text' placeholder='Please enter coupon code' disabled='disabled' id='l2vCoupanCode' data-code='' class='form-control' style='width:140px; display:inline-block;'>" + "&nbsp;<button onclick='removecoupen()' class='btn btn-danger' style='height:35px; line-height:26px; padding-left:6px; padding-right:6px;'>Remove</button><br>" + "<a style='font-size:12px; color:#3E3C6C; font-weight:bold; cursor:pointer;' onclick='showcoupon()'>View Coupons</a><br>" + "<b style='font-size:12px; color:#d22;'>Note:*Re-apply the Coupon Code When Add/Edit item </b>" +
	"</div-->"+
	//Source of referral
	"<div class='col-lg-3'>"+
	"<label style='color:#408DAE; font-weight:bold;'>Source of Referral*</label><br>" +
	"<select type='text' id='l2vsourcereferral' class='form-control' style='min-width:140px;'><option value=''>Choose officer id</option></select>" +
	"</div>"+
	//Referred by officer
	"<div class='col-lg-3'>" +
	"<label style='color:#408DAE; font-weight:bold;'>Referred By Officer*</label><br>" +
	"<input type='text' placeholder='Please officer id' id='l2vreferby' class='form-control referedbylist' style='min-width:140px;'>"+
	"</div>"+
	//Closed by officer
	"<div class='col-lg-3'>"+
	"<label style='color:#408DAE; font-weight:bold;'>Closed By Officer*</label><br>"+
	"<input type='text' placeholder='Please officer id' id='l2vclosedby' class='form-control closedbylist' style='min-width:140px;'>"+
	"</div>"+
	//Closed by officer
	"<div class='col-lg-3'>" +
	"<label style='color:#408DAE; font-weight:bold; min-width:150px;'>Referred by mrn</label><br>" +
	"<input type='number' placeholder='Please enter mrn.' id='l2vsreferbymrn' class='form-control' style='min-width:150px;'>" +
	"</div>"+
	"</div>"+
	"<div class='col-lg-4' align='right'>" +
	"<!--<button onclick='addincart()' class='btn btn-success'>Save as draft</button>&nbsp;&nbsp;-->";
	if(sessionStorage.getItem("open_order_type")==0){
		htmlBanner += "<button onclick='createOrder()' class='btn btn-success'> Re-Confirm reject order </button>&nbsp;&nbsp;";
	}else{
		htmlBanner += "<button onclick='createOrder()' class='btn btn-success'> Book </button>&nbsp;&nbsp;";
	}	
	htmlBanner += "</div>"+
	"</section><br><br>";
	htmlBanner += '<div id="patientAddressList"></div>';
	//"</div>" + htmlBannerMCrg;
	
	//console.log(htmlBanner);
    $("#Custom_body").html("<section id='l2ordercreatediv' style='display:block;'>" + htmlBanner + "</section></section><section style='display:none;' id='l2orderdetailsdiv'></section>");
    $(".loader").hide();
	if(sessionStorage.getItem("is_cart")=="1"){
		check_itemisavailable();
	}
}

function updateaddresspopn() {
    if ($("#address1").val() == "") {
        alert('Please enter address');
        return;
    }
    if ($("#postal_code").val() == "" || $("#postal_code").val() == 0 || $("#postal_code").val() == "0") {
        alert('Please enter postal code');
        return;
    }
    /*if ($("#popid").val() == "" || $("#popid").val() == 0 || $("#popid").val() == "0") {
        alert('Non serviceable area, Please change the pincode');
        return;
    }*/
    if ($("#administrative_area_level_1").val() == "") {
        alert('Please enter state.');
        return;
    }
    if (($("#pcontactno").val() == "") || ($("#pcontactno").val().length < 10)) {
        alert('Please enter contact no.');
        return;
    }
    var showdelvaddress = $("#address1").val() + ", " + $("#route").val() + ", " + $("#locality").val() + ", " + $("#administrative_area_level_1").val() + ", " + $("#postal_code").val();
    
    
    $("#showdelvaddress").html(showdelvaddress);
    $("#showdelvpop").html($("#popname").val());
    sessionStorage.setItem("popname", $("#popname").val());
    sessionStorage.setItem("facility_id", $("#popid").val());
    sessionStorage.setItem("state", $("#administrative_area_level_1").val());
    var addressActionType = $('#actionType').val();
    var addressNickName = $('#address_nick_name').val();
    var district = $('#district').val();
    var latitude = $('#latitude').val();
    var longitude = $('#longitude').val();
    var addressId = $('#selected_address_id').val();
    var address1 = $('#address1').val();
    var stateVal = $('#administrative_area_level_1').val();
    var locality = $('#locality').val();
    var route = $('#route').val();
    var zipcodeVal = $('#postal_code').val();
    var landmark = $('#autocomplete').val();
    var contactno = $('#pcontactno').val();
    var alternetcontactno = $('#alternetcontactno').val();
    var _dataAddress = {
        action: (addressId) ? 'update' : 'add', // add or update
        addressId: addressId, //Mandatory if action=="update"
        mrn: sessionStorage.getItem('patientmrn'),
        createdBy: "",
        createdByType: "",
        stateVal: stateVal,
        addressVal: address1,
        cityVal: locality,
        addressType: 1,
        addressNickName: addressNickName,
        zipcodeVal: zipcodeVal,
        isActive: 1,
        countryVal: "India",
        lngVal: longitude,
        district: district,
        customerId: "CH333218",
        latVal: latitude,
        landmark: landmark,
        defaultAddress: "1"
    };
    _ajaxEventHandler("modifyAddress", _dataAddress, cbk_setNewAddress);
}

function cbk_setNewAddress(response) {
    var responseData = response;
    if(typeof response == 'string'){
        responseData = JSON.parse(response);
    }
    console.log(responseData);
    if(responseData.status == 0 || responseData.status == '0'){
        alert(responseData.message);
        return false;
    }
    
    var currentAddress = responseData.data.addressDetails;
    var district = $('#district').val();
    var latitude = $('#latitude').val();
    var longitude = $('#longitude').val();
    var addressId = currentAddress.AddressId;
    var address1 = $('#address1').val();
    var stateVal = $('#administrative_area_level_1').val();
    var country = $('#country').val();
    var locality = $('#locality').val();
    var latitude = $('#latitude').val();
    var longitude = $('#longitude').val();
    var route = $('#route').val();
    var zipcodeVal = $('#postal_code').val();
    var landmark = $('#autocomplete').val();
    var contactno = $('#pcontactno').val();
    var address_nick_name = $('#address_nick_name').val();
    var alternetcontactno = $('#alternetcontactno').val();
    var address = address1 + ", " + route + ", " + locality + ", " + stateVal + ", " + country + ", " + zipcodeVal;
    sessionStorage.setItem("landmark", landmark);
    sessionStorage.setItem("city", locality);
    sessionStorage.setItem("district", district);
    sessionStorage.setItem("state", stateVal);
    sessionStorage.setItem("country", country);
    sessionStorage.setItem("postal_code", zipcodeVal);
    sessionStorage.setItem("address_id", addressId);
    sessionStorage.setItem("address_nickname", address_nick_name);
    sessionStorage.setItem("address", address);
    sessionStorage.setItem("latitude", latitude);
    sessionStorage.setItem("longitude", longitude);
    $('#showdelvaddress').html(address);
    $('#addressListModal').modal('hide');
}


function render_order_basedonmrn(response,$type) {
    ordersdetails = response;
	htmlBanner_later='';
    htmlBanner = '<br>'+
	'<section class="container-fluid">'+
	'<article class="main_content">' +
	'<div class="tab-content custom_tab_content">'+
	'<div role="tabpanel" class="tab-pane fade in active">'+
	'<div class="col-md-12 col-sm-12 col-xs-12 mp">'+
	'<div class="table-responsive">'+
	'<table id="example1" cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">'+
	'<thead>'+
	'<tr>'+
	'<th>MRN</th>'+
	'<th>Transaction No.</th>'+
	'<th>Order No.</th>'+
	'<th>Order DID.</th>'+
	'<th>Work Order ID</th>'+
	'<th>Order Created Date</th>'+
	'<th>Vendor Name</th>'+
	'<th>Location</th>'+
	'<th>Source</th>'+
	'<th>Item Names</th>';
	if($type=="completed"){
		htmlBanner+='<th>Completed Date</th>';
		htmlBanner_later='<th>Re-order</th>';
		colspan=14; 
	}else if($type=="pending"){
		htmlBanner+='<th>Schedule Date</th>'+
		'<th>Total Amount</th>'+
		'<th>Order Status</th>';
		htmlBanner_later='<th>Edit</th>';
		colspan=16;
	}
	htmlBanner+='<th>Order Details</th><th>Track</th>';
	htmlBanner+=htmlBanner_later;
	htmlBanner+='</tr></thead><tbody>';
	if (parseInt(ordersdetails.countn) > 0) {
        $.each(ordersdetails.data, function (key, val){
			var htmlBanner_later="";
			var itemnames = "";
            var transaction_code =((typeof val.transaction_code!="undefined")?val.transaction_code:"");
            htmlBanner += '<tr><td>'+ val.order.patientinfo.mrn + '</td>'+
			'<td>'+transaction_code+'</td>'+
			'<td>'+val._id+'</td>'+
			'<td>'+val.odid+'</td>'+
			'<td>'+val.wodid+'</td>'+
			'<td>'+val.order.order_status.created_date+'</td>';
			if((typeof val.order.provider_info != "undefined") && (typeof val.order.provider_info[0].associate_id != "undefined")){
				htmlBanner += '<td>'+val.order.provider_info[0].associate_name+'</td>';
			}else{
				htmlBanner += '<td>'+((typeof val.order.vendorinfo == "undefined")?"":val.order.vendorinfo.VendorName)+'</td>';
			}
			
			
			
			htmlBanner += '<td>'+val.order.patientinfo.city+'</td>'+
			'<td>'+channel[val.channel]+'</td>';			
			if (typeof val.order.orderitem != "undefined" || (val.order.orderitem != null)) {
                $.each(val.order.orderitem, function (key, val1) {
                    if (val1.itemname != "" || val.OStatus == "8"){
						itemnames+=val1.itemname+',';
					}                   
                });
            }
			htmlBanner+='<td>'+itemnames+'</td>';
			if($type=="completed"){
				htmlBanner_later='<td>';
				if(jQuery.inArray(val.OStatus,[6])>-1){
					htmlBanner_later+='<a onclick="reorderfun('+ val._id + ',1);" class="track_btn">Order</a>';
				}
				htmlBanner_later+='</td>';
				htmlBanner+='<td>'+changedate(val.order.patientinfo.completed_date)+'</td>';
			}else if($type=="pending"){
				htmlBanner_later='<td>';
				//if(jQuery.inArray(val.OStatus,[24,1000])>-1){
				if(1 == 1){
					htmlBanner_later+='<a onclick="reorderfun('+ val._id + ',0);" class="track_btn">Order</a>';
				}
				htmlBanner_later+='</td>';
				htmlBanner+='<td>'+changedate(val.order.patientinfo.scheduled_date)+'</td>'+
				'<td>'+val.order.patientinfo.net_amount+'</td>'+
				'<td>'+val.data.Nomenclature+'</td>';			
			}
			//htmlBanner+='<td><a onclick="vieworderdetails_modal('+ val._id + ')" class="view">view</a></td>'+
			htmlBanner+='<td><a onclick="vieworder('+ val._id + ')" class="view">view</a></td>'+
			'<td><a onclick="trackOrder('+ val._id + ')" class="track_btn">Track</a></td>'+htmlBanner_later+'</tr>';
        });
    } else {
        htmlBanner+='<tr><td colspan="'+colspan+'"> Data is not found.</td><tr>';
    }
	htmlBanner += '</tbody>'+
	'</table>'+
	'</div>'+
	'</div>'+
	'</div>'+
	'</div>'+
	'</article>'+
	'</section>';
	$(".loader").hide();
    $("#l2vsearch_custom").hide();
    $("#l2orderdetailsdiv").css("display", "block");
    $("#l2orderdetailsdiv").html(htmlBanner);
    $("#l2ordercreatediv").css("display", "none");
}

function patientAddressList(addressList) {
    var addressListHtml = '';
    if (addressList.length > 0) {
        $.each(addressList, function (key, address) {
            var selectedBackground = 'style="border: 1px solid;padding: 0px 5px; color:gray;margin:0px 2.5px 5px 2.5px; width : 49.5%; height: 180px; float: left;"';
            if (address.AddressId == sessionStorage.getItem('address_id')) {
                selectedBackground = 'style="background : #d3d3d32b;border: 1px solid;padding: 0px 5px; color:gray; margin:0px 2.5px 5px 2.5px;width : 49.5%; height: 180px; float: left;"';
            }
            addressListHtml += '<div id="' + address.AddressId + '" ' + selectedBackground + '>' +
                    '<p style="background-color: gray;margin: 10px 0px;font-size: 18px;color: white;padding: 5px;font-weight: 900;">Address Name - <span class="addressNickName">' + address.AddressNickName + '</span><button style="margin-top: -1.5px;" class="btn btn-warning pull-right" value="' + address.AddressId + '" onclick="selectAddress(' + address.AddressId + ',true);">Modify</button><button style="margin-right : 5px; margin-top: -1.5px;" class="btn btn-success pull-right" value="' + address.AddressId + '" onclick="selectAddress(' + address.AddressId + ');">Select</button></p>' +
                    '<p><b>Address - </b> <span class="addressVal">' + address.addressVal + '</span>,<span class="areaVal">' + address.areaVal + '</span>,<span class="mandalVal">' + address.Mandal + '</span></p>' +
                    '<p><b>City - </b><span class="cityVal">' + address.cityVal + '</span>,<b> District - </b><span class="districtVal">' + address.district + '</span>,<b> State - </b><span class="stateVal">' + address.stateVal + '</span>,<b> Pincode - </b><span class="zipcodeVal">' + address.zipcodeVal + '</span></p>' +
                    '<p><b>Landmark - </b><span class="landMarkVal">' + address.Landmark + '</span></p>' +
                    '<p style="display: none;"><label class="latitude">' + address.LatVal + '</label> <label class="logitude">' + address.LngVal + '</label></p>' +
                    '</div>';
        });
    }
    var addressModalHtml = '<div id="addressListModal" class="modal fade" role="dialog">' +
            '<div class="modal-dialog modal-lg" style="width: 80%">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal" style="margin-top: 6px;">&times;</button>' +
            '<h4 class="modal-title" style="border:0px;">Address List</h4>' +
            '</div>' +
            '<div class="modal-body addressListModalBody">' +
            '<div class="newAddress">' +
            '<div id="editaddress" style=""> <!-- l2v -->' +
            '<div class="col-md-12 col-sm-12 col-xs-12 update_address" id="l2vupdate_address" style="display:block; border:0px;background:#f1f3f4;">' +
            '<!--div class="col-md-12"><h4>Delivery Address</h4></div--><br>' +
            '<div class="col-md-4 col-sm-4 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Address Nick Name</label>' +
            '<input id="address_nick_name" name="address_nick_name" type="text" class="form-control clearAddressData" value="">' +
            '<input id="selected_address_id" name="selected_address_id" type="text" class="form-control" value="' + sessionStorage.getItem('address_id') + '" style="display:none;">' +
            '</div>' +
            '</div>' +
            '<div class="col-md-4 col-sm-4 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Address:</label>' +
            '<textarea id="address1" class="form-control clearAddressData"></textarea>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Country:</label>' +
            '<input id="country" name="country" type="text" class="form-control " value="India" disabled>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">State / Province:</label>' +
            '<input type="text" class="form-control" list="l2vadministrative_area_level_111" id="administrative_area_level_1" value="" placeholder="select state">' +
            '<datalist id="l2vadministrative_area_level_111"><option>Telangana</option></datalist>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">City / Town:</label>' +
            '<input type="text" list="l2vlocality111" id="locality" class="form-control clearAddressData input-sm sa-bordnone" placeholder="select District" value="">' +
            '<datalist id="l2vlocality111"></datalist>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Area Location:</label>' +
            '<input type="text" list="l2vroute111" id="route" class="form-control clearAddressData" value="" placeholder="select area">' +
            '<datalist id="l2vroute111"></datalist>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Postal Code:</label>' +
            '<input class="form-control clearAddressData"  onchange="populatepopsetailsbypin(this.value)" id="postal_code" name="srch-term" type="number" size="18" value="" placeholder="Postal Code">' +
            '</div>' +
            '</div>' +
            '<div class="col-md-4 col-sm-4 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Landmark:</label>' +
            '<textarea name="job_name" id="autocomplete" onfocusout="getAddressLatLong(value)" autocomplete="off" required="required" class="form-control clearAddressData new-status ui-autocomplete-input" placeholder="Landmark"></textarea>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">POP Name:</label>' +
            '<input class="form-control clearAddressData" id="popname" name="srch-term" type="text" size="18" value="" placeholder="popname" disabled>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Primery Mobile No:</label>' +
            '<input class="form-control clearAddressData" id="pcontactno" name="srch-term" type="number" size="11" value="" placeholder="Primery contect no">' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2 col-sm-2 col-xs-12">' +
            '<div class="form-group">' +
            '<label for="usr">Alternative contact No:</label>' +
            '<input class="form-control clearAddressData" id="alcontactno" name="srch-term" type="number" size="11" value="" placeholder="Alternative contect no">' +
            '</div>' +
            '</div>' +
            '<div class="col-md-3 col-sm-3 col-xs-12">' +
            '<br>' +
            '<div class="form-group" style="margin-top : 10px;">' +
            '<input class="form-control" id="district" name="srch-term" type="hidden" size="18" placeholder="District" value="">' +
            '<input type="hidden" class="form-control" id="popid" value="" style="display:inline;">' +
            '<input type="hidden" class="clearAddressData" value="" name="latitude" id="latitude">' +
            '<input type="hidden" class="clearAddressData" value="" name="longitude" id="longitude">' +
            '<a onclick="updateaddresspopn();" style="cursor:pointer;" class="update_address_btn">Save Address</a>' +
            '<a onclick="clearAddressData();" style="cursor:pointer;cursor:pointer;margin-left: 10px !important;background-color: darkred; color: #fff;padding: 8px 10px;border-radius: 0px;text-align: center;height: 34px;display: inline;font-size: 12px;line-height: 0px;text-decoration: none;" class="clear_address_btn">Clear Address</a>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-12 existingAddress" id="addressList" style="padding: 0px;">' + addressListHtml + '<div class="clearfix"></div></div>' +
            '<div class="clearfix"></div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>';
    console.log(addressModalHtml);
    $(".loader").hide();
    $('#patientAddressList').html(addressModalHtml);
    $('#addressListModal').modal('show');
}












































/*function render_cartitem(response) {
    ordersdetails = response;
    htmlBanner = '<br>'+
	'<section class="container-fluid">'+
	'<article class="main_content">' +
	'<div class="tab-content custom_tab_content">'+
	'<div role="tabpanel" class="tab-pane fade in active">'+
	'<div class="col-md-12 col-sm-12 col-xs-12 mp">'+
	'<div class="table-responsive">'+
	'<table id="example1" cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">'+
	'<thead>'+
	'<tr>'+
	'<th>Item Name</th>'+
	'<th>Item Created Date</th>'+
	'<th>Quantity</th>'+
	'<th>Action</th>'+
	'</tr></thead><tbody>';
	if (parseInt(ordersdetails.status) == 1) {
        $.each(ordersdetails.data, function (key, val){
			var createdate = val.CreatedDate.year+"-"+val.CreatedDate.month+"-"+val.CreatedDate.dayOfMonth+" "+val.CreatedDate.hourOfDay+":"+val.CreatedDate.minute+":"+val.CreatedDate.second;
            htmlBanner += '<tr><td>'+val.name+'</td>'+
			'<td>'+createdate+'</td>'+
			'<td>'+val.session+'</td>'+
			'<td>'+val.odid+'</td>'+
			'<td><a onclick="add('+ val._id + ',1);" class="track_btn">Order</a>'+
			'<a onclick="reorderfun('+ val._id + ',1);" class="track_btn">Order</a></td></tr>';
        });
    } else {
        htmlBanner+='<tr><td colspan="4"> There is no item in the cart.</td><tr>';
    }
	htmlBanner += '</tbody>'+
	'</table>'+
	'</div>'+
	'</div>'+
	'</div>'+
	'</div>'+
	'</article>'+
	'</section>';
	$(".loader").hide();
    $("#l2vsearch_custom").hide();
    $("#l2orderdetailsdiv").css("display", "block");
    $("#l2orderdetailsdiv").html(htmlBanner);
    $("#l2ordercreatediv").css("display", "none");
}*/







































function renderCreateOrder_old(bj) {
   // console.log(bj.countn);
    var htmlBannerMCrg = "<input id='medicine_delivery' data-id='' data-codedid='' data-item_mrp='' data-item_gross='' data-item_net='' data-item_discount='' data-ignoreToPartner='' value='0' type='hidden'>";
    if (bj.countn>0) {
         console.log("hello");
        var Obj = bj.itemlist.orderitem ? bj.itemlist.orderitem:0;
        var htmlBanner = "";
        htmlBanner += "<section class='container-fluid'><div class='col-md-12 col-sm-12 col-xs-12 mp'>" +
                "<div class=''>" +
                "<table class='table cust_table_order table-condensed table-bordered table-striped medicine_home_order_table' id='mtable'>" +
                "<thead>" +
                "<tr>" +
                "<th style='width: 23%;'>" +
                "Product Name" +
                "</th>" +
                "<th style='width: 20%;'>" +
                "Brand Name" +
                "</th>" +
                "<th>" +
                " Doctor Name" +
                "</th>" +
                "<th style='width: 10%;'>" +
                "Type" +
                "</th>" +
                "<th>" +
                "Item MRP" +
                "</th>" +
                "<th style='width:80px;'>" +
                "Order Qty" +
                "</th>" +
                "<th>" +
                "Days" +
                "</th>" +
                "<th>" +
                "Month" +
                " </th>" +
                "<th>" +
                "Year" +
                "</th>" +
                "<th style='min-width:65px;'>" +
                " Actions" +
                "</th> " +
                "</tr>" +
                " </thead>" +
                "<tbody>";
         for (var i = 0; i < (Obj.length); i++) {
             if (Obj[i].item_status != "8") {
                if (i == 0) {
                    htmlBanner +=
                            "<tr class='rowdrug' id='rowdrug-0'>" +
                            "<td>" +
                            " <div class='form-group'>" +
                            " <div class='input-group input-group-md'>" +
                            "<div class='icon-addon'>" +
                            "<input type='text' value='" + Obj[i].itemname + "' list='druglist'  class='form-control drugsearch' id='drugsearch' name='drugsearch' onkeyup='loaddruglist(event,this);' onchange='loadanotherdrug(this);' data-code='" + Obj[i].item_id + "' data-codedid='" + Obj[i].item_code + "'><datalist id='druglist' class='data_druglist'></datalist>" +
                            "</div>" +
                            "<span class='input-group-btn'>" +
                            "<button class='btn btn-default' type='button'><i class='fa fa-search' aria-hidden='true'></i></button>" +
                            "</span>" +
                            "</div>" +
                            "</div>" +
                            "</td>" +
                            "<td>" +
                            " <div class='form-group'>" +
                            "<input type='text' value='" + Obj[i].itembrand + "' class='form-control' id='drugbrand' name='drugbrand'	>" +
                            " </div>" +
                            "</td>" +
                            " <td>" +
                            "<input type='text' value='" + Obj[i].doctor + "'  class='form-control' name='doctorname' id='doctorname'>" +
                            "</td>" +
                            "<td>" +
                            " <div class='form-group'>" +
                            "<input type='radio' class='' id='rentalSale" + i + "' name='rentalSale'  value='1'> Rental &nbsp;&nbsp;" +
                            "<input type='radio' class='' id='rentalSale" + i + "' name='rentalSale'  value='2'> Sale" +
                            " </div>" +
                            "</td>" +
                            "<td>" +
                            "<input type='text' disabled value='" + Obj[i].item_mrp + "' class='form-control' id='itemmrpval'>" +
                            "</td>" +
                            "<td><input type='number' min='1' class='form-control typestatus' onchange='checkpricefrommdm();' value='" + Obj[i].quantity + "' id='quantity'></td>" +
                            "<td>" +
                            "<input type='text' disabled data-mrp='" + Obj[i].item_mrp + "' value='" + Obj[i].gross_amount + "' class='form-control' id='grossamount'>" +
                            "</td>" +
                            "<td>" +
                            "<input type='text' disabled value='" + Obj[i].discount_amount + "' class='form-control' id='discountamount'>" +
                            "</td>" +
                            "<td><input disabled type='text'  class='form-control' id='netamount'  data-walletamt='" + ((typeof Obj[i].item_wallet == "undefined") ? 0 : Obj[i].item_wallet) + "' value='" + Obj[i].net_amount + "'></td>" +
                            "<td><label id='l2vaccept" + i + "' title='" + ((typeof Obj[i].pricePerUnit != "undefined") ? Obj[i].pricePerUnit : 'NA') + "'><a href='#' title='" + Obj[i].user_log + "'><i class='fa fa-info cust_check' aria-hidden='true'></i></a></label><label name='l2vcancel' id='l2vcancel" + i + "' onclick='cancellineitemdiag(this);'><i class='fa fa-times cust_times' aria-hidden='true'></i></label></td>" +
                            "</tr> ";
                }else {
                    htmlBanner +=
					"<tr class='rowdrug' id='rowdrug-0'>" +
					"<td>" +
					"<div class='form-group'>" +
					"<div class='input-group input-group-md'>" +
					"<div class='icon-addon'>" +
					"<input value='" + Obj[i].itemname + "' type='text' list='druglist" + i + "'  class='form-control drugsearch' id='drugsearch" + i + "' name='drugsearch' onkeyup='loaddruglist(event,this);' onchange='loadanotherdrug(this);' data-code='" + Obj[i].item_id + "' data-codedid='" + Obj[i].item_code + "'><datalist id='druglist" + i + "'' class='data_druglist'></datalist>" +
					"</div>" +
					"<span class='input-group-btn'>" +
					"<button class='btn btn-default' type='button'><i class='fa fa-search' aria-hidden='true'></i></button>" +
					"</span>" +
					"</div>" +
					"</div>" +
					"</td>" +
					"<td>" +
					"<div class='form-group'>" +
					"<input type='text' disabled  value='" + Obj[i].itembrand + "' class='form-control' name='drugbrand' id='drugbrand" + i + "'>" +
					"</div>" +
					"</td>" +
					"<td>" +
					"<input type='text' class='form-control' value='" + Obj[i].doctor + "' name='doctorname' id='doctorname" + i + "'>" +
					"</td>" +
					"<td>" +
					"<div class='form-group'>" +
					"<input type='radio' class='' id='rentalSale" + i + "' name='rentalSale'  value='1' checked> Rental &nbsp;&nbsp;" +
					"<input type='radio' class='' id='rentalSale" + i + "' name='rentalSale'  value='2' > Sale" +
					"</div>" +
					"</td>" +
					"<td>" +
					"<input type='text' disabled value='" + Obj[i].item_mrp + "' class='form-control' id='itemmrpval" + i + "'>" +
					"</td>" +
					"<td><input type='number' min='1' class='form-control typestatus ' onchange='checkpricefrommdm();' value='" + Obj[i].quantity + "' id='quantity" + i + "'></td>" +
					"<td>" +
					"<input type='text' disabled data-mrp='" + Obj[i].item_mrp + "' value='" + Obj[i].gross_amount + "'  class='form-control' id='grossamount" + i + "'>" +
					"</td>" +
					"<td>" +
					"<input type='text' disabled value='" + Obj[i].discount_amount + "'  class='form-control' id='discountamount" + i + "'>" +
					"</td>" +
					"<td><input disabled value='" + Obj[i].net_amount + "' type='text'  class='form-control'  data-walletamt='" + ((typeof Obj[i].item_wallet == "undefined") ? 0 : Obj[i].item_wallet) + "' id='netamount" + i + "'></td>" +
					"<td><label id='l2vaccept" + i + "' title='" + ((typeof Obj[i].pricePerUnit != "undefined") ? Obj[i].pricePerUnit : 'NA') + "'><a href='#' title='" + Obj[i].user_log + "'><i class='fa fa-info cust_check' aria-hidden='true'></i></a></label><label name='l2vcancel' id='l2vcancel" + i + "' onclick='cancellineitemdiag(this);'><i class='fa fa-times cust_times' aria-hidden='true'></i></label></td>" +
					"</tr> ";
                }
            }
        }
        htmlBanner +=
                "<tr class='rowdrug' id='rowdrug-0'>" +
                "<td>" +
                " <div class='form-group'>" +
                " <div class='input-group input-group-md'>" +
                "<div class='icon-addon'>" +
                "<input type='text' list='druglist" + i + "'  class='form-control drugsearch' id='drugsearch" + i + "' name='drugsearch' onkeyup='loaddruglist(event,this);' onchange='loadanotherdrug(this);'><datalist id='druglist" + i + "' class='data_druglist'></datalist>" +
                "</div>" +
                "<span class='input-group-btn'>" +
                "<button class='btn btn-default' type='button'><i class='fa fa-search' aria-hidden='true'></i></button>" +
                "</span>" +
                "</div>" +
                "</div>" +
                "</td>" +
                "<td>" +
                " <div class='form-group'>" +
                "<input type='text' disabled  class='form-control' name='drugbrand' id='drugbrand" + i + "'>" +
                " </div>" +
                "</td>" +
                " <td>" +
                "<input type='text'  class='form-control' name='doctorname' id='doctorname" + i + "'>" +
                "</td>" +
                "<td>" +
                " <div class='form-group'>" +
                "<input type='radio' class='radioclass' id='rentalSale" + i + "'  name='rentalSale' value='1'> Rental &nbsp;&nbsp;" +
                "<input type='radio' class='radioclass' id='rentalSale" + i + "'  name='rentalSale' value='2'> Sale" +
                " </div>" +
                "</td>" +
                "<td>" +
                "<input type='text' disabled value='' class='form-control' id='itemmrpval" + i + "'>" +
                "</td>" +
                "<td><input type='number' min='1' class='form-control' name='quantity' onchange='checkpricefrommdm();' id='quantity" + i + "'></td>" +
                "<td>" +
                "<input type='text' disabled data-mrp='' class='form-control' id='grossamount" + i + "'>" +
                "</td>" +
                " <td>" +
                "<input type='text' disabled  class='form-control' id='discountamount" + i + "'>" +
                "</td>" +
                "<td><input disabled type='text'  class='form-control' data-walletamt='' id='netamount" + i + "'></td>" +
                "<td><label id='l2vaccept' title='hello'><a href='#'><i class='fa fa-info cust_check' aria-hidden='true'></i></a></label><label name='l2vcancel' id='l2vcancel' onclick='cancellineitemdiag(this);'><i class='fa fa-times cust_times' aria-hidden='true'></i></label></td>" +
                "</tr> ";
        htmlBanner +=
                "</tbody>" + "</table>" +
                "</div>" +
                "<!--<div class='col-md-12 col-sm-12 col-xs-12 text-right view_prec'>" +
                " <a href='#' class='back_btn'>View Prescription</a>&nbsp;" +
                "<a href='#' class='back_btn'>Rpeat Order</a>&nbsp;" +
                "<button onclick='createOrder()' class='btn btn-primary'>Save</button>&nbsp;" +
                "</div>-->" +
                "<!--<div class='col-md-8 col-md-offset-4 pull-right'>" +
                " <nav aria-label='...'>" +
                "<ul class='pagination'>" +
                " <li class='page-item disabled'>" +
                " <a class='page-link' href='#' tabindex='-1'>Previous</a>" +
                "</li>" +
                "<li class='page-item'><a class='page-link' href='#'>Order( 1 - 100 from 123 )</a></li>" +
                "<li class='page-item'>" +
                " <a class='page-link' href='#'>Next</a>" +
                " </li>" +
                "</ul>" +
                "<span class='nps'>" +
                "No of Pages <select name='job_name' class='form-control noofpages'>" +
                " <option value=''>1</option>" +
                "<option value=''>25</option>" +
                "<option value=''>50</option>" +
                " <option value=''>100</option>" +
                "</select>" +
                " </span>" +
                "</nav>" +
                " </div>-->" +
                "</div></section>";
    }
    else {
        var htmlBanner = "";
        htmlBanner = "<section class='container-fluid'><div class='col-md-12 col-sm-12 col-xs-12 mp'>" +
                "<div class=''>" +
                "<table class='table cust_table_order table-condensed table-bordered table-striped medicine_home_order_table' id='mtable'>" +
                "<thead>" +
                "<tr>" +
                "<th style='width: 23%;'>" +
                "Product Name" +
                "</th>" +
                "<th style='width: 14%;'>" +
                "Brand Name" +
                "</th>" +
                "<th style='width: 8%;'>" +
                "Type" +
                "</th>" +
                "<th style='width: 11%;'>" +
                "Vendor Name" +
                "</th>" +
                
                "<th style='width:65px;'>" +
                "Order Qty" +
                "</th>" +                
                "<th style='width:65px;'>" +
                "Days" +
                "</th>" +
                "<th style='width:65px;'>" +
                "Month" +
                " </th>" +
                "<th style='width:65px;'>" +
                "Year" +
                "</th>" +
                "<th style='width:80px;'>" +
                "MRP" +
                "</th>" +
                "<th style='width:80px;'>" +
                "Baseprice" +
                "</th>" +
                "<th style='width:50px;'>" +
                "Sellingprice" +
                "</th>" +
                "<!--<th style='width: 10%;'>" +
                "Priceupdate" +
                "</th>-->" +
                "<th>" +
                " Actions" +
                "</th> " +
                "</tr>" +
                "</thead>" +
                "<tbody>" +
                "<tr class='rowdrug' id='rowdrug-0'>" +
                "<td>" +
                "<div class='form-group'>" +
                "<div class='input-group input-group-md'>" +
                "<div class='icon-addon'>" +
                "<input type='text' list='druglist'  class='form-control drugsearch' id='drugsearch' name='drugsearch' onkeyup='loaddruglist(event,this);' onchange='loadanotherdrug(this);'><datalist id='druglist' class='data_druglist'></datalist>" +
                "</div>" +
                "<span class='input-group-btn'>" +
                "<button class='btn btn-default' type='button'><i class='fa fa-search' aria-hidden='true'></i></button>" +
                "</span>" +
                "</div>" +
                "</div>" +
                "</td>" +
                "<td>" +
                "<div class='form-group'>" +
                "<input type='text' disabled  class='form-control' id='drugbrand' name='drugbrand'>" +
                "</div>" +
                "</td>" +
                "<td>" +
                "<div class='form-group'>" +
                "<!--<input type='radio' class='raidocalss'  onchange='isChecked(this);' name='rentalSale' value='1'> Rental &nbsp;&nbsp;" +
                "<input type='radio' class='raidocalss'   onchange='isChecked(this);' name='rentalSale' value='2'> Sale" +
                "<input type='hidden' class='raidocalss'   id='rentaltype' value='1'>-->" +
                "<select name='equipmenttype' id='equipmenttype' class='form-control new-status equipmenttype' onchange='choose_equipmenttype(this);'>" +               
                "<option value='0' selected='selected'>Select Type</option>" +
                "<option value='1'>Rent</option>" +
                "<option value='2'>Sale</option>" +
                "</select>"+
                "</div>" +
                "</td>" +
                "<td>"+
                "<select name='selectvendor' id='selectvendor' class='form-control new-status vendorname' onchange='choose_vendor(this);'>" +
                "<option value='0' selected='selected'>Select Vendor</option>" +
                "</select>" +
                "</td>"+
                "<td>" +
				"<!--input type='number' min='1' class='form-control typestatus'  name='productQuantity'  onkeyup='calculate(this);' onchange='calculate(this);' id='productQuantity'-->" +
				"<input type='number' min='1' class='form-control typestatus'  name='productQuantity' id='productQuantity' value='1'>" +
				"</td>" +                
                "<td>" +
                "<input type='text'  min='1' max='31' data-mrp=''  ' class='form-control typestatus' name='s_days'  onchange='calculteDayMonthsYears(\"day\",this);' id='s_days'>" +
                "<input type='hidden' class='raidocalss'   name='totaldays' id='number_days'>" +
                "</td>" +
                "<td><input  type='text' min='1' max='12'  class='form-control typestatus' data-walletamt='' name='s_month' onchange='calculteDayMonthsYears(\"month\",this);'  id='s_month'></td>" +               
                "<td><input  type='text' min='1'  class='form-control typestatus' data-walletamt='' onchange='calculteDayMonthsYears(\"year\",this);' name='s_year' id='s_year'></td>" +
                "<input type='hidden' class='raidocalss'   name='totalyears' id='number_years'>" +
                "<td><input type='text' min='1' class='form-control typestatus' name='s_mrp' id='s_mrp'><br><spna id='s_mrp_span'></span></td>" +
                "<td><input type='text' min='1' class='form-control typestatus' name='s_baseprice'  id='s_baseprice'><br><spna id='s_baseprice_span'></span></td>" +
                "<td><input type='text' min='1' class='form-control typestatus' name='s_sellingprice' id='s_sellingprice'><br><spna id='s_sellingprice_span'></span></td>" +
                "<!--<td> <input type='submit' onclick='updateprice(this);' class='btn btn-primary' name='s_button' id='s_button' value='Priceupdate'></td>-->"+
                "<td><label id='l2vaccept' title='hello'><a href='#'><i class='fa fa-info cust_check' aria-hidden='true'></i></a></label><label name='l2vcancel' id='l2vcancel' onclick='cancellineitemdiag(this);'><i class='fa fa-times cust_times' aria-hidden='true'></i></label></td>" +
                "</tr> " +
                "</tbody>" +
                "</table>" +
                "</div>" +
                "<!--div class='col-md-12 col-sm-12 col-xs-12 text-right view_prec'>" +
                "<a href='#' class='back_btn'>View Prescription</a>&nbsp;" +
                "<a href='#' class='back_btn'>Rpeat Order</a>&nbsp;" +
                "<button onclick='createOrder()' class='btn btn-primary'>Save</button>&nbsp;" +
                "</div-->" +
                "<!--div class='col-md-8 col-md-offset-4 pull-right'>" +
                "<nav aria-label='...'>" +
                "<ul class='pagination'>" +
                "<li class='page-item disabled'>" +
                "<a class='page-link' href='#' tabindex='-1'>Previous</a>" +
                "</li>" +
                "<li class='page-item'><a class='page-link' href='#'>Order( 1 - 100 from 123 )</a></li>" +
                "<li class='page-item'>" +
                "<a class='page-link' href='#'>Next</a>" +
                "</li>" +
                "</ul>" +
                "<span class='nps'>" +
                "No of Pages <select name='job_name' class='form-control noofpages'>" +
                "<option value=''>1</option>" +
                "<option value=''>25</option>" +
                "<option value=''>50</option>" +
                "<option value=''>100</option>" +
                "</select>" +
                "</span>" +
                "</nav>" +
                "</div-->" +
                "</div></section>";
    }
    htmlBanner += "<section class='container-fluid'>" +
            "<div class='col-lg-7'>"+
			"<div class='col-lg-4'>" +
            "<label style='color:#408DAE; font-weight:bold;'>Coupon</label><br>" +
            "<input type='text' placeholder='Please enter coupon code' disabled='disabled' id='l2vCoupanCode' data-code='' class='form-control' style='width:140px; display:inline-block;'>" + "&nbsp;<button onclick='removecoupen()' class='btn btn-danger' style='height:35px; line-height:26px; padding-left:6px; padding-right:6px;'>Remove</button><br>" + "<a style='font-size:12px; color:#3E3C6C; font-weight:bold; cursor:pointer;' onclick='showcoupon()'>View Coupons</a><br>" + "<b style='font-size:12px; color:#d22;'>Note:*Re-apply the Coupon Code When Add/Edit item </b>" +
            "</div>"+
            "<div class='col-lg-3'>"+
            "<label style='color:#408DAE; font-weight:bold;'>Source of Referral*</label><br>" +
            "<select type='text' id='l2vsourcereferral' class='form-control' style='min-width:140px;'><option value=''>Choose officer id</option></select>" +
            "</div>"+
			"<div class='col-lg-3'>" +
            "<label style='color:#408DAE; font-weight:bold;'>Referred By*</label><br>" +
            "<input type='text' placeholder='Please officer id' id='l2vreferby' class='form-control referedbylist' style='min-width:140px;'>" +
            "<!--input type='text' onkeyup='findofferid();' list='referedbylist' placeholder='Please officer id' id='l2vreferby' class='form-control referedbylist' style='min-width:140px;'><datalist id='referedbylist'></datalist-->" +
            "</div>"+
			"<div class='col-lg-3'>" +
            "<label style='color:#408DAE; font-weight:bold;'>Closed By*</label><br>" +
            "<input type='text' placeholder='Please officer id' id='l2vclosedby' class='form-control closedbylist' style='min-width:140px;'>" +
            "<!--input type='text' onkeyup='findofferidforclosed();' list='closedbylist' placeholder='Please officer id' id='l2vclosedby' class='form-control closedbylist' style='min-width:140px;'><datalist id='closedbylist'></datalist-->" +
            "</div>"+
            "<div class='col-lg-3'>" +
            "<label style='color:#408DAE; font-weight:bold; min-width:150px;'>Referred by mrn</label><br>" +
            "<input type='number' placeholder='Please enter mrn.' id='l2vsreferbymrn' class='form-control' style='min-width:150px;'>" +
            "</div>" +
            
            "<div class='col-lg-4'></div>" +
            "</div>" +
            "<div class='col-lg-5' align='right'>" +
            "<label></label>" +
            "<!--input type='checkbox' name='checkboxprescriptionsms' id='checkboxprescriptionsms' data-status='0'>&nbsp;" +
            "<span style='color:#222; font-size:13px; font-weight: bold;' id='checkboxprescriptionsmsname'>Prescription Required</span>&nbsp;" +
            "<button onclick='l2prescptionuploadl2()' class='btn btn-success'>Add Prescription</button>&nbsp;" +
            "<button onclick='openprescriptionmadal()' id='l2vopenprescriptionmadal' class='btn btn-success'>View Prescription</button-->&nbsp;" +
            "<button onclick='createOrder()' class='btn btn-success'> Book </button>&nbsp;&nbsp;" +
            "</div>" +
            "<div class='col-lg-12' align='right'><br><br></div>" +
            "</section>" +
            "<div class='modal fade' id='Uploadprescptionl2' role='dialog'>" +
            "<div class='modal-dialog'>" +
            "<!-- Modal content-->" +
            "<div class='modal-content'>" +
            "<div class='modal-header'>" +
            "<button type='button' class='close' data-dismiss='modal'>&times;</button>" +
            "</div>" +
            "<div class='modal-body'>" +
            "<form  id='formsuml2'  method='post' enctype='multipart/form-data'>" +
            "<input type='file' name='pic[]' id='l2prescptionname' multiple>" +
            "<input type='hidden' name='orderid' value='+ordersdetails._id+' id='orderid'>" +
            "<button type='button' class='btn btn-success' data-dismiss='modal' onclick='l2prescptionuploadfroml2()' >Upload</button>" +
            "</form>" +
            "</div>" +
            "<div class='modal-footer'>" +
            "<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>" +
            "</div>" +
            "</div>" +
            "</div>" +
            "</div><div class='modal fade' id='couponlistmodal' role='dialog'>" +
            "<div class='modal-dialog'>" +
            "<!-- Modal content-->" +
            "<div class='modal-content'>" +
            "<div class='modal-header'>" +
            "<button type='button' class='close' data-dismiss='modal'>&times;</button>" +
            "<h4 class='modal-title'>Coupon List</h4>" +
            "</div>" +
            "<div class='modal-body' align='left'>" +
            "<table border='1' style='margin:10px; width:95%;'><thead><tr style='background:#0F7C75; color:#fff;'><th>Coupons Name</th><th>Description</th><th>Action</th></tr></thead><tbody id='couponlist'>" +
            "</tbody></table>" +
            "</div>" +
            "<div class='modal-footer'>" +
            "<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>" +
            "</div>" +
            "</div>" +
            "</div>" +
            "</div>" + htmlBannerMCrg;
    
    '<!-- Showing update Price  -->';
  htmlBanner +='<div class="modal fade" id="myPrice" role="dialog">'+
    '<div class="modal-dialog">'+
    
      '<!-- Modal content-->'+
      '<div class="modal-content">'+
        '<div class="modal-header">'+
          '<button type="button" class="close" data-dismiss="modal">&times;</button>'+
          '<h4 class="modal-title">Update MRP </h4>'+
        '</div>'+
        '<div class="modal-body">'+
		'<h5>Quantity:&nbsp;&nbsp;<b><span id=qty></span></b></h5>'+
		'<h6>Product Name:&nbsp;&nbsp;<b><span id=iname></span></b></h6>'+
		'<h6>Days:&nbsp;&nbsp;<b><span id=days></span></b></h6>'+
		'<h6>Month:&nbsp;&nbsp;<b><span id=month></span></b></h6>'+
		'<h6>Year:&nbsp;&nbsp;<b><span id=year></span></b></h6>'+
		'<h6>Type:&nbsp;&nbsp;<b><span id=type></span></b>&nbsp;&nbsp;(1=Rent / 2=Sale )</h6>'+
         '<table class="table table-striped" id="vendorupdateprice">'+
           ' <thead id="tblHead">'+
             ' <tr>'+
               ' <th>Quantity</th>'+
                '<th>MRP</th>'+
				'<th>Base Price</th>'+
				'<th>Selling Price</th>'+
				'<th>GST</th>'+
                               
                
             ' </tr>'+
            '</thead>'+
            '<tbody>';
			
			htmlBanner+='<tr><input type="hidden" id="quantity" name="quantity">'+
			'<td><input type="Number" onkeypress="return event.charCode >= 48 && event.charCode <= 57" class="form-control controlInput" id="changequantity1" disabled min="1" name="changequantity1"></td>'+
                '<td><input type="Number" min="1"   onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" title="Only Number"  step="1" class="form-control controlInput" id="price1" name="price1"></td>'+
				'<td><input type="Number" min="1"   onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" title="Only Number"  step="1" class="form-control controlInput" id="baseprice" name="baseprice"></td>'+
				'<td><input type="Number" min="1"   onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" title="Only Number"  step="1" class="form-control controlInput sellingprice1" id="sellingprice" name="sellingprice"></td>'+
				'<td><input type="text" min="1"   onkeypress="return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46" title="Only Number"  step="1" class="form-control controlInput" id="gst" name="gst" disabled></td>'+
                       
				'<td><input type="hidden" class="form-control controlInput" id="bbatchno1" name="bbatchno1" maxlength="20"  value="1"></td>'+
                '<td><input type="hidden" id="l2omorder_id" name="l2omorder_id"></td>'+
                '<td><input type="hidden" id="item_code" name="item_code"></td>'+
                '<td><input type="hidden" id="disamount" name="disamount"></td>'+
                '<td><input type="hidden" id="baseprice" name="baseprice"></td>'+
                '<td><input type="hidden" id="sellingprice" name="sellingprice"></td>'+
                '<td><input type="hidden" id="gst" name="gst"></td>'+
				'<td><input type="hidden" id="batchcount" name="batchcount" value="1"></td>'+
			    '</tr>'+
                           '<tr><label>Calculate GST(Selling Price):</label>'+
                           '<td id="show_gst"></td>'+
			   '<select name="gstcalcualtor" id="gstdropdown" class="form-control new-status" onchange="calculateGST(this.value)">'+
                            '<option value="0.00">Calculate GST</option> '+
                            '<option value="0.05">5%</option> '+
                            '<option value="0.12">12%</option> '+
                            '<option value="0.18">18%</option> '+                                  
                    '</select>'+
                     '<td><input type="hidden" id="showprice" name="gst"></td>'+
                            '</tr>';
			
			
          htmlBanner+= ' </tbody>'+
          '</table>'+
          
		  '<button type="button" class="btn btn-primary" onclick="vendorupdateprice()" id="vendor_update_but">Update</button>'+
                  '<span id="display"></span>'+
        '</div>'+
		
        '<div class="modal-footer">'+
         ' <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>'+
        '</div>'+
      '</div>'+
      
    '</div>'+
  '</div>' + htmlBannerMCrg;
    


    //console.log(htmlBanner);
    $("#Custom_body").html("<section id='l2ordercreatediv' style='display:block;'>" + htmlBanner + "</section><section style='display:none;' id='l2orderdetailsdiv'></section>");
    $(".loader").hide();

}

function rendercompletedorder_old(response) {
    ordersdetails = response;
    htmlBanner = '<br><section class="container-fluid">' +
            '<article class="main_content">' +
            '<div class="tab-content custom_tab_content">' +
            '<div role="tabpanel" class="tab-pane fade in active">' +
            '<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
            '<div class="table-responsive">' +
            '<table id="example1" cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">' +
            '<thead>' +
            '<tr>' +
            '<th>MRN</th>' +
            '<th>Customer Name</th>' +
            '<th>Order No.</th>' +
            '<th>Order DID.</th>' +
            '<th>Work Order ID</th>' +
            '<th>Vendor Name</th>' +
            '<th>Location</th>' +
            '<th>Source</th>' +
            '<th>Order Created Date </th>' +
            '<th>Order Status</th>' +
            '<th>Order Details</th>' +
            '<th>Track</th>' +
            '<th>Re-order</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';
    if (parseInt(ordersdetails.countn) > 0) {
        $.each(ordersdetails.data, function (key, val) {
            //console.log(val._id);
            var patientname = val.order.patientinfo.name;
            patientname = patientname.replace("null", "");
            htmlBanner += '<tr><td>' + val.order.patientinfo.mrn + '</td>' +
                    '<td>' + patientname + '</td>' +
                    '<td>' + val._id + '</td>' +
                    '<td>' + val.odid + '</td>' +
                    '<td>' + val.wodid + '</td>' +
                    '<td>' + ((typeof val.order.vendorinfo == "undefined") ? "" : val.order.vendorinfo.VendorName) + '</td>' +
                    '<td>' + val.order.patientinfo.city + '</td>' +
                    '<td>' + val.order.order_status.last_updated_by + '</td>' +
                    '<td>' + val.order.order_status.created_date + '</td>' +
                    '<td>' + getOrderStatus(val.OStatus) + '</td>' +
                    '<td><a onclick="vvieworderdetails(' + val._id + ')" class="view">view</a></td>' +
                    '<td><a onclick="vordertrack(' + val._id + ')" class="track_btn">Track</a></td>' +
                    '<td><a onclick="reorderfun(' + val._id + ',1);" class="track_btn">Order</a></td><tr>';
        });
    } else {
        htmlBanner += '<tr><td colspan="12"> Data is not found.</td><tr>';
    }
    htmlBanner += '</tbody>' +
            '</table>' +
            '</div>' +
            ' </div>' +
            '</div>' +
            '</div>' +
            '</article>' +
            '<div class="modal fade in" id="l2vtrack" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">' +
            '<div class="modal-dialog" style="width:80%;">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>' +
            '<h3 class="modal-title" style="width:300px;" id="l2vtrackhead"></h3>' +
            '<label id="l2vhforhomefacility" style="width: auto;margin-top: -24px;margin-bottom: 0px;height: 21px;margin-right: 34px;" class="pull-right label label-success popup_label"></label>' +
            '</div>' +
            '<div class="modal-body" style="overflow:auto; background: #fff;" id="l2vtrackresult">' +
            '</div>' +
            '<div class="modal-footer" id="l2vtrackfooter">' +
            '<button type="button" class="btn btn-default sa-success" data-dismiss="modal" style="color:#fff;">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>'
    '</section>';
    $(".loader").hide();
    $("#l2vsearch_custom").hide();
    //$("#Custom_body").html(htmlBanner);	
    $("#l2orderdetailsdiv").css("display", "block");
    $("#l2orderdetailsdiv").html(htmlBanner);
    $("#l2ordercreatediv").css("display", "none");
}

function renderpendingorder_old(response) {
    ordersdetails = response;
    //console.log(ordersdetails);return;
    htmlBanner = '<br><section class="container-fluid">' +
            '<article class="main_content">' +
            '<div class="tab-content custom_tab_content">' +
            '<div role="tabpanel" class="tab-pane fade in active">' +
            '<div class="col-md-12 col-sm-12 col-xs-12 mp">' +
            '<div class="table-responsive">' +
            '<table id="example1" cellspacing="0" width="100%" class="display table-responsive table table-condensed table-bordered table-striped medicine_home_order_table">' +
            '<thead>' +
            '<tr>' +
            '<th>MRN</th>' +
            '<th>Order No.</th>' +
            '<th>Order DID.</th>' +
            '<th>Order Date</th>' +
            '<th>Schedule Date</th>' +
            '<th style="max-width:450px;">Items Name</th>' +
            '<th>Total Amount</th>' +
            '<th>Source</th>' +
            '<th>Status</th>' +
            '<th style="min-width:70px;">Track</th>' +
            '<th style="min-width:70px;">Edit</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';

    if (parseInt(ordersdetails.countn) > 0) {
        $.each(ordersdetails.data, function (key, val) {
            if (val.order.order_status.last_updated_by === undefined) {
                val.order.order_status.last_updated_by = "Na";
            }
            var itemname = "";
            htmlBanner += '<tr><td>' + val.order.patientinfo.mrn + '</td>' +
                    '<td>' + val._id + '</td>' +
                    '<td>' + val.odid + '</td>' +
                    '<td>' + val.order.order_status.created_date + '</td>' +
                    '<td>' + changedate(val.order.patientinfo.scheduled_date) + '</td>';
            if (typeof val.order.orderitem != "undefined" || (val.order.orderitem != null)) {
                $.each(val.order.orderitem, function (key, val1) {
                    if (val1.itemname != "" || val.OStatus == "8")
                        itemname += '' + val1.itemname + ',';
                });
            }
            htmlBanner += '<td>' + itemname + '</td>' +
                    '<td>' + val.order.patientinfo.net_amount + '</td>' +
                    '<td>' + val.order.order_status.last_updated_by + '</td>' +
                    '<td>' + getOrderStatus(val.OStatus) + '</td>' +
                    '<td><a onclick="vordertrack(' + val._id + ')" class="track_btn">Track</a></td>';
            if (val.OStatus == "17" || val.OStatus == "24" || val.OStatus == 17 || val.OStatus == 24) {
                htmlBanner += '<td><a onclick="reorderfun(' + val._id + ',0);" class="track_btn">Open</a></td></tr>';
            } else {
                htmlBanner += '<td></td></tr>';
            }
        });
    } else {
        htmlBanner += '<tr><td colspan="8"> Data is not found.</td><tr>';
    }
    htmlBanner += '</tbody>' +
            '</table>' +
            '</div>' +
            ' </div>' +
            '</div>' +
            '</div>' +
            '</article>' +
            '<div class="modal fade in" id="l2vtrack" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">' +
            '<div class="modal-dialog" style="width:80%;">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>' +
            '<h3 class="modal-title" style="width:300px;" id="l2vtrackhead"></h3>' +
            '<label id="l2vhforhomefacility" style="width: auto;margin-top: -24px;margin-bottom: 0px;height: 21px;margin-right: 34px;" class="pull-right label label-success popup_label"></label>' +
            '</div>' +
            '<div class="modal-body" style="overflow:auto; background: #fff;" id="l2vtrackresult">' +
            '</div>' +
            '<div class="modal-footer" id="l2vtrackfooter">' +
            '<button type="button" class="btn btn-default sa-success" data-dismiss="modal" style="color:#fff;">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>'
    '</section>';
    $(".loader").hide();
    $("#l2vsearch_custom").hide();
    //$("#Custom_body").html(htmlBanner);
    $("#l2orderdetailsdiv").css("display", "block");
    $("#l2orderdetailsdiv").html(htmlBanner);
    $("#l2ordercreatediv").css("display", "none");

}

function trackOrderView(result){
	var modalfooter='<button type="button" class="btn btn-default sa-success" data-dismiss="modal" style="color:#fff;">Close</button>';
	var myModalLabel="Order Tracking Status";
	var trackresult="";
	if(result.status==1){
		var tdata = ''; 
		if(result.data.order_log.length <= 0){
			tdata = '<h4>No Data</h4>';
			$('#trackresult').html(tdata);
			$('#track').modal('show');
		}else{
			tdata="<table class='table table-responsive'><thead><tr>"+
			"<th>Order</th>"+
			"<th>User Name</th>"+
			"<th>User ID</th>"+
			"<th>Role</th>"+
			"<th>Action</th>"+
			"<th>Servicing Facility Name</th>"+
			"<th>Order Status</th>"+
			"<th>Updated On</th>"+
			"<th>Text</th>"+
			"</tr></thead><tbody>";
			$.each(result.data.order_log, function (key, val) {
				tdata +='<tr><td>'+val.wodid+'</td>'+
				'<td>'+val.actionByName+'</td>'+
				'<td>'+val.actionById+'</td>'+
				'<td>'+val.role+'</td>'+
				'<td>'+val.action+'</td>'+
				'<td>'+val.popname+'</td>'+
				'<td>'+((typeof val.status_name !="undefined")?val.status_name:"")+'</td>'+
				'<td>'+val.created_date+'</td>'+
				'<td>'+val.reason+'</td></tr>';
			});
			tdata += '</tbody></table>';
			trackresult = tdata;
		}		
	}else{
		trackresult = result.message;
	}
	$(".loader").hide();
	$("#myModalLabel").html(myModalLabel);
	$("#trackresult").html(trackresult);
	$("#modalfooter").html(modalfooter);
	$("#Modal_for_all").modal('show');
}


