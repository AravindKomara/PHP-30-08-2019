<?php ob_start();session_start();
$base_url="http://172.26.7.111/";
$serverhostpath="http://172.26.7.111/";
$securl = "https://qaaccount.callhealth.com";
$sec_url = "qaaccount";
$getheaderinfo = apache_request_headers();
//print_r($getheaderinfo);exit;
$referer = $getheaderinfo["Referer"];

?>