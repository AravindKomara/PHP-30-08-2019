<!-- Modal Footer for track -->
<div class="modal fade in" id="Modal_for_all" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog" style="width:80%;">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
				<h3 class="modal-title" style="width:300px;" id="myModalLabel"></h3>
			</div>
			<div class="modal-body" style="float:left; width:100%; background: #fff;">
				<div class="col-md-12" id="trackresult">
				</div>
			</div>
			<div id="modalfooter" class="modal-footer">
				
			</div>
		</div>
	</div>
</div>
<div id="viewCompleteOrder">    
</div>
<script type="text/javascript">
	sessionStorage.setItem("loginid", "<?php echo $_SESSION["l2equp_user_id"]; ?>");
	sessionStorage.setItem("loginname", "<?php echo $_SESSION['l2equp_user_name']; ?>");
	sessionStorage.setItem("callnumber", "<?php echo $_SESSION['l2equp_patient_mobile']; ?>");
	sessionStorage.setItem("base_url", "<?php echo $base_url; ?>");
	sessionStorage.setItem("dialerpath", "<?php echo $dialerpath; ?>");
	sessionStorage.setItem("callbacklink", "<?php echo $callback_url."?paraf=".htmlentities($_SESSION['l2equp_user_name'])."&paras=".htmlentities($_SESSION['l2equp_user_id']); ?>");
</script>

<script src="js/common-config.js?v1=1.0"></script>
<script src="js/custom.js?v1=1.0"></script>
<script src="js/viewRender.js?v1=1.0"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/serverDataTables.js"></script>
<script type="text/javascript">

$(window).load(function() {
		$(".loader").hide();
});	

$(document).ready(function () {
	// Requested date
	var date = new Date();
	var tomorrow = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
	$('body').on('click','.custom_search .datepicker', function() {
		$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true				
		});
	}).on('focus','.custom_search .datepicker', function() {
		$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true
		});
	});
	
	/*$('body').on('click','#l2vsearch_custom .datepicker', function() {
		$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true,
			startDate: date
		});
	}).on('focus','#l2vsearch_custom .datepicker', function() {
		$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true,
			startDate: date
		});
	});*/
	
	$('body').on('load','#l2vsearch_custom #orderdatediv', function() {
		$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true,
			startDate: tomorrow
		});
	}).on('focus','#l2vsearch_custom #orderdatediv', function() {
		$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true,
			startDate: tomorrow
		});
		$(this).datepicker('update',$("#mainorderdate").val());
		/*$(this).datepicker({
			format: "yyyy-mm-dd",
			autoclose: true,
			startDate: tomorrow
		});*/
	});
	
	
	var patient_mobile = sessionStorage.getItem('callnumber');
	if(patient_mobile!==''){
		dashboard_widgets_render_oncall();
		patient_search("mobile",patient_mobile,100,1,patient_search_list);
	}else{
		allOrders('all_orders','allordersview',false,1,true);
		//get_allorder();
	}
	//sessionStorage.setItem("loginuserid",sessionStorage.getItem("loginid"));
	//allOrders('all_orders','allordersview',false,1,true); 	
});

$("#btnOrderSearch").click(function () {
	if ($(".custom_search").hasClass("custom_searchpre"))
		$(".custom_search").removeClass("custom_searchpre");
	else
		$(".custom_search").addClass("custom_searchpre");
});

</script>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script src="https://maps.googleapis.com/maps/api/js?signed_in=true&libraries=places&key=AIzaSyDMBANKRQ3qnYtSCUbJci_hLKaQVifW4TE&callback=initAutocomplete" async defer></script>
</body>
</html>
