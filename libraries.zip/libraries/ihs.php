<?php

class Ihs extends Oms
{
    public function __construct()
    {
        parent::__construct();
    }

    public function getname(){
        return "ihs";
    }

    function getCorporateInfo($payload){
        $mrn = $payload->mrn;
        if($payload->mrn==null || empty($payload->mrn)){
        	$response = array("status"=>0,"message"=>"Please provide mrn value");
        	return $response;
        }
        $url=$this->config->getconfig('ihspathhdfc','services/domain/GetCorporateInfo/'.$mrn);
        $result = $this->utility->my_curl($url,'GET',"",'',null,10);
      	if($result["name"]!=null){
    		$response = array("status"=>1,"message"=>"Data Found Successfully","data"=>$result);
      		return $response;
      	}else{
      		$response = array("status"=>0,"message"=>"No Data Found");
    		return $response;
      	}       
    }
	
	function updateOrderByAssociate($payload,$ticket)
	{
		$this->log->create_log("","",$this->getname(),"Execution",200,"updateOrderByAssociate_Start",json_encode($payload),(string)$ticket);
		
        if($payload->orderID=="" || !isset($payload->orderID)){
        	$response = array("status"=>0,"message"=>"Please provide orderID value");
        	return $response;
        }
        $url=$this->config->getconfig('ihspathhdfc','services/hdfc/updateOrderByAssociate');
		$payload = json_encode($payload);
		//echo $url." ".$payload;exit;
		
		//SYNCHRONOUS CALL
		/*$result = $this->utility->my_curl($url, 'POST', $payload, 'json', null, 20);
		print_R($result);exit;
      	if(strtolower($result["status"])!="error")
		{
    		$response = array("status"=>1,"message"=>"Data Found Successfully","data"=>$result);
      		return $response;
      	}else{
      		$response = array("status"=>0,"message"=>"No Data Found");
    		return $response;
      	} */

		//ASYNCHRONOUS CALL
		$this->utility->async_curl($url, $payload);	
    }

	
}