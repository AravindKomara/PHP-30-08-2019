<?php 
class Associate extends Oms { 
	
	public function getname()
	{
		return "associate";
    }
    
    public function __construct()
    {
        parent::__construct(); 
    }
	
	
		
		function get_associate_info($associates)
		{
			$this->log->create_log("","",$this->getname(),"Execution",200,"get_associate_info_start",json_encode($associates),(string)$ticket);
			
			try
			{
				
			 $associate_id_branch_id_main=array();

			 //print_r($associates);exit; 
			 foreach($associates as $associate)
			 {
				if($associate->associate_id!=null and (!isset($associate->branch_id) or $associate->branch_id!=null))
				{
					 $associate_id_branch_id_main[] = $associate->associate_id."_".$associate->branch_id;
				}
				else if($associate->associate_id!=null)
				{
					$associate_id_branch_id_main[] = $associate->associate_id;
				}
			 } 
			
			
			//print_r($associate_id_branch_id_main);exit;
			$associate_id_branch_id_main = array_values(array_unique($associate_id_branch_id_main));
			
			//STRUCTURE ASSOCIATE PAYLOAD
			if(!empty($associate_id_branch_id_main))
			{
			$associate_payload_main = array("_source"=>array("name","code","mobile","email","address",                                            "area","latlon"),
									   "query"=>array("ids"=>array("values"=>$associate_id_branch_id_main))
									  );
			}
			
			$this->log->create_log("","",$this->getname(),"Execution",200,"get_associate_info_associateCall",json_encode($associate_payload_main),(string)$ticket);
			
			$associate_payload_main = json_encode($associate_payload_main);	
			
			$sub_url = 'associate_information/_search';
			$sub_url_b2b = 'associate_information_b2b/_search';
			
			$url = $this->config->getConfig("associtepath",$sub_url); //URL to hit
			$url_b2b = $this->config->getConfig("associtepath",$sub_url_b2b); //URL to hit b2b
			
			//echo $url." ".$url_b2b;//exit;
			//https://elk-e-uat.callhealth.com/associate_info/_search'; //TOTAL URL
			
			//echo $associate_payload_main;exit;
			$output = array();
			
			if(!empty($associate_payload_main) and $associate_payload_main != 'null' and $associate_payload_main != null)
			{
				//CHECK IF NORMAL ASSOCIATE
				$buffer = $this->utility->my_curl($url,'POST',$associate_payload_main,'json',null,20);
				
				$associates_data = $buffer['hits']['hits'];
				
				//IF NOT EMPTY FETCH ALL ASSOCIATES DATA AVAILABLE AND REMOVE IT FROM associate_id_branch_id_main ARRAY
				if(!empty($associates_data) and $associates_data!=null) 
				{
					//print_r($assoicates_data);exit;
					foreach($associates_data as $associate)  
					{
						$associate_details = $associate[_source];
						if(in_array($associate[_id],$associate_id_branch_id_main))
						{
							$dummy = array();
							
							$key = array_search($associate[_id], $associate_id_branch_id_main); 
							unset($associate_id_branch_id_main[$key]);
							
							$address = $associate_details[address];
							
							//GETTING ASSOCIATE_ID, BRANCH_ID
							$ids = explode("_",$associate[_id]);
							$dummy[associate_id] = $ids[0];
							$dummy[associate_branch_id] = $ids[1];
							
							$dummy[associate_name] = $associate_details[name];
							
							$dummy[associate_address] = 
										$address[locality].",".$address[area].",".$address[city].",".
												$address[district].",".$address[state];
							
							$dummy[associate_location] = $address[locality];
							$dummy[associate_latitude] = $address[latlon][lat];
							$dummy[associate_longitude] = $address[latlon][lon];
							$dummy[associate_contact_number] = $associate_details[mobile];
							$dummy[associate_email_id] = $associate_details[email];
							$dummy[associate_website_url] = "";//NOT SPECIFIED BY API YET
							$dummy[associate_license_number] = "";//NOT SPECIFIED BY API YET
							$dummy[associate_skill] = "";//NOT SPECIFIED BY API YET
							
							$output[$associate[_id]] = $dummy;
						}		
					}
				}
				
				//IF STILL SOME ASSOCIATES LEFT SEARCH IN ASSOCIATE_B2B API
				if(!empty($associate_id_branch_id_main) and $associate_id_branch_id_main!=null)
				{
					//CALL B2B WITH ASSOCIATES THAT ARE LEFT
					$associate_id_branch_id_main = array_values($associate_id_branch_id_main);
					
					$associate_payload_main = array("_source"=>array("name","code","mobile","email","address",                                            "area","latlon"),
									   "query"=>array("ids"=>array("values"=>$associate_id_branch_id_main))
									  );
					$associate_payload_main = json_encode($associate_payload_main);	
					
					//CHECK IF B2B ASSOCIATE
					$buffer_b2b = $this->utility->my_curl($url_b2b,'POST',$associate_payload_main,'json',null,20);
				
					$associates_data_b2b = $buffer_b2b['hits']['hits'];
					
					//IF NOT IN BOTH THEN INVALID ASSOCIATE
					if(empty($associates_data_b2b) or $associates_data_b2b==null)
					{
						
						//print_r($associates_data_b2b);exit;
						$output = array("status"=>0,"message"=>implode(',',$associate_id_branch_id_main)." values not with associate api");
						
						$this->log->create_log("","",$this->getname(),"Execution",200,json_encode($output),"get_associate_info_end",(string)$ticket);	
						echo json_encode($output);
						exit;
						//return $output;
					}
					
					foreach($associates_data_b2b as $associate)  
					{
						$associate_details = $associate[_source];
						
						if(in_array($associate[_id],$associate_id_branch_id_main))
						{
							$dummy = array();
							
							$key = array_search($associate[_id], $associate_id_branch_id_main); 
							unset($associate_id_branch_id_main[$key]);
							
							$address = $associate_details[address];
							
							//GETTING ASSOCIATE_ID, BRANCH_ID
							$ids = explode("_",$associate[_id]);
							$dummy[associate_id] = $ids[0];
							$dummy[associate_branch_id] = $ids[1];
							
							$dummy[associate_name] = $associate_details[name];
							
							$dummy[associate_address] = 
										$address[locality].",".$address[area].",".$address[city].",".
												$address[district].",".$address[state];
							
							$dummy[associate_location] = $address[locality];
							$dummy[associate_latitude] = $address[latlon][lat];
							$dummy[associate_longitude] = $address[latlon][lon];
							$dummy[associate_contact_number] = $associate_details[mobile];
							$dummy[associate_email_id] = $associate_details[email];
							$dummy[associate_website_url] = "";//NOT SPECIFIED BY API YET
							$dummy[associate_license_number] = "";//NOT SPECIFIED BY API YET
							$dummy[associate_skill] = "";//NOT SPECIFIED BY API YET
							
							$output[$associate[_id]] = $dummy;
						}		
					}
					//print_r($associate_id_branch_id);
					
					$this->log->create_log("","",$this->getname(),"Execution",200,json_encode($output),"get_associate_info_end",(string)$ticket);
					
					return $output;
				}
				
				
				//print_r($associate_id_branch_id_main);
				//print_r($output);exit;
				 		
				if(!empty($associate_id_branch_id_main))
				{
					/* foreach($associate_id_branch_id_main as $a_id_b_id)
					{
					  $ids = explode("_",$a_id_b_id);
					  $dummy[associate_id] = $ids[0];
					  $dummy[associate_branch_id] = $ids[1];
					  $output[$a_id_b_id] = $dummy;
					}  */
					$output = array("status"=>0,"message"=>implode(',',$associate_id_branch_id_main)." values not with associate api");
					//print_r($output);exit;
					return $output;
					
				}
				$this->log->create_log("","",$this->getname(),"Execution",200,json_encode($output),"get_associate_info_end",(string)$ticket);
				//print_r($output);exit;			
				return $output;		
			}
			
			else
			{
				$output = array("status"=>0,"message"=>"No Associates given");
				$this->log->create_log("","",$this->getname(),"Execution",200,json_encode($output),"get_associate_info_end",(string)$ticket);
				//print_r($output);exit;			
				return $output;
			}
			
		    }

			catch(Exception $e)
			{
			  echo 'Message: ' .$e->getMessage();
			  $this->log->create_log("","",$this->getname(),"Execution",300,"Error_get_associate_info",$e->getMessage(),(string)$ticket);
			  exit;
			
			}

			
			$this->log->create_log("","",$this->getname(),"Execution",200,"function_end","get_associate_info",(string)$ticket);
		    //print_r($output);exit;			
			return $output;
		}





		function helptokencreation($payload,$ticket)
		{
			
			$this->log->create_log("","",$this->getname(),"Execution",200,"function_start","helptokencreation",(string)$ticket);
			
			try
			{
				$associate_id=$payload->associate_id; 
				$branch_id=$payload->branch_id;
				$officer_id=$payload->officer_id; 
				$officer_name=$payload->officer_name; 
				$role=$payload->role; 
				$associate_name=$payload->associate_name;
				$branch_name=$payload->branch_name;
				$role_list=array("0","5","2");
				if (!in_array($role, $role_list)){
					return array("status"=>0,"message"=>"session setting failed, Please provide the proper role.");
				}
			  
			
				$session=rand(0,999999999999);
				$filter=array('associate_id' => $associate_id,"branch_id"=>$branch_id,"officer_id"=>$officer_id,"role"=>$role);
				$set=array(
					"associate_id"=>$associate_id,
					"branch_id"=>$branch_id,
					"officer_id"=>$officer_id,
					"officer_name"=>$officer_name,
					"role"=>$role,
					"associate_name"=>$associate_name,
					"branch_name"=>$branch_name,
					"session"=>(string)$session
				);
				$log=$this->dbo->update("masters","sessions",$filter,$set,array(),array("multi"=>false,"upsert"=>true));
				
				
				$url = $this->config->getConfig("domainurl",$sub_url);
				if($role=="0")
				{ 
					$sub_url = 'escalations?session=';
				}
				else if($role=="5")
				{
					$sub_url = 'carehelp/auth/login?session=';
				}
				else if($role=="2")
				{
					$sub_url = 'carehelp/auth/login?session=';
				}
				
				if($log['ok']==1)
				{
					$response=array("status"=>1,"session"=>$session,"message"=>"session set successfully","url"=>$url.$sub_url.$session);
				}
				else
				{
					$response=array("status"=>0,"message"=>"session setting failed");
				}				
			}
			catch(Exception $e)
			{
			  echo 'Message: ' .$e->getMessage();
			  $this->log->create_log("","",$this->getname(),"Execution",300,"Error_helptokencreation",$e->getMessage(),(string)$ticket);
			}

			$this->log->create_log("","",$this->getname(),"Execution",200,"function_end","helptokencreation",(string)$ticket);
				return $response;
				
		}
		function gettokendata($payload,$ticket)
		{   
		   
			$this->log->create_log("","",$this->getname(),"Execution",200,"function_start","gettokendata",(string)$ticket);
			
			try
			{
				$token=$payload->token;
				$filter = array('session'=>(string)$token);
				
				$data = $this->dbo->findOne("masters","sessions",$filter,array());
				if(empty($data))
				{
					$data=array("status"=>0,"message"=>"Invalid Session");
					return $data;
				}
					$data['status']=1;
			}
            
            catch(Exception $e)
			{
			  echo 'Message: ' .$e->getMessage();
			  $this->log->create_log("","",$this->getname(),"Execution",300,"Error_gettokendata",$e->getMessage(),(string)$ticket);
			}

			$this->log->create_log("","",$this->getname(),"Execution",200,"function_end","gettokendata",(string)$ticket);			
			return $data;
		}
		
		
		
		 // Developed By Prasanna
   
    public function finalReport($payload, $ticket) 
	{
        $this->log->create_log("", "","report_status", "Execution", 200, "change_order_item_status_start", json_encode($payload), (string) $ticket);
	    $response = array("status" => "0", "message" => "Update Failed", "data" => '');
		
	
	//	$odid=$payload->orderNumber;
		
		foreach($payload->orderNumber as $odid){ 
			$odid = str_replace(' ', '', $odid);
		$order_filter = array('odid' => (string) $odid);
		
		$order_cursor = $this->dbo->findOne('masters', 'orders',  $order_filter, array());
		
		$orderItems=$order_cursor['order']['orderitem'];
		$i=-1;
		$itemobj=array();
		foreach($orderItems as $lineitem)
		{
			
			if((int)$lineitem[component_no]!=7  or  isset($lineitem[report_received]) )
			{
				//echo $lineitem[item_code]."-0 ";
				
			}
			else 
			{
				sleep(10);
				$lineitem[report_received]=TRUE;
				$lineitem[report_received_time]=$this->utility->getCurrentdatetimesimple();
				
				
			}
			
			array_push($itemobj,$lineitem);
		}
		
		$set= array('order.orderitem'=>$itemobj);
		$updateItems = $this->dbo->update("masters", "orders", $order_filter, $set, array(), array("multiple" => true));
		
	    array_push($update_query,array("set"=>$set,"update"=>$updateItems));
		$orderid = $order_cursor['_id'];
		$lat = $order_cursor['order']['patientinfo']['delivery_lat'];
		$lng = $order_cursor['order']['patientinfo']['delivery_lng'];
		
		
		$statusPayload = array("order_id"=>$orderid,
									"actionById"=>"CRM0",
									"actionByName"=>"CRMO",
									"source"=>"Escaltion Dashboard",
									"reasonType"=>"1",
									"latitude"=>$lat,
									"longitude"=>$lng,
									"status"=>6
									);
			$statusPayload = json_encode($statusPayload);
			
			$this->log->create_log("", "","report_status", "Execution", 200, "changeorderstatus_start", $statusPayload, (string) $ticket);
           
			
			$url = $this->config->getConfig('serverurl','OMS/api/operation.php/v1/order/change/status');

			$this->utility->async_curl($url,$statusPayload);

			$response = array("status"=>"1","message"=>"Items Updated");	
			
			$this->log->create_log("", "", "report_status", "Execution", 200, "change_order_item_status_end", json_encode($response), (string) $ticket);
		}
		    
			$this->log->create_log("", "","report_status", "Execution", 200, "changeorderstatus_start", json_encode($update_query), (string) $ticket);
			$response = array("status"=>"1","message"=>"Items Updated");
			return $response;
	}
   
   
    public function change_order_item_status($payload, $ticket) 
	{
        $this->log->create_log("", "","report_status", "Execution", 200, "change_order_item_status_start", json_encode($payload), (string) $ticket);
		
		$response = array("status" => "0", "message" => "Update Failed", "data" => '');
		
		if($payload->eventID!=70)
		{
			$response = array("status"=>"0","message"=>"Invalid Event");	
			return $response;
		}
		/* $payload->orderNumber=str_replace('[', '',$payload->orderNumber);
		$payload->orderNumber=str_replace(']', '',$payload->orderNumber);
		$payload->orderNumber=explode(",",$payload->orderNumber); */
		$receivedMessage = json_decode($payload->message)->receivedMessage;
		//print_r($payload->orderNumber);exit;
		$update_query=[];
		foreach($payload->orderNumber as $odid){
			$odid = str_replace(' ', '', $odid);
			
			//echo $odid;exit;
       // $odid = $payload->orderNumber[0];
      
       
        $order_filter = array('odid' => (string) $odid);
		//echo  json_encode($order_filter); 
       
		
		//FETCH ITEMCODES TO UPDATE REPORT FOR 
        $reportItemCodes = json_encode($receivedMessage->reportData);
        $orderItemCodesArray = json_decode($reportItemCodes, true);
		$reportItemCodes = array_column($orderItemCodesArray, 'test_codes');
		
		//UPDATE ORDERS
		/* $order_filter['order.orderitem.item_code'] = array('$in'=>$reportItemCodes);
		$order_filter['order.orderitem.report_received'] = array('$exists'=>false);
        $set = array('order.orderitem.$.report_received' => true,
					 'order.orderitem.$.report_received_time' => 
											$this->utility->getCurrentdatetimesimple()
					 ); */
        
		
		$order_cursor = $this->dbo->findOne('masters', 'orders',  $order_filter, array());
		
		$orderItems=$order_cursor['order']['orderitem'];
		$i=-1;
		$itemobj=array();
		foreach($orderItems as $lineitem)
		{
			
			if((int)$lineitem[component_no]!=7 or !in_array($lineitem[item_code],$reportItemCodes) or  isset($lineitem[report_received])  or $lineitem["diagnosticType"]== "Packages" )
			{
				//echo $lineitem[item_code]."-0 ";
				
			}
			else 
			{
				
				$lineitem[report_received]=TRUE;
				$lineitem[report_received_time]=$this->utility->getCurrentdatetimesimple();
				
				//echo $lineitem[item_code]."-1 ";
			}
			
			array_push($itemobj,$lineitem);
		}
		 
		
		
		$set= array('order.orderitem'=>$itemobj);
		$updateItems = $this->dbo->update("masters", "orders", $order_filter, $set, array(), array("multiple" => true));
		
	   array_push($update_query,array("set"=>$set,"update"=>$updateItems));
		
		$order_cursor = $this->dbo->findOne('masters', 'orders', $order_filter, array());
        // print_r($order_cursor);exit;
        if (empty($order_cursor)) 
		{
            $response = array('status' => "0",'message' => 'Order not found');
			$this->log->create_log("", "", "report_status", "Execution", 200, "change_order_item_status_end", json_encode($response), (string) $ticket);
            //return $response;
        }

		$orderid = $order_cursor['_id'];
		$lat = $order_cursor['order']['patientinfo']['delivery_lat'];
		$lng = $order_cursor['order']['patientinfo']['delivery_lng'];
				
        $orderItems = $order_cursor['order']['orderitem'];
        if (count($orderItems) <= 0) 
		{    
			$response = array('status' => "0",'message' => 'No Order Items in Order');
			$this->log->create_log("", "","report_status", "Execution", 200, "change_order_item_status_end", json_encode($response), (string) $ticket);
           // return $response;
        }
		
		//CHECK WHETHER ALL OTHER ITEMS WITH COMPONENT 7 HAVE REPORTS GENERATED => TO CHANGE ORDER STATUS  
        $items = array();
		
		
		$reportFlag = 1; //ASSUME ALL OTHER LINE ITEMS WITH COMP 7 HAVE REPORTS GENERATED
        foreach ($orderItems as $key => $value) 
		{
            if(!in_array($value['item_code'],$reportItemCodes) and (int)$value['component_no']==7) 
			{
				if(!isset($value['report_received']) or $value['report_received']!=true)
				{
					$reportFlag = 0; //IF NOT GENERATED PREVIOUSLY FLAG IS 0
				}
            }

            //$testcodeKey = array_keys(array_column($orderItemCodesArray, 'test_codes'), $value['item_code']);
            
			//$orderItems[$key]['item_status'] = $orderItemCodesArray[$testcodeKey[0]]['reports_status'];
        }

		//echo $reportFlag;exit;
		
		 if($reportFlag == 1)
		{
			//CALL CHANGE ORDER STATUS IF REPORTFLAG == 1
			$statusPayload = array("order_id"=>$orderid,
									"actionById"=>"CRM0",
									"actionByName"=>"CRMO",
									"source"=>"Escaltion Dashboard",
									"reasonType"=>"1",
									"latitude"=>$lat,
									"longitude"=>$lng,
									"status"=>6
									);
			$statusPayload = json_encode($statusPayload);
			
			$this->log->create_log("", "","report_status", "Execution", 200, "changeorderstatus_start", $statusPayload, (string) $ticket);
           
			
			$url = $this->config->getConfig('serverurl','OMS/api/operation.php/v1/order/change/status');

			$this->utility->async_curl($url,$statusPayload);

			$response = array("status"=>"1","message"=>"Items Updated");	
			
			$this->log->create_log("", "", "report_status", "Execution", 200, "change_order_item_status_end", json_encode($response), (string) $ticket);
           
		}
		
		
		
		$response = array("status"=>"1","message"=>"Items Updated");
		
	}
		//DEFAULT RESPONSE
	//	print_r($update_query);
		$this->log->create_log("", "","report_status", "Execution", 200, "changeorderstatus_start", json_encode($update_query), (string) $ticket);
		
		
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "change_order_item_status_end", json_encode($response), (string) $ticket);
        return $response;
	

        /* $order_cursor['order']['orderitem'] = $orderItems;
        $order_cursor['date'] = $payload->date;
        $order_cursor['eventDetails'] = $payload;
        $response['data'] = $order_cursor;
		
		$this->log->create_log("", "", "reports", "Execution", 200, "change_order_item_status_end", json_encode($response), (string) $ticket);
     
        return $response; */
    }

	
	 public function update_ahelp_intdb_from_oms($payload, $ticket) {
        $response = array("status" => 1, "message" => "", "data" => '');
       
        $this->log->create_log("", "", "Ahelp", "Execution", 200,  "update_ahelp_intdb_from_oms",json_encode($payload), (string) $ticket);

		$orderId = $payload->orderId;
		print_r($order_id);exit;
        $componentNo = array( "7","9");
      
        $order_filter = array(
		'OStatus'=>array('$in'=>array(6,103,102)),
		'$or' => array(array('associate_settlement' => (int) 0), array('associate_settlement' => array('$exists' => false))));
        if ($orderId) {
            $order_filter['_id'] = (int) $orderId;
        } /* else {

            
        } */
		
		$order_filter['order.orderitem.component_no'] = array('$in' => $componentNo);
		$order_filter['order.patientinfo.scheduled_date']=array('$gte'=>'2019-07-09'); 
		//$order_filter['order.orderitem.item_status'] = array('$nin' => array(8,"8"));
		$order_filter['version']=array('$in'=>array(2,3));
        $project = array(
            '_id' => 1,
            'odid' => 1,
            'order.patientinfo.scheduled_date' => 1,
            'order.patientinfo.name' => 1,
            'order.patientinfo.service_type' => 1,
            'order.patientinfo.facility_id' => 1,
            'order.provider_info.associate_id' => 1,
            'order.provider_info.associate_name' => 1,
            'order.provider_info.associate_branch_id' => 1,
            'order.orderitem.item_code' => 1,
            'order.orderitem.itemname' => 1,
            'order.orderitem.item_status' => 1,
            'order.order_status.order_status' => 1,
            'order.order_status.created_date' => 1,
            'order.order_status.order_did' => 1,
            'order.order_status.assignedto' => 1,
            'order.patientinfo.mrn' => 1,
            'order.patientinfo.pincode' => 1,
            'order.patientinfo.barcode.barcode' => 1,
            'order.patientinfo.barcode.sampleType' => 1,
            'order.patientinfo.completed_time' => 1,
            'order.orderitem.corporatereportemail' => 1,
            'order.patientinfo.sample_collection_by_vendor_date' => 1,
            'order.orderitem.reportdeliverydateto' => 1,
            'order.patientinfo.corporatename' => 1,
            'order.patientinfo.corporateid' => 1,
            'order.orderitem.net_amount' => 1,
            'order.orderitem.invoiceto' => 1,
            'order.orderitem.reportto' => 1,
            'order.orderitem.gross_amount' => 1,
            'order.orderitem.component_no' => 1
        );
		//echo json_encode($order_filter);exit;
        $order_cursor = $this->dbo->find('masters', 'orders', $order_filter, $project, array());
		
	   
        if (!$order_cursor) {
            $response['status'] = 0;
            $response['message'] = 'Invalid component details';
            return $response;
        }

        $updateIntdbData = array();
        $orderIds = array();
        foreach ($order_cursor as $orderKey => $orderValue) {
            $orderIds[] = $orderValue['_id'];
            $orderDetails = $orderValue['order'];
            $orderStatus = $orderDetails['order_status'];
            $patientInfo =(array) $orderDetails['patientinfo'];
            $providerInfo = isset($orderDetails['provider_info']) ? $orderDetails['provider_info'] : '';
            $orderItems = $orderDetails['orderitem'];
            $scheduleDate = str_replace('T', ' ', $patientInfo['scheduled_date']);
            $scheduleDate = str_replace('Z', '', $scheduleDate);
            $scheduleDate = date('Y-m-d H:i:s', strtotime($scheduleDate));
            if (count($orderItems) <= 0) {
                continue;
            }

            foreach ($orderItems as $orderItemKey => $orderItemValue) {
				
				
                if (isset($orderItemValue['component_no'])) {
                    if (!in_array($orderItemValue['component_no'], $componentNo)) {
                        continue;
                    }
					
					//echo $orderItemValue['itemname']." : ".$orderItemValue['component_no'];
					


			    }
				
				if((int)$orderItemValue['component_no']==0  )
					{
						continue; 
					}
					
					
				if($orderItemValue[item_status]=="8" or $orderItemValue[item_status]==8)
					continue;

                $sampleCollectedTime = date("Y-m-d H:i:s");//need to fix
                if (isset($patientInfo['sample_collection_by_vendor_date']) && (!empty($patientInfo['sample_collection_by_vendor_date']) && ($patientInfo['sample_collection_by_vendor_date'] != null))) {
                    $sampleCollectedTime = str_replace('T', ' ', $patientInfo['sample_collection_by_vendor_date']);
                    $sampleCollectedTime = str_replace('Z', '', $sampleCollectedTime);
                }

                $reportdeliverydateto =date("Y-m-d H:i:s"); //need to fix
                if (isset($orderItemValue['reportdeliverydateto']) && (!empty($orderItemValue['reportdeliverydateto']) && ($orderItemValue['reportdeliverydateto'] != null))) {
                    $reportdeliverydateto = str_replace('T', ' ', $orderItemValue['reportdeliverydateto']);
                    $reportdeliverydateto = str_replace('.000Z', '', $reportdeliverydateto);
                }
                
              $activeComponent = isset($orderValue['active_component']) ? $orderValue['active_component'] : '';
				$containerInfo=(isset($patientInfo['barcode']['sampleType']) && !empty($patientInfo['barcode']['sampleType'])) ? "'".json_encode($patientInfo['barcode']['sampleType']). "'" : "'NULL'";
				
				//print_r($patientInfo['barcode'][sampleType]);exit;
              $branchId = (isset($providerInfo[0]['associate_branch_id']) && $providerInfo[0]['associate_branch_id']!="" )? $providerInfo[0]['associate_branch_id'] : 0;
             // print_r($providerInfo);
				
				if($patientInfo['order_status']=="7" || $patientInfo['order_status']=="16" )
				{
					$status=7;
				}
				else if($patientInfo['order_status']=="8" || $patientInfo['order_status']=="15" )
				{
					$status=8;
				}
				else
				{
					$status=6;
				}
				$type="";
                if($patientInfo['service_type']=="2")
				{
					
					if($orderItemValue[prescription_required])
					{
						$type="2";
					}
					else
					{
						$type="1";
					}
				}
				$updateIntdbDataArray[] = array(
                    'ORDER_ID' => $orderValue['_id'],
                    'ORDER_NO' => "'" . $orderValue['odid'] . "'",
                    'SCHEDULED_DATE_time' => "'".$scheduleDate."'",
                    'SERVICE_TYPE' => ($patientInfo['service_type']) ? $patientInfo['service_type'] : 0,
                    'BRANCH_ID' => $branchId,
                    'VENDOR_CODE' => (isset($providerInfo[0]['associate_id']) && !empty($providerInfo[0]['associate_id'])) ? "'".$providerInfo[0]['associate_id']."'" : "'NULL'",
                    'VENDOR_NAME' => (isset($providerInfo[0]['associate_name']) && !empty($providerInfo[0]['associate_name'])) ? "'".$providerInfo[0]['associate_name']."'" : "'NULL'",
                    'ITEM_SERVICE_DID' => (isset($orderItemValue['item_code']) && !empty($orderItemValue['item_code'])) ? "'" . $orderItemValue['item_code'] . "'" : "'NULL'",
                    'ITEM_SERVICE_NAME' => (isset($orderItemValue['itemname']) && !empty($orderItemValue['itemname'])) ? "'" . str_replace("'", ' ', $orderItemValue['itemname']) . "'" : "'NULL'",
                    'ORDER_STATUS' => (isset($patientInfo['order_status']) && !empty($patientInfo['order_status'])) ? $status : 6,
                    'MRN' => ($patientInfo['mrn']) ? $patientInfo['mrn'] : 0,
                    'DELIVERY_PIN_CODE' => ($patientInfo['pincode']) ? $patientInfo['pincode'] : 0,
                    
                    'CURRENCY_CODE' => 56,
                    'ASSOCIATE_PROCESS_STATUS' => "'TP'", //Associate_portal
                    'CRMO_PROCESSING_STATUS' => "'TP'",
                    'BARCODE' => (isset($patientInfo['barcode']['barcode']) && !empty($patientInfo['barcode']['barcode'])) ? "'".json_encode($patientInfo['barcode']['barcode'])."'" : "'NULL'",
                    'CONTAINER_INFO' => $containerInfo, //sample type
                    'COMPLETED_DATE_TIME' => "'".date("Y-m-d H:i:s")."'",
                    
					'CORPORATE' =>(isset($patientInfo['corporatename']) && !empty($patientInfo['corporatename'])) ? "'".$patientInfo['corporatename']."'" : "'NULL'",
                    'CORPORATE_EMAIL' => (isset($orderItemValue['corporatereportemail']) && !empty($orderItemValue['corporatereportemail'])) ? "'".$orderItemValue['corporatereportemail']."'" : "'NULL'",
                    
					'SAMPLES_SUBMITTED_TIME' => "'".$sampleCollectedTime."'",
                    'ISP_ID' => (isset($orderStatus['assignedto']) && !empty($orderStatus['assignedto'])) ? "'".$orderStatus['assignedto']."'" : "'NULL'",
                    'REPORTS_SUBMITTED_TIME' => "'".$reportdeliverydateto."'",
                    'Reports_Expected_Time' => "'".$reportdeliverydateto."'",
                    'ORDER_RAISED_DATE' => isset($orderStatus['created_date']) ? "'".$orderStatus['created_date']."'" :"'".date("Y-m-d H:i:s")."'",
					
					'PATIENT_FIRST_NAME'=>"'".$patientInfo['name']."'",
					'PATIENT_MIDDLE_NAME'=>"''",
					'PATIENT_LAST_NAME'=>"''",
					'INVOICE_TO'=>($orderItemValue['invoiceto']) ? $orderItemValue['invoiceto'] : 1,
					'REPORT_TO'=>($orderItemValue['reportto']) ? $orderItemValue['reportto'] : 1,
					'CORPORATE_ID'=>(isset($patientInfo['corporateid']) && !empty($patientInfo['corporateid'])) ? "'".$patientInfo['corporateid']."'" : "'NULL'",//corporateid
					'GROSS_AMOUNT'=>($orderItemValue['gross_amount'])?$orderItemValue['gross_amount']:0,
					'NET_AMOUNT'=>($orderItemValue['net_amount'])?$orderItemValue['net_amount']:0,
					'TYPE'=>"'".$type."'"
                );
            }
        }
        
		//echo "<pre>"; print_r($updateIntdbDataArray); exit;    
        $response['data'] = $updateIntdbDataArray;
        $insertResult = $this->insertData('RTM_T_MEDI_ORDER_AHELP', $updateIntdbDataArray);
       

	  /*  $orderIds = $this->getInsertedIds('RTM_T_MEDI_ORDER_AHELP', 'ORDER_ID', $orderIds);
        if ($orderIds == false) {
            return false;
        }

        $set = array('associate_settlement' => (int) 1);
        $update_order_filter = array('_id' => array('$in' => $orderIds['ORDER_ID']));
        $updateItems = $this->dbo->update("masters", "orders", $order_filter, $set, array(), array("multi" => true)); */

        $response['data'] = $insertResult;

        return $response;
    }

    public function update_phelp_intdb_from_oms($payload, $ticket) 
    {
        $response = array("status" => 1, "message" => "", "data" => '');

        $logobj = new Logapp;
        $logobj->create_log("", "", "Phelp", "Execution", 200, "update_phelp_intdb_from_oms", json_encode($payload), (string) $ticket);
		
        $workOrderId = $payload->workOrderId;
        //print_r($workOrderId);exit;
        $dbo = new Dbo;
        $OStatus = array("5", "6","106",5,6,106,"7",8,"8",7);
		
        $order_filter = array('$or' => array(array('associate_settlement' => (int) 0), array('associate_settlement' => array('$exists' => false))));
        //echo $workOrderId;exit; 
        if ($workOrderId) 
        {
            $order_filter['_id'] = array('$in' => array((string)$workOrderId, (int)$workOrderId));
        } 
        else 
        {
            $order_filter['orderinfo.order_status'] = array('$in' => $OStatus);
        }
        $order_filter['version']=array('$in'=>array("3"));
	  $order_filter['orderinfo.component_no']=array('$exists'=>true,'$nin'=>array("3","7","9","null"));
        $project_woid = array(
            '_id' => 1,
			'wodid'=> 1, 
            'orderinfo.completed_time' => 1,
            'payment_applicable' => 1,
            'orderinfo.order_id' => 1,
			'orderinfo.associate_id' => 1,
			'orderinfo.associate_branch_id' => 1,
			'orderinfo.component_no'=> 1,
			'orderinfo.order_status' =>1,
			'orderinfo.assignedto' =>1,
			'orderinfo.assignedname' =>1
        );
		$project_wo = array(
		    '_id' => 1,
            'orderinfo.order_id' => 1,
			'orderinfo.completed_time' => 1,
            'wodid' => 1,
			'payment_applicable' => 1,
			'orderinfo.associate_id' => 1,
			'orderinfo.associate_branch_id' => 1,
			'orderinfo.component_no'=> 1,
			'orderdata.assigned_to' =>1,
			'orderinfo.assignedto' =>1,
			'orderinfo.order_status' =>1,
			'orderinfo.assignedname' =>1,
           'orderdata._id' => 1,
           'orderdata.odid' => 1,
           'orderdata.wid' => 1,
           'orderdata.wodid' => 1,
           'orderdata.order.patientinfo.scheduled_date' => 1,
           'orderdata.order.provider_info.component_no' => 1,
           'orderdata.active_component' => 1,
           'orderdata.order.patientinfo.service_type' => 1,
           'orderdata.order.patientinfo.facility_id' => 1,
           'orderdata.order.provider_info.associate_id' => 1,
           'orderdata.order.provider_info.associate_name' => 1,
           'orderdata.order.provider_info.associate_branch_id' => 1,
           'orderdata.order.orderitem.item_code' => 1,
           'orderdata.order.orderitem.itemname' => 1,
           'orderdata.order.order_status.order_status' => 1,
           'orderdata.order.order_status.created_date' => 1,
           'orderdata.order.order_status.order_did' => 1,
            'orderdata.order.order_status.assignedto' => 1,
           'orderdata.order.patientinfo.mrn' => 1,
           'orderdata.order.patientinfo.pincode' => 1,
           'orderdata.order.patientinfo.barcode.barcode' => 1, 
           'orderdata.order.orderitem.sampletype' => 1,
           'orderdata.order.patientinfo.completed_time' => 1,
           'orderdata.order.orderitem.corporatereportemail' => 1,
           'orderdata.order.patientinfo.sample_collection_by_vendor_date' => 1,
           'orderdata.order.orderitem.reportdeliverydateto' => 1,
           'orderdata.order.orderitem.component_no' => 1,
		   'orderdata.order.patientinfo.corporatename' => 1,
            'orderdata.order.patientinfo.corporateid' => 1,
            'orderdata.order.patientinfo.order_status' => 1,
            'orderdata.order.orderitem.net_amount' => 1,
            'orderdata.order.orderitem.wellness_code' => 1,
            'orderdata.order.business.package_parent_id' => 1,
            'orderdata.order.orderitem.invoiceto' => 1,
            'orderdata.order.orderitem.reportto' => 1,
            'orderdata.order.business.internal' => 1,
            'orderdata.order.orderitem.gross_amount' => 1
			
        );
		
		$lookup=array(
		        "from"=>"orders",
                 "localField"=> "orderinfo.order_id",
                 "foreignField"=> "_id",
                 "as"=>"orderdata"   
		);
		$pipeline=array(
		array('$match'=>$order_filter),array('$project'=>$project_woid),array('$lookup'=>$lookup),array('$project'=>$project_wo)
		);
		
		//echo json_encode($pipeline);exit; 
		$workOrders = $dbo->aggregate('masters', 'workorders', $pipeline);
		//print_r($workOrders);exit; 
		
		 if (!$workOrders) {
            $response['status'] = 0;
            $response['message'] = 'Order details not found.';
            return $response;
        }
		 $updateIntdbDataArray = array();
		  $workOrderIds = array();
        
           
		foreach((array)$workOrders as $workOrder)
		{//echo "<pre>";
			//print_r($workOrder);exit;
			if(!$workOrder[payment_applicable])
				continue;
			
			$orderinfo=(array)$workOrder[orderdata];
			$component=$workOrder[orderinfo][component_no];
			$providerInfo=array();
			$item=array();
			foreach($orderinfo[0][order][provider_info] as $providerInfo)
			{
				if($component == $providerInfo["component_no"])
				{
					
					break;
				}
			}
			
		//	
			
			foreach($orderinfo[0][order][orderitem] as $item)
			{
				if($component == $item["component_no"])
				{
					break;
				}
			
			}
			if(empty($item))
				continue;
			$orderinfo=$orderinfo[0];
			
            $patientInfo = $orderinfo[order]['patientinfo'];
            $orderStatus = $orderinfo[order]['order_status'];
			$branchId =( isset($providerInfo['associate_branch_id']) and$providerInfo['associate_branch_id']!=""  )? $providerInfo['associate_branch_id'] : 0;
                  //      break;
			//print_r($orderinfo);
			 $workOrderIds[] = $workOrder['_id'];
			 if($orderinfo[_id]=="" || $orderinfo[_id]==null)
				 continue;
			 
			 $orderinfo['order_status']=$workOrder[orderinfo][order_status];
			 if($orderinfo['order_status']==7 || $orderinfo['order_status']=="16" )
				{
					$status=7;
				}
				else if($orderinfo['order_status']==8 || $orderinfo['order_status']=="15" )
				{
					$status=8;
				}
				else
				{
					$status=6; 
				}
			//	echo "1";
			//echo "<pre>";
				//print_r($workOrder[orderinfo][order_status]);exit;
				/* $scheduleDate = str_replace('T', ' ', $patientInfo['scheduled_date']);
                $scheduleDate = str_replace('Z', '', $scheduleDate);
                $scheduleDate = date('Y-m-d H:i:s', strtotime($scheduleDate)); */
			 $completedTime=  $workOrder[orderinfo][completed_time];
			 
			 
			 
			
			 
			 $item_code=(isset($item['item_code']) && !empty($item['item_code'])) ? "'" . $item['item_code'] . "'" : "'NULL'";
			 
			  if(isset($orderinfo['order']['business']['package_parent_id'] ) && $orderinfo['order']['patientinfo']['service_type']=="1"){
			 
		 $item_code=(isset($item['wellness_code']) && !empty($item['wellness_code'])) ? "'" . $item['wellness_code'] . "'" : "'" . $item['item_code'] . "'";
		 
		 
		 }
			 $updateIntdbDataArray[] = array(
                    'ORDER_ID' => $orderinfo[_id],
                    'ORDER_NO' => "'" . $orderinfo['odid'] . "'",
                    'WORK_ORDER_ID' => $workOrder[_id],
                    'WORK_ORDER_NO' => "'" . $workOrder['wodid'] . "'",
                    'SCHEDULED_DATE_time' => "'".$orderinfo['order']['patientinfo']['scheduled_date']."'",
                    'SERVICE_TYPE' => (isset($orderinfo['order']['patientinfo']['service_type']) && !empty($orderinfo['order']['patientinfo']['service_type'])) ? $orderinfo['order']['patientinfo']['service_type'] : 0,
                   
                    'BRANCH_ID' => $branchId,
                    'VENDOR_CODE' => (isset($providerInfo['associate_id']) && !empty($providerInfo['associate_id']) && $providerInfo['associate_id']!=null) ? "'".$providerInfo['associate_id']."'" : "'".$workOrder[orderinfo]['assignedto']."'",
                    'VENDOR_NAME' => (isset($providerInfo['associate_name']) && !empty($providerInfo['associate_name'])) ? "'".$providerInfo['associate_name']."'" : "'NULL'",
                    'ITEM_SERVICE_DID' => $item_code,
                    'ITEM_SERVICE_NAME' => (isset($item['itemname']) && !empty($item['itemname'])) ? "'" . $item['itemname'] . "'" : "'NULL'",
                    'ORDER_STATUS' => (isset($patientInfo['order_status']) && !empty($patientInfo['order_status'])) ? $status : 6,
                    'MRN' => (isset($patientInfo['mrn']) && !empty($patientInfo['mrn'])) ? $patientInfo['mrn'] : 0,
                    'DELIVERY_PIN_CODE' => (isset($patientInfo['pincode']) && !empty($patientInfo['pincode'])) ? $patientInfo['pincode'] : 0,
                    'CURRENCY_CODE' => '0', 
                    'ASSOCIATE_PROCESS_STATUS' => "'TP'", //Associate_portal
                    'COMPLETED_DATE_TIME' => "'".$completedTime."'",
                   'CORPORATE' =>(isset($patientInfo['corporatename']) && !empty($patientInfo['corporatename'])) ? "'".$patientInfo['corporatename']."'" : "'NULL'",
				   
                    'CORPORATE_EMAIL' => (isset($item['corporatereportemail']) && !empty($item['corporatereportemail'])) ? "'".$item['corporatereportemail']."'" : "'NULL'",
                    'ISP_ID' => (isset($workOrder[orderinfo]['assignedto']) && !empty($workOrder[orderinfo]['assignedto'])) ? "'".$workOrder[orderinfo]['assignedto']."'" : "'NULL'",
                    'ORDER_RAISED_DATE' => (isset($orderStatus['created_date'])) ? "'".$orderStatus['created_date']."'" :"'".date("Y-m-d H:i:s")."'",
					
					
					'INVOICE_TO'=>($item['invoiceto']) ? $item['invoiceto'] : 1,
					'REPORT_TO'=>($item['reportto']) ? $item['reportto'] : 1,
					'CORPORATE_ID'=>(isset($patientInfo['corporateid']) && !empty($patientInfo['corporateid'])) ? "'".$patientInfo['corporateid']."'" : "'NULL'",//corporateid
					'GROSS_AMOUNT'=>$item['gross_amount'],
					'NET_AMOUNT'=>$item['net_amount'],
					'TYPE'=>"''"
					
					
                );
			//print_r($updateIntdbDataArray);exit;
			
			
			
			
		}
		//echo "<pre>";
	//	print_r($updateIntdbDataArray);exit;
	//	$response['data'] = $updateIntdbDataArray;
        $insertResult = $this->insertData('RTM_T_MEDI_ORDER_PHELP', $updateIntdbDataArray);
        //print_r($insertResult); exit;

        /* $pHelpIds = $this->getInsertedIds('RTM_T_MEDI_ORDER_PHELP', 'WORK_ORDER_ID', $workOrderIds);
        //print_r($pHelpIds);exit;
        if ($pHelpIds === false) {
            return false;
        }
        $orderIds = array_unique($pHelpIds['ORDER_ID']);
        $set = array('associate_settlement' => (int) 1);
        $update_workorder_filter = array('_id' => array('$in' => $pHelpIds['WORK_ORDER_ID']));
        $updateWorkOrders = $dbo->update("masters", "workorders", $update_workorder_filter, $set, array(), array("multi" => true));
        $update_order_filter = array('_id' => array('$in' => $orderIds));
        $updateOrders = $dbo->update("masters", "orders", $update_order_filter, $set, array(), array("multi" => true)); */
        $response['data'] = $insertResult;

        //print_r($workOrders);exit;
        return $response;
		
	}
    function totalOrders($dboTemp, $orderIds = '') {
        $project = array(
            '_id' => 1,
            'odid' => 1,
            'wid' => 1,
            'wodid' => 1,
            'order.patientinfo.scheduled_date' => 1,
            'order.provider_info.component_no' => 1,
            'active_component' => 1,
            'order.patientinfo.service_type' => 1,
            'order.patientinfo.facility_id' => 1,
            'order.provider_info.associate_id' => 1,
            'order.provider_info.associate_name' => 1,
            'order.provider_info.associate_branch_id' => 1,
            'order.orderitem.item_code' => 1,
            'order.orderitem.itemname' => 1,
            'order.order_status.order_status' => 1,
            'order.order_status.created_date' => 1,
            'order.order_status.order_did' => 1,
             'order.order_status.assignedto' => 1,
            'order.patientinfo.mrn' => 1,
            'order.patientinfo.pincode' => 1,
            'order.patientinfo.barcode.barcode' => 1,
            'order.orderitem.sampletype' => 1,
            'order.patientinfo.completed_time' => 1,
            'order.orderitem.corporatereportemail' => 1,
            'order.patientinfo.sample_collection_by_vendor_date' => 1,
            'order.orderitem.reportdeliverydateto' => 1,
            'order.orderitem.component_no' => 1,
			
        );
//s, '$or' => array(array('order.order_status.associate_settlement' => (int) 0), array('order.order_status.associate_settlement' => array('$exists' => false)))
        
		$order_filter = array("_id" => (int) $orderIds,
		"order.provider_info.component_no"=>array('$in'=>array("1","2","3","8"))
		
		);
        if (is_array($orderIds)) {
            $order_filter['_id'] = array('$in' => $orderIds);
        }
       

	//	echo json_encode($project);
	   $order_cursor = $this->dbo->find('masters', 'orders', $order_filter, $project, array());
        return $order_cursor;
    }

    function insertData($tableName, $insertData) {
        $fieldsArray = array_keys($insertData[0]);
        $fields = implode(',', $fieldsArray);
        $updateItems=array();
		$successful=array();
		$unsuccessful=array();
		//echo "<pre>";
	//	print_r($insertData);exit;
        $connect = odbc_connect("INTDB", "ordmgnt", "CallHealth@1234");
        for ($i = 0; $i < count($insertData); $i++) {
			
			/* if($i==1)
				break; */
			$insertQuery="";
			$tableValues="";
			 
			$insertQuery = "INSERT INTO " . $tableName . " (" . $fields . ") VALUES";
            $tableValues .= '(';
            $tableArrayValues = array_values($insertData[$i]);
            $tableValues .= implode(',', $tableArrayValues) . '),';
             $tableValues = rtrim($tableValues, ',');
             $insertQuery .= $tableValues;
		   

		//   print_r($insertQuery);exit;
			 $result = odbc_exec($connect, $insertQuery);
			// print_r($insertQuery);//exit;
			$error = "Query failed - " . odbc_errormsg($connect);
			// echo "<pre>";
			 if ($result) {
				
				 //print_r($insertData[$i]);
				 
				
				//echo $tableName;
				if($tableName=="RTM_T_MEDI_ORDER_AHELP")
				{
					$set = array('associate_settlement' => (int) 1);
				    $order_filter = array('_id' => (int)$insertData[$i]['ORDER_ID']);
					$updateItems[] = $this->dbo->update("masters", "orders", $order_filter, $set, array(), array("multi" => false));
					$successful[]=$insertData[$i]['ORDER_ID'];
				}
				else
				{
					//print_r( $insertData[$i]);exit;
					$set = array('associate_settlement' => (int) 1);
				    $order_filter = array('_id' =>$insertData[$i]['WORK_ORDER_ID']);
					$updateItems[] = $this->dbo->update("masters", "workorders", $order_filter, $set, array(), array("multi" => false));
					
					$successful[]=$insertData[$i]['WORK_ORDER_ID'];
					
				}
				
				 //exit;
				 
                //return $error;
            }
			else
			{
				$updateItems[]=$error.$insertQuery;
				//print_r($insertData[$i]);//exit;
				if($tableName=="RTM_T_MEDI_ORDER_AHELP")
				{
					$unsuccessful[]=$insertData[$i]['ORDER_ID'];
				}else
				{
					$unsuccessful[]=$insertData[$i]['WORK_ORDER_ID'];
				}
			}
			
			
			
			//break;
		}
       
      
		//print_r($updateItems);exit;
       
        //$columnDetails = odbc_columns($connect, "QACHINTDB", '%', $tableName,'%');
        //print_r(odbc_result_all($columnDetails));
		
        
        odbc_close($connect);
        $updateItems[unsuccessful]=$unsuccessful;
        $updateItems[successful]=$successful;
       
        return $updateItems;
    }

   /*  function getInsertedIds($tableName, $columnName, $orderIds) {
        $connect = odbc_connect("INTDB", "ordmgnt", "CallHealth@1234");
        // $truncate = "TRUNCATE TABLE ".$tableName;
         // $truncateQueryResult = odbc_exec($connect, $truncate) or die(odbc_errormsg());
        //  print_r($truncateQueryResult);exit; 
        if (!is_array($orderIds)) {
            $orderIds = array($orderIds);
        }
        $orderid = implode(',', $orderIds);
        $selectColumns = $columnName;
        if ($columnName == 'WORK_ORDER_ID') {
            $selectColumns = $columnName . ', ORDER_ID';
        }
        $newInsertedQuery = "SELECT " . $selectColumns . " FROM " . $tableName . " WHERE " . $columnName . " IN (" . $orderid . ")";
		
        $newInsertedQueryResult = odbc_exec($connect, $newInsertedQuery) or die(odbc_errormsg());
        //echo $newInsertedQuery;exit;
        $insertedOrderIds = array();
        while (false != $row = odbc_fetch_array($newInsertedQueryResult)) {
            $insertedOrderIds[$columnName][] = (int) $row[$columnName];
            if ($columnName == 'WORK_ORDER_ID') {
                $insertedOrderIds['ORDER_ID'][] = (int) $row['ORDER_ID'];
            }
        }
        odbc_close($connect);
        $insertedIds = array_unique($insertedOrderIds[$columnName]);
        $checkOrderIdsDiff = array_diff($orderIds, $insertedIds);
        $countCheckOrderIdsDiff = count($checkOrderIdsDiff);
        $countorderIds = count($orderIds);
        $countInsertedIds = count($insertedIds);
		
        if ($countorderIds == $countCheckOrderIdsDiff) {
            return false;
        }
        if ($countorderIds > $countInsertedIds) {
            $orderIds = array_intersect($orderIds, $insertedIds);
        }
        $insertedOrderIds[$columnName] = $orderIds;
		
		
		
        return $insertedOrderIds;
    } 
 */
    public function order_pods_update($payload, $ticket) {
        $response = array("status" => 1, "message" => "", "data" => '');
       
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_start", "update_phelp_intdb_from_oms", (string) $ticket);
        
        $orderId = (int) $payload->orderId;
        $workOrderId = (int) $payload->workOrderId;
        $officerId = (int) $payload->officerId;
        $project = array('_id' => 1);
        $orderPodsfilter = array('odid' => $orderId);
        $capturedDateTime = $payload->captured_date_time;
        if (!$capturedDateTime) {
            $capturedDateTime = 'null';
        } else {
            $capturedDateTime = str_replace(" ", "T", $capturedDateTime) . '.000Z';
        }

        $pushDocument = array();
        $setDocument = array();
        if (isset($payload->face_match)) {
            $setDocument['face_match'] = $payload->face_match;
        }
        if (isset($payload->logo_match)) {
            $setDocument['logo_match'] = $payload->logo_match;
        }
        if (isset($payload->uniform_match)) {
            $setDocument['uniform_match'] = $payload->uniform_match;
        }
        
        $orderPods = $this->dbo->find('masters', 'order_pods', $orderPodsfilter, array('_id' => 1), array());
        if ($orderPods) {
            $orderPodFilter = array('_id' => $orderPods[0]['_id']);
            if (isset($payload->type)) {
                $pushDocument['data'] = array(
                    'type' => $payload->type,
                    'captured_date_time' => $capturedDateTime,
                    'image_url' => isset($payload->image_url) ? $payload->image_url : 'null',
                    'capture_location' => isset($payload->capture_location) ? $payload->capture_location : 'null',
                    'capture_latitude' => $payload->capture_location_lat,
                    'capture_longitude' => $payload->capture_location_long
                );
            }
            $updateorderImage = $this->dbo->update("masters", "order_pods", $orderPodFilter, $setDocument, $pushDocument, array("multi" => true));
            return $updateorderImage;
        }


        $newUpdateDocument['odid'] = $orderId;
        $newUpdateDocument['wid'] = $workOrderId;
        $newUpdateDocument['officer_id'] = $officerId;
        $newUpdateDocument['data'] = array(
            array(
                'type' => $payload->type,
                'image_url' => isset($payload->image_url) ? $payload->image_url : 'null',
                'captured_date_time' => $capturedDateTime,
                'capture_location' => isset($payload->capture_location) ? $payload->capture_location : 'null',
				'capture_latitude' => $payload->capture_location_lat,
				'capture_longitude' => $payload->capture_location_long
            )
        );
        $insertData = $this->dbo->insert('masters', 'order_pods', $newUpdateDocument);
        return $insertData;
    }

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
}


?>