
<?php 
class Smsemail { 
	
	

function sms_gateway($request,$response)
{
	$jdcode = json_decode($request->getBody());
    $order_id = $jdcode->order_id;
	
	$db = getDBmasters();
	$collection = $db->orders;

	$eventID="55";
	$eventType="2";

	
	$cursor = $collection->find(array('order.order_status.order_id'=>$order_id)
	                            //,array('order'=>1)
								);
	
	foreach($cursor as $document)
	{
		$result[] = $document;
	}
	
	//print_r($result);exit;
	foreach($result as $each_result)
	{
		$output = array();
		
		$patientinfo = $each_result['order']['patientinfo'];
		$order_status = $each_result['order']['order_status'];
		
		
		$applicationNumber = isset($document['order']['patientinfo']['application_no'])?$document['order']['patientinfo']['application_no']:"";
		$createddate = date("d-m-Y h:i", strtotime($order_status['created_date']));
		$scdt = $patientinfo['scheduled_date'];
		$pay_type = $patientinfo['payment_method'];
		$prepaid = isset($patientinfo['prepaid'])?$patientinfo['prepaid']:"0";
		$prepaidamount = isset($each_result['order']['prepayment']['amount'])?$each_result['order']['prepayment']['amount']:"0";
		
		$pay_type = strtolower($pay_type);

		if($pay_type == 'card' || $prepaid == "1")
		{
		   $pay = 3;
		}   
		else if($pay_type == 'cod')
		{
		   $pay = 1;
		}
		else
		{
		   $pay = 0;
		}   

		$scdt1 = explode("T",$scdt);
		$scdt2 = explode("-",$scdt1[0]); 
		$scdt3 = explode(":",$scdt1[1]);

		$s_id = isset($patientinfo['service_subtype_id'])?$patientinfo['service_subtype_id']:"13";

		if($s_id == "" || $s_id == "Array" || is_array($s_id))
		{
		   $s_id = "13";
		}

		$scheduleddate = $scdt2[2]."-".$scdt2[1]."-".$scdt2[0]." ".$scdt3[0].":".$scdt3[1];
		
		//main section 1
		$main_event_detials= array();

		$main_event_details['eventID']= $eventID;
		$main_event_details['applicationID']=$applicationID;
		$main_event_details['topicID']=$topicID;
		$main_event_details['Business']= $patientinfo['service_type'];
		$main_event_details['eventType']=$eventType;
		$main_event_details['stakeHolderType']=$stakeHolderType;
		$main_event_details['stakeHolderID']=$stakeHolderID;
		$main_event_details['orderNumber']=$order_status['order_did'];
		$main_event_details['orderDateTime']=$order_status['created_date'];

		
		//main section 2
		$output['corporateId'] = ""; //corporateId
		$output['applicationNumber'] = $applicationNumber;	//applicationNumber
		$output['businessID'] = $patientinfo['service_type'];
		$output['eventDate']= $scheduleddate; //$patientinfo['scheduled_date'];
		$output['orderDate']= $order_status['created_date'];
		$output['scheduledDate']= $scheduleddate; //$patientinfo['scheduled_date'];
		$output['orderID'] = $order_status['order_id'];
		$output['orderDID'] = $order_status['order_did'];
		//$output['eventType'] = ""; //eventType
		$output['mrn'] = $patientinfo['mrn'];
		$output['pop'] = $patientinfo['facility_id'];
		$output['serviceTypeId'] = $patientinfo['service_type'];
		$output['serviceSubTypeId'] = $patientinfo['service_subtype_id'];
		$output['orderStatus'] = $order_status['order_status'];
		$output['grossAmount'] = $each_result['payment_info']['gross_amount'];
		$output['discountAmount'] = $each_result['payment_info']['discount_amount'];
		$output['netAmount'] = $each_result['payment_info']['net_amount']-$each_result['payment_info']['wallet_amount'];
		$output['amountPaid'] = $prepaidamount;//amountPaid
		$output['paymentType'] = $pay;//paymentType
		$output['sourceType'] = "Customer";
		$output['rescheduleDate'] = $patientinfo['scheduled_date'];
		
		//userdetails
		$user_details = array();
		
		$user_details['firstName'] = $patientinfo['name'];
		$user_details['lastName'] = "";//lastName
		$user_details['address1'] = $patientinfo['address'];
		$user_details['address2'] = "";//address2
		$user_details['city'] = $patientinfo['city'];
		$user_details['state'] = $patientinfo['state'];
		$user_details['pincode'] = $patientinfo['pincode'];
		$user_details['landmark'] = $patientinfo['landmark'];
		$user_details['mobileNumber'] = $patientinfo['contact'];
		$user_details['emailAddress'] = $patientinfo['email'];
		
		$output['userDetails'] = $user_details;
		
		//officer details
		$officer_details = array();
		
		$officer_details['ID'] = $patientinfo['actionById'];
		$officer_details['name'] = $patientinfo['actionByName'];
		$officer_details['latitude'] = $patientinfo['delivery_lat'];
		$officer_details['longitude'] = $patientinfo['delivery_lng'];
		
		$output['officer'] = $officer_details;

		//lineitem details
		$lineitems = array();
		foreach($each_result["order"]["orderitem"] as $orderlineitem)
		{ 
            

			if($orderlineitem['item_status']!="8")
			{ 
			if($orderlineitem['invoiceto'] == 2 || $orderlineitem['invoiceto'] == "2")
			   {
			     $orderlineitem['net_amount'] = 0;
			   } 

			
			   
			   $sub_lineitems = array("itemDID"=> $orderlineitem['item_code'],"itemName"=>$orderlineitem['itemname'],"quantity"=>$orderlineitem['quantity'],"grossAmount"=>$orderlineitem['gross_amount'],
			   "discount"=>$orderlineitem['discount_amount'],"netAmount"=>$orderlineitem['net_amount']);
			   
		    }
			else
			{
			   if($orderlineitem['invoiceto'] == 2 || $orderlineitem['invoiceto'] == "2")
			   {
			   $orderlineitem['net_amount'] = 0;
			   } 
			   
			   $sub_lineitems = array("itemName"=>$orderlineitem['itemname'],"quantity"=>$orderlineitem['quantity'],"grossAmount"=>$orderlineitem['gross_amount'],
			   "discount"=>$orderlineitem['discount_amount'],"netAmount"=>$orderlineitem['net_amount']);
			   
			}
            array_push($lineitems,$sub_lineitems);

		}
		

		$output['lineItemList'] = $lineitems;//line item list
		$output['params'] = ""; //extraData
	}
	
	/*print_r($main_event_details);
	print_r($output);
	exit;*/


	$final = array('message'=> json_encode(array('receivedMessage'=>$output)));

	$response =json_encode(array_merge($main_event_details,$final));
	echo $response;
	//return $response;
}


?>