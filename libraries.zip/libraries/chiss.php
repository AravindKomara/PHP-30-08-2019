<?php
class Chiss extends Oms
{
    public function __construct()
    {
        parent::__construct();
    }

    public function getname()
    {
        return "chiss";
    }

    public function slot($chiss_payload, $ticket)
    {
        $chiss_payload = json_encode($chiss_payload);
		//echo $chiss_payload;exit;
        $sub_url = 'api/aposlots';
        $url = $this->config->getConfig("chissurl", $sub_url); //URL to hit
        //$url = 'https://chissapouat.callhealth.com/api/apoorders'; //echo $url.$json_payload;exit;
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "slot_start", $chiss_payload, (string) $ticket);
        //CALLING THE API
        $startTime = microtime(true);
        $slots = $this->utility->my_curl($url, 'POST', $chiss_payload, 'json', null, 20);
        $this->log->logThirdPartyCall("CHISS", $url, $startTime, json_decode($chiss_payload), $slots);

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "slot_end", $slots, (string) $ticket);
        return $slots;
    }

    public function get_slot($chiss_payload, $ticket)
    {
        $chiss_payload = json_encode($chiss_payload);
        $sub_url = 'api/officerforceallotment'; //'api/fetch_apo_slots';
        $url = $this->config->getconfig("chissurl", $sub_url);
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "get_slot_start", $chiss_payload, (string) $ticket);

        $startTime = microtime(true);
        $buffer = $this->utility->my_curl($url, 'POST', $chiss_payload, 'json', null, 30);
        $this->log->logThirdPartyCall("CHISS", $url, $startTime, json_decode($chiss_payload), $buffer);

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "get_slot_end", $buffer, (string) $ticket);
        return $buffer;
    }

    public function get_officer($orders_info, $ticket)
    {
        $sub_url = "";
        $api_key = $this->config->getConfig("chissapikey", $sub_url);

        $chiss_payload = array(
            "api_key" => $api_key,
            "orders_info" => $orders_info,
        );
        $chiss_payload = json_encode($chiss_payload);
		//echo $chiss_payload;exit;

        $sub_url = 'api/apoorders';
        $url = $this->config->getConfig("chissurl", $sub_url); //URL to hit
		//echo $url." ".$chiss_payload;exit;

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "get_officer_creation_start", $chiss_payload, (string) $ticket);

        $startTime = microtime(true);
        $output = $this->utility->my_curl($url, 'POST', $chiss_payload, 'json', null, 60);
        $this->log->logThirdPartyCall("CHISS", $url, $startTime, json_decode($chiss_payload), $output);

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "get_officer_creation_end", $output, (string) $ticket);

        return $output;
    }
	
	public function get_wellness_officer($chiss_payload, $ticket)
    {
        $sub_url = "";
        $api_key = $this->config->getConfig("chissapikey", $sub_url);

        $chiss_payload["api_key"] = $api_key;
       
        $chiss_payload = json_encode($chiss_payload);

        $sub_url = 'api/package_orders';
        $url = $this->config->getConfig("chissurl", $sub_url); //URL to hit
		//$url = "http://chissdev.callhealth.com:8084/api/package_orders";
		//echo $url." ".$chiss_payload;exit;

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "get_wellness_officer_creation_start", $chiss_payload, (string) $ticket);

        $startTime = microtime(true);
        $output = $this->utility->my_curl($url, 'POST', $chiss_payload, 'json', null, 20);
        $this->log->logThirdPartyCall("CHISS", $url, $startTime, json_decode($chiss_payload), $output);

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "get_wellness_officer_creation_end", $output, (string) $ticket);

        return $output;
    }

	

    public function fetch_appointment($payload, $ticket)
    {
        $sub_url = ""; //UPDATE CONFIG FILE TO UPDATE SUB_URL to""
        $api_key = $this->config->getConfig("chissapikey", $sub_url);
        $from_date = date('Y-m-d', strtotime($payload->from_date));
        $to_date = date('Y-m-d', strtotime($payload->to_date));
        $speciality_id = $payload->speciality_id;
        $chiss_payload = array(
            "api_key" => $api_key,
            "engagement_level" => "3", //Mandatory (1-@Home,2-@center,3-@Platform)
            "from_date" => $from_date, //Mandatory
            "to_date" => $to_date,
            "speciality_id" => $speciality_id,
        );
        $chiss_payload = json_encode($chiss_payload);

        $sub_url = 'api/aposlotsbyspeciality';
        $url = $this->config->getConfig("chissurl", $sub_url); //URL to hit

        $startTime = microtime(true);
        $output = $this->utility->my_curl($url, 'POST', $chiss_payload, 'json', null, 20);
        $this->log->logThirdPartyCall("CHISS", $url, $startTime, json_decode($chiss_payload), $output);

        return $output;
    }

    public function fetch_associate_isp_data($payload, $ticket)
    {

        $sub_url = ""; //UPDATE CONFIG FILE TO UPDATE SUB_URL to""
        $api_key = $this->config->getConfig("chissapikey", $sub_url);

        $payload->api_key = $api_key;
        $chiss_payload = json_encode($payload);
        $sub_url = 'api/fetch_associate_isp_data';
        $url = $this->config->getConfig("chissurl", $sub_url); //URL to hit
        //$url = 'https://chissapouat.callhealth.com/api/fetch_associate_isp_data';    //echo $url;exit;

        $startTime = microtime(true);
        $output = $this->utility->my_curl($url, 'POST', $chiss_payload, 'json', null, 20);
        $this->log->logThirdPartyCall("CHISS", $url, $startTime, json_decode($chiss_payload), $output);

        return $output;
    }
}
