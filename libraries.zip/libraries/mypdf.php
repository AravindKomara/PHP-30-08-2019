<?php
require_once('tcpdf/config/lang/eng.php');
require_once('tcpdf/tcpdf.php');
require_once('./../constant.php');

class MYPDF extends TCPDF {			
	public function Header() {
		$headerlogoimage =	SERVER_PATH."/OMS/libraries/tcpdf/images/ch_images/header_logo.png";
		$right_top_corner =	SERVER_PATH."/OMS/libraries/tcpdf/images/ch_images/right_top_corner.png";
		// Image($file, $x='', $y='', $w=0, $h=0, $type='', $link='', $align='', $resize=false, $dpi=300, $palign='', $ismask=false, $imgmask=false, $border=0, $fitbox=false, $hidden=false, $fitonpage=false)
		//$font=$this->addTTFfont("open_sans_regular.ttf");
		//$font1=$this->addTTFfont("open_sans_bold.ttf");
		//$this->SetFont($font);
		$this->SetFont('dejavusans');	
		$this->Image($headerlogoimage, 0, -1, 44, 0, 'PNG', '', 'C', false, 300, '', false, false, 0, false, false, false);
		$this->Image($right_top_corner, 185, '', 25, 0, 'PNG', '', 'C', false, 300, '', false, false, 0, false, false, false);
		$headerData = '<br><br><table width="100%" cellpadding=0 cellspacing=0><tr><td width="51%"></td>
		<td width="49%" style="font-size:32px; line-height:5px; color:#333333;"><b>CallHealth Services Pvt Ltd.,</b></td></tr>
		<tr>
			<td></td>
			<td style="font-size:28px; line-height:5px; color:#444444;">11th Floor, Ramky Grandiose, Survey No. 136/2 & 4,
			<br>Gachibowli, Hyderabad - 5000032. Telangana, India.
			<br>Tel: 040 - 41415555. www.callhealth.com
		</td></tr>
		<tr><td></td><td style="font-size:28px; line-height:5px; color:#444444;">
			<span style="height:1px; line-height:1px; background-color:#666666;"></span>
			CIN # &nbsp; U85100TG2013PTC091009 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; HSN # &nbsp; 9993
			<br>GST # &nbsp; 36AAFCC5151Q1Z9</td>
		</tr></table>';
		$this->writeHTML($headerData);
		$this->Line(0, $this->y-2, $this->w, $this->y-2,array('color' => array(200, 200, 200)));
	}
	
	public function Footer() {
		$this->SetY(-33);
		$this->SetFont('dejavusans');
		$footerData = '<table width="100%" style="background-color:#efefef;" align="center"><tr><td width="4%"></td><td style="font-size:26px; line-height:5px; color:#444444; text-align:left;" width="92%"><br><br><u>DISCLAIMER</u><br>
		CallHealth is not responsible for acts or omissions of its suppliers, their failure to provide services of adhere to their own schedules, failure to pay any refund, delay, inconvinience, or irregularity which may be caused by any party. By accepting this cash memo, you hereby agree to release CallHealth from all claims arising out of any act of other party.<br><br></td><td width="4%"></td></tr></table>';
		$this->writeHTML($footerData);
		$footerimage =	SERVER_PATH."/OMS/libraries/tcpdf/images/ch_images/footer_ribben.png";				
		$this->Image($footerimage, 0, 285, 210, 14, 'PNG', '', '', false, 300, '', false, false, 0, false, false, false);
	}
}

class MYPDF_fordrug extends TCPDF {			
	public function Header() {
		$headerlogoimage =	SERVER_PATH."/OMS/libraries/tcpdf/images/ch_images/header_logo.png";
		$right_top_corner =	SERVER_PATH."/OMS/libraries/tcpdf/images/ch_images/right_top_corner.png";
		// Image($file, $x='', $y='', $w=0, $h=0, $type='', $link='', $align='', $resize=false, $dpi=300, $palign='', $ismask=false, $imgmask=false, $border=0, $fitbox=false, $hidden=false, $fitonpage=false)
		//$font=$this->addTTFfont("open_sans_regular.ttf");
		//$font1=$this->addTTFfont("open_sans_bold.ttf");
		//$this->SetFont($font);
		$this->SetFont('dejavusans');	
		$this->Image($headerlogoimage, 0, -1, 44, 0, 'PNG', '', 'C', false, 300, '', false, false, 0, false, false, false);
		$this->Image($right_top_corner, 185, '', 25, 0, 'PNG', '', 'C', false, 300, '', false, false, 0, false, false, false);
		$headerData = '<br><br><table width="100%" cellpadding=0 cellspacing=0><tr><td width="51%"></td>
		<td width="49%" style="font-size:32px; line-height:5px; color:#333333;"><b>CallHealth Online Services Pvt Ltd.,</b></td></tr>
		<tr>
			<td></td>
			<td style="font-size:28px; line-height:5px; color:#444444;">11th Floor, Ramky Grandiose, Survey No. 136/2 & 4,
			<br>Gachibowli, Hyderabad - 5000032. Telangana, India.
			<br>Tel: 040 - 41415555. www.callhealth.com
		</td></tr>
		<tr><td></td><td style="font-size:28px; line-height:5px; color:#444444;">
			<span style="height:1px; line-height:1px; background-color:#666666;"></span>
			CIN # &nbsp; U85100TG2013PTC091009 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; HSN # &nbsp; 9993
			<br>GST # &nbsp; 36AAFCC5151Q1Z9</td>
		</tr></table>';
		$this->writeHTML($headerData);
		$this->Line(0, $this->y-2, $this->w, $this->y-2,array('color' => array(200, 200, 200)));
	}
	
	public function Footer() {
		$this->SetY(-33);
		$this->SetFont('dejavusans');
		$footerData = '<table width="100%" style="background-color:#efefef;" align="center"><tr><td width="4%"></td><td style="font-size:26px; line-height:5px; color:#444444; text-align:left;" width="92%"><br><br><u>DISCLAIMER</u><br>
		CallHealth is not responsible for acts or omissions of its suppliers, their failure to provide services of adhere to their own schedules, failure to pay any refund, delay, inconvinience, or irregularity which may be caused by any party. By accepting this cash memo, you hereby agree to release CallHealth from all claims arising out of any act of other party.<br><br></td><td width="4%"></td></tr></table>';
		$this->writeHTML($footerData);
		$footerimage =	SERVER_PATH."/OMS/libraries/tcpdf/images/ch_images/footer_ribben.png";				
		$this->Image($footerimage, 0, 285, 210, 14, 'PNG', '', '', false, 300, '', false, false, 0, false, false, false);
	}
}

class MYPDF_forSampleCollection extends TCPDF {	
 
	public function Header() {
           // echo 'fbgfgnjyj';exit;
		$headerlogoimage =	SERVER_PATH."/OMS/libraries/tcpdf/images/ch_images/logo_2.png";
		
		$this->SetFont('dejavusans');
		$this->Image($headerlogoimage, 12, 15, 44, 0, 'PNG', '', 'L', false, 300, '', false, false, 0, false, false, false);		
		$this->Line(0, $this->y-2, $this->w, $this->y-2,array('color' => array(200, 200, 200)));
	}
	
	public function Footer() {
		$this->SetY(-33);
		$this->SetFont('dejavusans');
		$footerData = '<table width="100%" style="background-color:#efefef;" align="center"><tr><td width="4%"></td><td style="font-size:26px; line-height:5px; color:#444444; text-align:center;" width="92%"><br><br><u></u><br>
		All Rights Reserved @ 2019 <br><br></td><td width="4%"></td></tr></table>';
		$this->writeHTML($footerData);
		$footerimage =	SERVER_PATH."/OMS/libraries/tcpdf/images/ch_images/footer_ribben.png";				
		$this->Image($footerimage, 0, 285, 210, 14, 'PNG', '', '', false, 300, '', false, false, 0, false, false, false);
	}
}

class MYPDF_forPrescription extends TCPDF {	
 
	public function Header() {
             
           
		$headerlogoimage =	 SERVER_PATH."/OMS/libraries/tcpdf/images/ch_images/header_logo.png";
		$right_top_corner =	 SERVER_PATH."/OMS/libraries/tcpdf/images/ch_images/right_top_corner.png";
		// Image($file, $x='', $y='', $w=0, $h=0, $type='', $link='', $align='', $resize=false, $dpi=300, $palign='', $ismask=false, $imgmask=false, $border=0, $fitbox=false, $hidden=false, $fitonpage=false)
		//$font=$this->addTTFfont("open_sans_regular.ttf");
		//$font1=$this->addTTFfont("open_sans_bold.ttf");
		//$this->SetFont($font);
		$this->SetFont('dejavusans');	
		$this->Image($headerlogoimage, 0, -1, 44, 0, 'PNG', '', 'C', false, 300, '', false, false, 0, false, false, false);
		$this->Image($right_top_corner, 185, '', 25, 0, 'PNG', '', 'C', false, 300, '', false, false, 0, false, false, false);
		$headerData = '<br><br><table width="100%" cellpadding=0 cellspacing=0><tr><td width="51%"></td>
		<td width="49%" style="font-size:32px; line-height:5px; color:#333333;"><b>CallHealth Services Pvt Ltd.,</b></td></tr>
		<tr>
			<td></td>
			<td style="font-size:28px; line-height:5px; color:#444444;">11th Floor, Ramky Grandiose, Survey No. 136/2 & 4,
			<br>Gachibowli, Hyderabad - 5000032. Telangana, India.
			<br>Tel: 040 - 41415555. www.callhealth.com
		</td></tr>
		<tr><td></td><td style="font-size:28px; line-height:5px; color:#444444;">
			<span style="height:1px; line-height:1px; background-color:#666666;"></span>
			CIN # &nbsp; U85100TG2013PTC091009 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; HSN # &nbsp; 9993
			<br>GST # &nbsp; 36AAFCC5151Q1Z9</td>
		</tr></table>';
		$this->writeHTML($headerData);
		$this->Line(0, $this->y-2, $this->w, $this->y-2,array('color' => array(200, 200, 200)));
	}
	
	public function Footer() {
		$this->SetY(-33);
		$this->SetFont('dejavusans');
		/*$footerData = '<table width="100%" style="background-color:#efefef;" align="center"><tr><td width="4%"></td><td style="font-size:26px; line-height:5px; color:#444444; text-align:left;" width="92%"><br><br><u>DISCLAIMER</u><br>
		CallHealth is not responsible for acts or omissions of its suppliers, their failure to provide services of adhere to their own schedules, failure to pay any refund, delay, inconvinience, or irregularity which may be caused by any party. By accepting this cash memo, you hereby agree to release CallHealth from all claims arising out of any act of other party.<br><br></td><td width="4%"></td></tr></table>';
		$this->writeHTML($footerData);*/
               
		$footerimage =	 SERVER_PATH."/OMS/libraries/tcpdf/images/ch_images/footer_ribben.png";			
		$this->Image($footerimage, 0, 285, 210, 14, 'PNG', '', '', false, 300, '', false, false, 0, false, false, false);
	}
}
?>