<?php

class Mdm extends Oms
{

    public function getname()
    {
        return "mdm";
    }
	
	public function getfilename_mdmreqres()
    {
        return "mdm_req_res";
    }

    public function __construct()
    {
        parent::__construct();
    }

    public function get_line_item_info($order_item_payload)
    {
        $order_item_payload_main = $order_item_payload;
        /* $order_item_payload = array(
        'data'=>array(
        array(
        "business"=>'2',
        'itemcodes'=> array("TS02DRHBBAS0212","TS02DRHALAS0202")
        ),
        array(
        "business"=>'9',
        'itemcodes'=> array("TS1501ECNSRB00006")
        )
        )
        );      *///DUMMY ARRAY THAT WORKS, TO BE COMMENTED
		//print_r($orig_item_codes);exit;
		
        $order_item_payload = json_encode($order_item_payload);
        $url = $this->config->getconfig('mdmpath', "fetchservice/getLineItemsByServiceCodes");
        //echo $url." ".$order_item_payload;exit;
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "get_line_item_info_start", $order_item_payload, (string) $ticket);

        try
        {
            //FUNCTION TO HIT THE API FOR LINE ITEM DETAILS
            $startTime = microtime(true);
            $buffer = $this->utility->my_curl($url, 'POST', $order_item_payload, 'json', null, 10);
			//print_r($buffer);exit;
			$returned_item_codes = array_keys($buffer);
			$item_codes_without_data = array();
			
            $this->log->logThirdPartyCall("MDM", $url, $startTime, $order_item_payload_main, $buffer);

            if (array_values($buffer) == null or empty(array_values($buffer))) {
                $line_item_info = array("response" => 0, "message" => "No data Returned from MDM api");
				$this->log->create_log("", "", $this->getname(), "Execution", 200, "get_line_item_info_end", json_encode($line_item_info), (string) $ticket);
                echo json_encode($line_item_info);
                exit;
            }
			
            foreach ($buffer as $key => $item_values) {
				
				//Push the item code without data to item_codes_without_data
				if($item_values == null or empty(array_values($item_values)) 
					or array_key_exists("status",$item_values))
				{
					$item_codes_without_data[] = $key;
				}
                
                if ($item_values[businessId] == 2) {
                    $line_item_info[$key]['itemname'] = $item_values['name'];
                    //$line_item_info[$key]['quantity'] = ""; //$item_values[];
                    //$line_item_info[$key]['item_mrp'] = $item_values['mrp'];
					$line_item_info[$key]['pricePerUnit'] = $item_values['pricePerUnit'];
                    $line_item_info[$key]['pharmaname'] = ""; //$item_values[];
                    $line_item_info[$key]['prescribed'] = (int)$item_values['prescribed'];
					$line_item_info[$key]['prescription_required'] = $item_values['prescribed'];
                    $line_item_info[$key]['item_status'] = "0"; //$item_values[];
                    $line_item_info[$key]['category'] = $item_values['categoryID'];
                    $line_item_info[$key]['packsize'] = $item_values['packSizeID'];
                    $line_item_info[$key]['manufacturer_id'] = $item_values['manufacturerID'];
                    $line_item_info[$key]['manufacturer'] = $item_values['manufactureName'];
                    $line_item_info[$key]['type'] = ""; //$item_values[];
                } else {
                    if (isset($item_values['name'])) {
                        $line_item_info[$key]['itemname'] = $item_values['name'];
                    } else {
                        $line_item_info[$key]['itemname'] = $item_values['roleName'];
                    }

                    /* $line_item_info[$key]['role'] = $item_values['roleId'];
                    $line_item_info[$key]['skill'] = $item_values['skillLevel'];
					
					//SKILL IN CASE OF CARE@HOME COMES FROM DIFFERENT KEY
					if (in_array((int) $item_values[businessId], [6,7,8]))
					{
						$line_item_info[$key]['skill'] = $item_values['skillID'];
					} */

                    if (array_key_exists('continuous', $item_values)) {
                        $line_item_info[$key]['continuous'] = $item_values['continuous'];
                    }

                    //DIAGNOSTIC AND IMAGING ORDER
                    if ((int) $item_values[businessId] == 3 or (int) $item_values[businessId] == 4) {
                        if (array_key_exists('departmentName', $item_values)) {
                            $line_item_info[$key]['department'] = $item_values['departmentName'];
                            //$item_values['department'];//NOT YET AVAILABLE(int) $item_values[businessId] == 4
                        }
						
						//fastingRequired will be added if present 
						if (array_key_exists('fastingRequired', $item_values))
						{
							$line_item_info[$key]['fastingRequired'] = $item_values['fastingRequired'];
						}

						//tatHours will be added for getting report delivery date
						//NOW FROM DIFFERENT API FOR DIAGNOSTICS (businessId:3)
						if (array_key_exists('tatHours', $item_values) and (int) $item_values[businessId] == 4)
						{
							$line_item_info[$key]['tatHours'] = $item_values['tatHours'];
						}
						
						//sampleType will be added for diagnostic orders
						if (array_key_exists('sampleType', $item_values))
						{
							$line_item_info[$key]['sampleType'] = $item_values['sampleType'];
						}
						
						//diagnosticType will be added for diagnostic orders
						if (array_key_exists('diagnosticType', $item_values))
						{
							$line_item_info[$key]['diagnosticType'] = $item_values['diagnosticType'];
						}

                        //Vacutainer mandatory for diagnostic
                        if (array_key_exists('vacutainer', $item_values) and (int) $item_values[businessId] == 3) {
                            $line_item_info[$key]['vacutainer'] = $item_values['vacutainer'];
                        } else if ((int) $item_values[businessId] == 3) {
                            $line_item_info[$key]['vacutainer'] = ""; //NO VACUTAINER DETAILS RECEIVED
                        }
                    }
					
					//FOR PACKAGE ORDERS
					if((int) $item_values[businessId] == 100)
					{
						$line_item_info[$key]['itemname'] = $item_values['packageName'];
					}
					
					//FOR ECON ORDERS
					if((int) $item_values[businessId] == 1 and isset($item_values['specialityName']))
					{
						//print_r( $item_values);exit;
						$line_item_info[$key]['specialityName'] = $item_values['specialityName'];
					}

                }
				//ROLE AND SKILL
				$line_item_info[$key]['role'] = $item_values['roleId'];
				$line_item_info[$key]['skill'] = $item_values['skillLevel'];
				
				//SKILL IN CASE OF CARE@HOME COMES FROM DIFFERENT KEY
				if (in_array((int) $item_values[businessId], [6,7,8]))
				{
					$line_item_info[$key]['skill'] = $item_values['skillID'];
					$line_item_info[$key]['service_subtype_id'] = $item_values['subBusinessID'];
				}
            }
			//print_r($item_codes_without_data);exit;
            if ($item_codes_without_data != null and !empty($item_codes_without_data)) {
                $line_item_info = array("response" => 0, "message" => implode(",",$item_codes_without_data) . " doesnt have item details from MDM");
				$this->log->create_log("", "", $this->getname(), "Execution", 200, "get_line_item_info_end", json_encode($line_item_info), (string) $ticket);
                echo json_encode($line_item_info);
                exit;
            }

        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_get_line_item_info", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "get_line_item_info_end", $output, (string) $ticket);

        //print_r($line_item_info);exit;
        return $line_item_info;
    }
	
	
	public function fetch_wallet_transaction_history($payload,$ticket) 
	{
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "getWallet_Transaction_History_start", $payload, (string) $ticket);
		
		try
        {
			if (isset($payload->mrn) && $payload->mrn != "") 
			{
				
				$parameter = json_encode(array("mrn" => (string) $payload->mrn));
				$url=$this->config->getconfig('mdmpath','walletTransactions/');
				
				$buffer = $this->utility->my_curl($url, 'POST', $parameter, 'json', null, 10);
				//OR
				//$headersetcurl = array('Content-Type: application/json');
				//$result = $this->utility->common_curl($url, $parameter, 1, $headersetcurl);
				if(!empty($buffer) and $buffer!=null)
				{
					$response["status"] = 1;
					$response["message"] = "Success";
					$response["data"] = $buffer;
				}
				else
				{
					$response["status"] = 0;
					$response["message"] = "No data Returned from MDM api";
					$response["data"] = array();
				}	
			}
			else 
			{
				$response["status"] = 0;
				$response["message"] = "Invalid or No mrn";
				$response["data"] = array();
			}
		}
		
		catch (Exception $e) 
		{
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_getWallet_Transaction_History", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "getWallet_Transaction_History_end", $response, (string) $ticket);

		return $response;
	}
	
	public function checkPriceFromMDM($payload,$ticket)	{
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "checkPriceFromMDM_start", $payload, (string) $ticket);		
		try
        {
			$req_data = json_encode($payload);
			$url=$this->config->getconfig('mdmpath','domain/Order');			
			$buffer = $this->utility->my_curl($url, 'POST', $req_data, 'json', null, 10);
			//return $buffer;
			$mdm_log = array(
				"api"=>'domain/Order'
				,"requestdata"=>$req_data
				,"result"=>json_encode($buffer)
			);			
			$insert_mdm_log = $this->dbo->insert('masters','mdm_log',$mdm_log);
			
			if(strtolower($buffer['status'])=="success")
			{
				$result = array("status"=>1,"message"=>"Success","data"=>$buffer);
			}
			else
			{
				$result = array("status"=>0,"message"=>"No data Returned from MDM api");
			}
		}
		
		catch (Exception $e)
		{
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_checkPriceFromMDM", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "checkPriceFromMDM_end", $result, (string) $ticket);

		return $result;
	}
	
	//GET request
	public function getSource_of_Referral($ticket)
	{
		try
		{	
			$url=$this->config->getconfig('mdmpath','crud/entities/sourceOfOrder');
			$buffer = $this->utility->my_curl($url,'GET',"",'',null,10);
			
			if (array_values($buffer) == null or empty(array_values($buffer))) {
				$line_item_info = array("status" => 0, "message" => "No data Returned from MDM api");
			}
			else
			{
				$line_item_info = array("status" => 1, "message" => "Success","data"=>$buffer);
			}
			
			$this->log->create_log("", "", $this->getname(), "Execution", 200, "getSource_of_Referral_end", json_encode($line_item_info), (string) $ticket);
			return $line_item_info;
		}
		catch (Exception $e) 
		{
            echo 'Message:'.$e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_getSource_of_Referral", $e->getMessage(), (string) $ticket);
        }
	}
	
	public function requestForCallbackMdm($ticket)
	{
		try
		{	
			$url=$this->config->getconfig('mdmpath','fetchservice/requestForCallback');
			$buffer = $this->utility->my_curl($url,'GET',"",'',null,10);
			
			if (empty($buffer) or empty($buffer['data'])) {
				$result = array("status" => 0, "message" => "No data Returned from MDM api");
			}
			else
			{
				$result = array("status" => 1, "message" => "Success","data"=>$buffer["data"]);
			}
			
			$this->log->create_log("", "", $this->getname(), "Execution", 200, "requestForCallbackMdm_end", json_encode($result), (string) $ticket);
			return $result;
			
		}
		catch (Exception $e) 
		{
            echo 'Message:'.$e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_requestForCallbackMdm", $e->getMessage(), (string) $ticket);
        }
	}
	
	
	public function getWalletAmount($payload,$ticket)
	{
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "getWalletAmount_start",$payload, (string) $ticket);
		
		try
        {
			$mrn = $payload->mrn;
			$req_data = array();
			$url=$this->config->getconfig('mdmpath','getWalletBalance/'.$mrn);
			
			$result = $this->utility->my_curl($url,'GET',"",'',null,10);
			//OR
			//$headersetcurl = array("Content-Type: application/x-www-form-urlencoded");
			//$result = $this->utility->common_curl($url, $req_data, 0, $headersetcurl);
			
			//print_r($result);exit;
			//print_r($result[object][Balance]); exit;
			if(!empty($result) and $result!=null)
			{
				$response = array("status"=>1,"message"=>"Success");
				if($result[status]=="success"){
					$response["amount"]=$result[object][Balance];
				}else{
					$response["amount"]="0";
				}
			}
			else
			{
				$response = array("status"=>0,"message"=>"No data returned");
			}
			
			$this->log->create_log("", "", $this->getname(), "Execution", 200, "getWalletAmount_end", $response, (string) $ticket);
			
			return $response;
		}
		catch (Exception $e) 
		{
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_getWalletAmount", $e->getMessage(), (string) $ticket);
        }	
	}

	public function common_coupendetails($payload,$ticket)
	{
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "common_coupendetails_start",$payload, (string) $ticket);
		
		try
        {
		
			$coupen_name = $payload->coupen_name;
			$url=$this->config->getconfig('mdmpath','crud/fetch/couponMedicine/name/'.rawurlencode(trim($coupen_name)));
			
			$result = $this->utility->my_curl($url,'GET',"",'',null,10);
			//OR
			
			//$req_data = json_encode(array(""=>""));
			//$headersetcurl = array('Content-Type: application/json');
			//$result = $this->utility->common_curl($url,$req_data,0,$headersetcurl);
			
			
			$officerid=array("data"=>"");

			foreach($result as $data1)
			{
				if((int)$data1[businessID]==2)
				{
					$officerid["data"] = $data1;
				}
			}
			
			if(!empty($officerid["data"]) and $officerid["data"]!=null)
			{
				$response = array("status"=>1,"message"=>"Success","data"=>$officerid["data"]);
			}
			else
			{
				$response = array("status"=>0,"message"=>"No data returned");
			}
			
		}
		
		catch (Exception $e) 
		{
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_common_coupendetails", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "common_coupendetails_end", $response, (string) $ticket);
		
		// print_r($result);exit;	
		return $response;
	}
		
	
	public function fetchservice($req_data,$ticket){
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "fetchservice_start",$req_data, (string) $ticket);
		
		try{
			$url=$this->config->getconfig('mdmpath','fetchservice/entity');		
			$req_data = json_encode($req_data);			
			$buffer = $this->utility->my_curl($url, 'POST', $req_data, 'json', null, 10);
			
			if(!empty($buffer) and $buffer!=null){
				if(count($buffer[data])>0){
					$result = array("status"=>1,"message"=>$buffer[value],"data"=>$buffer[data]);
				}else{
					$result = array("status"=>0,"message"=>$buffer[value],"data"=>$buffer[data]);
				}				
			}else{				
				$result = array("status"=>0,"message"=>"No data returned","data"=>array());
			}
			
		}catch(Exception $e){
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_fetchservice", $e->getMessage(), (string) $ticket);
        }
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "fetchservice_end", $result, (string) $ticket);
		return $result;
	}
	
	public function updatewalletamtinmdm($payload,$ticket)
	{
		//$config= new config;
		//$utility = new Utility;
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "updatewalletamtinmdm_start",$payload, (string) $ticket);
		
		try
        {
		
			$url=$this->config->getconfig('mdmpath','InsertWalletTransaction');		
			$req_data = json_encode(array(		
				"key"=>$payload->transactionkey,
				"mrn"=>$payload->mrn,
				"source"=>isset($payload->source)? $payload->source : "cco",
				"createdBy"=>isset($payload->source)? $payload->source : "cco",
				"description"=>$payload->description,
				"otherParams"=>(string)$payload->orderid,
				"amount"=>"-".$payload->amount		
			));
			
			//return $url;exit;
			//return $req_data;exit;
			$this->log->create_log("", "", $this->getfilename_mdmreqres(), "Execution", 200, "updatewalletamtinmdm_start",$req_data, (string) $ticket);
			
			$buffer = $this->utility->my_curl($url, 'POST', $req_data, 'json', null, 10);
			
			$this->log->create_log("", "", $this->getfilename_mdmreqres(), "Execution", 200, "updatewalletamtinmdm_start",$buffer, (string) $ticket);
			//OR
			//$headersetcurl = array('Content-Type: application/json');
			//$result = $this->utility->common_curl($url,$req_data,1,$headersetcurl);
			//$result = json_decode($result);
			
			if(!empty($buffer) and $buffer!=null)
			{
				$result = array("status"=>1,"message"=>"Success","data"=>$buffer);
			}
			else
			{
				$result = array("status"=>0,"message"=>"No data returned");
			}
		}
		catch (Exception $e) 
		{
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_updatewalletamtinmdm", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "updatewalletamtinmdm_end", $result, (string) $ticket);

		// print_r($result);exit;
		
		return $result;
	}
	
	public function creditwalletamtinmdm($payload,$ticket)
	{
		//$config= new config;
		//$utility = new Utility;
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "creditwalletamtinmdm_start",$payload, (string) $ticket);
		
		try
        {
			$url=$this->config->getconfig('mdmpath','InsertWalletTransaction');
			
			$req_data = json_encode(
				array(		
				"key"=>$payload->transactionkey,
				"mrn"=>$payload->mrn,
				"source"=>isset($payload->source)? $payload->source : "cco",
				"createdBy"=>isset($payload->source)? $payload->source : "cco",
				"description"=>$payload->description,
				"otherParams"=>(string)$payload->orderid,
				"amount"=>"+".$payload->amount,
				"validityDate"=>date("d-M-Y", strtotime(" +3 months"))		
				)
			);
			
			//echo $url." ".$req_data;exit;
			
			$buffer = $this->utility->my_curl($url, 'POST', $req_data, 'json', null, 10);
			//OR
			//$headersetcurl = array('Content-Type: application/json');
			//$result = $this->utility->common_curl($url,$req_data,1,$headersetcurl);
			//$result = json_decode($result);
			
			if(!empty($buffer) and $buffer!=null)
			{
				$result = array("status"=>1,"message"=>"Success","data"=>$buffer);
			}
			else
			{
				$result = array("status"=>0,"message"=>"No data returned");
			}
		}
		catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_creditwalletamtinmdm", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "creditwalletamtinmdm_end", $result, (string) $ticket);

		// print_r($result);exit;
		
		return $result;
	}
	
	
	public function gettransactionkeyforwallet($payload,$ticket)
	{
		//$config= new config;
		//$utility = new Utility;
		
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "gettransactionkeyforwallet_start",$payload, (string) $ticket);
		
		try 
        {
			$url=$this->config->getconfig('mdmpath','getwallettransactionkey');
			
			$req_data = json_encode(array("mrn"=>$mrn));
			//echo $url." ".$req_data;exit;
			
			$buffer = $this->utility->my_curl($url, 'POST', $req_data, 'json', null, 10);
			
			//OR
			//$headersetcurl = array('Content-Type: application/json');
			//$result = $this->utility->common_curl($url,$req_data,1,$headersetcurl);
			//$result = json_decode($result);
			
			if(!empty($buffer) and $buffer!=null)
			{
				$result = array("status"=>1,"message"=>"Success","data"=>$buffer);
			}
			else
			{
				$result = array("status"=>0,"message"=>"No data returned");
			}
		}
		catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_gettransactionkeyforwallet", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "gettransactionkeyforwallet_end", $result, (string) $ticket);

		// print_r($result);exit;
		 return $result;
	}

	public function coupenlist_orderwise($payload,$ticket)
	{
		//$utility = new Utility;
		//$config = new Config;
		
		//$orderreq = json_decode($payload);
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "coupenlist_orderwise_start",$payload, (string) $ticket);
		
		try
        {
		
			$url=$this->config->getconfig('mdmpath','domain/ApplicableMedicineCoupons');
			$req_data = json_encode($payload);
			//echo $url." ".$req_data;exit;
			
			$buffer = $this->utility->my_curl($url, 'POST', $req_data, 'json', null, 10);
			
			//OR
			//$headersetcurl = array('Content-Type: application/json');
			//$result = $this->utility->common_curl($url,$req_data,1,$headersetcurl);
			//$result = json_decode($result);
			
			if(!empty($buffer) and $buffer!=null)
			{
				$result = array("status"=>1,"message"=>"Success","data"=>$buffer);
			}
			else
			{
				$result = array("status"=>0,"message"=>"No data returned");
			}
		}
		catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_coupenlist_orderwise", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "coupenlist_orderwise_end", $result, (string) $ticket);

		
		//print_r($result);exit;
		return $result;
	}
	
	public function isMadRulesApplied($payload,$ticket)
	{
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "isMadRulesApplied_start",json_encode($payload), (string) $ticket);
		
		try
        {
			$url=$this->config->getconfig('mdmpath','domain/isMadRulesApplied');
			$req_data = json_encode($payload);
			//echo $url." ".$req_data;exit;
			
			$buffer = $this->utility->my_curl($url, 'POST', $req_data, 'json', null, 10);
			$result = $buffer;
		}
		
		catch (Exception $e) 
		{
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_isMadRulesApplied", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "isMadRulesApplied_end", $result, (string) $ticket);

		
		//print_r($result);exit;
		return $result;
	}
	
	public function getTatHours($payload,$ticket)
	{
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "getTatHours_start",json_encode($payload), (string) $ticket);
		
		try
        {
			$url = $this->config->getconfig('mdmpath', 'fetchservice/getTATHours');
			$req_data = json_encode($payload);
			//echo $url." ".$req_data;exit;
			
			$buffer = $this->utility->my_curl($url, 'POST', $req_data, 'json', null, 10);
			$result = $buffer;
		}
		
		catch (Exception $e) 
		{
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_getTatHours", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "getTatHours_end", $result, (string) $ticket);

		
		//print_r($result);exit;
		return $result;
	}
			
	
}
