<?php

class DelhiveryExpressLibrary extends Oms {

    private $validator = '';

    public function getname() {
        return "DelhiveryExpress";
    }

    public function __construct() {
        parent::__construct();
    }

    private function DEResponse($url, $payload, $type = 'POST', $createPayload = true, $headerReq = true) {
        $response = array('error' => false, 'message' => '');
        $payload = (array) $payload;
        unset($payload['ticket']);
        if ($type == 'GET') {
            $reqParams = $payload;
            $reqParams['token'] = AUTHORIZATION;
        }

        if ($type == 'POST') {
            $reqParams = $payload;
            unset($reqParams['rawDataWithdata']);
            $reqParams = json_encode($reqParams);
        }

        if (isset($payload['rawDataWithdata'])) {
            $reqParams = 'format=json&data=' . $reqParams;
        }

        if (count($reqParams) <= 0) {
            $response['error'] = true;
            $response['data'] = "Some thing went wrong. Try after some time";
            return $response;
        }

        $headers = array(
            'Accept:application/json'
        );

        if ($headerReq) {
            $headers[] = 'Authorization:Token ' . AUTHORIZATION;
        }
        $curlResponse = $this->utility->my_curl($url, $type, $reqParams, 'json', $headers);

        if (!$curlResponse) {
            $response['error'] = true;
            $response['data'] = "Somting went wrong, Please try after some time.";
            //$response['data'] = $curlResponse;
        } else {
            $response['data'] = $curlResponse;
        }
        return $response;
    }

    private function createCurlPayload($reqParams) {
        if (!is_array($reqParams)) {
            $reqParams = (array) $reqParams;
        }
        $curlReq = array();
        if (is_array($reqParams) && count($reqParams) > 0) {
            foreach ($reqParams as $key => $value) {
                $curlReq[$key] = $value;
            }
        }
        return $curlReq;
    }

    public function getPincode($payload, $ticket,$multiplincode) {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_start", "getpincodes", (string) $ticket);
        $response = array("status" => 1, "message" => "", "data" => '');
		$payload=(object)$payload;
        $url = DELHIVERYTESTURL . 'c/api/pin-codes/json/?';
        $is_invalidpincode = 0;
		$totalpincode = 0;
		if($multiplincode==true){
			if ($payload->filter_codes) {
				$pincodes = explode(",", $payload->filter_codes);
				if(count($pincodes)<1){
					$response['status'] = 0;
					$response['message'] = "Please enter the valid pincode.";
					return $response;
				}
				foreach ($pincodes as $pincodechech) {
					if (!(preg_match("/^\d{6,8}$/", $pincodechech))) {
						$is_invalidpincode = 1;
						break;
					}
					$totalpincode = $totalpincode + 1;
				}
			}
			if($is_invalidpincode==1){
				$response['status'] = 0;
				//$response['message']['dt'] = "Please enter valid pincode";
				$response['message'] = "Please enter the valid pincode.";
				return $response;
			}else{
				$parameters['filter_codes'] = $payload->filter_codes;
			}
		}else{
			 if (!(preg_match("/^\d{6,8}$/", $payload->filter_codes))) {
				$response['status'] = 0;
				$response['message'] = "Please enter the valid pincode.";
				return $response;
			}
			$parameters['filter_codes'] = $payload->filter_codes;
			$totalpincode = 1;
		}
        // end for multiple pincode 

        if ($payload->dt) {
            if (preg_match("/(\d{4})\-(\d{2})\-(\d{2})$/", $payload->dt)) {
                $parameters['dt'] = $payload->dt;
            } else {
                $response['status'] = 0;
                $response['message'] = "Please enter the valid date format.";
                return $response;
            }
        }

        if ($payload->st) {
            if (preg_match('/[A-Z]{2}$/', $payload->st)) {
                $parameters['st'] = $payload->st;
            } else {
                $response['status'] = 0;
                $response['message'] = "Please enter the valid state code.";
                return $response;
            }
        }
        $DBResponse = $this->DEResponse($url, $payload, 'GET', true, false);
        
        if ($DBResponse['error'] === true || (!isset($DBResponse['data']['delivery_codes']))) {
            $response['status'] = 0;
            $response['message'] = 'Somthing went wrong, please try after some time.';
            return $response;
        }
        
        if(count($DBResponse['data']['delivery_codes']) <= 0){
            $response['status'] = 0;
            $response['message'] = 'Sorry! This location is not serviceable.';			
        }else{
			if($totalpincode!=count($DBResponse['data']['delivery_codes'])){
				$response['status'] = 0;
				$response['message'] = 'Sorry! This location is not serviceable.';
				$response['data'] = $DBResponse['data']['delivery_codes'];
			}else{
				$response['message'] = 'This location is serviceable.';
				$response['data'] = $DBResponse['data']['delivery_codes'];
			}
        }
        return $response;
    }

    public function createWarehouse($payload, $ticket) {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_start", "createwarehouse", (string) $ticket);
        $response = array("status" => 1, "message" => "", "data" => '');

        $payload = (array) $payload;

        $warehouseFilter = array('name' => (string) $payload['name']);
        $checkWHAvailable = $this->dbo->find('masters', 'logistic_warehouse_list', $warehouseFilter, array(), array());
        if ($checkWHAvailable) {
            $response['message'] = 'Warehouse already exist with same name';
            $response['status'] = 0;
            return $response;
        }

        $vendor_code = $payload['vendor_code'];
        unset($payload['vendor_code']);

        $url = DELHIVERYTESTURL . 'api/backend/clientwarehouse/create/';
        $DBResponse = $this->DEResponse($url, $payload);
        if ($DBResponse['error'] === true) {
            $response['status'] = 0;
            $response['message'] = $DBResponse['data'];
            return $response;
        }
        $DBResponse = $DBResponse['data'];
        if ($DBResponse['success'] === false) {
            $response['status'] = 0;
            $response['message'] = $DBResponse['error'];
            return $response;
        }

        $this->delhiveryLog($payload['name'], 'warehouse', $url, 'POST', $payload, $DBResponse);

        $warehouseDoc = (array) $DBResponse['data'];
        $warehouseDoc['country'] = $payload['country'];
        $warehouseDoc['email'] = $payload['email'];
        $warehouseDoc['contact_person'] = $payload['contact_person'];
        $warehouseDoc['registered_name'] = $payload['registered_name'];
        $warehouseDoc['return_address'] = $payload['return_address'];
        $warehouseDoc['return_pin'] = $payload['return_pin'];
        $warehouseDoc['return_city'] = $payload['return_city'];
        $warehouseDoc['return_state'] = $payload['return_state'];
        $warehouseDoc['return_country'] = $payload['return_country'];
        $warehouseDoc['vendor_code'] = $vendor_code;
        $insertData = $this->dbo->insert('masters', 'logistic_warehouse_list', $warehouseDoc);

        $response['message'] = 'Success';
        $response['data'] = $DBResponse['data'];

        return $response;
    }

    public function updateWarehouse($payload, $ticket) {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_start", "updatewarehouse", (string) $ticket);
        $response = array("status" => 1, "message" => "", "data" => '');
        $url = DELHIVERYTESTURL . 'api/backend/clientwarehouse/edit/';

        $warehouseFilter = array('name' => (string) $payload->name);
        $checkWHAvailable = $this->dbo->find('masters', 'logistic_warehouse_list', $warehouseFilter, array(), array());
        if (!$checkWHAvailable) {
            $response['message'] = 'Warehouse doesn`t exist.';
            $response['status'] = 0;
            return $response;
        }
        $checkWHAvailable = $checkWHAvailable[0];
        unset($checkWHAvailable['_id']);
        $DBResponse = $this->DEResponse($url, $payload);

        if ($DBResponse['error'] === true) {
            $response['status'] = 0;
            $response['message'] = $DBResponse['data'];
        }

        $DBResponse = $DBResponse['data'];
        if ($DBResponse['success'] === false) {
            $response['status'] = 0;
            $response['message'] = $DBResponse['error'];
            return $response;
        }

        $this->delhiveryLog($payload->name, 'warehouseupdate', $url, 'POST', $payload, $DBResponse);

        $payload = (array) $payload;
        $checkWHAvailable['name'] = (isset($payload['name']) && ($payload['name'] != '')) ? $payload['name'] : $checkWHAvailable['name'];
        $checkWHAvailable['pincode'] = (isset($payload['pin']) && ($payload['pin'] != '')) ? $payload['pin'] : $checkWHAvailable['pincode'];
        $checkWHAvailable['country'] = (isset($payload['country']) && ($payload['country'] != '')) ? $payload['country'] : $checkWHAvailable['country'];
        $checkWHAvailable['address'] = (isset($payload['address']) && ($payload['address'] != '')) ? $payload['address'] : $checkWHAvailable['address'];
        $checkWHAvailable['phone'] = (isset($payload['phone']) && ($payload['phone'] != '')) ? $payload['phone'] : $checkWHAvailable['phone'];
        $checkWHAvailable['email'] = (isset($payload['email']) && ($payload['email'] != '')) ? $payload['email'] : $checkWHAvailable['email'];
        $checkWHAvailable['contact_person'] = (isset($payload['contact_person']) && ($payload['contact_person'] != '')) ? $payload['contact_person'] : $checkWHAvailable['contact_person'];
        $checkWHAvailable['registered_name'] = (isset($payload['registered_name']) && ($payload['registered_name'] != '')) ? $payload['registered_name'] : $checkWHAvailable['registered_name'];
        $checkWHAvailable['return_address'] = (isset($payload['return_address']) && ($payload['return_address'] != '')) ? $payload['return_address'] : $checkWHAvailable['return_address'];
        $checkWHAvailable['return_pin'] = (isset($payload['return_pin']) && ($payload['return_pin'] != '')) ? $payload['return_pin'] : $checkWHAvailable['return_pin'];
        $checkWHAvailable['return_city'] = (isset($payload['return_city']) && ($payload['return_city'] != '')) ? $payload['return_city'] : $checkWHAvailable['return_city'];
        $checkWHAvailable['return_state'] = (isset($payload['return_state']) && ($payload['return_state'] != '')) ? $payload['return_state'] : $checkWHAvailable['return_state'];
        $checkWHAvailable['return_country'] = (isset($payload['return_country']) && ($payload['return_country'] != '')) ? $payload['return_country'] : $checkWHAvailable['return_country'];
        $checkWHAvailable['working_hours'] = $DBResponse['data']['working_hours'];

        unset($checkWHAvailable['warehouse_updates']);

        $updateWarehouseReqResp = array(
            "warehouse_updates" => array(
                "request" => $payload,
                "response" => $DBResponse
            )
        );
        $updateResult = $this->dbo->update("masters", "logistic_warehouse_list", $warehouseFilter, $checkWHAvailable, $updateWarehouseReqResp, array("multi" => true));

        $response['message'] = $DBResponse['error'];
        $response['data'] = $DBResponse;
        return $response;
    }

    public function bulkWayBills($payload, $ticket) {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_start", "updatewarehouse", (string) $ticket);
        $response = array("status" => 1, "message" => "", "data" => '');
        $url = DELHIVERYTESTURL . 'waybill/api/bulk/json/?';
        $DBResponse = $this->DEResponse($url, $payload, 'GET', false);

        if ($DBResponse['error'] === false) {
            $response['message'] = 'Success';
            $response['data'] = $DBResponse['data'];
        } else {
            $response['status'] = 0;
            $response['message'] = $DBResponse['data'];
        }

        return $response;
    }

    public function singleWayBill($payload, $ticket) {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_start", "updatewarehouse", (string) $ticket);
        $response = array("status" => 1, "message" => "", "data" => '');
        $url = DELHIVERYTESTURL . 'waybill/api/fetch/json/?';
        $DBResponse = $this->DEResponse($url, $payload, 'GET', false);

        if ($DBResponse['error'] === false) {
            $response['message'] = 'Success';
            $response['data'] = $DBResponse['data'];
        } else {
            $response['status'] = 0;
            $response['message'] = $DBResponse['data'];
        }

        return $response;
    }

    public function createOrder($payload, $ticket) {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_start", "updatewarehouse", (string) $ticket);
        $response = array("status" => 1, "message" => "", "data" => '');
        $url = DELHIVERYTESTURL . 'api/cmu/create.json';
        $orderId = (int) $payload->order_id;

        // Check for order exist or not
        $orderFilter = array(
            '_id' => (int) $orderId
        );
        $checkOrderDetails = $this->dbo->find('masters', 'orders', $orderFilter, array(), array());

        if (!$checkOrderDetails) {
            $response['status'] = 0;
            $response['message'] = "Order details doesn`t exist.";
            return $response;
        }

        $orderDetails = $checkOrderDetails[0];
        $orderPatientInfo = $orderDetails['order']['patientinfo'];
        $providerInfo = $orderDetails['order']['provider_info'];
        $providerInfo = $providerInfo[count($providerInfo) - 1];
        $paymentInfo = $orderDetails['order']['payment_info'];
        $orderStatus = $orderDetails['order']['order_status'];
        $orderItems = $orderPatientInfo['orderitem'];
        // check for the pincode
        $payload->filter_codes = $orderPatientInfo['pincode'];
        $checkPinCode = $this->getPincode($payload, $ticket);
        if ($checkPinCode['status'] == 0) {
            return $checkPinCode;
        }
        
        $service_type = 'medicine';
        if($orderPatientInfo['service_type'] == "3" || $orderPatientInfo['service_type'] == "4"){
        $service_type = 'report';    
        }
        
        $checkWareHouseFilter = array('service_type' => (string) $service_type);
        $checkWareHouse = $this->dbo->find('masters', 'logistic_warehouse_list', $checkWareHouseFilter, array(), array());
         if (!$checkWareHouse) {
            $response['status'] = 0;
            $response['message'] = "Warehouse doesn`t exist.";
            return $response;
        }
        $orderPayLoad = array(
            "pickup_location" => array(
                "name" => $checkWareHouse[0]['name']
                //"name" => "chwhv5"
            ),
            "shipments" => array(
                array(
                    "return_name" => isset($checkWareHouse['registered_name']) ? $checkWareHouse['registered_name'] : "",
                    "return_pin" => isset($checkWareHouse['return_pin']) ? $checkWareHouse['return_pin'] : "",
                    "return_city" => isset($checkWareHouse['return_city']) ? $checkWareHouse['return_city'] : "",
                    "return_phone" => isset($checkWareHouse['mobile']) ? $checkWareHouse['mobile'] : "",
                    "return_add" => isset($checkWareHouse['return_address']) ? $checkWareHouse['return_address'] : "",
                    "return_state" => isset($checkWareHouse['return_state']) ? $checkWareHouse['return_state'] : "",
                    "return_country" => isset($checkWareHouse['return_country']) ? $checkWareHouse['return_country'] : "",
                    "order" => $orderDetails['_id'],
                    "phone" => $orderPatientInfo['contact'],
                    "products_desc" => "",
                    "cod_amount" => $orderPatientInfo['net_amount'],
                    "name" => $orderPatientInfo['name'],
                    "country" => "India",
                    "seller_inv_date" => "",
                    "order_date" => $orderStatus['created_date'],
                    "total_amount" => $orderPatientInfo['net_amount'],
                    "pin"=> $orderPatientInfo['pincode'],
                    'add' => $orderPatientInfo['address'],
                    "quantity" => "1",
                    "payment_mode" => "COD",
                    "state" => $orderPatientInfo['state'],
                    "city" => $orderPatientInfo['city'],
                )
            )
        );
        // Create Order
        $orderPayLoad['rawDataWithdata'] = true;
        $DBResponse = $this->DEResponse($url, $orderPayLoad);
        // If error getting form curl
        if ($DBResponse['error'] === true) {
            $response['status'] = 0;
            $response['message'] = $DBResponse['data'];
            return $response;
        }

        // If order doesn`t created from Delhivery Express by any reason
        $DBResponse = $DBResponse['data'];
        if ($DBResponse['success'] === false) {
            $response['message'] = $DBResponse['packages'][0]['remarks'];
            $response['status'] = 0;
            return $response;
        }

        $orderType = "createorder";
        if ($orderPayLoad['shipments'][0]['payment_mode'] == 'Pickup') {
            $orderType = "returnorder";
        }

        $this->delhiveryLog($orderId, $orderType, $url, 'POST', $orderPayLoad, $DBResponse);

        $setDocument = array(
            'waybill_no' => $DBResponse['packages'][0]['waybill'],
            'delhiveryOrderStatus' => 'Order created',
            'delhivery_details' => array($DBResponse)
        );
        $updateResult = $this->dbo->update("masters", "orders", $orderFilter, $setDocument, array(), array("multi" => true));

		//UPDATE PROVIDERINFO
		//$this->updateDelhiveryComponent($orderId);
		
        $response['data'] = $DBResponse;
        $response['message'] = 'Order Created Successfully';
        return $response;
    }
	
	public function updateDelhiveryComponent($orderId){
		//Fetch DelhiveryAssociateDetails
		$filter = array("_id"=>$orderId);
		$provider = $this->dbo->find('masters','logistic_partners',$filter,array("_id"=>0));
		$provider = $provider[0];
		
		//UPDATE IN COMPONENT "13"
		$filter = array("_id"=>$orderId,"order.provider_info.component_no"=>"13");
		$set = array();
		foreach($provider as $key=>$value)
		{
			$set["order.provider_info.$.".$key] = $value;
		}
		$updateResult = $this->dbo->update("masters", "orders", $filter, $set, array(), array("multiple" => true));
		return $updateResult;
	}

    public function updateOrder($payload, $ticket) {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_start", "updatewarehouse", (string) $ticket);
        $response = array("status" => 1, "message" => "", "data" => '');
        $url = DELHIVERYTESTURL . 'api/p/edit';
        $orderId = (int) $payload->orderId;
        // Check for order exist or not
        $orderFilter = array('$and' => array(array('_id' => $orderId), array('delhivery_details' => array('$exists' => true))));

        $checkOrderDetails = $this->dbo->find('masters', 'orders', $orderFilter, array(), array());

        if (!$checkOrderDetails) {
            $response['status'] = 0;
            $response['message'] = "Order details doesn`t exist.";
            return $response;
        }

        unset($payload->orderId);
        $DBResponse = $this->DEResponse($url, $payload);

        // If error getting form curl
        if ($DBResponse['error'] === true) {
            $response['status'] = 0;
            $response['message'] = $DBResponse['data'];
            return $response;
        }

        // If order doesn`t created from Delhivery Express by any reason
        $DBResponse = $DBResponse['data'];
        if ($DBResponse['status'] == 'Failure') {
            $response['message'] = $DBResponse['error'];
            $response['status'] = 0;
            return $response;
        }

        $this->delhiveryLog($orderId, 'updateorder', $url, 'POST', $payload, $DBResponse);

        $pushDocument = array(
            'delhivery_details' => $DBResponse
        );
        $updateResult = $this->dbo->update("masters", "orders", $orderFilter, array(), $pushDocument, array("multi" => true));

        $response['data'] = $DBResponse;
        $response['message'] = 'Order Created Successfully';
        return $response;

        return $response;
    }

    public function cancelOrder($payload, $ticket) {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_start", "updatewarehouse", (string) $ticket);
        $response = array("status" => 1, "message" => "", "data" => '');
        $url = DELHIVERYTESTURL . 'api/p/edit';

        $orderId = (int) $payload->orderId;
        // Check for order exist or not
        $orderFilter = array('_id' => $orderId);
        $checkOrderDetails = $this->dbo->find('masters', 'orders', $orderFilter, array(), array());

        if (!$checkOrderDetails) {
            $response['status'] = 0;
            $response['message'] = "Order details doesn`t exist.";
            return $response;
        }

        $DBResponse = $this->DEResponse($url, $payload);
        //print_r($DBResponse);
        if ($DBResponse['error'] === true) {
            $response['status'] = 0;
            $response['message'] = $DBResponse['data'];
            return $response;
        }

        // If order doesn`t cancelled from Delhivery Express by any reason
        $DBResponse = $DBResponse['data'];
        if ($DBResponse['status'] === 'Failure') {
            $response['message'] = $DBResponse['error'];
            $response['status'] = 0;
            return $response;
        }

        $this->delhiveryLog($orderId, 'cancelorder', $url, 'POST', $payload, $DBResponse);

        $setDocument = array(
            'delhiveryOrderStatus' => 'Order Cancelled Successfully',
        );
        $pushDocument = array(
            'delhivery_details' => array($DBResponse)
        );
        $updateResult = $this->dbo->update("masters", "orders", $orderFilter, $setDocument, $pushDocument, array("multi" => true));

        $response['data'] = $DBResponse;
        $response['message'] = 'Order Created Successfully';
        return $response;
    }

    

    public function shippingChargesInvoice($payload, $ticket) {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_start", "updatewarehouse", (string) $ticket);
        $response = array("status" => 1, "message" => "", "data" => '');
        $url = DELHIVERYTESTURL . 'api/kinko/v1/invoice/charges/.json?';

        $payload->cl = CLIENTNAME;
        $DBResponse = $this->DEResponse($url, $payload, 'GET', false);

        if ($DBResponse['error'] === true) {
            $response['status'] = 0;
            $response['message'] = $DBResponse['data'];
            return $response;
        }

        $DBResponse = $DBResponse['data'];
        if (isset($DBResponse['error'])) {
            $response['status'] = 0;
            $response['message'] = $DBResponse['error'];
            return $response;
        }

        $response['message'] = 'Sccess';
        $response['data'] = $DBResponse;
        return $response;
    }

    public function createPackageSlip($payload, $ticket) {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_start", "updatewarehouse", (string) $ticket);
        $response = array("status" => 1, "message" => "", "data" => '');
        $url = DELHIVERYTESTURL . 'api/p/packing_slip?';

        // Check for order exist or not
        $orderFilter = array('_id' => (int) $payload->orderId);
        $checkOrderDetails = $this->dbo->find('masters', 'orders', $orderFilter, array(), array());

        if (!$checkOrderDetails) {
            $response['status'] = 0;
            $response['message'] = "Order details doesn`t exist.";
            return $response;
        }

        $DBResponse = $this->DEResponse($url, $payload, 'GET', false);

        if ($DBResponse['error'] === true) {
            $response['status'] = 0;
            $response['message'] = $DBResponse['data'];
        }

        $DBResponse = $DBResponse['data'];
        if (isset($DBResponse['error'])) {
            $response['status'] = 0;
            $response['message'] = $DBResponse['error'];
            return $response;
        }

        $this->delhiveryLog($payload->wbns, 'package', $url, 'GET', $payload, $DBResponse);

        $packageSlips = array(
            'order_id' => $payload->orderId,
            'waybill_no' => $payload->wbns,
            'package_slip' => $DBResponse
        );

        $this->dbo->insert('masters', 'logistic_order_package_slips', $packageSlips);
        $response['message'] = 'Success';
        $response['data'] = $packageSlips;
        return $response;
    }

    public function createPickupReq($payload, $ticket) {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_start", "updatewarehouse", (string) $ticket);
        $response = array("status" => 1, "message" => "", "data" => '');
        $url = DELHIVERYTESTURL . 'fm/request/new/';

        if ($payload->pickup_time == '') {
            $response['status'] = 0;
            $response['message'] = "Please enter valid pickup time.";
            return $response;
        }
        $pickuptime = date('H:i:s', strtotime($payload->pickup_time));

        if ($payload->pickup_date == '') {
            $response['status'] = 0;
            $response['message'] = "Please enter valid pickup date.";
            return $response;
        }
        $pickupdate = date('Y-m-d', strtotime($payload->pickup_date));
        // Check for order exist or not
        $orderFilter = array('$and' => array(array('pickup_status' => 'active'), array('pickup_date' => (string) $pickupdate)));
        $checkOrderDetails = $this->dbo->find('masters', 'logistic_order_pickup_request', $orderFilter, array(), array());

        if ($checkOrderDetails) {
            $response['status'] = 0;
            $response['message'] = "Pickup request already created.";
            return $response;
        }

        $warehouseFilter = array(
            'name' => (string) $payload->pickup_location
        );
        $checkWarehouse = $this->dbo->find('masters', 'logistic_warehouse_list', $warehouseFilter, array(), array());
        if (!$checkWarehouse) {
            $response['status'] = 0;
            $response['message'] = "Please enter valid pickup location.";
            return $response;
        }
        $DBResponse = $this->DEResponse($url, $payload);

        if ($DBResponse['error'] === true) {
            $response['status'] = 0;
            $response['message'] = $DBResponse['data'];
            return $response;
        }

        $DBResponse = $DBResponse['data'];
        if (!isset($DBResponse['client_name'])) {
            $response['status'] = 0;
            $response['message'] = $DBResponse;
            return $response;
        }
        $this->delhiveryLog($payload->pickup_location, 'pickup', $url, 'GET', $payload, $DBResponse);

        $DBResponse['pickup_status'] = 'active';
        $this->dbo->insert('masters', 'logistic_order_pickup_request', $DBResponse);

        unset($DBResponse['client_name']);

        $response['message'] = 'Success';
        $response['data'] = $DBResponse;
        return $response;
    }
    
    public function trackOrder($payload, $ticket) {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_start", "updatewarehouse", (string) $ticket);
        $response = array("status" => 1, "message" => "", "data" => '');
        $url = DELHIVERYTESTURL . 'api/packages/json/?';
        $orderId = $payload->waybill;
        if(isset($payload->trackIdType) && $payload->trackIdType == 'order'){
            
            // Check for order exist or not
            $orderFilter = array(
                '_id' => (int) $orderId
            );

            $orderDetails = $this->dbo->find('masters', 'orders', $orderFilter, array(), array());
            if (!$orderDetails) {
                $response['status'] = 0;
                $response['message'] = "Order details doesn`t exist.";
                return $response;
            }
            
            $payload->waybill = $orderDetails[0]['waybill_no'];
        }
        
        $DBResponse = $this->DEResponse($url, $payload, 'GET', false);

        if ($DBResponse['error'] === true) {
            $response['status'] = 0;
            $response['message'] = $DBResponse['data'];
            return $response;
        }
        
        if (!isset($DBResponse['data']['ShipmentData'][0]['Shipment']['Scans'])) {
            return false;
        }
        
        if (!isset($payload->uiType)) {
            return $this->trackerUIVertical($DBResponse, false);
        }else if($payload->uiType == 'v'){
            return $this->trackerUIVertical($DBResponse, false);
        }else if ($payload->uiType == 'h') {
            return $this->trackerUIHorizontal($DBResponse, false);
        }else if($payload->uiType == 'r'){
            $response['message'] = 'Success';
            $response['data'] = $this->trackerUIVertical($DBResponse, true);
            return $response;
        }
    }

    private function trackerUIVertical($DBResponse, $rawJson) {

        $scanListArray = $DBResponse['data']['ShipmentData'][0]['Shipment']['Scans'];

        /*
         * X-UCI - Order Placed
         * X-PROM - Shipped
         * X-DDD1FD, X-DDO3F - Out for Deliverey
         * 'EOD-135','EOD-136','EOD-141','EOD-143','EOD-145' - Delivered
         */
        $orderPlaced = array('X-UCI');
        $shipped = array('X-PIOM');
        $outForDelhivery = array('X-DDD3FD');
        $delhivery = array('EOD-38');
        $SellerCancelled = array('DTUP-210');
        $consigneCancelled = array('FMEOD-118');
        $cancelledBy = '';
        $orderPlacedStyle = '';
        $rawScanDetails = array();
        foreach ($scanListArray as $key => $scanDetails) {
            $scanDetails = $scanDetails['ScanDetail'];
            $scanStatusCode = $scanDetails['StatusCode'];
            $rawScanDetails[$scanStatusCode] = $scanDetails['Instructions'];

            if (in_array($scanStatusCode, $orderPlaced)) {
                $orderPlacedStyle .= '.orderPlaced::after{background-color: #6fd445; border: 4px solid #31a700; }';
            }

            if (in_array($scanStatusCode, $shipped)) {
                $orderPlacedStyle .= '.orderShipped::after{background-color: #6fd445; border: 4px solid #31a700; }';
            }

            if (in_array($scanStatusCode, $outForDelhivery)) {
                $orderPlacedStyle .= '.outforDelivery::after{background-color: #6fd445; border: 4px solid #31a700; }';
            }

            if (in_array($scanStatusCode, $delhivery)) {
                $orderPlacedStyle .= '.orderDelivered::after{background-color: #6fd445; border: 4px solid #31a700; }';
            }

            if (in_array($scanStatusCode, $SellerCancelled)) {
                $cancelledBy = 'Cancelled by Seller';
                $orderPlacedStyle .= '.orderCancelled::after{background-color: #6fd445; border: 4px solid #31a700; }';
            }

            if (in_array($scanStatusCode, $consigneCancelled)) {
                $cancelledBy = 'Cancelled by Customer';
                $orderPlacedStyle .= '.orderCancelled::after{background-color: #6fd445; border: 4px solid #31a700; }';
            }
        }
        if ($rawJson === true) {
            return $rawScanDetails;
        }

        $html = '<!DOCTYPE html>
            <html>
            <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
            *{
              box-sizing: border-box;
            }
            
            body {
              background-color: #474e5d;
              font-family: Helvetica, sans-serif;
            }

            /* The actual timeline (the vertical ruler) */
            .timeline {
              position: relative;
              max-width: 1200px;
              margin: 0 auto;
            }

            /* The actual timeline (the vertical ruler) */
            .timeline::after {
              content: "";
              position: absolute;
              width: 6px;
              background-color: white;
              top: 0;
              bottom: 0;
              left: 50%;
              margin-left: -3px;
            }

            /* Container around content */
            .container {
              padding: 10px 40px;
              position: relative;
              background-color: inherit;
              width: 50%;
            }

            /* The circles on the timeline */
            .container::after {
              content: "";
              position: absolute;
              width: 25px;
              height: 25px;
              right: -17px;
              background-color: white;
              border: 4px solid #FF9F55;
              top: 15px;
              border-radius: 50%;
              z-index: 1;
            }

            /* Place the container to the left */
            .left {
              left: 0;
            }

            /* Place the container to the right */
            .right {
              left: 50%;
            }

            /* Add arrows to the left container (pointing right) */
            .left::before {
              content: " ";
              height: 0;
              position: absolute;
              top: 22px;
              width: 0;
              z-index: 1;
              right: 30px;
              border: medium solid white;
              border-width: 10px 0 10px 10px;
              border-color: transparent transparent transparent white;
            }

            /* Add arrows to the right container (pointing left) */
            .right::before {
              content: " ";
              height: 0;
              position: absolute;
              top: 22px;
              width: 0;
              z-index: 1;
              left: 30px;
              border: medium solid white;
              border-width: 10px 10px 10px 0;
              border-color: transparent white transparent transparent;
            }

            /* Fix the circle for containers on the right side */
            .right::after {
              left: -16px;
            }

            /* The actual content */
            .content {
                padding: 1px 30px;
                background-color: white;
                position: relative;
                border-radius: 6px;
                width: 204px;
                margin-left: 318px;
            }

            /* Media queries - Responsive timeline on screens less than 600px wide */
            @media screen and (max-width: 600px) {
              /* Place the timelime to the left */
              .timeline::after {
                left: 31px;
              }

              /* Full-width containers */
              .container {
                width: 100%;
                padding-left: 70px;
                padding-right: 25px;
              }

              /* Make sure that all arrows are pointing leftwards */
              .container::before {
                left: 60px;
                border: medium solid white;
                border-width: 10px 10px 10px 0;
                border-color: transparent white transparent transparent;
              }

              /* Make sure all circles are at the same spot */
              .left::after, .right::after {
                left: 15px;
              }

              /* Make all right containers behave like the left ones */
              .right {
                left: 0%;
              }
            }

            @media screen and (max-width: 700px){
              .lefttmenu{
                  margin-left: 0px !important;
              }
            }

              .rightmenu{
                  margin-left: 0px !important;
              }
              
              ' . $orderPlacedStyle . '
              
            </style>
            </head>
            <body>
            <div class="timeline">';

        $html .='<div class="container left orderPlaced">
                <div class="content lefttmenu">
                  <p>Order Placed.</p>
                </div>
              </div>';
        if ($cancelledBy != '') {
            $html .= '<div class="container right orderCancelled">
                  <div class="content rightmenu">
                      <p>' . $cancelledBy . '</p>
                  </div>
              </div>';
        } else {
            $html .= '<div class="container right orderShipped">
                <div class="content rightmenu">
                   <p>Order Shipped.</p>
                </div>
              </div>
              <div class="container left outforDelivery">
                  <div class="content leftmenu">
                      <p>Out for Delivery.</p>
                  </div>
              </div>
              <div class="container right orderDelivered">
                  <div class="content rightmenu">
                      <p>Delivered</p>
                  </div>
              </div>';
        }


        $html .='</div>
            </body>
            </html>
            ';
        return $html;
    }
    
     public function trackerUIHorizontal($DBResponse,$rawJson){
        
        $scanListArray = $DBResponse['data']['ShipmentData'][0]['Shipment']['Scans'];

        /*
         * X-UCI - Order Placed
         * X-PROM - Shipped
         * X-DDD1FD, X-DDO3F - Out for Deliverey
         * 'EOD-135','EOD-136','EOD-141','EOD-143','EOD-145' - Delivered
         */
        $orderPlaced = array('X-UCI');
        $shipped = array('X-PIOM');
        $outForDelhivery = array('X-DDD3FD');
        $delhivery = array('EOD-38');
        $SellerCancelled = array('DTUP-210');
        $consigneCancelled = array('FMEOD-118');
        $rawScanDetails = array();
        $orderPlacedStyle = 'progtrckr-todo';
        $orderShippedStyle = 'progtrckr-todo';
        $outforDeliveryStyle = 'progtrckr-todo';
        $orderDeliveredStyle = 'progtrckr-todo';
        $cancelledBy = '';
        foreach ($scanListArray as $key => $scanDetails) {
            $scanDetails = $scanDetails['ScanDetail'];
            $scanStatusCode = $scanDetails['StatusCode'];
            $rawScanDetails[$scanStatusCode] = $scanDetails['Instructions'];

            if (in_array($scanStatusCode, $orderPlaced)) {
                $orderPlacedStyle = 'progtrckr-done';
            }

            if (in_array($scanStatusCode, $shipped)) {
                $orderShippedStyle = 'progtrckr-done';
            }

            if (in_array($scanStatusCode, $outForDelhivery)) {
                $outforDeliveryStyle = 'progtrckr-done';
            }

            if (in_array($scanStatusCode, $delhivery)) {
                $orderDeliveredStyle = 'progtrckr-done';
            }

            if (in_array($scanStatusCode, $SellerCancelled)) {
                $cancelledBy = 'Cancelled by Seller';
            }

            if (in_array($scanStatusCode, $consigneCancelled)) {
                $cancelledBy = 'Cancelled by Customer';
            }
        }
        if ($rawJson === true) {
            return $rawScanDetails;
        }
        $html = '<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
                        <!--[if lt IE 9]>
                          <script src="http://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.2/html5shiv.js"></script>
                        <![endif]-->

                            <style>
                                    ol.progtrckr {
                        margin: 0;
                        padding: 0;
                        list-style-type none;
                    }

                    ol.progtrckr li {
                        display: inline-block;
                        text-align: center;
                        line-height: 3.5em;
                    }

                    ol.progtrckr[data-progtrckr-steps="2"] li { width: 49%; }
                    ol.progtrckr[data-progtrckr-steps="3"] li { width: 33%; }
                    ol.progtrckr[data-progtrckr-steps="4"] li { width: 24%; }
                    ol.progtrckr[data-progtrckr-steps="5"] li { width: 19%; }
                    ol.progtrckr[data-progtrckr-steps="6"] li { width: 16%; }
                    ol.progtrckr[data-progtrckr-steps="7"] li { width: 14%; }
                    ol.progtrckr[data-progtrckr-steps="8"] li { width: 12%; }
                    ol.progtrckr[data-progtrckr-steps="9"] li { width: 11%; }

                    ol.progtrckr li.progtrckr-done {
                        color: black;
                        border-bottom: 4px solid yellowgreen;
                    }
                    ol.progtrckr li.progtrckr-todo {
                        color: silver; 
                        border-bottom: 4px solid silver;
                    }

                    ol.progtrckr li:after {
                        content: "\00a0\00a0";
                    }
                    ol.progtrckr li:before {
                        position: relative;
                        bottom: -2.5em;
                        float: left;
                        left: 50%;
                        line-height: 1em;
                    }
                    ol.progtrckr li.progtrckr-done:before {
                        content: "\2713";
                        color: white;
                        background-color: yellowgreen;
                        height: 2.2em;
                        width: 2.2em;
                        line-height: 2.2em;
                        border: none;
                        border-radius: 2.2em;
                    }
                    ol.progtrckr li.progtrckr-todo:before {
                        content: "\039F";
                        color: silver;
                        background-color: white;
                        font-size: 2.2em;
                        bottom: -1.2em;
                    }


                            </style>

                         <ol class="progtrckr" data-progtrckr-steps="5">
                        <li class="progtrckr-done">Order Placed</li>';
                        if ($cancelledBy != '') {
                            $html .= '<li class="progtrckr-done">' . $cancelledBy . '</li>';
                        }else{
                            $html .= '<li class="'.$orderShippedStyle.'">Order Shipped</li>
                                    <li class="'.$outforDeliveryStyle.'">Out for Delivery</li>
                                    <li class="'.$orderDeliveredStyle.'">Delivered</li>';
                        }
                        
                    $html .= '</ol>';
                    
                    return $html;
    }

    public function updateDelStatusDetails($payload, $ticket) {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "function_start", "updateDelStatusDetails", (string) $ticket);
        $response = array("status" => 1, "message" => "", "data" => '');

        // Check for order exist or not
        $orderFilter = array('waybill_no' => (string) $payload->Shipment->AWB);
        $checkOrderDetails = $this->dbo->find('masters', 'orders', $orderFilter, array(), array());

        if (!$checkOrderDetails) {
            $response['status'] = 0;
            $response['message'] = "Order details doesn`t exist.";
            return $response;
        }

        $setDocument = array(
            'delhiveryLiveStatus' => $payload->Shipment->Status->Status,
        );
        $pushDocument = array(
            'delhivery_live_tracking' => $payload->Shipment
        );

        $updateResult = $this->dbo->update("masters", "orders", $orderFilter, $setDocument, $pushDocument, array("multi" => true));

        $response['message'] = 'Success';
        return $response;
    }

    public function delhiveryLog($logId, $logType, $url, $httpType, $request, $response) {

        $insertArray = array(
            'log_id' => $logId,
            'log_type' => $logType,
            'url' => $url,
            'method' => $httpType,
            'request' => $request,
            'response' => $response
        );

        $this->dbo->insert('masters', 'logistic_log', $insertArray);
    }

}
