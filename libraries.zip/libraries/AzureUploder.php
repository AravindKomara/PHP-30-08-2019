<?php

//https://github.com/Azure/azure-storage-php/blob/master/samples/BlobSamples.php
require_once "../blob/vendor/autoload.php"; 

use MicrosoftAzure\Storage\Blob\BlobRestProxy;
use MicrosoftAzure\Storage\Blob\Models\CreateContainerOptions;
use MicrosoftAzure\Storage\Blob\Models\PublicAccessType;
use MicrosoftAzure\Storage\Common\Exceptions\ServiceException;

class AzureUploder
{

    public $blobClient = null;
    public $accountName = AZURE_ACCOUNT_NAME; //ACCOUNT_NAME;
    public $accountKey = AZURE_ACCOUNT_KEY; //ACCOUNT_KEY;
    public $connectionString = null;
    public $container = 'logs';

    public function __construct()
    {
        $this->connectionString = 'DefaultEndpointsProtocol=https;AccountName=' . AZURE_ACCOUNT_NAME . ';AccountKey=' . AZURE_ACCOUNT_KEY;
        $this->blobClient = BlobRestProxy::createBlobService($this->connectionString);
        //$this->blobClient = ServicesBuilder::getInstance()->createBlobService($this->connectionString);
    }

    // To create a container call createContainer.
    //createContainerSample($blobClient); only one time

    // To upload a file as a blob, use the BlobRestProxy->createBlockBlob method. This operation will
    // create the blob if it doesn��t exist, or overwrite it if it does. The code example below assumes
    // that the container has already been created and uses fopen to open the file as a stream.
    //uploadBlobSample($blobClient);

    // To download blob into a file, use the BlobRestProxy->getBlob method. The example below assumes
    // the blob to download has been already created.
    //downloadBlobSample($blobClient);

    // To list the blobs in a container, use the BlobRestProxy->listBlobs method with a foreach loop to loop
    // through the result. The following code outputs the name and URI of each blob in a container.
    //listBlobsSample($blobClient);

    public function create_container($container_name, $metadata = array())
    {
        // OPTIONAL: Set public access policy and metadata.
        // Create container options object.
        $createContainerOptions = new CreateContainerOptions();

        // Set public access policy. Possible values are
        // PublicAccessType::CONTAINER_AND_BLOBS and PublicAccessType::BLOBS_ONLY.
        // CONTAINER_AND_BLOBS: full public read access for container and blob data.
        // BLOBS_ONLY: public read access for blobs. Container data not available.
        // If this value is not specified, container data is private to the account owner.
        $createContainerOptions->setPublicAccess(PublicAccessType::CONTAINER_AND_BLOBS);

        // Set container metadata
        if (!empty($metadata)) {
            foreach ($metadata as $key => $value) {
                $createContainerOptions->addMetaData($key, $value);
            }
        }
        $createContainerOptions->addMetaData("CreatedOn", date('Y-m-d H:i:s'));

        try {
            // Create container.
            $this->blobClient->createContainer($container_name, $createContainerOptions);
            return true;
        } catch (ServiceException $e) {
            $code = $e->getCode();
            $error_message = $e->getMessage();
            //echo $code.": ".$error_message.PHP_EOL;
            return false;
        }
    }

    public function delete_container($container = null, $filepath = null)
    {
        if (empty($container)) {
            $container = $this->container;
        }

        try {
            $t = $this->blobClient->deleteContainer($container);
        } catch (ServiceException $e) {
            $code = $e->getCode();
            $error_message = $e->getMessage();
            //echo $code.": ".$error_message.PHP_EOL;
        }
    }

    // uses : upload_blob('logs','/var/www/html/access.log','/instance/myblob1.log');
    public function upload_blob($container = null, $filepath = null, $blob_name)
    {
        $content = fopen($filepath, "r");
        if (empty($container)) {
            $container = $this->container;
        }

        try {
            return $this->blobClient->createBlockBlob($container, $blob_name, $content);
        } catch (ServiceException $e) {
            $code = $e->getCode();
            $error_message = $e->getMessage();
            //echo $code.": ".$error_message.PHP_EOL;
        }
    }

    // uses : upload_blob('logs','/var/www/html/access.log',data (string));
    public function append_blob($container = null, $filepath = null, $blob_content)
    {
        //echo $blob_content;
        if (empty($container)) {
            $container = $this->container;
        }

        try {
            //$t = $this->blobClient->appendBlockAsync( $container , $filepath, $blob_content);
            //$start_time = microtime(TRUE);
            $t = $this->blobClient->appendBlock($container, $filepath, $blob_content);
            //$end_time = microtime(TRUE);
            //echo number_format($end_time - $start_time, 4). '<br>';
        } catch (ServiceException $e) {
            $code = $e->getCode();
            $error_message = $e->getMessage();
            //echo $code.": ".$error_message.PHP_EOL;
        }
    }

    public function create_append_blob($container = null, $filepath = null)
    {
        //var_dump($filepath); die;
        if (empty($container)) {
            $container = $this->container;
        }

        try {
            $t = $this->blobClient->createAppendBlob($container, $filepath, null);
        } catch (ServiceException $e) {
            $code = $e->getCode();
            $error_message = $e->getMessage();
            echo $code . ": " . $error_message . PHP_EOL;
        }
        //var_dump($filepath); die;
        if (!empty($code)) {
            return 0;
        }
        return 1;
    }

    public function create_blob($container = null, $filepath = null, $content = null)
    {
        //var_dump($filepath); die;
        if (empty($container)) {
            $container = $this->container;
		}
		try {
			$t = $this->blobClient->createBlockBlob($container, $filepath, $content);
			return true;
        } catch (ServiceException $e) {
            $code = $e->getCode();
            $error_message = $e->getMessage();
            echo $code . ": " . $error_message . PHP_EOL;
        }
        //var_dump($filepath); die;
        if (!empty($code)) {
            return 0;
        }
        
    }

    public function get_blob($container = null, $filepath = null)
    {
        //var_dump($blob_content); die;
        if (empty($container)) {
            $container = $this->container;
        }

        try {
            //Upload blob
            $t = $this->blobClient->getBlob($container, $filepath);
        } catch (ServiceException $e) {
            $code = $e->getCode();
            $error_message = $e->getMessage();
            //echo $code.": ".$error_message.PHP_EOL;
        }
    }

    public function delete_blob($container = null, $filepath = null)
    {
        if (empty($container)) {
            $container = $this->container;
        }

        try {
			$t = $this->blobClient->deleteBlob($container, $filepath);
			return $t;
        } catch (ServiceException $e) {
            $code = $e->getCode();
            $error_message = $e->getMessage();
			//echo $code.": ".$error_message.PHP_EOL;
			return false;
        }
    }

    // uses : download_blob('logs','/instance/myblob1.log',['/var/www/html/access.log']);
    public function download_blob($container = null, $blog_name, $download_location = null)
    {
        if (empty($container)) {
            $container = $this->container;
        }

        try {
            $getBlobResult = $this->blobClient->getBlob($container, $blog_name);
        } catch (ServiceException $e) {
            $code = $e->getCode();
            $error_message = $e->getMessage();
            //echo $code.": ".$error_message.PHP_EOL;
        }
        if (!empty($download_location)) {
            $download_location = '/var/www/html/temp/' . basename($blog_name);
            file_put_contents($download_location, $getBlobResult->getContentStream());
        } else {
            file_put_contents($download_location, $getBlobResult->getContentStream());
            $file_url = $download_location;
            header('Content-Type: application/octet-stream');
            header("Content-Transfer-Encoding: Binary");
            header("Content-disposition: attachment; filename=\"" . basename($file_url) . "\"");
            ob_clean();
            flush();
            readfile($file_url);
            unlink($file_url);
        }
    }

    public function list_blobs($container = null)
    {
        try {
            // List blobs.
            $start_time = microtime(true);
            $blob_list = $this->blobClient->listBlobs($container);
            $end_time = microtime(true);
            echo number_format($end_time - $start_time, 4);
            $blobs = $blob_list->getBlobs();
            $rest = array();
            foreach ($blobs as $blob) {
                //echo $blob->getName().": ".$blob->getUrl().PHP_EOL;
                $rest[] = array('name' => $blob->getName(), 'url' => $blob->getUrl(), 'contentLength' => $blob->getProperties());
            }
            return $rest;
        } catch (ServiceException $e) {
            $code = $e->getCode();
            $error_message = $e->getMessage();
            echo $code.": ".$error_message.PHP_EOL;
            return false;
        }
    }
}
