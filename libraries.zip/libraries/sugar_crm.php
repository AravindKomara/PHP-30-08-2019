<?php

class SugarCRM extends Oms
{
    public function __construct()
    {
        parent::__construct();
    }

    public function raise_ticket($payload)
    {
        create_debug_log($payload->order_id, 'SugarCrm', $payload, __FILE__);
        if (empty($payload->order_id)) {
            $response = array("status" => 0, "message" => "Please provide order_id in request");
            return $response;
        }
        $filter = array("_id" => (int) $payload->order_id);
        //print_r($filter); exit;
        $dbo = new Dbo;

        $result = $dbo->findOne("masters", "orders", $filter, array());
        //var_dump($result); exit;
        //echo json_encode($result);exit;
        if (isset($payload->type) && $payload->type!="POST" &&  $payload->type!="GET" &&  $payload->type!="Post") {
            $type = $payload->type;
        } else {
            $type = "Request";
        }

        $slant = (ENV_MODE == 'PROD') ? '' : '-' . ENV_MODE;
        $subject = 'Test';
        if (isset($payload->subject)) {
            $subject = $payload->subject;
        }
        //if($result['OStatus']!='15'&&$result['OStatus']!='16'&&$result['OStatus']!=null)
        unset($payload->ticket);
        $payload->case_number = "";
        $payload->subject = $subject . $slant;
        $payload->status = "OPEN_NEW";
        $payload->priority = "High";
        $payload->source = "Phone";
        $payload->type = $type;
        $payload->agent = $result['order']['patientinfo']['source_type'];
        $payload->description =  $payload->sub_category_description;
        $payload->resolution = "";
        $payload->rca = "";
        $payload->created_time = $result['order']['order_status']['created_date'];
        $payload->due_time = (string) $result['order']['patientinfo']['scheduled_date'];
        $payload->location = $result['order']['patientinfo']['area'];
        $payload->mrn = $result['order']['patientinfo']['mrn'];
        $payload->customer_name = $result['order']['patientinfo']['name'];
        $payload->order_id = $result['order']['patientinfo']['order_id'];
        $payload->business = $this->utility->getbusinessName($result['order']['patientinfo']['service_type']);
        $payload->category = $payload->category;
        $payload->sub_category = $payload->sub_category;
        $payload->sub_category_description = $payload->sub_category_description;
        $payload->closed_time = "";
        $payload->updated_time = "";
        $payload->first_response_time = "";
        $payload->first_response_status = "";
        $payload->tags = "";
        $payload->rating = "";

        $data = array($payload);
        $result = json_encode($data);
        // https://choicev3.callhealth.com/rest/raiseATicket
        //echo $result;exit;
        $url = $this->config->getconfig('CPchoice_url', 'raiseATicket');
        //print_r($url);exit;
        $startTime = microtime(true);
        $finalResult = $this->utility->my_curl($url, 'POST', $result, 'json', null, 10);
        $this->log->logThirdPartyCall("SUGAR_CRM", $url, $startTime, $data, $finalResult);
        //print_r($data);exit;
        return $finalResult;

    }
}
