<?php

class Gcm extends Oms
{
    public function __construct()
    {
        parent::__construct();
    }

    public function getname()
    {
        return "gcm";
    }

    public function get_patient_details($buffer, $mrnIds)
    {
        $patient_details = $buffer[allCustDetails];
        foreach ($mrnIds as $mrn) {
            $details = $patient_details[$mrn];
            $dummy = array();
			/* if($details[mobile]=="" || $details[mobile]==null)
			{
				$mobile=$details[secondaryMobile];
				$email=$details[secondaryEmail];
			}
			else
			{
				$mobile=$details[mobile];
				$email=$details[email];
			} */
			
			$email=$details[contactEmail];
            $mobile=$details[contactMobile];
            $dummy['mrn'] = $details[mrn];
            $dummy['patient_id'] = $details[patientId];
            $dummy['salutation'] = $details[salutation];
            $dummy['name'] = $details[firstName] . " " . $details[lastName];
            $dummy['firstName'] = $details[firstName] ;
			$dummy['lastName'] = $details[lastName];
			$dummy['profilePhotoUrl'] = $details[profilePhotoUrl];
            $dummy['age'] = $details[age];
            $dummy['gender'] = $details[gender];
            $dummy['contact'] = $mobile;
            $dummy['alternatecontactno'] =  $details[secondaryMobile]; // NOT AVAILABLE WITH THE SPECIFIED API
            $dummy['email'] = $email;
			$dummy['tags'] = $details[tags];
            $output['mrn'][$mrn] = $dummy;
        }
        return $output;
    }

    public function get_address_details($buffer, $addressIds)
    {
        $address_details = $buffer[allAddressDetails];
        foreach ($addressIds as $address_id) {
            $details = $address_details[$address_id];
            $dummy = array();
            $dummy['address_id'] = $details[AddressId];
            $dummy['landmark'] = $details[Landmark];
            $dummy['pincode'] = $details[zipcodeVal];
            //$dummy['address'] = $details[Landmark] . "," . $details[areaVal] . "," . $details[cityVal] . "," . $details[stateVal];
            $dummy['address'] = $details[addressVal] . "," . $details[areaVal] . "," . $details[cityVal] . "," . $details[stateVal];
            $dummy['city'] = $details[cityVal];
            $dummy['state'] = $details[stateVal];
            $dummy['district'] = $details[district];

            //$dummy['home_facility_id']= ""; // NOT AVAILABLE WITH THE SPECIFIED API
            //$dummy['home_popname']=""; // NOT AVAILABLE WITH THE SPECIFIED API

            $dummy['delivery_lat'] = $details[LatVal];
            $dummy['delivery_lng'] = $details[LngVal];
            $output['address_id'][$address_id] = $dummy;
            $pincode[$address_id] = $dummy['pincode'];
        }
		
		//FETCHING POP DETAILS FROM PINCODE => COMMENTED
        /* //print_r($pincode);exit;
        //$pincode = ["500030","500012"];//DUMMY PINCODES THAT WORK
        $pin_payload = json_encode(array("pincodes" => $pincode));
        //$sub_url = 'mdm/services/fetchservice/getPopsByZip';

        $sub_url = 'fetchservice/getPopsByZip';
        $url = $this->config->getConfig("mdmpath", $sub_url);

        $startTime = microtime(true);
        $resp = $this->utility->my_curl($url, 'POST', $pin_payload, 'json', null, 10);
        $this->log->logThirdPartyCall("GCM", $url, $startTime, json_decode($pin_payload), $resp);

        if (empty($resp)) {
            $response = json_encode(array("response" => 0, "message" => "Nothing returned from PINCODE API."));
            $output['address_id'][$address_id][facility_id] = "";
            //SET AS EMPTY STRING IF DATA NOT FOUND
            $output['address_id'][$address_id][popname] = "";
        } else {
            foreach ($addressIds as $address_id) {
                $details = $address_details[$address_id];
                $output['address_id'][$address_id][facility_id] = $resp[$details[zipcodeVal]][popid];
                $output['address_id'][$address_id][popname] = $resp[$details[zipcodeVal]][popname];
            }
        } */
        
        
        //code to get pincode area details
        $pin_payload = json_encode(array("pincodes" => array_values($pincode) ));
        //$sub_url = 'mdm/services/fetchservice/getPopsByZip';

        $sub_url = 'fetchservice/pincodeDetails';
        $url = $this->config->getConfig("mdmpath", $sub_url);

        $startTime = microtime(true);
        $resp = $this->utility->my_curl($url, 'POST', $pin_payload, 'json', null, 10);
        //print_r($resp);exit;
        $this->log->logThirdPartyCall("GCM", $url, $startTime, json_decode($pin_payload), $resp);

        if (empty($resp)) {
            $response = json_encode(array("response" => 0, "message" => "Nothing returned from PINCODE API."));
           
        } 
        else 
        {
            foreach ($pincode as $key => $pin) {
                //$details = $address_details[$address_id];
                $output['address_id'][$key][state] = $resp['data'][$pin][0][stateName];
                $output['address_id'][$key][district] = $resp['data'][$pin][0][districtName];
                $output['address_id'][$key][cityID] = $resp['data'][$pin][0][id];
                $output['address_id'][$key][postOfficeType] = $resp['data'][$pin][0][postOfficeType];
                $output['address_id'][$key][postOfficeName] = $resp['data'][$pin][0][postOfficeName];
            }
        }
        
        //print_r($output);exit; 

        return $output;
    }

    public function get_mrn_address_info($mrnIds, $addressIds)
    {
        // $mrnIds = rtrim( implode(',', $mrnIds) , ',');
        // $addressIds = rtrim( implode(',', $addressIds) , ',');
        //echo $mrnIds;
        $patient_payload = array("mrnIds" => $mrnIds, "addressIds" => $addressIds);
        $patient_payload = json_encode($patient_payload);

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "get_mrn_address_info_start", $patient_payload, (string) $ticket);

        try
        {
            $sub_url = 'GcmJava/services/gcm/oms/getbulkdetails';
            $url = $this->config->getConfig("cpservicepath", $sub_url); //URL to hit
			//print_r($this->config);
           //echo $url.json_encode($patient_payload);exit;
            $startTime = microtime(true);
            $buffer = $this->utility->my_curl($url, 'POST', $patient_payload, 'json', null, 10);
            $this->log->logThirdPartyCall("GCM", $url, $startTime, json_decode($patient_payload), $buffer);

            $output = array();
            if (empty($buffer[allCustDetails]) and empty($buffer[allAddressDetails])) {
                $output = json_encode(array("response" => 0, "message" => "No Result returned from GCM API."));
                echo $output;
                exit;
                /* foreach($mrnIds as $mrn)
            {
            $mrn_details[mrn][$mrn][mrn] = $mrn;
            }
            foreach($addressIds as $addressId)
            {
            $address_details[address_id][$addressId][address_id] = $addressId;
            } */
            } else if (empty($buffer[allCustDetails]) and !empty($buffer[allAddressDetails])) {
                $output = json_encode(array("response" => 0, "message" => "Patient(mrn) Details Missing from GCM API."));
                echo $output;
                exit;
                /* foreach($mrnIds as $mrn)
            {
            $mrn_details[mrn][$mrn][mrn] = $mrn;
            }
            $address_details = $this->get_address_details($buffer,$addressIds); */
            } else if (!empty($buffer[allCustDetails]) and empty($buffer[allAddressDetails])) {
                $output = json_encode(array("response" => 0, "message" => "Address Details Missing from GCM API."));
                echo $output;
                exit;
                /* foreach($addressIds as $addressId)
            {
            $address_details[address_id][$addressId][address_id] = $addressId;
            }
            $mrn_details = $this->get_patient_details($buffer,$mrnIds); */
            } else {
                //$buffer = json_decode($buffer, true);
                //print_r($buffer);exit;

                $mrn_details = $this->get_patient_details($buffer, $mrnIds);
                //print_r($mrn_details);exit;

                $address_details = $this->get_address_details($buffer, $addressIds);
                //print_r($address_details);exit;

                $output = array_merge($mrn_details, $address_details);
            }
            //$output = array_merge($mrn_details,$address_details);
            //print_r($output);exit;
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_get_mrn_address_info", $e->getMessage(), (string) $ticket);
        }

        $this->log->create_log("", "", $this->getname(), "Execution", 200, "get_mrn_address_info_end", $output, (string) $ticket);
        //print_r($output);exit;
        return $output;
    }

    public function customer_search($searchtype="",$searchvalue,$ticket,$records_per_page = 10,$pagenumber = 1)
    {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "customer_search_start", $patient_payload, (string) $ticket);
        try
        {
            $sub_url = 'GcmJava/services/gcm/oms/customer/search'; //OLD URL
            $url = $this->config->getConfig("cpservicepath", $sub_url); //URL to hit
            $payload = array(
				"searchType"=>$searchtype,
                "searchText" => $searchvalue,
                "recordsPerPage" => (string) $records_per_page,
                "pageNumber" => (string) $pagenumber,
            );
			
            $payload = json_encode($payload);
            $startTime = microtime(true);
            $responceData = $this->utility->my_curl($url, 'POST', $payload, 'json', null, 10);			
            $this->log->logThirdPartyCall("GCM", $url, $startTime, json_decode($payload), $responceData);

            if (empty($responceData) or (int)$responceData['status']==0 or $responceData==null) 
			{
                $buffer = array('status' => 0, 'message' => "Empty GCM Response!",
								'data'=>$responceData);
            }else{
				$buffer = array('status' => 1, 'message' => "Successfully GCM Response",'data' => $responceData);
			}
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "Error_customer_search", $e->getMessage(), (string) $ticket);
        }
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "customer_search_end", $responceData, (string) $ticket);
        return $buffer;
    }

    function getPrescriptionFromGcm($payload)
    {
        $mrn = $payload->mrn;
        $data1=array();
        $url=$this->config->getconfig('doctorurl','/services/clinics/getPrescriptionByMrn');
        $req_data = json_encode(array("mrn"=>$payload->mrn,"type"=>"prescriptions"));
        //echo $url.' '.$req_data;exit;
        //print_r($req_data);exit;
        $result = $this->utility->my_curl($url, 'POST', $req_data, 'json', null, 10);
        //print_r($result);exit;

        $data = json_decode($result);
        foreach($data->data as $val)
        {
            if((int)$val->appointmentId==(int)$encid)  
            {
                $data1["itemlist"][]=$getvars['doctorurl'].'services/clinics/getPatientDocumentFile/documents/'.$val->id;
            }
        }
       return $data1;  
    }

     function customerClassification($payload)  
    {   
        $idorder=array();
        $result = array(); 
        $mainresult = array();
         
        if($payload->searchdate==null || $payload->searchduration==null ||
						$this->utility->validateDate_Ymd($payload->searchdate) == false )
        {
            $response["status"]="0";
            $response["message"]="Please provide required parameters(searchdate(YYYY-MM-DD), searchduration(no. of months).";
			return $response;
        }
        else
        {
            $input_date = isset($payload->searchdate)?$payload->searchdate:"";
            $input_duration = isset($payload->searchduration)?$payload->searchduration:"";
            $till_date = date('Y-m-d', strtotime('-'.$input_duration.' Months',strtotime($input_date)));
            $input_date = date('Y-m-d', strtotime($input_date));
            $filterpatient = array("order.order_status.created_date" => array('$gte' => $till_date, '$lte' => $input_date));
            $filterpatient["OStatus"]=6;

            $cursor = $this->dbo->find("masters","orders",$filterpatient,array(),array());
            if(count($cursor)>0) 
            {
                foreach ($cursor as $document) 
                {                   
                    $result[$document['_id']]=$document;
                    array_push($idorder,$document['_id']);
                }
            }

             $project_order=array( 
                'mrn'=>'$order.patientinfo.mrn',
                "orderId"=>'$_id',
                'business'=>'$order.patientinfo.service_type',
                'status'=>'$OStatus',
                'date'=>'$order.order_status.created_date',
                'amount'=>'$order.patientinfo.net_amount',
                'tags'=>'$order.patientinfo.service_type'
            );

            $filterpatient =array('$and'=> array(array("_id"=>array('$in'=>$idorder)),
                             array('$or'=>array(
                                            array('order.patientinfo.service_type'=>array('$nin'=>array('5','6','7','8'))),
                                            array('order.patientinfo.service_type'=>array('$in'=>array('5','6','7','8')),
                                            'order.business.is_parent'=>1)
                         ))
            ));

            $pipeline = array(array('$match'=>$filterpatient),array('$project'=>$project_order));
            //echo json_encode($pipeline);exit;
            $mainresult = $this->dbo->aggregate("masters","orders",$pipeline);

            if(count($mainresult)>=0)
            {
                $response = array("status"=>"1","message"=>"Success","count"=>count($mainresult),"data"=>$mainresult);
            }
            else
            {
                $response = array("status"=>"0","message"=>"No Data Found","data"=>array());
            }
            return $response;
        }   
    }
	
	public function getAddress($payload,$ticket) 
    {
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "getAddressStart", $payload, (string) $ticket);
        try
        {
            $sub_url = 'GcmJava/services/gcm/cp/address/details'; //OLD URL
            $url = $this->config->getConfig("cpservicepath", $sub_url); //URL to hit
            $payload = array(
                "mrn"=>(string)$payload->mrn
            );
            
            $payload = json_encode($payload);
            $startTime = microtime(true);
            $responceData = $this->utility->my_curl($url, 'POST', $payload, 'json', null, 10);          
            $this->log->logThirdPartyCall("GCM", $url, $startTime, json_decode($payload), $responceData);

            if (empty($responceData) or $responceData['status']==0) {
                $buffer = array('status' => 0, 'message' => "Empty GCM Response!",'data'=>$responceData);
            }else{
                $buffer = array('status' => 1, 'message' => "Successfull GCM Response",'data' => $responceData);
            }
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
            $this->log->create_log("", "", $this->getname(), "Execution", 300, "error_fetchAddress", $e->getMessage(), (string) $ticket);
        }
        $this->log->create_log("", "", $this->getname(), "Execution", 200, "getAddressEnd", $responceData, (string) $ticket);
        return $buffer;
    }

	
	public function modifyAddress($payload, $ticket)
	{
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "modifyAddressStart", $payload, (string) $ticket);
        try
        {
			$reqtype = $payload->action;
			
			if(strtolower($reqtype) == 'update')
			{
				if(!isset($payload->addressId))
				{
					$response = array("status"=>0,"message"=>"Updating of address needs addressId");
					$this->log->create_log("", "", $this->getname(), "Execution", 200, "modifyAddressEnd", $response, (string) $ticket);
					return $response;
				}
				$sub_url = 'GcmJava/services/gcm/cp/address/update';
			}
			else if(strtolower($reqtype) == 'add')
			{
				$sub_url = 'GcmJava/services/gcm/cp/address/create';
			}
			
			else
			{
				$response = array("status"=>0,"message"=>"Invalid or no action");
				
				$this->log->create_log("", "", $this->getname(), "Execution", 200, "modifyAddressEnd", $response, (string) $ticket);
				return $response;
			}
			
			
			$url = $this->config->getconfig('cpservicepath',$sub_url);
			$payload = json_encode($payload);
			
			$startTime = microtime(true);
			$buffer = $this->utility->my_curl($url, 'POST', $payload, 'json', null, 20);
			
			$this->log->logThirdPartyCall("GCM", $url, $startTime, json_decode($payload),$buffer);
			//echo $url." ".$payload;exit;
			
			if(!empty($buffer) and $buffer['status']==1)
			{
				$response = array("status" => 1,"message" => "Success","data" => $buffer);
				
				$this->log->create_log("", "", $this->getname(), "Execution", 200, "modifyAddressEnd", $response, (string) $ticket);
				return $response;
			}
			else
			{
				$response = array("status" => 0,"message" => "Data Not Found","data" => $buffer);
				
				$this->log->create_log("", "", $this->getname(), "Execution", 200, "modifyAddressEnd", $response, (string) $ticket);
				return $response;
			}
			
			
		}
		
		catch (Exception $e) 
		{
           echo 'Message: ' . $e->getMessage();
           $this->log->create_log("", "", $this->getname(), "Execution", 300, "error_modifyAddress", $e->getMessage(), (string) $ticket);
        }
			
			
	}

    public function send_care_plan($payload,$ticket)
    {
        $result = json_encode($payload);
        $url = 'http://doctoruatv3.callhealth.com/services/officer/saveCarePlanTemplate';
        $data = $this->utility->async_curl($url,$result);

        if(empty($data))
        {
            $response = array("status"=>0,"message"=>"No data returned from GCM API");
            return $response;
        }
        else
        {
            $response = array("status"=>1,"message"=>"Successfull");
            return $response; 
        }

    }
	
	public function prescriptionFromDoctor($payload, $ticket)
	{
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "prescriptionFromDoctorStart", $payload, (string) $ticket);
		try
		{
			$sub_url = '/services/clinics/prescription';
			$url = $this->config->getconfig('doctorurl',$sub_url);
			$payload = json_encode($payload);
			
			//echo $url." ".$payload;exit;
			
			$startTime = microtime(true);
			$buffer = $this->utility->my_curl($url, 'POST', $payload, 'json', null, 20);
			//print_r($buffer);exit;
			$this->log->logThirdPartyCall("GCM", $url, $startTime, json_decode($payload),$buffer);
			
			$result = array();
			if($buffer['status'] == 1)
			{
				$result['filename'] = $buffer['prescription_name'];
				$result['filepath'] = "";
				$result['fullpath'] = $buffer['prescription_filepath'];
				$result['uploaded_from'] = 'doctor';
				$result['prescription_id'] = $buffer['prescription_id'];
			}
			else
			{
				$result= array("status"=>0,"message"=>$buffer);
			}
			
			
			$this->log->create_log("", "", $this->getname(), "Execution", 200, "prescriptionFromDoctorEnd", json_encode($buffer), (string) $ticket);
			return $result;
		}
		
		catch (Exception $e) 
		{
           echo 'Message: ' . $e->getMessage();
           $this->log->create_log("", "", $this->getname(), "Execution", 300, "error_prescriptionFromDoctorEnd", $e->getMessage(), (string) $ticket);
        }
	}
	
		
	public function customerUpdate($payload,$ticket)
    {
		$this->log->create_log("", "", $this->getname(), "Execution", 200, "customerUpdateStart", $payload, (string) $ticket);
		try
		{
		   $payload = json_encode($payload);
		   //print_r($payload);exit;

		   $sub_url = 'GcmJava/services/gcm/oms/customer/update';
		   $url = $this->config->getconfig('cpservicepath',$sub_url);  
		   //echo $url;exit;
		   
		   $startTime = microtime(true);
		   $result = $this->utility->my_curl($url, 'POST', $payload, 'json', null, 20);
		   // print_r($result);exit;
		   $this->log->logThirdPartyCall("GCM", $url, $startTime, json_decode($payload),$result);
		   
		   $this->log->create_log("", "", $this->getname(), "Execution", 200, "customerUpdateEnd", json_encode($result), (string) $ticket);
		}
		catch (Exception $e) 
		{
           $result = array("response"=>"0","errorMessage"=>$e->getMessage());
           $this->log->create_log("", "", $this->getname(), "Execution", 300, "error_customerUpdate", $e->getMessage(), (string) $ticket);
        }
		return $result; 
    }	
		
	
	
	
}
