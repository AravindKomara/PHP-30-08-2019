<?php

class Choice extends Oms
{
    public function __construct()
    {
        parent::__construct();
    }

    public function getname()
    { 
        return "choice";
    }

    function getPrescriptionCP($payload){
    	//print_r($payload);exit;
        $utilityobj = new Utility;
        $mrn = isset($payload->mrn) ? $payload->mrn : "";
        $url=$this->config->getconfig('CPchoice_url','priscriptionData');
        $parameter = json_encode(array("mrn" => $mrn));
        $result = $utilityobj->my_curl($url,'POST',$parameter,'json',null,10);
        //$result = $utilityobj->my_curl($url,'GET',null,'json',null,10);
        return $result;
    }
	
	function uploadPrescriptionCP($payload){
    	//print_r($payload);exit;
        $utilityobj = new Utility;
        $url=$this->config->getconfig('CPchoice_url','omsUpload');
        $result = $utilityobj->my_curl($url,'POST',$payload,'form-data-multipart',null,10);
        //$result = $utilityobj->my_curl($url,'GET',null,'json',null,10);
        return $result;
    }

}//end of main class